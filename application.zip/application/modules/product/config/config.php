<?php
// module directory name
$HmvcConfig['product']["_title"]     = "product Details ";
$HmvcConfig['product']["_description"] = "Simple product processing System";
	  
$HmvcConfig['product']['_database'] = true;
$HmvcConfig['product']["_tables"] = array( 
	'product_information',
);