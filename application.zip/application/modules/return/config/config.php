<?php
// module directory name
$HmvcConfig['return']["_title"]     = "return Details ";
$HmvcConfig['return']["_description"] = "Simple return processing System";
	  
$HmvcConfig['return']['_database'] = true;
$HmvcConfig['return']["_tables"] = array( 
	'customer_information',
);