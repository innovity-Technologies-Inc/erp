<?php
// module directory name
$HmvcConfig['hrm']["_title"]     = "hrm Details ";
$HmvcConfig['hrm']["_description"] = "Simple hrm processing System";
	  
	  
$HmvcConfig['hrm']['_database'] = true;
$HmvcConfig['hrm']["_tables"] = array( 
	'employee',
);
