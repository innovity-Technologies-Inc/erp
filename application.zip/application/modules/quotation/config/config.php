<?php
// module directory name
$HmvcConfig['quotation']["_title"]     = "quotation Details ";
$HmvcConfig['quotation']["_description"] = "Simple quotation processing System";
$HmvcConfig['quotation']['_database'] = true;
$HmvcConfig['quotation']["_tables"] = array( 
	'product_quotation',
);
