<?php
// module directory name
$HmvcConfig['report']["_title"]     = "report Details ";
$HmvcConfig['report']["_description"] = "Simple report processing System";
	  
$HmvcConfig['report']['_database'] = true;
$HmvcConfig['report']["_tables"] = array( 
	'report',
);
