<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-04 01:25:49 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:25:49 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:25:49 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:25:49 --> Model Class Initialized
ERROR - 2025-04-04 01:25:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 01:25:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 01:25:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-04 01:25:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-04 01:25:49 --> Template MX_Controller Initialized
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-04 01:25:49 --> Model Class Initialized
ERROR - 2025-04-04 01:25:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-04 01:25:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-04 01:25:49 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-04 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-04 01:25:49 --> Final output sent to browser
DEBUG - 2025-04-04 01:25:49 --> Total execution time: 0.1745
INFO - 2025-04-04 01:25:54 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:25:54 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:25:54 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:25:54 --> Model Class Initialized
INFO - 2025-04-04 01:25:54 --> Final output sent to browser
DEBUG - 2025-04-04 01:25:54 --> Total execution time: 0.0146
INFO - 2025-04-04 01:25:55 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:25:55 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:25:55 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:25:55 --> Model Class Initialized
INFO - 2025-04-04 01:25:55 --> Final output sent to browser
DEBUG - 2025-04-04 01:25:55 --> Total execution time: 0.0169
INFO - 2025-04-04 01:25:57 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:25:57 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:25:57 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:25:57 --> Model Class Initialized
INFO - 2025-04-04 01:25:57 --> Final output sent to browser
DEBUG - 2025-04-04 01:25:57 --> Total execution time: 0.0123
INFO - 2025-04-04 01:25:58 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:25:58 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:25:58 --> Model Class Initialized
DEBUG - 2025-04-04 01:25:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:25:58 --> Model Class Initialized
INFO - 2025-04-04 01:25:58 --> Final output sent to browser
DEBUG - 2025-04-04 01:25:58 --> Total execution time: 0.0223
INFO - 2025-04-04 01:26:38 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:26:38 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:26:38 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:26:38 --> Model Class Initialized
INFO - 2025-04-04 01:26:38 --> Final output sent to browser
DEBUG - 2025-04-04 01:26:38 --> Total execution time: 0.0210
INFO - 2025-04-04 01:26:43 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:26:43 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:26:43 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:26:43 --> Model Class Initialized
INFO - 2025-04-04 01:26:43 --> Final output sent to browser
DEBUG - 2025-04-04 01:26:43 --> Total execution time: 0.0064
INFO - 2025-04-04 01:26:49 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:26:49 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:26:49 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:26:49 --> Model Class Initialized
INFO - 2025-04-04 01:26:49 --> Final output sent to browser
DEBUG - 2025-04-04 01:26:49 --> Total execution time: 0.0237
INFO - 2025-04-04 01:26:52 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:26:52 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:26:52 --> Model Class Initialized
DEBUG - 2025-04-04 01:26:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:26:52 --> Model Class Initialized
INFO - 2025-04-04 01:26:52 --> Final output sent to browser
DEBUG - 2025-04-04 01:26:52 --> Total execution time: 0.0149
INFO - 2025-04-04 01:27:11 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:27:11 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:27:11 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:27:11 --> Model Class Initialized
INFO - 2025-04-04 01:27:11 --> Final output sent to browser
DEBUG - 2025-04-04 01:27:11 --> Total execution time: 0.0137
INFO - 2025-04-04 01:27:14 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:27:14 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:27:14 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:27:14 --> Model Class Initialized
ERROR - 2025-04-04 01:27:14 --> Severity: Warning --> Attempt to read property "serial_no" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1179
ERROR - 2025-04-04 01:27:14 --> Severity: Warning --> Attempt to read property "supplier_price" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1203
ERROR - 2025-04-04 01:27:14 --> Severity: Warning --> Attempt to read property "price" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1204
ERROR - 2025-04-04 01:27:14 --> Severity: Warning --> Attempt to read property "supplier_id" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1205
ERROR - 2025-04-04 01:27:14 --> Severity: Warning --> Attempt to read property "unit" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1206
ERROR - 2025-04-04 01:27:14 --> Severity: Warning --> Attempt to read property "tax" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1207
ERROR - 2025-04-04 01:27:14 --> Severity: Warning --> Attempt to read property "product_vat" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1208
INFO - 2025-04-04 01:27:14 --> Final output sent to browser
DEBUG - 2025-04-04 01:27:14 --> Total execution time: 0.0197
INFO - 2025-04-04 01:27:19 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:27:19 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:27:19 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:27:19 --> Model Class Initialized
INFO - 2025-04-04 01:27:19 --> Final output sent to browser
DEBUG - 2025-04-04 01:27:19 --> Total execution time: 0.0153
INFO - 2025-04-04 01:27:20 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:27:20 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:27:20 --> Model Class Initialized
DEBUG - 2025-04-04 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:27:20 --> Model Class Initialized
ERROR - 2025-04-04 01:27:20 --> Severity: Warning --> Attempt to read property "serial_no" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1179
ERROR - 2025-04-04 01:27:20 --> Severity: Warning --> Attempt to read property "supplier_price" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1203
ERROR - 2025-04-04 01:27:20 --> Severity: Warning --> Attempt to read property "price" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1204
ERROR - 2025-04-04 01:27:20 --> Severity: Warning --> Attempt to read property "supplier_id" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1205
ERROR - 2025-04-04 01:27:20 --> Severity: Warning --> Attempt to read property "unit" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1206
ERROR - 2025-04-04 01:27:20 --> Severity: Warning --> Attempt to read property "tax" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1207
ERROR - 2025-04-04 01:27:20 --> Severity: Warning --> Attempt to read property "product_vat" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 1208
INFO - 2025-04-04 01:27:20 --> Final output sent to browser
DEBUG - 2025-04-04 01:27:20 --> Total execution time: 0.0153
INFO - 2025-04-04 01:30:47 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:30:47 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:30:47 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:30:47 --> Model Class Initialized
ERROR - 2025-04-04 01:30:47 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 01:30:47 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 01:30:47 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-04 01:30:47 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-04 01:30:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-04 01:30:47 --> Model Class Initialized
ERROR - 2025-04-04 01:30:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-04 01:30:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-04 01:30:47 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-04 01:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-04 01:30:47 --> Final output sent to browser
DEBUG - 2025-04-04 01:30:47 --> Total execution time: 0.2039
INFO - 2025-04-04 01:30:53 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:30:53 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:30:53 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:30:53 --> Model Class Initialized
INFO - 2025-04-04 01:30:53 --> Final output sent to browser
DEBUG - 2025-04-04 01:30:53 --> Total execution time: 0.0130
INFO - 2025-04-04 01:30:54 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:30:54 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:30:54 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:30:54 --> Model Class Initialized
INFO - 2025-04-04 01:30:54 --> Final output sent to browser
DEBUG - 2025-04-04 01:30:54 --> Total execution time: 0.0120
INFO - 2025-04-04 01:30:58 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:30:58 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:30:58 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:30:58 --> Model Class Initialized
INFO - 2025-04-04 01:30:58 --> Final output sent to browser
DEBUG - 2025-04-04 01:30:58 --> Total execution time: 0.0057
INFO - 2025-04-04 01:30:59 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:30:59 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:30:59 --> Model Class Initialized
DEBUG - 2025-04-04 01:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:30:59 --> Model Class Initialized
INFO - 2025-04-04 01:30:59 --> Final output sent to browser
DEBUG - 2025-04-04 01:30:59 --> Total execution time: 0.0246
INFO - 2025-04-04 01:31:02 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:31:02 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:31:02 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:31:02 --> Model Class Initialized
INFO - 2025-04-04 01:31:02 --> Final output sent to browser
DEBUG - 2025-04-04 01:31:02 --> Total execution time: 0.0133
INFO - 2025-04-04 01:31:19 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:31:19 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:31:19 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:31:19 --> Model Class Initialized
INFO - 2025-04-04 01:31:19 --> Final output sent to browser
DEBUG - 2025-04-04 01:31:19 --> Total execution time: 0.0100
INFO - 2025-04-04 01:31:37 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:31:37 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:31:37 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:31:37 --> Model Class Initialized
INFO - 2025-04-04 01:31:37 --> Final output sent to browser
DEBUG - 2025-04-04 01:31:37 --> Total execution time: 0.0251
INFO - 2025-04-04 01:31:39 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:31:39 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:31:39 --> Model Class Initialized
DEBUG - 2025-04-04 01:31:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:31:39 --> Model Class Initialized
INFO - 2025-04-04 01:31:39 --> Final output sent to browser
DEBUG - 2025-04-04 01:31:39 --> Total execution time: 0.0078
INFO - 2025-04-04 01:32:01 --> Model Class Initialized
DEBUG - 2025-04-04 01:32:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:32:01 --> Model Class Initialized
DEBUG - 2025-04-04 01:32:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:32:01 --> Model Class Initialized
DEBUG - 2025-04-04 01:32:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:32:01 --> Model Class Initialized
INFO - 2025-04-04 01:32:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-04 01:32:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
ERROR - 2025-04-04 01:32:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
DEBUG - 2025-04-04 01:32:01 --> 📥 acc_transaction insert: {"vid":"166","fyear":"1","VNo":"CV-47","Vtype":"CV","referenceNo":"1092","VDate":"2025-04-04","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"2000.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 01:32:01"}
DEBUG - 2025-04-04 01:32:01 --> 📥 acc_transaction insert: {"vid":"166","fyear":"1","VNo":"CV-47","Vtype":"CV","referenceNo":"1092","VDate":"2025-04-04","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"2000.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 01:32:01"}
DEBUG - 2025-04-04 01:32:01 --> 📥 acc_transaction insert: {"vid":"167","fyear":"1","VNo":"JV-69","Vtype":"JV","referenceNo":"1092","VDate":"2025-04-04","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"1350.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 01:32:01"}
DEBUG - 2025-04-04 01:32:01 --> 📥 acc_transaction insert: {"vid":"167","fyear":"1","VNo":"JV-69","Vtype":"JV","referenceNo":"1092","VDate":"2025-04-04","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"1350.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 01:32:01"}
DEBUG - 2025-04-04 01:32:01 --> 📥 acc_transaction insert: {"vid":"168","fyear":"1","VNo":"JV-70","Vtype":"JV","referenceNo":"1092","VDate":"2025-04-04","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 01:32:01"}
DEBUG - 2025-04-04 01:32:01 --> 📥 acc_transaction insert: {"vid":"168","fyear":"1","VNo":"JV-70","Vtype":"JV","referenceNo":"1092","VDate":"2025-04-04","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 01:32:01"}
DEBUG - 2025-04-04 01:32:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-04 01:32:01 --> Final output sent to browser
DEBUG - 2025-04-04 01:32:01 --> Total execution time: 0.1210
INFO - 2025-04-04 01:32:04 --> Model Class Initialized
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 01:32:04 --> Model Class Initialized
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 01:32:04 --> Model Class Initialized
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 01:32:04 --> Model Class Initialized
ERROR - 2025-04-04 01:32:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 01:32:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 01:32:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-04 01:32:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-04 01:32:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-04 01:32:04 --> Model Class Initialized
ERROR - 2025-04-04 01:32:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-04 01:32:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-04 01:32:04 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-04 01:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-04 01:32:04 --> Final output sent to browser
DEBUG - 2025-04-04 01:32:04 --> Total execution time: 0.1584
INFO - 2025-04-04 03:12:02 --> Model Class Initialized
DEBUG - 2025-04-04 03:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:12:02 --> Model Class Initialized
DEBUG - 2025-04-04 03:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:12:02 --> Model Class Initialized
DEBUG - 2025-04-04 03:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:12:02 --> Model Class Initialized
ERROR - 2025-04-04 03:12:02 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 03:12:02 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 03:12:02 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-04 03:12:02 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-04 03:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-04 03:12:02 --> Template MX_Controller Initialized
DEBUG - 2025-04-04 03:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-04 03:12:02 --> Model Class Initialized
ERROR - 2025-04-04 03:12:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-04 03:12:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-04 03:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-04 03:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-04 03:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-04 03:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-04 03:12:03 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-04 03:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-04 03:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-04 03:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-04 03:12:03 --> Final output sent to browser
DEBUG - 2025-04-04 03:12:03 --> Total execution time: 0.7242
INFO - 2025-04-04 03:13:05 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:05 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:05 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:05 --> Model Class Initialized
INFO - 2025-04-04 03:13:05 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:05 --> Total execution time: 0.0165
INFO - 2025-04-04 03:13:06 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:06 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:06 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:06 --> Model Class Initialized
INFO - 2025-04-04 03:13:06 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:06 --> Total execution time: 0.0144
INFO - 2025-04-04 03:13:10 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:10 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:10 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:10 --> Model Class Initialized
INFO - 2025-04-04 03:13:10 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:10 --> Total execution time: 0.0125
INFO - 2025-04-04 03:13:11 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:11 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:11 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:11 --> Model Class Initialized
INFO - 2025-04-04 03:13:11 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:11 --> Total execution time: 0.0193
INFO - 2025-04-04 03:13:16 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:16 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:16 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:16 --> Model Class Initialized
INFO - 2025-04-04 03:13:16 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:16 --> Total execution time: 0.0152
INFO - 2025-04-04 03:13:17 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:17 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:17 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:17 --> Model Class Initialized
INFO - 2025-04-04 03:13:17 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:17 --> Total execution time: 0.0115
INFO - 2025-04-04 03:13:19 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:19 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:19 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:19 --> Model Class Initialized
INFO - 2025-04-04 03:13:19 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:19 --> Total execution time: 0.0120
INFO - 2025-04-04 03:13:29 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:29 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:29 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:29 --> Model Class Initialized
INFO - 2025-04-04 03:13:29 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:29 --> Total execution time: 0.0141
INFO - 2025-04-04 03:13:30 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:30 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:30 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:30 --> Model Class Initialized
INFO - 2025-04-04 03:13:30 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:30 --> Total execution time: 0.0230
INFO - 2025-04-04 03:13:32 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:32 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:32 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:32 --> Model Class Initialized
INFO - 2025-04-04 03:13:32 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:32 --> Total execution time: 0.0128
INFO - 2025-04-04 03:13:46 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:46 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:46 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:46 --> Model Class Initialized
INFO - 2025-04-04 03:13:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-04 03:13:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 519
ERROR - 2025-04-04 03:13:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 519
DEBUG - 2025-04-04 03:13:46 --> 📥 acc_transaction insert: {"vid":"169","fyear":"1","VNo":"CV-48","Vtype":"CV","referenceNo":"1093","VDate":"2025-04-04","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"3000.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 03:13:46"}
DEBUG - 2025-04-04 03:13:46 --> 📥 acc_transaction insert: {"vid":"169","fyear":"1","VNo":"CV-48","Vtype":"CV","referenceNo":"1093","VDate":"2025-04-04","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"3000.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 03:13:46"}
DEBUG - 2025-04-04 03:13:46 --> 📥 acc_transaction insert: {"vid":"170","fyear":"1","VNo":"JV-71","Vtype":"JV","referenceNo":"1093","VDate":"2025-04-04","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"1800.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 03:13:46"}
DEBUG - 2025-04-04 03:13:46 --> 📥 acc_transaction insert: {"vid":"170","fyear":"1","VNo":"JV-71","Vtype":"JV","referenceNo":"1093","VDate":"2025-04-04","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"1800.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 03:13:46"}
DEBUG - 2025-04-04 03:13:46 --> 📥 acc_transaction insert: {"vid":"171","fyear":"1","VNo":"JV-72","Vtype":"JV","referenceNo":"1093","VDate":"2025-04-04","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 03:13:46"}
DEBUG - 2025-04-04 03:13:46 --> 📥 acc_transaction insert: {"vid":"171","fyear":"1","VNo":"JV-72","Vtype":"JV","referenceNo":"1093","VDate":"2025-04-04","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-04 03:13:46"}
DEBUG - 2025-04-04 03:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-04 03:13:46 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:46 --> Total execution time: 0.1192
INFO - 2025-04-04 03:13:51 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 03:13:51 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 03:13:51 --> Model Class Initialized
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 03:13:51 --> Model Class Initialized
ERROR - 2025-04-04 03:13:51 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 03:13:51 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 03:13:51 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-04 03:13:51 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-04 03:13:51 --> Template MX_Controller Initialized
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-04 03:13:51 --> Model Class Initialized
ERROR - 2025-04-04 03:13:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-04 03:13:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-04 03:13:51 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-04 03:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-04 03:13:51 --> Final output sent to browser
DEBUG - 2025-04-04 03:13:51 --> Total execution time: 0.1506
INFO - 2025-04-04 04:44:04 --> Model Class Initialized
DEBUG - 2025-04-04 04:44:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-04 04:44:04 --> Model Class Initialized
DEBUG - 2025-04-04 04:44:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-04 04:44:04 --> Model Class Initialized
DEBUG - 2025-04-04 04:44:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-04 04:44:04 --> Model Class Initialized
ERROR - 2025-04-04 04:44:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 04:44:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-04 04:44:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-04 04:44:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-04 04:44:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-04 04:44:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-04 04:44:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-04 04:44:04 --> Model Class Initialized
ERROR - 2025-04-04 04:44:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-04 04:44:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-04 04:44:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-04 04:44:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-04 04:44:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-04 04:44:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-04 04:44:05 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-04 04:44:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-04 04:44:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-04 04:44:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-04 04:44:05 --> Final output sent to browser
DEBUG - 2025-04-04 04:44:05 --> Total execution time: 0.5604
