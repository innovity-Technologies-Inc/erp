<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-11 17:09:41 --> Config Class Initialized
INFO - 2025-04-11 17:09:41 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:09:41 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:09:41 --> Utf8 Class Initialized
INFO - 2025-04-11 17:09:41 --> URI Class Initialized
DEBUG - 2025-04-11 17:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-11 17:09:41 --> No URI present. Default controller set.
INFO - 2025-04-11 17:09:41 --> Router Class Initialized
INFO - 2025-04-11 17:09:41 --> Output Class Initialized
INFO - 2025-04-11 17:09:41 --> Security Class Initialized
DEBUG - 2025-04-11 17:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:09:41 --> Input Class Initialized
INFO - 2025-04-11 17:09:41 --> Language Class Initialized
INFO - 2025-04-11 17:09:41 --> Language Class Initialized
INFO - 2025-04-11 17:09:41 --> Config Class Initialized
INFO - 2025-04-11 17:09:41 --> Loader Class Initialized
INFO - 2025-04-11 17:09:41 --> Helper loaded: url_helper
INFO - 2025-04-11 17:09:41 --> Helper loaded: file_helper
INFO - 2025-04-11 17:09:41 --> Helper loaded: html_helper
INFO - 2025-04-11 17:09:41 --> Helper loaded: form_helper
INFO - 2025-04-11 17:09:41 --> Helper loaded: text_helper
INFO - 2025-04-11 17:09:41 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:09:41 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:09:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:09:41 --> Database Driver Class Initialized
INFO - 2025-04-11 17:09:41 --> Email Class Initialized
INFO - 2025-04-11 17:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:09:41 --> Form Validation Class Initialized
INFO - 2025-04-11 17:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:09:41 --> Pagination Class Initialized
INFO - 2025-04-11 17:09:41 --> Controller Class Initialized
DEBUG - 2025-04-11 17:09:41 --> Auth MX_Controller Initialized
INFO - 2025-04-11 17:09:41 --> Model Class Initialized
DEBUG - 2025-04-11 17:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-11 17:09:41 --> Model Class Initialized
DEBUG - 2025-04-11 17:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:09:41 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:09:41 --> Model Class Initialized
DEBUG - 2025-04-11 17:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-11 17:09:41 --> Final output sent to browser
DEBUG - 2025-04-11 17:09:41 --> Total execution time: 0.0435
INFO - 2025-04-11 17:15:41 --> Config Class Initialized
INFO - 2025-04-11 17:15:41 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:15:41 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:15:41 --> Utf8 Class Initialized
INFO - 2025-04-11 17:15:41 --> URI Class Initialized
DEBUG - 2025-04-11 17:15:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-11 17:15:41 --> No URI present. Default controller set.
INFO - 2025-04-11 17:15:41 --> Router Class Initialized
INFO - 2025-04-11 17:15:41 --> Output Class Initialized
INFO - 2025-04-11 17:15:41 --> Security Class Initialized
DEBUG - 2025-04-11 17:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:15:41 --> Input Class Initialized
INFO - 2025-04-11 17:15:41 --> Language Class Initialized
INFO - 2025-04-11 17:15:41 --> Language Class Initialized
INFO - 2025-04-11 17:15:41 --> Config Class Initialized
INFO - 2025-04-11 17:15:41 --> Loader Class Initialized
INFO - 2025-04-11 17:15:41 --> Helper loaded: url_helper
INFO - 2025-04-11 17:15:41 --> Helper loaded: file_helper
INFO - 2025-04-11 17:15:41 --> Helper loaded: html_helper
INFO - 2025-04-11 17:15:41 --> Helper loaded: form_helper
INFO - 2025-04-11 17:15:41 --> Helper loaded: text_helper
INFO - 2025-04-11 17:15:41 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:15:41 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:15:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:15:41 --> Database Driver Class Initialized
INFO - 2025-04-11 17:15:41 --> Email Class Initialized
INFO - 2025-04-11 17:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:15:41 --> Form Validation Class Initialized
INFO - 2025-04-11 17:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:15:41 --> Pagination Class Initialized
INFO - 2025-04-11 17:15:41 --> Controller Class Initialized
DEBUG - 2025-04-11 17:15:41 --> Auth MX_Controller Initialized
INFO - 2025-04-11 17:15:41 --> Model Class Initialized
DEBUG - 2025-04-11 17:15:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-11 17:15:41 --> Model Class Initialized
DEBUG - 2025-04-11 17:15:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:15:41 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:15:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:15:41 --> Model Class Initialized
DEBUG - 2025-04-11 17:15:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-11 17:15:41 --> Final output sent to browser
DEBUG - 2025-04-11 17:15:41 --> Total execution time: 0.0197
INFO - 2025-04-11 17:15:49 --> Config Class Initialized
INFO - 2025-04-11 17:15:49 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:15:49 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:15:49 --> Utf8 Class Initialized
INFO - 2025-04-11 17:15:49 --> URI Class Initialized
DEBUG - 2025-04-11 17:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-11 17:15:49 --> Router Class Initialized
INFO - 2025-04-11 17:15:49 --> Output Class Initialized
INFO - 2025-04-11 17:15:49 --> Security Class Initialized
DEBUG - 2025-04-11 17:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:15:49 --> Input Class Initialized
INFO - 2025-04-11 17:15:49 --> Language Class Initialized
INFO - 2025-04-11 17:15:49 --> Language Class Initialized
INFO - 2025-04-11 17:15:49 --> Config Class Initialized
INFO - 2025-04-11 17:15:49 --> Loader Class Initialized
INFO - 2025-04-11 17:15:49 --> Helper loaded: url_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: file_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: html_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: form_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: text_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:15:49 --> Database Driver Class Initialized
INFO - 2025-04-11 17:15:49 --> Email Class Initialized
INFO - 2025-04-11 17:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:15:49 --> Form Validation Class Initialized
INFO - 2025-04-11 17:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:15:49 --> Pagination Class Initialized
INFO - 2025-04-11 17:15:49 --> Controller Class Initialized
DEBUG - 2025-04-11 17:15:49 --> Auth MX_Controller Initialized
INFO - 2025-04-11 17:15:49 --> Model Class Initialized
DEBUG - 2025-04-11 17:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-11 17:15:49 --> Model Class Initialized
INFO - 2025-04-11 17:15:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-11 17:15:49 --> Config Class Initialized
INFO - 2025-04-11 17:15:49 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:15:49 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:15:49 --> Utf8 Class Initialized
INFO - 2025-04-11 17:15:49 --> URI Class Initialized
DEBUG - 2025-04-11 17:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-11 17:15:49 --> Router Class Initialized
INFO - 2025-04-11 17:15:49 --> Output Class Initialized
INFO - 2025-04-11 17:15:49 --> Security Class Initialized
DEBUG - 2025-04-11 17:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:15:49 --> Input Class Initialized
INFO - 2025-04-11 17:15:49 --> Language Class Initialized
INFO - 2025-04-11 17:15:49 --> Language Class Initialized
INFO - 2025-04-11 17:15:49 --> Config Class Initialized
INFO - 2025-04-11 17:15:49 --> Loader Class Initialized
INFO - 2025-04-11 17:15:49 --> Helper loaded: url_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: file_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: html_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: form_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: text_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:15:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:15:49 --> Database Driver Class Initialized
INFO - 2025-04-11 17:15:49 --> Email Class Initialized
INFO - 2025-04-11 17:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:15:49 --> Form Validation Class Initialized
INFO - 2025-04-11 17:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:15:49 --> Pagination Class Initialized
INFO - 2025-04-11 17:15:49 --> Controller Class Initialized
DEBUG - 2025-04-11 17:15:49 --> Home MX_Controller Initialized
INFO - 2025-04-11 17:15:49 --> Model Class Initialized
DEBUG - 2025-04-11 17:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-11 17:15:49 --> Model Class Initialized
DEBUG - 2025-04-11 17:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:15:49 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:15:49 --> Model Class Initialized
ERROR - 2025-04-11 17:15:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 17:15:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 17:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 17:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 17:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 17:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 17:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-11 17:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 17:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 17:15:50 --> Final output sent to browser
DEBUG - 2025-04-11 17:15:50 --> Total execution time: 0.7713
INFO - 2025-04-11 17:16:17 --> Config Class Initialized
INFO - 2025-04-11 17:16:17 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:16:17 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:16:17 --> Utf8 Class Initialized
INFO - 2025-04-11 17:16:17 --> URI Class Initialized
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 17:16:17 --> Router Class Initialized
INFO - 2025-04-11 17:16:17 --> Output Class Initialized
INFO - 2025-04-11 17:16:17 --> Security Class Initialized
DEBUG - 2025-04-11 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:16:17 --> Input Class Initialized
INFO - 2025-04-11 17:16:17 --> Language Class Initialized
INFO - 2025-04-11 17:16:17 --> Language Class Initialized
INFO - 2025-04-11 17:16:17 --> Config Class Initialized
INFO - 2025-04-11 17:16:17 --> Loader Class Initialized
INFO - 2025-04-11 17:16:17 --> Helper loaded: url_helper
INFO - 2025-04-11 17:16:17 --> Helper loaded: file_helper
INFO - 2025-04-11 17:16:17 --> Helper loaded: html_helper
INFO - 2025-04-11 17:16:17 --> Helper loaded: form_helper
INFO - 2025-04-11 17:16:17 --> Helper loaded: text_helper
INFO - 2025-04-11 17:16:17 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:16:17 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:16:17 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:16:17 --> Database Driver Class Initialized
INFO - 2025-04-11 17:16:17 --> Email Class Initialized
INFO - 2025-04-11 17:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:16:17 --> Form Validation Class Initialized
INFO - 2025-04-11 17:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:16:17 --> Pagination Class Initialized
INFO - 2025-04-11 17:16:17 --> Controller Class Initialized
DEBUG - 2025-04-11 17:16:17 --> Returns MX_Controller Initialized
INFO - 2025-04-11 17:16:17 --> Model Class Initialized
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 17:16:17 --> Model Class Initialized
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 17:16:17 --> Model Class Initialized
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:16:17 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:16:17 --> Model Class Initialized
ERROR - 2025-04-11 17:16:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 17:16:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 17:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 17:16:17 --> Final output sent to browser
DEBUG - 2025-04-11 17:16:17 --> Total execution time: 0.1501
INFO - 2025-04-11 17:16:21 --> Config Class Initialized
INFO - 2025-04-11 17:16:21 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:16:21 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:16:21 --> Utf8 Class Initialized
INFO - 2025-04-11 17:16:21 --> URI Class Initialized
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 17:16:21 --> Router Class Initialized
INFO - 2025-04-11 17:16:21 --> Output Class Initialized
INFO - 2025-04-11 17:16:21 --> Security Class Initialized
DEBUG - 2025-04-11 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:16:21 --> Input Class Initialized
INFO - 2025-04-11 17:16:21 --> Language Class Initialized
INFO - 2025-04-11 17:16:21 --> Language Class Initialized
INFO - 2025-04-11 17:16:21 --> Config Class Initialized
INFO - 2025-04-11 17:16:21 --> Loader Class Initialized
INFO - 2025-04-11 17:16:21 --> Helper loaded: url_helper
INFO - 2025-04-11 17:16:21 --> Helper loaded: file_helper
INFO - 2025-04-11 17:16:21 --> Helper loaded: html_helper
INFO - 2025-04-11 17:16:21 --> Helper loaded: form_helper
INFO - 2025-04-11 17:16:21 --> Helper loaded: text_helper
INFO - 2025-04-11 17:16:21 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:16:21 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:16:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:16:21 --> Database Driver Class Initialized
INFO - 2025-04-11 17:16:21 --> Email Class Initialized
INFO - 2025-04-11 17:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:16:21 --> Form Validation Class Initialized
INFO - 2025-04-11 17:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:16:21 --> Pagination Class Initialized
INFO - 2025-04-11 17:16:21 --> Controller Class Initialized
DEBUG - 2025-04-11 17:16:21 --> Returns MX_Controller Initialized
INFO - 2025-04-11 17:16:21 --> Model Class Initialized
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 17:16:21 --> Model Class Initialized
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 17:16:21 --> Model Class Initialized
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:16:21 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:16:21 --> Model Class Initialized
ERROR - 2025-04-11 17:16:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 17:16:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 17:16:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 17:16:21 --> Final output sent to browser
DEBUG - 2025-04-11 17:16:21 --> Total execution time: 0.1922
INFO - 2025-04-11 17:17:52 --> Config Class Initialized
INFO - 2025-04-11 17:17:52 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:17:52 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:17:52 --> Utf8 Class Initialized
INFO - 2025-04-11 17:17:52 --> URI Class Initialized
DEBUG - 2025-04-11 17:17:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 17:17:52 --> Router Class Initialized
INFO - 2025-04-11 17:17:52 --> Output Class Initialized
INFO - 2025-04-11 17:17:52 --> Security Class Initialized
DEBUG - 2025-04-11 17:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:17:52 --> Input Class Initialized
INFO - 2025-04-11 17:17:52 --> Language Class Initialized
INFO - 2025-04-11 17:17:52 --> Language Class Initialized
INFO - 2025-04-11 17:17:52 --> Config Class Initialized
INFO - 2025-04-11 17:17:52 --> Loader Class Initialized
INFO - 2025-04-11 17:17:52 --> Helper loaded: url_helper
INFO - 2025-04-11 17:17:52 --> Helper loaded: file_helper
INFO - 2025-04-11 17:17:52 --> Helper loaded: html_helper
INFO - 2025-04-11 17:17:52 --> Helper loaded: form_helper
INFO - 2025-04-11 17:17:52 --> Helper loaded: text_helper
INFO - 2025-04-11 17:17:52 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:17:52 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:17:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:17:52 --> Database Driver Class Initialized
INFO - 2025-04-11 17:17:52 --> Email Class Initialized
INFO - 2025-04-11 17:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:17:52 --> Form Validation Class Initialized
INFO - 2025-04-11 17:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:17:52 --> Pagination Class Initialized
INFO - 2025-04-11 17:17:52 --> Controller Class Initialized
DEBUG - 2025-04-11 17:17:52 --> Returns MX_Controller Initialized
INFO - 2025-04-11 17:17:52 --> Model Class Initialized
DEBUG - 2025-04-11 17:17:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 17:17:52 --> Model Class Initialized
DEBUG - 2025-04-11 17:17:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 17:17:52 --> Model Class Initialized
DEBUG - 2025-04-11 17:17:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:17:52 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:17:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:17:52 --> Model Class Initialized
ERROR - 2025-04-11 17:17:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 17:17:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 17:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 17:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 17:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 17:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 17:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/return_supllier_list.php
DEBUG - 2025-04-11 17:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 17:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 17:17:53 --> Final output sent to browser
DEBUG - 2025-04-11 17:17:53 --> Total execution time: 0.1575
INFO - 2025-04-11 17:17:56 --> Config Class Initialized
INFO - 2025-04-11 17:17:56 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:17:56 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:17:56 --> Utf8 Class Initialized
INFO - 2025-04-11 17:17:56 --> URI Class Initialized
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 17:17:56 --> Router Class Initialized
INFO - 2025-04-11 17:17:56 --> Output Class Initialized
INFO - 2025-04-11 17:17:56 --> Security Class Initialized
DEBUG - 2025-04-11 17:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:17:56 --> Input Class Initialized
INFO - 2025-04-11 17:17:56 --> Language Class Initialized
INFO - 2025-04-11 17:17:56 --> Language Class Initialized
INFO - 2025-04-11 17:17:56 --> Config Class Initialized
INFO - 2025-04-11 17:17:56 --> Loader Class Initialized
INFO - 2025-04-11 17:17:56 --> Helper loaded: url_helper
INFO - 2025-04-11 17:17:56 --> Helper loaded: file_helper
INFO - 2025-04-11 17:17:56 --> Helper loaded: html_helper
INFO - 2025-04-11 17:17:56 --> Helper loaded: form_helper
INFO - 2025-04-11 17:17:56 --> Helper loaded: text_helper
INFO - 2025-04-11 17:17:56 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:17:56 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:17:56 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:17:56 --> Database Driver Class Initialized
INFO - 2025-04-11 17:17:56 --> Email Class Initialized
INFO - 2025-04-11 17:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:17:56 --> Form Validation Class Initialized
INFO - 2025-04-11 17:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:17:56 --> Pagination Class Initialized
INFO - 2025-04-11 17:17:56 --> Controller Class Initialized
DEBUG - 2025-04-11 17:17:56 --> Returns MX_Controller Initialized
INFO - 2025-04-11 17:17:56 --> Model Class Initialized
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 17:17:56 --> Model Class Initialized
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 17:17:56 --> Model Class Initialized
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:17:56 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:17:56 --> Model Class Initialized
ERROR - 2025-04-11 17:17:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 17:17:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/return_supllier_list.php
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 17:17:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 17:17:56 --> Final output sent to browser
DEBUG - 2025-04-11 17:17:56 --> Total execution time: 0.1588
INFO - 2025-04-11 17:18:01 --> Config Class Initialized
INFO - 2025-04-11 17:18:01 --> Hooks Class Initialized
DEBUG - 2025-04-11 17:18:01 --> UTF-8 Support Enabled
INFO - 2025-04-11 17:18:01 --> Utf8 Class Initialized
INFO - 2025-04-11 17:18:01 --> URI Class Initialized
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 17:18:01 --> Router Class Initialized
INFO - 2025-04-11 17:18:01 --> Output Class Initialized
INFO - 2025-04-11 17:18:01 --> Security Class Initialized
DEBUG - 2025-04-11 17:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 17:18:01 --> Input Class Initialized
INFO - 2025-04-11 17:18:01 --> Language Class Initialized
INFO - 2025-04-11 17:18:01 --> Language Class Initialized
INFO - 2025-04-11 17:18:01 --> Config Class Initialized
INFO - 2025-04-11 17:18:01 --> Loader Class Initialized
INFO - 2025-04-11 17:18:01 --> Helper loaded: url_helper
INFO - 2025-04-11 17:18:01 --> Helper loaded: file_helper
INFO - 2025-04-11 17:18:01 --> Helper loaded: html_helper
INFO - 2025-04-11 17:18:01 --> Helper loaded: form_helper
INFO - 2025-04-11 17:18:01 --> Helper loaded: text_helper
INFO - 2025-04-11 17:18:01 --> Helper loaded: lang_helper
INFO - 2025-04-11 17:18:01 --> Helper loaded: directory_helper
INFO - 2025-04-11 17:18:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 17:18:01 --> Database Driver Class Initialized
INFO - 2025-04-11 17:18:01 --> Email Class Initialized
INFO - 2025-04-11 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 17:18:01 --> Form Validation Class Initialized
INFO - 2025-04-11 17:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 17:18:01 --> Pagination Class Initialized
INFO - 2025-04-11 17:18:01 --> Controller Class Initialized
DEBUG - 2025-04-11 17:18:01 --> Returns MX_Controller Initialized
INFO - 2025-04-11 17:18:01 --> Model Class Initialized
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 17:18:01 --> Model Class Initialized
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 17:18:01 --> Model Class Initialized
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 17:18:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 17:18:01 --> Model Class Initialized
ERROR - 2025-04-11 17:18:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 17:18:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 17:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 17:18:01 --> Final output sent to browser
DEBUG - 2025-04-11 17:18:01 --> Total execution time: 0.2099
INFO - 2025-04-11 18:25:38 --> Config Class Initialized
INFO - 2025-04-11 18:25:38 --> Hooks Class Initialized
DEBUG - 2025-04-11 18:25:38 --> UTF-8 Support Enabled
INFO - 2025-04-11 18:25:38 --> Utf8 Class Initialized
INFO - 2025-04-11 18:25:38 --> URI Class Initialized
DEBUG - 2025-04-11 18:25:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-11 18:25:38 --> Router Class Initialized
INFO - 2025-04-11 18:25:38 --> Output Class Initialized
INFO - 2025-04-11 18:25:38 --> Security Class Initialized
DEBUG - 2025-04-11 18:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 18:25:38 --> Input Class Initialized
INFO - 2025-04-11 18:25:38 --> Language Class Initialized
INFO - 2025-04-11 18:25:38 --> Language Class Initialized
INFO - 2025-04-11 18:25:38 --> Config Class Initialized
INFO - 2025-04-11 18:25:38 --> Loader Class Initialized
INFO - 2025-04-11 18:25:38 --> Helper loaded: url_helper
INFO - 2025-04-11 18:25:38 --> Helper loaded: file_helper
INFO - 2025-04-11 18:25:38 --> Helper loaded: html_helper
INFO - 2025-04-11 18:25:38 --> Helper loaded: form_helper
INFO - 2025-04-11 18:25:38 --> Helper loaded: text_helper
INFO - 2025-04-11 18:25:38 --> Helper loaded: lang_helper
INFO - 2025-04-11 18:25:38 --> Helper loaded: directory_helper
INFO - 2025-04-11 18:25:38 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 18:25:38 --> Database Driver Class Initialized
INFO - 2025-04-11 18:25:38 --> Email Class Initialized
INFO - 2025-04-11 18:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 18:25:38 --> Form Validation Class Initialized
INFO - 2025-04-11 18:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 18:25:38 --> Pagination Class Initialized
INFO - 2025-04-11 18:25:38 --> Controller Class Initialized
DEBUG - 2025-04-11 18:25:38 --> Report MX_Controller Initialized
INFO - 2025-04-11 18:25:38 --> Model Class Initialized
DEBUG - 2025-04-11 18:25:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-11 18:25:38 --> Model Class Initialized
DEBUG - 2025-04-11 18:25:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 18:25:38 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 18:25:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 18:25:38 --> Model Class Initialized
ERROR - 2025-04-11 18:25:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 18:25:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 18:25:39 --> Final output sent to browser
DEBUG - 2025-04-11 18:25:39 --> Total execution time: 0.3751
INFO - 2025-04-11 18:25:39 --> Config Class Initialized
INFO - 2025-04-11 18:25:39 --> Hooks Class Initialized
DEBUG - 2025-04-11 18:25:39 --> UTF-8 Support Enabled
INFO - 2025-04-11 18:25:39 --> Utf8 Class Initialized
INFO - 2025-04-11 18:25:39 --> URI Class Initialized
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-11 18:25:39 --> Router Class Initialized
INFO - 2025-04-11 18:25:39 --> Output Class Initialized
INFO - 2025-04-11 18:25:39 --> Security Class Initialized
DEBUG - 2025-04-11 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 18:25:39 --> Input Class Initialized
INFO - 2025-04-11 18:25:39 --> Language Class Initialized
INFO - 2025-04-11 18:25:39 --> Language Class Initialized
INFO - 2025-04-11 18:25:39 --> Config Class Initialized
INFO - 2025-04-11 18:25:39 --> Loader Class Initialized
INFO - 2025-04-11 18:25:39 --> Helper loaded: url_helper
INFO - 2025-04-11 18:25:39 --> Helper loaded: file_helper
INFO - 2025-04-11 18:25:39 --> Helper loaded: html_helper
INFO - 2025-04-11 18:25:39 --> Helper loaded: form_helper
INFO - 2025-04-11 18:25:39 --> Helper loaded: text_helper
INFO - 2025-04-11 18:25:39 --> Helper loaded: lang_helper
INFO - 2025-04-11 18:25:39 --> Helper loaded: directory_helper
INFO - 2025-04-11 18:25:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 18:25:39 --> Database Driver Class Initialized
INFO - 2025-04-11 18:25:39 --> Email Class Initialized
INFO - 2025-04-11 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 18:25:39 --> Form Validation Class Initialized
INFO - 2025-04-11 18:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 18:25:39 --> Pagination Class Initialized
INFO - 2025-04-11 18:25:39 --> Controller Class Initialized
DEBUG - 2025-04-11 18:25:39 --> Report MX_Controller Initialized
INFO - 2025-04-11 18:25:39 --> Model Class Initialized
DEBUG - 2025-04-11 18:25:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-11 18:25:39 --> Model Class Initialized
INFO - 2025-04-11 18:25:39 --> Final output sent to browser
DEBUG - 2025-04-11 18:25:39 --> Total execution time: 0.0111
INFO - 2025-04-11 18:26:07 --> Config Class Initialized
INFO - 2025-04-11 18:26:07 --> Hooks Class Initialized
DEBUG - 2025-04-11 18:26:07 --> UTF-8 Support Enabled
INFO - 2025-04-11 18:26:07 --> Utf8 Class Initialized
INFO - 2025-04-11 18:26:07 --> URI Class Initialized
DEBUG - 2025-04-11 18:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 18:26:07 --> Router Class Initialized
INFO - 2025-04-11 18:26:07 --> Output Class Initialized
INFO - 2025-04-11 18:26:07 --> Security Class Initialized
DEBUG - 2025-04-11 18:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 18:26:07 --> Input Class Initialized
INFO - 2025-04-11 18:26:07 --> Language Class Initialized
INFO - 2025-04-11 18:26:07 --> Language Class Initialized
INFO - 2025-04-11 18:26:07 --> Config Class Initialized
INFO - 2025-04-11 18:26:07 --> Loader Class Initialized
INFO - 2025-04-11 18:26:07 --> Helper loaded: url_helper
INFO - 2025-04-11 18:26:07 --> Helper loaded: file_helper
INFO - 2025-04-11 18:26:07 --> Helper loaded: html_helper
INFO - 2025-04-11 18:26:07 --> Helper loaded: form_helper
INFO - 2025-04-11 18:26:07 --> Helper loaded: text_helper
INFO - 2025-04-11 18:26:07 --> Helper loaded: lang_helper
INFO - 2025-04-11 18:26:07 --> Helper loaded: directory_helper
INFO - 2025-04-11 18:26:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 18:26:07 --> Database Driver Class Initialized
INFO - 2025-04-11 18:26:07 --> Email Class Initialized
INFO - 2025-04-11 18:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 18:26:07 --> Form Validation Class Initialized
INFO - 2025-04-11 18:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 18:26:07 --> Pagination Class Initialized
INFO - 2025-04-11 18:26:07 --> Controller Class Initialized
DEBUG - 2025-04-11 18:26:07 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 18:26:08 --> Config Class Initialized
INFO - 2025-04-11 18:26:08 --> Hooks Class Initialized
DEBUG - 2025-04-11 18:26:08 --> UTF-8 Support Enabled
INFO - 2025-04-11 18:26:08 --> Utf8 Class Initialized
INFO - 2025-04-11 18:26:08 --> URI Class Initialized
DEBUG - 2025-04-11 18:26:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 18:26:08 --> Router Class Initialized
INFO - 2025-04-11 18:26:08 --> Output Class Initialized
INFO - 2025-04-11 18:26:08 --> Security Class Initialized
DEBUG - 2025-04-11 18:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 18:26:08 --> Input Class Initialized
INFO - 2025-04-11 18:26:08 --> Language Class Initialized
INFO - 2025-04-11 18:26:08 --> Language Class Initialized
INFO - 2025-04-11 18:26:08 --> Config Class Initialized
INFO - 2025-04-11 18:26:08 --> Loader Class Initialized
INFO - 2025-04-11 18:26:08 --> Helper loaded: url_helper
INFO - 2025-04-11 18:26:08 --> Helper loaded: file_helper
INFO - 2025-04-11 18:26:08 --> Helper loaded: html_helper
INFO - 2025-04-11 18:26:08 --> Helper loaded: form_helper
INFO - 2025-04-11 18:26:08 --> Helper loaded: text_helper
INFO - 2025-04-11 18:26:08 --> Helper loaded: lang_helper
INFO - 2025-04-11 18:26:08 --> Helper loaded: directory_helper
INFO - 2025-04-11 18:26:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 18:26:08 --> Database Driver Class Initialized
INFO - 2025-04-11 18:26:08 --> Email Class Initialized
INFO - 2025-04-11 18:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 18:26:08 --> Form Validation Class Initialized
INFO - 2025-04-11 18:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 18:26:08 --> Pagination Class Initialized
INFO - 2025-04-11 18:26:08 --> Controller Class Initialized
DEBUG - 2025-04-11 18:26:08 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 18:26:13 --> Config Class Initialized
INFO - 2025-04-11 18:26:13 --> Hooks Class Initialized
DEBUG - 2025-04-11 18:26:13 --> UTF-8 Support Enabled
INFO - 2025-04-11 18:26:13 --> Utf8 Class Initialized
INFO - 2025-04-11 18:26:13 --> URI Class Initialized
DEBUG - 2025-04-11 18:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 18:26:13 --> Router Class Initialized
INFO - 2025-04-11 18:26:13 --> Output Class Initialized
INFO - 2025-04-11 18:26:13 --> Security Class Initialized
DEBUG - 2025-04-11 18:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 18:26:13 --> Input Class Initialized
INFO - 2025-04-11 18:26:13 --> Language Class Initialized
INFO - 2025-04-11 18:26:13 --> Language Class Initialized
INFO - 2025-04-11 18:26:13 --> Config Class Initialized
INFO - 2025-04-11 18:26:13 --> Loader Class Initialized
INFO - 2025-04-11 18:26:13 --> Helper loaded: url_helper
INFO - 2025-04-11 18:26:13 --> Helper loaded: file_helper
INFO - 2025-04-11 18:26:13 --> Helper loaded: html_helper
INFO - 2025-04-11 18:26:13 --> Helper loaded: form_helper
INFO - 2025-04-11 18:26:13 --> Helper loaded: text_helper
INFO - 2025-04-11 18:26:13 --> Helper loaded: lang_helper
INFO - 2025-04-11 18:26:13 --> Helper loaded: directory_helper
INFO - 2025-04-11 18:26:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 18:26:13 --> Database Driver Class Initialized
INFO - 2025-04-11 18:26:13 --> Email Class Initialized
INFO - 2025-04-11 18:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 18:26:13 --> Form Validation Class Initialized
INFO - 2025-04-11 18:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 18:26:13 --> Pagination Class Initialized
INFO - 2025-04-11 18:26:13 --> Controller Class Initialized
DEBUG - 2025-04-11 18:26:13 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 18:28:07 --> Config Class Initialized
INFO - 2025-04-11 18:28:07 --> Hooks Class Initialized
DEBUG - 2025-04-11 18:28:07 --> UTF-8 Support Enabled
INFO - 2025-04-11 18:28:07 --> Utf8 Class Initialized
INFO - 2025-04-11 18:28:07 --> URI Class Initialized
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 18:28:07 --> Router Class Initialized
INFO - 2025-04-11 18:28:07 --> Output Class Initialized
INFO - 2025-04-11 18:28:07 --> Security Class Initialized
DEBUG - 2025-04-11 18:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 18:28:07 --> Input Class Initialized
INFO - 2025-04-11 18:28:07 --> Language Class Initialized
INFO - 2025-04-11 18:28:07 --> Language Class Initialized
INFO - 2025-04-11 18:28:07 --> Config Class Initialized
INFO - 2025-04-11 18:28:07 --> Loader Class Initialized
INFO - 2025-04-11 18:28:07 --> Helper loaded: url_helper
INFO - 2025-04-11 18:28:07 --> Helper loaded: file_helper
INFO - 2025-04-11 18:28:07 --> Helper loaded: html_helper
INFO - 2025-04-11 18:28:07 --> Helper loaded: form_helper
INFO - 2025-04-11 18:28:07 --> Helper loaded: text_helper
INFO - 2025-04-11 18:28:07 --> Helper loaded: lang_helper
INFO - 2025-04-11 18:28:07 --> Helper loaded: directory_helper
INFO - 2025-04-11 18:28:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 18:28:07 --> Database Driver Class Initialized
INFO - 2025-04-11 18:28:07 --> Email Class Initialized
INFO - 2025-04-11 18:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 18:28:07 --> Form Validation Class Initialized
INFO - 2025-04-11 18:28:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 18:28:07 --> Pagination Class Initialized
INFO - 2025-04-11 18:28:07 --> Controller Class Initialized
DEBUG - 2025-04-11 18:28:07 --> Returns MX_Controller Initialized
INFO - 2025-04-11 18:28:07 --> Model Class Initialized
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 18:28:07 --> Model Class Initialized
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 18:28:07 --> Model Class Initialized
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 18:28:07 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 18:28:07 --> Model Class Initialized
ERROR - 2025-04-11 18:28:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 18:28:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 18:28:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 18:28:07 --> Final output sent to browser
DEBUG - 2025-04-11 18:28:07 --> Total execution time: 0.1326
INFO - 2025-04-11 19:09:12 --> Config Class Initialized
INFO - 2025-04-11 19:09:12 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:09:12 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:09:12 --> Utf8 Class Initialized
INFO - 2025-04-11 19:09:12 --> URI Class Initialized
DEBUG - 2025-04-11 19:09:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-11 19:09:12 --> Router Class Initialized
INFO - 2025-04-11 19:09:12 --> Output Class Initialized
INFO - 2025-04-11 19:09:12 --> Security Class Initialized
DEBUG - 2025-04-11 19:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:09:12 --> Input Class Initialized
INFO - 2025-04-11 19:09:12 --> Language Class Initialized
INFO - 2025-04-11 19:09:12 --> Language Class Initialized
INFO - 2025-04-11 19:09:12 --> Config Class Initialized
INFO - 2025-04-11 19:09:12 --> Loader Class Initialized
INFO - 2025-04-11 19:09:12 --> Helper loaded: url_helper
INFO - 2025-04-11 19:09:12 --> Helper loaded: file_helper
INFO - 2025-04-11 19:09:12 --> Helper loaded: html_helper
INFO - 2025-04-11 19:09:12 --> Helper loaded: form_helper
INFO - 2025-04-11 19:09:12 --> Helper loaded: text_helper
INFO - 2025-04-11 19:09:12 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:09:12 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:09:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:09:12 --> Database Driver Class Initialized
INFO - 2025-04-11 19:09:12 --> Email Class Initialized
INFO - 2025-04-11 19:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:09:12 --> Form Validation Class Initialized
INFO - 2025-04-11 19:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:09:12 --> Pagination Class Initialized
INFO - 2025-04-11 19:09:12 --> Controller Class Initialized
DEBUG - 2025-04-11 19:09:12 --> Customer MX_Controller Initialized
INFO - 2025-04-11 19:09:12 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-11 19:09:12 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:09:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:09:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:09:12 --> Model Class Initialized
ERROR - 2025-04-11 19:09:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:09:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:09:13 --> Final output sent to browser
DEBUG - 2025-04-11 19:09:13 --> Total execution time: 0.8026
INFO - 2025-04-11 19:09:13 --> Config Class Initialized
INFO - 2025-04-11 19:09:13 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:09:13 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:09:13 --> Utf8 Class Initialized
INFO - 2025-04-11 19:09:13 --> URI Class Initialized
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-11 19:09:13 --> Router Class Initialized
INFO - 2025-04-11 19:09:13 --> Output Class Initialized
INFO - 2025-04-11 19:09:13 --> Security Class Initialized
DEBUG - 2025-04-11 19:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:09:13 --> Input Class Initialized
INFO - 2025-04-11 19:09:13 --> Language Class Initialized
INFO - 2025-04-11 19:09:13 --> Language Class Initialized
INFO - 2025-04-11 19:09:13 --> Config Class Initialized
INFO - 2025-04-11 19:09:13 --> Loader Class Initialized
INFO - 2025-04-11 19:09:13 --> Helper loaded: url_helper
INFO - 2025-04-11 19:09:13 --> Helper loaded: file_helper
INFO - 2025-04-11 19:09:13 --> Helper loaded: html_helper
INFO - 2025-04-11 19:09:13 --> Helper loaded: form_helper
INFO - 2025-04-11 19:09:13 --> Helper loaded: text_helper
INFO - 2025-04-11 19:09:13 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:09:13 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:09:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:09:13 --> Database Driver Class Initialized
INFO - 2025-04-11 19:09:13 --> Email Class Initialized
INFO - 2025-04-11 19:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:09:13 --> Form Validation Class Initialized
INFO - 2025-04-11 19:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:09:13 --> Pagination Class Initialized
INFO - 2025-04-11 19:09:13 --> Controller Class Initialized
DEBUG - 2025-04-11 19:09:13 --> Customer MX_Controller Initialized
INFO - 2025-04-11 19:09:13 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-11 19:09:13 --> Model Class Initialized
ERROR - 2025-04-11 19:09:13 --> ========= getCustomerList() START =========
ERROR - 2025-04-11 19:09:13 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-11 19:09:13 --> Received customer_id: null
ERROR - 2025-04-11 19:09:13 --> Received customfiled: null
ERROR - 2025-04-11 19:09:13 --> Pagination info: start=0, length=50
ERROR - 2025-04-11 19:09:13 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-11 19:09:13 --> Search value: 
ERROR - 2025-04-11 19:09:13 --> Total unfiltered records: 15
ERROR - 2025-04-11 19:09:13 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-11 19:09:13 --> Records fetched from DB: 15
ERROR - 2025-04-11 19:09:13 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-11 19:09:13 --> ========= getCustomerList() END =========
INFO - 2025-04-11 19:09:20 --> Config Class Initialized
INFO - 2025-04-11 19:09:20 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:09:20 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:09:20 --> Utf8 Class Initialized
INFO - 2025-04-11 19:09:20 --> URI Class Initialized
DEBUG - 2025-04-11 19:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 19:09:20 --> Router Class Initialized
INFO - 2025-04-11 19:09:20 --> Output Class Initialized
INFO - 2025-04-11 19:09:20 --> Security Class Initialized
DEBUG - 2025-04-11 19:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:09:20 --> Input Class Initialized
INFO - 2025-04-11 19:09:20 --> Language Class Initialized
INFO - 2025-04-11 19:09:20 --> Language Class Initialized
INFO - 2025-04-11 19:09:20 --> Config Class Initialized
INFO - 2025-04-11 19:09:20 --> Loader Class Initialized
INFO - 2025-04-11 19:09:20 --> Helper loaded: url_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: file_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: html_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: form_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: text_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:09:20 --> Database Driver Class Initialized
INFO - 2025-04-11 19:09:20 --> Email Class Initialized
INFO - 2025-04-11 19:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:09:20 --> Form Validation Class Initialized
INFO - 2025-04-11 19:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:09:20 --> Pagination Class Initialized
INFO - 2025-04-11 19:09:20 --> Controller Class Initialized
DEBUG - 2025-04-11 19:09:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 19:09:20 --> Config Class Initialized
INFO - 2025-04-11 19:09:20 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:09:20 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:09:20 --> Utf8 Class Initialized
INFO - 2025-04-11 19:09:20 --> URI Class Initialized
DEBUG - 2025-04-11 19:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 19:09:20 --> Router Class Initialized
INFO - 2025-04-11 19:09:20 --> Output Class Initialized
INFO - 2025-04-11 19:09:20 --> Security Class Initialized
DEBUG - 2025-04-11 19:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:09:20 --> Input Class Initialized
INFO - 2025-04-11 19:09:20 --> Language Class Initialized
INFO - 2025-04-11 19:09:20 --> Language Class Initialized
INFO - 2025-04-11 19:09:20 --> Config Class Initialized
INFO - 2025-04-11 19:09:20 --> Loader Class Initialized
INFO - 2025-04-11 19:09:20 --> Helper loaded: url_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: file_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: html_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: form_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: text_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:09:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:09:20 --> Database Driver Class Initialized
INFO - 2025-04-11 19:09:20 --> Email Class Initialized
INFO - 2025-04-11 19:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:09:20 --> Form Validation Class Initialized
INFO - 2025-04-11 19:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:09:20 --> Pagination Class Initialized
INFO - 2025-04-11 19:09:20 --> Controller Class Initialized
DEBUG - 2025-04-11 19:09:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 19:09:31 --> Config Class Initialized
INFO - 2025-04-11 19:09:31 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:09:31 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:09:31 --> Utf8 Class Initialized
INFO - 2025-04-11 19:09:31 --> URI Class Initialized
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-11 19:09:31 --> Router Class Initialized
INFO - 2025-04-11 19:09:31 --> Output Class Initialized
INFO - 2025-04-11 19:09:31 --> Security Class Initialized
DEBUG - 2025-04-11 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:09:31 --> Input Class Initialized
INFO - 2025-04-11 19:09:31 --> Language Class Initialized
INFO - 2025-04-11 19:09:31 --> Language Class Initialized
INFO - 2025-04-11 19:09:31 --> Config Class Initialized
INFO - 2025-04-11 19:09:31 --> Loader Class Initialized
INFO - 2025-04-11 19:09:31 --> Helper loaded: url_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: file_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: html_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: form_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: text_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:09:31 --> Database Driver Class Initialized
INFO - 2025-04-11 19:09:31 --> Email Class Initialized
INFO - 2025-04-11 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:09:31 --> Form Validation Class Initialized
INFO - 2025-04-11 19:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:09:31 --> Pagination Class Initialized
INFO - 2025-04-11 19:09:31 --> Controller Class Initialized
DEBUG - 2025-04-11 19:09:31 --> Report MX_Controller Initialized
INFO - 2025-04-11 19:09:31 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-11 19:09:31 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:09:31 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:09:31 --> Model Class Initialized
ERROR - 2025-04-11 19:09:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:09:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:09:31 --> Final output sent to browser
DEBUG - 2025-04-11 19:09:31 --> Total execution time: 0.1308
INFO - 2025-04-11 19:09:31 --> Config Class Initialized
INFO - 2025-04-11 19:09:31 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:09:31 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:09:31 --> Utf8 Class Initialized
INFO - 2025-04-11 19:09:31 --> URI Class Initialized
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-11 19:09:31 --> Router Class Initialized
INFO - 2025-04-11 19:09:31 --> Output Class Initialized
INFO - 2025-04-11 19:09:31 --> Security Class Initialized
DEBUG - 2025-04-11 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:09:31 --> Input Class Initialized
INFO - 2025-04-11 19:09:31 --> Language Class Initialized
INFO - 2025-04-11 19:09:31 --> Language Class Initialized
INFO - 2025-04-11 19:09:31 --> Config Class Initialized
INFO - 2025-04-11 19:09:31 --> Loader Class Initialized
INFO - 2025-04-11 19:09:31 --> Helper loaded: url_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: file_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: html_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: form_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: text_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:09:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:09:31 --> Database Driver Class Initialized
INFO - 2025-04-11 19:09:31 --> Email Class Initialized
INFO - 2025-04-11 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:09:31 --> Form Validation Class Initialized
INFO - 2025-04-11 19:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:09:31 --> Pagination Class Initialized
INFO - 2025-04-11 19:09:31 --> Controller Class Initialized
DEBUG - 2025-04-11 19:09:31 --> Report MX_Controller Initialized
INFO - 2025-04-11 19:09:31 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-11 19:09:31 --> Model Class Initialized
INFO - 2025-04-11 19:09:31 --> Final output sent to browser
DEBUG - 2025-04-11 19:09:31 --> Total execution time: 0.0086
INFO - 2025-04-11 19:09:55 --> Config Class Initialized
INFO - 2025-04-11 19:09:55 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:09:55 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:09:55 --> Utf8 Class Initialized
INFO - 2025-04-11 19:09:55 --> URI Class Initialized
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:09:55 --> Router Class Initialized
INFO - 2025-04-11 19:09:55 --> Output Class Initialized
INFO - 2025-04-11 19:09:55 --> Security Class Initialized
DEBUG - 2025-04-11 19:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:09:55 --> Input Class Initialized
INFO - 2025-04-11 19:09:55 --> Language Class Initialized
INFO - 2025-04-11 19:09:55 --> Language Class Initialized
INFO - 2025-04-11 19:09:55 --> Config Class Initialized
INFO - 2025-04-11 19:09:55 --> Loader Class Initialized
INFO - 2025-04-11 19:09:55 --> Helper loaded: url_helper
INFO - 2025-04-11 19:09:55 --> Helper loaded: file_helper
INFO - 2025-04-11 19:09:55 --> Helper loaded: html_helper
INFO - 2025-04-11 19:09:55 --> Helper loaded: form_helper
INFO - 2025-04-11 19:09:55 --> Helper loaded: text_helper
INFO - 2025-04-11 19:09:55 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:09:55 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:09:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:09:55 --> Database Driver Class Initialized
INFO - 2025-04-11 19:09:55 --> Email Class Initialized
INFO - 2025-04-11 19:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:09:55 --> Form Validation Class Initialized
INFO - 2025-04-11 19:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:09:55 --> Pagination Class Initialized
INFO - 2025-04-11 19:09:55 --> Controller Class Initialized
DEBUG - 2025-04-11 19:09:55 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:09:55 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:09:55 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:09:55 --> Model Class Initialized
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:09:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:09:55 --> Model Class Initialized
ERROR - 2025-04-11 19:09:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:09:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:09:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:09:55 --> Final output sent to browser
DEBUG - 2025-04-11 19:09:55 --> Total execution time: 0.2130
INFO - 2025-04-11 19:10:12 --> Config Class Initialized
INFO - 2025-04-11 19:10:12 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:10:12 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:10:12 --> Utf8 Class Initialized
INFO - 2025-04-11 19:10:12 --> URI Class Initialized
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:10:12 --> Router Class Initialized
INFO - 2025-04-11 19:10:12 --> Output Class Initialized
INFO - 2025-04-11 19:10:12 --> Security Class Initialized
DEBUG - 2025-04-11 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:10:12 --> Input Class Initialized
INFO - 2025-04-11 19:10:12 --> Language Class Initialized
INFO - 2025-04-11 19:10:12 --> Language Class Initialized
INFO - 2025-04-11 19:10:12 --> Config Class Initialized
INFO - 2025-04-11 19:10:12 --> Loader Class Initialized
INFO - 2025-04-11 19:10:12 --> Helper loaded: url_helper
INFO - 2025-04-11 19:10:12 --> Helper loaded: file_helper
INFO - 2025-04-11 19:10:12 --> Helper loaded: html_helper
INFO - 2025-04-11 19:10:12 --> Helper loaded: form_helper
INFO - 2025-04-11 19:10:12 --> Helper loaded: text_helper
INFO - 2025-04-11 19:10:12 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:10:12 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:10:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:10:12 --> Database Driver Class Initialized
INFO - 2025-04-11 19:10:12 --> Email Class Initialized
INFO - 2025-04-11 19:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:10:12 --> Form Validation Class Initialized
INFO - 2025-04-11 19:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:10:12 --> Pagination Class Initialized
INFO - 2025-04-11 19:10:12 --> Controller Class Initialized
DEBUG - 2025-04-11 19:10:12 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:10:12 --> Model Class Initialized
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:10:12 --> Model Class Initialized
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:10:12 --> Model Class Initialized
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:10:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:10:12 --> Model Class Initialized
ERROR - 2025-04-11 19:10:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:10:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:10:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:10:12 --> Final output sent to browser
DEBUG - 2025-04-11 19:10:12 --> Total execution time: 0.1632
INFO - 2025-04-11 19:11:57 --> Config Class Initialized
INFO - 2025-04-11 19:11:57 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:11:57 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:11:57 --> Utf8 Class Initialized
INFO - 2025-04-11 19:11:57 --> URI Class Initialized
DEBUG - 2025-04-11 19:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 19:11:57 --> Router Class Initialized
INFO - 2025-04-11 19:11:57 --> Output Class Initialized
INFO - 2025-04-11 19:11:57 --> Security Class Initialized
DEBUG - 2025-04-11 19:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:11:57 --> Input Class Initialized
INFO - 2025-04-11 19:11:57 --> Language Class Initialized
INFO - 2025-04-11 19:11:57 --> Language Class Initialized
INFO - 2025-04-11 19:11:57 --> Config Class Initialized
INFO - 2025-04-11 19:11:57 --> Loader Class Initialized
INFO - 2025-04-11 19:11:57 --> Helper loaded: url_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: file_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: html_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: form_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: text_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:11:57 --> Database Driver Class Initialized
INFO - 2025-04-11 19:11:57 --> Email Class Initialized
INFO - 2025-04-11 19:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:11:57 --> Form Validation Class Initialized
INFO - 2025-04-11 19:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:11:57 --> Pagination Class Initialized
INFO - 2025-04-11 19:11:57 --> Controller Class Initialized
DEBUG - 2025-04-11 19:11:57 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 19:11:57 --> Config Class Initialized
INFO - 2025-04-11 19:11:57 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:11:57 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:11:57 --> Utf8 Class Initialized
INFO - 2025-04-11 19:11:57 --> URI Class Initialized
DEBUG - 2025-04-11 19:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 19:11:57 --> Router Class Initialized
INFO - 2025-04-11 19:11:57 --> Output Class Initialized
INFO - 2025-04-11 19:11:57 --> Security Class Initialized
DEBUG - 2025-04-11 19:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:11:57 --> Input Class Initialized
INFO - 2025-04-11 19:11:57 --> Language Class Initialized
INFO - 2025-04-11 19:11:57 --> Language Class Initialized
INFO - 2025-04-11 19:11:57 --> Config Class Initialized
INFO - 2025-04-11 19:11:57 --> Loader Class Initialized
INFO - 2025-04-11 19:11:57 --> Helper loaded: url_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: file_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: html_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: form_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: text_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:11:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:11:57 --> Database Driver Class Initialized
INFO - 2025-04-11 19:11:57 --> Email Class Initialized
INFO - 2025-04-11 19:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:11:57 --> Form Validation Class Initialized
INFO - 2025-04-11 19:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:11:57 --> Pagination Class Initialized
INFO - 2025-04-11 19:11:57 --> Controller Class Initialized
DEBUG - 2025-04-11 19:11:57 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 19:11:58 --> Config Class Initialized
INFO - 2025-04-11 19:11:58 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:11:58 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:11:58 --> Utf8 Class Initialized
INFO - 2025-04-11 19:11:58 --> URI Class Initialized
DEBUG - 2025-04-11 19:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 19:11:58 --> Router Class Initialized
INFO - 2025-04-11 19:11:58 --> Output Class Initialized
INFO - 2025-04-11 19:11:58 --> Security Class Initialized
DEBUG - 2025-04-11 19:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:11:58 --> Input Class Initialized
INFO - 2025-04-11 19:11:58 --> Language Class Initialized
INFO - 2025-04-11 19:11:58 --> Language Class Initialized
INFO - 2025-04-11 19:11:58 --> Config Class Initialized
INFO - 2025-04-11 19:11:58 --> Loader Class Initialized
INFO - 2025-04-11 19:11:58 --> Helper loaded: url_helper
INFO - 2025-04-11 19:11:58 --> Helper loaded: file_helper
INFO - 2025-04-11 19:11:58 --> Helper loaded: html_helper
INFO - 2025-04-11 19:11:58 --> Helper loaded: form_helper
INFO - 2025-04-11 19:11:58 --> Helper loaded: text_helper
INFO - 2025-04-11 19:11:58 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:11:58 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:11:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:11:58 --> Database Driver Class Initialized
INFO - 2025-04-11 19:11:58 --> Email Class Initialized
INFO - 2025-04-11 19:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:11:58 --> Form Validation Class Initialized
INFO - 2025-04-11 19:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:11:58 --> Pagination Class Initialized
INFO - 2025-04-11 19:11:58 --> Controller Class Initialized
DEBUG - 2025-04-11 19:11:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 19:11:59 --> Config Class Initialized
INFO - 2025-04-11 19:11:59 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:11:59 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:11:59 --> Utf8 Class Initialized
INFO - 2025-04-11 19:11:59 --> URI Class Initialized
DEBUG - 2025-04-11 19:11:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 19:11:59 --> Router Class Initialized
INFO - 2025-04-11 19:11:59 --> Output Class Initialized
INFO - 2025-04-11 19:11:59 --> Security Class Initialized
DEBUG - 2025-04-11 19:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:11:59 --> Input Class Initialized
INFO - 2025-04-11 19:11:59 --> Language Class Initialized
INFO - 2025-04-11 19:11:59 --> Language Class Initialized
INFO - 2025-04-11 19:11:59 --> Config Class Initialized
INFO - 2025-04-11 19:11:59 --> Loader Class Initialized
INFO - 2025-04-11 19:11:59 --> Helper loaded: url_helper
INFO - 2025-04-11 19:11:59 --> Helper loaded: file_helper
INFO - 2025-04-11 19:11:59 --> Helper loaded: html_helper
INFO - 2025-04-11 19:11:59 --> Helper loaded: form_helper
INFO - 2025-04-11 19:11:59 --> Helper loaded: text_helper
INFO - 2025-04-11 19:11:59 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:11:59 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:11:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:11:59 --> Database Driver Class Initialized
INFO - 2025-04-11 19:11:59 --> Email Class Initialized
INFO - 2025-04-11 19:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:11:59 --> Form Validation Class Initialized
INFO - 2025-04-11 19:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:11:59 --> Pagination Class Initialized
INFO - 2025-04-11 19:11:59 --> Controller Class Initialized
DEBUG - 2025-04-11 19:11:59 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 19:12:58 --> Config Class Initialized
INFO - 2025-04-11 19:12:58 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:12:58 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:12:58 --> Utf8 Class Initialized
INFO - 2025-04-11 19:12:58 --> URI Class Initialized
DEBUG - 2025-04-11 19:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 19:12:58 --> Router Class Initialized
INFO - 2025-04-11 19:12:58 --> Output Class Initialized
INFO - 2025-04-11 19:12:58 --> Security Class Initialized
DEBUG - 2025-04-11 19:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:12:58 --> Input Class Initialized
INFO - 2025-04-11 19:12:58 --> Language Class Initialized
INFO - 2025-04-11 19:12:58 --> Language Class Initialized
INFO - 2025-04-11 19:12:58 --> Config Class Initialized
INFO - 2025-04-11 19:12:58 --> Loader Class Initialized
INFO - 2025-04-11 19:12:58 --> Helper loaded: url_helper
INFO - 2025-04-11 19:12:58 --> Helper loaded: file_helper
INFO - 2025-04-11 19:12:58 --> Helper loaded: html_helper
INFO - 2025-04-11 19:12:58 --> Helper loaded: form_helper
INFO - 2025-04-11 19:12:58 --> Helper loaded: text_helper
INFO - 2025-04-11 19:12:58 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:12:58 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:12:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:12:58 --> Database Driver Class Initialized
INFO - 2025-04-11 19:12:58 --> Email Class Initialized
INFO - 2025-04-11 19:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:12:58 --> Form Validation Class Initialized
INFO - 2025-04-11 19:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:12:58 --> Pagination Class Initialized
INFO - 2025-04-11 19:12:58 --> Controller Class Initialized
DEBUG - 2025-04-11 19:12:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 19:22:05 --> Config Class Initialized
INFO - 2025-04-11 19:22:05 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:22:05 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:22:05 --> Utf8 Class Initialized
INFO - 2025-04-11 19:22:05 --> URI Class Initialized
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:22:05 --> Router Class Initialized
INFO - 2025-04-11 19:22:05 --> Output Class Initialized
INFO - 2025-04-11 19:22:05 --> Security Class Initialized
DEBUG - 2025-04-11 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:22:05 --> Input Class Initialized
INFO - 2025-04-11 19:22:05 --> Language Class Initialized
INFO - 2025-04-11 19:22:05 --> Language Class Initialized
INFO - 2025-04-11 19:22:05 --> Config Class Initialized
INFO - 2025-04-11 19:22:05 --> Loader Class Initialized
INFO - 2025-04-11 19:22:05 --> Helper loaded: url_helper
INFO - 2025-04-11 19:22:05 --> Helper loaded: file_helper
INFO - 2025-04-11 19:22:05 --> Helper loaded: html_helper
INFO - 2025-04-11 19:22:05 --> Helper loaded: form_helper
INFO - 2025-04-11 19:22:05 --> Helper loaded: text_helper
INFO - 2025-04-11 19:22:05 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:22:05 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:22:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:22:05 --> Database Driver Class Initialized
INFO - 2025-04-11 19:22:05 --> Email Class Initialized
INFO - 2025-04-11 19:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:22:05 --> Form Validation Class Initialized
INFO - 2025-04-11 19:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:22:05 --> Pagination Class Initialized
INFO - 2025-04-11 19:22:05 --> Controller Class Initialized
DEBUG - 2025-04-11 19:22:05 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:22:05 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:22:05 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:22:05 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:22:05 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:22:05 --> Model Class Initialized
ERROR - 2025-04-11 19:22:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:22:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:22:05 --> Final output sent to browser
DEBUG - 2025-04-11 19:22:05 --> Total execution time: 0.1416
INFO - 2025-04-11 19:22:21 --> Config Class Initialized
INFO - 2025-04-11 19:22:21 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:22:21 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:22:21 --> Utf8 Class Initialized
INFO - 2025-04-11 19:22:21 --> URI Class Initialized
DEBUG - 2025-04-11 19:22:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:22:21 --> Router Class Initialized
INFO - 2025-04-11 19:22:21 --> Output Class Initialized
INFO - 2025-04-11 19:22:21 --> Security Class Initialized
DEBUG - 2025-04-11 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:22:21 --> Input Class Initialized
INFO - 2025-04-11 19:22:21 --> Language Class Initialized
INFO - 2025-04-11 19:22:21 --> Language Class Initialized
INFO - 2025-04-11 19:22:21 --> Config Class Initialized
INFO - 2025-04-11 19:22:21 --> Loader Class Initialized
INFO - 2025-04-11 19:22:21 --> Helper loaded: url_helper
INFO - 2025-04-11 19:22:21 --> Helper loaded: file_helper
INFO - 2025-04-11 19:22:21 --> Helper loaded: html_helper
INFO - 2025-04-11 19:22:21 --> Helper loaded: form_helper
INFO - 2025-04-11 19:22:21 --> Helper loaded: text_helper
INFO - 2025-04-11 19:22:21 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:22:21 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:22:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:22:21 --> Database Driver Class Initialized
INFO - 2025-04-11 19:22:21 --> Email Class Initialized
INFO - 2025-04-11 19:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:22:21 --> Form Validation Class Initialized
INFO - 2025-04-11 19:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:22:21 --> Pagination Class Initialized
INFO - 2025-04-11 19:22:21 --> Controller Class Initialized
DEBUG - 2025-04-11 19:22:21 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:22:21 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:22:21 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:22:21 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:22:21 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:22:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:22:21 --> Model Class Initialized
ERROR - 2025-04-11 19:22:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:22:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:22:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:22:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:22:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:22:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:22:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 19:22:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:22:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:22:22 --> Final output sent to browser
DEBUG - 2025-04-11 19:22:22 --> Total execution time: 0.0967
INFO - 2025-04-11 19:22:27 --> Config Class Initialized
INFO - 2025-04-11 19:22:27 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:22:27 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:22:27 --> Utf8 Class Initialized
INFO - 2025-04-11 19:22:27 --> URI Class Initialized
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:22:27 --> Router Class Initialized
INFO - 2025-04-11 19:22:27 --> Output Class Initialized
INFO - 2025-04-11 19:22:27 --> Security Class Initialized
DEBUG - 2025-04-11 19:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:22:27 --> Input Class Initialized
INFO - 2025-04-11 19:22:27 --> Language Class Initialized
INFO - 2025-04-11 19:22:27 --> Language Class Initialized
INFO - 2025-04-11 19:22:27 --> Config Class Initialized
INFO - 2025-04-11 19:22:27 --> Loader Class Initialized
INFO - 2025-04-11 19:22:27 --> Helper loaded: url_helper
INFO - 2025-04-11 19:22:27 --> Helper loaded: file_helper
INFO - 2025-04-11 19:22:27 --> Helper loaded: html_helper
INFO - 2025-04-11 19:22:27 --> Helper loaded: form_helper
INFO - 2025-04-11 19:22:27 --> Helper loaded: text_helper
INFO - 2025-04-11 19:22:27 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:22:27 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:22:27 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:22:27 --> Database Driver Class Initialized
INFO - 2025-04-11 19:22:27 --> Email Class Initialized
INFO - 2025-04-11 19:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:22:27 --> Form Validation Class Initialized
INFO - 2025-04-11 19:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:22:27 --> Pagination Class Initialized
INFO - 2025-04-11 19:22:27 --> Controller Class Initialized
DEBUG - 2025-04-11 19:22:27 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:22:27 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:22:27 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:22:27 --> Model Class Initialized
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:22:27 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:22:27 --> Model Class Initialized
ERROR - 2025-04-11 19:22:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:22:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:22:27 --> Final output sent to browser
DEBUG - 2025-04-11 19:22:27 --> Total execution time: 0.1705
INFO - 2025-04-11 19:26:01 --> Config Class Initialized
INFO - 2025-04-11 19:26:01 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:26:01 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:26:01 --> Utf8 Class Initialized
INFO - 2025-04-11 19:26:01 --> URI Class Initialized
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:26:01 --> Router Class Initialized
INFO - 2025-04-11 19:26:01 --> Output Class Initialized
INFO - 2025-04-11 19:26:01 --> Security Class Initialized
DEBUG - 2025-04-11 19:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:26:01 --> Input Class Initialized
INFO - 2025-04-11 19:26:01 --> Language Class Initialized
INFO - 2025-04-11 19:26:01 --> Language Class Initialized
INFO - 2025-04-11 19:26:01 --> Config Class Initialized
INFO - 2025-04-11 19:26:01 --> Loader Class Initialized
INFO - 2025-04-11 19:26:01 --> Helper loaded: url_helper
INFO - 2025-04-11 19:26:01 --> Helper loaded: file_helper
INFO - 2025-04-11 19:26:01 --> Helper loaded: html_helper
INFO - 2025-04-11 19:26:01 --> Helper loaded: form_helper
INFO - 2025-04-11 19:26:01 --> Helper loaded: text_helper
INFO - 2025-04-11 19:26:01 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:26:01 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:26:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:26:01 --> Database Driver Class Initialized
INFO - 2025-04-11 19:26:01 --> Email Class Initialized
INFO - 2025-04-11 19:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:26:01 --> Form Validation Class Initialized
INFO - 2025-04-11 19:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:26:01 --> Pagination Class Initialized
INFO - 2025-04-11 19:26:01 --> Controller Class Initialized
DEBUG - 2025-04-11 19:26:01 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:26:01 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:26:01 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:26:01 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:26:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:26:01 --> Model Class Initialized
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:26:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:26:01 --> Final output sent to browser
DEBUG - 2025-04-11 19:26:01 --> Total execution time: 0.2495
INFO - 2025-04-11 19:26:47 --> Config Class Initialized
INFO - 2025-04-11 19:26:47 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:26:47 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:26:47 --> Utf8 Class Initialized
INFO - 2025-04-11 19:26:47 --> URI Class Initialized
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:26:47 --> Router Class Initialized
INFO - 2025-04-11 19:26:47 --> Output Class Initialized
INFO - 2025-04-11 19:26:47 --> Security Class Initialized
DEBUG - 2025-04-11 19:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:26:47 --> Input Class Initialized
INFO - 2025-04-11 19:26:47 --> Language Class Initialized
INFO - 2025-04-11 19:26:47 --> Language Class Initialized
INFO - 2025-04-11 19:26:47 --> Config Class Initialized
INFO - 2025-04-11 19:26:47 --> Loader Class Initialized
INFO - 2025-04-11 19:26:47 --> Helper loaded: url_helper
INFO - 2025-04-11 19:26:47 --> Helper loaded: file_helper
INFO - 2025-04-11 19:26:47 --> Helper loaded: html_helper
INFO - 2025-04-11 19:26:47 --> Helper loaded: form_helper
INFO - 2025-04-11 19:26:47 --> Helper loaded: text_helper
INFO - 2025-04-11 19:26:47 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:26:47 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:26:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:26:47 --> Database Driver Class Initialized
INFO - 2025-04-11 19:26:47 --> Email Class Initialized
INFO - 2025-04-11 19:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:26:47 --> Form Validation Class Initialized
INFO - 2025-04-11 19:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:26:47 --> Pagination Class Initialized
INFO - 2025-04-11 19:26:47 --> Controller Class Initialized
DEBUG - 2025-04-11 19:26:47 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:26:47 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:26:47 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:26:47 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:26:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:26:47 --> Model Class Initialized
ERROR - 2025-04-11 19:26:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:26:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:26:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:26:47 --> Final output sent to browser
DEBUG - 2025-04-11 19:26:47 --> Total execution time: 0.1700
INFO - 2025-04-11 19:26:50 --> Config Class Initialized
INFO - 2025-04-11 19:26:50 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:26:50 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:26:50 --> Utf8 Class Initialized
INFO - 2025-04-11 19:26:50 --> URI Class Initialized
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:26:50 --> Router Class Initialized
INFO - 2025-04-11 19:26:50 --> Output Class Initialized
INFO - 2025-04-11 19:26:50 --> Security Class Initialized
DEBUG - 2025-04-11 19:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:26:50 --> Input Class Initialized
INFO - 2025-04-11 19:26:50 --> Language Class Initialized
INFO - 2025-04-11 19:26:50 --> Language Class Initialized
INFO - 2025-04-11 19:26:50 --> Config Class Initialized
INFO - 2025-04-11 19:26:50 --> Loader Class Initialized
INFO - 2025-04-11 19:26:50 --> Helper loaded: url_helper
INFO - 2025-04-11 19:26:50 --> Helper loaded: file_helper
INFO - 2025-04-11 19:26:50 --> Helper loaded: html_helper
INFO - 2025-04-11 19:26:50 --> Helper loaded: form_helper
INFO - 2025-04-11 19:26:50 --> Helper loaded: text_helper
INFO - 2025-04-11 19:26:50 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:26:50 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:26:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:26:50 --> Database Driver Class Initialized
INFO - 2025-04-11 19:26:50 --> Email Class Initialized
INFO - 2025-04-11 19:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:26:50 --> Form Validation Class Initialized
INFO - 2025-04-11 19:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:26:50 --> Pagination Class Initialized
INFO - 2025-04-11 19:26:50 --> Controller Class Initialized
DEBUG - 2025-04-11 19:26:50 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:26:50 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:26:50 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:26:50 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:26:50 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:26:50 --> Model Class Initialized
ERROR - 2025-04-11 19:26:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:26:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:26:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:26:50 --> Final output sent to browser
DEBUG - 2025-04-11 19:26:50 --> Total execution time: 0.1670
INFO - 2025-04-11 19:26:53 --> Config Class Initialized
INFO - 2025-04-11 19:26:53 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:26:53 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:26:53 --> Utf8 Class Initialized
INFO - 2025-04-11 19:26:53 --> URI Class Initialized
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:26:53 --> Router Class Initialized
INFO - 2025-04-11 19:26:53 --> Output Class Initialized
INFO - 2025-04-11 19:26:53 --> Security Class Initialized
DEBUG - 2025-04-11 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:26:53 --> Input Class Initialized
INFO - 2025-04-11 19:26:53 --> Language Class Initialized
INFO - 2025-04-11 19:26:53 --> Language Class Initialized
INFO - 2025-04-11 19:26:53 --> Config Class Initialized
INFO - 2025-04-11 19:26:53 --> Loader Class Initialized
INFO - 2025-04-11 19:26:53 --> Helper loaded: url_helper
INFO - 2025-04-11 19:26:53 --> Helper loaded: file_helper
INFO - 2025-04-11 19:26:53 --> Helper loaded: html_helper
INFO - 2025-04-11 19:26:53 --> Helper loaded: form_helper
INFO - 2025-04-11 19:26:53 --> Helper loaded: text_helper
INFO - 2025-04-11 19:26:53 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:26:53 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:26:53 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:26:53 --> Database Driver Class Initialized
INFO - 2025-04-11 19:26:53 --> Email Class Initialized
INFO - 2025-04-11 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:26:53 --> Form Validation Class Initialized
INFO - 2025-04-11 19:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:26:53 --> Pagination Class Initialized
INFO - 2025-04-11 19:26:53 --> Controller Class Initialized
DEBUG - 2025-04-11 19:26:53 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:26:53 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:26:53 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:26:53 --> Model Class Initialized
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:26:53 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:26:53 --> Model Class Initialized
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:26:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:26:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:26:53 --> Final output sent to browser
DEBUG - 2025-04-11 19:26:53 --> Total execution time: 0.1864
INFO - 2025-04-11 19:28:24 --> Config Class Initialized
INFO - 2025-04-11 19:28:24 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:28:24 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:28:24 --> Utf8 Class Initialized
INFO - 2025-04-11 19:28:24 --> URI Class Initialized
DEBUG - 2025-04-11 19:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:28:24 --> Router Class Initialized
INFO - 2025-04-11 19:28:24 --> Output Class Initialized
INFO - 2025-04-11 19:28:24 --> Security Class Initialized
DEBUG - 2025-04-11 19:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:28:24 --> Input Class Initialized
INFO - 2025-04-11 19:28:24 --> Language Class Initialized
INFO - 2025-04-11 19:28:24 --> Language Class Initialized
INFO - 2025-04-11 19:28:24 --> Config Class Initialized
INFO - 2025-04-11 19:28:24 --> Loader Class Initialized
INFO - 2025-04-11 19:28:24 --> Helper loaded: url_helper
INFO - 2025-04-11 19:28:24 --> Helper loaded: file_helper
INFO - 2025-04-11 19:28:24 --> Helper loaded: html_helper
INFO - 2025-04-11 19:28:24 --> Helper loaded: form_helper
INFO - 2025-04-11 19:28:24 --> Helper loaded: text_helper
INFO - 2025-04-11 19:28:24 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:28:24 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:28:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:28:24 --> Database Driver Class Initialized
INFO - 2025-04-11 19:28:25 --> Email Class Initialized
INFO - 2025-04-11 19:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:28:25 --> Form Validation Class Initialized
INFO - 2025-04-11 19:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:28:25 --> Pagination Class Initialized
INFO - 2025-04-11 19:28:25 --> Controller Class Initialized
DEBUG - 2025-04-11 19:28:25 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:28:25 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:28:25 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:28:25 --> Model Class Initialized
INFO - 2025-04-11 19:28:25 --> Config Class Initialized
INFO - 2025-04-11 19:28:25 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:28:25 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:28:25 --> Utf8 Class Initialized
INFO - 2025-04-11 19:28:25 --> URI Class Initialized
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:28:25 --> Router Class Initialized
INFO - 2025-04-11 19:28:25 --> Output Class Initialized
INFO - 2025-04-11 19:28:25 --> Security Class Initialized
DEBUG - 2025-04-11 19:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:28:25 --> Input Class Initialized
INFO - 2025-04-11 19:28:25 --> Language Class Initialized
INFO - 2025-04-11 19:28:25 --> Language Class Initialized
INFO - 2025-04-11 19:28:25 --> Config Class Initialized
INFO - 2025-04-11 19:28:25 --> Loader Class Initialized
INFO - 2025-04-11 19:28:25 --> Helper loaded: url_helper
INFO - 2025-04-11 19:28:25 --> Helper loaded: file_helper
INFO - 2025-04-11 19:28:25 --> Helper loaded: html_helper
INFO - 2025-04-11 19:28:25 --> Helper loaded: form_helper
INFO - 2025-04-11 19:28:25 --> Helper loaded: text_helper
INFO - 2025-04-11 19:28:25 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:28:25 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:28:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:28:25 --> Database Driver Class Initialized
INFO - 2025-04-11 19:28:25 --> Email Class Initialized
INFO - 2025-04-11 19:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:28:25 --> Form Validation Class Initialized
INFO - 2025-04-11 19:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:28:25 --> Pagination Class Initialized
INFO - 2025-04-11 19:28:25 --> Controller Class Initialized
DEBUG - 2025-04-11 19:28:25 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:28:25 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:28:25 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:28:25 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:28:25 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:28:25 --> Model Class Initialized
ERROR - 2025-04-11 19:28:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:28:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:28:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:28:25 --> Final output sent to browser
DEBUG - 2025-04-11 19:28:25 --> Total execution time: 0.1710
INFO - 2025-04-11 19:28:30 --> Config Class Initialized
INFO - 2025-04-11 19:28:30 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:28:30 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:28:30 --> Utf8 Class Initialized
INFO - 2025-04-11 19:28:30 --> URI Class Initialized
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:28:30 --> Router Class Initialized
INFO - 2025-04-11 19:28:30 --> Output Class Initialized
INFO - 2025-04-11 19:28:30 --> Security Class Initialized
DEBUG - 2025-04-11 19:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:28:30 --> Input Class Initialized
INFO - 2025-04-11 19:28:30 --> Language Class Initialized
INFO - 2025-04-11 19:28:30 --> Language Class Initialized
INFO - 2025-04-11 19:28:30 --> Config Class Initialized
INFO - 2025-04-11 19:28:30 --> Loader Class Initialized
INFO - 2025-04-11 19:28:30 --> Helper loaded: url_helper
INFO - 2025-04-11 19:28:30 --> Helper loaded: file_helper
INFO - 2025-04-11 19:28:30 --> Helper loaded: html_helper
INFO - 2025-04-11 19:28:30 --> Helper loaded: form_helper
INFO - 2025-04-11 19:28:30 --> Helper loaded: text_helper
INFO - 2025-04-11 19:28:30 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:28:30 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:28:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:28:30 --> Database Driver Class Initialized
INFO - 2025-04-11 19:28:30 --> Email Class Initialized
INFO - 2025-04-11 19:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:28:30 --> Form Validation Class Initialized
INFO - 2025-04-11 19:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:28:30 --> Pagination Class Initialized
INFO - 2025-04-11 19:28:30 --> Controller Class Initialized
DEBUG - 2025-04-11 19:28:30 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:28:30 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:28:30 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:28:30 --> Model Class Initialized
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:28:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:28:30 --> Model Class Initialized
ERROR - 2025-04-11 19:28:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:28:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:28:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:28:30 --> Final output sent to browser
DEBUG - 2025-04-11 19:28:30 --> Total execution time: 0.2128
INFO - 2025-04-11 19:30:49 --> Config Class Initialized
INFO - 2025-04-11 19:30:49 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:30:49 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:30:49 --> Utf8 Class Initialized
INFO - 2025-04-11 19:30:49 --> URI Class Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:30:49 --> Router Class Initialized
INFO - 2025-04-11 19:30:49 --> Output Class Initialized
INFO - 2025-04-11 19:30:49 --> Security Class Initialized
DEBUG - 2025-04-11 19:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:30:49 --> Input Class Initialized
INFO - 2025-04-11 19:30:49 --> Language Class Initialized
INFO - 2025-04-11 19:30:49 --> Language Class Initialized
INFO - 2025-04-11 19:30:49 --> Config Class Initialized
INFO - 2025-04-11 19:30:49 --> Loader Class Initialized
INFO - 2025-04-11 19:30:49 --> Helper loaded: url_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: file_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: html_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: form_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: text_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:30:49 --> Database Driver Class Initialized
INFO - 2025-04-11 19:30:49 --> Email Class Initialized
INFO - 2025-04-11 19:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:30:49 --> Form Validation Class Initialized
INFO - 2025-04-11 19:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:30:49 --> Pagination Class Initialized
INFO - 2025-04-11 19:30:49 --> Controller Class Initialized
DEBUG - 2025-04-11 19:30:49 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:30:49 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:30:49 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:30:49 --> Model Class Initialized
INFO - 2025-04-11 19:30:49 --> Config Class Initialized
INFO - 2025-04-11 19:30:49 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:30:49 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:30:49 --> Utf8 Class Initialized
INFO - 2025-04-11 19:30:49 --> URI Class Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:30:49 --> Router Class Initialized
INFO - 2025-04-11 19:30:49 --> Output Class Initialized
INFO - 2025-04-11 19:30:49 --> Security Class Initialized
DEBUG - 2025-04-11 19:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:30:49 --> Input Class Initialized
INFO - 2025-04-11 19:30:49 --> Language Class Initialized
INFO - 2025-04-11 19:30:49 --> Language Class Initialized
INFO - 2025-04-11 19:30:49 --> Config Class Initialized
INFO - 2025-04-11 19:30:49 --> Loader Class Initialized
INFO - 2025-04-11 19:30:49 --> Helper loaded: url_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: file_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: html_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: form_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: text_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:30:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:30:49 --> Database Driver Class Initialized
INFO - 2025-04-11 19:30:49 --> Email Class Initialized
INFO - 2025-04-11 19:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:30:49 --> Form Validation Class Initialized
INFO - 2025-04-11 19:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:30:49 --> Pagination Class Initialized
INFO - 2025-04-11 19:30:49 --> Controller Class Initialized
DEBUG - 2025-04-11 19:30:49 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:30:49 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:30:49 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:30:49 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:30:49 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:30:49 --> Model Class Initialized
ERROR - 2025-04-11 19:30:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:30:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:30:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:30:49 --> Final output sent to browser
DEBUG - 2025-04-11 19:30:49 --> Total execution time: 0.1099
INFO - 2025-04-11 19:30:52 --> Config Class Initialized
INFO - 2025-04-11 19:30:52 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:30:52 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:30:52 --> Utf8 Class Initialized
INFO - 2025-04-11 19:30:52 --> URI Class Initialized
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:30:52 --> Router Class Initialized
INFO - 2025-04-11 19:30:52 --> Output Class Initialized
INFO - 2025-04-11 19:30:52 --> Security Class Initialized
DEBUG - 2025-04-11 19:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:30:52 --> Input Class Initialized
INFO - 2025-04-11 19:30:52 --> Language Class Initialized
INFO - 2025-04-11 19:30:52 --> Language Class Initialized
INFO - 2025-04-11 19:30:52 --> Config Class Initialized
INFO - 2025-04-11 19:30:52 --> Loader Class Initialized
INFO - 2025-04-11 19:30:52 --> Helper loaded: url_helper
INFO - 2025-04-11 19:30:52 --> Helper loaded: file_helper
INFO - 2025-04-11 19:30:52 --> Helper loaded: html_helper
INFO - 2025-04-11 19:30:52 --> Helper loaded: form_helper
INFO - 2025-04-11 19:30:52 --> Helper loaded: text_helper
INFO - 2025-04-11 19:30:52 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:30:52 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:30:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:30:52 --> Database Driver Class Initialized
INFO - 2025-04-11 19:30:52 --> Email Class Initialized
INFO - 2025-04-11 19:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:30:52 --> Form Validation Class Initialized
INFO - 2025-04-11 19:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:30:52 --> Pagination Class Initialized
INFO - 2025-04-11 19:30:52 --> Controller Class Initialized
DEBUG - 2025-04-11 19:30:52 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:30:52 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:30:52 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:30:52 --> Model Class Initialized
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:30:52 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:30:52 --> Model Class Initialized
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> Undefined variable $details /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
ERROR - 2025-04-11 19:30:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php 50
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:30:52 --> Final output sent to browser
DEBUG - 2025-04-11 19:30:52 --> Total execution time: 0.1452
INFO - 2025-04-11 19:35:23 --> Config Class Initialized
INFO - 2025-04-11 19:35:23 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:35:23 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:35:23 --> Utf8 Class Initialized
INFO - 2025-04-11 19:35:23 --> URI Class Initialized
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:35:23 --> Router Class Initialized
INFO - 2025-04-11 19:35:23 --> Output Class Initialized
INFO - 2025-04-11 19:35:23 --> Security Class Initialized
DEBUG - 2025-04-11 19:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:35:23 --> Input Class Initialized
INFO - 2025-04-11 19:35:23 --> Language Class Initialized
INFO - 2025-04-11 19:35:23 --> Language Class Initialized
INFO - 2025-04-11 19:35:23 --> Config Class Initialized
INFO - 2025-04-11 19:35:23 --> Loader Class Initialized
INFO - 2025-04-11 19:35:23 --> Helper loaded: url_helper
INFO - 2025-04-11 19:35:23 --> Helper loaded: file_helper
INFO - 2025-04-11 19:35:23 --> Helper loaded: html_helper
INFO - 2025-04-11 19:35:23 --> Helper loaded: form_helper
INFO - 2025-04-11 19:35:23 --> Helper loaded: text_helper
INFO - 2025-04-11 19:35:23 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:35:23 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:35:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:35:23 --> Database Driver Class Initialized
INFO - 2025-04-11 19:35:23 --> Email Class Initialized
INFO - 2025-04-11 19:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:35:23 --> Form Validation Class Initialized
INFO - 2025-04-11 19:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:35:23 --> Pagination Class Initialized
INFO - 2025-04-11 19:35:23 --> Controller Class Initialized
DEBUG - 2025-04-11 19:35:23 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:35:23 --> Model Class Initialized
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:35:23 --> Model Class Initialized
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:35:23 --> Model Class Initialized
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:35:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:35:23 --> Model Class Initialized
ERROR - 2025-04-11 19:35:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:35:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:35:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:35:23 --> Final output sent to browser
DEBUG - 2025-04-11 19:35:23 --> Total execution time: 0.1588
INFO - 2025-04-11 19:39:00 --> Config Class Initialized
INFO - 2025-04-11 19:39:00 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:39:00 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:39:00 --> Utf8 Class Initialized
INFO - 2025-04-11 19:39:00 --> URI Class Initialized
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:39:00 --> Router Class Initialized
INFO - 2025-04-11 19:39:00 --> Output Class Initialized
INFO - 2025-04-11 19:39:00 --> Security Class Initialized
DEBUG - 2025-04-11 19:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:39:00 --> Input Class Initialized
INFO - 2025-04-11 19:39:00 --> Language Class Initialized
INFO - 2025-04-11 19:39:00 --> Language Class Initialized
INFO - 2025-04-11 19:39:00 --> Config Class Initialized
INFO - 2025-04-11 19:39:00 --> Loader Class Initialized
INFO - 2025-04-11 19:39:00 --> Helper loaded: url_helper
INFO - 2025-04-11 19:39:00 --> Helper loaded: file_helper
INFO - 2025-04-11 19:39:00 --> Helper loaded: html_helper
INFO - 2025-04-11 19:39:00 --> Helper loaded: form_helper
INFO - 2025-04-11 19:39:00 --> Helper loaded: text_helper
INFO - 2025-04-11 19:39:00 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:39:00 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:39:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:39:00 --> Database Driver Class Initialized
INFO - 2025-04-11 19:39:00 --> Email Class Initialized
INFO - 2025-04-11 19:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:39:00 --> Form Validation Class Initialized
INFO - 2025-04-11 19:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:39:00 --> Pagination Class Initialized
INFO - 2025-04-11 19:39:00 --> Controller Class Initialized
DEBUG - 2025-04-11 19:39:00 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:39:00 --> Model Class Initialized
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:39:00 --> Model Class Initialized
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:39:00 --> Model Class Initialized
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:39:00 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:39:00 --> Model Class Initialized
ERROR - 2025-04-11 19:39:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:39:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:39:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:39:00 --> Final output sent to browser
DEBUG - 2025-04-11 19:39:00 --> Total execution time: 0.1460
INFO - 2025-04-11 19:49:22 --> Config Class Initialized
INFO - 2025-04-11 19:49:22 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:49:22 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:49:22 --> Utf8 Class Initialized
INFO - 2025-04-11 19:49:22 --> URI Class Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:49:22 --> Router Class Initialized
INFO - 2025-04-11 19:49:22 --> Output Class Initialized
INFO - 2025-04-11 19:49:22 --> Security Class Initialized
DEBUG - 2025-04-11 19:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:49:22 --> Input Class Initialized
INFO - 2025-04-11 19:49:22 --> Language Class Initialized
INFO - 2025-04-11 19:49:22 --> Language Class Initialized
INFO - 2025-04-11 19:49:22 --> Config Class Initialized
INFO - 2025-04-11 19:49:22 --> Loader Class Initialized
INFO - 2025-04-11 19:49:22 --> Helper loaded: url_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: file_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: html_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: form_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: text_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:49:22 --> Database Driver Class Initialized
INFO - 2025-04-11 19:49:22 --> Email Class Initialized
INFO - 2025-04-11 19:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:49:22 --> Form Validation Class Initialized
INFO - 2025-04-11 19:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:49:22 --> Pagination Class Initialized
INFO - 2025-04-11 19:49:22 --> Controller Class Initialized
DEBUG - 2025-04-11 19:49:22 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:49:22 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:49:22 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:49:22 --> Model Class Initialized
INFO - 2025-04-11 19:49:22 --> Config Class Initialized
INFO - 2025-04-11 19:49:22 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:49:22 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:49:22 --> Utf8 Class Initialized
INFO - 2025-04-11 19:49:22 --> URI Class Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:49:22 --> Router Class Initialized
INFO - 2025-04-11 19:49:22 --> Output Class Initialized
INFO - 2025-04-11 19:49:22 --> Security Class Initialized
DEBUG - 2025-04-11 19:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:49:22 --> Input Class Initialized
INFO - 2025-04-11 19:49:22 --> Language Class Initialized
INFO - 2025-04-11 19:49:22 --> Language Class Initialized
INFO - 2025-04-11 19:49:22 --> Config Class Initialized
INFO - 2025-04-11 19:49:22 --> Loader Class Initialized
INFO - 2025-04-11 19:49:22 --> Helper loaded: url_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: file_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: html_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: form_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: text_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:49:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:49:22 --> Database Driver Class Initialized
INFO - 2025-04-11 19:49:22 --> Email Class Initialized
INFO - 2025-04-11 19:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:49:22 --> Form Validation Class Initialized
INFO - 2025-04-11 19:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:49:22 --> Pagination Class Initialized
INFO - 2025-04-11 19:49:22 --> Controller Class Initialized
DEBUG - 2025-04-11 19:49:22 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:49:22 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:49:22 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:49:22 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:49:22 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:49:22 --> Model Class Initialized
ERROR - 2025-04-11 19:49:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:49:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:49:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:49:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:49:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:49:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 19:49:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:49:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:49:23 --> Final output sent to browser
DEBUG - 2025-04-11 19:49:23 --> Total execution time: 0.1514
INFO - 2025-04-11 19:49:30 --> Config Class Initialized
INFO - 2025-04-11 19:49:30 --> Hooks Class Initialized
DEBUG - 2025-04-11 19:49:30 --> UTF-8 Support Enabled
INFO - 2025-04-11 19:49:30 --> Utf8 Class Initialized
INFO - 2025-04-11 19:49:30 --> URI Class Initialized
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 19:49:30 --> Router Class Initialized
INFO - 2025-04-11 19:49:30 --> Output Class Initialized
INFO - 2025-04-11 19:49:30 --> Security Class Initialized
DEBUG - 2025-04-11 19:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 19:49:30 --> Input Class Initialized
INFO - 2025-04-11 19:49:30 --> Language Class Initialized
INFO - 2025-04-11 19:49:30 --> Language Class Initialized
INFO - 2025-04-11 19:49:30 --> Config Class Initialized
INFO - 2025-04-11 19:49:30 --> Loader Class Initialized
INFO - 2025-04-11 19:49:30 --> Helper loaded: url_helper
INFO - 2025-04-11 19:49:30 --> Helper loaded: file_helper
INFO - 2025-04-11 19:49:30 --> Helper loaded: html_helper
INFO - 2025-04-11 19:49:30 --> Helper loaded: form_helper
INFO - 2025-04-11 19:49:30 --> Helper loaded: text_helper
INFO - 2025-04-11 19:49:30 --> Helper loaded: lang_helper
INFO - 2025-04-11 19:49:30 --> Helper loaded: directory_helper
INFO - 2025-04-11 19:49:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 19:49:30 --> Database Driver Class Initialized
INFO - 2025-04-11 19:49:30 --> Email Class Initialized
INFO - 2025-04-11 19:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 19:49:30 --> Form Validation Class Initialized
INFO - 2025-04-11 19:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 19:49:30 --> Pagination Class Initialized
INFO - 2025-04-11 19:49:30 --> Controller Class Initialized
DEBUG - 2025-04-11 19:49:30 --> Returns MX_Controller Initialized
INFO - 2025-04-11 19:49:30 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 19:49:30 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 19:49:30 --> Model Class Initialized
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 19:49:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 19:49:30 --> Model Class Initialized
ERROR - 2025-04-11 19:49:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 19:49:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 19:49:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 19:49:30 --> Final output sent to browser
DEBUG - 2025-04-11 19:49:30 --> Total execution time: 0.1349
INFO - 2025-04-11 20:04:59 --> Config Class Initialized
INFO - 2025-04-11 20:04:59 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:04:59 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:04:59 --> Utf8 Class Initialized
INFO - 2025-04-11 20:04:59 --> URI Class Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:04:59 --> Router Class Initialized
INFO - 2025-04-11 20:04:59 --> Output Class Initialized
INFO - 2025-04-11 20:04:59 --> Security Class Initialized
DEBUG - 2025-04-11 20:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:04:59 --> Input Class Initialized
INFO - 2025-04-11 20:04:59 --> Language Class Initialized
INFO - 2025-04-11 20:04:59 --> Language Class Initialized
INFO - 2025-04-11 20:04:59 --> Config Class Initialized
INFO - 2025-04-11 20:04:59 --> Loader Class Initialized
INFO - 2025-04-11 20:04:59 --> Helper loaded: url_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: file_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: html_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: form_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: text_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:04:59 --> Database Driver Class Initialized
INFO - 2025-04-11 20:04:59 --> Email Class Initialized
INFO - 2025-04-11 20:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:04:59 --> Form Validation Class Initialized
INFO - 2025-04-11 20:04:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:04:59 --> Pagination Class Initialized
INFO - 2025-04-11 20:04:59 --> Controller Class Initialized
DEBUG - 2025-04-11 20:04:59 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:04:59 --> Model Class Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:04:59 --> Model Class Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:04:59 --> Model Class Initialized
INFO - 2025-04-11 20:04:59 --> Config Class Initialized
INFO - 2025-04-11 20:04:59 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:04:59 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:04:59 --> Utf8 Class Initialized
INFO - 2025-04-11 20:04:59 --> URI Class Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:04:59 --> Router Class Initialized
INFO - 2025-04-11 20:04:59 --> Output Class Initialized
INFO - 2025-04-11 20:04:59 --> Security Class Initialized
DEBUG - 2025-04-11 20:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:04:59 --> Input Class Initialized
INFO - 2025-04-11 20:04:59 --> Language Class Initialized
INFO - 2025-04-11 20:04:59 --> Language Class Initialized
INFO - 2025-04-11 20:04:59 --> Config Class Initialized
INFO - 2025-04-11 20:04:59 --> Loader Class Initialized
INFO - 2025-04-11 20:04:59 --> Helper loaded: url_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: file_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: html_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: form_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: text_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:04:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:04:59 --> Database Driver Class Initialized
INFO - 2025-04-11 20:04:59 --> Email Class Initialized
INFO - 2025-04-11 20:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:04:59 --> Form Validation Class Initialized
INFO - 2025-04-11 20:04:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:04:59 --> Pagination Class Initialized
INFO - 2025-04-11 20:04:59 --> Controller Class Initialized
DEBUG - 2025-04-11 20:04:59 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:04:59 --> Model Class Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:04:59 --> Model Class Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:04:59 --> Model Class Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:04:59 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:04:59 --> Model Class Initialized
ERROR - 2025-04-11 20:04:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:04:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:04:59 --> Final output sent to browser
DEBUG - 2025-04-11 20:04:59 --> Total execution time: 0.1290
INFO - 2025-04-11 20:05:03 --> Config Class Initialized
INFO - 2025-04-11 20:05:03 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:05:03 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:05:03 --> Utf8 Class Initialized
INFO - 2025-04-11 20:05:03 --> URI Class Initialized
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:05:03 --> Router Class Initialized
INFO - 2025-04-11 20:05:03 --> Output Class Initialized
INFO - 2025-04-11 20:05:03 --> Security Class Initialized
DEBUG - 2025-04-11 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:05:03 --> Input Class Initialized
INFO - 2025-04-11 20:05:03 --> Language Class Initialized
INFO - 2025-04-11 20:05:03 --> Language Class Initialized
INFO - 2025-04-11 20:05:03 --> Config Class Initialized
INFO - 2025-04-11 20:05:03 --> Loader Class Initialized
INFO - 2025-04-11 20:05:03 --> Helper loaded: url_helper
INFO - 2025-04-11 20:05:03 --> Helper loaded: file_helper
INFO - 2025-04-11 20:05:03 --> Helper loaded: html_helper
INFO - 2025-04-11 20:05:03 --> Helper loaded: form_helper
INFO - 2025-04-11 20:05:03 --> Helper loaded: text_helper
INFO - 2025-04-11 20:05:03 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:05:03 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:05:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:05:03 --> Database Driver Class Initialized
INFO - 2025-04-11 20:05:03 --> Email Class Initialized
INFO - 2025-04-11 20:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:05:03 --> Form Validation Class Initialized
INFO - 2025-04-11 20:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:05:03 --> Pagination Class Initialized
INFO - 2025-04-11 20:05:03 --> Controller Class Initialized
DEBUG - 2025-04-11 20:05:03 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:05:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:05:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:05:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:05:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:05:03 --> Model Class Initialized
ERROR - 2025-04-11 20:05:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:05:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:05:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:05:03 --> Final output sent to browser
DEBUG - 2025-04-11 20:05:03 --> Total execution time: 0.1489
INFO - 2025-04-11 20:05:08 --> Config Class Initialized
INFO - 2025-04-11 20:05:08 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:05:08 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:05:08 --> Utf8 Class Initialized
INFO - 2025-04-11 20:05:08 --> URI Class Initialized
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:05:08 --> Router Class Initialized
INFO - 2025-04-11 20:05:08 --> Output Class Initialized
INFO - 2025-04-11 20:05:08 --> Security Class Initialized
DEBUG - 2025-04-11 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:05:08 --> Input Class Initialized
INFO - 2025-04-11 20:05:08 --> Language Class Initialized
INFO - 2025-04-11 20:05:08 --> Language Class Initialized
INFO - 2025-04-11 20:05:08 --> Config Class Initialized
INFO - 2025-04-11 20:05:08 --> Loader Class Initialized
INFO - 2025-04-11 20:05:08 --> Helper loaded: url_helper
INFO - 2025-04-11 20:05:08 --> Helper loaded: file_helper
INFO - 2025-04-11 20:05:08 --> Helper loaded: html_helper
INFO - 2025-04-11 20:05:08 --> Helper loaded: form_helper
INFO - 2025-04-11 20:05:08 --> Helper loaded: text_helper
INFO - 2025-04-11 20:05:08 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:05:08 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:05:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:05:08 --> Database Driver Class Initialized
INFO - 2025-04-11 20:05:08 --> Email Class Initialized
INFO - 2025-04-11 20:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:05:08 --> Form Validation Class Initialized
INFO - 2025-04-11 20:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:05:08 --> Pagination Class Initialized
INFO - 2025-04-11 20:05:08 --> Controller Class Initialized
DEBUG - 2025-04-11 20:05:08 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:05:08 --> Model Class Initialized
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:05:08 --> Model Class Initialized
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:05:08 --> Model Class Initialized
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:05:08 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:05:08 --> Model Class Initialized
ERROR - 2025-04-11 20:05:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:05:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:05:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:05:08 --> Final output sent to browser
DEBUG - 2025-04-11 20:05:08 --> Total execution time: 0.1612
INFO - 2025-04-11 20:15:46 --> Config Class Initialized
INFO - 2025-04-11 20:15:46 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:15:46 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:15:46 --> Utf8 Class Initialized
INFO - 2025-04-11 20:15:46 --> URI Class Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:15:46 --> Router Class Initialized
INFO - 2025-04-11 20:15:46 --> Output Class Initialized
INFO - 2025-04-11 20:15:46 --> Security Class Initialized
DEBUG - 2025-04-11 20:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:15:46 --> Input Class Initialized
INFO - 2025-04-11 20:15:46 --> Language Class Initialized
INFO - 2025-04-11 20:15:46 --> Language Class Initialized
INFO - 2025-04-11 20:15:46 --> Config Class Initialized
INFO - 2025-04-11 20:15:46 --> Loader Class Initialized
INFO - 2025-04-11 20:15:46 --> Helper loaded: url_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: file_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: html_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: form_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: text_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:15:46 --> Database Driver Class Initialized
INFO - 2025-04-11 20:15:46 --> Email Class Initialized
INFO - 2025-04-11 20:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:15:46 --> Form Validation Class Initialized
INFO - 2025-04-11 20:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:15:46 --> Pagination Class Initialized
INFO - 2025-04-11 20:15:46 --> Controller Class Initialized
DEBUG - 2025-04-11 20:15:46 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:15:46 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:15:46 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:15:46 --> Model Class Initialized
INFO - 2025-04-11 20:15:46 --> Config Class Initialized
INFO - 2025-04-11 20:15:46 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:15:46 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:15:46 --> Utf8 Class Initialized
INFO - 2025-04-11 20:15:46 --> URI Class Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:15:46 --> Router Class Initialized
INFO - 2025-04-11 20:15:46 --> Output Class Initialized
INFO - 2025-04-11 20:15:46 --> Security Class Initialized
DEBUG - 2025-04-11 20:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:15:46 --> Input Class Initialized
INFO - 2025-04-11 20:15:46 --> Language Class Initialized
INFO - 2025-04-11 20:15:46 --> Language Class Initialized
INFO - 2025-04-11 20:15:46 --> Config Class Initialized
INFO - 2025-04-11 20:15:46 --> Loader Class Initialized
INFO - 2025-04-11 20:15:46 --> Helper loaded: url_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: file_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: html_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: form_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: text_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:15:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:15:46 --> Database Driver Class Initialized
INFO - 2025-04-11 20:15:46 --> Email Class Initialized
INFO - 2025-04-11 20:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:15:46 --> Form Validation Class Initialized
INFO - 2025-04-11 20:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:15:46 --> Pagination Class Initialized
INFO - 2025-04-11 20:15:46 --> Controller Class Initialized
DEBUG - 2025-04-11 20:15:46 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:15:46 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:15:46 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:15:46 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:15:46 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:15:46 --> Model Class Initialized
ERROR - 2025-04-11 20:15:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:15:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:15:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:15:46 --> Final output sent to browser
DEBUG - 2025-04-11 20:15:46 --> Total execution time: 0.1578
INFO - 2025-04-11 20:15:50 --> Config Class Initialized
INFO - 2025-04-11 20:15:50 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:15:50 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:15:50 --> Utf8 Class Initialized
INFO - 2025-04-11 20:15:50 --> URI Class Initialized
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:15:50 --> Router Class Initialized
INFO - 2025-04-11 20:15:50 --> Output Class Initialized
INFO - 2025-04-11 20:15:50 --> Security Class Initialized
DEBUG - 2025-04-11 20:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:15:50 --> Input Class Initialized
INFO - 2025-04-11 20:15:50 --> Language Class Initialized
INFO - 2025-04-11 20:15:50 --> Language Class Initialized
INFO - 2025-04-11 20:15:50 --> Config Class Initialized
INFO - 2025-04-11 20:15:50 --> Loader Class Initialized
INFO - 2025-04-11 20:15:50 --> Helper loaded: url_helper
INFO - 2025-04-11 20:15:50 --> Helper loaded: file_helper
INFO - 2025-04-11 20:15:50 --> Helper loaded: html_helper
INFO - 2025-04-11 20:15:50 --> Helper loaded: form_helper
INFO - 2025-04-11 20:15:50 --> Helper loaded: text_helper
INFO - 2025-04-11 20:15:50 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:15:50 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:15:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:15:50 --> Database Driver Class Initialized
INFO - 2025-04-11 20:15:50 --> Email Class Initialized
INFO - 2025-04-11 20:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:15:50 --> Form Validation Class Initialized
INFO - 2025-04-11 20:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:15:50 --> Pagination Class Initialized
INFO - 2025-04-11 20:15:50 --> Controller Class Initialized
DEBUG - 2025-04-11 20:15:50 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:15:50 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:15:50 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:15:50 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:15:50 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:15:50 --> Model Class Initialized
ERROR - 2025-04-11 20:15:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:15:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:15:50 --> Final output sent to browser
DEBUG - 2025-04-11 20:15:50 --> Total execution time: 0.1277
INFO - 2025-04-11 20:15:54 --> Config Class Initialized
INFO - 2025-04-11 20:15:54 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:15:54 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:15:54 --> Utf8 Class Initialized
INFO - 2025-04-11 20:15:54 --> URI Class Initialized
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:15:54 --> Router Class Initialized
INFO - 2025-04-11 20:15:54 --> Output Class Initialized
INFO - 2025-04-11 20:15:54 --> Security Class Initialized
DEBUG - 2025-04-11 20:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:15:54 --> Input Class Initialized
INFO - 2025-04-11 20:15:54 --> Language Class Initialized
INFO - 2025-04-11 20:15:54 --> Language Class Initialized
INFO - 2025-04-11 20:15:54 --> Config Class Initialized
INFO - 2025-04-11 20:15:54 --> Loader Class Initialized
INFO - 2025-04-11 20:15:54 --> Helper loaded: url_helper
INFO - 2025-04-11 20:15:54 --> Helper loaded: file_helper
INFO - 2025-04-11 20:15:54 --> Helper loaded: html_helper
INFO - 2025-04-11 20:15:54 --> Helper loaded: form_helper
INFO - 2025-04-11 20:15:54 --> Helper loaded: text_helper
INFO - 2025-04-11 20:15:54 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:15:54 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:15:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:15:54 --> Database Driver Class Initialized
INFO - 2025-04-11 20:15:54 --> Email Class Initialized
INFO - 2025-04-11 20:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:15:54 --> Form Validation Class Initialized
INFO - 2025-04-11 20:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:15:54 --> Pagination Class Initialized
INFO - 2025-04-11 20:15:54 --> Controller Class Initialized
DEBUG - 2025-04-11 20:15:54 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:15:54 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:15:54 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:15:54 --> Model Class Initialized
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:15:54 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:15:54 --> Model Class Initialized
ERROR - 2025-04-11 20:15:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:15:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:15:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:15:54 --> Final output sent to browser
DEBUG - 2025-04-11 20:15:54 --> Total execution time: 0.2043
INFO - 2025-04-11 20:19:39 --> Config Class Initialized
INFO - 2025-04-11 20:19:39 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:19:39 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:19:39 --> Utf8 Class Initialized
INFO - 2025-04-11 20:19:39 --> URI Class Initialized
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:19:39 --> Router Class Initialized
INFO - 2025-04-11 20:19:39 --> Output Class Initialized
INFO - 2025-04-11 20:19:39 --> Security Class Initialized
DEBUG - 2025-04-11 20:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:19:39 --> Input Class Initialized
INFO - 2025-04-11 20:19:39 --> Language Class Initialized
INFO - 2025-04-11 20:19:39 --> Language Class Initialized
INFO - 2025-04-11 20:19:39 --> Config Class Initialized
INFO - 2025-04-11 20:19:39 --> Loader Class Initialized
INFO - 2025-04-11 20:19:39 --> Helper loaded: url_helper
INFO - 2025-04-11 20:19:39 --> Helper loaded: file_helper
INFO - 2025-04-11 20:19:39 --> Helper loaded: html_helper
INFO - 2025-04-11 20:19:39 --> Helper loaded: form_helper
INFO - 2025-04-11 20:19:39 --> Helper loaded: text_helper
INFO - 2025-04-11 20:19:39 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:19:39 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:19:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:19:39 --> Database Driver Class Initialized
INFO - 2025-04-11 20:19:39 --> Email Class Initialized
INFO - 2025-04-11 20:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:19:39 --> Form Validation Class Initialized
INFO - 2025-04-11 20:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:19:39 --> Pagination Class Initialized
INFO - 2025-04-11 20:19:39 --> Controller Class Initialized
DEBUG - 2025-04-11 20:19:39 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:19:39 --> Model Class Initialized
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:19:39 --> Model Class Initialized
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:19:39 --> Model Class Initialized
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:19:39 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:19:39 --> Model Class Initialized
ERROR - 2025-04-11 20:19:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:19:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:19:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:19:39 --> Final output sent to browser
DEBUG - 2025-04-11 20:19:39 --> Total execution time: 0.1632
INFO - 2025-04-11 20:19:42 --> Config Class Initialized
INFO - 2025-04-11 20:19:42 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:19:42 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:19:42 --> Utf8 Class Initialized
INFO - 2025-04-11 20:19:42 --> URI Class Initialized
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:19:42 --> Router Class Initialized
INFO - 2025-04-11 20:19:42 --> Output Class Initialized
INFO - 2025-04-11 20:19:42 --> Security Class Initialized
DEBUG - 2025-04-11 20:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:19:42 --> Input Class Initialized
INFO - 2025-04-11 20:19:42 --> Language Class Initialized
INFO - 2025-04-11 20:19:42 --> Language Class Initialized
INFO - 2025-04-11 20:19:42 --> Config Class Initialized
INFO - 2025-04-11 20:19:42 --> Loader Class Initialized
INFO - 2025-04-11 20:19:42 --> Helper loaded: url_helper
INFO - 2025-04-11 20:19:42 --> Helper loaded: file_helper
INFO - 2025-04-11 20:19:42 --> Helper loaded: html_helper
INFO - 2025-04-11 20:19:42 --> Helper loaded: form_helper
INFO - 2025-04-11 20:19:42 --> Helper loaded: text_helper
INFO - 2025-04-11 20:19:42 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:19:42 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:19:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:19:42 --> Database Driver Class Initialized
INFO - 2025-04-11 20:19:42 --> Email Class Initialized
INFO - 2025-04-11 20:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:19:42 --> Form Validation Class Initialized
INFO - 2025-04-11 20:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:19:42 --> Pagination Class Initialized
INFO - 2025-04-11 20:19:42 --> Controller Class Initialized
DEBUG - 2025-04-11 20:19:42 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:19:42 --> Model Class Initialized
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:19:42 --> Model Class Initialized
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:19:42 --> Model Class Initialized
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:19:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:19:42 --> Model Class Initialized
ERROR - 2025-04-11 20:19:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:19:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:19:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:19:42 --> Final output sent to browser
DEBUG - 2025-04-11 20:19:42 --> Total execution time: 0.1551
INFO - 2025-04-11 20:20:05 --> Config Class Initialized
INFO - 2025-04-11 20:20:05 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:20:05 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:20:05 --> Utf8 Class Initialized
INFO - 2025-04-11 20:20:05 --> URI Class Initialized
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:20:05 --> Router Class Initialized
INFO - 2025-04-11 20:20:05 --> Output Class Initialized
INFO - 2025-04-11 20:20:05 --> Security Class Initialized
DEBUG - 2025-04-11 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:20:05 --> Input Class Initialized
INFO - 2025-04-11 20:20:05 --> Language Class Initialized
INFO - 2025-04-11 20:20:05 --> Language Class Initialized
INFO - 2025-04-11 20:20:05 --> Config Class Initialized
INFO - 2025-04-11 20:20:05 --> Loader Class Initialized
INFO - 2025-04-11 20:20:05 --> Helper loaded: url_helper
INFO - 2025-04-11 20:20:05 --> Helper loaded: file_helper
INFO - 2025-04-11 20:20:05 --> Helper loaded: html_helper
INFO - 2025-04-11 20:20:05 --> Helper loaded: form_helper
INFO - 2025-04-11 20:20:05 --> Helper loaded: text_helper
INFO - 2025-04-11 20:20:05 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:20:05 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:20:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:20:05 --> Database Driver Class Initialized
INFO - 2025-04-11 20:20:05 --> Email Class Initialized
INFO - 2025-04-11 20:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:20:05 --> Form Validation Class Initialized
INFO - 2025-04-11 20:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:20:05 --> Pagination Class Initialized
INFO - 2025-04-11 20:20:05 --> Controller Class Initialized
DEBUG - 2025-04-11 20:20:05 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:20:05 --> Model Class Initialized
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:20:05 --> Model Class Initialized
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:20:05 --> Model Class Initialized
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:20:05 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:20:05 --> Model Class Initialized
ERROR - 2025-04-11 20:20:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:20:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:20:05 --> Final output sent to browser
DEBUG - 2025-04-11 20:20:05 --> Total execution time: 0.1439
INFO - 2025-04-11 20:31:04 --> Config Class Initialized
INFO - 2025-04-11 20:31:04 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:31:04 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:31:04 --> Utf8 Class Initialized
INFO - 2025-04-11 20:31:04 --> URI Class Initialized
DEBUG - 2025-04-11 20:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:31:04 --> Router Class Initialized
INFO - 2025-04-11 20:31:04 --> Output Class Initialized
INFO - 2025-04-11 20:31:04 --> Security Class Initialized
DEBUG - 2025-04-11 20:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:31:04 --> Input Class Initialized
INFO - 2025-04-11 20:31:04 --> Language Class Initialized
INFO - 2025-04-11 20:31:04 --> Language Class Initialized
INFO - 2025-04-11 20:31:04 --> Config Class Initialized
INFO - 2025-04-11 20:31:04 --> Loader Class Initialized
INFO - 2025-04-11 20:31:04 --> Helper loaded: url_helper
INFO - 2025-04-11 20:31:04 --> Helper loaded: file_helper
INFO - 2025-04-11 20:31:04 --> Helper loaded: html_helper
INFO - 2025-04-11 20:31:04 --> Helper loaded: form_helper
INFO - 2025-04-11 20:31:04 --> Helper loaded: text_helper
INFO - 2025-04-11 20:31:04 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:31:04 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:31:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:31:04 --> Database Driver Class Initialized
INFO - 2025-04-11 20:31:04 --> Email Class Initialized
INFO - 2025-04-11 20:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:31:04 --> Form Validation Class Initialized
INFO - 2025-04-11 20:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:31:04 --> Pagination Class Initialized
INFO - 2025-04-11 20:31:04 --> Controller Class Initialized
DEBUG - 2025-04-11 20:31:04 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:31:04 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:31:04 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:31:04 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:31:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:31:04 --> Model Class Initialized
ERROR - 2025-04-11 20:31:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:31:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:31:05 --> Final output sent to browser
DEBUG - 2025-04-11 20:31:05 --> Total execution time: 0.4320
INFO - 2025-04-11 20:31:07 --> Config Class Initialized
INFO - 2025-04-11 20:31:07 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:31:07 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:31:07 --> Utf8 Class Initialized
INFO - 2025-04-11 20:31:07 --> URI Class Initialized
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:31:07 --> Router Class Initialized
INFO - 2025-04-11 20:31:07 --> Output Class Initialized
INFO - 2025-04-11 20:31:07 --> Security Class Initialized
DEBUG - 2025-04-11 20:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:31:07 --> Input Class Initialized
INFO - 2025-04-11 20:31:07 --> Language Class Initialized
INFO - 2025-04-11 20:31:07 --> Language Class Initialized
INFO - 2025-04-11 20:31:07 --> Config Class Initialized
INFO - 2025-04-11 20:31:07 --> Loader Class Initialized
INFO - 2025-04-11 20:31:07 --> Helper loaded: url_helper
INFO - 2025-04-11 20:31:07 --> Helper loaded: file_helper
INFO - 2025-04-11 20:31:07 --> Helper loaded: html_helper
INFO - 2025-04-11 20:31:07 --> Helper loaded: form_helper
INFO - 2025-04-11 20:31:07 --> Helper loaded: text_helper
INFO - 2025-04-11 20:31:07 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:31:07 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:31:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:31:07 --> Database Driver Class Initialized
INFO - 2025-04-11 20:31:07 --> Email Class Initialized
INFO - 2025-04-11 20:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:31:07 --> Form Validation Class Initialized
INFO - 2025-04-11 20:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:31:07 --> Pagination Class Initialized
INFO - 2025-04-11 20:31:07 --> Controller Class Initialized
DEBUG - 2025-04-11 20:31:07 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:31:07 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:31:07 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:31:07 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:31:07 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:31:07 --> Model Class Initialized
ERROR - 2025-04-11 20:31:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:31:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:31:07 --> Final output sent to browser
DEBUG - 2025-04-11 20:31:07 --> Total execution time: 0.1192
INFO - 2025-04-11 20:31:23 --> Config Class Initialized
INFO - 2025-04-11 20:31:23 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:31:23 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:31:23 --> Utf8 Class Initialized
INFO - 2025-04-11 20:31:23 --> URI Class Initialized
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:31:23 --> Router Class Initialized
INFO - 2025-04-11 20:31:23 --> Output Class Initialized
INFO - 2025-04-11 20:31:23 --> Security Class Initialized
DEBUG - 2025-04-11 20:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:31:23 --> Input Class Initialized
INFO - 2025-04-11 20:31:23 --> Language Class Initialized
INFO - 2025-04-11 20:31:23 --> Language Class Initialized
INFO - 2025-04-11 20:31:23 --> Config Class Initialized
INFO - 2025-04-11 20:31:23 --> Loader Class Initialized
INFO - 2025-04-11 20:31:23 --> Helper loaded: url_helper
INFO - 2025-04-11 20:31:23 --> Helper loaded: file_helper
INFO - 2025-04-11 20:31:23 --> Helper loaded: html_helper
INFO - 2025-04-11 20:31:23 --> Helper loaded: form_helper
INFO - 2025-04-11 20:31:23 --> Helper loaded: text_helper
INFO - 2025-04-11 20:31:23 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:31:23 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:31:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:31:23 --> Database Driver Class Initialized
INFO - 2025-04-11 20:31:23 --> Email Class Initialized
INFO - 2025-04-11 20:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:31:23 --> Form Validation Class Initialized
INFO - 2025-04-11 20:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:31:23 --> Pagination Class Initialized
INFO - 2025-04-11 20:31:23 --> Controller Class Initialized
DEBUG - 2025-04-11 20:31:23 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:31:23 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:31:23 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:31:23 --> Model Class Initialized
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:31:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:31:23 --> Model Class Initialized
ERROR - 2025-04-11 20:31:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:31:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:31:23 --> Final output sent to browser
DEBUG - 2025-04-11 20:31:23 --> Total execution time: 0.1979
INFO - 2025-04-11 20:31:42 --> Config Class Initialized
INFO - 2025-04-11 20:31:42 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:31:42 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:31:42 --> Utf8 Class Initialized
INFO - 2025-04-11 20:31:42 --> URI Class Initialized
DEBUG - 2025-04-11 20:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 20:31:42 --> Router Class Initialized
INFO - 2025-04-11 20:31:42 --> Output Class Initialized
INFO - 2025-04-11 20:31:42 --> Security Class Initialized
DEBUG - 2025-04-11 20:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:31:42 --> Input Class Initialized
INFO - 2025-04-11 20:31:42 --> Language Class Initialized
INFO - 2025-04-11 20:31:42 --> Language Class Initialized
INFO - 2025-04-11 20:31:42 --> Config Class Initialized
INFO - 2025-04-11 20:31:42 --> Loader Class Initialized
INFO - 2025-04-11 20:31:42 --> Helper loaded: url_helper
INFO - 2025-04-11 20:31:42 --> Helper loaded: file_helper
INFO - 2025-04-11 20:31:42 --> Helper loaded: html_helper
INFO - 2025-04-11 20:31:42 --> Helper loaded: form_helper
INFO - 2025-04-11 20:31:42 --> Helper loaded: text_helper
INFO - 2025-04-11 20:31:42 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:31:42 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:31:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:31:42 --> Database Driver Class Initialized
INFO - 2025-04-11 20:31:42 --> Email Class Initialized
INFO - 2025-04-11 20:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:31:42 --> Form Validation Class Initialized
INFO - 2025-04-11 20:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:31:42 --> Pagination Class Initialized
INFO - 2025-04-11 20:31:42 --> Controller Class Initialized
DEBUG - 2025-04-11 20:31:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 20:31:43 --> Config Class Initialized
INFO - 2025-04-11 20:31:43 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:31:43 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:31:43 --> Utf8 Class Initialized
INFO - 2025-04-11 20:31:43 --> URI Class Initialized
DEBUG - 2025-04-11 20:31:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 20:31:43 --> Router Class Initialized
INFO - 2025-04-11 20:31:43 --> Output Class Initialized
INFO - 2025-04-11 20:31:43 --> Security Class Initialized
DEBUG - 2025-04-11 20:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:31:43 --> Input Class Initialized
INFO - 2025-04-11 20:31:43 --> Language Class Initialized
INFO - 2025-04-11 20:31:43 --> Language Class Initialized
INFO - 2025-04-11 20:31:43 --> Config Class Initialized
INFO - 2025-04-11 20:31:43 --> Loader Class Initialized
INFO - 2025-04-11 20:31:43 --> Helper loaded: url_helper
INFO - 2025-04-11 20:31:43 --> Helper loaded: file_helper
INFO - 2025-04-11 20:31:43 --> Helper loaded: html_helper
INFO - 2025-04-11 20:31:43 --> Helper loaded: form_helper
INFO - 2025-04-11 20:31:43 --> Helper loaded: text_helper
INFO - 2025-04-11 20:31:43 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:31:43 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:31:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:31:43 --> Database Driver Class Initialized
INFO - 2025-04-11 20:31:43 --> Email Class Initialized
INFO - 2025-04-11 20:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:31:43 --> Form Validation Class Initialized
INFO - 2025-04-11 20:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:31:43 --> Pagination Class Initialized
INFO - 2025-04-11 20:31:43 --> Controller Class Initialized
DEBUG - 2025-04-11 20:31:43 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 20:31:47 --> Config Class Initialized
INFO - 2025-04-11 20:31:47 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:31:47 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:31:47 --> Utf8 Class Initialized
INFO - 2025-04-11 20:31:47 --> URI Class Initialized
DEBUG - 2025-04-11 20:31:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 20:31:47 --> Router Class Initialized
INFO - 2025-04-11 20:31:47 --> Output Class Initialized
INFO - 2025-04-11 20:31:47 --> Security Class Initialized
DEBUG - 2025-04-11 20:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:31:47 --> Input Class Initialized
INFO - 2025-04-11 20:31:47 --> Language Class Initialized
INFO - 2025-04-11 20:31:47 --> Language Class Initialized
INFO - 2025-04-11 20:31:47 --> Config Class Initialized
INFO - 2025-04-11 20:31:47 --> Loader Class Initialized
INFO - 2025-04-11 20:31:47 --> Helper loaded: url_helper
INFO - 2025-04-11 20:31:47 --> Helper loaded: file_helper
INFO - 2025-04-11 20:31:47 --> Helper loaded: html_helper
INFO - 2025-04-11 20:31:47 --> Helper loaded: form_helper
INFO - 2025-04-11 20:31:47 --> Helper loaded: text_helper
INFO - 2025-04-11 20:31:47 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:31:47 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:31:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:31:47 --> Database Driver Class Initialized
INFO - 2025-04-11 20:31:47 --> Email Class Initialized
INFO - 2025-04-11 20:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:31:47 --> Form Validation Class Initialized
INFO - 2025-04-11 20:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:31:47 --> Pagination Class Initialized
INFO - 2025-04-11 20:31:47 --> Controller Class Initialized
DEBUG - 2025-04-11 20:31:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 20:32:35 --> Config Class Initialized
INFO - 2025-04-11 20:32:35 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:32:35 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:32:35 --> Utf8 Class Initialized
INFO - 2025-04-11 20:32:35 --> URI Class Initialized
DEBUG - 2025-04-11 20:32:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 20:32:35 --> Router Class Initialized
INFO - 2025-04-11 20:32:35 --> Output Class Initialized
INFO - 2025-04-11 20:32:35 --> Security Class Initialized
DEBUG - 2025-04-11 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:32:35 --> Input Class Initialized
INFO - 2025-04-11 20:32:35 --> Language Class Initialized
INFO - 2025-04-11 20:32:35 --> Language Class Initialized
INFO - 2025-04-11 20:32:35 --> Config Class Initialized
INFO - 2025-04-11 20:32:35 --> Loader Class Initialized
INFO - 2025-04-11 20:32:35 --> Helper loaded: url_helper
INFO - 2025-04-11 20:32:35 --> Helper loaded: file_helper
INFO - 2025-04-11 20:32:35 --> Helper loaded: html_helper
INFO - 2025-04-11 20:32:35 --> Helper loaded: form_helper
INFO - 2025-04-11 20:32:35 --> Helper loaded: text_helper
INFO - 2025-04-11 20:32:35 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:32:35 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:32:35 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:32:35 --> Database Driver Class Initialized
INFO - 2025-04-11 20:32:35 --> Email Class Initialized
INFO - 2025-04-11 20:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:32:35 --> Form Validation Class Initialized
INFO - 2025-04-11 20:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:32:35 --> Pagination Class Initialized
INFO - 2025-04-11 20:32:35 --> Controller Class Initialized
DEBUG - 2025-04-11 20:32:35 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 20:32:36 --> Config Class Initialized
INFO - 2025-04-11 20:32:36 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:32:36 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:32:36 --> Utf8 Class Initialized
INFO - 2025-04-11 20:32:36 --> URI Class Initialized
DEBUG - 2025-04-11 20:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 20:32:36 --> Router Class Initialized
INFO - 2025-04-11 20:32:36 --> Output Class Initialized
INFO - 2025-04-11 20:32:36 --> Security Class Initialized
DEBUG - 2025-04-11 20:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:32:36 --> Input Class Initialized
INFO - 2025-04-11 20:32:36 --> Language Class Initialized
INFO - 2025-04-11 20:32:36 --> Language Class Initialized
INFO - 2025-04-11 20:32:36 --> Config Class Initialized
INFO - 2025-04-11 20:32:36 --> Loader Class Initialized
INFO - 2025-04-11 20:32:36 --> Helper loaded: url_helper
INFO - 2025-04-11 20:32:36 --> Helper loaded: file_helper
INFO - 2025-04-11 20:32:36 --> Helper loaded: html_helper
INFO - 2025-04-11 20:32:36 --> Helper loaded: form_helper
INFO - 2025-04-11 20:32:36 --> Helper loaded: text_helper
INFO - 2025-04-11 20:32:36 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:32:36 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:32:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:32:36 --> Database Driver Class Initialized
INFO - 2025-04-11 20:32:36 --> Email Class Initialized
INFO - 2025-04-11 20:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:32:36 --> Form Validation Class Initialized
INFO - 2025-04-11 20:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:32:36 --> Pagination Class Initialized
INFO - 2025-04-11 20:32:36 --> Controller Class Initialized
DEBUG - 2025-04-11 20:32:36 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 20:33:21 --> Config Class Initialized
INFO - 2025-04-11 20:33:21 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:33:21 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:33:21 --> Utf8 Class Initialized
INFO - 2025-04-11 20:33:21 --> URI Class Initialized
DEBUG - 2025-04-11 20:33:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 20:33:21 --> Router Class Initialized
INFO - 2025-04-11 20:33:21 --> Output Class Initialized
INFO - 2025-04-11 20:33:21 --> Security Class Initialized
DEBUG - 2025-04-11 20:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:33:21 --> Input Class Initialized
INFO - 2025-04-11 20:33:21 --> Language Class Initialized
INFO - 2025-04-11 20:33:21 --> Language Class Initialized
INFO - 2025-04-11 20:33:21 --> Config Class Initialized
INFO - 2025-04-11 20:33:21 --> Loader Class Initialized
INFO - 2025-04-11 20:33:21 --> Helper loaded: url_helper
INFO - 2025-04-11 20:33:21 --> Helper loaded: file_helper
INFO - 2025-04-11 20:33:21 --> Helper loaded: html_helper
INFO - 2025-04-11 20:33:21 --> Helper loaded: form_helper
INFO - 2025-04-11 20:33:21 --> Helper loaded: text_helper
INFO - 2025-04-11 20:33:21 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:33:21 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:33:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:33:21 --> Database Driver Class Initialized
INFO - 2025-04-11 20:33:21 --> Email Class Initialized
INFO - 2025-04-11 20:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:33:21 --> Form Validation Class Initialized
INFO - 2025-04-11 20:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:33:21 --> Pagination Class Initialized
INFO - 2025-04-11 20:33:21 --> Controller Class Initialized
DEBUG - 2025-04-11 20:33:21 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 20:33:24 --> Config Class Initialized
INFO - 2025-04-11 20:33:24 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:33:24 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:33:24 --> Utf8 Class Initialized
INFO - 2025-04-11 20:33:24 --> URI Class Initialized
DEBUG - 2025-04-11 20:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-11 20:33:24 --> Router Class Initialized
INFO - 2025-04-11 20:33:24 --> Output Class Initialized
INFO - 2025-04-11 20:33:24 --> Security Class Initialized
DEBUG - 2025-04-11 20:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:33:24 --> Input Class Initialized
INFO - 2025-04-11 20:33:24 --> Language Class Initialized
INFO - 2025-04-11 20:33:24 --> Language Class Initialized
INFO - 2025-04-11 20:33:24 --> Config Class Initialized
INFO - 2025-04-11 20:33:24 --> Loader Class Initialized
INFO - 2025-04-11 20:33:24 --> Helper loaded: url_helper
INFO - 2025-04-11 20:33:24 --> Helper loaded: file_helper
INFO - 2025-04-11 20:33:24 --> Helper loaded: html_helper
INFO - 2025-04-11 20:33:24 --> Helper loaded: form_helper
INFO - 2025-04-11 20:33:24 --> Helper loaded: text_helper
INFO - 2025-04-11 20:33:24 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:33:24 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:33:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:33:24 --> Database Driver Class Initialized
INFO - 2025-04-11 20:33:24 --> Email Class Initialized
INFO - 2025-04-11 20:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:33:24 --> Form Validation Class Initialized
INFO - 2025-04-11 20:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:33:24 --> Pagination Class Initialized
INFO - 2025-04-11 20:33:24 --> Controller Class Initialized
DEBUG - 2025-04-11 20:33:24 --> Invoice MX_Controller Initialized
INFO - 2025-04-11 20:34:03 --> Config Class Initialized
INFO - 2025-04-11 20:34:03 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:34:03 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:34:03 --> Utf8 Class Initialized
INFO - 2025-04-11 20:34:03 --> URI Class Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:34:03 --> Router Class Initialized
INFO - 2025-04-11 20:34:03 --> Output Class Initialized
INFO - 2025-04-11 20:34:03 --> Security Class Initialized
DEBUG - 2025-04-11 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:34:03 --> Input Class Initialized
INFO - 2025-04-11 20:34:03 --> Language Class Initialized
INFO - 2025-04-11 20:34:03 --> Language Class Initialized
INFO - 2025-04-11 20:34:03 --> Config Class Initialized
INFO - 2025-04-11 20:34:03 --> Loader Class Initialized
INFO - 2025-04-11 20:34:03 --> Helper loaded: url_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: file_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: html_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: form_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: text_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:34:03 --> Database Driver Class Initialized
INFO - 2025-04-11 20:34:03 --> Email Class Initialized
INFO - 2025-04-11 20:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:34:03 --> Form Validation Class Initialized
INFO - 2025-04-11 20:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:34:03 --> Pagination Class Initialized
INFO - 2025-04-11 20:34:03 --> Controller Class Initialized
DEBUG - 2025-04-11 20:34:03 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:03 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-11 20:34:03 --> ✅ Proceeding with return_invoice_entry()
DEBUG - 2025-04-11 20:34:03 --> 📦 return_invoice_entry() returned Invoice ID: 3203403887
DEBUG - 2025-04-11 20:34:03 --> ⚙️ Web setting loaded: [{"is_autoapprove_v":"1"}]
DEBUG - 2025-04-11 20:34:03 --> ✅ Auto-approving return with ID: 3203403887
DEBUG - 2025-04-11 20:34:03 --> 🔁 autoapprove() called for invoice_id: 3203403887
DEBUG - 2025-04-11 20:34:03 --> 🧾 Found 1 vouchers to approve for invoice: 3203403887
DEBUG - 2025-04-11 20:34:03 --> 📝 Approving voucher: CV-51
DEBUG - 2025-04-11 20:34:03 --> 📥 acc_transaction insert: {"vid":"178","fyear":"1","VNo":"CV-51","Vtype":"CV","referenceNo":"3203403887","VDate":"2025-04-11","COAID":"1020101","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-11 20:34:03"}
DEBUG - 2025-04-11 20:34:03 --> 📥 acc_transaction insert: {"vid":"178","fyear":"1","VNo":"CV-51","Vtype":"CV","referenceNo":"3203403887","VDate":"2025-04-11","COAID":"3010301","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-11 20:34:03"}
DEBUG - 2025-04-11 20:34:03 --> ✅ Voucher approved: CV-51 | Result: true
INFO - 2025-04-11 20:34:03 --> Config Class Initialized
INFO - 2025-04-11 20:34:03 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:34:03 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:34:03 --> Utf8 Class Initialized
INFO - 2025-04-11 20:34:03 --> URI Class Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:34:03 --> Router Class Initialized
INFO - 2025-04-11 20:34:03 --> Output Class Initialized
INFO - 2025-04-11 20:34:03 --> Security Class Initialized
DEBUG - 2025-04-11 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:34:03 --> Input Class Initialized
INFO - 2025-04-11 20:34:03 --> Language Class Initialized
INFO - 2025-04-11 20:34:03 --> Language Class Initialized
INFO - 2025-04-11 20:34:03 --> Config Class Initialized
INFO - 2025-04-11 20:34:03 --> Loader Class Initialized
INFO - 2025-04-11 20:34:03 --> Helper loaded: url_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: file_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: html_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: form_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: text_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:34:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:34:03 --> Database Driver Class Initialized
INFO - 2025-04-11 20:34:03 --> Email Class Initialized
INFO - 2025-04-11 20:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:34:03 --> Form Validation Class Initialized
INFO - 2025-04-11 20:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:34:03 --> Pagination Class Initialized
INFO - 2025-04-11 20:34:03 --> Controller Class Initialized
DEBUG - 2025-04-11 20:34:03 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:34:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:34:03 --> Model Class Initialized
ERROR - 2025-04-11 20:34:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:34:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:34:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:34:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:34:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-11 20:34:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:34:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:34:04 --> Final output sent to browser
DEBUG - 2025-04-11 20:34:04 --> Total execution time: 0.1411
INFO - 2025-04-11 20:34:19 --> Config Class Initialized
INFO - 2025-04-11 20:34:19 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:34:19 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:34:19 --> Utf8 Class Initialized
INFO - 2025-04-11 20:34:19 --> URI Class Initialized
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-11 20:34:19 --> Router Class Initialized
INFO - 2025-04-11 20:34:19 --> Output Class Initialized
INFO - 2025-04-11 20:34:19 --> Security Class Initialized
DEBUG - 2025-04-11 20:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:34:19 --> Input Class Initialized
INFO - 2025-04-11 20:34:19 --> Language Class Initialized
INFO - 2025-04-11 20:34:19 --> Language Class Initialized
INFO - 2025-04-11 20:34:19 --> Config Class Initialized
INFO - 2025-04-11 20:34:19 --> Loader Class Initialized
INFO - 2025-04-11 20:34:19 --> Helper loaded: url_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: file_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: html_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: form_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: text_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:34:19 --> Database Driver Class Initialized
INFO - 2025-04-11 20:34:19 --> Email Class Initialized
INFO - 2025-04-11 20:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:34:19 --> Form Validation Class Initialized
INFO - 2025-04-11 20:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:34:19 --> Pagination Class Initialized
INFO - 2025-04-11 20:34:19 --> Controller Class Initialized
DEBUG - 2025-04-11 20:34:19 --> Report MX_Controller Initialized
INFO - 2025-04-11 20:34:19 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-11 20:34:19 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:34:19 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:34:19 --> Model Class Initialized
ERROR - 2025-04-11 20:34:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:34:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:34:19 --> Final output sent to browser
DEBUG - 2025-04-11 20:34:19 --> Total execution time: 0.1481
INFO - 2025-04-11 20:34:19 --> Config Class Initialized
INFO - 2025-04-11 20:34:19 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:34:19 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:34:19 --> Utf8 Class Initialized
INFO - 2025-04-11 20:34:19 --> URI Class Initialized
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-11 20:34:19 --> Router Class Initialized
INFO - 2025-04-11 20:34:19 --> Output Class Initialized
INFO - 2025-04-11 20:34:19 --> Security Class Initialized
DEBUG - 2025-04-11 20:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:34:19 --> Input Class Initialized
INFO - 2025-04-11 20:34:19 --> Language Class Initialized
INFO - 2025-04-11 20:34:19 --> Language Class Initialized
INFO - 2025-04-11 20:34:19 --> Config Class Initialized
INFO - 2025-04-11 20:34:19 --> Loader Class Initialized
INFO - 2025-04-11 20:34:19 --> Helper loaded: url_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: file_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: html_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: form_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: text_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:34:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:34:19 --> Database Driver Class Initialized
INFO - 2025-04-11 20:34:19 --> Email Class Initialized
INFO - 2025-04-11 20:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:34:19 --> Form Validation Class Initialized
INFO - 2025-04-11 20:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:34:19 --> Pagination Class Initialized
INFO - 2025-04-11 20:34:19 --> Controller Class Initialized
DEBUG - 2025-04-11 20:34:19 --> Report MX_Controller Initialized
INFO - 2025-04-11 20:34:19 --> Model Class Initialized
DEBUG - 2025-04-11 20:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-11 20:34:19 --> Model Class Initialized
INFO - 2025-04-11 20:34:19 --> Final output sent to browser
DEBUG - 2025-04-11 20:34:19 --> Total execution time: 0.0091
INFO - 2025-04-11 20:41:55 --> Config Class Initialized
INFO - 2025-04-11 20:41:55 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:41:55 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:41:55 --> Utf8 Class Initialized
INFO - 2025-04-11 20:41:55 --> URI Class Initialized
DEBUG - 2025-04-11 20:41:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:41:55 --> Router Class Initialized
INFO - 2025-04-11 20:41:55 --> Output Class Initialized
INFO - 2025-04-11 20:41:55 --> Security Class Initialized
DEBUG - 2025-04-11 20:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:41:55 --> Input Class Initialized
INFO - 2025-04-11 20:41:55 --> Language Class Initialized
INFO - 2025-04-11 20:41:55 --> Language Class Initialized
INFO - 2025-04-11 20:41:55 --> Config Class Initialized
INFO - 2025-04-11 20:41:55 --> Loader Class Initialized
INFO - 2025-04-11 20:41:55 --> Helper loaded: url_helper
INFO - 2025-04-11 20:41:55 --> Helper loaded: file_helper
INFO - 2025-04-11 20:41:55 --> Helper loaded: html_helper
INFO - 2025-04-11 20:41:55 --> Helper loaded: form_helper
INFO - 2025-04-11 20:41:55 --> Helper loaded: text_helper
INFO - 2025-04-11 20:41:55 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:41:55 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:41:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:41:55 --> Database Driver Class Initialized
INFO - 2025-04-11 20:41:55 --> Email Class Initialized
INFO - 2025-04-11 20:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:41:55 --> Form Validation Class Initialized
INFO - 2025-04-11 20:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:41:55 --> Pagination Class Initialized
INFO - 2025-04-11 20:41:55 --> Controller Class Initialized
DEBUG - 2025-04-11 20:41:55 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:41:55 --> Model Class Initialized
DEBUG - 2025-04-11 20:41:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:41:55 --> Model Class Initialized
DEBUG - 2025-04-11 20:41:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:41:55 --> Model Class Initialized
DEBUG - 2025-04-11 20:41:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:41:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:41:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:41:55 --> Model Class Initialized
ERROR - 2025-04-11 20:41:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:41:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:41:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:41:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:41:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:41:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:41:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-11 20:41:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:41:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:41:56 --> Final output sent to browser
DEBUG - 2025-04-11 20:41:56 --> Total execution time: 0.6059
INFO - 2025-04-11 20:41:58 --> Config Class Initialized
INFO - 2025-04-11 20:41:58 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:41:58 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:41:58 --> Utf8 Class Initialized
INFO - 2025-04-11 20:41:58 --> URI Class Initialized
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:41:58 --> Router Class Initialized
INFO - 2025-04-11 20:41:58 --> Output Class Initialized
INFO - 2025-04-11 20:41:58 --> Security Class Initialized
DEBUG - 2025-04-11 20:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:41:58 --> Input Class Initialized
INFO - 2025-04-11 20:41:58 --> Language Class Initialized
INFO - 2025-04-11 20:41:58 --> Language Class Initialized
INFO - 2025-04-11 20:41:58 --> Config Class Initialized
INFO - 2025-04-11 20:41:58 --> Loader Class Initialized
INFO - 2025-04-11 20:41:58 --> Helper loaded: url_helper
INFO - 2025-04-11 20:41:58 --> Helper loaded: file_helper
INFO - 2025-04-11 20:41:58 --> Helper loaded: html_helper
INFO - 2025-04-11 20:41:58 --> Helper loaded: form_helper
INFO - 2025-04-11 20:41:58 --> Helper loaded: text_helper
INFO - 2025-04-11 20:41:58 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:41:58 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:41:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:41:58 --> Database Driver Class Initialized
INFO - 2025-04-11 20:41:58 --> Email Class Initialized
INFO - 2025-04-11 20:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:41:58 --> Form Validation Class Initialized
INFO - 2025-04-11 20:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:41:58 --> Pagination Class Initialized
INFO - 2025-04-11 20:41:58 --> Controller Class Initialized
DEBUG - 2025-04-11 20:41:58 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:41:58 --> Model Class Initialized
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:41:58 --> Model Class Initialized
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:41:58 --> Model Class Initialized
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:41:58 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:41:58 --> Model Class Initialized
ERROR - 2025-04-11 20:41:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:41:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:41:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:41:58 --> Final output sent to browser
DEBUG - 2025-04-11 20:41:58 --> Total execution time: 0.2037
INFO - 2025-04-11 20:42:03 --> Config Class Initialized
INFO - 2025-04-11 20:42:03 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:42:03 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:42:03 --> Utf8 Class Initialized
INFO - 2025-04-11 20:42:03 --> URI Class Initialized
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:42:03 --> Router Class Initialized
INFO - 2025-04-11 20:42:03 --> Output Class Initialized
INFO - 2025-04-11 20:42:03 --> Security Class Initialized
DEBUG - 2025-04-11 20:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:42:03 --> Input Class Initialized
INFO - 2025-04-11 20:42:03 --> Language Class Initialized
INFO - 2025-04-11 20:42:03 --> Language Class Initialized
INFO - 2025-04-11 20:42:03 --> Config Class Initialized
INFO - 2025-04-11 20:42:03 --> Loader Class Initialized
INFO - 2025-04-11 20:42:03 --> Helper loaded: url_helper
INFO - 2025-04-11 20:42:03 --> Helper loaded: file_helper
INFO - 2025-04-11 20:42:03 --> Helper loaded: html_helper
INFO - 2025-04-11 20:42:03 --> Helper loaded: form_helper
INFO - 2025-04-11 20:42:03 --> Helper loaded: text_helper
INFO - 2025-04-11 20:42:03 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:42:03 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:42:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:42:03 --> Database Driver Class Initialized
INFO - 2025-04-11 20:42:03 --> Email Class Initialized
INFO - 2025-04-11 20:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:42:03 --> Form Validation Class Initialized
INFO - 2025-04-11 20:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:42:03 --> Pagination Class Initialized
INFO - 2025-04-11 20:42:03 --> Controller Class Initialized
DEBUG - 2025-04-11 20:42:03 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:42:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:42:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:42:03 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:42:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:42:03 --> Model Class Initialized
ERROR - 2025-04-11 20:42:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:42:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:42:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-11 20:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:42:04 --> Final output sent to browser
DEBUG - 2025-04-11 20:42:04 --> Total execution time: 0.1776
INFO - 2025-04-11 20:42:27 --> Config Class Initialized
INFO - 2025-04-11 20:42:27 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:42:27 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:42:27 --> Utf8 Class Initialized
INFO - 2025-04-11 20:42:27 --> URI Class Initialized
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:42:27 --> Router Class Initialized
INFO - 2025-04-11 20:42:27 --> Output Class Initialized
INFO - 2025-04-11 20:42:27 --> Security Class Initialized
DEBUG - 2025-04-11 20:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:42:27 --> Input Class Initialized
INFO - 2025-04-11 20:42:27 --> Language Class Initialized
INFO - 2025-04-11 20:42:27 --> Language Class Initialized
INFO - 2025-04-11 20:42:27 --> Config Class Initialized
INFO - 2025-04-11 20:42:27 --> Loader Class Initialized
INFO - 2025-04-11 20:42:27 --> Helper loaded: url_helper
INFO - 2025-04-11 20:42:27 --> Helper loaded: file_helper
INFO - 2025-04-11 20:42:27 --> Helper loaded: html_helper
INFO - 2025-04-11 20:42:27 --> Helper loaded: form_helper
INFO - 2025-04-11 20:42:27 --> Helper loaded: text_helper
INFO - 2025-04-11 20:42:27 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:42:27 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:42:27 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:42:27 --> Database Driver Class Initialized
INFO - 2025-04-11 20:42:27 --> Email Class Initialized
INFO - 2025-04-11 20:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:42:27 --> Form Validation Class Initialized
INFO - 2025-04-11 20:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:42:27 --> Pagination Class Initialized
INFO - 2025-04-11 20:42:27 --> Controller Class Initialized
DEBUG - 2025-04-11 20:42:27 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:42:27 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:42:27 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:42:27 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:42:27 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:42:27 --> Model Class Initialized
ERROR - 2025-04-11 20:42:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:42:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:42:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:42:27 --> Final output sent to browser
DEBUG - 2025-04-11 20:42:27 --> Total execution time: 0.1445
INFO - 2025-04-11 20:42:30 --> Config Class Initialized
INFO - 2025-04-11 20:42:30 --> Hooks Class Initialized
DEBUG - 2025-04-11 20:42:30 --> UTF-8 Support Enabled
INFO - 2025-04-11 20:42:30 --> Utf8 Class Initialized
INFO - 2025-04-11 20:42:30 --> URI Class Initialized
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-11 20:42:30 --> Router Class Initialized
INFO - 2025-04-11 20:42:30 --> Output Class Initialized
INFO - 2025-04-11 20:42:30 --> Security Class Initialized
DEBUG - 2025-04-11 20:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-11 20:42:30 --> Input Class Initialized
INFO - 2025-04-11 20:42:30 --> Language Class Initialized
INFO - 2025-04-11 20:42:30 --> Language Class Initialized
INFO - 2025-04-11 20:42:30 --> Config Class Initialized
INFO - 2025-04-11 20:42:30 --> Loader Class Initialized
INFO - 2025-04-11 20:42:30 --> Helper loaded: url_helper
INFO - 2025-04-11 20:42:30 --> Helper loaded: file_helper
INFO - 2025-04-11 20:42:30 --> Helper loaded: html_helper
INFO - 2025-04-11 20:42:30 --> Helper loaded: form_helper
INFO - 2025-04-11 20:42:30 --> Helper loaded: text_helper
INFO - 2025-04-11 20:42:30 --> Helper loaded: lang_helper
INFO - 2025-04-11 20:42:30 --> Helper loaded: directory_helper
INFO - 2025-04-11 20:42:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-11 20:42:30 --> Database Driver Class Initialized
INFO - 2025-04-11 20:42:30 --> Email Class Initialized
INFO - 2025-04-11 20:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-11 20:42:30 --> Form Validation Class Initialized
INFO - 2025-04-11 20:42:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-11 20:42:30 --> Pagination Class Initialized
INFO - 2025-04-11 20:42:30 --> Controller Class Initialized
DEBUG - 2025-04-11 20:42:30 --> Returns MX_Controller Initialized
INFO - 2025-04-11 20:42:30 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-11 20:42:30 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-11 20:42:30 --> Model Class Initialized
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-11 20:42:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-11 20:42:30 --> Model Class Initialized
ERROR - 2025-04-11 20:42:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-11 20:42:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-11 20:42:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-11 20:42:30 --> Final output sent to browser
DEBUG - 2025-04-11 20:42:30 --> Total execution time: 0.1682
