<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-20 18:17:16 --> Config Class Initialized
INFO - 2025-03-20 18:17:16 --> Hooks Class Initialized
DEBUG - 2025-03-20 18:17:16 --> UTF-8 Support Enabled
INFO - 2025-03-20 18:17:16 --> Utf8 Class Initialized
INFO - 2025-03-20 18:17:16 --> URI Class Initialized
DEBUG - 2025-03-20 18:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 18:17:16 --> Router Class Initialized
INFO - 2025-03-20 18:17:16 --> Output Class Initialized
INFO - 2025-03-20 18:17:16 --> Security Class Initialized
DEBUG - 2025-03-20 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 18:17:16 --> Input Class Initialized
INFO - 2025-03-20 18:17:16 --> Language Class Initialized
INFO - 2025-03-20 18:17:16 --> Language Class Initialized
INFO - 2025-03-20 18:17:16 --> Config Class Initialized
INFO - 2025-03-20 18:17:16 --> Loader Class Initialized
INFO - 2025-03-20 18:17:16 --> Helper loaded: url_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: file_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: html_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: form_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: text_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: lang_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: directory_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 18:17:16 --> Database Driver Class Initialized
INFO - 2025-03-20 18:17:16 --> Email Class Initialized
INFO - 2025-03-20 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 18:17:16 --> Form Validation Class Initialized
INFO - 2025-03-20 18:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 18:17:16 --> Pagination Class Initialized
INFO - 2025-03-20 18:17:16 --> Controller Class Initialized
DEBUG - 2025-03-20 18:17:16 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 18:17:16 --> Config Class Initialized
INFO - 2025-03-20 18:17:16 --> Hooks Class Initialized
DEBUG - 2025-03-20 18:17:16 --> UTF-8 Support Enabled
INFO - 2025-03-20 18:17:16 --> Utf8 Class Initialized
INFO - 2025-03-20 18:17:16 --> URI Class Initialized
DEBUG - 2025-03-20 18:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-20 18:17:16 --> Router Class Initialized
INFO - 2025-03-20 18:17:16 --> Output Class Initialized
INFO - 2025-03-20 18:17:16 --> Security Class Initialized
DEBUG - 2025-03-20 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 18:17:16 --> Input Class Initialized
INFO - 2025-03-20 18:17:16 --> Language Class Initialized
INFO - 2025-03-20 18:17:16 --> Language Class Initialized
INFO - 2025-03-20 18:17:16 --> Config Class Initialized
INFO - 2025-03-20 18:17:16 --> Loader Class Initialized
INFO - 2025-03-20 18:17:16 --> Helper loaded: url_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: file_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: html_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: form_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: text_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: lang_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: directory_helper
INFO - 2025-03-20 18:17:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 18:17:16 --> Database Driver Class Initialized
INFO - 2025-03-20 18:17:16 --> Email Class Initialized
INFO - 2025-03-20 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 18:17:16 --> Form Validation Class Initialized
INFO - 2025-03-20 18:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 18:17:16 --> Pagination Class Initialized
INFO - 2025-03-20 18:17:16 --> Controller Class Initialized
DEBUG - 2025-03-20 18:17:16 --> Auth MX_Controller Initialized
INFO - 2025-03-20 18:17:16 --> Model Class Initialized
DEBUG - 2025-03-20 18:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-20 18:17:16 --> Model Class Initialized
DEBUG - 2025-03-20 18:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 18:17:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 18:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 18:17:16 --> Model Class Initialized
DEBUG - 2025-03-20 18:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-20 18:17:16 --> Final output sent to browser
DEBUG - 2025-03-20 18:17:16 --> Total execution time: 0.0171
INFO - 2025-03-20 18:17:24 --> Config Class Initialized
INFO - 2025-03-20 18:17:24 --> Hooks Class Initialized
DEBUG - 2025-03-20 18:17:24 --> UTF-8 Support Enabled
INFO - 2025-03-20 18:17:24 --> Utf8 Class Initialized
INFO - 2025-03-20 18:17:24 --> URI Class Initialized
DEBUG - 2025-03-20 18:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-20 18:17:24 --> Router Class Initialized
INFO - 2025-03-20 18:17:24 --> Output Class Initialized
INFO - 2025-03-20 18:17:24 --> Security Class Initialized
DEBUG - 2025-03-20 18:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 18:17:24 --> Input Class Initialized
INFO - 2025-03-20 18:17:24 --> Language Class Initialized
INFO - 2025-03-20 18:17:24 --> Language Class Initialized
INFO - 2025-03-20 18:17:24 --> Config Class Initialized
INFO - 2025-03-20 18:17:24 --> Loader Class Initialized
INFO - 2025-03-20 18:17:24 --> Helper loaded: url_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: file_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: html_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: form_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: text_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: lang_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: directory_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 18:17:24 --> Database Driver Class Initialized
INFO - 2025-03-20 18:17:24 --> Email Class Initialized
INFO - 2025-03-20 18:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 18:17:24 --> Form Validation Class Initialized
INFO - 2025-03-20 18:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 18:17:24 --> Pagination Class Initialized
INFO - 2025-03-20 18:17:24 --> Controller Class Initialized
DEBUG - 2025-03-20 18:17:24 --> Auth MX_Controller Initialized
INFO - 2025-03-20 18:17:24 --> Model Class Initialized
DEBUG - 2025-03-20 18:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-20 18:17:24 --> Model Class Initialized
INFO - 2025-03-20 18:17:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-20 18:17:24 --> Config Class Initialized
INFO - 2025-03-20 18:17:24 --> Hooks Class Initialized
DEBUG - 2025-03-20 18:17:24 --> UTF-8 Support Enabled
INFO - 2025-03-20 18:17:24 --> Utf8 Class Initialized
INFO - 2025-03-20 18:17:24 --> URI Class Initialized
DEBUG - 2025-03-20 18:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-20 18:17:24 --> Router Class Initialized
INFO - 2025-03-20 18:17:24 --> Output Class Initialized
INFO - 2025-03-20 18:17:24 --> Security Class Initialized
DEBUG - 2025-03-20 18:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 18:17:24 --> Input Class Initialized
INFO - 2025-03-20 18:17:24 --> Language Class Initialized
INFO - 2025-03-20 18:17:24 --> Language Class Initialized
INFO - 2025-03-20 18:17:24 --> Config Class Initialized
INFO - 2025-03-20 18:17:24 --> Loader Class Initialized
INFO - 2025-03-20 18:17:24 --> Helper loaded: url_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: file_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: html_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: form_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: text_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: lang_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: directory_helper
INFO - 2025-03-20 18:17:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 18:17:24 --> Database Driver Class Initialized
INFO - 2025-03-20 18:17:24 --> Email Class Initialized
INFO - 2025-03-20 18:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 18:17:24 --> Form Validation Class Initialized
INFO - 2025-03-20 18:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 18:17:24 --> Pagination Class Initialized
INFO - 2025-03-20 18:17:24 --> Controller Class Initialized
DEBUG - 2025-03-20 18:17:24 --> Home MX_Controller Initialized
INFO - 2025-03-20 18:17:24 --> Model Class Initialized
DEBUG - 2025-03-20 18:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-20 18:17:24 --> Model Class Initialized
DEBUG - 2025-03-20 18:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 18:17:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 18:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 18:17:24 --> Model Class Initialized
ERROR - 2025-03-20 18:17:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 18:17:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 18:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 18:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 18:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 18:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 18:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-20 18:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 18:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 18:17:25 --> Final output sent to browser
DEBUG - 2025-03-20 18:17:25 --> Total execution time: 0.8115
INFO - 2025-03-20 18:17:30 --> Config Class Initialized
INFO - 2025-03-20 18:17:30 --> Hooks Class Initialized
DEBUG - 2025-03-20 18:17:30 --> UTF-8 Support Enabled
INFO - 2025-03-20 18:17:30 --> Utf8 Class Initialized
INFO - 2025-03-20 18:17:30 --> URI Class Initialized
DEBUG - 2025-03-20 18:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 18:17:30 --> Router Class Initialized
INFO - 2025-03-20 18:17:30 --> Output Class Initialized
INFO - 2025-03-20 18:17:30 --> Security Class Initialized
DEBUG - 2025-03-20 18:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 18:17:30 --> Input Class Initialized
INFO - 2025-03-20 18:17:30 --> Language Class Initialized
INFO - 2025-03-20 18:17:30 --> Language Class Initialized
INFO - 2025-03-20 18:17:30 --> Config Class Initialized
INFO - 2025-03-20 18:17:30 --> Loader Class Initialized
INFO - 2025-03-20 18:17:30 --> Helper loaded: url_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: file_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: html_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: form_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: text_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: lang_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: directory_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 18:17:30 --> Database Driver Class Initialized
INFO - 2025-03-20 18:17:30 --> Email Class Initialized
INFO - 2025-03-20 18:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 18:17:30 --> Form Validation Class Initialized
INFO - 2025-03-20 18:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 18:17:30 --> Pagination Class Initialized
INFO - 2025-03-20 18:17:30 --> Controller Class Initialized
DEBUG - 2025-03-20 18:17:30 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 18:17:30 --> Config Class Initialized
INFO - 2025-03-20 18:17:30 --> Hooks Class Initialized
DEBUG - 2025-03-20 18:17:30 --> UTF-8 Support Enabled
INFO - 2025-03-20 18:17:30 --> Utf8 Class Initialized
INFO - 2025-03-20 18:17:30 --> URI Class Initialized
DEBUG - 2025-03-20 18:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 18:17:30 --> Router Class Initialized
INFO - 2025-03-20 18:17:30 --> Output Class Initialized
INFO - 2025-03-20 18:17:30 --> Security Class Initialized
DEBUG - 2025-03-20 18:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 18:17:30 --> Input Class Initialized
INFO - 2025-03-20 18:17:30 --> Language Class Initialized
INFO - 2025-03-20 18:17:30 --> Language Class Initialized
INFO - 2025-03-20 18:17:30 --> Config Class Initialized
INFO - 2025-03-20 18:17:30 --> Loader Class Initialized
INFO - 2025-03-20 18:17:30 --> Helper loaded: url_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: file_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: html_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: form_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: text_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: lang_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: directory_helper
INFO - 2025-03-20 18:17:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 18:17:30 --> Database Driver Class Initialized
INFO - 2025-03-20 18:17:30 --> Email Class Initialized
INFO - 2025-03-20 18:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 18:17:30 --> Form Validation Class Initialized
INFO - 2025-03-20 18:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 18:17:30 --> Pagination Class Initialized
INFO - 2025-03-20 18:17:30 --> Controller Class Initialized
DEBUG - 2025-03-20 18:17:30 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 19:46:30 --> Config Class Initialized
INFO - 2025-03-20 19:46:30 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:46:30 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:46:30 --> Utf8 Class Initialized
INFO - 2025-03-20 19:46:30 --> URI Class Initialized
DEBUG - 2025-03-20 19:46:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:46:30 --> Router Class Initialized
INFO - 2025-03-20 19:46:30 --> Output Class Initialized
INFO - 2025-03-20 19:46:30 --> Security Class Initialized
DEBUG - 2025-03-20 19:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:46:30 --> Input Class Initialized
INFO - 2025-03-20 19:46:30 --> Language Class Initialized
INFO - 2025-03-20 19:46:30 --> Language Class Initialized
INFO - 2025-03-20 19:46:30 --> Config Class Initialized
INFO - 2025-03-20 19:46:30 --> Loader Class Initialized
INFO - 2025-03-20 19:46:30 --> Helper loaded: url_helper
INFO - 2025-03-20 19:46:30 --> Helper loaded: file_helper
INFO - 2025-03-20 19:46:30 --> Helper loaded: html_helper
INFO - 2025-03-20 19:46:30 --> Helper loaded: form_helper
INFO - 2025-03-20 19:46:30 --> Helper loaded: text_helper
INFO - 2025-03-20 19:46:30 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:46:30 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:46:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:46:30 --> Database Driver Class Initialized
INFO - 2025-03-20 19:46:30 --> Email Class Initialized
INFO - 2025-03-20 19:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:46:30 --> Form Validation Class Initialized
INFO - 2025-03-20 19:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:46:30 --> Pagination Class Initialized
INFO - 2025-03-20 19:46:30 --> Controller Class Initialized
DEBUG - 2025-03-20 19:46:30 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:46:30 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:46:30 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:46:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:46:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:46:30 --> Model Class Initialized
ERROR - 2025-03-20 19:46:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:46:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:46:31 --> Final output sent to browser
DEBUG - 2025-03-20 19:46:31 --> Total execution time: 0.6668
INFO - 2025-03-20 19:46:31 --> Config Class Initialized
INFO - 2025-03-20 19:46:31 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:46:31 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:46:31 --> Utf8 Class Initialized
INFO - 2025-03-20 19:46:31 --> URI Class Initialized
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:46:31 --> Router Class Initialized
INFO - 2025-03-20 19:46:31 --> Output Class Initialized
INFO - 2025-03-20 19:46:31 --> Security Class Initialized
DEBUG - 2025-03-20 19:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:46:31 --> Input Class Initialized
INFO - 2025-03-20 19:46:31 --> Language Class Initialized
INFO - 2025-03-20 19:46:31 --> Language Class Initialized
INFO - 2025-03-20 19:46:31 --> Config Class Initialized
INFO - 2025-03-20 19:46:31 --> Loader Class Initialized
INFO - 2025-03-20 19:46:31 --> Helper loaded: url_helper
INFO - 2025-03-20 19:46:31 --> Helper loaded: file_helper
INFO - 2025-03-20 19:46:31 --> Helper loaded: html_helper
INFO - 2025-03-20 19:46:31 --> Helper loaded: form_helper
INFO - 2025-03-20 19:46:31 --> Helper loaded: text_helper
INFO - 2025-03-20 19:46:31 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:46:31 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:46:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:46:31 --> Database Driver Class Initialized
INFO - 2025-03-20 19:46:31 --> Email Class Initialized
INFO - 2025-03-20 19:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:46:31 --> Form Validation Class Initialized
INFO - 2025-03-20 19:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:46:31 --> Pagination Class Initialized
INFO - 2025-03-20 19:46:31 --> Controller Class Initialized
DEBUG - 2025-03-20 19:46:31 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:46:31 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:46:31 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:46:31 --> Model Class Initialized
INFO - 2025-03-20 19:46:31 --> Final output sent to browser
DEBUG - 2025-03-20 19:46:31 --> Total execution time: 0.0099
INFO - 2025-03-20 19:46:34 --> Config Class Initialized
INFO - 2025-03-20 19:46:34 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:46:34 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:46:34 --> Utf8 Class Initialized
INFO - 2025-03-20 19:46:34 --> URI Class Initialized
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:46:34 --> Router Class Initialized
INFO - 2025-03-20 19:46:34 --> Output Class Initialized
INFO - 2025-03-20 19:46:34 --> Security Class Initialized
DEBUG - 2025-03-20 19:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:46:34 --> Input Class Initialized
INFO - 2025-03-20 19:46:34 --> Language Class Initialized
INFO - 2025-03-20 19:46:34 --> Language Class Initialized
INFO - 2025-03-20 19:46:34 --> Config Class Initialized
INFO - 2025-03-20 19:46:34 --> Loader Class Initialized
INFO - 2025-03-20 19:46:34 --> Helper loaded: url_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: file_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: html_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: form_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: text_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:46:34 --> Database Driver Class Initialized
INFO - 2025-03-20 19:46:34 --> Email Class Initialized
INFO - 2025-03-20 19:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:46:34 --> Form Validation Class Initialized
INFO - 2025-03-20 19:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:46:34 --> Pagination Class Initialized
INFO - 2025-03-20 19:46:34 --> Controller Class Initialized
DEBUG - 2025-03-20 19:46:34 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:46:34 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:46:34 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:46:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:46:34 --> Model Class Initialized
ERROR - 2025-03-20 19:46:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:46:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:46:34 --> Final output sent to browser
DEBUG - 2025-03-20 19:46:34 --> Total execution time: 0.1379
INFO - 2025-03-20 19:46:34 --> Config Class Initialized
INFO - 2025-03-20 19:46:34 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:46:34 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:46:34 --> Utf8 Class Initialized
INFO - 2025-03-20 19:46:34 --> URI Class Initialized
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:46:34 --> Router Class Initialized
INFO - 2025-03-20 19:46:34 --> Output Class Initialized
INFO - 2025-03-20 19:46:34 --> Security Class Initialized
DEBUG - 2025-03-20 19:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:46:34 --> Input Class Initialized
INFO - 2025-03-20 19:46:34 --> Language Class Initialized
INFO - 2025-03-20 19:46:34 --> Language Class Initialized
INFO - 2025-03-20 19:46:34 --> Config Class Initialized
INFO - 2025-03-20 19:46:34 --> Loader Class Initialized
INFO - 2025-03-20 19:46:34 --> Helper loaded: url_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: file_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: html_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: form_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: text_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:46:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:46:34 --> Database Driver Class Initialized
INFO - 2025-03-20 19:46:34 --> Email Class Initialized
INFO - 2025-03-20 19:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:46:34 --> Form Validation Class Initialized
INFO - 2025-03-20 19:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:46:34 --> Pagination Class Initialized
INFO - 2025-03-20 19:46:34 --> Controller Class Initialized
DEBUG - 2025-03-20 19:46:34 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:46:34 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:46:34 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:46:34 --> Model Class Initialized
INFO - 2025-03-20 19:46:34 --> Final output sent to browser
DEBUG - 2025-03-20 19:46:34 --> Total execution time: 0.0104
INFO - 2025-03-20 19:46:49 --> Config Class Initialized
INFO - 2025-03-20 19:46:49 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:46:49 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:46:49 --> Utf8 Class Initialized
INFO - 2025-03-20 19:46:49 --> URI Class Initialized
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:46:49 --> Router Class Initialized
INFO - 2025-03-20 19:46:49 --> Output Class Initialized
INFO - 2025-03-20 19:46:49 --> Security Class Initialized
DEBUG - 2025-03-20 19:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:46:49 --> Input Class Initialized
INFO - 2025-03-20 19:46:49 --> Language Class Initialized
INFO - 2025-03-20 19:46:49 --> Language Class Initialized
INFO - 2025-03-20 19:46:49 --> Config Class Initialized
INFO - 2025-03-20 19:46:49 --> Loader Class Initialized
INFO - 2025-03-20 19:46:49 --> Helper loaded: url_helper
INFO - 2025-03-20 19:46:49 --> Helper loaded: file_helper
INFO - 2025-03-20 19:46:49 --> Helper loaded: html_helper
INFO - 2025-03-20 19:46:49 --> Helper loaded: form_helper
INFO - 2025-03-20 19:46:49 --> Helper loaded: text_helper
INFO - 2025-03-20 19:46:49 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:46:49 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:46:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:46:49 --> Database Driver Class Initialized
INFO - 2025-03-20 19:46:49 --> Email Class Initialized
INFO - 2025-03-20 19:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:46:49 --> Form Validation Class Initialized
INFO - 2025-03-20 19:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:46:49 --> Pagination Class Initialized
INFO - 2025-03-20 19:46:49 --> Controller Class Initialized
DEBUG - 2025-03-20 19:46:49 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:46:49 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:46:49 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:46:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:46:49 --> Model Class Initialized
ERROR - 2025-03-20 19:46:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:46:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:46:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:46:49 --> Final output sent to browser
DEBUG - 2025-03-20 19:46:49 --> Total execution time: 0.1754
INFO - 2025-03-20 19:46:50 --> Config Class Initialized
INFO - 2025-03-20 19:46:50 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:46:50 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:46:50 --> Utf8 Class Initialized
INFO - 2025-03-20 19:46:50 --> URI Class Initialized
DEBUG - 2025-03-20 19:46:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:46:50 --> Router Class Initialized
INFO - 2025-03-20 19:46:50 --> Output Class Initialized
INFO - 2025-03-20 19:46:50 --> Security Class Initialized
DEBUG - 2025-03-20 19:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:46:50 --> Input Class Initialized
INFO - 2025-03-20 19:46:50 --> Language Class Initialized
INFO - 2025-03-20 19:46:50 --> Language Class Initialized
INFO - 2025-03-20 19:46:50 --> Config Class Initialized
INFO - 2025-03-20 19:46:50 --> Loader Class Initialized
INFO - 2025-03-20 19:46:50 --> Helper loaded: url_helper
INFO - 2025-03-20 19:46:50 --> Helper loaded: file_helper
INFO - 2025-03-20 19:46:50 --> Helper loaded: html_helper
INFO - 2025-03-20 19:46:50 --> Helper loaded: form_helper
INFO - 2025-03-20 19:46:50 --> Helper loaded: text_helper
INFO - 2025-03-20 19:46:50 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:46:50 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:46:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:46:50 --> Database Driver Class Initialized
INFO - 2025-03-20 19:46:50 --> Email Class Initialized
INFO - 2025-03-20 19:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:46:50 --> Form Validation Class Initialized
INFO - 2025-03-20 19:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:46:50 --> Pagination Class Initialized
INFO - 2025-03-20 19:46:50 --> Controller Class Initialized
DEBUG - 2025-03-20 19:46:50 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:46:50 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:46:50 --> Model Class Initialized
DEBUG - 2025-03-20 19:46:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:46:50 --> Model Class Initialized
INFO - 2025-03-20 19:46:50 --> Final output sent to browser
DEBUG - 2025-03-20 19:46:50 --> Total execution time: 0.0080
INFO - 2025-03-20 19:47:16 --> Config Class Initialized
INFO - 2025-03-20 19:47:16 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:47:16 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:47:16 --> Utf8 Class Initialized
INFO - 2025-03-20 19:47:16 --> URI Class Initialized
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:47:16 --> Router Class Initialized
INFO - 2025-03-20 19:47:16 --> Output Class Initialized
INFO - 2025-03-20 19:47:16 --> Security Class Initialized
DEBUG - 2025-03-20 19:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:47:16 --> Input Class Initialized
INFO - 2025-03-20 19:47:16 --> Language Class Initialized
INFO - 2025-03-20 19:47:16 --> Language Class Initialized
INFO - 2025-03-20 19:47:16 --> Config Class Initialized
INFO - 2025-03-20 19:47:16 --> Loader Class Initialized
INFO - 2025-03-20 19:47:16 --> Helper loaded: url_helper
INFO - 2025-03-20 19:47:16 --> Helper loaded: file_helper
INFO - 2025-03-20 19:47:16 --> Helper loaded: html_helper
INFO - 2025-03-20 19:47:16 --> Helper loaded: form_helper
INFO - 2025-03-20 19:47:16 --> Helper loaded: text_helper
INFO - 2025-03-20 19:47:16 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:47:16 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:47:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:47:16 --> Database Driver Class Initialized
INFO - 2025-03-20 19:47:16 --> Email Class Initialized
INFO - 2025-03-20 19:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:47:16 --> Form Validation Class Initialized
INFO - 2025-03-20 19:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:47:16 --> Pagination Class Initialized
INFO - 2025-03-20 19:47:16 --> Controller Class Initialized
DEBUG - 2025-03-20 19:47:16 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:47:16 --> Model Class Initialized
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:47:16 --> Model Class Initialized
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:47:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:47:16 --> Model Class Initialized
ERROR - 2025-03-20 19:47:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:47:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:47:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:47:16 --> Final output sent to browser
DEBUG - 2025-03-20 19:47:16 --> Total execution time: 0.1541
INFO - 2025-03-20 19:47:17 --> Config Class Initialized
INFO - 2025-03-20 19:47:17 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:47:17 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:47:17 --> Utf8 Class Initialized
INFO - 2025-03-20 19:47:17 --> URI Class Initialized
DEBUG - 2025-03-20 19:47:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:47:17 --> Router Class Initialized
INFO - 2025-03-20 19:47:17 --> Output Class Initialized
INFO - 2025-03-20 19:47:17 --> Security Class Initialized
DEBUG - 2025-03-20 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:47:17 --> Input Class Initialized
INFO - 2025-03-20 19:47:17 --> Language Class Initialized
INFO - 2025-03-20 19:47:17 --> Language Class Initialized
INFO - 2025-03-20 19:47:17 --> Config Class Initialized
INFO - 2025-03-20 19:47:17 --> Loader Class Initialized
INFO - 2025-03-20 19:47:17 --> Helper loaded: url_helper
INFO - 2025-03-20 19:47:17 --> Helper loaded: file_helper
INFO - 2025-03-20 19:47:17 --> Helper loaded: html_helper
INFO - 2025-03-20 19:47:17 --> Helper loaded: form_helper
INFO - 2025-03-20 19:47:17 --> Helper loaded: text_helper
INFO - 2025-03-20 19:47:17 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:47:17 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:47:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:47:17 --> Database Driver Class Initialized
INFO - 2025-03-20 19:47:17 --> Email Class Initialized
INFO - 2025-03-20 19:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:47:17 --> Form Validation Class Initialized
INFO - 2025-03-20 19:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:47:17 --> Pagination Class Initialized
INFO - 2025-03-20 19:47:17 --> Controller Class Initialized
DEBUG - 2025-03-20 19:47:17 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:47:17 --> Model Class Initialized
DEBUG - 2025-03-20 19:47:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:47:17 --> Model Class Initialized
DEBUG - 2025-03-20 19:47:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:47:17 --> Model Class Initialized
INFO - 2025-03-20 19:47:17 --> Final output sent to browser
DEBUG - 2025-03-20 19:47:17 --> Total execution time: 0.0082
INFO - 2025-03-20 19:47:25 --> Config Class Initialized
INFO - 2025-03-20 19:47:25 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:47:25 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:47:25 --> Utf8 Class Initialized
INFO - 2025-03-20 19:47:25 --> URI Class Initialized
DEBUG - 2025-03-20 19:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:47:25 --> Router Class Initialized
INFO - 2025-03-20 19:47:25 --> Output Class Initialized
INFO - 2025-03-20 19:47:25 --> Security Class Initialized
DEBUG - 2025-03-20 19:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:47:25 --> Input Class Initialized
INFO - 2025-03-20 19:47:25 --> Language Class Initialized
INFO - 2025-03-20 19:47:25 --> Language Class Initialized
INFO - 2025-03-20 19:47:25 --> Config Class Initialized
INFO - 2025-03-20 19:47:25 --> Loader Class Initialized
INFO - 2025-03-20 19:47:25 --> Helper loaded: url_helper
INFO - 2025-03-20 19:47:25 --> Helper loaded: file_helper
INFO - 2025-03-20 19:47:25 --> Helper loaded: html_helper
INFO - 2025-03-20 19:47:25 --> Helper loaded: form_helper
INFO - 2025-03-20 19:47:25 --> Helper loaded: text_helper
INFO - 2025-03-20 19:47:25 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:47:25 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:47:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:47:25 --> Database Driver Class Initialized
INFO - 2025-03-20 19:47:25 --> Email Class Initialized
INFO - 2025-03-20 19:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:47:25 --> Form Validation Class Initialized
INFO - 2025-03-20 19:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:47:25 --> Pagination Class Initialized
INFO - 2025-03-20 19:47:25 --> Controller Class Initialized
DEBUG - 2025-03-20 19:47:25 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:47:25 --> Model Class Initialized
DEBUG - 2025-03-20 19:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:47:25 --> Model Class Initialized
DEBUG - 2025-03-20 19:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:47:25 --> Model Class Initialized
INFO - 2025-03-20 19:47:25 --> Final output sent to browser
DEBUG - 2025-03-20 19:47:25 --> Total execution time: 0.0111
INFO - 2025-03-20 19:49:02 --> Config Class Initialized
INFO - 2025-03-20 19:49:02 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:49:02 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:49:02 --> Utf8 Class Initialized
INFO - 2025-03-20 19:49:02 --> URI Class Initialized
DEBUG - 2025-03-20 19:49:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:49:02 --> Router Class Initialized
INFO - 2025-03-20 19:49:02 --> Output Class Initialized
INFO - 2025-03-20 19:49:02 --> Security Class Initialized
DEBUG - 2025-03-20 19:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:49:02 --> Input Class Initialized
INFO - 2025-03-20 19:49:02 --> Language Class Initialized
INFO - 2025-03-20 19:49:02 --> Language Class Initialized
INFO - 2025-03-20 19:49:02 --> Config Class Initialized
INFO - 2025-03-20 19:49:02 --> Loader Class Initialized
INFO - 2025-03-20 19:49:02 --> Helper loaded: url_helper
INFO - 2025-03-20 19:49:02 --> Helper loaded: file_helper
INFO - 2025-03-20 19:49:02 --> Helper loaded: html_helper
INFO - 2025-03-20 19:49:02 --> Helper loaded: form_helper
INFO - 2025-03-20 19:49:02 --> Helper loaded: text_helper
INFO - 2025-03-20 19:49:02 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:49:02 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:49:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:49:02 --> Database Driver Class Initialized
INFO - 2025-03-20 19:49:02 --> Email Class Initialized
INFO - 2025-03-20 19:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:49:02 --> Form Validation Class Initialized
INFO - 2025-03-20 19:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:49:02 --> Pagination Class Initialized
INFO - 2025-03-20 19:49:02 --> Controller Class Initialized
DEBUG - 2025-03-20 19:49:02 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:49:02 --> Model Class Initialized
DEBUG - 2025-03-20 19:49:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:49:02 --> Model Class Initialized
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:49:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:49:03 --> Model Class Initialized
ERROR - 2025-03-20 19:49:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:49:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:49:03 --> Final output sent to browser
DEBUG - 2025-03-20 19:49:03 --> Total execution time: 0.1173
INFO - 2025-03-20 19:50:28 --> Config Class Initialized
INFO - 2025-03-20 19:50:28 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:50:28 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:50:28 --> Utf8 Class Initialized
INFO - 2025-03-20 19:50:28 --> URI Class Initialized
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:50:28 --> Router Class Initialized
INFO - 2025-03-20 19:50:28 --> Output Class Initialized
INFO - 2025-03-20 19:50:28 --> Security Class Initialized
DEBUG - 2025-03-20 19:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:50:28 --> Input Class Initialized
INFO - 2025-03-20 19:50:28 --> Language Class Initialized
INFO - 2025-03-20 19:50:28 --> Language Class Initialized
INFO - 2025-03-20 19:50:28 --> Config Class Initialized
INFO - 2025-03-20 19:50:28 --> Loader Class Initialized
INFO - 2025-03-20 19:50:28 --> Helper loaded: url_helper
INFO - 2025-03-20 19:50:28 --> Helper loaded: file_helper
INFO - 2025-03-20 19:50:28 --> Helper loaded: html_helper
INFO - 2025-03-20 19:50:28 --> Helper loaded: form_helper
INFO - 2025-03-20 19:50:28 --> Helper loaded: text_helper
INFO - 2025-03-20 19:50:28 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:50:28 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:50:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:50:28 --> Database Driver Class Initialized
INFO - 2025-03-20 19:50:28 --> Email Class Initialized
INFO - 2025-03-20 19:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:50:28 --> Form Validation Class Initialized
INFO - 2025-03-20 19:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:50:28 --> Pagination Class Initialized
INFO - 2025-03-20 19:50:28 --> Controller Class Initialized
DEBUG - 2025-03-20 19:50:28 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:50:28 --> Model Class Initialized
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:50:28 --> Model Class Initialized
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:50:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:50:28 --> Model Class Initialized
ERROR - 2025-03-20 19:50:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:50:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:50:28 --> Final output sent to browser
DEBUG - 2025-03-20 19:50:28 --> Total execution time: 0.1398
INFO - 2025-03-20 19:51:12 --> Config Class Initialized
INFO - 2025-03-20 19:51:12 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:51:12 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:51:12 --> Utf8 Class Initialized
INFO - 2025-03-20 19:51:12 --> URI Class Initialized
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:51:12 --> Router Class Initialized
INFO - 2025-03-20 19:51:12 --> Output Class Initialized
INFO - 2025-03-20 19:51:12 --> Security Class Initialized
DEBUG - 2025-03-20 19:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:51:12 --> Input Class Initialized
INFO - 2025-03-20 19:51:12 --> Language Class Initialized
INFO - 2025-03-20 19:51:12 --> Language Class Initialized
INFO - 2025-03-20 19:51:12 --> Config Class Initialized
INFO - 2025-03-20 19:51:12 --> Loader Class Initialized
INFO - 2025-03-20 19:51:12 --> Helper loaded: url_helper
INFO - 2025-03-20 19:51:12 --> Helper loaded: file_helper
INFO - 2025-03-20 19:51:12 --> Helper loaded: html_helper
INFO - 2025-03-20 19:51:12 --> Helper loaded: form_helper
INFO - 2025-03-20 19:51:12 --> Helper loaded: text_helper
INFO - 2025-03-20 19:51:12 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:51:12 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:51:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:51:12 --> Database Driver Class Initialized
INFO - 2025-03-20 19:51:12 --> Email Class Initialized
INFO - 2025-03-20 19:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:51:12 --> Form Validation Class Initialized
INFO - 2025-03-20 19:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:51:12 --> Pagination Class Initialized
INFO - 2025-03-20 19:51:12 --> Controller Class Initialized
DEBUG - 2025-03-20 19:51:12 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:51:12 --> Model Class Initialized
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:51:12 --> Model Class Initialized
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:51:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:51:12 --> Model Class Initialized
ERROR - 2025-03-20 19:51:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:51:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:51:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:51:12 --> Final output sent to browser
DEBUG - 2025-03-20 19:51:12 --> Total execution time: 0.1339
INFO - 2025-03-20 19:51:26 --> Config Class Initialized
INFO - 2025-03-20 19:51:26 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:51:26 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:51:26 --> Utf8 Class Initialized
INFO - 2025-03-20 19:51:26 --> URI Class Initialized
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:51:26 --> Router Class Initialized
INFO - 2025-03-20 19:51:26 --> Output Class Initialized
INFO - 2025-03-20 19:51:26 --> Security Class Initialized
DEBUG - 2025-03-20 19:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:51:26 --> Input Class Initialized
INFO - 2025-03-20 19:51:26 --> Language Class Initialized
INFO - 2025-03-20 19:51:26 --> Language Class Initialized
INFO - 2025-03-20 19:51:26 --> Config Class Initialized
INFO - 2025-03-20 19:51:26 --> Loader Class Initialized
INFO - 2025-03-20 19:51:26 --> Helper loaded: url_helper
INFO - 2025-03-20 19:51:26 --> Helper loaded: file_helper
INFO - 2025-03-20 19:51:26 --> Helper loaded: html_helper
INFO - 2025-03-20 19:51:26 --> Helper loaded: form_helper
INFO - 2025-03-20 19:51:26 --> Helper loaded: text_helper
INFO - 2025-03-20 19:51:26 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:51:26 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:51:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:51:26 --> Database Driver Class Initialized
INFO - 2025-03-20 19:51:26 --> Email Class Initialized
INFO - 2025-03-20 19:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:51:26 --> Form Validation Class Initialized
INFO - 2025-03-20 19:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:51:26 --> Pagination Class Initialized
INFO - 2025-03-20 19:51:26 --> Controller Class Initialized
DEBUG - 2025-03-20 19:51:26 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:51:26 --> Model Class Initialized
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:51:26 --> Model Class Initialized
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:51:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:51:26 --> Model Class Initialized
ERROR - 2025-03-20 19:51:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:51:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:51:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:51:26 --> Final output sent to browser
DEBUG - 2025-03-20 19:51:26 --> Total execution time: 0.1391
INFO - 2025-03-20 19:52:27 --> Config Class Initialized
INFO - 2025-03-20 19:52:27 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:52:27 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:52:27 --> Utf8 Class Initialized
INFO - 2025-03-20 19:52:27 --> URI Class Initialized
DEBUG - 2025-03-20 19:52:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:52:27 --> Router Class Initialized
INFO - 2025-03-20 19:52:27 --> Output Class Initialized
INFO - 2025-03-20 19:52:27 --> Security Class Initialized
DEBUG - 2025-03-20 19:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:52:27 --> Input Class Initialized
INFO - 2025-03-20 19:52:27 --> Language Class Initialized
INFO - 2025-03-20 19:52:27 --> Language Class Initialized
INFO - 2025-03-20 19:52:27 --> Config Class Initialized
INFO - 2025-03-20 19:52:27 --> Loader Class Initialized
INFO - 2025-03-20 19:52:27 --> Helper loaded: url_helper
INFO - 2025-03-20 19:52:27 --> Helper loaded: file_helper
INFO - 2025-03-20 19:52:27 --> Helper loaded: html_helper
INFO - 2025-03-20 19:52:27 --> Helper loaded: form_helper
INFO - 2025-03-20 19:52:27 --> Helper loaded: text_helper
INFO - 2025-03-20 19:52:27 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:52:27 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:52:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:52:27 --> Database Driver Class Initialized
INFO - 2025-03-20 19:52:27 --> Email Class Initialized
INFO - 2025-03-20 19:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:52:27 --> Form Validation Class Initialized
INFO - 2025-03-20 19:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:52:27 --> Pagination Class Initialized
INFO - 2025-03-20 19:52:27 --> Controller Class Initialized
DEBUG - 2025-03-20 19:52:27 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:52:27 --> Model Class Initialized
DEBUG - 2025-03-20 19:52:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:52:27 --> Model Class Initialized
DEBUG - 2025-03-20 19:52:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:52:27 --> Model Class Initialized
INFO - 2025-03-20 19:52:27 --> Final output sent to browser
DEBUG - 2025-03-20 19:52:27 --> Total execution time: 0.0276
INFO - 2025-03-20 19:56:28 --> Config Class Initialized
INFO - 2025-03-20 19:56:28 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:56:28 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:56:28 --> Utf8 Class Initialized
INFO - 2025-03-20 19:56:28 --> URI Class Initialized
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:56:28 --> Router Class Initialized
INFO - 2025-03-20 19:56:28 --> Output Class Initialized
INFO - 2025-03-20 19:56:28 --> Security Class Initialized
DEBUG - 2025-03-20 19:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:56:28 --> Input Class Initialized
INFO - 2025-03-20 19:56:28 --> Language Class Initialized
INFO - 2025-03-20 19:56:28 --> Language Class Initialized
INFO - 2025-03-20 19:56:28 --> Config Class Initialized
INFO - 2025-03-20 19:56:28 --> Loader Class Initialized
INFO - 2025-03-20 19:56:28 --> Helper loaded: url_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: file_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: html_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: form_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: text_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:56:28 --> Database Driver Class Initialized
INFO - 2025-03-20 19:56:28 --> Email Class Initialized
INFO - 2025-03-20 19:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:56:28 --> Form Validation Class Initialized
INFO - 2025-03-20 19:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:56:28 --> Pagination Class Initialized
INFO - 2025-03-20 19:56:28 --> Controller Class Initialized
DEBUG - 2025-03-20 19:56:28 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:56:28 --> Model Class Initialized
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:56:28 --> Model Class Initialized
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:56:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:56:28 --> Model Class Initialized
ERROR - 2025-03-20 19:56:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:56:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:56:28 --> Final output sent to browser
DEBUG - 2025-03-20 19:56:28 --> Total execution time: 0.1163
INFO - 2025-03-20 19:56:28 --> Config Class Initialized
INFO - 2025-03-20 19:56:28 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:56:28 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:56:28 --> Utf8 Class Initialized
INFO - 2025-03-20 19:56:28 --> URI Class Initialized
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:56:28 --> Router Class Initialized
INFO - 2025-03-20 19:56:28 --> Output Class Initialized
INFO - 2025-03-20 19:56:28 --> Security Class Initialized
DEBUG - 2025-03-20 19:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:56:28 --> Input Class Initialized
INFO - 2025-03-20 19:56:28 --> Language Class Initialized
INFO - 2025-03-20 19:56:28 --> Language Class Initialized
INFO - 2025-03-20 19:56:28 --> Config Class Initialized
INFO - 2025-03-20 19:56:28 --> Loader Class Initialized
INFO - 2025-03-20 19:56:28 --> Helper loaded: url_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: file_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: html_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: form_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: text_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:56:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:56:28 --> Database Driver Class Initialized
INFO - 2025-03-20 19:56:28 --> Email Class Initialized
INFO - 2025-03-20 19:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:56:28 --> Form Validation Class Initialized
INFO - 2025-03-20 19:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:56:28 --> Pagination Class Initialized
INFO - 2025-03-20 19:56:28 --> Controller Class Initialized
DEBUG - 2025-03-20 19:56:28 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:56:28 --> Model Class Initialized
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:56:28 --> Model Class Initialized
DEBUG - 2025-03-20 19:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:56:28 --> Model Class Initialized
INFO - 2025-03-20 19:56:28 --> Final output sent to browser
DEBUG - 2025-03-20 19:56:28 --> Total execution time: 0.0176
INFO - 2025-03-20 19:56:34 --> Config Class Initialized
INFO - 2025-03-20 19:56:34 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:56:34 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:56:34 --> Utf8 Class Initialized
INFO - 2025-03-20 19:56:34 --> URI Class Initialized
DEBUG - 2025-03-20 19:56:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:56:34 --> Router Class Initialized
INFO - 2025-03-20 19:56:34 --> Output Class Initialized
INFO - 2025-03-20 19:56:34 --> Security Class Initialized
DEBUG - 2025-03-20 19:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:56:34 --> Input Class Initialized
INFO - 2025-03-20 19:56:34 --> Language Class Initialized
INFO - 2025-03-20 19:56:34 --> Language Class Initialized
INFO - 2025-03-20 19:56:34 --> Config Class Initialized
INFO - 2025-03-20 19:56:34 --> Loader Class Initialized
INFO - 2025-03-20 19:56:34 --> Helper loaded: url_helper
INFO - 2025-03-20 19:56:34 --> Helper loaded: file_helper
INFO - 2025-03-20 19:56:34 --> Helper loaded: html_helper
INFO - 2025-03-20 19:56:34 --> Helper loaded: form_helper
INFO - 2025-03-20 19:56:34 --> Helper loaded: text_helper
INFO - 2025-03-20 19:56:34 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:56:34 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:56:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:56:34 --> Database Driver Class Initialized
INFO - 2025-03-20 19:56:34 --> Email Class Initialized
INFO - 2025-03-20 19:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:56:34 --> Form Validation Class Initialized
INFO - 2025-03-20 19:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:56:34 --> Pagination Class Initialized
INFO - 2025-03-20 19:56:34 --> Controller Class Initialized
DEBUG - 2025-03-20 19:56:34 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:56:34 --> Model Class Initialized
DEBUG - 2025-03-20 19:56:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:56:34 --> Model Class Initialized
DEBUG - 2025-03-20 19:56:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:56:34 --> Model Class Initialized
INFO - 2025-03-20 19:56:34 --> Final output sent to browser
DEBUG - 2025-03-20 19:56:34 --> Total execution time: 0.0111
INFO - 2025-03-20 19:57:25 --> Config Class Initialized
INFO - 2025-03-20 19:57:25 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:57:25 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:57:25 --> Utf8 Class Initialized
INFO - 2025-03-20 19:57:25 --> URI Class Initialized
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:57:25 --> Router Class Initialized
INFO - 2025-03-20 19:57:25 --> Output Class Initialized
INFO - 2025-03-20 19:57:25 --> Security Class Initialized
DEBUG - 2025-03-20 19:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:57:25 --> Input Class Initialized
INFO - 2025-03-20 19:57:25 --> Language Class Initialized
INFO - 2025-03-20 19:57:25 --> Language Class Initialized
INFO - 2025-03-20 19:57:25 --> Config Class Initialized
INFO - 2025-03-20 19:57:25 --> Loader Class Initialized
INFO - 2025-03-20 19:57:25 --> Helper loaded: url_helper
INFO - 2025-03-20 19:57:25 --> Helper loaded: file_helper
INFO - 2025-03-20 19:57:25 --> Helper loaded: html_helper
INFO - 2025-03-20 19:57:25 --> Helper loaded: form_helper
INFO - 2025-03-20 19:57:25 --> Helper loaded: text_helper
INFO - 2025-03-20 19:57:25 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:57:25 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:57:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:57:25 --> Database Driver Class Initialized
INFO - 2025-03-20 19:57:25 --> Email Class Initialized
INFO - 2025-03-20 19:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:57:25 --> Form Validation Class Initialized
INFO - 2025-03-20 19:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:57:25 --> Pagination Class Initialized
INFO - 2025-03-20 19:57:25 --> Controller Class Initialized
DEBUG - 2025-03-20 19:57:25 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:57:25 --> Model Class Initialized
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:57:25 --> Model Class Initialized
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:57:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:57:25 --> Model Class Initialized
ERROR - 2025-03-20 19:57:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:57:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:57:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:57:25 --> Final output sent to browser
DEBUG - 2025-03-20 19:57:25 --> Total execution time: 0.1206
INFO - 2025-03-20 19:57:38 --> Config Class Initialized
INFO - 2025-03-20 19:57:38 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:57:38 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:57:38 --> Utf8 Class Initialized
INFO - 2025-03-20 19:57:38 --> URI Class Initialized
DEBUG - 2025-03-20 19:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:57:38 --> Router Class Initialized
INFO - 2025-03-20 19:57:38 --> Output Class Initialized
INFO - 2025-03-20 19:57:38 --> Security Class Initialized
DEBUG - 2025-03-20 19:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:57:38 --> Input Class Initialized
INFO - 2025-03-20 19:57:38 --> Language Class Initialized
INFO - 2025-03-20 19:57:38 --> Language Class Initialized
INFO - 2025-03-20 19:57:38 --> Config Class Initialized
INFO - 2025-03-20 19:57:38 --> Loader Class Initialized
INFO - 2025-03-20 19:57:38 --> Helper loaded: url_helper
INFO - 2025-03-20 19:57:38 --> Helper loaded: file_helper
INFO - 2025-03-20 19:57:38 --> Helper loaded: html_helper
INFO - 2025-03-20 19:57:38 --> Helper loaded: form_helper
INFO - 2025-03-20 19:57:38 --> Helper loaded: text_helper
INFO - 2025-03-20 19:57:38 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:57:38 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:57:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:57:38 --> Database Driver Class Initialized
INFO - 2025-03-20 19:57:38 --> Email Class Initialized
INFO - 2025-03-20 19:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:57:38 --> Form Validation Class Initialized
INFO - 2025-03-20 19:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:57:38 --> Pagination Class Initialized
INFO - 2025-03-20 19:57:38 --> Controller Class Initialized
DEBUG - 2025-03-20 19:57:38 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:57:38 --> Model Class Initialized
DEBUG - 2025-03-20 19:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:57:38 --> Model Class Initialized
INFO - 2025-03-20 19:57:38 --> Final output sent to browser
DEBUG - 2025-03-20 19:57:38 --> Total execution time: 0.0136
INFO - 2025-03-20 19:57:47 --> Config Class Initialized
INFO - 2025-03-20 19:57:47 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:57:47 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:57:47 --> Utf8 Class Initialized
INFO - 2025-03-20 19:57:47 --> URI Class Initialized
DEBUG - 2025-03-20 19:57:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:57:47 --> Router Class Initialized
INFO - 2025-03-20 19:57:47 --> Output Class Initialized
INFO - 2025-03-20 19:57:47 --> Security Class Initialized
DEBUG - 2025-03-20 19:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:57:47 --> Input Class Initialized
INFO - 2025-03-20 19:57:47 --> Language Class Initialized
INFO - 2025-03-20 19:57:47 --> Language Class Initialized
INFO - 2025-03-20 19:57:47 --> Config Class Initialized
INFO - 2025-03-20 19:57:47 --> Loader Class Initialized
INFO - 2025-03-20 19:57:47 --> Helper loaded: url_helper
INFO - 2025-03-20 19:57:47 --> Helper loaded: file_helper
INFO - 2025-03-20 19:57:47 --> Helper loaded: html_helper
INFO - 2025-03-20 19:57:47 --> Helper loaded: form_helper
INFO - 2025-03-20 19:57:47 --> Helper loaded: text_helper
INFO - 2025-03-20 19:57:47 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:57:47 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:57:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:57:47 --> Database Driver Class Initialized
INFO - 2025-03-20 19:57:47 --> Email Class Initialized
INFO - 2025-03-20 19:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:57:47 --> Form Validation Class Initialized
INFO - 2025-03-20 19:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:57:47 --> Pagination Class Initialized
INFO - 2025-03-20 19:57:47 --> Controller Class Initialized
DEBUG - 2025-03-20 19:57:47 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:57:47 --> Model Class Initialized
DEBUG - 2025-03-20 19:57:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:57:47 --> Model Class Initialized
INFO - 2025-03-20 19:57:47 --> Final output sent to browser
DEBUG - 2025-03-20 19:57:47 --> Total execution time: 0.0074
INFO - 2025-03-20 19:58:06 --> Config Class Initialized
INFO - 2025-03-20 19:58:06 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:58:06 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:58:06 --> Utf8 Class Initialized
INFO - 2025-03-20 19:58:06 --> URI Class Initialized
DEBUG - 2025-03-20 19:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:58:06 --> Router Class Initialized
INFO - 2025-03-20 19:58:06 --> Output Class Initialized
INFO - 2025-03-20 19:58:06 --> Security Class Initialized
DEBUG - 2025-03-20 19:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:58:06 --> Input Class Initialized
INFO - 2025-03-20 19:58:06 --> Language Class Initialized
INFO - 2025-03-20 19:58:06 --> Language Class Initialized
INFO - 2025-03-20 19:58:06 --> Config Class Initialized
INFO - 2025-03-20 19:58:06 --> Loader Class Initialized
INFO - 2025-03-20 19:58:06 --> Helper loaded: url_helper
INFO - 2025-03-20 19:58:06 --> Helper loaded: file_helper
INFO - 2025-03-20 19:58:06 --> Helper loaded: html_helper
INFO - 2025-03-20 19:58:06 --> Helper loaded: form_helper
INFO - 2025-03-20 19:58:06 --> Helper loaded: text_helper
INFO - 2025-03-20 19:58:06 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:58:06 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:58:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:58:06 --> Database Driver Class Initialized
INFO - 2025-03-20 19:58:06 --> Email Class Initialized
INFO - 2025-03-20 19:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:58:06 --> Form Validation Class Initialized
INFO - 2025-03-20 19:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:58:06 --> Pagination Class Initialized
INFO - 2025-03-20 19:58:06 --> Controller Class Initialized
DEBUG - 2025-03-20 19:58:06 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:58:06 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:58:06 --> Model Class Initialized
INFO - 2025-03-20 19:58:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-20 19:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_payment_receipt.php
INFO - 2025-03-20 19:58:08 --> Config Class Initialized
INFO - 2025-03-20 19:58:08 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:58:08 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:58:08 --> Utf8 Class Initialized
INFO - 2025-03-20 19:58:08 --> URI Class Initialized
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:58:08 --> Router Class Initialized
INFO - 2025-03-20 19:58:08 --> Output Class Initialized
INFO - 2025-03-20 19:58:08 --> Security Class Initialized
DEBUG - 2025-03-20 19:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:58:08 --> Input Class Initialized
INFO - 2025-03-20 19:58:08 --> Language Class Initialized
INFO - 2025-03-20 19:58:08 --> Language Class Initialized
INFO - 2025-03-20 19:58:08 --> Config Class Initialized
INFO - 2025-03-20 19:58:08 --> Loader Class Initialized
INFO - 2025-03-20 19:58:08 --> Helper loaded: url_helper
INFO - 2025-03-20 19:58:08 --> Helper loaded: file_helper
INFO - 2025-03-20 19:58:08 --> Helper loaded: html_helper
INFO - 2025-03-20 19:58:08 --> Helper loaded: form_helper
INFO - 2025-03-20 19:58:08 --> Helper loaded: text_helper
INFO - 2025-03-20 19:58:08 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:58:08 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:58:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:58:08 --> Database Driver Class Initialized
INFO - 2025-03-20 19:58:08 --> Email Class Initialized
INFO - 2025-03-20 19:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:58:08 --> Form Validation Class Initialized
INFO - 2025-03-20 19:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:58:08 --> Pagination Class Initialized
INFO - 2025-03-20 19:58:08 --> Controller Class Initialized
DEBUG - 2025-03-20 19:58:08 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:58:08 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:58:08 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:58:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:58:08 --> Model Class Initialized
ERROR - 2025-03-20 19:58:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:58:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:58:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:58:08 --> Final output sent to browser
DEBUG - 2025-03-20 19:58:08 --> Total execution time: 0.1442
INFO - 2025-03-20 19:58:16 --> Config Class Initialized
INFO - 2025-03-20 19:58:16 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:58:16 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:58:16 --> Utf8 Class Initialized
INFO - 2025-03-20 19:58:16 --> URI Class Initialized
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:58:16 --> Router Class Initialized
INFO - 2025-03-20 19:58:16 --> Output Class Initialized
INFO - 2025-03-20 19:58:16 --> Security Class Initialized
DEBUG - 2025-03-20 19:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:58:16 --> Input Class Initialized
INFO - 2025-03-20 19:58:16 --> Language Class Initialized
INFO - 2025-03-20 19:58:16 --> Language Class Initialized
INFO - 2025-03-20 19:58:16 --> Config Class Initialized
INFO - 2025-03-20 19:58:16 --> Loader Class Initialized
INFO - 2025-03-20 19:58:16 --> Helper loaded: url_helper
INFO - 2025-03-20 19:58:16 --> Helper loaded: file_helper
INFO - 2025-03-20 19:58:16 --> Helper loaded: html_helper
INFO - 2025-03-20 19:58:16 --> Helper loaded: form_helper
INFO - 2025-03-20 19:58:16 --> Helper loaded: text_helper
INFO - 2025-03-20 19:58:16 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:58:16 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:58:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:58:16 --> Database Driver Class Initialized
INFO - 2025-03-20 19:58:16 --> Email Class Initialized
INFO - 2025-03-20 19:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:58:16 --> Form Validation Class Initialized
INFO - 2025-03-20 19:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:58:16 --> Pagination Class Initialized
INFO - 2025-03-20 19:58:16 --> Controller Class Initialized
DEBUG - 2025-03-20 19:58:16 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:58:16 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:58:16 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:58:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:58:16 --> Model Class Initialized
ERROR - 2025-03-20 19:58:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:58:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:58:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:58:16 --> Final output sent to browser
DEBUG - 2025-03-20 19:58:16 --> Total execution time: 0.1378
INFO - 2025-03-20 19:58:17 --> Config Class Initialized
INFO - 2025-03-20 19:58:17 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:58:17 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:58:17 --> Utf8 Class Initialized
INFO - 2025-03-20 19:58:17 --> URI Class Initialized
DEBUG - 2025-03-20 19:58:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:58:17 --> Router Class Initialized
INFO - 2025-03-20 19:58:17 --> Output Class Initialized
INFO - 2025-03-20 19:58:17 --> Security Class Initialized
DEBUG - 2025-03-20 19:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:58:17 --> Input Class Initialized
INFO - 2025-03-20 19:58:17 --> Language Class Initialized
INFO - 2025-03-20 19:58:17 --> Language Class Initialized
INFO - 2025-03-20 19:58:17 --> Config Class Initialized
INFO - 2025-03-20 19:58:17 --> Loader Class Initialized
INFO - 2025-03-20 19:58:17 --> Helper loaded: url_helper
INFO - 2025-03-20 19:58:17 --> Helper loaded: file_helper
INFO - 2025-03-20 19:58:17 --> Helper loaded: html_helper
INFO - 2025-03-20 19:58:17 --> Helper loaded: form_helper
INFO - 2025-03-20 19:58:17 --> Helper loaded: text_helper
INFO - 2025-03-20 19:58:17 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:58:17 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:58:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:58:17 --> Database Driver Class Initialized
INFO - 2025-03-20 19:58:17 --> Email Class Initialized
INFO - 2025-03-20 19:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:58:17 --> Form Validation Class Initialized
INFO - 2025-03-20 19:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:58:17 --> Pagination Class Initialized
INFO - 2025-03-20 19:58:17 --> Controller Class Initialized
DEBUG - 2025-03-20 19:58:17 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:58:17 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:58:17 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:58:17 --> Model Class Initialized
INFO - 2025-03-20 19:58:17 --> Final output sent to browser
DEBUG - 2025-03-20 19:58:17 --> Total execution time: 0.0101
INFO - 2025-03-20 19:58:22 --> Config Class Initialized
INFO - 2025-03-20 19:58:22 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:58:22 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:58:22 --> Utf8 Class Initialized
INFO - 2025-03-20 19:58:22 --> URI Class Initialized
DEBUG - 2025-03-20 19:58:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 19:58:22 --> Router Class Initialized
INFO - 2025-03-20 19:58:22 --> Output Class Initialized
INFO - 2025-03-20 19:58:22 --> Security Class Initialized
DEBUG - 2025-03-20 19:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:58:22 --> Input Class Initialized
INFO - 2025-03-20 19:58:22 --> Language Class Initialized
INFO - 2025-03-20 19:58:22 --> Language Class Initialized
INFO - 2025-03-20 19:58:22 --> Config Class Initialized
INFO - 2025-03-20 19:58:22 --> Loader Class Initialized
INFO - 2025-03-20 19:58:22 --> Helper loaded: url_helper
INFO - 2025-03-20 19:58:22 --> Helper loaded: file_helper
INFO - 2025-03-20 19:58:22 --> Helper loaded: html_helper
INFO - 2025-03-20 19:58:22 --> Helper loaded: form_helper
INFO - 2025-03-20 19:58:22 --> Helper loaded: text_helper
INFO - 2025-03-20 19:58:22 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:58:22 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:58:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:58:22 --> Database Driver Class Initialized
INFO - 2025-03-20 19:58:22 --> Email Class Initialized
INFO - 2025-03-20 19:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:58:22 --> Form Validation Class Initialized
INFO - 2025-03-20 19:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:58:22 --> Pagination Class Initialized
INFO - 2025-03-20 19:58:22 --> Controller Class Initialized
DEBUG - 2025-03-20 19:58:22 --> Report MX_Controller Initialized
INFO - 2025-03-20 19:58:22 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 19:58:22 --> Model Class Initialized
DEBUG - 2025-03-20 19:58:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:58:22 --> Model Class Initialized
INFO - 2025-03-20 19:58:22 --> Final output sent to browser
DEBUG - 2025-03-20 19:58:22 --> Total execution time: 0.0112
INFO - 2025-03-20 19:59:36 --> Config Class Initialized
INFO - 2025-03-20 19:59:36 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:59:36 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:59:36 --> Utf8 Class Initialized
INFO - 2025-03-20 19:59:36 --> URI Class Initialized
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:59:36 --> Router Class Initialized
INFO - 2025-03-20 19:59:36 --> Output Class Initialized
INFO - 2025-03-20 19:59:36 --> Security Class Initialized
DEBUG - 2025-03-20 19:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:59:36 --> Input Class Initialized
INFO - 2025-03-20 19:59:36 --> Language Class Initialized
INFO - 2025-03-20 19:59:36 --> Language Class Initialized
INFO - 2025-03-20 19:59:36 --> Config Class Initialized
INFO - 2025-03-20 19:59:36 --> Loader Class Initialized
INFO - 2025-03-20 19:59:36 --> Helper loaded: url_helper
INFO - 2025-03-20 19:59:36 --> Helper loaded: file_helper
INFO - 2025-03-20 19:59:36 --> Helper loaded: html_helper
INFO - 2025-03-20 19:59:36 --> Helper loaded: form_helper
INFO - 2025-03-20 19:59:36 --> Helper loaded: text_helper
INFO - 2025-03-20 19:59:36 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:59:36 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:59:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:59:36 --> Database Driver Class Initialized
INFO - 2025-03-20 19:59:36 --> Email Class Initialized
INFO - 2025-03-20 19:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:59:36 --> Form Validation Class Initialized
INFO - 2025-03-20 19:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:59:36 --> Pagination Class Initialized
INFO - 2025-03-20 19:59:36 --> Controller Class Initialized
DEBUG - 2025-03-20 19:59:36 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:59:36 --> Model Class Initialized
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:59:36 --> Model Class Initialized
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 19:59:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 19:59:36 --> Model Class Initialized
ERROR - 2025-03-20 19:59:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 19:59:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 19:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 19:59:36 --> Final output sent to browser
DEBUG - 2025-03-20 19:59:36 --> Total execution time: 0.1392
INFO - 2025-03-20 19:59:45 --> Config Class Initialized
INFO - 2025-03-20 19:59:45 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:59:45 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:59:45 --> Utf8 Class Initialized
INFO - 2025-03-20 19:59:45 --> URI Class Initialized
DEBUG - 2025-03-20 19:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:59:45 --> Router Class Initialized
INFO - 2025-03-20 19:59:45 --> Output Class Initialized
INFO - 2025-03-20 19:59:45 --> Security Class Initialized
DEBUG - 2025-03-20 19:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:59:45 --> Input Class Initialized
INFO - 2025-03-20 19:59:45 --> Language Class Initialized
INFO - 2025-03-20 19:59:45 --> Language Class Initialized
INFO - 2025-03-20 19:59:45 --> Config Class Initialized
INFO - 2025-03-20 19:59:45 --> Loader Class Initialized
INFO - 2025-03-20 19:59:45 --> Helper loaded: url_helper
INFO - 2025-03-20 19:59:45 --> Helper loaded: file_helper
INFO - 2025-03-20 19:59:45 --> Helper loaded: html_helper
INFO - 2025-03-20 19:59:45 --> Helper loaded: form_helper
INFO - 2025-03-20 19:59:45 --> Helper loaded: text_helper
INFO - 2025-03-20 19:59:45 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:59:45 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:59:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:59:45 --> Database Driver Class Initialized
INFO - 2025-03-20 19:59:45 --> Email Class Initialized
INFO - 2025-03-20 19:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:59:45 --> Form Validation Class Initialized
INFO - 2025-03-20 19:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:59:45 --> Pagination Class Initialized
INFO - 2025-03-20 19:59:45 --> Controller Class Initialized
DEBUG - 2025-03-20 19:59:45 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:59:45 --> Model Class Initialized
DEBUG - 2025-03-20 19:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:59:45 --> Model Class Initialized
INFO - 2025-03-20 19:59:45 --> Final output sent to browser
DEBUG - 2025-03-20 19:59:45 --> Total execution time: 0.0054
INFO - 2025-03-20 19:59:47 --> Config Class Initialized
INFO - 2025-03-20 19:59:47 --> Hooks Class Initialized
DEBUG - 2025-03-20 19:59:47 --> UTF-8 Support Enabled
INFO - 2025-03-20 19:59:47 --> Utf8 Class Initialized
INFO - 2025-03-20 19:59:47 --> URI Class Initialized
DEBUG - 2025-03-20 19:59:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 19:59:47 --> Router Class Initialized
INFO - 2025-03-20 19:59:47 --> Output Class Initialized
INFO - 2025-03-20 19:59:47 --> Security Class Initialized
DEBUG - 2025-03-20 19:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 19:59:47 --> Input Class Initialized
INFO - 2025-03-20 19:59:47 --> Language Class Initialized
INFO - 2025-03-20 19:59:47 --> Language Class Initialized
INFO - 2025-03-20 19:59:47 --> Config Class Initialized
INFO - 2025-03-20 19:59:47 --> Loader Class Initialized
INFO - 2025-03-20 19:59:47 --> Helper loaded: url_helper
INFO - 2025-03-20 19:59:47 --> Helper loaded: file_helper
INFO - 2025-03-20 19:59:47 --> Helper loaded: html_helper
INFO - 2025-03-20 19:59:47 --> Helper loaded: form_helper
INFO - 2025-03-20 19:59:47 --> Helper loaded: text_helper
INFO - 2025-03-20 19:59:47 --> Helper loaded: lang_helper
INFO - 2025-03-20 19:59:47 --> Helper loaded: directory_helper
INFO - 2025-03-20 19:59:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 19:59:47 --> Database Driver Class Initialized
INFO - 2025-03-20 19:59:47 --> Email Class Initialized
INFO - 2025-03-20 19:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 19:59:47 --> Form Validation Class Initialized
INFO - 2025-03-20 19:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 19:59:47 --> Pagination Class Initialized
INFO - 2025-03-20 19:59:47 --> Controller Class Initialized
DEBUG - 2025-03-20 19:59:47 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 19:59:47 --> Model Class Initialized
DEBUG - 2025-03-20 19:59:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 19:59:47 --> Model Class Initialized
INFO - 2025-03-20 19:59:47 --> Final output sent to browser
DEBUG - 2025-03-20 19:59:47 --> Total execution time: 0.0081
INFO - 2025-03-20 20:00:15 --> Config Class Initialized
INFO - 2025-03-20 20:00:15 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:00:15 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:00:15 --> Utf8 Class Initialized
INFO - 2025-03-20 20:00:15 --> URI Class Initialized
DEBUG - 2025-03-20 20:00:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 20:00:15 --> Router Class Initialized
INFO - 2025-03-20 20:00:15 --> Output Class Initialized
INFO - 2025-03-20 20:00:15 --> Security Class Initialized
DEBUG - 2025-03-20 20:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:00:15 --> Input Class Initialized
INFO - 2025-03-20 20:00:15 --> Language Class Initialized
INFO - 2025-03-20 20:00:15 --> Language Class Initialized
INFO - 2025-03-20 20:00:15 --> Config Class Initialized
INFO - 2025-03-20 20:00:15 --> Loader Class Initialized
INFO - 2025-03-20 20:00:15 --> Helper loaded: url_helper
INFO - 2025-03-20 20:00:15 --> Helper loaded: file_helper
INFO - 2025-03-20 20:00:15 --> Helper loaded: html_helper
INFO - 2025-03-20 20:00:15 --> Helper loaded: form_helper
INFO - 2025-03-20 20:00:15 --> Helper loaded: text_helper
INFO - 2025-03-20 20:00:15 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:00:15 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:00:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:00:15 --> Database Driver Class Initialized
INFO - 2025-03-20 20:00:15 --> Email Class Initialized
INFO - 2025-03-20 20:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:00:15 --> Form Validation Class Initialized
INFO - 2025-03-20 20:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:00:15 --> Pagination Class Initialized
INFO - 2025-03-20 20:00:15 --> Controller Class Initialized
DEBUG - 2025-03-20 20:00:15 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 20:00:15 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:00:15 --> Model Class Initialized
INFO - 2025-03-20 20:00:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-20 20:00:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_payment_receipt.php
INFO - 2025-03-20 20:00:16 --> Config Class Initialized
INFO - 2025-03-20 20:00:16 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:00:16 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:00:16 --> Utf8 Class Initialized
INFO - 2025-03-20 20:00:16 --> URI Class Initialized
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 20:00:16 --> Router Class Initialized
INFO - 2025-03-20 20:00:16 --> Output Class Initialized
INFO - 2025-03-20 20:00:16 --> Security Class Initialized
DEBUG - 2025-03-20 20:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:00:16 --> Input Class Initialized
INFO - 2025-03-20 20:00:16 --> Language Class Initialized
INFO - 2025-03-20 20:00:16 --> Language Class Initialized
INFO - 2025-03-20 20:00:16 --> Config Class Initialized
INFO - 2025-03-20 20:00:16 --> Loader Class Initialized
INFO - 2025-03-20 20:00:16 --> Helper loaded: url_helper
INFO - 2025-03-20 20:00:16 --> Helper loaded: file_helper
INFO - 2025-03-20 20:00:16 --> Helper loaded: html_helper
INFO - 2025-03-20 20:00:16 --> Helper loaded: form_helper
INFO - 2025-03-20 20:00:16 --> Helper loaded: text_helper
INFO - 2025-03-20 20:00:16 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:00:16 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:00:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:00:16 --> Database Driver Class Initialized
INFO - 2025-03-20 20:00:16 --> Email Class Initialized
INFO - 2025-03-20 20:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:00:16 --> Form Validation Class Initialized
INFO - 2025-03-20 20:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:00:16 --> Pagination Class Initialized
INFO - 2025-03-20 20:00:16 --> Controller Class Initialized
DEBUG - 2025-03-20 20:00:16 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 20:00:16 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:00:16 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:00:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:00:16 --> Model Class Initialized
ERROR - 2025-03-20 20:00:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:00:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:00:16 --> Final output sent to browser
DEBUG - 2025-03-20 20:00:16 --> Total execution time: 0.1332
INFO - 2025-03-20 20:00:24 --> Config Class Initialized
INFO - 2025-03-20 20:00:24 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:00:24 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:00:24 --> Utf8 Class Initialized
INFO - 2025-03-20 20:00:24 --> URI Class Initialized
DEBUG - 2025-03-20 20:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:00:24 --> Router Class Initialized
INFO - 2025-03-20 20:00:24 --> Output Class Initialized
INFO - 2025-03-20 20:00:24 --> Security Class Initialized
DEBUG - 2025-03-20 20:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:00:24 --> Input Class Initialized
INFO - 2025-03-20 20:00:24 --> Language Class Initialized
INFO - 2025-03-20 20:00:24 --> Language Class Initialized
INFO - 2025-03-20 20:00:24 --> Config Class Initialized
INFO - 2025-03-20 20:00:24 --> Loader Class Initialized
INFO - 2025-03-20 20:00:24 --> Helper loaded: url_helper
INFO - 2025-03-20 20:00:24 --> Helper loaded: file_helper
INFO - 2025-03-20 20:00:24 --> Helper loaded: html_helper
INFO - 2025-03-20 20:00:24 --> Helper loaded: form_helper
INFO - 2025-03-20 20:00:24 --> Helper loaded: text_helper
INFO - 2025-03-20 20:00:24 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:00:24 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:00:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:00:24 --> Database Driver Class Initialized
INFO - 2025-03-20 20:00:24 --> Email Class Initialized
INFO - 2025-03-20 20:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:00:24 --> Form Validation Class Initialized
INFO - 2025-03-20 20:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:00:24 --> Pagination Class Initialized
INFO - 2025-03-20 20:00:24 --> Controller Class Initialized
DEBUG - 2025-03-20 20:00:24 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:00:24 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:00:24 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:00:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:00:24 --> Model Class Initialized
ERROR - 2025-03-20 20:00:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:00:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:00:25 --> Final output sent to browser
DEBUG - 2025-03-20 20:00:25 --> Total execution time: 0.1604
INFO - 2025-03-20 20:00:25 --> Config Class Initialized
INFO - 2025-03-20 20:00:25 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:00:25 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:00:25 --> Utf8 Class Initialized
INFO - 2025-03-20 20:00:25 --> URI Class Initialized
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:00:25 --> Router Class Initialized
INFO - 2025-03-20 20:00:25 --> Output Class Initialized
INFO - 2025-03-20 20:00:25 --> Security Class Initialized
DEBUG - 2025-03-20 20:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:00:25 --> Input Class Initialized
INFO - 2025-03-20 20:00:25 --> Language Class Initialized
INFO - 2025-03-20 20:00:25 --> Language Class Initialized
INFO - 2025-03-20 20:00:25 --> Config Class Initialized
INFO - 2025-03-20 20:00:25 --> Loader Class Initialized
INFO - 2025-03-20 20:00:25 --> Helper loaded: url_helper
INFO - 2025-03-20 20:00:25 --> Helper loaded: file_helper
INFO - 2025-03-20 20:00:25 --> Helper loaded: html_helper
INFO - 2025-03-20 20:00:25 --> Helper loaded: form_helper
INFO - 2025-03-20 20:00:25 --> Helper loaded: text_helper
INFO - 2025-03-20 20:00:25 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:00:25 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:00:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:00:25 --> Database Driver Class Initialized
INFO - 2025-03-20 20:00:25 --> Email Class Initialized
INFO - 2025-03-20 20:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:00:25 --> Form Validation Class Initialized
INFO - 2025-03-20 20:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:00:25 --> Pagination Class Initialized
INFO - 2025-03-20 20:00:25 --> Controller Class Initialized
DEBUG - 2025-03-20 20:00:25 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:00:25 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:00:25 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:00:25 --> Model Class Initialized
INFO - 2025-03-20 20:00:25 --> Final output sent to browser
DEBUG - 2025-03-20 20:00:25 --> Total execution time: 0.0071
INFO - 2025-03-20 20:00:29 --> Config Class Initialized
INFO - 2025-03-20 20:00:29 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:00:29 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:00:29 --> Utf8 Class Initialized
INFO - 2025-03-20 20:00:29 --> URI Class Initialized
DEBUG - 2025-03-20 20:00:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:00:29 --> Router Class Initialized
INFO - 2025-03-20 20:00:29 --> Output Class Initialized
INFO - 2025-03-20 20:00:29 --> Security Class Initialized
DEBUG - 2025-03-20 20:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:00:29 --> Input Class Initialized
INFO - 2025-03-20 20:00:29 --> Language Class Initialized
INFO - 2025-03-20 20:00:29 --> Language Class Initialized
INFO - 2025-03-20 20:00:29 --> Config Class Initialized
INFO - 2025-03-20 20:00:29 --> Loader Class Initialized
INFO - 2025-03-20 20:00:29 --> Helper loaded: url_helper
INFO - 2025-03-20 20:00:29 --> Helper loaded: file_helper
INFO - 2025-03-20 20:00:29 --> Helper loaded: html_helper
INFO - 2025-03-20 20:00:29 --> Helper loaded: form_helper
INFO - 2025-03-20 20:00:29 --> Helper loaded: text_helper
INFO - 2025-03-20 20:00:29 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:00:29 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:00:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:00:29 --> Database Driver Class Initialized
INFO - 2025-03-20 20:00:29 --> Email Class Initialized
INFO - 2025-03-20 20:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:00:29 --> Form Validation Class Initialized
INFO - 2025-03-20 20:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:00:29 --> Pagination Class Initialized
INFO - 2025-03-20 20:00:29 --> Controller Class Initialized
DEBUG - 2025-03-20 20:00:29 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:00:29 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:00:29 --> Model Class Initialized
DEBUG - 2025-03-20 20:00:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:00:29 --> Model Class Initialized
INFO - 2025-03-20 20:00:29 --> Final output sent to browser
DEBUG - 2025-03-20 20:00:29 --> Total execution time: 0.0150
INFO - 2025-03-20 20:01:30 --> Config Class Initialized
INFO - 2025-03-20 20:01:30 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:01:30 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:01:30 --> Utf8 Class Initialized
INFO - 2025-03-20 20:01:30 --> URI Class Initialized
DEBUG - 2025-03-20 20:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:01:30 --> Router Class Initialized
INFO - 2025-03-20 20:01:30 --> Output Class Initialized
INFO - 2025-03-20 20:01:30 --> Security Class Initialized
DEBUG - 2025-03-20 20:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:01:30 --> Input Class Initialized
INFO - 2025-03-20 20:01:30 --> Language Class Initialized
INFO - 2025-03-20 20:01:30 --> Language Class Initialized
INFO - 2025-03-20 20:01:30 --> Config Class Initialized
INFO - 2025-03-20 20:01:30 --> Loader Class Initialized
INFO - 2025-03-20 20:01:30 --> Helper loaded: url_helper
INFO - 2025-03-20 20:01:30 --> Helper loaded: file_helper
INFO - 2025-03-20 20:01:30 --> Helper loaded: html_helper
INFO - 2025-03-20 20:01:30 --> Helper loaded: form_helper
INFO - 2025-03-20 20:01:30 --> Helper loaded: text_helper
INFO - 2025-03-20 20:01:30 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:01:30 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:01:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:01:30 --> Database Driver Class Initialized
INFO - 2025-03-20 20:01:30 --> Email Class Initialized
INFO - 2025-03-20 20:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:01:30 --> Form Validation Class Initialized
INFO - 2025-03-20 20:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:01:30 --> Pagination Class Initialized
INFO - 2025-03-20 20:01:30 --> Controller Class Initialized
DEBUG - 2025-03-20 20:01:30 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:01:33 --> Config Class Initialized
INFO - 2025-03-20 20:01:33 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:01:33 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:01:33 --> Utf8 Class Initialized
INFO - 2025-03-20 20:01:33 --> URI Class Initialized
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 20:01:33 --> Router Class Initialized
INFO - 2025-03-20 20:01:33 --> Output Class Initialized
INFO - 2025-03-20 20:01:33 --> Security Class Initialized
DEBUG - 2025-03-20 20:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:01:33 --> Input Class Initialized
INFO - 2025-03-20 20:01:33 --> Language Class Initialized
INFO - 2025-03-20 20:01:33 --> Language Class Initialized
INFO - 2025-03-20 20:01:33 --> Config Class Initialized
INFO - 2025-03-20 20:01:33 --> Loader Class Initialized
INFO - 2025-03-20 20:01:33 --> Helper loaded: url_helper
INFO - 2025-03-20 20:01:33 --> Helper loaded: file_helper
INFO - 2025-03-20 20:01:33 --> Helper loaded: html_helper
INFO - 2025-03-20 20:01:33 --> Helper loaded: form_helper
INFO - 2025-03-20 20:01:33 --> Helper loaded: text_helper
INFO - 2025-03-20 20:01:33 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:01:33 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:01:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:01:33 --> Database Driver Class Initialized
INFO - 2025-03-20 20:01:33 --> Email Class Initialized
INFO - 2025-03-20 20:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:01:33 --> Form Validation Class Initialized
INFO - 2025-03-20 20:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:01:33 --> Pagination Class Initialized
INFO - 2025-03-20 20:01:33 --> Controller Class Initialized
DEBUG - 2025-03-20 20:01:33 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 20:01:33 --> Model Class Initialized
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:01:33 --> Model Class Initialized
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:01:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:01:33 --> Model Class Initialized
ERROR - 2025-03-20 20:01:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:01:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:01:33 --> Final output sent to browser
DEBUG - 2025-03-20 20:01:33 --> Total execution time: 0.1224
INFO - 2025-03-20 20:02:02 --> Config Class Initialized
INFO - 2025-03-20 20:02:02 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:02 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:02 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:02 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 20:02:02 --> Router Class Initialized
INFO - 2025-03-20 20:02:02 --> Output Class Initialized
INFO - 2025-03-20 20:02:02 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:02 --> Input Class Initialized
INFO - 2025-03-20 20:02:02 --> Language Class Initialized
INFO - 2025-03-20 20:02:02 --> Language Class Initialized
INFO - 2025-03-20 20:02:02 --> Config Class Initialized
INFO - 2025-03-20 20:02:02 --> Loader Class Initialized
INFO - 2025-03-20 20:02:02 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:02 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:02 --> Email Class Initialized
INFO - 2025-03-20 20:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:02 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:02 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:02 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:02 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 20:02:02 --> Model Class Initialized
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:02:02 --> Model Class Initialized
INFO - 2025-03-20 20:02:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-20 20:02:02 --> Config Class Initialized
INFO - 2025-03-20 20:02:02 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:02 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:02 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:02 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-20 20:02:02 --> Router Class Initialized
INFO - 2025-03-20 20:02:02 --> Output Class Initialized
INFO - 2025-03-20 20:02:02 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:02 --> Input Class Initialized
INFO - 2025-03-20 20:02:02 --> Language Class Initialized
INFO - 2025-03-20 20:02:02 --> Language Class Initialized
INFO - 2025-03-20 20:02:02 --> Config Class Initialized
INFO - 2025-03-20 20:02:02 --> Loader Class Initialized
INFO - 2025-03-20 20:02:02 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:02 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:02 --> Email Class Initialized
INFO - 2025-03-20 20:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:02 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:02 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:02 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:02 --> Accounts MX_Controller Initialized
INFO - 2025-03-20 20:02:02 --> Model Class Initialized
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:02:02 --> Model Class Initialized
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:02:02 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:02:02 --> Model Class Initialized
ERROR - 2025-03-20 20:02:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:02:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_list.php
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:02:02 --> Final output sent to browser
DEBUG - 2025-03-20 20:02:02 --> Total execution time: 0.1306
INFO - 2025-03-20 20:02:08 --> Config Class Initialized
INFO - 2025-03-20 20:02:08 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:08 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:08 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:08 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:08 --> Router Class Initialized
INFO - 2025-03-20 20:02:08 --> Output Class Initialized
INFO - 2025-03-20 20:02:08 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:08 --> Input Class Initialized
INFO - 2025-03-20 20:02:08 --> Language Class Initialized
INFO - 2025-03-20 20:02:08 --> Language Class Initialized
INFO - 2025-03-20 20:02:08 --> Config Class Initialized
INFO - 2025-03-20 20:02:08 --> Loader Class Initialized
INFO - 2025-03-20 20:02:08 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:08 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:08 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:08 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:08 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:08 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:08 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:08 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:08 --> Email Class Initialized
INFO - 2025-03-20 20:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:08 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:08 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:08 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:08 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:17 --> Config Class Initialized
INFO - 2025-03-20 20:02:17 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:17 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:17 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:17 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:17 --> Router Class Initialized
INFO - 2025-03-20 20:02:17 --> Output Class Initialized
INFO - 2025-03-20 20:02:17 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:17 --> Input Class Initialized
INFO - 2025-03-20 20:02:17 --> Language Class Initialized
INFO - 2025-03-20 20:02:17 --> Language Class Initialized
INFO - 2025-03-20 20:02:17 --> Config Class Initialized
INFO - 2025-03-20 20:02:17 --> Loader Class Initialized
INFO - 2025-03-20 20:02:17 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:17 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:17 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:17 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:17 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:17 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:17 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:17 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:17 --> Email Class Initialized
INFO - 2025-03-20 20:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:17 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:17 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:17 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:17 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:18 --> Config Class Initialized
INFO - 2025-03-20 20:02:18 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:18 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:18 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:18 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:18 --> Router Class Initialized
INFO - 2025-03-20 20:02:18 --> Output Class Initialized
INFO - 2025-03-20 20:02:18 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:18 --> Input Class Initialized
INFO - 2025-03-20 20:02:18 --> Language Class Initialized
INFO - 2025-03-20 20:02:18 --> Language Class Initialized
INFO - 2025-03-20 20:02:18 --> Config Class Initialized
INFO - 2025-03-20 20:02:18 --> Loader Class Initialized
INFO - 2025-03-20 20:02:18 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:18 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:18 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:18 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:18 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:18 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:18 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:18 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:18 --> Email Class Initialized
INFO - 2025-03-20 20:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:18 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:18 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:18 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:18 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:26 --> Config Class Initialized
INFO - 2025-03-20 20:02:26 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:26 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:26 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:26 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:26 --> Router Class Initialized
INFO - 2025-03-20 20:02:26 --> Output Class Initialized
INFO - 2025-03-20 20:02:26 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:26 --> Input Class Initialized
INFO - 2025-03-20 20:02:26 --> Language Class Initialized
INFO - 2025-03-20 20:02:26 --> Language Class Initialized
INFO - 2025-03-20 20:02:26 --> Config Class Initialized
INFO - 2025-03-20 20:02:26 --> Loader Class Initialized
INFO - 2025-03-20 20:02:26 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:26 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:26 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:26 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:26 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:26 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:26 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:26 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:26 --> Email Class Initialized
INFO - 2025-03-20 20:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:26 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:26 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:26 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:26 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:28 --> Config Class Initialized
INFO - 2025-03-20 20:02:28 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:28 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:28 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:28 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:28 --> Router Class Initialized
INFO - 2025-03-20 20:02:28 --> Output Class Initialized
INFO - 2025-03-20 20:02:28 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:28 --> Input Class Initialized
INFO - 2025-03-20 20:02:28 --> Language Class Initialized
INFO - 2025-03-20 20:02:28 --> Language Class Initialized
INFO - 2025-03-20 20:02:28 --> Config Class Initialized
INFO - 2025-03-20 20:02:28 --> Loader Class Initialized
INFO - 2025-03-20 20:02:28 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:28 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:28 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:28 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:28 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:28 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:28 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:28 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:28 --> Email Class Initialized
INFO - 2025-03-20 20:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:28 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:28 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:28 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:28 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:33 --> Config Class Initialized
INFO - 2025-03-20 20:02:33 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:33 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:33 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:33 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:33 --> Router Class Initialized
INFO - 2025-03-20 20:02:33 --> Output Class Initialized
INFO - 2025-03-20 20:02:33 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:33 --> Input Class Initialized
INFO - 2025-03-20 20:02:33 --> Language Class Initialized
INFO - 2025-03-20 20:02:33 --> Language Class Initialized
INFO - 2025-03-20 20:02:33 --> Config Class Initialized
INFO - 2025-03-20 20:02:33 --> Loader Class Initialized
INFO - 2025-03-20 20:02:33 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:33 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:33 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:33 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:33 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:33 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:33 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:33 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:33 --> Email Class Initialized
INFO - 2025-03-20 20:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:33 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:33 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:33 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:33 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:34 --> Config Class Initialized
INFO - 2025-03-20 20:02:34 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:34 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:34 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:34 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:34 --> Router Class Initialized
INFO - 2025-03-20 20:02:34 --> Output Class Initialized
INFO - 2025-03-20 20:02:34 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:34 --> Input Class Initialized
INFO - 2025-03-20 20:02:34 --> Language Class Initialized
INFO - 2025-03-20 20:02:34 --> Language Class Initialized
INFO - 2025-03-20 20:02:34 --> Config Class Initialized
INFO - 2025-03-20 20:02:34 --> Loader Class Initialized
INFO - 2025-03-20 20:02:34 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:34 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:34 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:34 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:34 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:34 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:34 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:34 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:34 --> Email Class Initialized
INFO - 2025-03-20 20:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:34 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:34 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:34 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:34 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:35 --> Config Class Initialized
INFO - 2025-03-20 20:02:35 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:35 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:35 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:35 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:35 --> Router Class Initialized
INFO - 2025-03-20 20:02:35 --> Output Class Initialized
INFO - 2025-03-20 20:02:35 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:35 --> Input Class Initialized
INFO - 2025-03-20 20:02:35 --> Language Class Initialized
INFO - 2025-03-20 20:02:35 --> Language Class Initialized
INFO - 2025-03-20 20:02:35 --> Config Class Initialized
INFO - 2025-03-20 20:02:35 --> Loader Class Initialized
INFO - 2025-03-20 20:02:35 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:35 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:35 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:35 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:35 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:35 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:35 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:35 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:35 --> Email Class Initialized
INFO - 2025-03-20 20:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:35 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:35 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:35 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:35 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:37 --> Config Class Initialized
INFO - 2025-03-20 20:02:37 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:37 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:37 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:37 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:37 --> Router Class Initialized
INFO - 2025-03-20 20:02:37 --> Output Class Initialized
INFO - 2025-03-20 20:02:37 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:37 --> Input Class Initialized
INFO - 2025-03-20 20:02:37 --> Language Class Initialized
INFO - 2025-03-20 20:02:37 --> Language Class Initialized
INFO - 2025-03-20 20:02:37 --> Config Class Initialized
INFO - 2025-03-20 20:02:37 --> Loader Class Initialized
INFO - 2025-03-20 20:02:37 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:37 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:37 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:37 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:37 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:37 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:37 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:37 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:37 --> Email Class Initialized
INFO - 2025-03-20 20:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:37 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:37 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:37 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:37 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:02:59 --> Config Class Initialized
INFO - 2025-03-20 20:02:59 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:02:59 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:02:59 --> Utf8 Class Initialized
INFO - 2025-03-20 20:02:59 --> URI Class Initialized
DEBUG - 2025-03-20 20:02:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:02:59 --> Router Class Initialized
INFO - 2025-03-20 20:02:59 --> Output Class Initialized
INFO - 2025-03-20 20:02:59 --> Security Class Initialized
DEBUG - 2025-03-20 20:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:02:59 --> Input Class Initialized
INFO - 2025-03-20 20:02:59 --> Language Class Initialized
INFO - 2025-03-20 20:02:59 --> Language Class Initialized
INFO - 2025-03-20 20:02:59 --> Config Class Initialized
INFO - 2025-03-20 20:02:59 --> Loader Class Initialized
INFO - 2025-03-20 20:02:59 --> Helper loaded: url_helper
INFO - 2025-03-20 20:02:59 --> Helper loaded: file_helper
INFO - 2025-03-20 20:02:59 --> Helper loaded: html_helper
INFO - 2025-03-20 20:02:59 --> Helper loaded: form_helper
INFO - 2025-03-20 20:02:59 --> Helper loaded: text_helper
INFO - 2025-03-20 20:02:59 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:02:59 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:02:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:02:59 --> Database Driver Class Initialized
INFO - 2025-03-20 20:02:59 --> Email Class Initialized
INFO - 2025-03-20 20:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:02:59 --> Form Validation Class Initialized
INFO - 2025-03-20 20:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:02:59 --> Pagination Class Initialized
INFO - 2025-03-20 20:02:59 --> Controller Class Initialized
DEBUG - 2025-03-20 20:02:59 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:03:00 --> Config Class Initialized
INFO - 2025-03-20 20:03:00 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:03:00 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:03:00 --> Utf8 Class Initialized
INFO - 2025-03-20 20:03:00 --> URI Class Initialized
DEBUG - 2025-03-20 20:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-20 20:03:00 --> Router Class Initialized
INFO - 2025-03-20 20:03:00 --> Output Class Initialized
INFO - 2025-03-20 20:03:00 --> Security Class Initialized
DEBUG - 2025-03-20 20:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:03:00 --> Input Class Initialized
INFO - 2025-03-20 20:03:00 --> Language Class Initialized
INFO - 2025-03-20 20:03:00 --> Language Class Initialized
INFO - 2025-03-20 20:03:00 --> Config Class Initialized
INFO - 2025-03-20 20:03:00 --> Loader Class Initialized
INFO - 2025-03-20 20:03:00 --> Helper loaded: url_helper
INFO - 2025-03-20 20:03:00 --> Helper loaded: file_helper
INFO - 2025-03-20 20:03:00 --> Helper loaded: html_helper
INFO - 2025-03-20 20:03:00 --> Helper loaded: form_helper
INFO - 2025-03-20 20:03:00 --> Helper loaded: text_helper
INFO - 2025-03-20 20:03:00 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:03:00 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:03:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:03:00 --> Database Driver Class Initialized
INFO - 2025-03-20 20:03:00 --> Email Class Initialized
INFO - 2025-03-20 20:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:03:00 --> Form Validation Class Initialized
INFO - 2025-03-20 20:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:03:00 --> Pagination Class Initialized
INFO - 2025-03-20 20:03:00 --> Controller Class Initialized
DEBUG - 2025-03-20 20:03:00 --> Invoice MX_Controller Initialized
INFO - 2025-03-20 20:03:09 --> Config Class Initialized
INFO - 2025-03-20 20:03:09 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:03:09 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:03:09 --> Utf8 Class Initialized
INFO - 2025-03-20 20:03:09 --> URI Class Initialized
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:03:09 --> Router Class Initialized
INFO - 2025-03-20 20:03:09 --> Output Class Initialized
INFO - 2025-03-20 20:03:09 --> Security Class Initialized
DEBUG - 2025-03-20 20:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:03:09 --> Input Class Initialized
INFO - 2025-03-20 20:03:09 --> Language Class Initialized
INFO - 2025-03-20 20:03:09 --> Language Class Initialized
INFO - 2025-03-20 20:03:09 --> Config Class Initialized
INFO - 2025-03-20 20:03:09 --> Loader Class Initialized
INFO - 2025-03-20 20:03:09 --> Helper loaded: url_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: file_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: html_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: form_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: text_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:03:09 --> Database Driver Class Initialized
INFO - 2025-03-20 20:03:09 --> Email Class Initialized
INFO - 2025-03-20 20:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:03:09 --> Form Validation Class Initialized
INFO - 2025-03-20 20:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:03:09 --> Pagination Class Initialized
INFO - 2025-03-20 20:03:09 --> Controller Class Initialized
DEBUG - 2025-03-20 20:03:09 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:03:09 --> Model Class Initialized
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:03:09 --> Model Class Initialized
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:03:09 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:03:09 --> Model Class Initialized
ERROR - 2025-03-20 20:03:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:03:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:03:09 --> Final output sent to browser
DEBUG - 2025-03-20 20:03:09 --> Total execution time: 0.1289
INFO - 2025-03-20 20:03:09 --> Config Class Initialized
INFO - 2025-03-20 20:03:09 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:03:09 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:03:09 --> Utf8 Class Initialized
INFO - 2025-03-20 20:03:09 --> URI Class Initialized
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:03:09 --> Router Class Initialized
INFO - 2025-03-20 20:03:09 --> Output Class Initialized
INFO - 2025-03-20 20:03:09 --> Security Class Initialized
DEBUG - 2025-03-20 20:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:03:09 --> Input Class Initialized
INFO - 2025-03-20 20:03:09 --> Language Class Initialized
INFO - 2025-03-20 20:03:09 --> Language Class Initialized
INFO - 2025-03-20 20:03:09 --> Config Class Initialized
INFO - 2025-03-20 20:03:09 --> Loader Class Initialized
INFO - 2025-03-20 20:03:09 --> Helper loaded: url_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: file_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: html_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: form_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: text_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:03:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:03:09 --> Database Driver Class Initialized
INFO - 2025-03-20 20:03:09 --> Email Class Initialized
INFO - 2025-03-20 20:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:03:09 --> Form Validation Class Initialized
INFO - 2025-03-20 20:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:03:09 --> Pagination Class Initialized
INFO - 2025-03-20 20:03:09 --> Controller Class Initialized
DEBUG - 2025-03-20 20:03:09 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:03:09 --> Model Class Initialized
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:03:09 --> Model Class Initialized
DEBUG - 2025-03-20 20:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:03:09 --> Model Class Initialized
INFO - 2025-03-20 20:03:09 --> Final output sent to browser
DEBUG - 2025-03-20 20:03:09 --> Total execution time: 0.0094
INFO - 2025-03-20 20:03:14 --> Config Class Initialized
INFO - 2025-03-20 20:03:14 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:03:14 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:03:14 --> Utf8 Class Initialized
INFO - 2025-03-20 20:03:14 --> URI Class Initialized
DEBUG - 2025-03-20 20:03:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:03:14 --> Router Class Initialized
INFO - 2025-03-20 20:03:14 --> Output Class Initialized
INFO - 2025-03-20 20:03:14 --> Security Class Initialized
DEBUG - 2025-03-20 20:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:03:14 --> Input Class Initialized
INFO - 2025-03-20 20:03:14 --> Language Class Initialized
INFO - 2025-03-20 20:03:14 --> Language Class Initialized
INFO - 2025-03-20 20:03:14 --> Config Class Initialized
INFO - 2025-03-20 20:03:14 --> Loader Class Initialized
INFO - 2025-03-20 20:03:14 --> Helper loaded: url_helper
INFO - 2025-03-20 20:03:14 --> Helper loaded: file_helper
INFO - 2025-03-20 20:03:14 --> Helper loaded: html_helper
INFO - 2025-03-20 20:03:14 --> Helper loaded: form_helper
INFO - 2025-03-20 20:03:14 --> Helper loaded: text_helper
INFO - 2025-03-20 20:03:14 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:03:14 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:03:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:03:14 --> Database Driver Class Initialized
INFO - 2025-03-20 20:03:14 --> Email Class Initialized
INFO - 2025-03-20 20:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:03:14 --> Form Validation Class Initialized
INFO - 2025-03-20 20:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:03:14 --> Pagination Class Initialized
INFO - 2025-03-20 20:03:14 --> Controller Class Initialized
DEBUG - 2025-03-20 20:03:14 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:03:14 --> Model Class Initialized
DEBUG - 2025-03-20 20:03:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:03:14 --> Model Class Initialized
DEBUG - 2025-03-20 20:03:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:03:14 --> Model Class Initialized
INFO - 2025-03-20 20:03:14 --> Final output sent to browser
DEBUG - 2025-03-20 20:03:14 --> Total execution time: 0.0145
INFO - 2025-03-20 20:12:15 --> Config Class Initialized
INFO - 2025-03-20 20:12:15 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:12:15 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:12:15 --> Utf8 Class Initialized
INFO - 2025-03-20 20:12:15 --> URI Class Initialized
DEBUG - 2025-03-20 20:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:12:15 --> Router Class Initialized
INFO - 2025-03-20 20:12:15 --> Output Class Initialized
INFO - 2025-03-20 20:12:15 --> Security Class Initialized
DEBUG - 2025-03-20 20:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:12:15 --> Input Class Initialized
INFO - 2025-03-20 20:12:15 --> Language Class Initialized
INFO - 2025-03-20 20:12:15 --> Language Class Initialized
INFO - 2025-03-20 20:12:15 --> Config Class Initialized
INFO - 2025-03-20 20:12:15 --> Loader Class Initialized
INFO - 2025-03-20 20:12:15 --> Helper loaded: url_helper
INFO - 2025-03-20 20:12:15 --> Helper loaded: file_helper
INFO - 2025-03-20 20:12:15 --> Helper loaded: html_helper
INFO - 2025-03-20 20:12:15 --> Helper loaded: form_helper
INFO - 2025-03-20 20:12:15 --> Helper loaded: text_helper
INFO - 2025-03-20 20:12:15 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:12:15 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:12:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:12:15 --> Database Driver Class Initialized
INFO - 2025-03-20 20:12:15 --> Email Class Initialized
INFO - 2025-03-20 20:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:12:15 --> Form Validation Class Initialized
INFO - 2025-03-20 20:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:12:15 --> Pagination Class Initialized
INFO - 2025-03-20 20:12:15 --> Controller Class Initialized
DEBUG - 2025-03-20 20:12:15 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:12:15 --> Model Class Initialized
DEBUG - 2025-03-20 20:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:12:15 --> Model Class Initialized
DEBUG - 2025-03-20 20:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:12:15 --> Model Class Initialized
INFO - 2025-03-20 20:12:15 --> Final output sent to browser
DEBUG - 2025-03-20 20:12:15 --> Total execution time: 0.0143
INFO - 2025-03-20 20:12:43 --> Config Class Initialized
INFO - 2025-03-20 20:12:43 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:12:43 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:12:43 --> Utf8 Class Initialized
INFO - 2025-03-20 20:12:43 --> URI Class Initialized
DEBUG - 2025-03-20 20:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:12:43 --> Router Class Initialized
INFO - 2025-03-20 20:12:43 --> Output Class Initialized
INFO - 2025-03-20 20:12:43 --> Security Class Initialized
DEBUG - 2025-03-20 20:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:12:43 --> Input Class Initialized
INFO - 2025-03-20 20:12:43 --> Language Class Initialized
INFO - 2025-03-20 20:12:43 --> Language Class Initialized
INFO - 2025-03-20 20:12:43 --> Config Class Initialized
INFO - 2025-03-20 20:12:43 --> Loader Class Initialized
INFO - 2025-03-20 20:12:43 --> Helper loaded: url_helper
INFO - 2025-03-20 20:12:43 --> Helper loaded: file_helper
INFO - 2025-03-20 20:12:43 --> Helper loaded: html_helper
INFO - 2025-03-20 20:12:43 --> Helper loaded: form_helper
INFO - 2025-03-20 20:12:43 --> Helper loaded: text_helper
INFO - 2025-03-20 20:12:43 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:12:43 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:12:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:12:43 --> Database Driver Class Initialized
INFO - 2025-03-20 20:12:43 --> Email Class Initialized
INFO - 2025-03-20 20:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:12:43 --> Form Validation Class Initialized
INFO - 2025-03-20 20:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:12:43 --> Pagination Class Initialized
INFO - 2025-03-20 20:12:43 --> Controller Class Initialized
DEBUG - 2025-03-20 20:12:43 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:12:43 --> Model Class Initialized
DEBUG - 2025-03-20 20:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:12:43 --> Model Class Initialized
DEBUG - 2025-03-20 20:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:12:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:12:43 --> Model Class Initialized
ERROR - 2025-03-20 20:12:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:12:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:12:44 --> Final output sent to browser
DEBUG - 2025-03-20 20:12:44 --> Total execution time: 0.1328
INFO - 2025-03-20 20:12:44 --> Config Class Initialized
INFO - 2025-03-20 20:12:44 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:12:44 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:12:44 --> Utf8 Class Initialized
INFO - 2025-03-20 20:12:44 --> URI Class Initialized
DEBUG - 2025-03-20 20:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:12:44 --> Router Class Initialized
INFO - 2025-03-20 20:12:44 --> Output Class Initialized
INFO - 2025-03-20 20:12:44 --> Security Class Initialized
DEBUG - 2025-03-20 20:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:12:44 --> Input Class Initialized
INFO - 2025-03-20 20:12:44 --> Language Class Initialized
INFO - 2025-03-20 20:12:44 --> Language Class Initialized
INFO - 2025-03-20 20:12:44 --> Config Class Initialized
INFO - 2025-03-20 20:12:44 --> Loader Class Initialized
INFO - 2025-03-20 20:12:44 --> Helper loaded: url_helper
INFO - 2025-03-20 20:12:44 --> Helper loaded: file_helper
INFO - 2025-03-20 20:12:44 --> Helper loaded: html_helper
INFO - 2025-03-20 20:12:44 --> Helper loaded: form_helper
INFO - 2025-03-20 20:12:44 --> Helper loaded: text_helper
INFO - 2025-03-20 20:12:44 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:12:44 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:12:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:12:44 --> Database Driver Class Initialized
INFO - 2025-03-20 20:12:44 --> Email Class Initialized
INFO - 2025-03-20 20:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:12:44 --> Form Validation Class Initialized
INFO - 2025-03-20 20:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:12:44 --> Pagination Class Initialized
INFO - 2025-03-20 20:12:44 --> Controller Class Initialized
DEBUG - 2025-03-20 20:12:44 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:12:44 --> Model Class Initialized
DEBUG - 2025-03-20 20:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:12:44 --> Model Class Initialized
INFO - 2025-03-20 20:12:44 --> Final output sent to browser
DEBUG - 2025-03-20 20:12:44 --> Total execution time: 0.0114
INFO - 2025-03-20 20:12:51 --> Config Class Initialized
INFO - 2025-03-20 20:12:51 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:12:51 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:12:51 --> Utf8 Class Initialized
INFO - 2025-03-20 20:12:51 --> URI Class Initialized
DEBUG - 2025-03-20 20:12:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:12:51 --> Router Class Initialized
INFO - 2025-03-20 20:12:51 --> Output Class Initialized
INFO - 2025-03-20 20:12:51 --> Security Class Initialized
DEBUG - 2025-03-20 20:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:12:51 --> Input Class Initialized
INFO - 2025-03-20 20:12:51 --> Language Class Initialized
INFO - 2025-03-20 20:12:51 --> Language Class Initialized
INFO - 2025-03-20 20:12:51 --> Config Class Initialized
INFO - 2025-03-20 20:12:51 --> Loader Class Initialized
INFO - 2025-03-20 20:12:51 --> Helper loaded: url_helper
INFO - 2025-03-20 20:12:51 --> Helper loaded: file_helper
INFO - 2025-03-20 20:12:51 --> Helper loaded: html_helper
INFO - 2025-03-20 20:12:51 --> Helper loaded: form_helper
INFO - 2025-03-20 20:12:51 --> Helper loaded: text_helper
INFO - 2025-03-20 20:12:51 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:12:51 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:12:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:12:51 --> Database Driver Class Initialized
INFO - 2025-03-20 20:12:51 --> Email Class Initialized
INFO - 2025-03-20 20:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:12:51 --> Form Validation Class Initialized
INFO - 2025-03-20 20:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:12:51 --> Pagination Class Initialized
INFO - 2025-03-20 20:12:51 --> Controller Class Initialized
DEBUG - 2025-03-20 20:12:51 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:12:51 --> Model Class Initialized
DEBUG - 2025-03-20 20:12:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:12:51 --> Model Class Initialized
INFO - 2025-03-20 20:12:51 --> Final output sent to browser
DEBUG - 2025-03-20 20:12:51 --> Total execution time: 0.0090
INFO - 2025-03-20 20:13:26 --> Config Class Initialized
INFO - 2025-03-20 20:13:26 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:13:26 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:13:26 --> Utf8 Class Initialized
INFO - 2025-03-20 20:13:26 --> URI Class Initialized
DEBUG - 2025-03-20 20:13:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:13:26 --> Router Class Initialized
INFO - 2025-03-20 20:13:26 --> Output Class Initialized
INFO - 2025-03-20 20:13:26 --> Security Class Initialized
DEBUG - 2025-03-20 20:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:13:26 --> Input Class Initialized
INFO - 2025-03-20 20:13:26 --> Language Class Initialized
INFO - 2025-03-20 20:13:26 --> Language Class Initialized
INFO - 2025-03-20 20:13:26 --> Config Class Initialized
INFO - 2025-03-20 20:13:26 --> Loader Class Initialized
INFO - 2025-03-20 20:13:26 --> Helper loaded: url_helper
INFO - 2025-03-20 20:13:26 --> Helper loaded: file_helper
INFO - 2025-03-20 20:13:26 --> Helper loaded: html_helper
INFO - 2025-03-20 20:13:26 --> Helper loaded: form_helper
INFO - 2025-03-20 20:13:26 --> Helper loaded: text_helper
INFO - 2025-03-20 20:13:26 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:13:26 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:13:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:13:26 --> Database Driver Class Initialized
INFO - 2025-03-20 20:13:26 --> Email Class Initialized
INFO - 2025-03-20 20:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:13:26 --> Form Validation Class Initialized
INFO - 2025-03-20 20:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:13:26 --> Pagination Class Initialized
INFO - 2025-03-20 20:13:26 --> Controller Class Initialized
DEBUG - 2025-03-20 20:13:26 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:13:26 --> Model Class Initialized
DEBUG - 2025-03-20 20:13:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:13:26 --> Model Class Initialized
INFO - 2025-03-20 20:13:26 --> Final output sent to browser
DEBUG - 2025-03-20 20:13:26 --> Total execution time: 0.0255
INFO - 2025-03-20 20:13:29 --> Config Class Initialized
INFO - 2025-03-20 20:13:29 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:13:29 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:13:29 --> Utf8 Class Initialized
INFO - 2025-03-20 20:13:29 --> URI Class Initialized
DEBUG - 2025-03-20 20:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:13:29 --> Router Class Initialized
INFO - 2025-03-20 20:13:29 --> Output Class Initialized
INFO - 2025-03-20 20:13:29 --> Security Class Initialized
DEBUG - 2025-03-20 20:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:13:29 --> Input Class Initialized
INFO - 2025-03-20 20:13:29 --> Language Class Initialized
INFO - 2025-03-20 20:13:29 --> Language Class Initialized
INFO - 2025-03-20 20:13:29 --> Config Class Initialized
INFO - 2025-03-20 20:13:29 --> Loader Class Initialized
INFO - 2025-03-20 20:13:29 --> Helper loaded: url_helper
INFO - 2025-03-20 20:13:29 --> Helper loaded: file_helper
INFO - 2025-03-20 20:13:29 --> Helper loaded: html_helper
INFO - 2025-03-20 20:13:29 --> Helper loaded: form_helper
INFO - 2025-03-20 20:13:29 --> Helper loaded: text_helper
INFO - 2025-03-20 20:13:29 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:13:29 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:13:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:13:29 --> Database Driver Class Initialized
INFO - 2025-03-20 20:13:29 --> Email Class Initialized
INFO - 2025-03-20 20:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:13:29 --> Form Validation Class Initialized
INFO - 2025-03-20 20:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:13:29 --> Pagination Class Initialized
INFO - 2025-03-20 20:13:29 --> Controller Class Initialized
DEBUG - 2025-03-20 20:13:29 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:13:29 --> Model Class Initialized
DEBUG - 2025-03-20 20:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:13:29 --> Model Class Initialized
INFO - 2025-03-20 20:13:29 --> Final output sent to browser
DEBUG - 2025-03-20 20:13:29 --> Total execution time: 0.0070
INFO - 2025-03-20 20:13:38 --> Config Class Initialized
INFO - 2025-03-20 20:13:38 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:13:38 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:13:38 --> Utf8 Class Initialized
INFO - 2025-03-20 20:13:38 --> URI Class Initialized
DEBUG - 2025-03-20 20:13:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:13:38 --> Router Class Initialized
INFO - 2025-03-20 20:13:38 --> Output Class Initialized
INFO - 2025-03-20 20:13:38 --> Security Class Initialized
DEBUG - 2025-03-20 20:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:13:38 --> Input Class Initialized
INFO - 2025-03-20 20:13:38 --> Language Class Initialized
INFO - 2025-03-20 20:13:38 --> Language Class Initialized
INFO - 2025-03-20 20:13:38 --> Config Class Initialized
INFO - 2025-03-20 20:13:38 --> Loader Class Initialized
INFO - 2025-03-20 20:13:38 --> Helper loaded: url_helper
INFO - 2025-03-20 20:13:38 --> Helper loaded: file_helper
INFO - 2025-03-20 20:13:38 --> Helper loaded: html_helper
INFO - 2025-03-20 20:13:38 --> Helper loaded: form_helper
INFO - 2025-03-20 20:13:38 --> Helper loaded: text_helper
INFO - 2025-03-20 20:13:38 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:13:38 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:13:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:13:38 --> Database Driver Class Initialized
INFO - 2025-03-20 20:13:38 --> Email Class Initialized
INFO - 2025-03-20 20:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:13:38 --> Form Validation Class Initialized
INFO - 2025-03-20 20:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:13:38 --> Pagination Class Initialized
INFO - 2025-03-20 20:13:38 --> Controller Class Initialized
DEBUG - 2025-03-20 20:13:38 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:13:38 --> Model Class Initialized
DEBUG - 2025-03-20 20:13:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:13:38 --> Model Class Initialized
INFO - 2025-03-20 20:13:38 --> Final output sent to browser
DEBUG - 2025-03-20 20:13:38 --> Total execution time: 0.0092
INFO - 2025-03-20 20:13:46 --> Config Class Initialized
INFO - 2025-03-20 20:13:46 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:13:46 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:13:46 --> Utf8 Class Initialized
INFO - 2025-03-20 20:13:46 --> URI Class Initialized
DEBUG - 2025-03-20 20:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:13:46 --> Router Class Initialized
INFO - 2025-03-20 20:13:46 --> Output Class Initialized
INFO - 2025-03-20 20:13:46 --> Security Class Initialized
DEBUG - 2025-03-20 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:13:46 --> Input Class Initialized
INFO - 2025-03-20 20:13:46 --> Language Class Initialized
INFO - 2025-03-20 20:13:46 --> Language Class Initialized
INFO - 2025-03-20 20:13:46 --> Config Class Initialized
INFO - 2025-03-20 20:13:46 --> Loader Class Initialized
INFO - 2025-03-20 20:13:46 --> Helper loaded: url_helper
INFO - 2025-03-20 20:13:46 --> Helper loaded: file_helper
INFO - 2025-03-20 20:13:46 --> Helper loaded: html_helper
INFO - 2025-03-20 20:13:46 --> Helper loaded: form_helper
INFO - 2025-03-20 20:13:46 --> Helper loaded: text_helper
INFO - 2025-03-20 20:13:46 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:13:46 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:13:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:13:46 --> Database Driver Class Initialized
INFO - 2025-03-20 20:13:46 --> Email Class Initialized
INFO - 2025-03-20 20:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:13:46 --> Form Validation Class Initialized
INFO - 2025-03-20 20:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:13:46 --> Pagination Class Initialized
INFO - 2025-03-20 20:13:46 --> Controller Class Initialized
DEBUG - 2025-03-20 20:13:46 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:13:46 --> Model Class Initialized
DEBUG - 2025-03-20 20:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:13:46 --> Model Class Initialized
INFO - 2025-03-20 20:13:46 --> Final output sent to browser
DEBUG - 2025-03-20 20:13:46 --> Total execution time: 0.0092
INFO - 2025-03-20 20:17:02 --> Config Class Initialized
INFO - 2025-03-20 20:17:02 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:17:02 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:17:02 --> Utf8 Class Initialized
INFO - 2025-03-20 20:17:02 --> URI Class Initialized
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:17:02 --> Router Class Initialized
INFO - 2025-03-20 20:17:02 --> Output Class Initialized
INFO - 2025-03-20 20:17:02 --> Security Class Initialized
DEBUG - 2025-03-20 20:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:17:02 --> Input Class Initialized
INFO - 2025-03-20 20:17:02 --> Language Class Initialized
INFO - 2025-03-20 20:17:02 --> Language Class Initialized
INFO - 2025-03-20 20:17:02 --> Config Class Initialized
INFO - 2025-03-20 20:17:02 --> Loader Class Initialized
INFO - 2025-03-20 20:17:02 --> Helper loaded: url_helper
INFO - 2025-03-20 20:17:02 --> Helper loaded: file_helper
INFO - 2025-03-20 20:17:02 --> Helper loaded: html_helper
INFO - 2025-03-20 20:17:02 --> Helper loaded: form_helper
INFO - 2025-03-20 20:17:02 --> Helper loaded: text_helper
INFO - 2025-03-20 20:17:02 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:17:02 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:17:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:17:02 --> Database Driver Class Initialized
INFO - 2025-03-20 20:17:02 --> Email Class Initialized
INFO - 2025-03-20 20:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:17:02 --> Form Validation Class Initialized
INFO - 2025-03-20 20:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:17:02 --> Pagination Class Initialized
INFO - 2025-03-20 20:17:02 --> Controller Class Initialized
DEBUG - 2025-03-20 20:17:02 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:17:02 --> Model Class Initialized
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:17:02 --> Model Class Initialized
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:17:02 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:17:02 --> Model Class Initialized
ERROR - 2025-03-20 20:17:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:17:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:17:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:17:02 --> Final output sent to browser
DEBUG - 2025-03-20 20:17:02 --> Total execution time: 0.1414
INFO - 2025-03-20 20:17:03 --> Config Class Initialized
INFO - 2025-03-20 20:17:03 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:17:03 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:17:03 --> Utf8 Class Initialized
INFO - 2025-03-20 20:17:03 --> URI Class Initialized
DEBUG - 2025-03-20 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:17:03 --> Router Class Initialized
INFO - 2025-03-20 20:17:03 --> Output Class Initialized
INFO - 2025-03-20 20:17:03 --> Security Class Initialized
DEBUG - 2025-03-20 20:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:17:03 --> Input Class Initialized
INFO - 2025-03-20 20:17:03 --> Language Class Initialized
INFO - 2025-03-20 20:17:03 --> Language Class Initialized
INFO - 2025-03-20 20:17:03 --> Config Class Initialized
INFO - 2025-03-20 20:17:03 --> Loader Class Initialized
INFO - 2025-03-20 20:17:03 --> Helper loaded: url_helper
INFO - 2025-03-20 20:17:03 --> Helper loaded: file_helper
INFO - 2025-03-20 20:17:03 --> Helper loaded: html_helper
INFO - 2025-03-20 20:17:03 --> Helper loaded: form_helper
INFO - 2025-03-20 20:17:03 --> Helper loaded: text_helper
INFO - 2025-03-20 20:17:03 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:17:03 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:17:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:17:03 --> Database Driver Class Initialized
INFO - 2025-03-20 20:17:03 --> Email Class Initialized
INFO - 2025-03-20 20:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:17:03 --> Form Validation Class Initialized
INFO - 2025-03-20 20:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:17:03 --> Pagination Class Initialized
INFO - 2025-03-20 20:17:03 --> Controller Class Initialized
DEBUG - 2025-03-20 20:17:03 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:17:03 --> Model Class Initialized
DEBUG - 2025-03-20 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:17:03 --> Model Class Initialized
DEBUG - 2025-03-20 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:17:03 --> Model Class Initialized
INFO - 2025-03-20 20:17:03 --> Final output sent to browser
DEBUG - 2025-03-20 20:17:03 --> Total execution time: 0.0158
INFO - 2025-03-20 20:17:07 --> Config Class Initialized
INFO - 2025-03-20 20:17:07 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:17:07 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:17:07 --> Utf8 Class Initialized
INFO - 2025-03-20 20:17:07 --> URI Class Initialized
DEBUG - 2025-03-20 20:17:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:17:07 --> Router Class Initialized
INFO - 2025-03-20 20:17:07 --> Output Class Initialized
INFO - 2025-03-20 20:17:07 --> Security Class Initialized
DEBUG - 2025-03-20 20:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:17:07 --> Input Class Initialized
INFO - 2025-03-20 20:17:07 --> Language Class Initialized
INFO - 2025-03-20 20:17:07 --> Language Class Initialized
INFO - 2025-03-20 20:17:07 --> Config Class Initialized
INFO - 2025-03-20 20:17:07 --> Loader Class Initialized
INFO - 2025-03-20 20:17:07 --> Helper loaded: url_helper
INFO - 2025-03-20 20:17:07 --> Helper loaded: file_helper
INFO - 2025-03-20 20:17:07 --> Helper loaded: html_helper
INFO - 2025-03-20 20:17:07 --> Helper loaded: form_helper
INFO - 2025-03-20 20:17:07 --> Helper loaded: text_helper
INFO - 2025-03-20 20:17:07 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:17:07 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:17:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:17:07 --> Database Driver Class Initialized
INFO - 2025-03-20 20:17:07 --> Email Class Initialized
INFO - 2025-03-20 20:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:17:07 --> Form Validation Class Initialized
INFO - 2025-03-20 20:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:17:07 --> Pagination Class Initialized
INFO - 2025-03-20 20:17:07 --> Controller Class Initialized
DEBUG - 2025-03-20 20:17:07 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:17:07 --> Model Class Initialized
DEBUG - 2025-03-20 20:17:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:17:07 --> Model Class Initialized
DEBUG - 2025-03-20 20:17:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:17:07 --> Model Class Initialized
INFO - 2025-03-20 20:17:07 --> Final output sent to browser
DEBUG - 2025-03-20 20:17:07 --> Total execution time: 0.0138
INFO - 2025-03-20 20:20:52 --> Config Class Initialized
INFO - 2025-03-20 20:20:52 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:20:52 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:20:52 --> Utf8 Class Initialized
INFO - 2025-03-20 20:20:52 --> URI Class Initialized
DEBUG - 2025-03-20 20:20:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:20:52 --> Router Class Initialized
INFO - 2025-03-20 20:20:52 --> Output Class Initialized
INFO - 2025-03-20 20:20:52 --> Security Class Initialized
DEBUG - 2025-03-20 20:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:20:52 --> Input Class Initialized
INFO - 2025-03-20 20:20:52 --> Language Class Initialized
INFO - 2025-03-20 20:20:52 --> Language Class Initialized
INFO - 2025-03-20 20:20:52 --> Config Class Initialized
INFO - 2025-03-20 20:20:52 --> Loader Class Initialized
INFO - 2025-03-20 20:20:52 --> Helper loaded: url_helper
INFO - 2025-03-20 20:20:52 --> Helper loaded: file_helper
INFO - 2025-03-20 20:20:52 --> Helper loaded: html_helper
INFO - 2025-03-20 20:20:52 --> Helper loaded: form_helper
INFO - 2025-03-20 20:20:52 --> Helper loaded: text_helper
INFO - 2025-03-20 20:20:52 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:20:52 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:20:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:20:52 --> Database Driver Class Initialized
INFO - 2025-03-20 20:20:52 --> Email Class Initialized
INFO - 2025-03-20 20:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:20:52 --> Form Validation Class Initialized
INFO - 2025-03-20 20:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:20:52 --> Pagination Class Initialized
INFO - 2025-03-20 20:20:52 --> Controller Class Initialized
DEBUG - 2025-03-20 20:20:52 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:20:52 --> Model Class Initialized
DEBUG - 2025-03-20 20:20:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:20:52 --> Model Class Initialized
DEBUG - 2025-03-20 20:20:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:20:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:20:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:20:52 --> Model Class Initialized
ERROR - 2025-03-20 20:20:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:20:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:20:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:20:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:20:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:20:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:20:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:20:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:20:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:20:53 --> Final output sent to browser
DEBUG - 2025-03-20 20:20:53 --> Total execution time: 0.1465
INFO - 2025-03-20 20:20:53 --> Config Class Initialized
INFO - 2025-03-20 20:20:53 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:20:53 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:20:53 --> Utf8 Class Initialized
INFO - 2025-03-20 20:20:53 --> URI Class Initialized
DEBUG - 2025-03-20 20:20:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:20:53 --> Router Class Initialized
INFO - 2025-03-20 20:20:53 --> Output Class Initialized
INFO - 2025-03-20 20:20:53 --> Security Class Initialized
DEBUG - 2025-03-20 20:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:20:53 --> Input Class Initialized
INFO - 2025-03-20 20:20:53 --> Language Class Initialized
INFO - 2025-03-20 20:20:53 --> Language Class Initialized
INFO - 2025-03-20 20:20:53 --> Config Class Initialized
INFO - 2025-03-20 20:20:53 --> Loader Class Initialized
INFO - 2025-03-20 20:20:53 --> Helper loaded: url_helper
INFO - 2025-03-20 20:20:53 --> Helper loaded: file_helper
INFO - 2025-03-20 20:20:53 --> Helper loaded: html_helper
INFO - 2025-03-20 20:20:53 --> Helper loaded: form_helper
INFO - 2025-03-20 20:20:53 --> Helper loaded: text_helper
INFO - 2025-03-20 20:20:53 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:20:53 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:20:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:20:53 --> Database Driver Class Initialized
INFO - 2025-03-20 20:20:53 --> Email Class Initialized
INFO - 2025-03-20 20:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:20:53 --> Form Validation Class Initialized
INFO - 2025-03-20 20:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:20:53 --> Pagination Class Initialized
INFO - 2025-03-20 20:20:53 --> Controller Class Initialized
DEBUG - 2025-03-20 20:20:53 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:20:53 --> Model Class Initialized
DEBUG - 2025-03-20 20:20:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:20:53 --> Model Class Initialized
INFO - 2025-03-20 20:20:53 --> Final output sent to browser
DEBUG - 2025-03-20 20:20:53 --> Total execution time: 0.0061
INFO - 2025-03-20 20:21:20 --> Config Class Initialized
INFO - 2025-03-20 20:21:20 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:21:20 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:21:20 --> Utf8 Class Initialized
INFO - 2025-03-20 20:21:20 --> URI Class Initialized
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:21:20 --> Router Class Initialized
INFO - 2025-03-20 20:21:20 --> Output Class Initialized
INFO - 2025-03-20 20:21:20 --> Security Class Initialized
DEBUG - 2025-03-20 20:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:21:20 --> Input Class Initialized
INFO - 2025-03-20 20:21:20 --> Language Class Initialized
INFO - 2025-03-20 20:21:20 --> Language Class Initialized
INFO - 2025-03-20 20:21:20 --> Config Class Initialized
INFO - 2025-03-20 20:21:20 --> Loader Class Initialized
INFO - 2025-03-20 20:21:20 --> Helper loaded: url_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: file_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: html_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: form_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: text_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:21:20 --> Database Driver Class Initialized
INFO - 2025-03-20 20:21:20 --> Email Class Initialized
INFO - 2025-03-20 20:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:21:20 --> Form Validation Class Initialized
INFO - 2025-03-20 20:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:21:20 --> Pagination Class Initialized
INFO - 2025-03-20 20:21:20 --> Controller Class Initialized
DEBUG - 2025-03-20 20:21:20 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:21:20 --> Model Class Initialized
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:21:20 --> Model Class Initialized
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:21:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:21:20 --> Model Class Initialized
ERROR - 2025-03-20 20:21:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:21:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:21:20 --> Final output sent to browser
DEBUG - 2025-03-20 20:21:20 --> Total execution time: 0.1063
INFO - 2025-03-20 20:21:20 --> Config Class Initialized
INFO - 2025-03-20 20:21:20 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:21:20 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:21:20 --> Utf8 Class Initialized
INFO - 2025-03-20 20:21:20 --> URI Class Initialized
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:21:20 --> Router Class Initialized
INFO - 2025-03-20 20:21:20 --> Output Class Initialized
INFO - 2025-03-20 20:21:20 --> Security Class Initialized
DEBUG - 2025-03-20 20:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:21:20 --> Input Class Initialized
INFO - 2025-03-20 20:21:20 --> Language Class Initialized
INFO - 2025-03-20 20:21:20 --> Language Class Initialized
INFO - 2025-03-20 20:21:20 --> Config Class Initialized
INFO - 2025-03-20 20:21:20 --> Loader Class Initialized
INFO - 2025-03-20 20:21:20 --> Helper loaded: url_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: file_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: html_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: form_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: text_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:21:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:21:20 --> Database Driver Class Initialized
INFO - 2025-03-20 20:21:20 --> Email Class Initialized
INFO - 2025-03-20 20:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:21:20 --> Form Validation Class Initialized
INFO - 2025-03-20 20:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:21:20 --> Pagination Class Initialized
INFO - 2025-03-20 20:21:20 --> Controller Class Initialized
DEBUG - 2025-03-20 20:21:20 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:21:20 --> Model Class Initialized
DEBUG - 2025-03-20 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:21:20 --> Model Class Initialized
INFO - 2025-03-20 20:21:20 --> Final output sent to browser
DEBUG - 2025-03-20 20:21:20 --> Total execution time: 0.0170
INFO - 2025-03-20 20:21:27 --> Config Class Initialized
INFO - 2025-03-20 20:21:27 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:21:27 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:21:27 --> Utf8 Class Initialized
INFO - 2025-03-20 20:21:27 --> URI Class Initialized
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:21:27 --> Router Class Initialized
INFO - 2025-03-20 20:21:27 --> Output Class Initialized
INFO - 2025-03-20 20:21:27 --> Security Class Initialized
DEBUG - 2025-03-20 20:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:21:27 --> Input Class Initialized
INFO - 2025-03-20 20:21:27 --> Language Class Initialized
INFO - 2025-03-20 20:21:27 --> Language Class Initialized
INFO - 2025-03-20 20:21:27 --> Config Class Initialized
INFO - 2025-03-20 20:21:27 --> Loader Class Initialized
INFO - 2025-03-20 20:21:27 --> Helper loaded: url_helper
INFO - 2025-03-20 20:21:27 --> Helper loaded: file_helper
INFO - 2025-03-20 20:21:27 --> Helper loaded: html_helper
INFO - 2025-03-20 20:21:27 --> Helper loaded: form_helper
INFO - 2025-03-20 20:21:27 --> Helper loaded: text_helper
INFO - 2025-03-20 20:21:27 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:21:27 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:21:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:21:27 --> Database Driver Class Initialized
INFO - 2025-03-20 20:21:27 --> Email Class Initialized
INFO - 2025-03-20 20:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:21:27 --> Form Validation Class Initialized
INFO - 2025-03-20 20:21:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:21:27 --> Pagination Class Initialized
INFO - 2025-03-20 20:21:27 --> Controller Class Initialized
DEBUG - 2025-03-20 20:21:27 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:21:27 --> Model Class Initialized
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:21:27 --> Model Class Initialized
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:21:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:21:27 --> Model Class Initialized
ERROR - 2025-03-20 20:21:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:21:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:21:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:21:27 --> Final output sent to browser
DEBUG - 2025-03-20 20:21:27 --> Total execution time: 0.1330
INFO - 2025-03-20 20:21:28 --> Config Class Initialized
INFO - 2025-03-20 20:21:28 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:21:28 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:21:28 --> Utf8 Class Initialized
INFO - 2025-03-20 20:21:28 --> URI Class Initialized
DEBUG - 2025-03-20 20:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:21:28 --> Router Class Initialized
INFO - 2025-03-20 20:21:28 --> Output Class Initialized
INFO - 2025-03-20 20:21:28 --> Security Class Initialized
DEBUG - 2025-03-20 20:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:21:28 --> Input Class Initialized
INFO - 2025-03-20 20:21:28 --> Language Class Initialized
INFO - 2025-03-20 20:21:28 --> Language Class Initialized
INFO - 2025-03-20 20:21:28 --> Config Class Initialized
INFO - 2025-03-20 20:21:28 --> Loader Class Initialized
INFO - 2025-03-20 20:21:28 --> Helper loaded: url_helper
INFO - 2025-03-20 20:21:28 --> Helper loaded: file_helper
INFO - 2025-03-20 20:21:28 --> Helper loaded: html_helper
INFO - 2025-03-20 20:21:28 --> Helper loaded: form_helper
INFO - 2025-03-20 20:21:28 --> Helper loaded: text_helper
INFO - 2025-03-20 20:21:28 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:21:28 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:21:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:21:28 --> Database Driver Class Initialized
INFO - 2025-03-20 20:21:28 --> Email Class Initialized
INFO - 2025-03-20 20:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:21:28 --> Form Validation Class Initialized
INFO - 2025-03-20 20:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:21:28 --> Pagination Class Initialized
INFO - 2025-03-20 20:21:28 --> Controller Class Initialized
DEBUG - 2025-03-20 20:21:28 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:21:28 --> Model Class Initialized
DEBUG - 2025-03-20 20:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:21:28 --> Model Class Initialized
INFO - 2025-03-20 20:21:28 --> Final output sent to browser
DEBUG - 2025-03-20 20:21:28 --> Total execution time: 0.0095
INFO - 2025-03-20 20:21:39 --> Config Class Initialized
INFO - 2025-03-20 20:21:39 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:21:39 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:21:39 --> Utf8 Class Initialized
INFO - 2025-03-20 20:21:39 --> URI Class Initialized
DEBUG - 2025-03-20 20:21:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:21:39 --> Router Class Initialized
INFO - 2025-03-20 20:21:39 --> Output Class Initialized
INFO - 2025-03-20 20:21:39 --> Security Class Initialized
DEBUG - 2025-03-20 20:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:21:39 --> Input Class Initialized
INFO - 2025-03-20 20:21:39 --> Language Class Initialized
INFO - 2025-03-20 20:21:39 --> Language Class Initialized
INFO - 2025-03-20 20:21:39 --> Config Class Initialized
INFO - 2025-03-20 20:21:39 --> Loader Class Initialized
INFO - 2025-03-20 20:21:39 --> Helper loaded: url_helper
INFO - 2025-03-20 20:21:39 --> Helper loaded: file_helper
INFO - 2025-03-20 20:21:39 --> Helper loaded: html_helper
INFO - 2025-03-20 20:21:39 --> Helper loaded: form_helper
INFO - 2025-03-20 20:21:39 --> Helper loaded: text_helper
INFO - 2025-03-20 20:21:39 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:21:39 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:21:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:21:39 --> Database Driver Class Initialized
INFO - 2025-03-20 20:21:39 --> Email Class Initialized
INFO - 2025-03-20 20:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:21:39 --> Form Validation Class Initialized
INFO - 2025-03-20 20:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:21:39 --> Pagination Class Initialized
INFO - 2025-03-20 20:21:39 --> Controller Class Initialized
DEBUG - 2025-03-20 20:21:39 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:21:39 --> Model Class Initialized
DEBUG - 2025-03-20 20:21:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:21:39 --> Model Class Initialized
INFO - 2025-03-20 20:21:39 --> Final output sent to browser
DEBUG - 2025-03-20 20:21:39 --> Total execution time: 0.0101
INFO - 2025-03-20 20:22:20 --> Config Class Initialized
INFO - 2025-03-20 20:22:20 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:22:20 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:22:20 --> Utf8 Class Initialized
INFO - 2025-03-20 20:22:20 --> URI Class Initialized
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:22:20 --> Router Class Initialized
INFO - 2025-03-20 20:22:20 --> Output Class Initialized
INFO - 2025-03-20 20:22:20 --> Security Class Initialized
DEBUG - 2025-03-20 20:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:22:20 --> Input Class Initialized
INFO - 2025-03-20 20:22:20 --> Language Class Initialized
INFO - 2025-03-20 20:22:20 --> Language Class Initialized
INFO - 2025-03-20 20:22:20 --> Config Class Initialized
INFO - 2025-03-20 20:22:20 --> Loader Class Initialized
INFO - 2025-03-20 20:22:20 --> Helper loaded: url_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: file_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: html_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: form_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: text_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:22:20 --> Database Driver Class Initialized
INFO - 2025-03-20 20:22:20 --> Email Class Initialized
INFO - 2025-03-20 20:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:22:20 --> Form Validation Class Initialized
INFO - 2025-03-20 20:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:22:20 --> Pagination Class Initialized
INFO - 2025-03-20 20:22:20 --> Controller Class Initialized
DEBUG - 2025-03-20 20:22:20 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:22:20 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:22:20 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:22:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:22:20 --> Model Class Initialized
ERROR - 2025-03-20 20:22:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:22:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:22:20 --> Final output sent to browser
DEBUG - 2025-03-20 20:22:20 --> Total execution time: 0.1603
INFO - 2025-03-20 20:22:20 --> Config Class Initialized
INFO - 2025-03-20 20:22:20 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:22:20 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:22:20 --> Utf8 Class Initialized
INFO - 2025-03-20 20:22:20 --> URI Class Initialized
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:22:20 --> Router Class Initialized
INFO - 2025-03-20 20:22:20 --> Output Class Initialized
INFO - 2025-03-20 20:22:20 --> Security Class Initialized
DEBUG - 2025-03-20 20:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:22:20 --> Input Class Initialized
INFO - 2025-03-20 20:22:20 --> Language Class Initialized
INFO - 2025-03-20 20:22:20 --> Language Class Initialized
INFO - 2025-03-20 20:22:20 --> Config Class Initialized
INFO - 2025-03-20 20:22:20 --> Loader Class Initialized
INFO - 2025-03-20 20:22:20 --> Helper loaded: url_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: file_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: html_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: form_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: text_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:22:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:22:20 --> Database Driver Class Initialized
INFO - 2025-03-20 20:22:20 --> Email Class Initialized
INFO - 2025-03-20 20:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:22:20 --> Form Validation Class Initialized
INFO - 2025-03-20 20:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:22:20 --> Pagination Class Initialized
INFO - 2025-03-20 20:22:20 --> Controller Class Initialized
DEBUG - 2025-03-20 20:22:20 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:22:20 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:22:20 --> Model Class Initialized
INFO - 2025-03-20 20:22:20 --> Final output sent to browser
DEBUG - 2025-03-20 20:22:20 --> Total execution time: 0.0098
INFO - 2025-03-20 20:22:42 --> Config Class Initialized
INFO - 2025-03-20 20:22:42 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:22:42 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:22:42 --> Utf8 Class Initialized
INFO - 2025-03-20 20:22:42 --> URI Class Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-20 20:22:42 --> Router Class Initialized
INFO - 2025-03-20 20:22:42 --> Output Class Initialized
INFO - 2025-03-20 20:22:42 --> Security Class Initialized
DEBUG - 2025-03-20 20:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:22:42 --> Input Class Initialized
INFO - 2025-03-20 20:22:42 --> Language Class Initialized
INFO - 2025-03-20 20:22:42 --> Language Class Initialized
INFO - 2025-03-20 20:22:42 --> Config Class Initialized
INFO - 2025-03-20 20:22:42 --> Loader Class Initialized
INFO - 2025-03-20 20:22:42 --> Helper loaded: url_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: file_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: html_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: form_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: text_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:22:42 --> Database Driver Class Initialized
INFO - 2025-03-20 20:22:42 --> Email Class Initialized
INFO - 2025-03-20 20:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:22:42 --> Form Validation Class Initialized
INFO - 2025-03-20 20:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:22:42 --> Pagination Class Initialized
INFO - 2025-03-20 20:22:42 --> Controller Class Initialized
DEBUG - 2025-03-20 20:22:42 --> Purchase MX_Controller Initialized
INFO - 2025-03-20 20:22:42 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-20 20:22:42 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:22:42 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:22:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:22:42 --> Model Class Initialized
ERROR - 2025-03-20 20:22:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:22:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:22:42 --> Final output sent to browser
DEBUG - 2025-03-20 20:22:42 --> Total execution time: 0.1318
INFO - 2025-03-20 20:22:42 --> Config Class Initialized
INFO - 2025-03-20 20:22:42 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:22:42 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:22:42 --> Utf8 Class Initialized
INFO - 2025-03-20 20:22:42 --> URI Class Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-20 20:22:42 --> Router Class Initialized
INFO - 2025-03-20 20:22:42 --> Output Class Initialized
INFO - 2025-03-20 20:22:42 --> Security Class Initialized
DEBUG - 2025-03-20 20:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:22:42 --> Input Class Initialized
INFO - 2025-03-20 20:22:42 --> Language Class Initialized
INFO - 2025-03-20 20:22:42 --> Language Class Initialized
INFO - 2025-03-20 20:22:42 --> Config Class Initialized
INFO - 2025-03-20 20:22:42 --> Loader Class Initialized
INFO - 2025-03-20 20:22:42 --> Helper loaded: url_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: file_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: html_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: form_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: text_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:22:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:22:42 --> Database Driver Class Initialized
INFO - 2025-03-20 20:22:42 --> Email Class Initialized
INFO - 2025-03-20 20:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:22:42 --> Form Validation Class Initialized
INFO - 2025-03-20 20:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:22:42 --> Pagination Class Initialized
INFO - 2025-03-20 20:22:42 --> Controller Class Initialized
DEBUG - 2025-03-20 20:22:42 --> Purchase MX_Controller Initialized
INFO - 2025-03-20 20:22:42 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-20 20:22:42 --> Model Class Initialized
DEBUG - 2025-03-20 20:22:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:22:42 --> Model Class Initialized
INFO - 2025-03-20 20:22:42 --> Final output sent to browser
DEBUG - 2025-03-20 20:22:42 --> Total execution time: 0.0283
INFO - 2025-03-20 20:23:49 --> Config Class Initialized
INFO - 2025-03-20 20:23:49 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:23:49 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:23:49 --> Utf8 Class Initialized
INFO - 2025-03-20 20:23:49 --> URI Class Initialized
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:23:49 --> Router Class Initialized
INFO - 2025-03-20 20:23:49 --> Output Class Initialized
INFO - 2025-03-20 20:23:49 --> Security Class Initialized
DEBUG - 2025-03-20 20:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:23:49 --> Input Class Initialized
INFO - 2025-03-20 20:23:49 --> Language Class Initialized
INFO - 2025-03-20 20:23:49 --> Language Class Initialized
INFO - 2025-03-20 20:23:49 --> Config Class Initialized
INFO - 2025-03-20 20:23:49 --> Loader Class Initialized
INFO - 2025-03-20 20:23:49 --> Helper loaded: url_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: file_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: html_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: form_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: text_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:23:49 --> Database Driver Class Initialized
INFO - 2025-03-20 20:23:49 --> Email Class Initialized
INFO - 2025-03-20 20:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:23:49 --> Form Validation Class Initialized
INFO - 2025-03-20 20:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:23:49 --> Pagination Class Initialized
INFO - 2025-03-20 20:23:49 --> Controller Class Initialized
DEBUG - 2025-03-20 20:23:49 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:23:49 --> Model Class Initialized
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:23:49 --> Model Class Initialized
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:23:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:23:49 --> Model Class Initialized
ERROR - 2025-03-20 20:23:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:23:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:23:49 --> Final output sent to browser
DEBUG - 2025-03-20 20:23:49 --> Total execution time: 0.1345
INFO - 2025-03-20 20:23:49 --> Config Class Initialized
INFO - 2025-03-20 20:23:49 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:23:49 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:23:49 --> Utf8 Class Initialized
INFO - 2025-03-20 20:23:49 --> URI Class Initialized
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:23:49 --> Router Class Initialized
INFO - 2025-03-20 20:23:49 --> Output Class Initialized
INFO - 2025-03-20 20:23:49 --> Security Class Initialized
DEBUG - 2025-03-20 20:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:23:49 --> Input Class Initialized
INFO - 2025-03-20 20:23:49 --> Language Class Initialized
INFO - 2025-03-20 20:23:49 --> Language Class Initialized
INFO - 2025-03-20 20:23:49 --> Config Class Initialized
INFO - 2025-03-20 20:23:49 --> Loader Class Initialized
INFO - 2025-03-20 20:23:49 --> Helper loaded: url_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: file_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: html_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: form_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: text_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:23:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:23:49 --> Database Driver Class Initialized
INFO - 2025-03-20 20:23:49 --> Email Class Initialized
INFO - 2025-03-20 20:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:23:49 --> Form Validation Class Initialized
INFO - 2025-03-20 20:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:23:49 --> Pagination Class Initialized
INFO - 2025-03-20 20:23:49 --> Controller Class Initialized
DEBUG - 2025-03-20 20:23:49 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:23:49 --> Model Class Initialized
DEBUG - 2025-03-20 20:23:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:23:49 --> Model Class Initialized
INFO - 2025-03-20 20:23:49 --> Final output sent to browser
DEBUG - 2025-03-20 20:23:49 --> Total execution time: 0.0093
INFO - 2025-03-20 20:26:10 --> Config Class Initialized
INFO - 2025-03-20 20:26:10 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:26:10 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:26:10 --> Utf8 Class Initialized
INFO - 2025-03-20 20:26:10 --> URI Class Initialized
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:26:10 --> Router Class Initialized
INFO - 2025-03-20 20:26:10 --> Output Class Initialized
INFO - 2025-03-20 20:26:10 --> Security Class Initialized
DEBUG - 2025-03-20 20:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:26:10 --> Input Class Initialized
INFO - 2025-03-20 20:26:10 --> Language Class Initialized
INFO - 2025-03-20 20:26:10 --> Language Class Initialized
INFO - 2025-03-20 20:26:10 --> Config Class Initialized
INFO - 2025-03-20 20:26:10 --> Loader Class Initialized
INFO - 2025-03-20 20:26:10 --> Helper loaded: url_helper
INFO - 2025-03-20 20:26:10 --> Helper loaded: file_helper
INFO - 2025-03-20 20:26:10 --> Helper loaded: html_helper
INFO - 2025-03-20 20:26:10 --> Helper loaded: form_helper
INFO - 2025-03-20 20:26:10 --> Helper loaded: text_helper
INFO - 2025-03-20 20:26:10 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:26:10 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:26:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:26:10 --> Database Driver Class Initialized
INFO - 2025-03-20 20:26:10 --> Email Class Initialized
INFO - 2025-03-20 20:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:26:10 --> Form Validation Class Initialized
INFO - 2025-03-20 20:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:26:10 --> Pagination Class Initialized
INFO - 2025-03-20 20:26:10 --> Controller Class Initialized
DEBUG - 2025-03-20 20:26:10 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:26:10 --> Model Class Initialized
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:26:10 --> Model Class Initialized
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:26:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:26:10 --> Model Class Initialized
ERROR - 2025-03-20 20:26:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:26:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:26:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:26:10 --> Final output sent to browser
DEBUG - 2025-03-20 20:26:10 --> Total execution time: 0.1574
INFO - 2025-03-20 20:26:11 --> Config Class Initialized
INFO - 2025-03-20 20:26:11 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:26:11 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:26:11 --> Utf8 Class Initialized
INFO - 2025-03-20 20:26:11 --> URI Class Initialized
DEBUG - 2025-03-20 20:26:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:26:11 --> Router Class Initialized
INFO - 2025-03-20 20:26:11 --> Output Class Initialized
INFO - 2025-03-20 20:26:11 --> Security Class Initialized
DEBUG - 2025-03-20 20:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:26:11 --> Input Class Initialized
INFO - 2025-03-20 20:26:11 --> Language Class Initialized
INFO - 2025-03-20 20:26:11 --> Language Class Initialized
INFO - 2025-03-20 20:26:11 --> Config Class Initialized
INFO - 2025-03-20 20:26:11 --> Loader Class Initialized
INFO - 2025-03-20 20:26:11 --> Helper loaded: url_helper
INFO - 2025-03-20 20:26:11 --> Helper loaded: file_helper
INFO - 2025-03-20 20:26:11 --> Helper loaded: html_helper
INFO - 2025-03-20 20:26:11 --> Helper loaded: form_helper
INFO - 2025-03-20 20:26:11 --> Helper loaded: text_helper
INFO - 2025-03-20 20:26:11 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:26:11 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:26:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:26:11 --> Database Driver Class Initialized
INFO - 2025-03-20 20:26:11 --> Email Class Initialized
INFO - 2025-03-20 20:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:26:11 --> Form Validation Class Initialized
INFO - 2025-03-20 20:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:26:11 --> Pagination Class Initialized
INFO - 2025-03-20 20:26:11 --> Controller Class Initialized
DEBUG - 2025-03-20 20:26:11 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:26:11 --> Model Class Initialized
DEBUG - 2025-03-20 20:26:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:26:11 --> Model Class Initialized
INFO - 2025-03-20 20:26:11 --> Final output sent to browser
DEBUG - 2025-03-20 20:26:11 --> Total execution time: 0.0110
INFO - 2025-03-20 20:33:38 --> Config Class Initialized
INFO - 2025-03-20 20:33:38 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:33:38 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:33:38 --> Utf8 Class Initialized
INFO - 2025-03-20 20:33:38 --> URI Class Initialized
DEBUG - 2025-03-20 20:33:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:33:38 --> Router Class Initialized
INFO - 2025-03-20 20:33:38 --> Output Class Initialized
INFO - 2025-03-20 20:33:38 --> Security Class Initialized
DEBUG - 2025-03-20 20:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:33:38 --> Input Class Initialized
INFO - 2025-03-20 20:33:38 --> Language Class Initialized
INFO - 2025-03-20 20:33:38 --> Language Class Initialized
INFO - 2025-03-20 20:33:38 --> Config Class Initialized
INFO - 2025-03-20 20:33:38 --> Loader Class Initialized
INFO - 2025-03-20 20:33:38 --> Helper loaded: url_helper
INFO - 2025-03-20 20:33:38 --> Helper loaded: file_helper
INFO - 2025-03-20 20:33:38 --> Helper loaded: html_helper
INFO - 2025-03-20 20:33:38 --> Helper loaded: form_helper
INFO - 2025-03-20 20:33:38 --> Helper loaded: text_helper
INFO - 2025-03-20 20:33:38 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:33:38 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:33:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:33:38 --> Database Driver Class Initialized
INFO - 2025-03-20 20:33:38 --> Email Class Initialized
INFO - 2025-03-20 20:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:33:38 --> Form Validation Class Initialized
INFO - 2025-03-20 20:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:33:38 --> Pagination Class Initialized
INFO - 2025-03-20 20:33:38 --> Controller Class Initialized
ERROR - 2025-03-20 20:33:38 --> 404 Page Not Found: ../modules/report/controllers/Report/getPurchaseReportList
INFO - 2025-03-20 20:33:46 --> Config Class Initialized
INFO - 2025-03-20 20:33:46 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:33:46 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:33:46 --> Utf8 Class Initialized
INFO - 2025-03-20 20:33:46 --> URI Class Initialized
DEBUG - 2025-03-20 20:33:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:33:46 --> Router Class Initialized
INFO - 2025-03-20 20:33:46 --> Output Class Initialized
INFO - 2025-03-20 20:33:46 --> Security Class Initialized
DEBUG - 2025-03-20 20:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:33:46 --> Input Class Initialized
INFO - 2025-03-20 20:33:46 --> Language Class Initialized
INFO - 2025-03-20 20:33:46 --> Language Class Initialized
INFO - 2025-03-20 20:33:46 --> Config Class Initialized
INFO - 2025-03-20 20:33:46 --> Loader Class Initialized
INFO - 2025-03-20 20:33:46 --> Helper loaded: url_helper
INFO - 2025-03-20 20:33:46 --> Helper loaded: file_helper
INFO - 2025-03-20 20:33:46 --> Helper loaded: html_helper
INFO - 2025-03-20 20:33:46 --> Helper loaded: form_helper
INFO - 2025-03-20 20:33:46 --> Helper loaded: text_helper
INFO - 2025-03-20 20:33:46 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:33:46 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:33:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:33:46 --> Database Driver Class Initialized
INFO - 2025-03-20 20:33:46 --> Email Class Initialized
INFO - 2025-03-20 20:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:33:46 --> Form Validation Class Initialized
INFO - 2025-03-20 20:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:33:46 --> Pagination Class Initialized
INFO - 2025-03-20 20:33:46 --> Controller Class Initialized
ERROR - 2025-03-20 20:33:46 --> 404 Page Not Found: ../modules/report/controllers/Report/getPurchaseReportList
INFO - 2025-03-20 20:33:50 --> Config Class Initialized
INFO - 2025-03-20 20:33:50 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:33:50 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:33:50 --> Utf8 Class Initialized
INFO - 2025-03-20 20:33:50 --> URI Class Initialized
DEBUG - 2025-03-20 20:33:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:33:50 --> Router Class Initialized
INFO - 2025-03-20 20:33:50 --> Output Class Initialized
INFO - 2025-03-20 20:33:50 --> Security Class Initialized
DEBUG - 2025-03-20 20:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:33:50 --> Input Class Initialized
INFO - 2025-03-20 20:33:50 --> Language Class Initialized
INFO - 2025-03-20 20:33:50 --> Language Class Initialized
INFO - 2025-03-20 20:33:50 --> Config Class Initialized
INFO - 2025-03-20 20:33:50 --> Loader Class Initialized
INFO - 2025-03-20 20:33:50 --> Helper loaded: url_helper
INFO - 2025-03-20 20:33:50 --> Helper loaded: file_helper
INFO - 2025-03-20 20:33:50 --> Helper loaded: html_helper
INFO - 2025-03-20 20:33:50 --> Helper loaded: form_helper
INFO - 2025-03-20 20:33:50 --> Helper loaded: text_helper
INFO - 2025-03-20 20:33:50 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:33:50 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:33:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:33:50 --> Database Driver Class Initialized
INFO - 2025-03-20 20:33:50 --> Email Class Initialized
INFO - 2025-03-20 20:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:33:50 --> Form Validation Class Initialized
INFO - 2025-03-20 20:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:33:50 --> Pagination Class Initialized
INFO - 2025-03-20 20:33:50 --> Controller Class Initialized
ERROR - 2025-03-20 20:33:50 --> 404 Page Not Found: ../modules/report/controllers/Report/getPurchaseReportList
INFO - 2025-03-20 20:33:51 --> Config Class Initialized
INFO - 2025-03-20 20:33:51 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:33:51 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:33:51 --> Utf8 Class Initialized
INFO - 2025-03-20 20:33:51 --> URI Class Initialized
DEBUG - 2025-03-20 20:33:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:33:51 --> Router Class Initialized
INFO - 2025-03-20 20:33:51 --> Output Class Initialized
INFO - 2025-03-20 20:33:51 --> Security Class Initialized
DEBUG - 2025-03-20 20:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:33:51 --> Input Class Initialized
INFO - 2025-03-20 20:33:51 --> Language Class Initialized
INFO - 2025-03-20 20:33:51 --> Language Class Initialized
INFO - 2025-03-20 20:33:51 --> Config Class Initialized
INFO - 2025-03-20 20:33:51 --> Loader Class Initialized
INFO - 2025-03-20 20:33:51 --> Helper loaded: url_helper
INFO - 2025-03-20 20:33:51 --> Helper loaded: file_helper
INFO - 2025-03-20 20:33:51 --> Helper loaded: html_helper
INFO - 2025-03-20 20:33:51 --> Helper loaded: form_helper
INFO - 2025-03-20 20:33:51 --> Helper loaded: text_helper
INFO - 2025-03-20 20:33:51 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:33:51 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:33:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:33:51 --> Database Driver Class Initialized
INFO - 2025-03-20 20:33:51 --> Email Class Initialized
INFO - 2025-03-20 20:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:33:51 --> Form Validation Class Initialized
INFO - 2025-03-20 20:33:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:33:51 --> Pagination Class Initialized
INFO - 2025-03-20 20:33:51 --> Controller Class Initialized
DEBUG - 2025-03-20 20:33:51 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:33:51 --> Model Class Initialized
DEBUG - 2025-03-20 20:33:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:33:51 --> Model Class Initialized
DEBUG - 2025-03-20 20:33:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:33:51 --> Model Class Initialized
INFO - 2025-03-20 20:33:51 --> Final output sent to browser
DEBUG - 2025-03-20 20:33:51 --> Total execution time: 0.0089
INFO - 2025-03-20 20:34:05 --> Config Class Initialized
INFO - 2025-03-20 20:34:05 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:34:05 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:34:05 --> Utf8 Class Initialized
INFO - 2025-03-20 20:34:05 --> URI Class Initialized
DEBUG - 2025-03-20 20:34:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:34:05 --> Router Class Initialized
INFO - 2025-03-20 20:34:05 --> Output Class Initialized
INFO - 2025-03-20 20:34:05 --> Security Class Initialized
DEBUG - 2025-03-20 20:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:34:05 --> Input Class Initialized
INFO - 2025-03-20 20:34:05 --> Language Class Initialized
INFO - 2025-03-20 20:34:05 --> Language Class Initialized
INFO - 2025-03-20 20:34:05 --> Config Class Initialized
INFO - 2025-03-20 20:34:05 --> Loader Class Initialized
INFO - 2025-03-20 20:34:05 --> Helper loaded: url_helper
INFO - 2025-03-20 20:34:05 --> Helper loaded: file_helper
INFO - 2025-03-20 20:34:05 --> Helper loaded: html_helper
INFO - 2025-03-20 20:34:05 --> Helper loaded: form_helper
INFO - 2025-03-20 20:34:05 --> Helper loaded: text_helper
INFO - 2025-03-20 20:34:05 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:34:05 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:34:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:34:05 --> Database Driver Class Initialized
INFO - 2025-03-20 20:34:05 --> Email Class Initialized
INFO - 2025-03-20 20:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:34:05 --> Form Validation Class Initialized
INFO - 2025-03-20 20:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:34:05 --> Pagination Class Initialized
INFO - 2025-03-20 20:34:05 --> Controller Class Initialized
ERROR - 2025-03-20 20:34:05 --> 404 Page Not Found: ../modules/report/controllers/Report/getPurchaseReportList
INFO - 2025-03-20 20:36:06 --> Config Class Initialized
INFO - 2025-03-20 20:36:06 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:36:06 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:36:06 --> Utf8 Class Initialized
INFO - 2025-03-20 20:36:06 --> URI Class Initialized
DEBUG - 2025-03-20 20:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:36:06 --> Router Class Initialized
INFO - 2025-03-20 20:36:06 --> Output Class Initialized
INFO - 2025-03-20 20:36:06 --> Security Class Initialized
DEBUG - 2025-03-20 20:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:36:06 --> Input Class Initialized
INFO - 2025-03-20 20:36:06 --> Language Class Initialized
INFO - 2025-03-20 20:36:06 --> Language Class Initialized
INFO - 2025-03-20 20:36:06 --> Config Class Initialized
INFO - 2025-03-20 20:36:06 --> Loader Class Initialized
INFO - 2025-03-20 20:36:06 --> Helper loaded: url_helper
INFO - 2025-03-20 20:36:06 --> Helper loaded: file_helper
INFO - 2025-03-20 20:36:06 --> Helper loaded: html_helper
INFO - 2025-03-20 20:36:06 --> Helper loaded: form_helper
INFO - 2025-03-20 20:36:06 --> Helper loaded: text_helper
INFO - 2025-03-20 20:36:06 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:36:06 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:36:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:36:06 --> Database Driver Class Initialized
INFO - 2025-03-20 20:36:06 --> Email Class Initialized
INFO - 2025-03-20 20:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:36:06 --> Form Validation Class Initialized
INFO - 2025-03-20 20:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:36:06 --> Pagination Class Initialized
INFO - 2025-03-20 20:36:06 --> Controller Class Initialized
DEBUG - 2025-03-20 20:36:06 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:36:06 --> Model Class Initialized
DEBUG - 2025-03-20 20:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:36:06 --> Model Class Initialized
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Undefined array key "draw" /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 638
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Undefined array key "start" /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 639
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Undefined array key "length" /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 640
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Undefined array key "order" /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 641
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 641
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 641
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Undefined array key "columns" /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 642
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 642
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 642
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Undefined array key "order" /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 643
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 643
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 643
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Undefined array key "search" /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 644
ERROR - 2025-03-20 20:36:06 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 644
INFO - 2025-03-20 20:36:06 --> Final output sent to browser
DEBUG - 2025-03-20 20:36:06 --> Total execution time: 0.0108
INFO - 2025-03-20 20:38:12 --> Config Class Initialized
INFO - 2025-03-20 20:38:12 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:38:12 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:38:12 --> Utf8 Class Initialized
INFO - 2025-03-20 20:38:12 --> URI Class Initialized
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:38:12 --> Router Class Initialized
INFO - 2025-03-20 20:38:12 --> Output Class Initialized
INFO - 2025-03-20 20:38:12 --> Security Class Initialized
DEBUG - 2025-03-20 20:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:38:12 --> Input Class Initialized
INFO - 2025-03-20 20:38:12 --> Language Class Initialized
INFO - 2025-03-20 20:38:12 --> Language Class Initialized
INFO - 2025-03-20 20:38:12 --> Config Class Initialized
INFO - 2025-03-20 20:38:12 --> Loader Class Initialized
INFO - 2025-03-20 20:38:12 --> Helper loaded: url_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: file_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: html_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: form_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: text_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:38:12 --> Database Driver Class Initialized
INFO - 2025-03-20 20:38:12 --> Email Class Initialized
INFO - 2025-03-20 20:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:38:12 --> Form Validation Class Initialized
INFO - 2025-03-20 20:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:38:12 --> Pagination Class Initialized
INFO - 2025-03-20 20:38:12 --> Controller Class Initialized
DEBUG - 2025-03-20 20:38:12 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:38:12 --> Model Class Initialized
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:38:12 --> Model Class Initialized
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:38:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:38:12 --> Model Class Initialized
ERROR - 2025-03-20 20:38:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:38:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:38:12 --> Final output sent to browser
DEBUG - 2025-03-20 20:38:12 --> Total execution time: 0.1486
INFO - 2025-03-20 20:38:12 --> Config Class Initialized
INFO - 2025-03-20 20:38:12 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:38:12 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:38:12 --> Utf8 Class Initialized
INFO - 2025-03-20 20:38:12 --> URI Class Initialized
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:38:12 --> Router Class Initialized
INFO - 2025-03-20 20:38:12 --> Output Class Initialized
INFO - 2025-03-20 20:38:12 --> Security Class Initialized
DEBUG - 2025-03-20 20:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:38:12 --> Input Class Initialized
INFO - 2025-03-20 20:38:12 --> Language Class Initialized
INFO - 2025-03-20 20:38:12 --> Language Class Initialized
INFO - 2025-03-20 20:38:12 --> Config Class Initialized
INFO - 2025-03-20 20:38:12 --> Loader Class Initialized
INFO - 2025-03-20 20:38:12 --> Helper loaded: url_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: file_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: html_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: form_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: text_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:38:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:38:12 --> Database Driver Class Initialized
INFO - 2025-03-20 20:38:12 --> Email Class Initialized
INFO - 2025-03-20 20:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:38:12 --> Form Validation Class Initialized
INFO - 2025-03-20 20:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:38:12 --> Pagination Class Initialized
INFO - 2025-03-20 20:38:12 --> Controller Class Initialized
DEBUG - 2025-03-20 20:38:12 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:38:12 --> Model Class Initialized
DEBUG - 2025-03-20 20:38:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:38:12 --> Model Class Initialized
ERROR - 2025-03-20 20:38:12 --> Severity: error --> Exception: Unknown column 'invoice_no' in 'order clause' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-20 20:41:00 --> Config Class Initialized
INFO - 2025-03-20 20:41:00 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:41:00 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:41:00 --> Utf8 Class Initialized
INFO - 2025-03-20 20:41:00 --> URI Class Initialized
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:41:00 --> Router Class Initialized
INFO - 2025-03-20 20:41:00 --> Output Class Initialized
INFO - 2025-03-20 20:41:00 --> Security Class Initialized
DEBUG - 2025-03-20 20:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:41:00 --> Input Class Initialized
INFO - 2025-03-20 20:41:00 --> Language Class Initialized
INFO - 2025-03-20 20:41:00 --> Language Class Initialized
INFO - 2025-03-20 20:41:00 --> Config Class Initialized
INFO - 2025-03-20 20:41:00 --> Loader Class Initialized
INFO - 2025-03-20 20:41:00 --> Helper loaded: url_helper
INFO - 2025-03-20 20:41:00 --> Helper loaded: file_helper
INFO - 2025-03-20 20:41:00 --> Helper loaded: html_helper
INFO - 2025-03-20 20:41:00 --> Helper loaded: form_helper
INFO - 2025-03-20 20:41:00 --> Helper loaded: text_helper
INFO - 2025-03-20 20:41:00 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:41:00 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:41:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:41:00 --> Database Driver Class Initialized
INFO - 2025-03-20 20:41:00 --> Email Class Initialized
INFO - 2025-03-20 20:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:41:00 --> Form Validation Class Initialized
INFO - 2025-03-20 20:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:41:00 --> Pagination Class Initialized
INFO - 2025-03-20 20:41:00 --> Controller Class Initialized
DEBUG - 2025-03-20 20:41:00 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:41:00 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:41:00 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:41:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:41:00 --> Model Class Initialized
ERROR - 2025-03-20 20:41:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:41:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:41:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:41:00 --> Final output sent to browser
DEBUG - 2025-03-20 20:41:00 --> Total execution time: 0.1562
INFO - 2025-03-20 20:41:01 --> Config Class Initialized
INFO - 2025-03-20 20:41:01 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:41:01 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:41:01 --> Utf8 Class Initialized
INFO - 2025-03-20 20:41:01 --> URI Class Initialized
DEBUG - 2025-03-20 20:41:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:41:01 --> Router Class Initialized
INFO - 2025-03-20 20:41:01 --> Output Class Initialized
INFO - 2025-03-20 20:41:01 --> Security Class Initialized
DEBUG - 2025-03-20 20:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:41:01 --> Input Class Initialized
INFO - 2025-03-20 20:41:01 --> Language Class Initialized
INFO - 2025-03-20 20:41:01 --> Language Class Initialized
INFO - 2025-03-20 20:41:01 --> Config Class Initialized
INFO - 2025-03-20 20:41:01 --> Loader Class Initialized
INFO - 2025-03-20 20:41:01 --> Helper loaded: url_helper
INFO - 2025-03-20 20:41:01 --> Helper loaded: file_helper
INFO - 2025-03-20 20:41:01 --> Helper loaded: html_helper
INFO - 2025-03-20 20:41:01 --> Helper loaded: form_helper
INFO - 2025-03-20 20:41:01 --> Helper loaded: text_helper
INFO - 2025-03-20 20:41:01 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:41:01 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:41:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:41:01 --> Database Driver Class Initialized
INFO - 2025-03-20 20:41:01 --> Email Class Initialized
INFO - 2025-03-20 20:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:41:01 --> Form Validation Class Initialized
INFO - 2025-03-20 20:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:41:01 --> Pagination Class Initialized
INFO - 2025-03-20 20:41:01 --> Controller Class Initialized
DEBUG - 2025-03-20 20:41:01 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:41:01 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:41:01 --> Model Class Initialized
ERROR - 2025-03-20 20:41:01 --> Severity: error --> Exception: Unknown column 'invoice_no' in 'order clause' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-20 20:41:15 --> Config Class Initialized
INFO - 2025-03-20 20:41:15 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:41:15 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:41:15 --> Utf8 Class Initialized
INFO - 2025-03-20 20:41:15 --> URI Class Initialized
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:41:15 --> Router Class Initialized
INFO - 2025-03-20 20:41:15 --> Output Class Initialized
INFO - 2025-03-20 20:41:15 --> Security Class Initialized
DEBUG - 2025-03-20 20:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:41:15 --> Input Class Initialized
INFO - 2025-03-20 20:41:15 --> Language Class Initialized
INFO - 2025-03-20 20:41:15 --> Language Class Initialized
INFO - 2025-03-20 20:41:15 --> Config Class Initialized
INFO - 2025-03-20 20:41:15 --> Loader Class Initialized
INFO - 2025-03-20 20:41:15 --> Helper loaded: url_helper
INFO - 2025-03-20 20:41:15 --> Helper loaded: file_helper
INFO - 2025-03-20 20:41:15 --> Helper loaded: html_helper
INFO - 2025-03-20 20:41:15 --> Helper loaded: form_helper
INFO - 2025-03-20 20:41:15 --> Helper loaded: text_helper
INFO - 2025-03-20 20:41:15 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:41:15 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:41:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:41:15 --> Database Driver Class Initialized
INFO - 2025-03-20 20:41:15 --> Email Class Initialized
INFO - 2025-03-20 20:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:41:15 --> Form Validation Class Initialized
INFO - 2025-03-20 20:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:41:15 --> Pagination Class Initialized
INFO - 2025-03-20 20:41:15 --> Controller Class Initialized
DEBUG - 2025-03-20 20:41:15 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:41:15 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:41:15 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:41:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:41:15 --> Model Class Initialized
ERROR - 2025-03-20 20:41:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:41:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:41:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:41:15 --> Final output sent to browser
DEBUG - 2025-03-20 20:41:15 --> Total execution time: 0.1410
INFO - 2025-03-20 20:41:16 --> Config Class Initialized
INFO - 2025-03-20 20:41:16 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:41:16 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:41:16 --> Utf8 Class Initialized
INFO - 2025-03-20 20:41:16 --> URI Class Initialized
DEBUG - 2025-03-20 20:41:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:41:16 --> Router Class Initialized
INFO - 2025-03-20 20:41:16 --> Output Class Initialized
INFO - 2025-03-20 20:41:16 --> Security Class Initialized
DEBUG - 2025-03-20 20:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:41:16 --> Input Class Initialized
INFO - 2025-03-20 20:41:16 --> Language Class Initialized
INFO - 2025-03-20 20:41:16 --> Language Class Initialized
INFO - 2025-03-20 20:41:16 --> Config Class Initialized
INFO - 2025-03-20 20:41:16 --> Loader Class Initialized
INFO - 2025-03-20 20:41:16 --> Helper loaded: url_helper
INFO - 2025-03-20 20:41:16 --> Helper loaded: file_helper
INFO - 2025-03-20 20:41:16 --> Helper loaded: html_helper
INFO - 2025-03-20 20:41:16 --> Helper loaded: form_helper
INFO - 2025-03-20 20:41:16 --> Helper loaded: text_helper
INFO - 2025-03-20 20:41:16 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:41:16 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:41:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:41:16 --> Database Driver Class Initialized
INFO - 2025-03-20 20:41:16 --> Email Class Initialized
INFO - 2025-03-20 20:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:41:16 --> Form Validation Class Initialized
INFO - 2025-03-20 20:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:41:16 --> Pagination Class Initialized
INFO - 2025-03-20 20:41:16 --> Controller Class Initialized
DEBUG - 2025-03-20 20:41:16 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:41:16 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:41:16 --> Model Class Initialized
ERROR - 2025-03-20 20:41:16 --> Severity: error --> Exception: Unknown column 'invoice_no' in 'order clause' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-20 20:41:47 --> Config Class Initialized
INFO - 2025-03-20 20:41:47 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:41:47 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:41:47 --> Utf8 Class Initialized
INFO - 2025-03-20 20:41:47 --> URI Class Initialized
DEBUG - 2025-03-20 20:41:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:41:47 --> Router Class Initialized
INFO - 2025-03-20 20:41:47 --> Output Class Initialized
INFO - 2025-03-20 20:41:47 --> Security Class Initialized
DEBUG - 2025-03-20 20:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:41:47 --> Input Class Initialized
INFO - 2025-03-20 20:41:47 --> Language Class Initialized
INFO - 2025-03-20 20:41:47 --> Language Class Initialized
INFO - 2025-03-20 20:41:47 --> Config Class Initialized
INFO - 2025-03-20 20:41:47 --> Loader Class Initialized
INFO - 2025-03-20 20:41:47 --> Helper loaded: url_helper
INFO - 2025-03-20 20:41:47 --> Helper loaded: file_helper
INFO - 2025-03-20 20:41:47 --> Helper loaded: html_helper
INFO - 2025-03-20 20:41:47 --> Helper loaded: form_helper
INFO - 2025-03-20 20:41:47 --> Helper loaded: text_helper
INFO - 2025-03-20 20:41:47 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:41:47 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:41:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:41:47 --> Database Driver Class Initialized
INFO - 2025-03-20 20:41:47 --> Email Class Initialized
INFO - 2025-03-20 20:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:41:47 --> Form Validation Class Initialized
INFO - 2025-03-20 20:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:41:47 --> Pagination Class Initialized
INFO - 2025-03-20 20:41:47 --> Controller Class Initialized
DEBUG - 2025-03-20 20:41:47 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:41:47 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:41:47 --> Model Class Initialized
INFO - 2025-03-20 20:41:47 --> Final output sent to browser
DEBUG - 2025-03-20 20:41:47 --> Total execution time: 0.0145
INFO - 2025-03-20 20:41:49 --> Config Class Initialized
INFO - 2025-03-20 20:41:49 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:41:49 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:41:49 --> Utf8 Class Initialized
INFO - 2025-03-20 20:41:49 --> URI Class Initialized
DEBUG - 2025-03-20 20:41:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:41:49 --> Router Class Initialized
INFO - 2025-03-20 20:41:49 --> Output Class Initialized
INFO - 2025-03-20 20:41:49 --> Security Class Initialized
DEBUG - 2025-03-20 20:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:41:49 --> Input Class Initialized
INFO - 2025-03-20 20:41:49 --> Language Class Initialized
INFO - 2025-03-20 20:41:49 --> Language Class Initialized
INFO - 2025-03-20 20:41:49 --> Config Class Initialized
INFO - 2025-03-20 20:41:49 --> Loader Class Initialized
INFO - 2025-03-20 20:41:49 --> Helper loaded: url_helper
INFO - 2025-03-20 20:41:49 --> Helper loaded: file_helper
INFO - 2025-03-20 20:41:49 --> Helper loaded: html_helper
INFO - 2025-03-20 20:41:49 --> Helper loaded: form_helper
INFO - 2025-03-20 20:41:49 --> Helper loaded: text_helper
INFO - 2025-03-20 20:41:49 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:41:49 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:41:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:41:49 --> Database Driver Class Initialized
INFO - 2025-03-20 20:41:49 --> Email Class Initialized
INFO - 2025-03-20 20:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:41:49 --> Form Validation Class Initialized
INFO - 2025-03-20 20:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:41:49 --> Pagination Class Initialized
INFO - 2025-03-20 20:41:49 --> Controller Class Initialized
DEBUG - 2025-03-20 20:41:49 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:41:49 --> Model Class Initialized
DEBUG - 2025-03-20 20:41:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:41:49 --> Model Class Initialized
INFO - 2025-03-20 20:41:49 --> Final output sent to browser
DEBUG - 2025-03-20 20:41:49 --> Total execution time: 0.0080
INFO - 2025-03-20 20:42:59 --> Config Class Initialized
INFO - 2025-03-20 20:42:59 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:42:59 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:42:59 --> Utf8 Class Initialized
INFO - 2025-03-20 20:42:59 --> URI Class Initialized
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:42:59 --> Router Class Initialized
INFO - 2025-03-20 20:42:59 --> Output Class Initialized
INFO - 2025-03-20 20:42:59 --> Security Class Initialized
DEBUG - 2025-03-20 20:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:42:59 --> Input Class Initialized
INFO - 2025-03-20 20:42:59 --> Language Class Initialized
INFO - 2025-03-20 20:42:59 --> Language Class Initialized
INFO - 2025-03-20 20:42:59 --> Config Class Initialized
INFO - 2025-03-20 20:42:59 --> Loader Class Initialized
INFO - 2025-03-20 20:42:59 --> Helper loaded: url_helper
INFO - 2025-03-20 20:42:59 --> Helper loaded: file_helper
INFO - 2025-03-20 20:42:59 --> Helper loaded: html_helper
INFO - 2025-03-20 20:42:59 --> Helper loaded: form_helper
INFO - 2025-03-20 20:42:59 --> Helper loaded: text_helper
INFO - 2025-03-20 20:42:59 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:42:59 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:42:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:42:59 --> Database Driver Class Initialized
INFO - 2025-03-20 20:42:59 --> Email Class Initialized
INFO - 2025-03-20 20:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:42:59 --> Form Validation Class Initialized
INFO - 2025-03-20 20:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:42:59 --> Pagination Class Initialized
INFO - 2025-03-20 20:42:59 --> Controller Class Initialized
DEBUG - 2025-03-20 20:42:59 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:42:59 --> Model Class Initialized
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:42:59 --> Model Class Initialized
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:42:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:42:59 --> Model Class Initialized
ERROR - 2025-03-20 20:42:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:42:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:42:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:42:59 --> Final output sent to browser
DEBUG - 2025-03-20 20:42:59 --> Total execution time: 0.1161
INFO - 2025-03-20 20:43:00 --> Config Class Initialized
INFO - 2025-03-20 20:43:00 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:43:00 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:43:00 --> Utf8 Class Initialized
INFO - 2025-03-20 20:43:00 --> URI Class Initialized
DEBUG - 2025-03-20 20:43:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:43:00 --> Router Class Initialized
INFO - 2025-03-20 20:43:00 --> Output Class Initialized
INFO - 2025-03-20 20:43:00 --> Security Class Initialized
DEBUG - 2025-03-20 20:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:43:00 --> Input Class Initialized
INFO - 2025-03-20 20:43:00 --> Language Class Initialized
INFO - 2025-03-20 20:43:00 --> Language Class Initialized
INFO - 2025-03-20 20:43:00 --> Config Class Initialized
INFO - 2025-03-20 20:43:00 --> Loader Class Initialized
INFO - 2025-03-20 20:43:00 --> Helper loaded: url_helper
INFO - 2025-03-20 20:43:00 --> Helper loaded: file_helper
INFO - 2025-03-20 20:43:00 --> Helper loaded: html_helper
INFO - 2025-03-20 20:43:00 --> Helper loaded: form_helper
INFO - 2025-03-20 20:43:00 --> Helper loaded: text_helper
INFO - 2025-03-20 20:43:00 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:43:00 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:43:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:43:00 --> Database Driver Class Initialized
INFO - 2025-03-20 20:43:00 --> Email Class Initialized
INFO - 2025-03-20 20:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:43:00 --> Form Validation Class Initialized
INFO - 2025-03-20 20:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:43:00 --> Pagination Class Initialized
INFO - 2025-03-20 20:43:00 --> Controller Class Initialized
DEBUG - 2025-03-20 20:43:00 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:43:00 --> Model Class Initialized
DEBUG - 2025-03-20 20:43:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:43:00 --> Model Class Initialized
INFO - 2025-03-20 20:43:00 --> Final output sent to browser
DEBUG - 2025-03-20 20:43:00 --> Total execution time: 0.0151
INFO - 2025-03-20 20:43:06 --> Config Class Initialized
INFO - 2025-03-20 20:43:06 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:43:06 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:43:06 --> Utf8 Class Initialized
INFO - 2025-03-20 20:43:06 --> URI Class Initialized
DEBUG - 2025-03-20 20:43:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:43:06 --> Router Class Initialized
INFO - 2025-03-20 20:43:06 --> Output Class Initialized
INFO - 2025-03-20 20:43:06 --> Security Class Initialized
DEBUG - 2025-03-20 20:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:43:06 --> Input Class Initialized
INFO - 2025-03-20 20:43:06 --> Language Class Initialized
INFO - 2025-03-20 20:43:06 --> Language Class Initialized
INFO - 2025-03-20 20:43:06 --> Config Class Initialized
INFO - 2025-03-20 20:43:06 --> Loader Class Initialized
INFO - 2025-03-20 20:43:06 --> Helper loaded: url_helper
INFO - 2025-03-20 20:43:06 --> Helper loaded: file_helper
INFO - 2025-03-20 20:43:06 --> Helper loaded: html_helper
INFO - 2025-03-20 20:43:06 --> Helper loaded: form_helper
INFO - 2025-03-20 20:43:06 --> Helper loaded: text_helper
INFO - 2025-03-20 20:43:06 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:43:06 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:43:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:43:06 --> Database Driver Class Initialized
INFO - 2025-03-20 20:43:06 --> Email Class Initialized
INFO - 2025-03-20 20:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:43:06 --> Form Validation Class Initialized
INFO - 2025-03-20 20:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:43:06 --> Pagination Class Initialized
INFO - 2025-03-20 20:43:06 --> Controller Class Initialized
DEBUG - 2025-03-20 20:43:06 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:43:06 --> Model Class Initialized
DEBUG - 2025-03-20 20:43:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:43:06 --> Model Class Initialized
INFO - 2025-03-20 20:43:06 --> Final output sent to browser
DEBUG - 2025-03-20 20:43:06 --> Total execution time: 0.0099
INFO - 2025-03-20 20:43:17 --> Config Class Initialized
INFO - 2025-03-20 20:43:17 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:43:17 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:43:17 --> Utf8 Class Initialized
INFO - 2025-03-20 20:43:17 --> URI Class Initialized
DEBUG - 2025-03-20 20:43:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 20:43:17 --> Router Class Initialized
INFO - 2025-03-20 20:43:17 --> Output Class Initialized
INFO - 2025-03-20 20:43:17 --> Security Class Initialized
DEBUG - 2025-03-20 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:43:17 --> Input Class Initialized
INFO - 2025-03-20 20:43:17 --> Language Class Initialized
INFO - 2025-03-20 20:43:17 --> Language Class Initialized
INFO - 2025-03-20 20:43:17 --> Config Class Initialized
INFO - 2025-03-20 20:43:17 --> Loader Class Initialized
INFO - 2025-03-20 20:43:17 --> Helper loaded: url_helper
INFO - 2025-03-20 20:43:17 --> Helper loaded: file_helper
INFO - 2025-03-20 20:43:17 --> Helper loaded: html_helper
INFO - 2025-03-20 20:43:17 --> Helper loaded: form_helper
INFO - 2025-03-20 20:43:17 --> Helper loaded: text_helper
INFO - 2025-03-20 20:43:17 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:43:17 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:43:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:43:17 --> Database Driver Class Initialized
INFO - 2025-03-20 20:43:17 --> Email Class Initialized
INFO - 2025-03-20 20:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:43:17 --> Form Validation Class Initialized
INFO - 2025-03-20 20:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:43:17 --> Pagination Class Initialized
INFO - 2025-03-20 20:43:17 --> Controller Class Initialized
DEBUG - 2025-03-20 20:43:17 --> Report MX_Controller Initialized
INFO - 2025-03-20 20:43:17 --> Model Class Initialized
DEBUG - 2025-03-20 20:43:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 20:43:17 --> Model Class Initialized
INFO - 2025-03-20 20:43:17 --> Final output sent to browser
DEBUG - 2025-03-20 20:43:17 --> Total execution time: 0.0122
INFO - 2025-03-20 20:50:37 --> Config Class Initialized
INFO - 2025-03-20 20:50:37 --> Hooks Class Initialized
DEBUG - 2025-03-20 20:50:37 --> UTF-8 Support Enabled
INFO - 2025-03-20 20:50:37 --> Utf8 Class Initialized
INFO - 2025-03-20 20:50:37 --> URI Class Initialized
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-20 20:50:37 --> Router Class Initialized
INFO - 2025-03-20 20:50:37 --> Output Class Initialized
INFO - 2025-03-20 20:50:37 --> Security Class Initialized
DEBUG - 2025-03-20 20:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 20:50:37 --> Input Class Initialized
INFO - 2025-03-20 20:50:37 --> Language Class Initialized
INFO - 2025-03-20 20:50:37 --> Language Class Initialized
INFO - 2025-03-20 20:50:37 --> Config Class Initialized
INFO - 2025-03-20 20:50:37 --> Loader Class Initialized
INFO - 2025-03-20 20:50:37 --> Helper loaded: url_helper
INFO - 2025-03-20 20:50:37 --> Helper loaded: file_helper
INFO - 2025-03-20 20:50:37 --> Helper loaded: html_helper
INFO - 2025-03-20 20:50:37 --> Helper loaded: form_helper
INFO - 2025-03-20 20:50:37 --> Helper loaded: text_helper
INFO - 2025-03-20 20:50:37 --> Helper loaded: lang_helper
INFO - 2025-03-20 20:50:37 --> Helper loaded: directory_helper
INFO - 2025-03-20 20:50:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 20:50:37 --> Database Driver Class Initialized
INFO - 2025-03-20 20:50:37 --> Email Class Initialized
INFO - 2025-03-20 20:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 20:50:37 --> Form Validation Class Initialized
INFO - 2025-03-20 20:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 20:50:37 --> Pagination Class Initialized
INFO - 2025-03-20 20:50:37 --> Controller Class Initialized
DEBUG - 2025-03-20 20:50:37 --> Purchase MX_Controller Initialized
INFO - 2025-03-20 20:50:37 --> Model Class Initialized
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-20 20:50:37 --> Model Class Initialized
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-20 20:50:37 --> Model Class Initialized
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 20:50:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 20:50:37 --> Model Class Initialized
ERROR - 2025-03-20 20:50:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 20:50:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 20:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 20:50:37 --> Final output sent to browser
DEBUG - 2025-03-20 20:50:37 --> Total execution time: 0.1257
INFO - 2025-03-20 21:09:08 --> Config Class Initialized
INFO - 2025-03-20 21:09:08 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:09:08 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:09:08 --> Utf8 Class Initialized
INFO - 2025-03-20 21:09:08 --> URI Class Initialized
DEBUG - 2025-03-20 21:09:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:09:08 --> Router Class Initialized
INFO - 2025-03-20 21:09:08 --> Output Class Initialized
INFO - 2025-03-20 21:09:08 --> Security Class Initialized
DEBUG - 2025-03-20 21:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:09:08 --> Input Class Initialized
INFO - 2025-03-20 21:09:08 --> Language Class Initialized
INFO - 2025-03-20 21:09:08 --> Language Class Initialized
INFO - 2025-03-20 21:09:08 --> Config Class Initialized
INFO - 2025-03-20 21:09:08 --> Loader Class Initialized
INFO - 2025-03-20 21:09:08 --> Helper loaded: url_helper
INFO - 2025-03-20 21:09:08 --> Helper loaded: file_helper
INFO - 2025-03-20 21:09:08 --> Helper loaded: html_helper
INFO - 2025-03-20 21:09:08 --> Helper loaded: form_helper
INFO - 2025-03-20 21:09:08 --> Helper loaded: text_helper
INFO - 2025-03-20 21:09:08 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:09:08 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:09:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:09:08 --> Database Driver Class Initialized
INFO - 2025-03-20 21:09:08 --> Email Class Initialized
INFO - 2025-03-20 21:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:09:08 --> Form Validation Class Initialized
INFO - 2025-03-20 21:09:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:09:08 --> Pagination Class Initialized
INFO - 2025-03-20 21:09:08 --> Controller Class Initialized
DEBUG - 2025-03-20 21:09:08 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:09:08 --> Model Class Initialized
DEBUG - 2025-03-20 21:09:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:09:08 --> Model Class Initialized
DEBUG - 2025-03-20 21:09:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:09:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:09:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:09:08 --> Model Class Initialized
ERROR - 2025-03-20 21:09:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:09:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:09:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:09:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:09:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:09:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:09:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 21:09:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:09:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:09:09 --> Final output sent to browser
DEBUG - 2025-03-20 21:09:09 --> Total execution time: 0.4151
INFO - 2025-03-20 21:09:09 --> Config Class Initialized
INFO - 2025-03-20 21:09:09 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:09:09 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:09:09 --> Utf8 Class Initialized
INFO - 2025-03-20 21:09:09 --> URI Class Initialized
DEBUG - 2025-03-20 21:09:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:09:09 --> Router Class Initialized
INFO - 2025-03-20 21:09:09 --> Output Class Initialized
INFO - 2025-03-20 21:09:09 --> Security Class Initialized
DEBUG - 2025-03-20 21:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:09:09 --> Input Class Initialized
INFO - 2025-03-20 21:09:09 --> Language Class Initialized
INFO - 2025-03-20 21:09:09 --> Language Class Initialized
INFO - 2025-03-20 21:09:09 --> Config Class Initialized
INFO - 2025-03-20 21:09:09 --> Loader Class Initialized
INFO - 2025-03-20 21:09:09 --> Helper loaded: url_helper
INFO - 2025-03-20 21:09:09 --> Helper loaded: file_helper
INFO - 2025-03-20 21:09:09 --> Helper loaded: html_helper
INFO - 2025-03-20 21:09:09 --> Helper loaded: form_helper
INFO - 2025-03-20 21:09:09 --> Helper loaded: text_helper
INFO - 2025-03-20 21:09:09 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:09:09 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:09:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:09:09 --> Database Driver Class Initialized
INFO - 2025-03-20 21:09:09 --> Email Class Initialized
INFO - 2025-03-20 21:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:09:09 --> Form Validation Class Initialized
INFO - 2025-03-20 21:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:09:09 --> Pagination Class Initialized
INFO - 2025-03-20 21:09:09 --> Controller Class Initialized
DEBUG - 2025-03-20 21:09:09 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:09:09 --> Model Class Initialized
DEBUG - 2025-03-20 21:09:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:09:09 --> Model Class Initialized
INFO - 2025-03-20 21:09:09 --> Final output sent to browser
DEBUG - 2025-03-20 21:09:09 --> Total execution time: 0.0082
INFO - 2025-03-20 21:09:13 --> Config Class Initialized
INFO - 2025-03-20 21:09:13 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:09:13 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:09:13 --> Utf8 Class Initialized
INFO - 2025-03-20 21:09:13 --> URI Class Initialized
DEBUG - 2025-03-20 21:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:09:13 --> Router Class Initialized
INFO - 2025-03-20 21:09:13 --> Output Class Initialized
INFO - 2025-03-20 21:09:13 --> Security Class Initialized
DEBUG - 2025-03-20 21:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:09:13 --> Input Class Initialized
INFO - 2025-03-20 21:09:13 --> Language Class Initialized
INFO - 2025-03-20 21:09:13 --> Language Class Initialized
INFO - 2025-03-20 21:09:13 --> Config Class Initialized
INFO - 2025-03-20 21:09:13 --> Loader Class Initialized
INFO - 2025-03-20 21:09:13 --> Helper loaded: url_helper
INFO - 2025-03-20 21:09:13 --> Helper loaded: file_helper
INFO - 2025-03-20 21:09:13 --> Helper loaded: html_helper
INFO - 2025-03-20 21:09:13 --> Helper loaded: form_helper
INFO - 2025-03-20 21:09:13 --> Helper loaded: text_helper
INFO - 2025-03-20 21:09:13 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:09:13 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:09:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:09:13 --> Database Driver Class Initialized
INFO - 2025-03-20 21:09:13 --> Email Class Initialized
INFO - 2025-03-20 21:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:09:13 --> Form Validation Class Initialized
INFO - 2025-03-20 21:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:09:13 --> Pagination Class Initialized
INFO - 2025-03-20 21:09:13 --> Controller Class Initialized
DEBUG - 2025-03-20 21:09:13 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:09:13 --> Model Class Initialized
DEBUG - 2025-03-20 21:09:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:09:13 --> Model Class Initialized
INFO - 2025-03-20 21:09:13 --> Final output sent to browser
DEBUG - 2025-03-20 21:09:13 --> Total execution time: 0.0106
INFO - 2025-03-20 21:09:19 --> Config Class Initialized
INFO - 2025-03-20 21:09:19 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:09:19 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:09:19 --> Utf8 Class Initialized
INFO - 2025-03-20 21:09:19 --> URI Class Initialized
DEBUG - 2025-03-20 21:09:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:09:19 --> Router Class Initialized
INFO - 2025-03-20 21:09:19 --> Output Class Initialized
INFO - 2025-03-20 21:09:19 --> Security Class Initialized
DEBUG - 2025-03-20 21:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:09:19 --> Input Class Initialized
INFO - 2025-03-20 21:09:19 --> Language Class Initialized
INFO - 2025-03-20 21:09:19 --> Language Class Initialized
INFO - 2025-03-20 21:09:19 --> Config Class Initialized
INFO - 2025-03-20 21:09:19 --> Loader Class Initialized
INFO - 2025-03-20 21:09:19 --> Helper loaded: url_helper
INFO - 2025-03-20 21:09:19 --> Helper loaded: file_helper
INFO - 2025-03-20 21:09:19 --> Helper loaded: html_helper
INFO - 2025-03-20 21:09:19 --> Helper loaded: form_helper
INFO - 2025-03-20 21:09:19 --> Helper loaded: text_helper
INFO - 2025-03-20 21:09:19 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:09:19 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:09:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:09:19 --> Database Driver Class Initialized
INFO - 2025-03-20 21:09:19 --> Email Class Initialized
INFO - 2025-03-20 21:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:09:19 --> Form Validation Class Initialized
INFO - 2025-03-20 21:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:09:19 --> Pagination Class Initialized
INFO - 2025-03-20 21:09:19 --> Controller Class Initialized
DEBUG - 2025-03-20 21:09:19 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:09:19 --> Model Class Initialized
DEBUG - 2025-03-20 21:09:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:09:19 --> Model Class Initialized
INFO - 2025-03-20 21:09:19 --> Final output sent to browser
DEBUG - 2025-03-20 21:09:19 --> Total execution time: 0.0115
INFO - 2025-03-20 21:11:15 --> Config Class Initialized
INFO - 2025-03-20 21:11:15 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:11:15 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:11:15 --> Utf8 Class Initialized
INFO - 2025-03-20 21:11:15 --> URI Class Initialized
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:11:15 --> Router Class Initialized
INFO - 2025-03-20 21:11:15 --> Output Class Initialized
INFO - 2025-03-20 21:11:15 --> Security Class Initialized
DEBUG - 2025-03-20 21:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:11:15 --> Input Class Initialized
INFO - 2025-03-20 21:11:15 --> Language Class Initialized
INFO - 2025-03-20 21:11:15 --> Language Class Initialized
INFO - 2025-03-20 21:11:15 --> Config Class Initialized
INFO - 2025-03-20 21:11:15 --> Loader Class Initialized
INFO - 2025-03-20 21:11:15 --> Helper loaded: url_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: file_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: html_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: form_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: text_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:11:15 --> Database Driver Class Initialized
INFO - 2025-03-20 21:11:15 --> Email Class Initialized
INFO - 2025-03-20 21:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:11:15 --> Form Validation Class Initialized
INFO - 2025-03-20 21:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:11:15 --> Pagination Class Initialized
INFO - 2025-03-20 21:11:15 --> Controller Class Initialized
DEBUG - 2025-03-20 21:11:15 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:11:15 --> Model Class Initialized
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:11:15 --> Model Class Initialized
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:11:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:11:15 --> Model Class Initialized
ERROR - 2025-03-20 21:11:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:11:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:11:15 --> Final output sent to browser
DEBUG - 2025-03-20 21:11:15 --> Total execution time: 0.1227
INFO - 2025-03-20 21:11:15 --> Config Class Initialized
INFO - 2025-03-20 21:11:15 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:11:15 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:11:15 --> Utf8 Class Initialized
INFO - 2025-03-20 21:11:15 --> URI Class Initialized
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:11:15 --> Router Class Initialized
INFO - 2025-03-20 21:11:15 --> Output Class Initialized
INFO - 2025-03-20 21:11:15 --> Security Class Initialized
DEBUG - 2025-03-20 21:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:11:15 --> Input Class Initialized
INFO - 2025-03-20 21:11:15 --> Language Class Initialized
INFO - 2025-03-20 21:11:15 --> Language Class Initialized
INFO - 2025-03-20 21:11:15 --> Config Class Initialized
INFO - 2025-03-20 21:11:15 --> Loader Class Initialized
INFO - 2025-03-20 21:11:15 --> Helper loaded: url_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: file_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: html_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: form_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: text_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:11:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:11:15 --> Database Driver Class Initialized
INFO - 2025-03-20 21:11:15 --> Email Class Initialized
INFO - 2025-03-20 21:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:11:15 --> Form Validation Class Initialized
INFO - 2025-03-20 21:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:11:15 --> Pagination Class Initialized
INFO - 2025-03-20 21:11:15 --> Controller Class Initialized
DEBUG - 2025-03-20 21:11:15 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:11:15 --> Model Class Initialized
DEBUG - 2025-03-20 21:11:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:11:15 --> Model Class Initialized
INFO - 2025-03-20 21:11:15 --> Final output sent to browser
DEBUG - 2025-03-20 21:11:15 --> Total execution time: 0.0086
INFO - 2025-03-20 21:11:20 --> Config Class Initialized
INFO - 2025-03-20 21:11:20 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:11:20 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:11:20 --> Utf8 Class Initialized
INFO - 2025-03-20 21:11:20 --> URI Class Initialized
DEBUG - 2025-03-20 21:11:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:11:20 --> Router Class Initialized
INFO - 2025-03-20 21:11:20 --> Output Class Initialized
INFO - 2025-03-20 21:11:20 --> Security Class Initialized
DEBUG - 2025-03-20 21:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:11:20 --> Input Class Initialized
INFO - 2025-03-20 21:11:20 --> Language Class Initialized
INFO - 2025-03-20 21:11:20 --> Language Class Initialized
INFO - 2025-03-20 21:11:20 --> Config Class Initialized
INFO - 2025-03-20 21:11:20 --> Loader Class Initialized
INFO - 2025-03-20 21:11:20 --> Helper loaded: url_helper
INFO - 2025-03-20 21:11:20 --> Helper loaded: file_helper
INFO - 2025-03-20 21:11:20 --> Helper loaded: html_helper
INFO - 2025-03-20 21:11:20 --> Helper loaded: form_helper
INFO - 2025-03-20 21:11:20 --> Helper loaded: text_helper
INFO - 2025-03-20 21:11:20 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:11:20 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:11:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:11:20 --> Database Driver Class Initialized
INFO - 2025-03-20 21:11:20 --> Email Class Initialized
INFO - 2025-03-20 21:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:11:20 --> Form Validation Class Initialized
INFO - 2025-03-20 21:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:11:20 --> Pagination Class Initialized
INFO - 2025-03-20 21:11:20 --> Controller Class Initialized
DEBUG - 2025-03-20 21:11:20 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:11:20 --> Model Class Initialized
DEBUG - 2025-03-20 21:11:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:11:20 --> Model Class Initialized
INFO - 2025-03-20 21:11:20 --> Final output sent to browser
DEBUG - 2025-03-20 21:11:20 --> Total execution time: 0.0100
INFO - 2025-03-20 21:11:31 --> Config Class Initialized
INFO - 2025-03-20 21:11:31 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:11:31 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:11:31 --> Utf8 Class Initialized
INFO - 2025-03-20 21:11:31 --> URI Class Initialized
DEBUG - 2025-03-20 21:11:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:11:31 --> Router Class Initialized
INFO - 2025-03-20 21:11:31 --> Output Class Initialized
INFO - 2025-03-20 21:11:31 --> Security Class Initialized
DEBUG - 2025-03-20 21:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:11:31 --> Input Class Initialized
INFO - 2025-03-20 21:11:31 --> Language Class Initialized
INFO - 2025-03-20 21:11:31 --> Language Class Initialized
INFO - 2025-03-20 21:11:31 --> Config Class Initialized
INFO - 2025-03-20 21:11:31 --> Loader Class Initialized
INFO - 2025-03-20 21:11:31 --> Helper loaded: url_helper
INFO - 2025-03-20 21:11:31 --> Helper loaded: file_helper
INFO - 2025-03-20 21:11:31 --> Helper loaded: html_helper
INFO - 2025-03-20 21:11:31 --> Helper loaded: form_helper
INFO - 2025-03-20 21:11:31 --> Helper loaded: text_helper
INFO - 2025-03-20 21:11:31 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:11:31 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:11:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:11:31 --> Database Driver Class Initialized
INFO - 2025-03-20 21:11:31 --> Email Class Initialized
INFO - 2025-03-20 21:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:11:31 --> Form Validation Class Initialized
INFO - 2025-03-20 21:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:11:31 --> Pagination Class Initialized
INFO - 2025-03-20 21:11:31 --> Controller Class Initialized
DEBUG - 2025-03-20 21:11:31 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:11:31 --> Model Class Initialized
DEBUG - 2025-03-20 21:11:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:11:31 --> Model Class Initialized
INFO - 2025-03-20 21:11:31 --> Final output sent to browser
DEBUG - 2025-03-20 21:11:31 --> Total execution time: 0.0120
INFO - 2025-03-20 21:13:59 --> Config Class Initialized
INFO - 2025-03-20 21:13:59 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:13:59 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:13:59 --> Utf8 Class Initialized
INFO - 2025-03-20 21:13:59 --> URI Class Initialized
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:13:59 --> Router Class Initialized
INFO - 2025-03-20 21:13:59 --> Output Class Initialized
INFO - 2025-03-20 21:13:59 --> Security Class Initialized
DEBUG - 2025-03-20 21:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:13:59 --> Input Class Initialized
INFO - 2025-03-20 21:13:59 --> Language Class Initialized
INFO - 2025-03-20 21:13:59 --> Language Class Initialized
INFO - 2025-03-20 21:13:59 --> Config Class Initialized
INFO - 2025-03-20 21:13:59 --> Loader Class Initialized
INFO - 2025-03-20 21:13:59 --> Helper loaded: url_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: file_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: html_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: form_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: text_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:13:59 --> Database Driver Class Initialized
INFO - 2025-03-20 21:13:59 --> Email Class Initialized
INFO - 2025-03-20 21:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:13:59 --> Form Validation Class Initialized
INFO - 2025-03-20 21:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:13:59 --> Pagination Class Initialized
INFO - 2025-03-20 21:13:59 --> Controller Class Initialized
DEBUG - 2025-03-20 21:13:59 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:13:59 --> Model Class Initialized
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:13:59 --> Model Class Initialized
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:13:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:13:59 --> Model Class Initialized
ERROR - 2025-03-20 21:13:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:13:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report.php
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:13:59 --> Final output sent to browser
DEBUG - 2025-03-20 21:13:59 --> Total execution time: 0.1475
INFO - 2025-03-20 21:13:59 --> Config Class Initialized
INFO - 2025-03-20 21:13:59 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:13:59 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:13:59 --> Utf8 Class Initialized
INFO - 2025-03-20 21:13:59 --> URI Class Initialized
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:13:59 --> Router Class Initialized
INFO - 2025-03-20 21:13:59 --> Output Class Initialized
INFO - 2025-03-20 21:13:59 --> Security Class Initialized
DEBUG - 2025-03-20 21:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:13:59 --> Input Class Initialized
INFO - 2025-03-20 21:13:59 --> Language Class Initialized
INFO - 2025-03-20 21:13:59 --> Language Class Initialized
INFO - 2025-03-20 21:13:59 --> Config Class Initialized
INFO - 2025-03-20 21:13:59 --> Loader Class Initialized
INFO - 2025-03-20 21:13:59 --> Helper loaded: url_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: file_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: html_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: form_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: text_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:13:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:13:59 --> Database Driver Class Initialized
INFO - 2025-03-20 21:13:59 --> Email Class Initialized
INFO - 2025-03-20 21:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:13:59 --> Form Validation Class Initialized
INFO - 2025-03-20 21:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:13:59 --> Pagination Class Initialized
INFO - 2025-03-20 21:13:59 --> Controller Class Initialized
DEBUG - 2025-03-20 21:13:59 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:13:59 --> Model Class Initialized
DEBUG - 2025-03-20 21:13:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:13:59 --> Model Class Initialized
INFO - 2025-03-20 21:13:59 --> Final output sent to browser
DEBUG - 2025-03-20 21:13:59 --> Total execution time: 0.0089
INFO - 2025-03-20 21:14:05 --> Config Class Initialized
INFO - 2025-03-20 21:14:05 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:14:05 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:14:05 --> Utf8 Class Initialized
INFO - 2025-03-20 21:14:05 --> URI Class Initialized
DEBUG - 2025-03-20 21:14:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:14:05 --> Router Class Initialized
INFO - 2025-03-20 21:14:05 --> Output Class Initialized
INFO - 2025-03-20 21:14:05 --> Security Class Initialized
DEBUG - 2025-03-20 21:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:14:05 --> Input Class Initialized
INFO - 2025-03-20 21:14:05 --> Language Class Initialized
INFO - 2025-03-20 21:14:05 --> Language Class Initialized
INFO - 2025-03-20 21:14:05 --> Config Class Initialized
INFO - 2025-03-20 21:14:05 --> Loader Class Initialized
INFO - 2025-03-20 21:14:05 --> Helper loaded: url_helper
INFO - 2025-03-20 21:14:05 --> Helper loaded: file_helper
INFO - 2025-03-20 21:14:05 --> Helper loaded: html_helper
INFO - 2025-03-20 21:14:05 --> Helper loaded: form_helper
INFO - 2025-03-20 21:14:05 --> Helper loaded: text_helper
INFO - 2025-03-20 21:14:05 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:14:05 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:14:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:14:05 --> Database Driver Class Initialized
INFO - 2025-03-20 21:14:05 --> Email Class Initialized
INFO - 2025-03-20 21:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:14:05 --> Form Validation Class Initialized
INFO - 2025-03-20 21:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:14:05 --> Pagination Class Initialized
INFO - 2025-03-20 21:14:05 --> Controller Class Initialized
DEBUG - 2025-03-20 21:14:05 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:14:05 --> Model Class Initialized
DEBUG - 2025-03-20 21:14:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:14:05 --> Model Class Initialized
INFO - 2025-03-20 21:14:05 --> Final output sent to browser
DEBUG - 2025-03-20 21:14:05 --> Total execution time: 0.0114
INFO - 2025-03-20 21:14:10 --> Config Class Initialized
INFO - 2025-03-20 21:14:10 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:14:10 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:14:10 --> Utf8 Class Initialized
INFO - 2025-03-20 21:14:10 --> URI Class Initialized
DEBUG - 2025-03-20 21:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:14:10 --> Router Class Initialized
INFO - 2025-03-20 21:14:10 --> Output Class Initialized
INFO - 2025-03-20 21:14:10 --> Security Class Initialized
DEBUG - 2025-03-20 21:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:14:10 --> Input Class Initialized
INFO - 2025-03-20 21:14:10 --> Language Class Initialized
INFO - 2025-03-20 21:14:10 --> Language Class Initialized
INFO - 2025-03-20 21:14:10 --> Config Class Initialized
INFO - 2025-03-20 21:14:10 --> Loader Class Initialized
INFO - 2025-03-20 21:14:10 --> Helper loaded: url_helper
INFO - 2025-03-20 21:14:10 --> Helper loaded: file_helper
INFO - 2025-03-20 21:14:10 --> Helper loaded: html_helper
INFO - 2025-03-20 21:14:10 --> Helper loaded: form_helper
INFO - 2025-03-20 21:14:10 --> Helper loaded: text_helper
INFO - 2025-03-20 21:14:10 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:14:10 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:14:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:14:10 --> Database Driver Class Initialized
INFO - 2025-03-20 21:14:10 --> Email Class Initialized
INFO - 2025-03-20 21:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:14:10 --> Form Validation Class Initialized
INFO - 2025-03-20 21:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:14:10 --> Pagination Class Initialized
INFO - 2025-03-20 21:14:10 --> Controller Class Initialized
DEBUG - 2025-03-20 21:14:10 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:14:10 --> Model Class Initialized
DEBUG - 2025-03-20 21:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:14:10 --> Model Class Initialized
INFO - 2025-03-20 21:14:10 --> Final output sent to browser
DEBUG - 2025-03-20 21:14:10 --> Total execution time: 0.0104
INFO - 2025-03-20 21:14:46 --> Config Class Initialized
INFO - 2025-03-20 21:14:46 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:14:46 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:14:46 --> Utf8 Class Initialized
INFO - 2025-03-20 21:14:46 --> URI Class Initialized
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-20 21:14:46 --> Router Class Initialized
INFO - 2025-03-20 21:14:46 --> Output Class Initialized
INFO - 2025-03-20 21:14:46 --> Security Class Initialized
DEBUG - 2025-03-20 21:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:14:46 --> Input Class Initialized
INFO - 2025-03-20 21:14:46 --> Language Class Initialized
INFO - 2025-03-20 21:14:46 --> Language Class Initialized
INFO - 2025-03-20 21:14:46 --> Config Class Initialized
INFO - 2025-03-20 21:14:46 --> Loader Class Initialized
INFO - 2025-03-20 21:14:46 --> Helper loaded: url_helper
INFO - 2025-03-20 21:14:46 --> Helper loaded: file_helper
INFO - 2025-03-20 21:14:46 --> Helper loaded: html_helper
INFO - 2025-03-20 21:14:46 --> Helper loaded: form_helper
INFO - 2025-03-20 21:14:46 --> Helper loaded: text_helper
INFO - 2025-03-20 21:14:46 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:14:46 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:14:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:14:46 --> Database Driver Class Initialized
INFO - 2025-03-20 21:14:46 --> Email Class Initialized
INFO - 2025-03-20 21:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:14:46 --> Form Validation Class Initialized
INFO - 2025-03-20 21:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:14:46 --> Pagination Class Initialized
INFO - 2025-03-20 21:14:46 --> Controller Class Initialized
DEBUG - 2025-03-20 21:14:46 --> Home MX_Controller Initialized
INFO - 2025-03-20 21:14:46 --> Model Class Initialized
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-20 21:14:46 --> Model Class Initialized
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:14:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:14:46 --> Model Class Initialized
ERROR - 2025-03-20 21:14:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:14:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:14:46 --> Final output sent to browser
DEBUG - 2025-03-20 21:14:46 --> Total execution time: 0.1511
INFO - 2025-03-20 21:15:07 --> Config Class Initialized
INFO - 2025-03-20 21:15:07 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:15:07 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:15:07 --> Utf8 Class Initialized
INFO - 2025-03-20 21:15:07 --> URI Class Initialized
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:15:07 --> Router Class Initialized
INFO - 2025-03-20 21:15:07 --> Output Class Initialized
INFO - 2025-03-20 21:15:07 --> Security Class Initialized
DEBUG - 2025-03-20 21:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:15:07 --> Input Class Initialized
INFO - 2025-03-20 21:15:07 --> Language Class Initialized
INFO - 2025-03-20 21:15:07 --> Language Class Initialized
INFO - 2025-03-20 21:15:07 --> Config Class Initialized
INFO - 2025-03-20 21:15:07 --> Loader Class Initialized
INFO - 2025-03-20 21:15:07 --> Helper loaded: url_helper
INFO - 2025-03-20 21:15:07 --> Helper loaded: file_helper
INFO - 2025-03-20 21:15:07 --> Helper loaded: html_helper
INFO - 2025-03-20 21:15:07 --> Helper loaded: form_helper
INFO - 2025-03-20 21:15:07 --> Helper loaded: text_helper
INFO - 2025-03-20 21:15:07 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:15:07 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:15:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:15:07 --> Database Driver Class Initialized
INFO - 2025-03-20 21:15:07 --> Email Class Initialized
INFO - 2025-03-20 21:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:15:07 --> Form Validation Class Initialized
INFO - 2025-03-20 21:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:15:07 --> Pagination Class Initialized
INFO - 2025-03-20 21:15:07 --> Controller Class Initialized
DEBUG - 2025-03-20 21:15:07 --> Product MX_Controller Initialized
INFO - 2025-03-20 21:15:07 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-20 21:15:07 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-20 21:15:07 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:15:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:15:07 --> Model Class Initialized
ERROR - 2025-03-20 21:15:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:15:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:15:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:15:07 --> Final output sent to browser
DEBUG - 2025-03-20 21:15:07 --> Total execution time: 0.1117
INFO - 2025-03-20 21:15:23 --> Config Class Initialized
INFO - 2025-03-20 21:15:23 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:15:23 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:15:23 --> Utf8 Class Initialized
INFO - 2025-03-20 21:15:23 --> URI Class Initialized
DEBUG - 2025-03-20 21:15:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:15:23 --> Router Class Initialized
INFO - 2025-03-20 21:15:23 --> Output Class Initialized
INFO - 2025-03-20 21:15:23 --> Security Class Initialized
DEBUG - 2025-03-20 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:15:23 --> Input Class Initialized
INFO - 2025-03-20 21:15:23 --> Language Class Initialized
INFO - 2025-03-20 21:15:23 --> Language Class Initialized
INFO - 2025-03-20 21:15:23 --> Config Class Initialized
INFO - 2025-03-20 21:15:23 --> Loader Class Initialized
INFO - 2025-03-20 21:15:23 --> Helper loaded: url_helper
INFO - 2025-03-20 21:15:23 --> Helper loaded: file_helper
INFO - 2025-03-20 21:15:23 --> Helper loaded: html_helper
INFO - 2025-03-20 21:15:23 --> Helper loaded: form_helper
INFO - 2025-03-20 21:15:23 --> Helper loaded: text_helper
INFO - 2025-03-20 21:15:23 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:15:23 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:15:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:15:23 --> Database Driver Class Initialized
INFO - 2025-03-20 21:15:23 --> Email Class Initialized
INFO - 2025-03-20 21:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:15:23 --> Form Validation Class Initialized
INFO - 2025-03-20 21:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:15:23 --> Pagination Class Initialized
INFO - 2025-03-20 21:15:23 --> Controller Class Initialized
ERROR - 2025-03-20 21:15:23 --> 404 Page Not Found: ../modules/product/controllers/Product/category_list
INFO - 2025-03-20 21:15:31 --> Config Class Initialized
INFO - 2025-03-20 21:15:31 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:15:31 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:15:31 --> Utf8 Class Initialized
INFO - 2025-03-20 21:15:31 --> URI Class Initialized
DEBUG - 2025-03-20 21:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:15:31 --> Router Class Initialized
INFO - 2025-03-20 21:15:31 --> Output Class Initialized
INFO - 2025-03-20 21:15:31 --> Security Class Initialized
DEBUG - 2025-03-20 21:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:15:31 --> Input Class Initialized
INFO - 2025-03-20 21:15:31 --> Language Class Initialized
INFO - 2025-03-20 21:15:31 --> Language Class Initialized
INFO - 2025-03-20 21:15:31 --> Config Class Initialized
INFO - 2025-03-20 21:15:31 --> Loader Class Initialized
INFO - 2025-03-20 21:15:31 --> Helper loaded: url_helper
INFO - 2025-03-20 21:15:31 --> Helper loaded: file_helper
INFO - 2025-03-20 21:15:31 --> Helper loaded: html_helper
INFO - 2025-03-20 21:15:31 --> Helper loaded: form_helper
INFO - 2025-03-20 21:15:31 --> Helper loaded: text_helper
INFO - 2025-03-20 21:15:31 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:15:31 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:15:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:15:31 --> Database Driver Class Initialized
INFO - 2025-03-20 21:15:31 --> Email Class Initialized
INFO - 2025-03-20 21:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:15:31 --> Form Validation Class Initialized
INFO - 2025-03-20 21:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:15:31 --> Pagination Class Initialized
INFO - 2025-03-20 21:15:31 --> Controller Class Initialized
ERROR - 2025-03-20 21:15:31 --> 404 Page Not Found: ../modules/product/controllers/Product/category_list
INFO - 2025-03-20 21:15:53 --> Config Class Initialized
INFO - 2025-03-20 21:15:53 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:15:53 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:15:53 --> Utf8 Class Initialized
INFO - 2025-03-20 21:15:53 --> URI Class Initialized
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:15:53 --> Router Class Initialized
INFO - 2025-03-20 21:15:53 --> Output Class Initialized
INFO - 2025-03-20 21:15:53 --> Security Class Initialized
DEBUG - 2025-03-20 21:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:15:53 --> Input Class Initialized
INFO - 2025-03-20 21:15:53 --> Language Class Initialized
INFO - 2025-03-20 21:15:53 --> Language Class Initialized
INFO - 2025-03-20 21:15:53 --> Config Class Initialized
INFO - 2025-03-20 21:15:53 --> Loader Class Initialized
INFO - 2025-03-20 21:15:53 --> Helper loaded: url_helper
INFO - 2025-03-20 21:15:53 --> Helper loaded: file_helper
INFO - 2025-03-20 21:15:53 --> Helper loaded: html_helper
INFO - 2025-03-20 21:15:53 --> Helper loaded: form_helper
INFO - 2025-03-20 21:15:53 --> Helper loaded: text_helper
INFO - 2025-03-20 21:15:53 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:15:53 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:15:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:15:53 --> Database Driver Class Initialized
INFO - 2025-03-20 21:15:53 --> Email Class Initialized
INFO - 2025-03-20 21:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:15:53 --> Form Validation Class Initialized
INFO - 2025-03-20 21:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:15:53 --> Pagination Class Initialized
INFO - 2025-03-20 21:15:53 --> Controller Class Initialized
DEBUG - 2025-03-20 21:15:53 --> Product MX_Controller Initialized
INFO - 2025-03-20 21:15:53 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-20 21:15:53 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-20 21:15:53 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:15:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:15:53 --> Model Class Initialized
ERROR - 2025-03-20 21:15:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:15:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:15:53 --> Final output sent to browser
DEBUG - 2025-03-20 21:15:53 --> Total execution time: 0.1127
INFO - 2025-03-20 21:15:58 --> Config Class Initialized
INFO - 2025-03-20 21:15:58 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:15:58 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:15:58 --> Utf8 Class Initialized
INFO - 2025-03-20 21:15:58 --> URI Class Initialized
DEBUG - 2025-03-20 21:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:15:58 --> Router Class Initialized
INFO - 2025-03-20 21:15:58 --> Output Class Initialized
INFO - 2025-03-20 21:15:58 --> Security Class Initialized
DEBUG - 2025-03-20 21:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:15:58 --> Input Class Initialized
INFO - 2025-03-20 21:15:58 --> Language Class Initialized
INFO - 2025-03-20 21:15:58 --> Language Class Initialized
INFO - 2025-03-20 21:15:58 --> Config Class Initialized
INFO - 2025-03-20 21:15:58 --> Loader Class Initialized
INFO - 2025-03-20 21:15:58 --> Helper loaded: url_helper
INFO - 2025-03-20 21:15:58 --> Helper loaded: file_helper
INFO - 2025-03-20 21:15:58 --> Helper loaded: html_helper
INFO - 2025-03-20 21:15:58 --> Helper loaded: form_helper
INFO - 2025-03-20 21:15:58 --> Helper loaded: text_helper
INFO - 2025-03-20 21:15:58 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:15:58 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:15:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:15:58 --> Database Driver Class Initialized
INFO - 2025-03-20 21:15:58 --> Email Class Initialized
INFO - 2025-03-20 21:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:15:58 --> Form Validation Class Initialized
INFO - 2025-03-20 21:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:15:58 --> Pagination Class Initialized
INFO - 2025-03-20 21:15:58 --> Controller Class Initialized
DEBUG - 2025-03-20 21:15:58 --> Product MX_Controller Initialized
INFO - 2025-03-20 21:15:58 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-20 21:15:58 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-20 21:15:58 --> Model Class Initialized
DEBUG - 2025-03-20 21:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:15:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:15:58 --> Model Class Initialized
ERROR - 2025-03-20 21:15:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:15:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-20 21:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:15:59 --> Final output sent to browser
DEBUG - 2025-03-20 21:15:59 --> Total execution time: 0.1491
INFO - 2025-03-20 21:16:09 --> Config Class Initialized
INFO - 2025-03-20 21:16:09 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:16:09 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:16:09 --> Utf8 Class Initialized
INFO - 2025-03-20 21:16:09 --> URI Class Initialized
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:16:09 --> Router Class Initialized
INFO - 2025-03-20 21:16:09 --> Output Class Initialized
INFO - 2025-03-20 21:16:09 --> Security Class Initialized
DEBUG - 2025-03-20 21:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:16:09 --> Input Class Initialized
INFO - 2025-03-20 21:16:09 --> Language Class Initialized
INFO - 2025-03-20 21:16:09 --> Language Class Initialized
INFO - 2025-03-20 21:16:09 --> Config Class Initialized
INFO - 2025-03-20 21:16:09 --> Loader Class Initialized
INFO - 2025-03-20 21:16:09 --> Helper loaded: url_helper
INFO - 2025-03-20 21:16:09 --> Helper loaded: file_helper
INFO - 2025-03-20 21:16:09 --> Helper loaded: html_helper
INFO - 2025-03-20 21:16:09 --> Helper loaded: form_helper
INFO - 2025-03-20 21:16:09 --> Helper loaded: text_helper
INFO - 2025-03-20 21:16:09 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:16:09 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:16:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:16:09 --> Database Driver Class Initialized
INFO - 2025-03-20 21:16:09 --> Email Class Initialized
INFO - 2025-03-20 21:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:16:09 --> Form Validation Class Initialized
INFO - 2025-03-20 21:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:16:09 --> Pagination Class Initialized
INFO - 2025-03-20 21:16:09 --> Controller Class Initialized
DEBUG - 2025-03-20 21:16:09 --> Product MX_Controller Initialized
INFO - 2025-03-20 21:16:09 --> Model Class Initialized
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-20 21:16:09 --> Model Class Initialized
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-20 21:16:09 --> Model Class Initialized
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:16:09 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:16:09 --> Model Class Initialized
ERROR - 2025-03-20 21:16:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:16:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:16:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:16:09 --> Final output sent to browser
DEBUG - 2025-03-20 21:16:09 --> Total execution time: 0.1273
INFO - 2025-03-20 21:17:16 --> Config Class Initialized
INFO - 2025-03-20 21:17:16 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:17:16 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:17:16 --> Utf8 Class Initialized
INFO - 2025-03-20 21:17:16 --> URI Class Initialized
INFO - 2025-03-20 21:17:16 --> Router Class Initialized
INFO - 2025-03-20 21:17:16 --> Output Class Initialized
INFO - 2025-03-20 21:17:16 --> Security Class Initialized
DEBUG - 2025-03-20 21:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:17:16 --> Input Class Initialized
INFO - 2025-03-20 21:17:16 --> Language Class Initialized
ERROR - 2025-03-20 21:17:16 --> 404 Page Not Found: Api/product
INFO - 2025-03-20 21:17:21 --> Config Class Initialized
INFO - 2025-03-20 21:17:21 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:17:21 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:17:21 --> Utf8 Class Initialized
INFO - 2025-03-20 21:17:21 --> URI Class Initialized
INFO - 2025-03-20 21:17:21 --> Router Class Initialized
INFO - 2025-03-20 21:17:21 --> Output Class Initialized
INFO - 2025-03-20 21:17:21 --> Security Class Initialized
DEBUG - 2025-03-20 21:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:17:21 --> Input Class Initialized
INFO - 2025-03-20 21:17:21 --> Language Class Initialized
INFO - 2025-03-20 21:17:21 --> Language Class Initialized
INFO - 2025-03-20 21:17:21 --> Config Class Initialized
INFO - 2025-03-20 21:17:21 --> Loader Class Initialized
INFO - 2025-03-20 21:17:21 --> Helper loaded: url_helper
INFO - 2025-03-20 21:17:21 --> Helper loaded: file_helper
INFO - 2025-03-20 21:17:21 --> Helper loaded: html_helper
INFO - 2025-03-20 21:17:21 --> Helper loaded: form_helper
INFO - 2025-03-20 21:17:21 --> Helper loaded: text_helper
INFO - 2025-03-20 21:17:21 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:17:21 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:17:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:17:21 --> Database Driver Class Initialized
INFO - 2025-03-20 21:17:21 --> Email Class Initialized
INFO - 2025-03-20 21:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:17:21 --> Form Validation Class Initialized
INFO - 2025-03-20 21:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:17:21 --> Pagination Class Initialized
INFO - 2025-03-20 21:17:21 --> Controller Class Initialized
INFO - 2025-03-20 21:17:21 --> Model Class Initialized
INFO - 2025-03-20 21:17:21 --> Final output sent to browser
DEBUG - 2025-03-20 21:17:21 --> Total execution time: 0.0169
INFO - 2025-03-20 21:20:20 --> Config Class Initialized
INFO - 2025-03-20 21:20:20 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:20:20 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:20:20 --> Utf8 Class Initialized
INFO - 2025-03-20 21:20:20 --> URI Class Initialized
DEBUG - 2025-03-20 21:20:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:20:20 --> Router Class Initialized
INFO - 2025-03-20 21:20:20 --> Output Class Initialized
INFO - 2025-03-20 21:20:20 --> Security Class Initialized
DEBUG - 2025-03-20 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:20:20 --> Input Class Initialized
INFO - 2025-03-20 21:20:20 --> Language Class Initialized
INFO - 2025-03-20 21:20:20 --> Language Class Initialized
INFO - 2025-03-20 21:20:20 --> Config Class Initialized
INFO - 2025-03-20 21:20:20 --> Loader Class Initialized
INFO - 2025-03-20 21:20:20 --> Helper loaded: url_helper
INFO - 2025-03-20 21:20:20 --> Helper loaded: file_helper
INFO - 2025-03-20 21:20:20 --> Helper loaded: html_helper
INFO - 2025-03-20 21:20:20 --> Helper loaded: form_helper
INFO - 2025-03-20 21:20:20 --> Helper loaded: text_helper
INFO - 2025-03-20 21:20:20 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:20:20 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:20:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:20:20 --> Database Driver Class Initialized
INFO - 2025-03-20 21:20:20 --> Email Class Initialized
INFO - 2025-03-20 21:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:20:20 --> Form Validation Class Initialized
INFO - 2025-03-20 21:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:20:20 --> Pagination Class Initialized
INFO - 2025-03-20 21:20:20 --> Controller Class Initialized
DEBUG - 2025-03-20 21:20:20 --> Product MX_Controller Initialized
INFO - 2025-03-20 21:20:20 --> Model Class Initialized
DEBUG - 2025-03-20 21:20:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-20 21:20:20 --> Model Class Initialized
DEBUG - 2025-03-20 21:20:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-20 21:20:20 --> Model Class Initialized
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:20:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:20:21 --> Model Class Initialized
ERROR - 2025-03-20 21:20:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:20:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:20:21 --> Final output sent to browser
DEBUG - 2025-03-20 21:20:21 --> Total execution time: 0.1225
INFO - 2025-03-20 21:20:21 --> Config Class Initialized
INFO - 2025-03-20 21:20:21 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:20:21 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:20:21 --> Utf8 Class Initialized
INFO - 2025-03-20 21:20:21 --> URI Class Initialized
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-20 21:20:21 --> Router Class Initialized
INFO - 2025-03-20 21:20:21 --> Output Class Initialized
INFO - 2025-03-20 21:20:21 --> Security Class Initialized
DEBUG - 2025-03-20 21:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:20:21 --> Input Class Initialized
INFO - 2025-03-20 21:20:21 --> Language Class Initialized
INFO - 2025-03-20 21:20:21 --> Language Class Initialized
INFO - 2025-03-20 21:20:21 --> Config Class Initialized
INFO - 2025-03-20 21:20:21 --> Loader Class Initialized
INFO - 2025-03-20 21:20:21 --> Helper loaded: url_helper
INFO - 2025-03-20 21:20:21 --> Helper loaded: file_helper
INFO - 2025-03-20 21:20:21 --> Helper loaded: html_helper
INFO - 2025-03-20 21:20:21 --> Helper loaded: form_helper
INFO - 2025-03-20 21:20:21 --> Helper loaded: text_helper
INFO - 2025-03-20 21:20:21 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:20:21 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:20:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:20:21 --> Database Driver Class Initialized
INFO - 2025-03-20 21:20:21 --> Email Class Initialized
INFO - 2025-03-20 21:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:20:21 --> Form Validation Class Initialized
INFO - 2025-03-20 21:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:20:21 --> Pagination Class Initialized
INFO - 2025-03-20 21:20:21 --> Controller Class Initialized
DEBUG - 2025-03-20 21:20:21 --> Product MX_Controller Initialized
INFO - 2025-03-20 21:20:21 --> Model Class Initialized
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-20 21:20:21 --> Model Class Initialized
DEBUG - 2025-03-20 21:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-20 21:20:21 --> Model Class Initialized
ERROR - 2025-03-20 21:20:21 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-20 21:20:21 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-20 21:20:21 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-20 21:20:21 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-20 21:20:21 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-20 21:20:21 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-20 21:20:21 --> Final output sent to browser
DEBUG - 2025-03-20 21:20:21 --> Total execution time: 0.0323
INFO - 2025-03-20 21:20:33 --> Config Class Initialized
INFO - 2025-03-20 21:20:33 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:20:33 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:20:33 --> Utf8 Class Initialized
INFO - 2025-03-20 21:20:33 --> URI Class Initialized
INFO - 2025-03-20 21:20:33 --> Router Class Initialized
INFO - 2025-03-20 21:20:33 --> Output Class Initialized
INFO - 2025-03-20 21:20:33 --> Security Class Initialized
DEBUG - 2025-03-20 21:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:20:33 --> Input Class Initialized
INFO - 2025-03-20 21:20:33 --> Language Class Initialized
INFO - 2025-03-20 21:20:33 --> Language Class Initialized
INFO - 2025-03-20 21:20:33 --> Config Class Initialized
INFO - 2025-03-20 21:20:33 --> Loader Class Initialized
INFO - 2025-03-20 21:20:33 --> Helper loaded: url_helper
INFO - 2025-03-20 21:20:33 --> Helper loaded: file_helper
INFO - 2025-03-20 21:20:33 --> Helper loaded: html_helper
INFO - 2025-03-20 21:20:33 --> Helper loaded: form_helper
INFO - 2025-03-20 21:20:33 --> Helper loaded: text_helper
INFO - 2025-03-20 21:20:33 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:20:33 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:20:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:20:33 --> Database Driver Class Initialized
INFO - 2025-03-20 21:20:33 --> Email Class Initialized
INFO - 2025-03-20 21:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:20:33 --> Form Validation Class Initialized
INFO - 2025-03-20 21:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:20:33 --> Pagination Class Initialized
INFO - 2025-03-20 21:20:33 --> Controller Class Initialized
INFO - 2025-03-20 21:20:33 --> Model Class Initialized
INFO - 2025-03-20 21:20:34 --> Final output sent to browser
DEBUG - 2025-03-20 21:20:34 --> Total execution time: 0.0619
INFO - 2025-03-20 21:21:43 --> Config Class Initialized
INFO - 2025-03-20 21:21:43 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:21:43 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:21:43 --> Utf8 Class Initialized
INFO - 2025-03-20 21:21:43 --> URI Class Initialized
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:21:43 --> Router Class Initialized
INFO - 2025-03-20 21:21:43 --> Output Class Initialized
INFO - 2025-03-20 21:21:43 --> Security Class Initialized
DEBUG - 2025-03-20 21:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:21:43 --> Input Class Initialized
INFO - 2025-03-20 21:21:43 --> Language Class Initialized
INFO - 2025-03-20 21:21:43 --> Language Class Initialized
INFO - 2025-03-20 21:21:43 --> Config Class Initialized
INFO - 2025-03-20 21:21:43 --> Loader Class Initialized
INFO - 2025-03-20 21:21:43 --> Helper loaded: url_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: file_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: html_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: form_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: text_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:21:43 --> Database Driver Class Initialized
INFO - 2025-03-20 21:21:43 --> Email Class Initialized
INFO - 2025-03-20 21:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:21:43 --> Form Validation Class Initialized
INFO - 2025-03-20 21:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:21:43 --> Pagination Class Initialized
INFO - 2025-03-20 21:21:43 --> Controller Class Initialized
DEBUG - 2025-03-20 21:21:43 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:21:43 --> Model Class Initialized
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:21:43 --> Model Class Initialized
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-20 21:21:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-20 21:21:43 --> Model Class Initialized
ERROR - 2025-03-20 21:21:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-20 21:21:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-20 21:21:43 --> Final output sent to browser
DEBUG - 2025-03-20 21:21:43 --> Total execution time: 0.1327
INFO - 2025-03-20 21:21:43 --> Config Class Initialized
INFO - 2025-03-20 21:21:43 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:21:43 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:21:43 --> Utf8 Class Initialized
INFO - 2025-03-20 21:21:43 --> URI Class Initialized
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-20 21:21:43 --> Router Class Initialized
INFO - 2025-03-20 21:21:43 --> Output Class Initialized
INFO - 2025-03-20 21:21:43 --> Security Class Initialized
DEBUG - 2025-03-20 21:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:21:43 --> Input Class Initialized
INFO - 2025-03-20 21:21:43 --> Language Class Initialized
INFO - 2025-03-20 21:21:43 --> Language Class Initialized
INFO - 2025-03-20 21:21:43 --> Config Class Initialized
INFO - 2025-03-20 21:21:43 --> Loader Class Initialized
INFO - 2025-03-20 21:21:43 --> Helper loaded: url_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: file_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: html_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: form_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: text_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:21:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:21:43 --> Database Driver Class Initialized
INFO - 2025-03-20 21:21:43 --> Email Class Initialized
INFO - 2025-03-20 21:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:21:43 --> Form Validation Class Initialized
INFO - 2025-03-20 21:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:21:43 --> Pagination Class Initialized
INFO - 2025-03-20 21:21:43 --> Controller Class Initialized
DEBUG - 2025-03-20 21:21:43 --> Report MX_Controller Initialized
INFO - 2025-03-20 21:21:43 --> Model Class Initialized
DEBUG - 2025-03-20 21:21:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-20 21:21:43 --> Model Class Initialized
INFO - 2025-03-20 21:21:44 --> Final output sent to browser
DEBUG - 2025-03-20 21:21:44 --> Total execution time: 0.0211
INFO - 2025-03-20 21:21:58 --> Config Class Initialized
INFO - 2025-03-20 21:21:58 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:21:58 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:21:58 --> Utf8 Class Initialized
INFO - 2025-03-20 21:21:58 --> URI Class Initialized
INFO - 2025-03-20 21:21:58 --> Router Class Initialized
INFO - 2025-03-20 21:21:58 --> Output Class Initialized
INFO - 2025-03-20 21:21:58 --> Security Class Initialized
DEBUG - 2025-03-20 21:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:21:58 --> Input Class Initialized
INFO - 2025-03-20 21:21:58 --> Language Class Initialized
ERROR - 2025-03-20 21:21:58 --> 404 Page Not Found: Api/stock
INFO - 2025-03-20 21:22:24 --> Config Class Initialized
INFO - 2025-03-20 21:22:24 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:22:24 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:22:24 --> Utf8 Class Initialized
INFO - 2025-03-20 21:22:24 --> URI Class Initialized
INFO - 2025-03-20 21:22:24 --> Router Class Initialized
INFO - 2025-03-20 21:22:24 --> Output Class Initialized
INFO - 2025-03-20 21:22:24 --> Security Class Initialized
DEBUG - 2025-03-20 21:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:22:24 --> Input Class Initialized
INFO - 2025-03-20 21:22:24 --> Language Class Initialized
ERROR - 2025-03-20 21:22:24 --> 404 Page Not Found: Api/stock_qty
INFO - 2025-03-20 21:22:46 --> Config Class Initialized
INFO - 2025-03-20 21:22:46 --> Hooks Class Initialized
DEBUG - 2025-03-20 21:22:46 --> UTF-8 Support Enabled
INFO - 2025-03-20 21:22:46 --> Utf8 Class Initialized
INFO - 2025-03-20 21:22:46 --> URI Class Initialized
INFO - 2025-03-20 21:22:46 --> Router Class Initialized
INFO - 2025-03-20 21:22:46 --> Output Class Initialized
INFO - 2025-03-20 21:22:46 --> Security Class Initialized
DEBUG - 2025-03-20 21:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-20 21:22:46 --> Input Class Initialized
INFO - 2025-03-20 21:22:46 --> Language Class Initialized
INFO - 2025-03-20 21:22:46 --> Language Class Initialized
INFO - 2025-03-20 21:22:46 --> Config Class Initialized
INFO - 2025-03-20 21:22:46 --> Loader Class Initialized
INFO - 2025-03-20 21:22:46 --> Helper loaded: url_helper
INFO - 2025-03-20 21:22:46 --> Helper loaded: file_helper
INFO - 2025-03-20 21:22:46 --> Helper loaded: html_helper
INFO - 2025-03-20 21:22:46 --> Helper loaded: form_helper
INFO - 2025-03-20 21:22:46 --> Helper loaded: text_helper
INFO - 2025-03-20 21:22:46 --> Helper loaded: lang_helper
INFO - 2025-03-20 21:22:46 --> Helper loaded: directory_helper
INFO - 2025-03-20 21:22:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-20 21:22:46 --> Database Driver Class Initialized
INFO - 2025-03-20 21:22:46 --> Email Class Initialized
INFO - 2025-03-20 21:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-20 21:22:46 --> Form Validation Class Initialized
INFO - 2025-03-20 21:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-20 21:22:46 --> Pagination Class Initialized
INFO - 2025-03-20 21:22:46 --> Controller Class Initialized
INFO - 2025-03-20 21:22:46 --> Model Class Initialized
INFO - 2025-03-20 21:22:46 --> Final output sent to browser
DEBUG - 2025-03-20 21:22:46 --> Total execution time: 0.0092
