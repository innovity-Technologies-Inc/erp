<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-10 00:00:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:00:13 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
ERROR - 2025-04-10 00:00:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:00:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:00:13 --> Final output sent to browser
DEBUG - 2025-04-10 00:00:13 --> Total execution time: 0.1148
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:00:13 --> Model Class Initialized
INFO - 2025-04-10 00:00:13 --> Final output sent to browser
DEBUG - 2025-04-10 00:00:13 --> Total execution time: 0.0068
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:00:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
ERROR - 2025-04-10 00:00:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:00:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:00:23 --> Final output sent to browser
DEBUG - 2025-04-10 00:00:23 --> Total execution time: 0.1525
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:00:23 --> Model Class Initialized
INFO - 2025-04-10 00:00:23 --> Final output sent to browser
DEBUG - 2025-04-10 00:00:23 --> Total execution time: 0.0079
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:01:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
ERROR - 2025-04-10 00:01:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:01:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:01:55 --> Final output sent to browser
DEBUG - 2025-04-10 00:01:55 --> Total execution time: 0.0912
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:01:55 --> Model Class Initialized
INFO - 2025-04-10 00:01:55 --> Final output sent to browser
DEBUG - 2025-04-10 00:01:55 --> Total execution time: 0.0078
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:02:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
ERROR - 2025-04-10 00:02:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:02:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:02:01 --> Final output sent to browser
DEBUG - 2025-04-10 00:02:01 --> Total execution time: 0.2104
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:02:01 --> Model Class Initialized
INFO - 2025-04-10 00:02:01 --> Final output sent to browser
DEBUG - 2025-04-10 00:02:01 --> Total execution time: 0.0097
INFO - 2025-04-10 00:05:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:05:05 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:05:05 --> Model Class Initialized
ERROR - 2025-04-10 00:05:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:05:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:05:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:05:05 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:05 --> Total execution time: 0.1231
INFO - 2025-04-10 00:05:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:06 --> Model Class Initialized
INFO - 2025-04-10 00:05:06 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:06 --> Total execution time: 0.0113
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:05:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
ERROR - 2025-04-10 00:05:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:05:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:05:15 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:15 --> Total execution time: 0.1841
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:15 --> Model Class Initialized
INFO - 2025-04-10 00:05:15 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:15 --> Total execution time: 0.0067
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:05:29 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
ERROR - 2025-04-10 00:05:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:05:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:05:29 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:29 --> Total execution time: 0.1498
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:29 --> Model Class Initialized
INFO - 2025-04-10 00:05:29 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:29 --> Total execution time: 0.0081
INFO - 2025-04-10 00:05:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:05:37 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:05:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:05:37 --> Model Class Initialized
ERROR - 2025-04-10 00:05:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:05:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:05:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:05:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:05:38 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:38 --> Total execution time: 0.1583
INFO - 2025-04-10 00:05:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:05:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:05:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:05:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:05:38 --> Model Class Initialized
INFO - 2025-04-10 00:05:38 --> Final output sent to browser
DEBUG - 2025-04-10 00:05:38 --> Total execution time: 0.0083
INFO - 2025-04-10 00:06:34 --> Model Class Initialized
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:06:34 --> Model Class Initialized
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:06:34 --> Model Class Initialized
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:06:34 --> Model Class Initialized
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:06:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:06:34 --> Model Class Initialized
ERROR - 2025-04-10 00:06:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:06:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:06:34 --> Final output sent to browser
DEBUG - 2025-04-10 00:06:34 --> Total execution time: 0.1018
INFO - 2025-04-10 00:06:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:06:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:06:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:06:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:06:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:06:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:06:35 --> Model Class Initialized
INFO - 2025-04-10 00:06:35 --> Final output sent to browser
DEBUG - 2025-04-10 00:06:35 --> Total execution time: 0.0076
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:09:40 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
ERROR - 2025-04-10 00:09:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:09:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:09:40 --> Final output sent to browser
DEBUG - 2025-04-10 00:09:40 --> Total execution time: 0.1313
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:09:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:09:40 --> Model Class Initialized
INFO - 2025-04-10 00:09:40 --> Final output sent to browser
DEBUG - 2025-04-10 00:09:40 --> Total execution time: 0.0103
INFO - 2025-04-10 00:10:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:10:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:10:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:10:17 --> Model Class Initialized
INFO - 2025-04-10 00:10:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:10:17 --> Total execution time: 0.0105
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:10:57 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
ERROR - 2025-04-10 00:10:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:10:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:10:57 --> Final output sent to browser
DEBUG - 2025-04-10 00:10:57 --> Total execution time: 0.1370
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:10:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:10:57 --> Model Class Initialized
INFO - 2025-04-10 00:10:57 --> Final output sent to browser
DEBUG - 2025-04-10 00:10:57 --> Total execution time: 0.0096
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:11:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
ERROR - 2025-04-10 00:11:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:11:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:11:30 --> Final output sent to browser
DEBUG - 2025-04-10 00:11:30 --> Total execution time: 0.0910
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:11:30 --> Model Class Initialized
INFO - 2025-04-10 00:11:30 --> Final output sent to browser
DEBUG - 2025-04-10 00:11:30 --> Total execution time: 0.0106
INFO - 2025-04-10 00:11:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:11:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:11:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:11:37 --> Model Class Initialized
INFO - 2025-04-10 00:11:37 --> Final output sent to browser
DEBUG - 2025-04-10 00:11:37 --> Total execution time: 0.0077
INFO - 2025-04-10 00:11:59 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:11:59 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:11:59 --> Model Class Initialized
DEBUG - 2025-04-10 00:11:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:11:59 --> Model Class Initialized
INFO - 2025-04-10 00:11:59 --> Final output sent to browser
DEBUG - 2025-04-10 00:11:59 --> Total execution time: 0.0126
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:12:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
ERROR - 2025-04-10 00:12:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:12:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:12:33 --> Final output sent to browser
DEBUG - 2025-04-10 00:12:33 --> Total execution time: 0.1690
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:12:33 --> Model Class Initialized
INFO - 2025-04-10 00:12:33 --> Final output sent to browser
DEBUG - 2025-04-10 00:12:33 --> Total execution time: 0.0100
INFO - 2025-04-10 00:12:39 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:12:39 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:12:39 --> Model Class Initialized
DEBUG - 2025-04-10 00:12:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:12:39 --> Model Class Initialized
INFO - 2025-04-10 00:12:39 --> Final output sent to browser
DEBUG - 2025-04-10 00:12:39 --> Total execution time: 0.0053
INFO - 2025-04-10 00:16:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:16:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:16:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:16:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:16:17 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:16:17 --> Model Class Initialized
ERROR - 2025-04-10 00:16:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:16:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:16:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:16:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:16:17 --> Total execution time: 0.1154
INFO - 2025-04-10 00:16:18 --> Model Class Initialized
DEBUG - 2025-04-10 00:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:16:18 --> Model Class Initialized
DEBUG - 2025-04-10 00:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:16:18 --> Model Class Initialized
DEBUG - 2025-04-10 00:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:16:18 --> Model Class Initialized
INFO - 2025-04-10 00:16:18 --> Final output sent to browser
DEBUG - 2025-04-10 00:16:18 --> Total execution time: 0.0088
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:17:05 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
ERROR - 2025-04-10 00:17:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:17:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:17:05 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:05 --> Total execution time: 0.1166
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:05 --> Model Class Initialized
INFO - 2025-04-10 00:17:05 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:05 --> Total execution time: 0.0092
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
INFO - 2025-04-10 00:17:11 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:11 --> Total execution time: 0.0283
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:11 --> Model Class Initialized
INFO - 2025-04-10 00:17:11 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:11 --> Total execution time: 0.0170
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:17:17 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
ERROR - 2025-04-10 00:17:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:17:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:17:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:17 --> Total execution time: 0.0936
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:17 --> Model Class Initialized
INFO - 2025-04-10 00:17:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:17 --> Total execution time: 0.0149
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
INFO - 2025-04-10 00:17:55 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:55 --> Total execution time: 0.0166
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:17:55 --> Model Class Initialized
INFO - 2025-04-10 00:17:55 --> Final output sent to browser
DEBUG - 2025-04-10 00:17:55 --> Total execution time: 0.0086
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
INFO - 2025-04-10 00:18:01 --> Final output sent to browser
DEBUG - 2025-04-10 00:18:01 --> Total execution time: 0.0172
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:18:01 --> Model Class Initialized
INFO - 2025-04-10 00:18:01 --> Final output sent to browser
DEBUG - 2025-04-10 00:18:01 --> Total execution time: 0.0070
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
INFO - 2025-04-10 00:18:04 --> Final output sent to browser
DEBUG - 2025-04-10 00:18:04 --> Total execution time: 0.0146
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:18:04 --> Model Class Initialized
INFO - 2025-04-10 00:18:04 --> Final output sent to browser
DEBUG - 2025-04-10 00:18:04 --> Total execution time: 0.0098
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
INFO - 2025-04-10 00:18:06 --> Final output sent to browser
DEBUG - 2025-04-10 00:18:06 --> Total execution time: 0.0124
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
DEBUG - 2025-04-10 00:18:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:18:06 --> Model Class Initialized
INFO - 2025-04-10 00:18:06 --> Final output sent to browser
DEBUG - 2025-04-10 00:18:06 --> Total execution time: 0.0071
INFO - 2025-04-10 00:21:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:21:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:21:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:21:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:21:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:21:20 --> Model Class Initialized
ERROR - 2025-04-10 00:21:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:21:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:21:20 --> Final output sent to browser
DEBUG - 2025-04-10 00:21:20 --> Total execution time: 0.1548
INFO - 2025-04-10 00:21:21 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:21:21 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:21:21 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:21:21 --> Model Class Initialized
INFO - 2025-04-10 00:21:21 --> Final output sent to browser
DEBUG - 2025-04-10 00:21:21 --> Total execution time: 0.0116
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
INFO - 2025-04-10 00:21:40 --> Final output sent to browser
DEBUG - 2025-04-10 00:21:40 --> Total execution time: 0.0101
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
DEBUG - 2025-04-10 00:21:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:21:40 --> Model Class Initialized
INFO - 2025-04-10 00:21:40 --> Final output sent to browser
DEBUG - 2025-04-10 00:21:40 --> Total execution time: 0.0113
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:24:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
ERROR - 2025-04-10 00:24:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:24:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:24:20 --> Final output sent to browser
DEBUG - 2025-04-10 00:24:20 --> Total execution time: 0.1399
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:24:20 --> Model Class Initialized
INFO - 2025-04-10 00:24:20 --> Final output sent to browser
DEBUG - 2025-04-10 00:24:20 --> Total execution time: 0.0123
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:24:25 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
ERROR - 2025-04-10 00:24:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:24:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:24:25 --> Final output sent to browser
DEBUG - 2025-04-10 00:24:25 --> Total execution time: 0.1384
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:24:25 --> Model Class Initialized
INFO - 2025-04-10 00:24:25 --> Final output sent to browser
DEBUG - 2025-04-10 00:24:25 --> Total execution time: 0.0118
INFO - 2025-04-10 00:24:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:24:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:24:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:24:56 --> Model Class Initialized
INFO - 2025-04-10 00:24:56 --> Final output sent to browser
DEBUG - 2025-04-10 00:24:56 --> Total execution time: 0.0090
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:25:13 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
ERROR - 2025-04-10 00:25:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:25:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:25:13 --> Final output sent to browser
DEBUG - 2025-04-10 00:25:13 --> Total execution time: 0.1694
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:25:13 --> Model Class Initialized
INFO - 2025-04-10 00:25:13 --> Final output sent to browser
DEBUG - 2025-04-10 00:25:13 --> Total execution time: 0.0067
INFO - 2025-04-10 00:25:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:25:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:25:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:25:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:25:17 --> Model Class Initialized
INFO - 2025-04-10 00:25:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:25:17 --> Total execution time: 0.0053
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:26:38 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
ERROR - 2025-04-10 00:26:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:26:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:26:38 --> Final output sent to browser
DEBUG - 2025-04-10 00:26:38 --> Total execution time: 0.1142
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:26:38 --> Model Class Initialized
INFO - 2025-04-10 00:26:38 --> Final output sent to browser
DEBUG - 2025-04-10 00:26:38 --> Total execution time: 0.0111
INFO - 2025-04-10 00:26:43 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:26:43 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:26:43 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:26:43 --> Model Class Initialized
INFO - 2025-04-10 00:26:43 --> Final output sent to browser
DEBUG - 2025-04-10 00:26:43 --> Total execution time: 0.0117
INFO - 2025-04-10 00:26:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:26:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:26:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:26:55 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:26:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:26:55 --> Model Class Initialized
ERROR - 2025-04-10 00:26:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:26:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:26:55 --> Final output sent to browser
DEBUG - 2025-04-10 00:26:55 --> Total execution time: 0.1922
INFO - 2025-04-10 00:26:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:26:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:26:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:26:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:26:56 --> Model Class Initialized
INFO - 2025-04-10 00:26:56 --> Final output sent to browser
DEBUG - 2025-04-10 00:26:56 --> Total execution time: 0.0070
INFO - 2025-04-10 00:27:02 --> Model Class Initialized
DEBUG - 2025-04-10 00:27:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:27:02 --> Model Class Initialized
DEBUG - 2025-04-10 00:27:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:27:02 --> Model Class Initialized
DEBUG - 2025-04-10 00:27:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:27:02 --> Model Class Initialized
INFO - 2025-04-10 00:27:02 --> Final output sent to browser
DEBUG - 2025-04-10 00:27:02 --> Total execution time: 0.0068
INFO - 2025-04-10 00:27:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:27:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:27:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:27:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:27:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:27:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:27:15 --> Model Class Initialized
INFO - 2025-04-10 00:27:15 --> Final output sent to browser
DEBUG - 2025-04-10 00:27:15 --> Total execution time: 0.0068
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:29:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
ERROR - 2025-04-10 00:29:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:29:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:29:23 --> Final output sent to browser
DEBUG - 2025-04-10 00:29:23 --> Total execution time: 0.1109
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:29:23 --> Model Class Initialized
INFO - 2025-04-10 00:29:23 --> Final output sent to browser
DEBUG - 2025-04-10 00:29:23 --> Total execution time: 0.0116
INFO - 2025-04-10 00:29:28 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:29:28 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:29:28 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:29:28 --> Model Class Initialized
INFO - 2025-04-10 00:29:28 --> Final output sent to browser
DEBUG - 2025-04-10 00:29:28 --> Total execution time: 0.0124
INFO - 2025-04-10 00:29:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:29:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:29:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:29:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:29:57 --> Model Class Initialized
INFO - 2025-04-10 00:29:57 --> Final output sent to browser
DEBUG - 2025-04-10 00:29:57 --> Total execution time: 0.0125
INFO - 2025-04-10 00:31:36 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:31:36 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:31:36 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:31:36 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:31:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:31:36 --> Model Class Initialized
ERROR - 2025-04-10 00:31:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:31:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:31:36 --> Final output sent to browser
DEBUG - 2025-04-10 00:31:36 --> Total execution time: 0.1605
INFO - 2025-04-10 00:31:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:31:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:31:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:31:37 --> Model Class Initialized
INFO - 2025-04-10 00:31:37 --> Final output sent to browser
DEBUG - 2025-04-10 00:31:37 --> Total execution time: 0.0207
INFO - 2025-04-10 00:31:44 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:31:44 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:31:44 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:31:44 --> Model Class Initialized
INFO - 2025-04-10 00:31:44 --> Final output sent to browser
DEBUG - 2025-04-10 00:31:44 --> Total execution time: 0.0119
INFO - 2025-04-10 00:31:50 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:31:50 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:31:50 --> Model Class Initialized
DEBUG - 2025-04-10 00:31:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:31:50 --> Model Class Initialized
INFO - 2025-04-10 00:31:50 --> Final output sent to browser
DEBUG - 2025-04-10 00:31:50 --> Total execution time: 0.0078
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:46:17 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
ERROR - 2025-04-10 00:46:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:46:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:46:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:46:17 --> Total execution time: 0.0906
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:46:17 --> Model Class Initialized
INFO - 2025-04-10 00:46:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:46:17 --> Total execution time: 0.0067
INFO - 2025-04-10 00:46:22 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:46:22 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:46:22 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:46:22 --> Model Class Initialized
INFO - 2025-04-10 00:46:22 --> Final output sent to browser
DEBUG - 2025-04-10 00:46:22 --> Total execution time: 0.0043
INFO - 2025-04-10 00:46:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:46:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:46:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:46:56 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:46:56 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:46:56 --> Model Class Initialized
ERROR - 2025-04-10 00:46:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:46:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:46:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:46:56 --> Final output sent to browser
DEBUG - 2025-04-10 00:46:56 --> Total execution time: 0.1432
INFO - 2025-04-10 00:46:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:46:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:46:57 --> Model Class Initialized
DEBUG - 2025-04-10 00:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:46:57 --> Model Class Initialized
INFO - 2025-04-10 00:46:57 --> Final output sent to browser
DEBUG - 2025-04-10 00:46:57 --> Total execution time: 0.0185
INFO - 2025-04-10 00:47:02 --> Model Class Initialized
DEBUG - 2025-04-10 00:47:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:47:02 --> Model Class Initialized
DEBUG - 2025-04-10 00:47:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:47:02 --> Model Class Initialized
DEBUG - 2025-04-10 00:47:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:47:02 --> Model Class Initialized
INFO - 2025-04-10 00:47:02 --> Final output sent to browser
DEBUG - 2025-04-10 00:47:02 --> Total execution time: 0.0063
INFO - 2025-04-10 00:48:32 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:32 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:32 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:32 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:48:32 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:48:32 --> Model Class Initialized
ERROR - 2025-04-10 00:48:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:48:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:48:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:48:32 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:32 --> Total execution time: 0.1582
INFO - 2025-04-10 00:48:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:33 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:33 --> Model Class Initialized
INFO - 2025-04-10 00:48:33 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:33 --> Total execution time: 0.0130
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
INFO - 2025-04-10 00:48:37 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:37 --> Total execution time: 0.0122
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:37 --> Model Class Initialized
INFO - 2025-04-10 00:48:37 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:37 --> Total execution time: 0.0103
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
INFO - 2025-04-10 00:48:47 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:47 --> Total execution time: 0.0104
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:47 --> Model Class Initialized
INFO - 2025-04-10 00:48:47 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:47 --> Total execution time: 0.0149
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
INFO - 2025-04-10 00:48:53 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:53 --> Total execution time: 0.0158
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
DEBUG - 2025-04-10 00:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:48:53 --> Model Class Initialized
INFO - 2025-04-10 00:48:53 --> Final output sent to browser
DEBUG - 2025-04-10 00:48:53 --> Total execution time: 0.0063
INFO - 2025-04-10 00:50:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:50:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:50:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:50:04 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:50:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:50:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:50:04 --> Model Class Initialized
ERROR - 2025-04-10 00:50:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:50:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:50:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:50:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:50:05 --> Final output sent to browser
DEBUG - 2025-04-10 00:50:05 --> Total execution time: 0.1191
INFO - 2025-04-10 00:50:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:50:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:50:05 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:50:05 --> Model Class Initialized
INFO - 2025-04-10 00:50:05 --> Final output sent to browser
DEBUG - 2025-04-10 00:50:05 --> Total execution time: 0.0109
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:50:19 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
ERROR - 2025-04-10 00:50:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:50:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:50:19 --> Final output sent to browser
DEBUG - 2025-04-10 00:50:19 --> Total execution time: 0.0955
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
DEBUG - 2025-04-10 00:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:50:19 --> Model Class Initialized
INFO - 2025-04-10 00:50:19 --> Final output sent to browser
DEBUG - 2025-04-10 00:50:19 --> Total execution time: 0.0145
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:53:27 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
ERROR - 2025-04-10 00:53:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:53:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:53:27 --> Final output sent to browser
DEBUG - 2025-04-10 00:53:27 --> Total execution time: 0.2761
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
DEBUG - 2025-04-10 00:53:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:53:27 --> Model Class Initialized
INFO - 2025-04-10 00:53:27 --> Final output sent to browser
DEBUG - 2025-04-10 00:53:27 --> Total execution time: 0.0106
INFO - 2025-04-10 00:54:44 --> Model Class Initialized
DEBUG - 2025-04-10 00:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:54:44 --> Model Class Initialized
DEBUG - 2025-04-10 00:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:54:44 --> Model Class Initialized
DEBUG - 2025-04-10 00:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:54:44 --> Model Class Initialized
DEBUG - 2025-04-10 00:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:54:44 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:54:44 --> Model Class Initialized
ERROR - 2025-04-10 00:54:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:54:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:54:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:54:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:54:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:54:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:54:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:54:45 --> Final output sent to browser
DEBUG - 2025-04-10 00:54:45 --> Total execution time: 0.1496
INFO - 2025-04-10 00:55:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:55:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:55:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:55:15 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:55:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:55:15 --> Model Class Initialized
ERROR - 2025-04-10 00:55:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:55:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:55:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:55:15 --> Final output sent to browser
DEBUG - 2025-04-10 00:55:15 --> Total execution time: 0.1416
INFO - 2025-04-10 00:55:16 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:55:16 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:55:16 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:55:16 --> Model Class Initialized
INFO - 2025-04-10 00:55:16 --> Final output sent to browser
DEBUG - 2025-04-10 00:55:16 --> Total execution time: 0.0143
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:55:45 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
ERROR - 2025-04-10 00:55:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:55:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:55:45 --> Final output sent to browser
DEBUG - 2025-04-10 00:55:45 --> Total execution time: 0.0951
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:55:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:55:45 --> Model Class Initialized
INFO - 2025-04-10 00:55:45 --> Final output sent to browser
DEBUG - 2025-04-10 00:55:45 --> Total execution time: 0.0095
INFO - 2025-04-10 00:57:50 --> Model Class Initialized
DEBUG - 2025-04-10 00:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:57:50 --> Model Class Initialized
DEBUG - 2025-04-10 00:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:57:50 --> Model Class Initialized
DEBUG - 2025-04-10 00:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:57:50 --> Model Class Initialized
DEBUG - 2025-04-10 00:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:57:50 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:57:50 --> Model Class Initialized
ERROR - 2025-04-10 00:57:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:57:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:57:51 --> Final output sent to browser
DEBUG - 2025-04-10 00:57:51 --> Total execution time: 0.5955
INFO - 2025-04-10 00:57:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:57:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:57:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:57:51 --> Model Class Initialized
INFO - 2025-04-10 00:57:51 --> Final output sent to browser
DEBUG - 2025-04-10 00:57:51 --> Total execution time: 0.0104
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:58:35 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
ERROR - 2025-04-10 00:58:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:58:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:58:35 --> Final output sent to browser
DEBUG - 2025-04-10 00:58:35 --> Total execution time: 0.1007
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:58:35 --> Model Class Initialized
INFO - 2025-04-10 00:58:35 --> Final output sent to browser
DEBUG - 2025-04-10 00:58:35 --> Total execution time: 0.0100
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
INFO - 2025-04-10 00:58:45 --> Final output sent to browser
DEBUG - 2025-04-10 00:58:45 --> Total execution time: 0.0138
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:58:45 --> Model Class Initialized
INFO - 2025-04-10 00:58:45 --> Final output sent to browser
DEBUG - 2025-04-10 00:58:45 --> Total execution time: 0.0085
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
INFO - 2025-04-10 00:58:51 --> Final output sent to browser
DEBUG - 2025-04-10 00:58:51 --> Total execution time: 0.0130
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
DEBUG - 2025-04-10 00:58:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:58:51 --> Model Class Initialized
INFO - 2025-04-10 00:58:51 --> Final output sent to browser
DEBUG - 2025-04-10 00:58:51 --> Total execution time: 0.0107
INFO - 2025-04-10 00:59:16 --> Model Class Initialized
DEBUG - 2025-04-10 00:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:59:16 --> Model Class Initialized
DEBUG - 2025-04-10 00:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:59:16 --> Model Class Initialized
DEBUG - 2025-04-10 00:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:59:16 --> Model Class Initialized
DEBUG - 2025-04-10 00:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 00:59:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 00:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 00:59:16 --> Model Class Initialized
ERROR - 2025-04-10 00:59:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 00:59:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 00:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 00:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 00:59:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:59:17 --> Total execution time: 0.1471
INFO - 2025-04-10 00:59:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 00:59:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 00:59:17 --> Model Class Initialized
DEBUG - 2025-04-10 00:59:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 00:59:17 --> Model Class Initialized
INFO - 2025-04-10 00:59:17 --> Final output sent to browser
DEBUG - 2025-04-10 00:59:17 --> Total execution time: 0.0114
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:01:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
ERROR - 2025-04-10 01:01:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:01:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:01:23 --> Final output sent to browser
DEBUG - 2025-04-10 01:01:23 --> Total execution time: 0.1200
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:01:23 --> Model Class Initialized
INFO - 2025-04-10 01:01:23 --> Final output sent to browser
DEBUG - 2025-04-10 01:01:23 --> Total execution time: 0.0162
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
INFO - 2025-04-10 01:01:33 --> Final output sent to browser
DEBUG - 2025-04-10 01:01:33 --> Total execution time: 0.0053
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:01:33 --> Model Class Initialized
INFO - 2025-04-10 01:01:33 --> Final output sent to browser
DEBUG - 2025-04-10 01:01:33 --> Total execution time: 0.0072
INFO - 2025-04-10 01:01:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:01:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:01:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:01:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:01:38 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:01:38 --> Model Class Initialized
ERROR - 2025-04-10 01:01:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:01:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:01:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:01:38 --> Final output sent to browser
DEBUG - 2025-04-10 01:01:38 --> Total execution time: 0.1323
INFO - 2025-04-10 01:01:39 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:01:39 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:01:39 --> Model Class Initialized
DEBUG - 2025-04-10 01:01:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:01:39 --> Model Class Initialized
INFO - 2025-04-10 01:01:39 --> Final output sent to browser
DEBUG - 2025-04-10 01:01:39 --> Total execution time: 0.0088
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:02:02 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
ERROR - 2025-04-10 01:02:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:02:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:02:02 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:02 --> Total execution time: 0.1016
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:02 --> Model Class Initialized
INFO - 2025-04-10 01:02:02 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:02 --> Total execution time: 0.0104
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:02:09 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
ERROR - 2025-04-10 01:02:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:02:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:02:09 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:09 --> Total execution time: 0.1558
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:09 --> Model Class Initialized
INFO - 2025-04-10 01:02:09 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:09 --> Total execution time: 0.0084
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:02:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
ERROR - 2025-04-10 01:02:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:02:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:02:16 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:16 --> Total execution time: 0.1334
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:16 --> Model Class Initialized
INFO - 2025-04-10 01:02:16 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:16 --> Total execution time: 0.0089
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
INFO - 2025-04-10 01:02:25 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:25 --> Total execution time: 0.0102
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:25 --> Model Class Initialized
INFO - 2025-04-10 01:02:25 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:25 --> Total execution time: 0.0116
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
INFO - 2025-04-10 01:02:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:30 --> Total execution time: 0.0147
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:30 --> Model Class Initialized
INFO - 2025-04-10 01:02:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:30 --> Total execution time: 0.0106
INFO - 2025-04-10 01:02:34 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:34 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:34 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:34 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:02:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:02:34 --> Model Class Initialized
ERROR - 2025-04-10 01:02:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:02:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:02:34 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:34 --> Total execution time: 0.1484
INFO - 2025-04-10 01:02:35 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:35 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:35 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:35 --> Model Class Initialized
INFO - 2025-04-10 01:02:35 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:35 --> Total execution time: 0.0125
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:02:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
ERROR - 2025-04-10 01:02:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:02:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:02:42 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:42 --> Total execution time: 0.1286
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
DEBUG - 2025-04-10 01:02:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:02:42 --> Model Class Initialized
INFO - 2025-04-10 01:02:42 --> Final output sent to browser
DEBUG - 2025-04-10 01:02:42 --> Total execution time: 0.0132
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:03:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
ERROR - 2025-04-10 01:03:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:03:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:03:16 --> Final output sent to browser
DEBUG - 2025-04-10 01:03:16 --> Total execution time: 0.1432
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
DEBUG - 2025-04-10 01:03:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:03:16 --> Model Class Initialized
INFO - 2025-04-10 01:03:16 --> Final output sent to browser
DEBUG - 2025-04-10 01:03:16 --> Total execution time: 0.0111
INFO - 2025-04-10 01:05:00 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:05:00 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:05:00 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:05:00 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:05:00 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:05:00 --> Model Class Initialized
ERROR - 2025-04-10 01:05:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:05:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:05:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:05:00 --> Final output sent to browser
DEBUG - 2025-04-10 01:05:00 --> Total execution time: 0.1188
INFO - 2025-04-10 01:05:01 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:05:01 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:05:01 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:05:01 --> Model Class Initialized
INFO - 2025-04-10 01:05:01 --> Final output sent to browser
DEBUG - 2025-04-10 01:05:01 --> Total execution time: 0.0098
INFO - 2025-04-10 01:05:22 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:05:22 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:05:22 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:05:22 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:05:22 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:05:22 --> Model Class Initialized
ERROR - 2025-04-10 01:05:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:05:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:05:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:05:22 --> Final output sent to browser
DEBUG - 2025-04-10 01:05:22 --> Total execution time: 0.0936
INFO - 2025-04-10 01:05:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:05:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:05:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:05:23 --> Model Class Initialized
INFO - 2025-04-10 01:05:23 --> Final output sent to browser
DEBUG - 2025-04-10 01:05:23 --> Total execution time: 0.0096
INFO - 2025-04-10 01:07:01 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:07:01 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:07:01 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:07:01 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:07:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:07:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:07:01 --> Model Class Initialized
ERROR - 2025-04-10 01:07:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:07:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:07:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:07:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:07:02 --> Final output sent to browser
DEBUG - 2025-04-10 01:07:02 --> Total execution time: 0.1315
INFO - 2025-04-10 01:07:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:07:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:07:02 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:07:02 --> Model Class Initialized
INFO - 2025-04-10 01:07:02 --> Final output sent to browser
DEBUG - 2025-04-10 01:07:02 --> Total execution time: 0.0066
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:07:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
ERROR - 2025-04-10 01:07:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:07:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:07:48 --> Final output sent to browser
DEBUG - 2025-04-10 01:07:48 --> Total execution time: 0.1380
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:07:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:07:48 --> Model Class Initialized
INFO - 2025-04-10 01:07:48 --> Final output sent to browser
DEBUG - 2025-04-10 01:07:48 --> Total execution time: 0.0107
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:10:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
ERROR - 2025-04-10 01:10:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:10:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:10:33 --> Final output sent to browser
DEBUG - 2025-04-10 01:10:33 --> Total execution time: 0.1036
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:10:33 --> Model Class Initialized
INFO - 2025-04-10 01:10:33 --> Final output sent to browser
DEBUG - 2025-04-10 01:10:33 --> Total execution time: 0.0067
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:10:45 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
ERROR - 2025-04-10 01:10:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:10:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:10:45 --> Final output sent to browser
DEBUG - 2025-04-10 01:10:45 --> Total execution time: 0.1448
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:10:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:10:45 --> Model Class Initialized
INFO - 2025-04-10 01:10:45 --> Final output sent to browser
DEBUG - 2025-04-10 01:10:45 --> Total execution time: 0.0081
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
INFO - 2025-04-10 01:11:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:30 --> Total execution time: 0.0171
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
INFO - 2025-04-10 01:11:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:30 --> Total execution time: 0.0133
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:30 --> Model Class Initialized
INFO - 2025-04-10 01:11:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:30 --> Total execution time: 0.0144
INFO - 2025-04-10 01:11:31 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:31 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:31 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:31 --> Model Class Initialized
INFO - 2025-04-10 01:11:31 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:31 --> Total execution time: 0.0069
INFO - 2025-04-10 01:11:32 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:32 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:32 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:32 --> Model Class Initialized
INFO - 2025-04-10 01:11:32 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:32 --> Total execution time: 0.0127
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
INFO - 2025-04-10 01:11:33 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:33 --> Total execution time: 0.0126
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:33 --> Model Class Initialized
INFO - 2025-04-10 01:11:33 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:33 --> Total execution time: 0.0100
INFO - 2025-04-10 01:11:36 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:36 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:36 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:36 --> Model Class Initialized
INFO - 2025-04-10 01:11:36 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:36 --> Total execution time: 0.0124
INFO - 2025-04-10 01:11:37 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:37 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:37 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:37 --> Model Class Initialized
INFO - 2025-04-10 01:11:37 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:37 --> Total execution time: 0.0116
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
INFO - 2025-04-10 01:11:38 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:38 --> Total execution time: 0.0076
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:38 --> Model Class Initialized
INFO - 2025-04-10 01:11:38 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:38 --> Total execution time: 0.0145
INFO - 2025-04-10 01:11:43 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:43 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:43 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:43 --> Model Class Initialized
INFO - 2025-04-10 01:11:43 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:43 --> Total execution time: 0.0086
INFO - 2025-04-10 01:11:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:44 --> Model Class Initialized
INFO - 2025-04-10 01:11:44 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:44 --> Total execution time: 0.0084
INFO - 2025-04-10 01:11:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:45 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:45 --> Model Class Initialized
INFO - 2025-04-10 01:11:45 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:45 --> Total execution time: 0.0084
INFO - 2025-04-10 01:11:46 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:11:46 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:11:46 --> Model Class Initialized
DEBUG - 2025-04-10 01:11:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:11:46 --> Model Class Initialized
INFO - 2025-04-10 01:11:46 --> Final output sent to browser
DEBUG - 2025-04-10 01:11:46 --> Total execution time: 0.0149
INFO - 2025-04-10 01:13:29 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:13:29 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:13:29 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:13:29 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:13:29 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:13:29 --> Model Class Initialized
ERROR - 2025-04-10 01:13:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:13:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:13:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:13:30 --> Total execution time: 0.1444
INFO - 2025-04-10 01:13:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:13:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:13:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:13:30 --> Model Class Initialized
INFO - 2025-04-10 01:13:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:13:30 --> Total execution time: 0.0388
INFO - 2025-04-10 01:13:36 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:13:36 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:13:36 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:13:36 --> Model Class Initialized
ERROR - 2025-04-10 01:13:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-10 01:13:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-10 01:13:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-10 01:13:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:13:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:13:36 --> Model Class Initialized
ERROR - 2025-04-10 01:13:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:13:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-10 01:13:36 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:13:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:13:36 --> Final output sent to browser
DEBUG - 2025-04-10 01:13:36 --> Total execution time: 0.2023
INFO - 2025-04-10 01:13:46 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:13:46 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:13:46 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:13:46 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:13:46 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:13:46 --> Model Class Initialized
ERROR - 2025-04-10 01:13:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:13:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:13:46 --> Final output sent to browser
DEBUG - 2025-04-10 01:13:46 --> Total execution time: 0.1623
INFO - 2025-04-10 01:13:47 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:13:47 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:13:47 --> Model Class Initialized
DEBUG - 2025-04-10 01:13:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:13:47 --> Model Class Initialized
INFO - 2025-04-10 01:13:47 --> Final output sent to browser
DEBUG - 2025-04-10 01:13:47 --> Total execution time: 0.0484
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:19:27 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
ERROR - 2025-04-10 01:19:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:19:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:19:27 --> Final output sent to browser
DEBUG - 2025-04-10 01:19:27 --> Total execution time: 0.1362
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:19:27 --> Model Class Initialized
INFO - 2025-04-10 01:19:27 --> Final output sent to browser
DEBUG - 2025-04-10 01:19:27 --> Total execution time: 0.0598
INFO - 2025-04-10 01:19:34 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:19:34 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:19:34 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:19:34 --> Model Class Initialized
INFO - 2025-04-10 01:19:34 --> Final output sent to browser
DEBUG - 2025-04-10 01:19:34 --> Total execution time: 0.2915
INFO - 2025-04-10 01:19:55 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:19:55 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:19:55 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:19:55 --> Model Class Initialized
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:19:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:19:55 --> Model Class Initialized
ERROR - 2025-04-10 01:19:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:19:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:19:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:19:55 --> Final output sent to browser
DEBUG - 2025-04-10 01:19:55 --> Total execution time: 0.1826
INFO - 2025-04-10 01:23:14 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:23:14 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:23:14 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:23:14 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:23:14 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:23:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:23:14 --> Model Class Initialized
ERROR - 2025-04-10 01:23:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:23:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:23:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:23:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:23:15 --> Final output sent to browser
DEBUG - 2025-04-10 01:23:15 --> Total execution time: 0.5494
INFO - 2025-04-10 01:23:15 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:23:15 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:23:15 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:23:15 --> Model Class Initialized
INFO - 2025-04-10 01:23:15 --> Final output sent to browser
DEBUG - 2025-04-10 01:23:15 --> Total execution time: 0.0426
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:23:28 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
ERROR - 2025-04-10 01:23:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:23:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:23:28 --> Final output sent to browser
DEBUG - 2025-04-10 01:23:28 --> Total execution time: 0.2558
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
DEBUG - 2025-04-10 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:23:28 --> Model Class Initialized
INFO - 2025-04-10 01:23:28 --> Final output sent to browser
DEBUG - 2025-04-10 01:23:28 --> Total execution time: 0.0514
INFO - 2025-04-10 01:27:12 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:27:12 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:27:12 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:27:12 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:27:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:27:12 --> Model Class Initialized
ERROR - 2025-04-10 01:27:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:27:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:27:12 --> Final output sent to browser
DEBUG - 2025-04-10 01:27:12 --> Total execution time: 0.1649
INFO - 2025-04-10 01:27:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:27:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:27:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:27:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:27:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:27:20 --> Model Class Initialized
ERROR - 2025-04-10 01:27:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:27:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:27:20 --> Final output sent to browser
DEBUG - 2025-04-10 01:27:20 --> Total execution time: 0.1368
INFO - 2025-04-10 01:28:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:28:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:28:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:28:23 --> Model Class Initialized
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:28:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:28:23 --> Model Class Initialized
ERROR - 2025-04-10 01:28:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:28:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:28:23 --> Final output sent to browser
DEBUG - 2025-04-10 01:28:23 --> Total execution time: 0.1423
INFO - 2025-04-10 01:30:11 --> Model Class Initialized
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:30:11 --> Model Class Initialized
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:30:11 --> Model Class Initialized
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:30:11 --> Model Class Initialized
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:30:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:30:11 --> Model Class Initialized
ERROR - 2025-04-10 01:30:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:30:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:30:11 --> Final output sent to browser
DEBUG - 2025-04-10 01:30:11 --> Total execution time: 0.1261
INFO - 2025-04-10 01:42:17 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:42:17 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:42:17 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:42:17 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:42:17 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:42:17 --> Model Class Initialized
ERROR - 2025-04-10 01:42:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:42:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:42:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:42:17 --> Final output sent to browser
DEBUG - 2025-04-10 01:42:17 --> Total execution time: 0.1776
INFO - 2025-04-10 01:42:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:42:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:42:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:42:20 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:42:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:42:20 --> Model Class Initialized
ERROR - 2025-04-10 01:42:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:42:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:42:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:42:20 --> Final output sent to browser
DEBUG - 2025-04-10 01:42:20 --> Total execution time: 0.1614
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:42:50 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
ERROR - 2025-04-10 01:42:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:42:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:42:50 --> Final output sent to browser
DEBUG - 2025-04-10 01:42:50 --> Total execution time: 0.1366
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:42:50 --> Model Class Initialized
INFO - 2025-04-10 01:42:50 --> Final output sent to browser
DEBUG - 2025-04-10 01:42:50 --> Total execution time: 0.0108
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
INFO - 2025-04-10 01:42:58 --> Final output sent to browser
DEBUG - 2025-04-10 01:42:58 --> Total execution time: 0.0162
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
DEBUG - 2025-04-10 01:42:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:42:58 --> Model Class Initialized
INFO - 2025-04-10 01:42:58 --> Final output sent to browser
DEBUG - 2025-04-10 01:42:58 --> Total execution time: 0.0117
INFO - 2025-04-10 01:50:53 --> Model Class Initialized
DEBUG - 2025-04-10 01:50:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:50:53 --> Model Class Initialized
DEBUG - 2025-04-10 01:50:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:50:53 --> Model Class Initialized
DEBUG - 2025-04-10 01:50:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:50:53 --> Model Class Initialized
DEBUG - 2025-04-10 01:50:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:50:53 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:50:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:50:53 --> Model Class Initialized
ERROR - 2025-04-10 01:50:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:50:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:50:54 --> Final output sent to browser
DEBUG - 2025-04-10 01:50:54 --> Total execution time: 0.3480
INFO - 2025-04-10 01:50:54 --> Model Class Initialized
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:50:54 --> Model Class Initialized
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:50:54 --> Model Class Initialized
DEBUG - 2025-04-10 01:50:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:50:54 --> Model Class Initialized
INFO - 2025-04-10 01:50:54 --> Final output sent to browser
DEBUG - 2025-04-10 01:50:54 --> Total execution time: 0.0065
INFO - 2025-04-10 01:51:03 --> Model Class Initialized
DEBUG - 2025-04-10 01:51:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:51:03 --> Model Class Initialized
DEBUG - 2025-04-10 01:51:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:51:03 --> Model Class Initialized
DEBUG - 2025-04-10 01:51:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:51:03 --> Model Class Initialized
INFO - 2025-04-10 01:51:08 --> Final output sent to browser
DEBUG - 2025-04-10 01:51:08 --> Total execution time: 5.2535
INFO - 2025-04-10 01:51:08 --> Model Class Initialized
DEBUG - 2025-04-10 01:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:51:08 --> Model Class Initialized
DEBUG - 2025-04-10 01:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:51:08 --> Model Class Initialized
DEBUG - 2025-04-10 01:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:51:08 --> Model Class Initialized
INFO - 2025-04-10 01:51:08 --> Final output sent to browser
DEBUG - 2025-04-10 01:51:08 --> Total execution time: 0.0158
INFO - 2025-04-10 01:53:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:53:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:53:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:53:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:53:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:53:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:53:44 --> Model Class Initialized
INFO - 2025-04-10 01:53:47 --> Final output sent to browser
DEBUG - 2025-04-10 01:53:47 --> Total execution time: 3.0169
INFO - 2025-04-10 01:53:47 --> Model Class Initialized
DEBUG - 2025-04-10 01:53:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:53:47 --> Model Class Initialized
DEBUG - 2025-04-10 01:53:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:53:47 --> Model Class Initialized
DEBUG - 2025-04-10 01:53:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:53:47 --> Model Class Initialized
INFO - 2025-04-10 01:53:47 --> Final output sent to browser
DEBUG - 2025-04-10 01:53:47 --> Total execution time: 0.0108
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:57:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
ERROR - 2025-04-10 01:57:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:57:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:57:24 --> Final output sent to browser
DEBUG - 2025-04-10 01:57:24 --> Total execution time: 0.1276
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:57:24 --> Model Class Initialized
INFO - 2025-04-10 01:57:24 --> Final output sent to browser
DEBUG - 2025-04-10 01:57:24 --> Total execution time: 0.0078
INFO - 2025-04-10 01:57:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:57:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:57:30 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:57:30 --> Model Class Initialized
INFO - 2025-04-10 01:57:30 --> Final output sent to browser
DEBUG - 2025-04-10 01:57:30 --> Total execution time: 0.0164
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:57:38 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
ERROR - 2025-04-10 01:57:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:57:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:57:38 --> Final output sent to browser
DEBUG - 2025-04-10 01:57:38 --> Total execution time: 0.1518
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:57:38 --> Model Class Initialized
INFO - 2025-04-10 01:57:38 --> Final output sent to browser
DEBUG - 2025-04-10 01:57:38 --> Total execution time: 0.0078
INFO - 2025-04-10 01:57:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:57:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:57:44 --> Model Class Initialized
DEBUG - 2025-04-10 01:57:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:57:44 --> Model Class Initialized
INFO - 2025-04-10 01:57:44 --> Final output sent to browser
DEBUG - 2025-04-10 01:57:44 --> Total execution time: 0.0057
INFO - 2025-04-10 01:58:40 --> Model Class Initialized
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:58:40 --> Model Class Initialized
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:58:40 --> Model Class Initialized
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:58:40 --> Model Class Initialized
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:58:40 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:58:40 --> Model Class Initialized
ERROR - 2025-04-10 01:58:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:58:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:58:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:58:40 --> Final output sent to browser
DEBUG - 2025-04-10 01:58:40 --> Total execution time: 0.0946
INFO - 2025-04-10 01:58:41 --> Model Class Initialized
DEBUG - 2025-04-10 01:58:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:58:41 --> Model Class Initialized
DEBUG - 2025-04-10 01:58:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:58:41 --> Model Class Initialized
DEBUG - 2025-04-10 01:58:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:58:41 --> Model Class Initialized
INFO - 2025-04-10 01:58:41 --> Final output sent to browser
DEBUG - 2025-04-10 01:58:41 --> Total execution time: 0.0094
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 01:59:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
ERROR - 2025-04-10 01:59:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 01:59:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 01:59:48 --> Final output sent to browser
DEBUG - 2025-04-10 01:59:48 --> Total execution time: 0.0941
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
DEBUG - 2025-04-10 01:59:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 01:59:48 --> Model Class Initialized
INFO - 2025-04-10 01:59:48 --> Final output sent to browser
DEBUG - 2025-04-10 01:59:48 --> Total execution time: 0.0075
INFO - 2025-04-10 02:00:16 --> Model Class Initialized
DEBUG - 2025-04-10 02:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:00:16 --> Model Class Initialized
DEBUG - 2025-04-10 02:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:00:16 --> Model Class Initialized
DEBUG - 2025-04-10 02:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:00:16 --> Model Class Initialized
INFO - 2025-04-10 02:00:21 --> Final output sent to browser
DEBUG - 2025-04-10 02:00:21 --> Total execution time: 4.9256
INFO - 2025-04-10 02:00:21 --> Model Class Initialized
DEBUG - 2025-04-10 02:00:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:00:21 --> Model Class Initialized
DEBUG - 2025-04-10 02:00:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:00:21 --> Model Class Initialized
DEBUG - 2025-04-10 02:00:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:00:21 --> Model Class Initialized
INFO - 2025-04-10 02:00:21 --> Final output sent to browser
DEBUG - 2025-04-10 02:00:21 --> Total execution time: 0.0128
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:05:02 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
ERROR - 2025-04-10 02:05:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:05:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:05:02 --> Final output sent to browser
DEBUG - 2025-04-10 02:05:02 --> Total execution time: 0.1010
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:05:02 --> Model Class Initialized
INFO - 2025-04-10 02:05:02 --> Final output sent to browser
DEBUG - 2025-04-10 02:05:02 --> Total execution time: 0.0664
INFO - 2025-04-10 02:06:53 --> Model Class Initialized
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:06:53 --> Model Class Initialized
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:06:53 --> Model Class Initialized
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:06:53 --> Model Class Initialized
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:06:53 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:06:53 --> Model Class Initialized
ERROR - 2025-04-10 02:06:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:06:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:06:53 --> Final output sent to browser
DEBUG - 2025-04-10 02:06:53 --> Total execution time: 0.1423
INFO - 2025-04-10 02:06:54 --> Model Class Initialized
DEBUG - 2025-04-10 02:06:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:06:54 --> Model Class Initialized
DEBUG - 2025-04-10 02:06:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:06:54 --> Model Class Initialized
DEBUG - 2025-04-10 02:06:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:06:54 --> Model Class Initialized
INFO - 2025-04-10 02:06:54 --> Final output sent to browser
DEBUG - 2025-04-10 02:06:54 --> Total execution time: 0.0401
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:07:09 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
ERROR - 2025-04-10 02:07:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:07:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:07:09 --> Final output sent to browser
DEBUG - 2025-04-10 02:07:09 --> Total execution time: 0.0989
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
DEBUG - 2025-04-10 02:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:07:09 --> Model Class Initialized
INFO - 2025-04-10 02:07:09 --> Final output sent to browser
DEBUG - 2025-04-10 02:07:09 --> Total execution time: 0.0563
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:11:57 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
ERROR - 2025-04-10 02:11:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:11:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:11:57 --> Final output sent to browser
DEBUG - 2025-04-10 02:11:57 --> Total execution time: 0.1560
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
DEBUG - 2025-04-10 02:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:11:57 --> Model Class Initialized
INFO - 2025-04-10 02:11:57 --> Final output sent to browser
DEBUG - 2025-04-10 02:11:57 --> Total execution time: 0.0671
INFO - 2025-04-10 02:12:01 --> Model Class Initialized
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:12:01 --> Model Class Initialized
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:12:01 --> Model Class Initialized
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:12:01 --> Model Class Initialized
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:12:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:12:01 --> Model Class Initialized
ERROR - 2025-04-10 02:12:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:12:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:12:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:12:01 --> Final output sent to browser
DEBUG - 2025-04-10 02:12:01 --> Total execution time: 0.0914
INFO - 2025-04-10 02:12:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:12:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:12:02 --> Model Class Initialized
DEBUG - 2025-04-10 02:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:12:02 --> Model Class Initialized
INFO - 2025-04-10 02:12:02 --> Final output sent to browser
DEBUG - 2025-04-10 02:12:02 --> Total execution time: 0.0462
INFO - 2025-04-10 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:16:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:16:15 --> Model Class Initialized
ERROR - 2025-04-10 02:16:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:16:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:16:16 --> Final output sent to browser
DEBUG - 2025-04-10 02:16:16 --> Total execution time: 0.4832
INFO - 2025-04-10 02:16:16 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:16:16 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:16:16 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:16:16 --> Model Class Initialized
INFO - 2025-04-10 02:16:16 --> Final output sent to browser
DEBUG - 2025-04-10 02:16:16 --> Total execution time: 0.0300
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:16:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
ERROR - 2025-04-10 02:16:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:16:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:16:24 --> Final output sent to browser
DEBUG - 2025-04-10 02:16:24 --> Total execution time: 0.1271
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
DEBUG - 2025-04-10 02:16:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:16:24 --> Model Class Initialized
INFO - 2025-04-10 02:16:24 --> Final output sent to browser
DEBUG - 2025-04-10 02:16:24 --> Total execution time: 0.0370
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:23:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
ERROR - 2025-04-10 02:23:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:23:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:23:34 --> Final output sent to browser
DEBUG - 2025-04-10 02:23:34 --> Total execution time: 0.3645
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
DEBUG - 2025-04-10 02:23:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:23:34 --> Model Class Initialized
INFO - 2025-04-10 02:23:34 --> Final output sent to browser
DEBUG - 2025-04-10 02:23:34 --> Total execution time: 0.0610
INFO - 2025-04-10 02:29:14 --> Model Class Initialized
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:29:14 --> Model Class Initialized
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:29:14 --> Model Class Initialized
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:29:14 --> Model Class Initialized
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:29:14 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:29:14 --> Model Class Initialized
ERROR - 2025-04-10 02:29:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:29:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:29:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:29:14 --> Final output sent to browser
DEBUG - 2025-04-10 02:29:14 --> Total execution time: 0.1204
INFO - 2025-04-10 02:29:15 --> Model Class Initialized
DEBUG - 2025-04-10 02:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:29:15 --> Model Class Initialized
DEBUG - 2025-04-10 02:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:29:15 --> Model Class Initialized
DEBUG - 2025-04-10 02:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:29:15 --> Model Class Initialized
INFO - 2025-04-10 02:29:15 --> Final output sent to browser
DEBUG - 2025-04-10 02:29:15 --> Total execution time: 0.0411
INFO - 2025-04-10 02:30:45 --> Model Class Initialized
DEBUG - 2025-04-10 02:30:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:30:45 --> Model Class Initialized
DEBUG - 2025-04-10 02:30:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:30:45 --> Model Class Initialized
DEBUG - 2025-04-10 02:30:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:30:45 --> Model Class Initialized
INFO - 2025-04-10 02:30:45 --> Final output sent to browser
DEBUG - 2025-04-10 02:30:45 --> Total execution time: 0.0396
INFO - 2025-04-10 02:30:46 --> Model Class Initialized
DEBUG - 2025-04-10 02:30:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:30:46 --> Model Class Initialized
DEBUG - 2025-04-10 02:30:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:30:46 --> Model Class Initialized
DEBUG - 2025-04-10 02:30:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:30:46 --> Model Class Initialized
INFO - 2025-04-10 02:30:46 --> Final output sent to browser
DEBUG - 2025-04-10 02:30:46 --> Total execution time: 0.0525
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:31:25 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
ERROR - 2025-04-10 02:31:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:31:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:31:25 --> Final output sent to browser
DEBUG - 2025-04-10 02:31:25 --> Total execution time: 0.1102
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
DEBUG - 2025-04-10 02:31:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:31:25 --> Model Class Initialized
INFO - 2025-04-10 02:31:25 --> Final output sent to browser
DEBUG - 2025-04-10 02:31:25 --> Total execution time: 0.0382
INFO - 2025-04-10 02:51:37 --> Model Class Initialized
DEBUG - 2025-04-10 02:51:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:51:37 --> Model Class Initialized
DEBUG - 2025-04-10 02:51:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:51:37 --> Model Class Initialized
DEBUG - 2025-04-10 02:51:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:51:37 --> Model Class Initialized
INFO - 2025-04-10 02:51:37 --> Final output sent to browser
DEBUG - 2025-04-10 02:51:37 --> Total execution time: 0.0568
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 02:56:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
ERROR - 2025-04-10 02:56:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 02:56:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 02:56:33 --> Final output sent to browser
DEBUG - 2025-04-10 02:56:33 --> Total execution time: 0.2520
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:56:33 --> Model Class Initialized
INFO - 2025-04-10 02:56:34 --> Final output sent to browser
DEBUG - 2025-04-10 02:56:34 --> Total execution time: 0.0860
INFO - 2025-04-10 02:56:40 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 02:56:40 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 02:56:40 --> Model Class Initialized
DEBUG - 2025-04-10 02:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 02:56:40 --> Model Class Initialized
INFO - 2025-04-10 02:56:40 --> Final output sent to browser
DEBUG - 2025-04-10 02:56:40 --> Total execution time: 0.0777
INFO - 2025-04-10 03:01:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:01:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:01:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:01:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 03:01:32 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 03:01:32 --> Model Class Initialized
ERROR - 2025-04-10 03:01:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 03:01:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 03:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 03:01:32 --> Final output sent to browser
DEBUG - 2025-04-10 03:01:32 --> Total execution time: 0.1636
INFO - 2025-04-10 03:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:01:33 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:01:33 --> Model Class Initialized
INFO - 2025-04-10 03:01:33 --> Final output sent to browser
DEBUG - 2025-04-10 03:01:33 --> Total execution time: 0.0780
INFO - 2025-04-10 03:01:42 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:01:42 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:01:42 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:01:42 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 03:01:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 03:01:42 --> Model Class Initialized
ERROR - 2025-04-10 03:01:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 03:01:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 03:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 03:01:42 --> Final output sent to browser
DEBUG - 2025-04-10 03:01:42 --> Total execution time: 0.1907
INFO - 2025-04-10 03:01:43 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:01:43 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:01:43 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:01:43 --> Model Class Initialized
INFO - 2025-04-10 03:01:43 --> Final output sent to browser
DEBUG - 2025-04-10 03:01:43 --> Total execution time: 0.0369
INFO - 2025-04-10 03:01:49 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:01:49 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:01:49 --> Model Class Initialized
DEBUG - 2025-04-10 03:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:01:49 --> Model Class Initialized
INFO - 2025-04-10 03:01:49 --> Final output sent to browser
DEBUG - 2025-04-10 03:01:49 --> Total execution time: 0.0621
INFO - 2025-04-10 03:16:40 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:16:40 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:16:40 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:16:40 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 03:16:40 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 03:16:40 --> Model Class Initialized
ERROR - 2025-04-10 03:16:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 03:16:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 03:16:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 03:16:40 --> Final output sent to browser
DEBUG - 2025-04-10 03:16:40 --> Total execution time: 0.1728
INFO - 2025-04-10 03:16:41 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:16:41 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:16:41 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:16:41 --> Model Class Initialized
INFO - 2025-04-10 03:16:41 --> Final output sent to browser
DEBUG - 2025-04-10 03:16:41 --> Total execution time: 0.0488
INFO - 2025-04-10 03:16:46 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:16:46 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:16:46 --> Model Class Initialized
DEBUG - 2025-04-10 03:16:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:16:46 --> Model Class Initialized
INFO - 2025-04-10 03:16:46 --> Final output sent to browser
DEBUG - 2025-04-10 03:16:46 --> Total execution time: 0.0970
INFO - 2025-04-10 03:17:03 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:03 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:03 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:03 --> Model Class Initialized
INFO - 2025-04-10 03:17:04 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:04 --> Total execution time: 1.5815
INFO - 2025-04-10 03:17:04 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:04 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:04 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:04 --> Model Class Initialized
INFO - 2025-04-10 03:17:05 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:05 --> Total execution time: 0.0555
INFO - 2025-04-10 03:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:11 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 03:17:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 03:17:11 --> Model Class Initialized
ERROR - 2025-04-10 03:17:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 03:17:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 03:17:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 03:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 03:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 03:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 03:17:12 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:12 --> Total execution time: 0.1086
INFO - 2025-04-10 03:17:12 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:12 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:12 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:12 --> Model Class Initialized
INFO - 2025-04-10 03:17:12 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:12 --> Total execution time: 0.0606
INFO - 2025-04-10 03:17:15 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:15 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:15 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:15 --> Model Class Initialized
INFO - 2025-04-10 03:17:15 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:15 --> Total execution time: 0.0754
INFO - 2025-04-10 03:17:44 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:44 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:44 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:44 --> Model Class Initialized
INFO - 2025-04-10 03:17:45 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:45 --> Total execution time: 0.9993
INFO - 2025-04-10 03:17:45 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:45 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:45 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:45 --> Model Class Initialized
INFO - 2025-04-10 03:17:45 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:45 --> Total execution time: 0.0405
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 03:17:51 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
ERROR - 2025-04-10 03:17:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 03:17:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 03:17:51 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:51 --> Total execution time: 0.1321
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:51 --> Model Class Initialized
INFO - 2025-04-10 03:17:51 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:51 --> Total execution time: 0.0700
INFO - 2025-04-10 03:17:53 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:17:53 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:17:53 --> Model Class Initialized
DEBUG - 2025-04-10 03:17:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:17:53 --> Model Class Initialized
INFO - 2025-04-10 03:17:53 --> Final output sent to browser
DEBUG - 2025-04-10 03:17:53 --> Total execution time: 0.0439
INFO - 2025-04-10 03:20:00 --> Model Class Initialized
DEBUG - 2025-04-10 03:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:20:00 --> Model Class Initialized
DEBUG - 2025-04-10 03:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:20:00 --> Model Class Initialized
DEBUG - 2025-04-10 03:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:20:00 --> Model Class Initialized
INFO - 2025-04-10 03:20:01 --> Final output sent to browser
DEBUG - 2025-04-10 03:20:01 --> Total execution time: 1.0340
INFO - 2025-04-10 03:20:01 --> Model Class Initialized
DEBUG - 2025-04-10 03:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:20:01 --> Model Class Initialized
DEBUG - 2025-04-10 03:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:20:01 --> Model Class Initialized
DEBUG - 2025-04-10 03:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:20:01 --> Model Class Initialized
INFO - 2025-04-10 03:20:01 --> Final output sent to browser
DEBUG - 2025-04-10 03:20:01 --> Total execution time: 0.0469
INFO - 2025-04-10 03:35:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:35:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:35:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:35:32 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 03:35:32 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 03:35:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 03:35:32 --> Model Class Initialized
ERROR - 2025-04-10 03:35:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 03:35:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 03:35:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 03:35:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 03:35:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 03:35:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 03:35:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 03:35:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 03:35:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 03:35:33 --> Final output sent to browser
DEBUG - 2025-04-10 03:35:33 --> Total execution time: 0.6953
INFO - 2025-04-10 03:35:34 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:35:34 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:35:34 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:35:34 --> Model Class Initialized
INFO - 2025-04-10 03:35:34 --> Final output sent to browser
DEBUG - 2025-04-10 03:35:34 --> Total execution time: 0.0384
INFO - 2025-04-10 03:35:36 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 03:35:36 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 03:35:36 --> Model Class Initialized
DEBUG - 2025-04-10 03:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 03:35:36 --> Model Class Initialized
INFO - 2025-04-10 03:35:36 --> Final output sent to browser
DEBUG - 2025-04-10 03:35:36 --> Total execution time: 0.0594
INFO - 2025-04-10 04:47:14 --> Config Class Initialized
INFO - 2025-04-10 04:47:14 --> Hooks Class Initialized
DEBUG - 2025-04-10 04:47:14 --> UTF-8 Support Enabled
INFO - 2025-04-10 04:47:14 --> Utf8 Class Initialized
INFO - 2025-04-10 04:47:14 --> URI Class Initialized
DEBUG - 2025-04-10 04:47:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-10 04:47:14 --> No URI present. Default controller set.
INFO - 2025-04-10 04:47:14 --> Router Class Initialized
INFO - 2025-04-10 04:47:14 --> Output Class Initialized
INFO - 2025-04-10 04:47:14 --> Security Class Initialized
DEBUG - 2025-04-10 04:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 04:47:14 --> Input Class Initialized
INFO - 2025-04-10 04:47:14 --> Language Class Initialized
INFO - 2025-04-10 04:47:14 --> Language Class Initialized
INFO - 2025-04-10 04:47:14 --> Config Class Initialized
INFO - 2025-04-10 04:47:14 --> Loader Class Initialized
INFO - 2025-04-10 04:47:14 --> Helper loaded: url_helper
INFO - 2025-04-10 04:47:14 --> Helper loaded: file_helper
INFO - 2025-04-10 04:47:14 --> Helper loaded: html_helper
INFO - 2025-04-10 04:47:14 --> Helper loaded: form_helper
INFO - 2025-04-10 04:47:14 --> Helper loaded: text_helper
INFO - 2025-04-10 04:47:14 --> Helper loaded: lang_helper
INFO - 2025-04-10 04:47:14 --> Helper loaded: directory_helper
INFO - 2025-04-10 04:47:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 04:47:14 --> Database Driver Class Initialized
INFO - 2025-04-10 04:47:14 --> Email Class Initialized
INFO - 2025-04-10 04:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 04:47:14 --> Form Validation Class Initialized
INFO - 2025-04-10 04:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 04:47:14 --> Pagination Class Initialized
INFO - 2025-04-10 04:47:14 --> Controller Class Initialized
DEBUG - 2025-04-10 04:47:14 --> Auth MX_Controller Initialized
INFO - 2025-04-10 04:47:14 --> Model Class Initialized
DEBUG - 2025-04-10 04:47:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-10 04:47:14 --> Model Class Initialized
DEBUG - 2025-04-10 04:47:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 04:47:14 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 04:47:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 04:47:14 --> Model Class Initialized
DEBUG - 2025-04-10 04:47:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-10 04:47:14 --> Final output sent to browser
DEBUG - 2025-04-10 04:47:14 --> Total execution time: 0.0719
INFO - 2025-04-10 04:47:25 --> Config Class Initialized
INFO - 2025-04-10 04:47:25 --> Hooks Class Initialized
DEBUG - 2025-04-10 04:47:25 --> UTF-8 Support Enabled
INFO - 2025-04-10 04:47:25 --> Utf8 Class Initialized
INFO - 2025-04-10 04:47:25 --> URI Class Initialized
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-10 04:47:25 --> Router Class Initialized
INFO - 2025-04-10 04:47:25 --> Output Class Initialized
INFO - 2025-04-10 04:47:25 --> Security Class Initialized
DEBUG - 2025-04-10 04:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 04:47:25 --> Input Class Initialized
INFO - 2025-04-10 04:47:25 --> Language Class Initialized
INFO - 2025-04-10 04:47:25 --> Language Class Initialized
INFO - 2025-04-10 04:47:25 --> Config Class Initialized
INFO - 2025-04-10 04:47:25 --> Loader Class Initialized
INFO - 2025-04-10 04:47:25 --> Helper loaded: url_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: file_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: html_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: form_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: text_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: lang_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: directory_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 04:47:25 --> Database Driver Class Initialized
INFO - 2025-04-10 04:47:25 --> Email Class Initialized
INFO - 2025-04-10 04:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 04:47:25 --> Form Validation Class Initialized
INFO - 2025-04-10 04:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 04:47:25 --> Pagination Class Initialized
INFO - 2025-04-10 04:47:25 --> Controller Class Initialized
DEBUG - 2025-04-10 04:47:25 --> Auth MX_Controller Initialized
INFO - 2025-04-10 04:47:25 --> Model Class Initialized
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-10 04:47:25 --> Model Class Initialized
INFO - 2025-04-10 04:47:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-10 04:47:25 --> Config Class Initialized
INFO - 2025-04-10 04:47:25 --> Hooks Class Initialized
DEBUG - 2025-04-10 04:47:25 --> UTF-8 Support Enabled
INFO - 2025-04-10 04:47:25 --> Utf8 Class Initialized
INFO - 2025-04-10 04:47:25 --> URI Class Initialized
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-10 04:47:25 --> Router Class Initialized
INFO - 2025-04-10 04:47:25 --> Output Class Initialized
INFO - 2025-04-10 04:47:25 --> Security Class Initialized
DEBUG - 2025-04-10 04:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 04:47:25 --> Input Class Initialized
INFO - 2025-04-10 04:47:25 --> Language Class Initialized
INFO - 2025-04-10 04:47:25 --> Language Class Initialized
INFO - 2025-04-10 04:47:25 --> Config Class Initialized
INFO - 2025-04-10 04:47:25 --> Loader Class Initialized
INFO - 2025-04-10 04:47:25 --> Helper loaded: url_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: file_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: html_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: form_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: text_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: lang_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: directory_helper
INFO - 2025-04-10 04:47:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 04:47:25 --> Database Driver Class Initialized
INFO - 2025-04-10 04:47:25 --> Email Class Initialized
INFO - 2025-04-10 04:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 04:47:25 --> Form Validation Class Initialized
INFO - 2025-04-10 04:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 04:47:25 --> Pagination Class Initialized
INFO - 2025-04-10 04:47:25 --> Controller Class Initialized
DEBUG - 2025-04-10 04:47:25 --> Home MX_Controller Initialized
INFO - 2025-04-10 04:47:25 --> Model Class Initialized
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-10 04:47:25 --> Model Class Initialized
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 04:47:25 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 04:47:25 --> Model Class Initialized
ERROR - 2025-04-10 04:47:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 04:47:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 04:47:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 04:47:25 --> Final output sent to browser
DEBUG - 2025-04-10 04:47:25 --> Total execution time: 0.7447
INFO - 2025-04-10 04:47:34 --> Config Class Initialized
INFO - 2025-04-10 04:47:34 --> Hooks Class Initialized
DEBUG - 2025-04-10 04:47:34 --> UTF-8 Support Enabled
INFO - 2025-04-10 04:47:34 --> Utf8 Class Initialized
INFO - 2025-04-10 04:47:34 --> URI Class Initialized
DEBUG - 2025-04-10 04:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-10 04:47:34 --> Router Class Initialized
INFO - 2025-04-10 04:47:34 --> Output Class Initialized
INFO - 2025-04-10 04:47:34 --> Security Class Initialized
DEBUG - 2025-04-10 04:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 04:47:34 --> Input Class Initialized
INFO - 2025-04-10 04:47:34 --> Language Class Initialized
INFO - 2025-04-10 04:47:34 --> Language Class Initialized
INFO - 2025-04-10 04:47:34 --> Config Class Initialized
INFO - 2025-04-10 04:47:34 --> Loader Class Initialized
INFO - 2025-04-10 04:47:34 --> Helper loaded: url_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: file_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: html_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: form_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: text_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: lang_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: directory_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 04:47:34 --> Database Driver Class Initialized
INFO - 2025-04-10 04:47:34 --> Email Class Initialized
INFO - 2025-04-10 04:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 04:47:34 --> Form Validation Class Initialized
INFO - 2025-04-10 04:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 04:47:34 --> Pagination Class Initialized
INFO - 2025-04-10 04:47:34 --> Controller Class Initialized
DEBUG - 2025-04-10 04:47:34 --> Invoice MX_Controller Initialized
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 10:47:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
ERROR - 2025-04-10 10:47:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 10:47:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 10:47:34 --> Final output sent to browser
DEBUG - 2025-04-10 10:47:34 --> Total execution time: 0.1382
INFO - 2025-04-10 04:47:34 --> Config Class Initialized
INFO - 2025-04-10 04:47:34 --> Hooks Class Initialized
DEBUG - 2025-04-10 04:47:34 --> UTF-8 Support Enabled
INFO - 2025-04-10 04:47:34 --> Utf8 Class Initialized
INFO - 2025-04-10 04:47:34 --> URI Class Initialized
DEBUG - 2025-04-10 04:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-10 04:47:34 --> Router Class Initialized
INFO - 2025-04-10 04:47:34 --> Output Class Initialized
INFO - 2025-04-10 04:47:34 --> Security Class Initialized
DEBUG - 2025-04-10 04:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 04:47:34 --> Input Class Initialized
INFO - 2025-04-10 04:47:34 --> Language Class Initialized
INFO - 2025-04-10 04:47:34 --> Language Class Initialized
INFO - 2025-04-10 04:47:34 --> Config Class Initialized
INFO - 2025-04-10 04:47:34 --> Loader Class Initialized
INFO - 2025-04-10 04:47:34 --> Helper loaded: url_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: file_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: html_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: form_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: text_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: lang_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: directory_helper
INFO - 2025-04-10 04:47:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 04:47:34 --> Database Driver Class Initialized
INFO - 2025-04-10 04:47:34 --> Email Class Initialized
INFO - 2025-04-10 04:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 04:47:34 --> Form Validation Class Initialized
INFO - 2025-04-10 04:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 04:47:34 --> Pagination Class Initialized
INFO - 2025-04-10 04:47:34 --> Controller Class Initialized
DEBUG - 2025-04-10 04:47:34 --> Invoice MX_Controller Initialized
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
DEBUG - 2025-04-10 10:47:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 10:47:34 --> Model Class Initialized
INFO - 2025-04-10 10:47:34 --> Final output sent to browser
DEBUG - 2025-04-10 10:47:34 --> Total execution time: 0.0082
INFO - 2025-04-10 04:48:05 --> Config Class Initialized
INFO - 2025-04-10 04:48:05 --> Hooks Class Initialized
DEBUG - 2025-04-10 04:48:05 --> UTF-8 Support Enabled
INFO - 2025-04-10 04:48:05 --> Utf8 Class Initialized
INFO - 2025-04-10 04:48:05 --> URI Class Initialized
DEBUG - 2025-04-10 04:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-10 04:48:05 --> Router Class Initialized
INFO - 2025-04-10 04:48:05 --> Output Class Initialized
INFO - 2025-04-10 04:48:05 --> Security Class Initialized
DEBUG - 2025-04-10 04:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 04:48:05 --> Input Class Initialized
INFO - 2025-04-10 04:48:05 --> Language Class Initialized
INFO - 2025-04-10 04:48:05 --> Language Class Initialized
INFO - 2025-04-10 04:48:05 --> Config Class Initialized
INFO - 2025-04-10 04:48:05 --> Loader Class Initialized
INFO - 2025-04-10 04:48:05 --> Helper loaded: url_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: file_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: html_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: form_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: text_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: lang_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: directory_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 04:48:05 --> Database Driver Class Initialized
INFO - 2025-04-10 04:48:05 --> Email Class Initialized
INFO - 2025-04-10 04:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 04:48:05 --> Form Validation Class Initialized
INFO - 2025-04-10 04:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 04:48:05 --> Pagination Class Initialized
INFO - 2025-04-10 04:48:05 --> Controller Class Initialized
DEBUG - 2025-04-10 04:48:05 --> Invoice MX_Controller Initialized
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-10 10:48:05 --> Template MX_Controller Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
ERROR - 2025-04-10 10:48:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-10 10:48:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-10 10:48:05 --> Final output sent to browser
DEBUG - 2025-04-10 10:48:05 --> Total execution time: 0.1163
INFO - 2025-04-10 04:48:05 --> Config Class Initialized
INFO - 2025-04-10 04:48:05 --> Hooks Class Initialized
DEBUG - 2025-04-10 04:48:05 --> UTF-8 Support Enabled
INFO - 2025-04-10 04:48:05 --> Utf8 Class Initialized
INFO - 2025-04-10 04:48:05 --> URI Class Initialized
DEBUG - 2025-04-10 04:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-10 04:48:05 --> Router Class Initialized
INFO - 2025-04-10 04:48:05 --> Output Class Initialized
INFO - 2025-04-10 04:48:05 --> Security Class Initialized
DEBUG - 2025-04-10 04:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 04:48:05 --> Input Class Initialized
INFO - 2025-04-10 04:48:05 --> Language Class Initialized
INFO - 2025-04-10 04:48:05 --> Language Class Initialized
INFO - 2025-04-10 04:48:05 --> Config Class Initialized
INFO - 2025-04-10 04:48:05 --> Loader Class Initialized
INFO - 2025-04-10 04:48:05 --> Helper loaded: url_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: file_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: html_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: form_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: text_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: lang_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: directory_helper
INFO - 2025-04-10 04:48:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 04:48:05 --> Database Driver Class Initialized
INFO - 2025-04-10 04:48:05 --> Email Class Initialized
INFO - 2025-04-10 04:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 04:48:05 --> Form Validation Class Initialized
INFO - 2025-04-10 04:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 04:48:05 --> Pagination Class Initialized
INFO - 2025-04-10 04:48:05 --> Controller Class Initialized
DEBUG - 2025-04-10 04:48:05 --> Invoice MX_Controller Initialized
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
DEBUG - 2025-04-10 10:48:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-10 10:48:05 --> Model Class Initialized
INFO - 2025-04-10 10:48:05 --> Final output sent to browser
DEBUG - 2025-04-10 10:48:05 --> Total execution time: 0.0643
INFO - 2025-04-10 08:56:19 --> Config Class Initialized
INFO - 2025-04-10 08:56:19 --> Hooks Class Initialized
DEBUG - 2025-04-10 08:56:19 --> UTF-8 Support Enabled
INFO - 2025-04-10 08:56:19 --> Utf8 Class Initialized
INFO - 2025-04-10 08:56:19 --> URI Class Initialized
INFO - 2025-04-10 08:56:19 --> Router Class Initialized
INFO - 2025-04-10 08:56:19 --> Output Class Initialized
INFO - 2025-04-10 08:56:19 --> Security Class Initialized
DEBUG - 2025-04-10 08:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 08:56:19 --> Input Class Initialized
INFO - 2025-04-10 08:56:19 --> Language Class Initialized
INFO - 2025-04-10 08:56:19 --> Language Class Initialized
INFO - 2025-04-10 08:56:19 --> Config Class Initialized
INFO - 2025-04-10 08:56:19 --> Loader Class Initialized
INFO - 2025-04-10 08:56:19 --> Helper loaded: url_helper
INFO - 2025-04-10 08:56:19 --> Helper loaded: file_helper
INFO - 2025-04-10 08:56:19 --> Helper loaded: html_helper
INFO - 2025-04-10 08:56:19 --> Helper loaded: form_helper
INFO - 2025-04-10 08:56:19 --> Helper loaded: text_helper
INFO - 2025-04-10 08:56:19 --> Helper loaded: lang_helper
INFO - 2025-04-10 08:56:19 --> Helper loaded: directory_helper
INFO - 2025-04-10 08:56:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 08:56:19 --> Database Driver Class Initialized
INFO - 2025-04-10 08:56:19 --> Email Class Initialized
INFO - 2025-04-10 08:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 08:56:19 --> Form Validation Class Initialized
INFO - 2025-04-10 08:56:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 08:56:19 --> Pagination Class Initialized
INFO - 2025-04-10 08:56:19 --> Controller Class Initialized
INFO - 2025-04-10 08:56:19 --> Model Class Initialized
INFO - 2025-04-10 08:56:19 --> Helper loaded: security_helper
INFO - 2025-04-10 08:56:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-10 08:56:19 --> Final output sent to browser
DEBUG - 2025-04-10 08:56:19 --> Total execution time: 0.0284
INFO - 2025-04-10 09:01:07 --> Config Class Initialized
INFO - 2025-04-10 09:01:07 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:01:07 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:01:07 --> Utf8 Class Initialized
INFO - 2025-04-10 09:01:07 --> URI Class Initialized
INFO - 2025-04-10 09:01:07 --> Router Class Initialized
INFO - 2025-04-10 09:01:07 --> Output Class Initialized
INFO - 2025-04-10 09:01:07 --> Security Class Initialized
DEBUG - 2025-04-10 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:01:07 --> Input Class Initialized
INFO - 2025-04-10 09:01:07 --> Language Class Initialized
INFO - 2025-04-10 09:01:07 --> Language Class Initialized
INFO - 2025-04-10 09:01:07 --> Config Class Initialized
INFO - 2025-04-10 09:01:07 --> Loader Class Initialized
INFO - 2025-04-10 09:01:07 --> Helper loaded: url_helper
INFO - 2025-04-10 09:01:07 --> Helper loaded: file_helper
INFO - 2025-04-10 09:01:07 --> Helper loaded: html_helper
INFO - 2025-04-10 09:01:07 --> Helper loaded: form_helper
INFO - 2025-04-10 09:01:07 --> Helper loaded: text_helper
INFO - 2025-04-10 09:01:07 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:01:07 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:01:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:01:07 --> Database Driver Class Initialized
INFO - 2025-04-10 09:01:07 --> Email Class Initialized
INFO - 2025-04-10 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:01:07 --> Form Validation Class Initialized
INFO - 2025-04-10 09:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:01:07 --> Pagination Class Initialized
INFO - 2025-04-10 09:01:07 --> Controller Class Initialized
INFO - 2025-04-10 09:01:07 --> Model Class Initialized
INFO - 2025-04-10 09:01:07 --> Helper loaded: security_helper
INFO - 2025-04-10 09:01:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-10 09:01:07 --> Final output sent to browser
DEBUG - 2025-04-10 09:01:07 --> Total execution time: 0.0098
INFO - 2025-04-10 09:02:52 --> Config Class Initialized
INFO - 2025-04-10 09:02:52 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:02:52 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:02:52 --> Utf8 Class Initialized
INFO - 2025-04-10 09:02:52 --> URI Class Initialized
INFO - 2025-04-10 09:02:52 --> Router Class Initialized
INFO - 2025-04-10 09:02:52 --> Output Class Initialized
INFO - 2025-04-10 09:02:52 --> Security Class Initialized
DEBUG - 2025-04-10 09:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:02:52 --> Input Class Initialized
INFO - 2025-04-10 09:02:52 --> Language Class Initialized
INFO - 2025-04-10 09:02:52 --> Language Class Initialized
INFO - 2025-04-10 09:02:52 --> Config Class Initialized
INFO - 2025-04-10 09:02:52 --> Loader Class Initialized
INFO - 2025-04-10 09:02:52 --> Helper loaded: url_helper
INFO - 2025-04-10 09:02:52 --> Helper loaded: file_helper
INFO - 2025-04-10 09:02:52 --> Helper loaded: html_helper
INFO - 2025-04-10 09:02:52 --> Helper loaded: form_helper
INFO - 2025-04-10 09:02:52 --> Helper loaded: text_helper
INFO - 2025-04-10 09:02:52 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:02:52 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:02:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:02:52 --> Database Driver Class Initialized
INFO - 2025-04-10 09:02:52 --> Email Class Initialized
INFO - 2025-04-10 09:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:02:52 --> Form Validation Class Initialized
INFO - 2025-04-10 09:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:02:52 --> Pagination Class Initialized
INFO - 2025-04-10 09:02:52 --> Controller Class Initialized
INFO - 2025-04-10 09:02:52 --> Model Class Initialized
INFO - 2025-04-10 09:02:52 --> Helper loaded: security_helper
INFO - 2025-04-10 09:02:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-10 09:02:52 --> Final output sent to browser
DEBUG - 2025-04-10 09:02:52 --> Total execution time: 0.0056
INFO - 2025-04-10 09:14:37 --> Config Class Initialized
INFO - 2025-04-10 09:14:37 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:14:37 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:14:37 --> Utf8 Class Initialized
INFO - 2025-04-10 09:14:37 --> URI Class Initialized
INFO - 2025-04-10 09:14:37 --> Router Class Initialized
INFO - 2025-04-10 09:14:37 --> Output Class Initialized
INFO - 2025-04-10 09:14:37 --> Security Class Initialized
DEBUG - 2025-04-10 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:14:37 --> Input Class Initialized
INFO - 2025-04-10 09:14:37 --> Language Class Initialized
INFO - 2025-04-10 09:14:37 --> Language Class Initialized
INFO - 2025-04-10 09:14:37 --> Config Class Initialized
INFO - 2025-04-10 09:14:37 --> Loader Class Initialized
INFO - 2025-04-10 09:14:37 --> Helper loaded: url_helper
INFO - 2025-04-10 09:14:37 --> Helper loaded: file_helper
INFO - 2025-04-10 09:14:37 --> Helper loaded: html_helper
INFO - 2025-04-10 09:14:37 --> Helper loaded: form_helper
INFO - 2025-04-10 09:14:37 --> Helper loaded: text_helper
INFO - 2025-04-10 09:14:37 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:14:37 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:14:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:14:37 --> Database Driver Class Initialized
INFO - 2025-04-10 09:14:37 --> Email Class Initialized
INFO - 2025-04-10 09:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:14:37 --> Form Validation Class Initialized
INFO - 2025-04-10 09:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:14:37 --> Pagination Class Initialized
INFO - 2025-04-10 09:14:37 --> Controller Class Initialized
INFO - 2025-04-10 09:14:37 --> Model Class Initialized
INFO - 2025-04-10 09:14:37 --> Helper loaded: security_helper
INFO - 2025-04-10 09:14:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-10 09:14:37 --> Final output sent to browser
DEBUG - 2025-04-10 09:14:37 --> Total execution time: 0.0984
INFO - 2025-04-10 09:21:33 --> Config Class Initialized
INFO - 2025-04-10 09:21:33 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:21:33 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:21:33 --> Utf8 Class Initialized
INFO - 2025-04-10 09:21:33 --> URI Class Initialized
INFO - 2025-04-10 09:21:33 --> Router Class Initialized
INFO - 2025-04-10 09:21:33 --> Output Class Initialized
INFO - 2025-04-10 09:21:33 --> Security Class Initialized
DEBUG - 2025-04-10 09:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:21:33 --> Input Class Initialized
INFO - 2025-04-10 09:21:33 --> Language Class Initialized
INFO - 2025-04-10 09:21:33 --> Language Class Initialized
INFO - 2025-04-10 09:21:33 --> Config Class Initialized
INFO - 2025-04-10 09:21:33 --> Loader Class Initialized
INFO - 2025-04-10 09:21:33 --> Helper loaded: url_helper
INFO - 2025-04-10 09:21:33 --> Helper loaded: file_helper
INFO - 2025-04-10 09:21:33 --> Helper loaded: html_helper
INFO - 2025-04-10 09:21:33 --> Helper loaded: form_helper
INFO - 2025-04-10 09:21:33 --> Helper loaded: text_helper
INFO - 2025-04-10 09:21:33 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:21:33 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:21:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:21:33 --> Database Driver Class Initialized
INFO - 2025-04-10 09:21:33 --> Email Class Initialized
INFO - 2025-04-10 09:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:21:33 --> Form Validation Class Initialized
INFO - 2025-04-10 09:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:21:33 --> Pagination Class Initialized
INFO - 2025-04-10 09:21:33 --> Controller Class Initialized
INFO - 2025-04-10 09:21:33 --> Model Class Initialized
INFO - 2025-04-10 09:21:33 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:21:33 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:22:45 --> Config Class Initialized
INFO - 2025-04-10 09:22:45 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:22:45 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:22:45 --> Utf8 Class Initialized
INFO - 2025-04-10 09:22:45 --> URI Class Initialized
INFO - 2025-04-10 09:22:45 --> Router Class Initialized
INFO - 2025-04-10 09:22:45 --> Output Class Initialized
INFO - 2025-04-10 09:22:45 --> Security Class Initialized
DEBUG - 2025-04-10 09:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:22:45 --> Input Class Initialized
INFO - 2025-04-10 09:22:45 --> Language Class Initialized
INFO - 2025-04-10 09:22:45 --> Language Class Initialized
INFO - 2025-04-10 09:22:45 --> Config Class Initialized
INFO - 2025-04-10 09:22:45 --> Loader Class Initialized
INFO - 2025-04-10 09:22:45 --> Helper loaded: url_helper
INFO - 2025-04-10 09:22:45 --> Helper loaded: file_helper
INFO - 2025-04-10 09:22:45 --> Helper loaded: html_helper
INFO - 2025-04-10 09:22:45 --> Helper loaded: form_helper
INFO - 2025-04-10 09:22:45 --> Helper loaded: text_helper
INFO - 2025-04-10 09:22:45 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:22:45 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:22:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:22:45 --> Database Driver Class Initialized
INFO - 2025-04-10 09:22:45 --> Email Class Initialized
INFO - 2025-04-10 09:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:22:45 --> Form Validation Class Initialized
INFO - 2025-04-10 09:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:22:45 --> Pagination Class Initialized
INFO - 2025-04-10 09:22:45 --> Controller Class Initialized
INFO - 2025-04-10 09:22:45 --> Model Class Initialized
INFO - 2025-04-10 09:22:45 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:22:45 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:23:55 --> Config Class Initialized
INFO - 2025-04-10 09:23:55 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:23:55 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:23:55 --> Utf8 Class Initialized
INFO - 2025-04-10 09:23:55 --> URI Class Initialized
INFO - 2025-04-10 09:23:55 --> Router Class Initialized
INFO - 2025-04-10 09:23:55 --> Output Class Initialized
INFO - 2025-04-10 09:23:55 --> Security Class Initialized
DEBUG - 2025-04-10 09:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:23:55 --> Input Class Initialized
INFO - 2025-04-10 09:23:55 --> Language Class Initialized
INFO - 2025-04-10 09:23:55 --> Language Class Initialized
INFO - 2025-04-10 09:23:55 --> Config Class Initialized
INFO - 2025-04-10 09:23:55 --> Loader Class Initialized
INFO - 2025-04-10 09:23:55 --> Helper loaded: url_helper
INFO - 2025-04-10 09:23:55 --> Helper loaded: file_helper
INFO - 2025-04-10 09:23:55 --> Helper loaded: html_helper
INFO - 2025-04-10 09:23:55 --> Helper loaded: form_helper
INFO - 2025-04-10 09:23:55 --> Helper loaded: text_helper
INFO - 2025-04-10 09:23:55 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:23:55 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:23:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:23:55 --> Database Driver Class Initialized
INFO - 2025-04-10 09:23:55 --> Email Class Initialized
INFO - 2025-04-10 09:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:23:55 --> Form Validation Class Initialized
INFO - 2025-04-10 09:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:23:55 --> Pagination Class Initialized
INFO - 2025-04-10 09:23:55 --> Controller Class Initialized
INFO - 2025-04-10 09:23:55 --> Model Class Initialized
INFO - 2025-04-10 09:23:55 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:23:55 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:24:15 --> Config Class Initialized
INFO - 2025-04-10 09:24:15 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:24:15 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:24:15 --> Utf8 Class Initialized
INFO - 2025-04-10 09:24:15 --> URI Class Initialized
INFO - 2025-04-10 09:24:15 --> Router Class Initialized
INFO - 2025-04-10 09:24:15 --> Output Class Initialized
INFO - 2025-04-10 09:24:15 --> Security Class Initialized
DEBUG - 2025-04-10 09:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:24:15 --> Input Class Initialized
INFO - 2025-04-10 09:24:15 --> Language Class Initialized
INFO - 2025-04-10 09:24:15 --> Language Class Initialized
INFO - 2025-04-10 09:24:15 --> Config Class Initialized
INFO - 2025-04-10 09:24:15 --> Loader Class Initialized
INFO - 2025-04-10 09:24:15 --> Helper loaded: url_helper
INFO - 2025-04-10 09:24:15 --> Helper loaded: file_helper
INFO - 2025-04-10 09:24:15 --> Helper loaded: html_helper
INFO - 2025-04-10 09:24:15 --> Helper loaded: form_helper
INFO - 2025-04-10 09:24:15 --> Helper loaded: text_helper
INFO - 2025-04-10 09:24:15 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:24:15 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:24:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:24:15 --> Database Driver Class Initialized
INFO - 2025-04-10 09:24:15 --> Email Class Initialized
INFO - 2025-04-10 09:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:24:15 --> Form Validation Class Initialized
INFO - 2025-04-10 09:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:24:15 --> Pagination Class Initialized
INFO - 2025-04-10 09:24:15 --> Controller Class Initialized
INFO - 2025-04-10 09:24:15 --> Model Class Initialized
INFO - 2025-04-10 09:24:15 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:24:15 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:26:18 --> Config Class Initialized
INFO - 2025-04-10 09:26:18 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:26:18 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:26:18 --> Utf8 Class Initialized
INFO - 2025-04-10 09:26:18 --> URI Class Initialized
INFO - 2025-04-10 09:26:18 --> Router Class Initialized
INFO - 2025-04-10 09:26:18 --> Output Class Initialized
INFO - 2025-04-10 09:26:18 --> Security Class Initialized
DEBUG - 2025-04-10 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:26:18 --> Input Class Initialized
INFO - 2025-04-10 09:26:18 --> Language Class Initialized
INFO - 2025-04-10 09:26:18 --> Language Class Initialized
INFO - 2025-04-10 09:26:18 --> Config Class Initialized
INFO - 2025-04-10 09:26:18 --> Loader Class Initialized
INFO - 2025-04-10 09:26:18 --> Helper loaded: url_helper
INFO - 2025-04-10 09:26:18 --> Helper loaded: file_helper
INFO - 2025-04-10 09:26:18 --> Helper loaded: html_helper
INFO - 2025-04-10 09:26:18 --> Helper loaded: form_helper
INFO - 2025-04-10 09:26:18 --> Helper loaded: text_helper
INFO - 2025-04-10 09:26:18 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:26:18 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:26:18 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:26:18 --> Database Driver Class Initialized
INFO - 2025-04-10 09:26:18 --> Email Class Initialized
INFO - 2025-04-10 09:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:26:18 --> Form Validation Class Initialized
INFO - 2025-04-10 09:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:26:18 --> Pagination Class Initialized
INFO - 2025-04-10 09:26:18 --> Controller Class Initialized
INFO - 2025-04-10 09:26:18 --> Model Class Initialized
INFO - 2025-04-10 09:26:18 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:26:18 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:26:22 --> Config Class Initialized
INFO - 2025-04-10 09:26:22 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:26:22 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:26:22 --> Utf8 Class Initialized
INFO - 2025-04-10 09:26:22 --> URI Class Initialized
INFO - 2025-04-10 09:26:22 --> Router Class Initialized
INFO - 2025-04-10 09:26:22 --> Output Class Initialized
INFO - 2025-04-10 09:26:22 --> Security Class Initialized
DEBUG - 2025-04-10 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:26:22 --> Input Class Initialized
INFO - 2025-04-10 09:26:22 --> Language Class Initialized
INFO - 2025-04-10 09:26:22 --> Language Class Initialized
INFO - 2025-04-10 09:26:22 --> Config Class Initialized
INFO - 2025-04-10 09:26:22 --> Loader Class Initialized
INFO - 2025-04-10 09:26:22 --> Helper loaded: url_helper
INFO - 2025-04-10 09:26:22 --> Helper loaded: file_helper
INFO - 2025-04-10 09:26:22 --> Helper loaded: html_helper
INFO - 2025-04-10 09:26:22 --> Helper loaded: form_helper
INFO - 2025-04-10 09:26:22 --> Helper loaded: text_helper
INFO - 2025-04-10 09:26:22 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:26:22 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:26:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:26:22 --> Database Driver Class Initialized
INFO - 2025-04-10 09:26:22 --> Email Class Initialized
INFO - 2025-04-10 09:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:26:22 --> Form Validation Class Initialized
INFO - 2025-04-10 09:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:26:22 --> Pagination Class Initialized
INFO - 2025-04-10 09:26:22 --> Controller Class Initialized
INFO - 2025-04-10 09:26:22 --> Model Class Initialized
INFO - 2025-04-10 09:26:22 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:26:22 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:27:41 --> Config Class Initialized
INFO - 2025-04-10 09:27:41 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:27:41 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:27:41 --> Utf8 Class Initialized
INFO - 2025-04-10 09:27:41 --> URI Class Initialized
INFO - 2025-04-10 09:27:41 --> Router Class Initialized
INFO - 2025-04-10 09:27:41 --> Output Class Initialized
INFO - 2025-04-10 09:27:41 --> Security Class Initialized
DEBUG - 2025-04-10 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:27:41 --> Input Class Initialized
INFO - 2025-04-10 09:27:41 --> Language Class Initialized
INFO - 2025-04-10 09:27:41 --> Language Class Initialized
INFO - 2025-04-10 09:27:41 --> Config Class Initialized
INFO - 2025-04-10 09:27:41 --> Loader Class Initialized
INFO - 2025-04-10 09:27:41 --> Helper loaded: url_helper
INFO - 2025-04-10 09:27:41 --> Helper loaded: file_helper
INFO - 2025-04-10 09:27:41 --> Helper loaded: html_helper
INFO - 2025-04-10 09:27:41 --> Helper loaded: form_helper
INFO - 2025-04-10 09:27:41 --> Helper loaded: text_helper
INFO - 2025-04-10 09:27:41 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:27:41 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:27:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:27:41 --> Database Driver Class Initialized
INFO - 2025-04-10 09:27:41 --> Email Class Initialized
INFO - 2025-04-10 09:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:27:41 --> Form Validation Class Initialized
INFO - 2025-04-10 09:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:27:41 --> Pagination Class Initialized
INFO - 2025-04-10 09:27:41 --> Controller Class Initialized
INFO - 2025-04-10 09:27:41 --> Model Class Initialized
INFO - 2025-04-10 09:27:41 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:27:41 --> Severity: error --> Exception: Call to undefined method Api_model::verify_api_user_credentials() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 133
INFO - 2025-04-10 09:27:46 --> Config Class Initialized
INFO - 2025-04-10 09:27:46 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:27:46 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:27:46 --> Utf8 Class Initialized
INFO - 2025-04-10 09:27:46 --> URI Class Initialized
INFO - 2025-04-10 09:27:46 --> Router Class Initialized
INFO - 2025-04-10 09:27:46 --> Output Class Initialized
INFO - 2025-04-10 09:27:46 --> Security Class Initialized
DEBUG - 2025-04-10 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:27:46 --> Input Class Initialized
INFO - 2025-04-10 09:27:46 --> Language Class Initialized
INFO - 2025-04-10 09:27:46 --> Language Class Initialized
INFO - 2025-04-10 09:27:46 --> Config Class Initialized
INFO - 2025-04-10 09:27:46 --> Loader Class Initialized
INFO - 2025-04-10 09:27:46 --> Helper loaded: url_helper
INFO - 2025-04-10 09:27:46 --> Helper loaded: file_helper
INFO - 2025-04-10 09:27:46 --> Helper loaded: html_helper
INFO - 2025-04-10 09:27:46 --> Helper loaded: form_helper
INFO - 2025-04-10 09:27:46 --> Helper loaded: text_helper
INFO - 2025-04-10 09:27:46 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:27:46 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:27:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:27:46 --> Database Driver Class Initialized
INFO - 2025-04-10 09:27:46 --> Email Class Initialized
INFO - 2025-04-10 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:27:46 --> Form Validation Class Initialized
INFO - 2025-04-10 09:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:27:46 --> Pagination Class Initialized
INFO - 2025-04-10 09:27:46 --> Controller Class Initialized
INFO - 2025-04-10 09:27:46 --> Model Class Initialized
INFO - 2025-04-10 09:27:46 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:27:46 --> Severity: error --> Exception: Call to undefined method Api_model::verify_api_user_credentials() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 133
INFO - 2025-04-10 09:27:49 --> Config Class Initialized
INFO - 2025-04-10 09:27:49 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:27:49 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:27:49 --> Utf8 Class Initialized
INFO - 2025-04-10 09:27:49 --> URI Class Initialized
INFO - 2025-04-10 09:27:49 --> Router Class Initialized
INFO - 2025-04-10 09:27:49 --> Output Class Initialized
INFO - 2025-04-10 09:27:49 --> Security Class Initialized
DEBUG - 2025-04-10 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:27:49 --> Input Class Initialized
INFO - 2025-04-10 09:27:49 --> Language Class Initialized
INFO - 2025-04-10 09:27:49 --> Language Class Initialized
INFO - 2025-04-10 09:27:49 --> Config Class Initialized
INFO - 2025-04-10 09:27:49 --> Loader Class Initialized
INFO - 2025-04-10 09:27:49 --> Helper loaded: url_helper
INFO - 2025-04-10 09:27:49 --> Helper loaded: file_helper
INFO - 2025-04-10 09:27:49 --> Helper loaded: html_helper
INFO - 2025-04-10 09:27:49 --> Helper loaded: form_helper
INFO - 2025-04-10 09:27:49 --> Helper loaded: text_helper
INFO - 2025-04-10 09:27:49 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:27:49 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:27:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:27:49 --> Database Driver Class Initialized
INFO - 2025-04-10 09:27:49 --> Email Class Initialized
INFO - 2025-04-10 09:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:27:49 --> Form Validation Class Initialized
INFO - 2025-04-10 09:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:27:49 --> Pagination Class Initialized
INFO - 2025-04-10 09:27:49 --> Controller Class Initialized
INFO - 2025-04-10 09:27:49 --> Model Class Initialized
INFO - 2025-04-10 09:27:49 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:27:49 --> Severity: error --> Exception: Call to undefined method Api_model::verify_api_user_credentials() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 133
INFO - 2025-04-10 09:28:03 --> Config Class Initialized
INFO - 2025-04-10 09:28:03 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:28:03 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:28:03 --> Utf8 Class Initialized
INFO - 2025-04-10 09:28:03 --> URI Class Initialized
INFO - 2025-04-10 09:28:03 --> Router Class Initialized
INFO - 2025-04-10 09:28:03 --> Output Class Initialized
INFO - 2025-04-10 09:28:03 --> Security Class Initialized
DEBUG - 2025-04-10 09:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:28:03 --> Input Class Initialized
INFO - 2025-04-10 09:28:03 --> Language Class Initialized
INFO - 2025-04-10 09:28:03 --> Language Class Initialized
INFO - 2025-04-10 09:28:03 --> Config Class Initialized
INFO - 2025-04-10 09:28:03 --> Loader Class Initialized
INFO - 2025-04-10 09:28:03 --> Helper loaded: url_helper
INFO - 2025-04-10 09:28:03 --> Helper loaded: file_helper
INFO - 2025-04-10 09:28:03 --> Helper loaded: html_helper
INFO - 2025-04-10 09:28:03 --> Helper loaded: form_helper
INFO - 2025-04-10 09:28:03 --> Helper loaded: text_helper
INFO - 2025-04-10 09:28:03 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:28:03 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:28:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:28:03 --> Database Driver Class Initialized
INFO - 2025-04-10 09:28:03 --> Email Class Initialized
INFO - 2025-04-10 09:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:28:03 --> Form Validation Class Initialized
INFO - 2025-04-10 09:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:28:03 --> Pagination Class Initialized
INFO - 2025-04-10 09:28:03 --> Controller Class Initialized
INFO - 2025-04-10 09:28:03 --> Model Class Initialized
INFO - 2025-04-10 09:28:03 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:28:03 --> Severity: error --> Exception: Call to undefined method Api_model::verify_api_user_credentials() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 133
INFO - 2025-04-10 09:28:34 --> Config Class Initialized
INFO - 2025-04-10 09:28:34 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:28:34 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:28:34 --> Utf8 Class Initialized
INFO - 2025-04-10 09:28:34 --> URI Class Initialized
INFO - 2025-04-10 09:28:34 --> Router Class Initialized
INFO - 2025-04-10 09:28:34 --> Output Class Initialized
INFO - 2025-04-10 09:28:34 --> Security Class Initialized
DEBUG - 2025-04-10 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:28:34 --> Input Class Initialized
INFO - 2025-04-10 09:28:34 --> Language Class Initialized
INFO - 2025-04-10 09:28:34 --> Language Class Initialized
INFO - 2025-04-10 09:28:34 --> Config Class Initialized
INFO - 2025-04-10 09:28:34 --> Loader Class Initialized
INFO - 2025-04-10 09:28:34 --> Helper loaded: url_helper
INFO - 2025-04-10 09:28:34 --> Helper loaded: file_helper
INFO - 2025-04-10 09:28:34 --> Helper loaded: html_helper
INFO - 2025-04-10 09:28:34 --> Helper loaded: form_helper
INFO - 2025-04-10 09:28:34 --> Helper loaded: text_helper
INFO - 2025-04-10 09:28:34 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:28:34 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:28:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:28:34 --> Database Driver Class Initialized
INFO - 2025-04-10 09:28:34 --> Email Class Initialized
INFO - 2025-04-10 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:28:34 --> Form Validation Class Initialized
INFO - 2025-04-10 09:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:28:34 --> Pagination Class Initialized
INFO - 2025-04-10 09:28:34 --> Controller Class Initialized
INFO - 2025-04-10 09:28:34 --> Model Class Initialized
INFO - 2025-04-10 09:28:34 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:28:34 --> Severity: error --> Exception: Call to undefined method Api_model::verify_api_user_credentials() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 133
INFO - 2025-04-10 09:28:35 --> Config Class Initialized
INFO - 2025-04-10 09:28:35 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:28:35 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:28:35 --> Utf8 Class Initialized
INFO - 2025-04-10 09:28:35 --> URI Class Initialized
INFO - 2025-04-10 09:28:35 --> Router Class Initialized
INFO - 2025-04-10 09:28:35 --> Output Class Initialized
INFO - 2025-04-10 09:28:35 --> Security Class Initialized
DEBUG - 2025-04-10 09:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:28:35 --> Input Class Initialized
INFO - 2025-04-10 09:28:35 --> Language Class Initialized
INFO - 2025-04-10 09:28:35 --> Language Class Initialized
INFO - 2025-04-10 09:28:35 --> Config Class Initialized
INFO - 2025-04-10 09:28:35 --> Loader Class Initialized
INFO - 2025-04-10 09:28:35 --> Helper loaded: url_helper
INFO - 2025-04-10 09:28:35 --> Helper loaded: file_helper
INFO - 2025-04-10 09:28:35 --> Helper loaded: html_helper
INFO - 2025-04-10 09:28:35 --> Helper loaded: form_helper
INFO - 2025-04-10 09:28:35 --> Helper loaded: text_helper
INFO - 2025-04-10 09:28:35 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:28:35 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:28:35 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:28:35 --> Database Driver Class Initialized
INFO - 2025-04-10 09:28:35 --> Email Class Initialized
INFO - 2025-04-10 09:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:28:35 --> Form Validation Class Initialized
INFO - 2025-04-10 09:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:28:35 --> Pagination Class Initialized
INFO - 2025-04-10 09:28:35 --> Controller Class Initialized
INFO - 2025-04-10 09:28:35 --> Model Class Initialized
INFO - 2025-04-10 09:28:35 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:28:35 --> Severity: error --> Exception: Call to undefined method Api_model::verify_api_user_credentials() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 133
INFO - 2025-04-10 09:29:57 --> Config Class Initialized
INFO - 2025-04-10 09:29:57 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:29:57 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:29:57 --> Utf8 Class Initialized
INFO - 2025-04-10 09:29:57 --> URI Class Initialized
INFO - 2025-04-10 09:29:57 --> Router Class Initialized
INFO - 2025-04-10 09:29:57 --> Output Class Initialized
INFO - 2025-04-10 09:29:57 --> Security Class Initialized
DEBUG - 2025-04-10 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:29:57 --> Input Class Initialized
INFO - 2025-04-10 09:29:57 --> Language Class Initialized
INFO - 2025-04-10 09:29:57 --> Language Class Initialized
INFO - 2025-04-10 09:29:57 --> Config Class Initialized
INFO - 2025-04-10 09:29:57 --> Loader Class Initialized
INFO - 2025-04-10 09:29:57 --> Helper loaded: url_helper
INFO - 2025-04-10 09:29:57 --> Helper loaded: file_helper
INFO - 2025-04-10 09:29:57 --> Helper loaded: html_helper
INFO - 2025-04-10 09:29:57 --> Helper loaded: form_helper
INFO - 2025-04-10 09:29:57 --> Helper loaded: text_helper
INFO - 2025-04-10 09:29:57 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:29:57 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:29:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:29:57 --> Database Driver Class Initialized
INFO - 2025-04-10 09:29:57 --> Email Class Initialized
INFO - 2025-04-10 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:29:57 --> Form Validation Class Initialized
INFO - 2025-04-10 09:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:29:57 --> Pagination Class Initialized
INFO - 2025-04-10 09:29:57 --> Controller Class Initialized
INFO - 2025-04-10 09:29:57 --> Model Class Initialized
INFO - 2025-04-10 09:29:57 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:29:57 --> Severity: error --> Exception: Call to undefined method Api_model::verify_api_user_credentials() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 133
INFO - 2025-04-10 09:32:44 --> Config Class Initialized
INFO - 2025-04-10 09:32:44 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:32:44 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:32:44 --> Utf8 Class Initialized
INFO - 2025-04-10 09:32:44 --> URI Class Initialized
INFO - 2025-04-10 09:32:44 --> Router Class Initialized
INFO - 2025-04-10 09:32:44 --> Output Class Initialized
INFO - 2025-04-10 09:32:44 --> Security Class Initialized
DEBUG - 2025-04-10 09:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:32:44 --> Input Class Initialized
INFO - 2025-04-10 09:32:44 --> Language Class Initialized
ERROR - 2025-04-10 09:32:44 --> 404 Page Not Found: Apiv2/verify_user_credentials
INFO - 2025-04-10 09:32:54 --> Config Class Initialized
INFO - 2025-04-10 09:32:54 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:32:54 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:32:54 --> Utf8 Class Initialized
INFO - 2025-04-10 09:32:54 --> URI Class Initialized
INFO - 2025-04-10 09:32:54 --> Router Class Initialized
INFO - 2025-04-10 09:32:54 --> Output Class Initialized
INFO - 2025-04-10 09:32:54 --> Security Class Initialized
DEBUG - 2025-04-10 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:32:54 --> Input Class Initialized
INFO - 2025-04-10 09:32:54 --> Language Class Initialized
ERROR - 2025-04-10 09:32:54 --> 404 Page Not Found: Apiv2/verify_user_credentials
INFO - 2025-04-10 09:32:58 --> Config Class Initialized
INFO - 2025-04-10 09:32:58 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:32:58 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:32:58 --> Utf8 Class Initialized
INFO - 2025-04-10 09:32:58 --> URI Class Initialized
INFO - 2025-04-10 09:32:58 --> Router Class Initialized
INFO - 2025-04-10 09:32:58 --> Output Class Initialized
INFO - 2025-04-10 09:32:58 --> Security Class Initialized
DEBUG - 2025-04-10 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:32:58 --> Input Class Initialized
INFO - 2025-04-10 09:32:58 --> Language Class Initialized
ERROR - 2025-04-10 09:32:58 --> 404 Page Not Found: Apiv2/verify_user_credentials
INFO - 2025-04-10 09:33:59 --> Config Class Initialized
INFO - 2025-04-10 09:33:59 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:33:59 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:33:59 --> Utf8 Class Initialized
INFO - 2025-04-10 09:33:59 --> URI Class Initialized
INFO - 2025-04-10 09:33:59 --> Router Class Initialized
INFO - 2025-04-10 09:33:59 --> Output Class Initialized
INFO - 2025-04-10 09:33:59 --> Security Class Initialized
DEBUG - 2025-04-10 09:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:33:59 --> Input Class Initialized
INFO - 2025-04-10 09:33:59 --> Language Class Initialized
INFO - 2025-04-10 09:33:59 --> Language Class Initialized
INFO - 2025-04-10 09:33:59 --> Config Class Initialized
INFO - 2025-04-10 09:33:59 --> Loader Class Initialized
INFO - 2025-04-10 09:33:59 --> Helper loaded: url_helper
INFO - 2025-04-10 09:33:59 --> Helper loaded: file_helper
INFO - 2025-04-10 09:33:59 --> Helper loaded: html_helper
INFO - 2025-04-10 09:33:59 --> Helper loaded: form_helper
INFO - 2025-04-10 09:33:59 --> Helper loaded: text_helper
INFO - 2025-04-10 09:33:59 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:33:59 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:33:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:33:59 --> Database Driver Class Initialized
INFO - 2025-04-10 09:33:59 --> Email Class Initialized
INFO - 2025-04-10 09:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:33:59 --> Form Validation Class Initialized
INFO - 2025-04-10 09:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:33:59 --> Pagination Class Initialized
INFO - 2025-04-10 09:33:59 --> Controller Class Initialized
INFO - 2025-04-10 09:33:59 --> Model Class Initialized
INFO - 2025-04-10 09:33:59 --> Helper loaded: security_helper
INFO - 2025-04-10 09:33:59 --> Final output sent to browser
DEBUG - 2025-04-10 09:33:59 --> Total execution time: 0.0096
INFO - 2025-04-10 09:36:51 --> Config Class Initialized
INFO - 2025-04-10 09:36:51 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:36:51 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:36:51 --> Utf8 Class Initialized
INFO - 2025-04-10 09:36:51 --> URI Class Initialized
INFO - 2025-04-10 09:36:51 --> Router Class Initialized
INFO - 2025-04-10 09:36:51 --> Output Class Initialized
INFO - 2025-04-10 09:36:51 --> Security Class Initialized
DEBUG - 2025-04-10 09:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:36:51 --> Input Class Initialized
INFO - 2025-04-10 09:36:51 --> Language Class Initialized
INFO - 2025-04-10 09:36:51 --> Language Class Initialized
INFO - 2025-04-10 09:36:51 --> Config Class Initialized
INFO - 2025-04-10 09:36:51 --> Loader Class Initialized
INFO - 2025-04-10 09:36:51 --> Helper loaded: url_helper
INFO - 2025-04-10 09:36:51 --> Helper loaded: file_helper
INFO - 2025-04-10 09:36:51 --> Helper loaded: html_helper
INFO - 2025-04-10 09:36:51 --> Helper loaded: form_helper
INFO - 2025-04-10 09:36:51 --> Helper loaded: text_helper
INFO - 2025-04-10 09:36:51 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:36:51 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:36:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:36:51 --> Database Driver Class Initialized
INFO - 2025-04-10 09:36:51 --> Email Class Initialized
INFO - 2025-04-10 09:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:36:51 --> Form Validation Class Initialized
INFO - 2025-04-10 09:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:36:51 --> Pagination Class Initialized
INFO - 2025-04-10 09:36:51 --> Controller Class Initialized
INFO - 2025-04-10 09:36:51 --> Model Class Initialized
INFO - 2025-04-10 09:36:51 --> Helper loaded: security_helper
INFO - 2025-04-10 09:36:51 --> Final output sent to browser
DEBUG - 2025-04-10 09:36:51 --> Total execution time: 0.0067
INFO - 2025-04-10 09:37:57 --> Config Class Initialized
INFO - 2025-04-10 09:37:57 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:37:57 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:37:57 --> Utf8 Class Initialized
INFO - 2025-04-10 09:37:57 --> URI Class Initialized
INFO - 2025-04-10 09:37:57 --> Router Class Initialized
INFO - 2025-04-10 09:37:57 --> Output Class Initialized
INFO - 2025-04-10 09:37:57 --> Security Class Initialized
DEBUG - 2025-04-10 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:37:57 --> Input Class Initialized
INFO - 2025-04-10 09:37:57 --> Language Class Initialized
INFO - 2025-04-10 09:37:57 --> Language Class Initialized
INFO - 2025-04-10 09:37:57 --> Config Class Initialized
INFO - 2025-04-10 09:37:57 --> Loader Class Initialized
INFO - 2025-04-10 09:37:57 --> Helper loaded: url_helper
INFO - 2025-04-10 09:37:57 --> Helper loaded: file_helper
INFO - 2025-04-10 09:37:57 --> Helper loaded: html_helper
INFO - 2025-04-10 09:37:57 --> Helper loaded: form_helper
INFO - 2025-04-10 09:37:57 --> Helper loaded: text_helper
INFO - 2025-04-10 09:37:57 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:37:57 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:37:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:37:57 --> Database Driver Class Initialized
INFO - 2025-04-10 09:37:57 --> Email Class Initialized
INFO - 2025-04-10 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:37:57 --> Form Validation Class Initialized
INFO - 2025-04-10 09:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:37:57 --> Pagination Class Initialized
INFO - 2025-04-10 09:37:57 --> Controller Class Initialized
INFO - 2025-04-10 09:37:57 --> Model Class Initialized
INFO - 2025-04-10 09:37:57 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:37:57 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:38:25 --> Config Class Initialized
INFO - 2025-04-10 09:38:25 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:38:25 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:38:25 --> Utf8 Class Initialized
INFO - 2025-04-10 09:38:25 --> URI Class Initialized
INFO - 2025-04-10 09:38:25 --> Router Class Initialized
INFO - 2025-04-10 09:38:25 --> Output Class Initialized
INFO - 2025-04-10 09:38:25 --> Security Class Initialized
DEBUG - 2025-04-10 09:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:38:25 --> Input Class Initialized
INFO - 2025-04-10 09:38:25 --> Language Class Initialized
INFO - 2025-04-10 09:38:25 --> Language Class Initialized
INFO - 2025-04-10 09:38:25 --> Config Class Initialized
INFO - 2025-04-10 09:38:25 --> Loader Class Initialized
INFO - 2025-04-10 09:38:25 --> Helper loaded: url_helper
INFO - 2025-04-10 09:38:25 --> Helper loaded: file_helper
INFO - 2025-04-10 09:38:25 --> Helper loaded: html_helper
INFO - 2025-04-10 09:38:25 --> Helper loaded: form_helper
INFO - 2025-04-10 09:38:25 --> Helper loaded: text_helper
INFO - 2025-04-10 09:38:25 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:38:25 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:38:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:38:25 --> Database Driver Class Initialized
INFO - 2025-04-10 09:38:25 --> Email Class Initialized
INFO - 2025-04-10 09:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:38:25 --> Form Validation Class Initialized
INFO - 2025-04-10 09:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:38:25 --> Pagination Class Initialized
INFO - 2025-04-10 09:38:25 --> Controller Class Initialized
INFO - 2025-04-10 09:38:25 --> Model Class Initialized
INFO - 2025-04-10 09:38:25 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:38:25 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:38:28 --> Config Class Initialized
INFO - 2025-04-10 09:38:28 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:38:28 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:38:28 --> Utf8 Class Initialized
INFO - 2025-04-10 09:38:28 --> URI Class Initialized
INFO - 2025-04-10 09:38:28 --> Router Class Initialized
INFO - 2025-04-10 09:38:28 --> Output Class Initialized
INFO - 2025-04-10 09:38:28 --> Security Class Initialized
DEBUG - 2025-04-10 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:38:28 --> Input Class Initialized
INFO - 2025-04-10 09:38:28 --> Language Class Initialized
INFO - 2025-04-10 09:38:28 --> Language Class Initialized
INFO - 2025-04-10 09:38:28 --> Config Class Initialized
INFO - 2025-04-10 09:38:28 --> Loader Class Initialized
INFO - 2025-04-10 09:38:28 --> Helper loaded: url_helper
INFO - 2025-04-10 09:38:28 --> Helper loaded: file_helper
INFO - 2025-04-10 09:38:28 --> Helper loaded: html_helper
INFO - 2025-04-10 09:38:28 --> Helper loaded: form_helper
INFO - 2025-04-10 09:38:28 --> Helper loaded: text_helper
INFO - 2025-04-10 09:38:28 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:38:28 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:38:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:38:28 --> Database Driver Class Initialized
INFO - 2025-04-10 09:38:28 --> Email Class Initialized
INFO - 2025-04-10 09:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:38:28 --> Form Validation Class Initialized
INFO - 2025-04-10 09:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:38:28 --> Pagination Class Initialized
INFO - 2025-04-10 09:38:28 --> Controller Class Initialized
INFO - 2025-04-10 09:38:28 --> Model Class Initialized
INFO - 2025-04-10 09:38:28 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:38:28 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:40:06 --> Config Class Initialized
INFO - 2025-04-10 09:40:06 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:40:06 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:40:06 --> Utf8 Class Initialized
INFO - 2025-04-10 09:40:06 --> URI Class Initialized
INFO - 2025-04-10 09:40:06 --> Router Class Initialized
INFO - 2025-04-10 09:40:06 --> Output Class Initialized
INFO - 2025-04-10 09:40:06 --> Security Class Initialized
DEBUG - 2025-04-10 09:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:40:06 --> Input Class Initialized
INFO - 2025-04-10 09:40:06 --> Language Class Initialized
INFO - 2025-04-10 09:40:06 --> Language Class Initialized
INFO - 2025-04-10 09:40:06 --> Config Class Initialized
INFO - 2025-04-10 09:40:06 --> Loader Class Initialized
INFO - 2025-04-10 09:40:06 --> Helper loaded: url_helper
INFO - 2025-04-10 09:40:06 --> Helper loaded: file_helper
INFO - 2025-04-10 09:40:06 --> Helper loaded: html_helper
INFO - 2025-04-10 09:40:06 --> Helper loaded: form_helper
INFO - 2025-04-10 09:40:06 --> Helper loaded: text_helper
INFO - 2025-04-10 09:40:06 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:40:06 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:40:06 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:40:06 --> Database Driver Class Initialized
INFO - 2025-04-10 09:40:06 --> Email Class Initialized
INFO - 2025-04-10 09:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:40:06 --> Form Validation Class Initialized
INFO - 2025-04-10 09:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:40:06 --> Pagination Class Initialized
INFO - 2025-04-10 09:40:06 --> Controller Class Initialized
INFO - 2025-04-10 09:40:06 --> Model Class Initialized
INFO - 2025-04-10 09:40:06 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:40:06 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:40:11 --> Config Class Initialized
INFO - 2025-04-10 09:40:11 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:40:11 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:40:11 --> Utf8 Class Initialized
INFO - 2025-04-10 09:40:11 --> URI Class Initialized
INFO - 2025-04-10 09:40:11 --> Router Class Initialized
INFO - 2025-04-10 09:40:11 --> Output Class Initialized
INFO - 2025-04-10 09:40:11 --> Security Class Initialized
DEBUG - 2025-04-10 09:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:40:11 --> Input Class Initialized
INFO - 2025-04-10 09:40:11 --> Language Class Initialized
INFO - 2025-04-10 09:40:11 --> Language Class Initialized
INFO - 2025-04-10 09:40:11 --> Config Class Initialized
INFO - 2025-04-10 09:40:11 --> Loader Class Initialized
INFO - 2025-04-10 09:40:11 --> Helper loaded: url_helper
INFO - 2025-04-10 09:40:11 --> Helper loaded: file_helper
INFO - 2025-04-10 09:40:11 --> Helper loaded: html_helper
INFO - 2025-04-10 09:40:11 --> Helper loaded: form_helper
INFO - 2025-04-10 09:40:11 --> Helper loaded: text_helper
INFO - 2025-04-10 09:40:11 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:40:11 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:40:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:40:11 --> Database Driver Class Initialized
INFO - 2025-04-10 09:40:11 --> Email Class Initialized
INFO - 2025-04-10 09:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:40:11 --> Form Validation Class Initialized
INFO - 2025-04-10 09:40:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:40:11 --> Pagination Class Initialized
INFO - 2025-04-10 09:40:11 --> Controller Class Initialized
INFO - 2025-04-10 09:40:11 --> Model Class Initialized
INFO - 2025-04-10 09:40:11 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:40:11 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:41:32 --> Config Class Initialized
INFO - 2025-04-10 09:41:32 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:41:32 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:41:32 --> Utf8 Class Initialized
INFO - 2025-04-10 09:41:32 --> URI Class Initialized
INFO - 2025-04-10 09:41:32 --> Router Class Initialized
INFO - 2025-04-10 09:41:32 --> Output Class Initialized
INFO - 2025-04-10 09:41:32 --> Security Class Initialized
DEBUG - 2025-04-10 09:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:41:32 --> Input Class Initialized
INFO - 2025-04-10 09:41:32 --> Language Class Initialized
INFO - 2025-04-10 09:41:32 --> Language Class Initialized
INFO - 2025-04-10 09:41:32 --> Config Class Initialized
INFO - 2025-04-10 09:41:32 --> Loader Class Initialized
INFO - 2025-04-10 09:41:32 --> Helper loaded: url_helper
INFO - 2025-04-10 09:41:32 --> Helper loaded: file_helper
INFO - 2025-04-10 09:41:32 --> Helper loaded: html_helper
INFO - 2025-04-10 09:41:32 --> Helper loaded: form_helper
INFO - 2025-04-10 09:41:32 --> Helper loaded: text_helper
INFO - 2025-04-10 09:41:32 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:41:32 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:41:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:41:32 --> Database Driver Class Initialized
INFO - 2025-04-10 09:41:32 --> Email Class Initialized
INFO - 2025-04-10 09:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:41:32 --> Form Validation Class Initialized
INFO - 2025-04-10 09:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:41:32 --> Pagination Class Initialized
INFO - 2025-04-10 09:41:32 --> Controller Class Initialized
INFO - 2025-04-10 09:41:32 --> Model Class Initialized
INFO - 2025-04-10 09:41:32 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:41:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:42:23 --> Config Class Initialized
INFO - 2025-04-10 09:42:23 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:42:23 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:42:23 --> Utf8 Class Initialized
INFO - 2025-04-10 09:42:23 --> URI Class Initialized
INFO - 2025-04-10 09:42:23 --> Router Class Initialized
INFO - 2025-04-10 09:42:23 --> Output Class Initialized
INFO - 2025-04-10 09:42:23 --> Security Class Initialized
DEBUG - 2025-04-10 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:42:23 --> Input Class Initialized
INFO - 2025-04-10 09:42:23 --> Language Class Initialized
INFO - 2025-04-10 09:42:23 --> Language Class Initialized
INFO - 2025-04-10 09:42:23 --> Config Class Initialized
INFO - 2025-04-10 09:42:23 --> Loader Class Initialized
INFO - 2025-04-10 09:42:23 --> Helper loaded: url_helper
INFO - 2025-04-10 09:42:23 --> Helper loaded: file_helper
INFO - 2025-04-10 09:42:23 --> Helper loaded: html_helper
INFO - 2025-04-10 09:42:23 --> Helper loaded: form_helper
INFO - 2025-04-10 09:42:23 --> Helper loaded: text_helper
INFO - 2025-04-10 09:42:23 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:42:23 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:42:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:42:23 --> Database Driver Class Initialized
INFO - 2025-04-10 09:42:23 --> Email Class Initialized
INFO - 2025-04-10 09:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:42:23 --> Form Validation Class Initialized
INFO - 2025-04-10 09:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:42:23 --> Pagination Class Initialized
INFO - 2025-04-10 09:42:23 --> Controller Class Initialized
INFO - 2025-04-10 09:42:23 --> Model Class Initialized
INFO - 2025-04-10 09:42:23 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:42:23 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::table() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1574
INFO - 2025-04-10 09:44:16 --> Config Class Initialized
INFO - 2025-04-10 09:44:16 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:44:16 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:44:16 --> Utf8 Class Initialized
INFO - 2025-04-10 09:44:16 --> URI Class Initialized
INFO - 2025-04-10 09:44:16 --> Router Class Initialized
INFO - 2025-04-10 09:44:16 --> Output Class Initialized
INFO - 2025-04-10 09:44:16 --> Security Class Initialized
DEBUG - 2025-04-10 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:44:16 --> Input Class Initialized
INFO - 2025-04-10 09:44:16 --> Language Class Initialized
INFO - 2025-04-10 09:44:16 --> Language Class Initialized
INFO - 2025-04-10 09:44:16 --> Config Class Initialized
INFO - 2025-04-10 09:44:16 --> Loader Class Initialized
INFO - 2025-04-10 09:44:16 --> Helper loaded: url_helper
INFO - 2025-04-10 09:44:16 --> Helper loaded: file_helper
INFO - 2025-04-10 09:44:16 --> Helper loaded: html_helper
INFO - 2025-04-10 09:44:16 --> Helper loaded: form_helper
INFO - 2025-04-10 09:44:16 --> Helper loaded: text_helper
INFO - 2025-04-10 09:44:16 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:44:16 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:44:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:44:16 --> Database Driver Class Initialized
INFO - 2025-04-10 09:44:16 --> Email Class Initialized
INFO - 2025-04-10 09:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:44:16 --> Form Validation Class Initialized
INFO - 2025-04-10 09:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:44:16 --> Pagination Class Initialized
INFO - 2025-04-10 09:44:16 --> Controller Class Initialized
INFO - 2025-04-10 09:44:16 --> Model Class Initialized
INFO - 2025-04-10 09:44:16 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:44:16 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::getRowArray() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1577
INFO - 2025-04-10 09:44:21 --> Config Class Initialized
INFO - 2025-04-10 09:44:21 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:44:21 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:44:21 --> Utf8 Class Initialized
INFO - 2025-04-10 09:44:21 --> URI Class Initialized
INFO - 2025-04-10 09:44:21 --> Router Class Initialized
INFO - 2025-04-10 09:44:21 --> Output Class Initialized
INFO - 2025-04-10 09:44:21 --> Security Class Initialized
DEBUG - 2025-04-10 09:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:44:21 --> Input Class Initialized
INFO - 2025-04-10 09:44:21 --> Language Class Initialized
INFO - 2025-04-10 09:44:21 --> Language Class Initialized
INFO - 2025-04-10 09:44:21 --> Config Class Initialized
INFO - 2025-04-10 09:44:21 --> Loader Class Initialized
INFO - 2025-04-10 09:44:21 --> Helper loaded: url_helper
INFO - 2025-04-10 09:44:21 --> Helper loaded: file_helper
INFO - 2025-04-10 09:44:21 --> Helper loaded: html_helper
INFO - 2025-04-10 09:44:21 --> Helper loaded: form_helper
INFO - 2025-04-10 09:44:21 --> Helper loaded: text_helper
INFO - 2025-04-10 09:44:21 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:44:21 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:44:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:44:21 --> Database Driver Class Initialized
INFO - 2025-04-10 09:44:21 --> Email Class Initialized
INFO - 2025-04-10 09:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:44:21 --> Form Validation Class Initialized
INFO - 2025-04-10 09:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:44:21 --> Pagination Class Initialized
INFO - 2025-04-10 09:44:21 --> Controller Class Initialized
INFO - 2025-04-10 09:44:21 --> Model Class Initialized
INFO - 2025-04-10 09:44:21 --> Helper loaded: security_helper
ERROR - 2025-04-10 09:44:21 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::getRowArray() /Users/faiz.shiraji/Sites/GenITech_B2B/application/models/Api_model.php 1577
INFO - 2025-04-10 09:45:21 --> Config Class Initialized
INFO - 2025-04-10 09:45:21 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:45:21 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:45:21 --> Utf8 Class Initialized
INFO - 2025-04-10 09:45:21 --> URI Class Initialized
INFO - 2025-04-10 09:45:21 --> Router Class Initialized
INFO - 2025-04-10 09:45:21 --> Output Class Initialized
INFO - 2025-04-10 09:45:21 --> Security Class Initialized
DEBUG - 2025-04-10 09:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:45:21 --> Input Class Initialized
INFO - 2025-04-10 09:45:21 --> Language Class Initialized
INFO - 2025-04-10 09:45:21 --> Language Class Initialized
INFO - 2025-04-10 09:45:21 --> Config Class Initialized
INFO - 2025-04-10 09:45:21 --> Loader Class Initialized
INFO - 2025-04-10 09:45:21 --> Helper loaded: url_helper
INFO - 2025-04-10 09:45:21 --> Helper loaded: file_helper
INFO - 2025-04-10 09:45:21 --> Helper loaded: html_helper
INFO - 2025-04-10 09:45:21 --> Helper loaded: form_helper
INFO - 2025-04-10 09:45:21 --> Helper loaded: text_helper
INFO - 2025-04-10 09:45:21 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:45:21 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:45:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:45:21 --> Database Driver Class Initialized
INFO - 2025-04-10 09:45:21 --> Email Class Initialized
INFO - 2025-04-10 09:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:45:21 --> Form Validation Class Initialized
INFO - 2025-04-10 09:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:45:21 --> Pagination Class Initialized
INFO - 2025-04-10 09:45:21 --> Controller Class Initialized
INFO - 2025-04-10 09:45:21 --> Model Class Initialized
INFO - 2025-04-10 09:45:21 --> Helper loaded: security_helper
INFO - 2025-04-10 09:45:21 --> Final output sent to browser
DEBUG - 2025-04-10 09:45:21 --> Total execution time: 0.0773
INFO - 2025-04-10 09:45:31 --> Config Class Initialized
INFO - 2025-04-10 09:45:31 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:45:31 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:45:31 --> Utf8 Class Initialized
INFO - 2025-04-10 09:45:31 --> URI Class Initialized
INFO - 2025-04-10 09:45:31 --> Router Class Initialized
INFO - 2025-04-10 09:45:31 --> Output Class Initialized
INFO - 2025-04-10 09:45:31 --> Security Class Initialized
DEBUG - 2025-04-10 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:45:31 --> Input Class Initialized
INFO - 2025-04-10 09:45:31 --> Language Class Initialized
INFO - 2025-04-10 09:45:31 --> Language Class Initialized
INFO - 2025-04-10 09:45:31 --> Config Class Initialized
INFO - 2025-04-10 09:45:31 --> Loader Class Initialized
INFO - 2025-04-10 09:45:31 --> Helper loaded: url_helper
INFO - 2025-04-10 09:45:31 --> Helper loaded: file_helper
INFO - 2025-04-10 09:45:31 --> Helper loaded: html_helper
INFO - 2025-04-10 09:45:31 --> Helper loaded: form_helper
INFO - 2025-04-10 09:45:31 --> Helper loaded: text_helper
INFO - 2025-04-10 09:45:31 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:45:31 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:45:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:45:31 --> Database Driver Class Initialized
INFO - 2025-04-10 09:45:31 --> Email Class Initialized
INFO - 2025-04-10 09:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:45:31 --> Form Validation Class Initialized
INFO - 2025-04-10 09:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:45:31 --> Pagination Class Initialized
INFO - 2025-04-10 09:45:31 --> Controller Class Initialized
INFO - 2025-04-10 09:45:31 --> Model Class Initialized
INFO - 2025-04-10 09:45:31 --> Helper loaded: security_helper
INFO - 2025-04-10 09:45:31 --> Final output sent to browser
DEBUG - 2025-04-10 09:45:31 --> Total execution time: 0.0727
INFO - 2025-04-10 09:45:37 --> Config Class Initialized
INFO - 2025-04-10 09:45:37 --> Hooks Class Initialized
DEBUG - 2025-04-10 09:45:37 --> UTF-8 Support Enabled
INFO - 2025-04-10 09:45:37 --> Utf8 Class Initialized
INFO - 2025-04-10 09:45:37 --> URI Class Initialized
INFO - 2025-04-10 09:45:37 --> Router Class Initialized
INFO - 2025-04-10 09:45:37 --> Output Class Initialized
INFO - 2025-04-10 09:45:37 --> Security Class Initialized
DEBUG - 2025-04-10 09:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 09:45:37 --> Input Class Initialized
INFO - 2025-04-10 09:45:37 --> Language Class Initialized
INFO - 2025-04-10 09:45:37 --> Language Class Initialized
INFO - 2025-04-10 09:45:37 --> Config Class Initialized
INFO - 2025-04-10 09:45:37 --> Loader Class Initialized
INFO - 2025-04-10 09:45:37 --> Helper loaded: url_helper
INFO - 2025-04-10 09:45:37 --> Helper loaded: file_helper
INFO - 2025-04-10 09:45:37 --> Helper loaded: html_helper
INFO - 2025-04-10 09:45:37 --> Helper loaded: form_helper
INFO - 2025-04-10 09:45:37 --> Helper loaded: text_helper
INFO - 2025-04-10 09:45:37 --> Helper loaded: lang_helper
INFO - 2025-04-10 09:45:37 --> Helper loaded: directory_helper
INFO - 2025-04-10 09:45:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 09:45:37 --> Database Driver Class Initialized
INFO - 2025-04-10 09:45:37 --> Email Class Initialized
INFO - 2025-04-10 09:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 09:45:37 --> Form Validation Class Initialized
INFO - 2025-04-10 09:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 09:45:37 --> Pagination Class Initialized
INFO - 2025-04-10 09:45:37 --> Controller Class Initialized
INFO - 2025-04-10 09:45:37 --> Model Class Initialized
INFO - 2025-04-10 09:45:37 --> Helper loaded: security_helper
INFO - 2025-04-10 09:45:37 --> Final output sent to browser
DEBUG - 2025-04-10 09:45:37 --> Total execution time: 0.0768
INFO - 2025-04-10 10:15:28 --> Config Class Initialized
INFO - 2025-04-10 10:15:28 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:15:28 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:15:28 --> Utf8 Class Initialized
INFO - 2025-04-10 10:15:28 --> URI Class Initialized
INFO - 2025-04-10 10:15:28 --> Router Class Initialized
INFO - 2025-04-10 10:15:28 --> Output Class Initialized
INFO - 2025-04-10 10:15:28 --> Security Class Initialized
DEBUG - 2025-04-10 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:15:28 --> Input Class Initialized
INFO - 2025-04-10 10:15:28 --> Language Class Initialized
INFO - 2025-04-10 10:15:28 --> Language Class Initialized
INFO - 2025-04-10 10:15:28 --> Config Class Initialized
INFO - 2025-04-10 10:15:28 --> Loader Class Initialized
INFO - 2025-04-10 10:15:28 --> Helper loaded: url_helper
INFO - 2025-04-10 10:15:28 --> Helper loaded: file_helper
INFO - 2025-04-10 10:15:28 --> Helper loaded: html_helper
INFO - 2025-04-10 10:15:28 --> Helper loaded: form_helper
INFO - 2025-04-10 10:15:28 --> Helper loaded: text_helper
INFO - 2025-04-10 10:15:28 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:15:28 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:15:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:15:28 --> Database Driver Class Initialized
INFO - 2025-04-10 10:15:28 --> Email Class Initialized
INFO - 2025-04-10 10:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:15:28 --> Form Validation Class Initialized
INFO - 2025-04-10 10:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:15:28 --> Pagination Class Initialized
INFO - 2025-04-10 10:15:28 --> Controller Class Initialized
INFO - 2025-04-10 10:15:28 --> Model Class Initialized
INFO - 2025-04-10 10:15:28 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:15:28 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:15:28 --> Final output sent to browser
DEBUG - 2025-04-10 10:15:28 --> Total execution time: 0.0831
INFO - 2025-04-10 10:36:08 --> Config Class Initialized
INFO - 2025-04-10 10:36:08 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:36:08 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:36:08 --> Utf8 Class Initialized
INFO - 2025-04-10 10:36:08 --> URI Class Initialized
INFO - 2025-04-10 10:36:08 --> Router Class Initialized
INFO - 2025-04-10 10:36:08 --> Output Class Initialized
INFO - 2025-04-10 10:36:08 --> Security Class Initialized
DEBUG - 2025-04-10 10:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:36:08 --> Input Class Initialized
INFO - 2025-04-10 10:36:08 --> Language Class Initialized
INFO - 2025-04-10 10:36:08 --> Language Class Initialized
INFO - 2025-04-10 10:36:08 --> Config Class Initialized
INFO - 2025-04-10 10:36:08 --> Loader Class Initialized
INFO - 2025-04-10 10:36:08 --> Helper loaded: url_helper
INFO - 2025-04-10 10:36:08 --> Helper loaded: file_helper
INFO - 2025-04-10 10:36:08 --> Helper loaded: html_helper
INFO - 2025-04-10 10:36:08 --> Helper loaded: form_helper
INFO - 2025-04-10 10:36:08 --> Helper loaded: text_helper
INFO - 2025-04-10 10:36:08 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:36:08 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:36:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:36:08 --> Database Driver Class Initialized
INFO - 2025-04-10 10:36:08 --> Email Class Initialized
INFO - 2025-04-10 10:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:36:08 --> Form Validation Class Initialized
INFO - 2025-04-10 10:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:36:08 --> Pagination Class Initialized
INFO - 2025-04-10 10:36:08 --> Controller Class Initialized
INFO - 2025-04-10 10:36:08 --> Model Class Initialized
INFO - 2025-04-10 10:36:08 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:36:08 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:36:08 --> Final output sent to browser
DEBUG - 2025-04-10 10:36:08 --> Total execution time: 0.0812
INFO - 2025-04-10 10:50:40 --> Config Class Initialized
INFO - 2025-04-10 10:50:40 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:50:40 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:50:40 --> Utf8 Class Initialized
INFO - 2025-04-10 10:50:40 --> URI Class Initialized
INFO - 2025-04-10 10:50:40 --> Router Class Initialized
INFO - 2025-04-10 10:50:40 --> Output Class Initialized
INFO - 2025-04-10 10:50:40 --> Security Class Initialized
DEBUG - 2025-04-10 10:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:50:40 --> Input Class Initialized
INFO - 2025-04-10 10:50:40 --> Language Class Initialized
INFO - 2025-04-10 10:50:40 --> Language Class Initialized
INFO - 2025-04-10 10:50:40 --> Config Class Initialized
INFO - 2025-04-10 10:50:40 --> Loader Class Initialized
INFO - 2025-04-10 10:50:40 --> Helper loaded: url_helper
INFO - 2025-04-10 10:50:40 --> Helper loaded: file_helper
INFO - 2025-04-10 10:50:40 --> Helper loaded: html_helper
INFO - 2025-04-10 10:50:40 --> Helper loaded: form_helper
INFO - 2025-04-10 10:50:40 --> Helper loaded: text_helper
INFO - 2025-04-10 10:50:40 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:50:40 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:50:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:50:40 --> Database Driver Class Initialized
INFO - 2025-04-10 10:50:40 --> Email Class Initialized
INFO - 2025-04-10 10:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:50:40 --> Form Validation Class Initialized
INFO - 2025-04-10 10:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:50:40 --> Pagination Class Initialized
INFO - 2025-04-10 10:50:40 --> Controller Class Initialized
INFO - 2025-04-10 10:50:40 --> Model Class Initialized
INFO - 2025-04-10 10:50:40 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:50:40 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 10:50:40 --> Severity: Warning --> Undefined property: Apiv2::$ciqrcode /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
ERROR - 2025-04-10 10:50:40 --> Severity: error --> Exception: Call to a member function initialize() on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
INFO - 2025-04-10 10:50:48 --> Config Class Initialized
INFO - 2025-04-10 10:50:48 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:50:48 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:50:48 --> Utf8 Class Initialized
INFO - 2025-04-10 10:50:48 --> URI Class Initialized
INFO - 2025-04-10 10:50:48 --> Router Class Initialized
INFO - 2025-04-10 10:50:48 --> Output Class Initialized
INFO - 2025-04-10 10:50:48 --> Security Class Initialized
DEBUG - 2025-04-10 10:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:50:48 --> Input Class Initialized
INFO - 2025-04-10 10:50:48 --> Language Class Initialized
INFO - 2025-04-10 10:50:48 --> Language Class Initialized
INFO - 2025-04-10 10:50:48 --> Config Class Initialized
INFO - 2025-04-10 10:50:48 --> Loader Class Initialized
INFO - 2025-04-10 10:50:48 --> Helper loaded: url_helper
INFO - 2025-04-10 10:50:48 --> Helper loaded: file_helper
INFO - 2025-04-10 10:50:48 --> Helper loaded: html_helper
INFO - 2025-04-10 10:50:48 --> Helper loaded: form_helper
INFO - 2025-04-10 10:50:48 --> Helper loaded: text_helper
INFO - 2025-04-10 10:50:48 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:50:48 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:50:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:50:48 --> Database Driver Class Initialized
INFO - 2025-04-10 10:50:48 --> Email Class Initialized
INFO - 2025-04-10 10:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:50:48 --> Form Validation Class Initialized
INFO - 2025-04-10 10:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:50:48 --> Pagination Class Initialized
INFO - 2025-04-10 10:50:48 --> Controller Class Initialized
INFO - 2025-04-10 10:50:48 --> Model Class Initialized
INFO - 2025-04-10 10:50:48 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:50:48 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:50:48 --> Final output sent to browser
DEBUG - 2025-04-10 10:50:48 --> Total execution time: 0.0729
INFO - 2025-04-10 10:51:47 --> Config Class Initialized
INFO - 2025-04-10 10:51:47 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:51:47 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:51:47 --> Utf8 Class Initialized
INFO - 2025-04-10 10:51:47 --> URI Class Initialized
INFO - 2025-04-10 10:51:47 --> Router Class Initialized
INFO - 2025-04-10 10:51:47 --> Output Class Initialized
INFO - 2025-04-10 10:51:47 --> Security Class Initialized
DEBUG - 2025-04-10 10:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:51:47 --> Input Class Initialized
INFO - 2025-04-10 10:51:47 --> Language Class Initialized
INFO - 2025-04-10 10:51:47 --> Language Class Initialized
INFO - 2025-04-10 10:51:47 --> Config Class Initialized
INFO - 2025-04-10 10:51:47 --> Loader Class Initialized
INFO - 2025-04-10 10:51:47 --> Helper loaded: url_helper
INFO - 2025-04-10 10:51:47 --> Helper loaded: file_helper
INFO - 2025-04-10 10:51:47 --> Helper loaded: html_helper
INFO - 2025-04-10 10:51:47 --> Helper loaded: form_helper
INFO - 2025-04-10 10:51:47 --> Helper loaded: text_helper
INFO - 2025-04-10 10:51:47 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:51:47 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:51:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:51:47 --> Database Driver Class Initialized
INFO - 2025-04-10 10:51:47 --> Email Class Initialized
INFO - 2025-04-10 10:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:51:47 --> Form Validation Class Initialized
INFO - 2025-04-10 10:51:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:51:47 --> Pagination Class Initialized
INFO - 2025-04-10 10:51:47 --> Controller Class Initialized
INFO - 2025-04-10 10:51:47 --> Model Class Initialized
INFO - 2025-04-10 10:51:47 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:51:47 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 10:51:47 --> Severity: Warning --> Undefined property: Apiv2::$ciqrcode /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
ERROR - 2025-04-10 10:51:47 --> Severity: error --> Exception: Call to a member function initialize() on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
INFO - 2025-04-10 10:52:02 --> Config Class Initialized
INFO - 2025-04-10 10:52:02 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:52:02 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:52:02 --> Utf8 Class Initialized
INFO - 2025-04-10 10:52:02 --> URI Class Initialized
INFO - 2025-04-10 10:52:02 --> Router Class Initialized
INFO - 2025-04-10 10:52:02 --> Output Class Initialized
INFO - 2025-04-10 10:52:02 --> Security Class Initialized
DEBUG - 2025-04-10 10:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:52:02 --> Input Class Initialized
INFO - 2025-04-10 10:52:02 --> Language Class Initialized
INFO - 2025-04-10 10:52:02 --> Language Class Initialized
INFO - 2025-04-10 10:52:02 --> Config Class Initialized
INFO - 2025-04-10 10:52:02 --> Loader Class Initialized
INFO - 2025-04-10 10:52:02 --> Helper loaded: url_helper
INFO - 2025-04-10 10:52:02 --> Helper loaded: file_helper
INFO - 2025-04-10 10:52:02 --> Helper loaded: html_helper
INFO - 2025-04-10 10:52:02 --> Helper loaded: form_helper
INFO - 2025-04-10 10:52:02 --> Helper loaded: text_helper
INFO - 2025-04-10 10:52:02 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:52:02 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:52:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:52:02 --> Database Driver Class Initialized
INFO - 2025-04-10 10:52:02 --> Email Class Initialized
INFO - 2025-04-10 10:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:52:02 --> Form Validation Class Initialized
INFO - 2025-04-10 10:52:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:52:02 --> Pagination Class Initialized
INFO - 2025-04-10 10:52:02 --> Controller Class Initialized
INFO - 2025-04-10 10:52:02 --> Model Class Initialized
INFO - 2025-04-10 10:52:02 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:52:02 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 10:52:02 --> Severity: Warning --> Undefined property: Apiv2::$ciqrcode /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
ERROR - 2025-04-10 10:52:02 --> Severity: error --> Exception: Call to a member function initialize() on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
INFO - 2025-04-10 10:52:19 --> Config Class Initialized
INFO - 2025-04-10 10:52:19 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:52:19 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:52:19 --> Utf8 Class Initialized
INFO - 2025-04-10 10:52:19 --> URI Class Initialized
INFO - 2025-04-10 10:52:19 --> Router Class Initialized
INFO - 2025-04-10 10:52:19 --> Output Class Initialized
INFO - 2025-04-10 10:52:19 --> Security Class Initialized
DEBUG - 2025-04-10 10:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:52:19 --> Input Class Initialized
INFO - 2025-04-10 10:52:19 --> Language Class Initialized
INFO - 2025-04-10 10:52:19 --> Language Class Initialized
INFO - 2025-04-10 10:52:19 --> Config Class Initialized
INFO - 2025-04-10 10:52:19 --> Loader Class Initialized
INFO - 2025-04-10 10:52:19 --> Helper loaded: url_helper
INFO - 2025-04-10 10:52:19 --> Helper loaded: file_helper
INFO - 2025-04-10 10:52:19 --> Helper loaded: html_helper
INFO - 2025-04-10 10:52:19 --> Helper loaded: form_helper
INFO - 2025-04-10 10:52:19 --> Helper loaded: text_helper
INFO - 2025-04-10 10:52:19 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:52:19 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:52:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:52:19 --> Database Driver Class Initialized
INFO - 2025-04-10 10:52:19 --> Email Class Initialized
INFO - 2025-04-10 10:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:52:19 --> Form Validation Class Initialized
INFO - 2025-04-10 10:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:52:19 --> Pagination Class Initialized
INFO - 2025-04-10 10:52:19 --> Controller Class Initialized
INFO - 2025-04-10 10:52:19 --> Model Class Initialized
INFO - 2025-04-10 10:52:19 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:52:19 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 10:52:19 --> Severity: Warning --> Undefined property: Apiv2::$ciqrcode /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
ERROR - 2025-04-10 10:52:19 --> Severity: error --> Exception: Call to a member function initialize() on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 442
INFO - 2025-04-10 10:53:56 --> Config Class Initialized
INFO - 2025-04-10 10:53:56 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:53:56 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:53:56 --> Utf8 Class Initialized
INFO - 2025-04-10 10:53:56 --> URI Class Initialized
INFO - 2025-04-10 10:53:56 --> Router Class Initialized
INFO - 2025-04-10 10:53:56 --> Output Class Initialized
INFO - 2025-04-10 10:53:56 --> Security Class Initialized
DEBUG - 2025-04-10 10:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:53:56 --> Input Class Initialized
INFO - 2025-04-10 10:53:56 --> Language Class Initialized
INFO - 2025-04-10 10:53:56 --> Language Class Initialized
INFO - 2025-04-10 10:53:56 --> Config Class Initialized
INFO - 2025-04-10 10:53:56 --> Loader Class Initialized
INFO - 2025-04-10 10:53:56 --> Helper loaded: url_helper
INFO - 2025-04-10 10:53:56 --> Helper loaded: file_helper
INFO - 2025-04-10 10:53:56 --> Helper loaded: html_helper
INFO - 2025-04-10 10:53:56 --> Helper loaded: form_helper
INFO - 2025-04-10 10:53:56 --> Helper loaded: text_helper
INFO - 2025-04-10 10:53:56 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:53:56 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:53:56 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:53:56 --> Database Driver Class Initialized
INFO - 2025-04-10 10:53:56 --> Email Class Initialized
INFO - 2025-04-10 10:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:53:56 --> Form Validation Class Initialized
INFO - 2025-04-10 10:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:53:56 --> Pagination Class Initialized
INFO - 2025-04-10 10:53:56 --> Controller Class Initialized
INFO - 2025-04-10 10:53:56 --> Model Class Initialized
INFO - 2025-04-10 10:53:56 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:53:56 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:53:56 --> Final output sent to browser
DEBUG - 2025-04-10 10:53:56 --> Total execution time: 0.0825
INFO - 2025-04-10 10:59:28 --> Config Class Initialized
INFO - 2025-04-10 10:59:28 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:59:28 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:59:28 --> Utf8 Class Initialized
INFO - 2025-04-10 10:59:28 --> URI Class Initialized
INFO - 2025-04-10 10:59:28 --> Router Class Initialized
INFO - 2025-04-10 10:59:28 --> Output Class Initialized
INFO - 2025-04-10 10:59:28 --> Security Class Initialized
DEBUG - 2025-04-10 10:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:59:28 --> Input Class Initialized
INFO - 2025-04-10 10:59:28 --> Language Class Initialized
INFO - 2025-04-10 10:59:28 --> Language Class Initialized
INFO - 2025-04-10 10:59:28 --> Config Class Initialized
INFO - 2025-04-10 10:59:28 --> Loader Class Initialized
INFO - 2025-04-10 10:59:28 --> Helper loaded: url_helper
INFO - 2025-04-10 10:59:28 --> Helper loaded: file_helper
INFO - 2025-04-10 10:59:28 --> Helper loaded: html_helper
INFO - 2025-04-10 10:59:28 --> Helper loaded: form_helper
INFO - 2025-04-10 10:59:28 --> Helper loaded: text_helper
INFO - 2025-04-10 10:59:28 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:59:28 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:59:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:59:28 --> Database Driver Class Initialized
INFO - 2025-04-10 10:59:28 --> Email Class Initialized
INFO - 2025-04-10 10:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:59:28 --> Form Validation Class Initialized
INFO - 2025-04-10 10:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:59:28 --> Pagination Class Initialized
INFO - 2025-04-10 10:59:28 --> Controller Class Initialized
INFO - 2025-04-10 10:59:28 --> Model Class Initialized
INFO - 2025-04-10 10:59:28 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:59:28 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:59:28 --> Final output sent to browser
DEBUG - 2025-04-10 10:59:28 --> Total execution time: 0.0112
INFO - 2025-04-10 10:59:40 --> Config Class Initialized
INFO - 2025-04-10 10:59:40 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:59:40 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:59:40 --> Utf8 Class Initialized
INFO - 2025-04-10 10:59:40 --> URI Class Initialized
INFO - 2025-04-10 10:59:40 --> Router Class Initialized
INFO - 2025-04-10 10:59:40 --> Output Class Initialized
INFO - 2025-04-10 10:59:40 --> Security Class Initialized
DEBUG - 2025-04-10 10:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:59:40 --> Input Class Initialized
INFO - 2025-04-10 10:59:40 --> Language Class Initialized
INFO - 2025-04-10 10:59:40 --> Language Class Initialized
INFO - 2025-04-10 10:59:40 --> Config Class Initialized
INFO - 2025-04-10 10:59:40 --> Loader Class Initialized
INFO - 2025-04-10 10:59:40 --> Helper loaded: url_helper
INFO - 2025-04-10 10:59:40 --> Helper loaded: file_helper
INFO - 2025-04-10 10:59:40 --> Helper loaded: html_helper
INFO - 2025-04-10 10:59:40 --> Helper loaded: form_helper
INFO - 2025-04-10 10:59:40 --> Helper loaded: text_helper
INFO - 2025-04-10 10:59:40 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:59:40 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:59:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:59:40 --> Database Driver Class Initialized
INFO - 2025-04-10 10:59:40 --> Email Class Initialized
INFO - 2025-04-10 10:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:59:40 --> Form Validation Class Initialized
INFO - 2025-04-10 10:59:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:59:40 --> Pagination Class Initialized
INFO - 2025-04-10 10:59:40 --> Controller Class Initialized
INFO - 2025-04-10 10:59:40 --> Model Class Initialized
INFO - 2025-04-10 10:59:40 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:59:40 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:59:40 --> Final output sent to browser
DEBUG - 2025-04-10 10:59:40 --> Total execution time: 0.0079
INFO - 2025-04-10 10:59:49 --> Config Class Initialized
INFO - 2025-04-10 10:59:49 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:59:49 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:59:49 --> Utf8 Class Initialized
INFO - 2025-04-10 10:59:49 --> URI Class Initialized
INFO - 2025-04-10 10:59:49 --> Router Class Initialized
INFO - 2025-04-10 10:59:49 --> Output Class Initialized
INFO - 2025-04-10 10:59:49 --> Security Class Initialized
DEBUG - 2025-04-10 10:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:59:49 --> Input Class Initialized
INFO - 2025-04-10 10:59:49 --> Language Class Initialized
INFO - 2025-04-10 10:59:49 --> Language Class Initialized
INFO - 2025-04-10 10:59:49 --> Config Class Initialized
INFO - 2025-04-10 10:59:49 --> Loader Class Initialized
INFO - 2025-04-10 10:59:49 --> Helper loaded: url_helper
INFO - 2025-04-10 10:59:49 --> Helper loaded: file_helper
INFO - 2025-04-10 10:59:49 --> Helper loaded: html_helper
INFO - 2025-04-10 10:59:49 --> Helper loaded: form_helper
INFO - 2025-04-10 10:59:49 --> Helper loaded: text_helper
INFO - 2025-04-10 10:59:49 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:59:49 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:59:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:59:49 --> Database Driver Class Initialized
INFO - 2025-04-10 10:59:49 --> Email Class Initialized
INFO - 2025-04-10 10:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:59:49 --> Form Validation Class Initialized
INFO - 2025-04-10 10:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:59:49 --> Pagination Class Initialized
INFO - 2025-04-10 10:59:49 --> Controller Class Initialized
INFO - 2025-04-10 10:59:49 --> Model Class Initialized
INFO - 2025-04-10 10:59:49 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:59:49 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:59:49 --> Final output sent to browser
DEBUG - 2025-04-10 10:59:49 --> Total execution time: 0.0661
INFO - 2025-04-10 10:59:54 --> Config Class Initialized
INFO - 2025-04-10 10:59:54 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:59:54 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:59:54 --> Utf8 Class Initialized
INFO - 2025-04-10 10:59:54 --> URI Class Initialized
INFO - 2025-04-10 10:59:54 --> Router Class Initialized
INFO - 2025-04-10 10:59:54 --> Output Class Initialized
INFO - 2025-04-10 10:59:54 --> Security Class Initialized
DEBUG - 2025-04-10 10:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:59:54 --> Input Class Initialized
INFO - 2025-04-10 10:59:54 --> Language Class Initialized
INFO - 2025-04-10 10:59:54 --> Language Class Initialized
INFO - 2025-04-10 10:59:54 --> Config Class Initialized
INFO - 2025-04-10 10:59:54 --> Loader Class Initialized
INFO - 2025-04-10 10:59:54 --> Helper loaded: url_helper
INFO - 2025-04-10 10:59:54 --> Helper loaded: file_helper
INFO - 2025-04-10 10:59:54 --> Helper loaded: html_helper
INFO - 2025-04-10 10:59:54 --> Helper loaded: form_helper
INFO - 2025-04-10 10:59:54 --> Helper loaded: text_helper
INFO - 2025-04-10 10:59:54 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:59:54 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:59:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:59:54 --> Database Driver Class Initialized
INFO - 2025-04-10 10:59:54 --> Email Class Initialized
INFO - 2025-04-10 10:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:59:54 --> Form Validation Class Initialized
INFO - 2025-04-10 10:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:59:54 --> Pagination Class Initialized
INFO - 2025-04-10 10:59:54 --> Controller Class Initialized
INFO - 2025-04-10 10:59:54 --> Model Class Initialized
INFO - 2025-04-10 10:59:54 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:59:54 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:59:54 --> Final output sent to browser
DEBUG - 2025-04-10 10:59:54 --> Total execution time: 0.0803
INFO - 2025-04-10 10:59:59 --> Config Class Initialized
INFO - 2025-04-10 10:59:59 --> Hooks Class Initialized
DEBUG - 2025-04-10 10:59:59 --> UTF-8 Support Enabled
INFO - 2025-04-10 10:59:59 --> Utf8 Class Initialized
INFO - 2025-04-10 10:59:59 --> URI Class Initialized
INFO - 2025-04-10 10:59:59 --> Router Class Initialized
INFO - 2025-04-10 10:59:59 --> Output Class Initialized
INFO - 2025-04-10 10:59:59 --> Security Class Initialized
DEBUG - 2025-04-10 10:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 10:59:59 --> Input Class Initialized
INFO - 2025-04-10 10:59:59 --> Language Class Initialized
INFO - 2025-04-10 10:59:59 --> Language Class Initialized
INFO - 2025-04-10 10:59:59 --> Config Class Initialized
INFO - 2025-04-10 10:59:59 --> Loader Class Initialized
INFO - 2025-04-10 10:59:59 --> Helper loaded: url_helper
INFO - 2025-04-10 10:59:59 --> Helper loaded: file_helper
INFO - 2025-04-10 10:59:59 --> Helper loaded: html_helper
INFO - 2025-04-10 10:59:59 --> Helper loaded: form_helper
INFO - 2025-04-10 10:59:59 --> Helper loaded: text_helper
INFO - 2025-04-10 10:59:59 --> Helper loaded: lang_helper
INFO - 2025-04-10 10:59:59 --> Helper loaded: directory_helper
INFO - 2025-04-10 10:59:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 10:59:59 --> Database Driver Class Initialized
INFO - 2025-04-10 10:59:59 --> Email Class Initialized
INFO - 2025-04-10 10:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 10:59:59 --> Form Validation Class Initialized
INFO - 2025-04-10 10:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 10:59:59 --> Pagination Class Initialized
INFO - 2025-04-10 10:59:59 --> Controller Class Initialized
INFO - 2025-04-10 10:59:59 --> Model Class Initialized
INFO - 2025-04-10 10:59:59 --> Helper loaded: security_helper
DEBUG - 2025-04-10 10:59:59 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 10:59:59 --> Final output sent to browser
DEBUG - 2025-04-10 10:59:59 --> Total execution time: 0.0653
INFO - 2025-04-10 11:00:24 --> Config Class Initialized
INFO - 2025-04-10 11:00:24 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:00:24 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:00:24 --> Utf8 Class Initialized
INFO - 2025-04-10 11:00:24 --> URI Class Initialized
INFO - 2025-04-10 11:00:24 --> Router Class Initialized
INFO - 2025-04-10 11:00:24 --> Output Class Initialized
INFO - 2025-04-10 11:00:24 --> Security Class Initialized
DEBUG - 2025-04-10 11:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:00:24 --> Input Class Initialized
INFO - 2025-04-10 11:00:24 --> Language Class Initialized
INFO - 2025-04-10 11:00:24 --> Language Class Initialized
INFO - 2025-04-10 11:00:24 --> Config Class Initialized
INFO - 2025-04-10 11:00:24 --> Loader Class Initialized
INFO - 2025-04-10 11:00:24 --> Helper loaded: url_helper
INFO - 2025-04-10 11:00:24 --> Helper loaded: file_helper
INFO - 2025-04-10 11:00:24 --> Helper loaded: html_helper
INFO - 2025-04-10 11:00:24 --> Helper loaded: form_helper
INFO - 2025-04-10 11:00:24 --> Helper loaded: text_helper
INFO - 2025-04-10 11:00:24 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:00:24 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:00:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:00:24 --> Database Driver Class Initialized
INFO - 2025-04-10 11:00:24 --> Email Class Initialized
INFO - 2025-04-10 11:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:00:24 --> Form Validation Class Initialized
INFO - 2025-04-10 11:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:00:24 --> Pagination Class Initialized
INFO - 2025-04-10 11:00:24 --> Controller Class Initialized
INFO - 2025-04-10 11:00:24 --> Model Class Initialized
INFO - 2025-04-10 11:00:24 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:00:24 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:00:24 --> Final output sent to browser
DEBUG - 2025-04-10 11:00:24 --> Total execution time: 0.0068
INFO - 2025-04-10 11:00:38 --> Config Class Initialized
INFO - 2025-04-10 11:00:38 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:00:38 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:00:38 --> Utf8 Class Initialized
INFO - 2025-04-10 11:00:38 --> URI Class Initialized
INFO - 2025-04-10 11:00:38 --> Router Class Initialized
INFO - 2025-04-10 11:00:38 --> Output Class Initialized
INFO - 2025-04-10 11:00:38 --> Security Class Initialized
DEBUG - 2025-04-10 11:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:00:38 --> Input Class Initialized
INFO - 2025-04-10 11:00:38 --> Language Class Initialized
INFO - 2025-04-10 11:00:38 --> Language Class Initialized
INFO - 2025-04-10 11:00:38 --> Config Class Initialized
INFO - 2025-04-10 11:00:38 --> Loader Class Initialized
INFO - 2025-04-10 11:00:38 --> Helper loaded: url_helper
INFO - 2025-04-10 11:00:38 --> Helper loaded: file_helper
INFO - 2025-04-10 11:00:38 --> Helper loaded: html_helper
INFO - 2025-04-10 11:00:38 --> Helper loaded: form_helper
INFO - 2025-04-10 11:00:38 --> Helper loaded: text_helper
INFO - 2025-04-10 11:00:38 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:00:38 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:00:38 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:00:38 --> Database Driver Class Initialized
INFO - 2025-04-10 11:00:38 --> Email Class Initialized
INFO - 2025-04-10 11:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:00:38 --> Form Validation Class Initialized
INFO - 2025-04-10 11:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:00:38 --> Pagination Class Initialized
INFO - 2025-04-10 11:00:38 --> Controller Class Initialized
INFO - 2025-04-10 11:00:38 --> Model Class Initialized
INFO - 2025-04-10 11:00:38 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:00:38 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:00:38 --> Final output sent to browser
DEBUG - 2025-04-10 11:00:38 --> Total execution time: 0.0106
INFO - 2025-04-10 11:01:03 --> Config Class Initialized
INFO - 2025-04-10 11:01:03 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:01:03 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:01:03 --> Utf8 Class Initialized
INFO - 2025-04-10 11:01:03 --> URI Class Initialized
INFO - 2025-04-10 11:01:03 --> Router Class Initialized
INFO - 2025-04-10 11:01:03 --> Output Class Initialized
INFO - 2025-04-10 11:01:03 --> Security Class Initialized
DEBUG - 2025-04-10 11:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:01:03 --> Input Class Initialized
INFO - 2025-04-10 11:01:03 --> Language Class Initialized
INFO - 2025-04-10 11:01:03 --> Language Class Initialized
INFO - 2025-04-10 11:01:03 --> Config Class Initialized
INFO - 2025-04-10 11:01:03 --> Loader Class Initialized
INFO - 2025-04-10 11:01:03 --> Helper loaded: url_helper
INFO - 2025-04-10 11:01:03 --> Helper loaded: file_helper
INFO - 2025-04-10 11:01:03 --> Helper loaded: html_helper
INFO - 2025-04-10 11:01:03 --> Helper loaded: form_helper
INFO - 2025-04-10 11:01:03 --> Helper loaded: text_helper
INFO - 2025-04-10 11:01:03 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:01:03 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:01:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:01:03 --> Database Driver Class Initialized
INFO - 2025-04-10 11:01:03 --> Email Class Initialized
INFO - 2025-04-10 11:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:01:03 --> Form Validation Class Initialized
INFO - 2025-04-10 11:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:01:03 --> Pagination Class Initialized
INFO - 2025-04-10 11:01:03 --> Controller Class Initialized
INFO - 2025-04-10 11:01:03 --> Model Class Initialized
INFO - 2025-04-10 11:01:03 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:01:03 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:01:03 --> Final output sent to browser
DEBUG - 2025-04-10 11:01:03 --> Total execution time: 0.0048
INFO - 2025-04-10 11:04:12 --> Config Class Initialized
INFO - 2025-04-10 11:04:12 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:04:12 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:04:12 --> Utf8 Class Initialized
INFO - 2025-04-10 11:04:12 --> URI Class Initialized
INFO - 2025-04-10 11:04:12 --> Router Class Initialized
INFO - 2025-04-10 11:04:12 --> Output Class Initialized
INFO - 2025-04-10 11:04:12 --> Security Class Initialized
DEBUG - 2025-04-10 11:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:04:12 --> Input Class Initialized
INFO - 2025-04-10 11:04:12 --> Language Class Initialized
INFO - 2025-04-10 11:04:12 --> Language Class Initialized
INFO - 2025-04-10 11:04:12 --> Config Class Initialized
INFO - 2025-04-10 11:04:12 --> Loader Class Initialized
INFO - 2025-04-10 11:04:12 --> Helper loaded: url_helper
INFO - 2025-04-10 11:04:12 --> Helper loaded: file_helper
INFO - 2025-04-10 11:04:12 --> Helper loaded: html_helper
INFO - 2025-04-10 11:04:12 --> Helper loaded: form_helper
INFO - 2025-04-10 11:04:12 --> Helper loaded: text_helper
INFO - 2025-04-10 11:04:12 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:04:12 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:04:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:04:12 --> Database Driver Class Initialized
INFO - 2025-04-10 11:04:12 --> Email Class Initialized
INFO - 2025-04-10 11:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:04:12 --> Form Validation Class Initialized
INFO - 2025-04-10 11:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:04:12 --> Pagination Class Initialized
INFO - 2025-04-10 11:04:12 --> Controller Class Initialized
INFO - 2025-04-10 11:04:12 --> Model Class Initialized
INFO - 2025-04-10 11:04:12 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:04:12 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:04:12 --> Final output sent to browser
DEBUG - 2025-04-10 11:04:12 --> Total execution time: 0.0101
INFO - 2025-04-10 11:04:28 --> Config Class Initialized
INFO - 2025-04-10 11:04:28 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:04:28 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:04:28 --> Utf8 Class Initialized
INFO - 2025-04-10 11:04:28 --> URI Class Initialized
INFO - 2025-04-10 11:04:28 --> Router Class Initialized
INFO - 2025-04-10 11:04:28 --> Output Class Initialized
INFO - 2025-04-10 11:04:28 --> Security Class Initialized
DEBUG - 2025-04-10 11:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:04:28 --> Input Class Initialized
INFO - 2025-04-10 11:04:28 --> Language Class Initialized
INFO - 2025-04-10 11:04:28 --> Language Class Initialized
INFO - 2025-04-10 11:04:28 --> Config Class Initialized
INFO - 2025-04-10 11:04:28 --> Loader Class Initialized
INFO - 2025-04-10 11:04:28 --> Helper loaded: url_helper
INFO - 2025-04-10 11:04:28 --> Helper loaded: file_helper
INFO - 2025-04-10 11:04:28 --> Helper loaded: html_helper
INFO - 2025-04-10 11:04:28 --> Helper loaded: form_helper
INFO - 2025-04-10 11:04:28 --> Helper loaded: text_helper
INFO - 2025-04-10 11:04:28 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:04:28 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:04:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:04:28 --> Database Driver Class Initialized
INFO - 2025-04-10 11:04:28 --> Email Class Initialized
INFO - 2025-04-10 11:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:04:28 --> Form Validation Class Initialized
INFO - 2025-04-10 11:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:04:28 --> Pagination Class Initialized
INFO - 2025-04-10 11:04:28 --> Controller Class Initialized
INFO - 2025-04-10 11:04:28 --> Model Class Initialized
INFO - 2025-04-10 11:04:28 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:04:28 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:04:28 --> Final output sent to browser
DEBUG - 2025-04-10 11:04:28 --> Total execution time: 0.0051
INFO - 2025-04-10 11:04:58 --> Config Class Initialized
INFO - 2025-04-10 11:04:58 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:04:58 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:04:58 --> Utf8 Class Initialized
INFO - 2025-04-10 11:04:58 --> URI Class Initialized
INFO - 2025-04-10 11:04:58 --> Router Class Initialized
INFO - 2025-04-10 11:04:58 --> Output Class Initialized
INFO - 2025-04-10 11:04:58 --> Security Class Initialized
DEBUG - 2025-04-10 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:04:58 --> Input Class Initialized
INFO - 2025-04-10 11:04:58 --> Language Class Initialized
INFO - 2025-04-10 11:04:58 --> Language Class Initialized
INFO - 2025-04-10 11:04:58 --> Config Class Initialized
INFO - 2025-04-10 11:04:58 --> Loader Class Initialized
INFO - 2025-04-10 11:04:58 --> Helper loaded: url_helper
INFO - 2025-04-10 11:04:58 --> Helper loaded: file_helper
INFO - 2025-04-10 11:04:58 --> Helper loaded: html_helper
INFO - 2025-04-10 11:04:58 --> Helper loaded: form_helper
INFO - 2025-04-10 11:04:58 --> Helper loaded: text_helper
INFO - 2025-04-10 11:04:58 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:04:58 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:04:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:04:58 --> Database Driver Class Initialized
INFO - 2025-04-10 11:04:58 --> Email Class Initialized
INFO - 2025-04-10 11:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:04:58 --> Form Validation Class Initialized
INFO - 2025-04-10 11:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:04:58 --> Pagination Class Initialized
INFO - 2025-04-10 11:04:58 --> Controller Class Initialized
INFO - 2025-04-10 11:04:58 --> Model Class Initialized
INFO - 2025-04-10 11:04:58 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:04:58 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:04:58 --> Final output sent to browser
DEBUG - 2025-04-10 11:04:58 --> Total execution time: 0.0126
INFO - 2025-04-10 11:05:13 --> Config Class Initialized
INFO - 2025-04-10 11:05:13 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:05:13 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:05:13 --> Utf8 Class Initialized
INFO - 2025-04-10 11:05:13 --> URI Class Initialized
INFO - 2025-04-10 11:05:13 --> Router Class Initialized
INFO - 2025-04-10 11:05:13 --> Output Class Initialized
INFO - 2025-04-10 11:05:13 --> Security Class Initialized
DEBUG - 2025-04-10 11:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:05:13 --> Input Class Initialized
INFO - 2025-04-10 11:05:13 --> Language Class Initialized
INFO - 2025-04-10 11:05:13 --> Language Class Initialized
INFO - 2025-04-10 11:05:13 --> Config Class Initialized
INFO - 2025-04-10 11:05:13 --> Loader Class Initialized
INFO - 2025-04-10 11:05:13 --> Helper loaded: url_helper
INFO - 2025-04-10 11:05:13 --> Helper loaded: file_helper
INFO - 2025-04-10 11:05:13 --> Helper loaded: html_helper
INFO - 2025-04-10 11:05:13 --> Helper loaded: form_helper
INFO - 2025-04-10 11:05:13 --> Helper loaded: text_helper
INFO - 2025-04-10 11:05:13 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:05:13 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:05:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:05:13 --> Database Driver Class Initialized
INFO - 2025-04-10 11:05:13 --> Email Class Initialized
INFO - 2025-04-10 11:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:05:13 --> Form Validation Class Initialized
INFO - 2025-04-10 11:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:05:13 --> Pagination Class Initialized
INFO - 2025-04-10 11:05:13 --> Controller Class Initialized
INFO - 2025-04-10 11:05:13 --> Model Class Initialized
INFO - 2025-04-10 11:05:13 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:05:13 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:05:13 --> Final output sent to browser
DEBUG - 2025-04-10 11:05:13 --> Total execution time: 0.0043
INFO - 2025-04-10 11:16:01 --> Config Class Initialized
INFO - 2025-04-10 11:16:01 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:16:01 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:16:01 --> Utf8 Class Initialized
INFO - 2025-04-10 11:16:01 --> URI Class Initialized
INFO - 2025-04-10 11:16:01 --> Router Class Initialized
INFO - 2025-04-10 11:16:01 --> Output Class Initialized
INFO - 2025-04-10 11:16:01 --> Security Class Initialized
DEBUG - 2025-04-10 11:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:16:01 --> Input Class Initialized
INFO - 2025-04-10 11:16:01 --> Language Class Initialized
INFO - 2025-04-10 11:16:01 --> Language Class Initialized
INFO - 2025-04-10 11:16:01 --> Config Class Initialized
INFO - 2025-04-10 11:16:01 --> Loader Class Initialized
INFO - 2025-04-10 11:16:01 --> Helper loaded: url_helper
INFO - 2025-04-10 11:16:01 --> Helper loaded: file_helper
INFO - 2025-04-10 11:16:01 --> Helper loaded: html_helper
INFO - 2025-04-10 11:16:01 --> Helper loaded: form_helper
INFO - 2025-04-10 11:16:01 --> Helper loaded: text_helper
INFO - 2025-04-10 11:16:01 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:16:01 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:16:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:16:01 --> Database Driver Class Initialized
INFO - 2025-04-10 11:16:01 --> Email Class Initialized
INFO - 2025-04-10 11:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:16:01 --> Form Validation Class Initialized
INFO - 2025-04-10 11:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:16:01 --> Pagination Class Initialized
INFO - 2025-04-10 11:16:01 --> Controller Class Initialized
INFO - 2025-04-10 11:16:01 --> Model Class Initialized
INFO - 2025-04-10 11:16:01 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:16:01 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:16:01 --> Final output sent to browser
DEBUG - 2025-04-10 11:16:01 --> Total execution time: 0.0822
INFO - 2025-04-10 11:16:19 --> Config Class Initialized
INFO - 2025-04-10 11:16:19 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:16:19 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:16:19 --> Utf8 Class Initialized
INFO - 2025-04-10 11:16:19 --> URI Class Initialized
INFO - 2025-04-10 11:16:19 --> Router Class Initialized
INFO - 2025-04-10 11:16:19 --> Output Class Initialized
INFO - 2025-04-10 11:16:19 --> Security Class Initialized
DEBUG - 2025-04-10 11:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:16:19 --> Input Class Initialized
INFO - 2025-04-10 11:16:19 --> Language Class Initialized
INFO - 2025-04-10 11:16:19 --> Language Class Initialized
INFO - 2025-04-10 11:16:19 --> Config Class Initialized
INFO - 2025-04-10 11:16:19 --> Loader Class Initialized
INFO - 2025-04-10 11:16:19 --> Helper loaded: url_helper
INFO - 2025-04-10 11:16:19 --> Helper loaded: file_helper
INFO - 2025-04-10 11:16:19 --> Helper loaded: html_helper
INFO - 2025-04-10 11:16:19 --> Helper loaded: form_helper
INFO - 2025-04-10 11:16:19 --> Helper loaded: text_helper
INFO - 2025-04-10 11:16:19 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:16:19 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:16:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:16:19 --> Database Driver Class Initialized
INFO - 2025-04-10 11:16:19 --> Email Class Initialized
INFO - 2025-04-10 11:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:16:19 --> Form Validation Class Initialized
INFO - 2025-04-10 11:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:16:19 --> Pagination Class Initialized
INFO - 2025-04-10 11:16:19 --> Controller Class Initialized
INFO - 2025-04-10 11:16:19 --> Model Class Initialized
INFO - 2025-04-10 11:16:19 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:16:19 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:16:19 --> Final output sent to browser
DEBUG - 2025-04-10 11:16:19 --> Total execution time: 0.0072
INFO - 2025-04-10 11:16:28 --> Config Class Initialized
INFO - 2025-04-10 11:16:28 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:16:28 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:16:28 --> Utf8 Class Initialized
INFO - 2025-04-10 11:16:28 --> URI Class Initialized
INFO - 2025-04-10 11:16:28 --> Router Class Initialized
INFO - 2025-04-10 11:16:28 --> Output Class Initialized
INFO - 2025-04-10 11:16:28 --> Security Class Initialized
DEBUG - 2025-04-10 11:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:16:28 --> Input Class Initialized
INFO - 2025-04-10 11:16:28 --> Language Class Initialized
INFO - 2025-04-10 11:16:28 --> Language Class Initialized
INFO - 2025-04-10 11:16:28 --> Config Class Initialized
INFO - 2025-04-10 11:16:28 --> Loader Class Initialized
INFO - 2025-04-10 11:16:28 --> Helper loaded: url_helper
INFO - 2025-04-10 11:16:28 --> Helper loaded: file_helper
INFO - 2025-04-10 11:16:28 --> Helper loaded: html_helper
INFO - 2025-04-10 11:16:28 --> Helper loaded: form_helper
INFO - 2025-04-10 11:16:28 --> Helper loaded: text_helper
INFO - 2025-04-10 11:16:28 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:16:28 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:16:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:16:28 --> Database Driver Class Initialized
INFO - 2025-04-10 11:16:28 --> Email Class Initialized
INFO - 2025-04-10 11:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:16:28 --> Form Validation Class Initialized
INFO - 2025-04-10 11:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:16:28 --> Pagination Class Initialized
INFO - 2025-04-10 11:16:28 --> Controller Class Initialized
INFO - 2025-04-10 11:16:28 --> Model Class Initialized
INFO - 2025-04-10 11:16:28 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:16:28 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:16:28 --> Final output sent to browser
DEBUG - 2025-04-10 11:16:28 --> Total execution time: 0.0604
INFO - 2025-04-10 11:53:20 --> Config Class Initialized
INFO - 2025-04-10 11:53:20 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:53:20 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:53:20 --> Utf8 Class Initialized
INFO - 2025-04-10 11:53:20 --> URI Class Initialized
INFO - 2025-04-10 11:53:20 --> Router Class Initialized
INFO - 2025-04-10 11:53:20 --> Output Class Initialized
INFO - 2025-04-10 11:53:20 --> Security Class Initialized
DEBUG - 2025-04-10 11:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:53:20 --> Input Class Initialized
INFO - 2025-04-10 11:53:20 --> Language Class Initialized
INFO - 2025-04-10 11:53:20 --> Language Class Initialized
INFO - 2025-04-10 11:53:20 --> Config Class Initialized
INFO - 2025-04-10 11:53:20 --> Loader Class Initialized
INFO - 2025-04-10 11:53:20 --> Helper loaded: url_helper
INFO - 2025-04-10 11:53:20 --> Helper loaded: file_helper
INFO - 2025-04-10 11:53:20 --> Helper loaded: html_helper
INFO - 2025-04-10 11:53:20 --> Helper loaded: form_helper
INFO - 2025-04-10 11:53:20 --> Helper loaded: text_helper
INFO - 2025-04-10 11:53:20 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:53:20 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:53:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:53:20 --> Database Driver Class Initialized
INFO - 2025-04-10 11:53:20 --> Email Class Initialized
INFO - 2025-04-10 11:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:53:20 --> Form Validation Class Initialized
INFO - 2025-04-10 11:53:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:53:20 --> Pagination Class Initialized
INFO - 2025-04-10 11:53:20 --> Controller Class Initialized
INFO - 2025-04-10 11:53:20 --> Model Class Initialized
INFO - 2025-04-10 11:53:20 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:53:20 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:53:21 --> Final output sent to browser
DEBUG - 2025-04-10 11:53:21 --> Total execution time: 0.0903
INFO - 2025-04-10 11:53:45 --> Config Class Initialized
INFO - 2025-04-10 11:53:45 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:53:45 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:53:45 --> Utf8 Class Initialized
INFO - 2025-04-10 11:53:45 --> URI Class Initialized
INFO - 2025-04-10 11:53:45 --> Router Class Initialized
INFO - 2025-04-10 11:53:45 --> Output Class Initialized
INFO - 2025-04-10 11:53:45 --> Security Class Initialized
DEBUG - 2025-04-10 11:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:53:45 --> Input Class Initialized
INFO - 2025-04-10 11:53:45 --> Language Class Initialized
INFO - 2025-04-10 11:53:45 --> Language Class Initialized
INFO - 2025-04-10 11:53:45 --> Config Class Initialized
INFO - 2025-04-10 11:53:45 --> Loader Class Initialized
INFO - 2025-04-10 11:53:45 --> Helper loaded: url_helper
INFO - 2025-04-10 11:53:45 --> Helper loaded: file_helper
INFO - 2025-04-10 11:53:45 --> Helper loaded: html_helper
INFO - 2025-04-10 11:53:45 --> Helper loaded: form_helper
INFO - 2025-04-10 11:53:45 --> Helper loaded: text_helper
INFO - 2025-04-10 11:53:45 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:53:45 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:53:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:53:45 --> Database Driver Class Initialized
INFO - 2025-04-10 11:53:45 --> Email Class Initialized
INFO - 2025-04-10 11:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:53:45 --> Form Validation Class Initialized
INFO - 2025-04-10 11:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:53:45 --> Pagination Class Initialized
INFO - 2025-04-10 11:53:45 --> Controller Class Initialized
INFO - 2025-04-10 11:53:45 --> Model Class Initialized
INFO - 2025-04-10 11:53:45 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:53:45 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:53:45 --> Final output sent to browser
DEBUG - 2025-04-10 11:53:45 --> Total execution time: 0.0061
INFO - 2025-04-10 11:53:51 --> Config Class Initialized
INFO - 2025-04-10 11:53:51 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:53:51 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:53:51 --> Utf8 Class Initialized
INFO - 2025-04-10 11:53:51 --> URI Class Initialized
INFO - 2025-04-10 11:53:51 --> Router Class Initialized
INFO - 2025-04-10 11:53:51 --> Output Class Initialized
INFO - 2025-04-10 11:53:51 --> Security Class Initialized
DEBUG - 2025-04-10 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:53:51 --> Input Class Initialized
INFO - 2025-04-10 11:53:51 --> Language Class Initialized
INFO - 2025-04-10 11:53:51 --> Language Class Initialized
INFO - 2025-04-10 11:53:51 --> Config Class Initialized
INFO - 2025-04-10 11:53:51 --> Loader Class Initialized
INFO - 2025-04-10 11:53:51 --> Helper loaded: url_helper
INFO - 2025-04-10 11:53:51 --> Helper loaded: file_helper
INFO - 2025-04-10 11:53:51 --> Helper loaded: html_helper
INFO - 2025-04-10 11:53:51 --> Helper loaded: form_helper
INFO - 2025-04-10 11:53:51 --> Helper loaded: text_helper
INFO - 2025-04-10 11:53:51 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:53:51 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:53:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:53:51 --> Database Driver Class Initialized
INFO - 2025-04-10 11:53:51 --> Email Class Initialized
INFO - 2025-04-10 11:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:53:51 --> Form Validation Class Initialized
INFO - 2025-04-10 11:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:53:51 --> Pagination Class Initialized
INFO - 2025-04-10 11:53:51 --> Controller Class Initialized
INFO - 2025-04-10 11:53:51 --> Model Class Initialized
INFO - 2025-04-10 11:53:51 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:53:51 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:53:51 --> Final output sent to browser
DEBUG - 2025-04-10 11:53:51 --> Total execution time: 0.0064
INFO - 2025-04-10 11:55:32 --> Config Class Initialized
INFO - 2025-04-10 11:55:32 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:55:32 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:55:32 --> Utf8 Class Initialized
INFO - 2025-04-10 11:55:32 --> URI Class Initialized
INFO - 2025-04-10 11:55:32 --> Router Class Initialized
INFO - 2025-04-10 11:55:32 --> Output Class Initialized
INFO - 2025-04-10 11:55:32 --> Security Class Initialized
DEBUG - 2025-04-10 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:55:32 --> Input Class Initialized
INFO - 2025-04-10 11:55:32 --> Language Class Initialized
INFO - 2025-04-10 11:55:32 --> Language Class Initialized
INFO - 2025-04-10 11:55:32 --> Config Class Initialized
INFO - 2025-04-10 11:55:32 --> Loader Class Initialized
INFO - 2025-04-10 11:55:32 --> Helper loaded: url_helper
INFO - 2025-04-10 11:55:32 --> Helper loaded: file_helper
INFO - 2025-04-10 11:55:32 --> Helper loaded: html_helper
INFO - 2025-04-10 11:55:32 --> Helper loaded: form_helper
INFO - 2025-04-10 11:55:32 --> Helper loaded: text_helper
INFO - 2025-04-10 11:55:32 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:55:32 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:55:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:55:32 --> Database Driver Class Initialized
INFO - 2025-04-10 11:55:32 --> Email Class Initialized
INFO - 2025-04-10 11:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:55:32 --> Form Validation Class Initialized
INFO - 2025-04-10 11:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:55:32 --> Pagination Class Initialized
INFO - 2025-04-10 11:55:32 --> Controller Class Initialized
INFO - 2025-04-10 11:55:32 --> Model Class Initialized
INFO - 2025-04-10 11:55:32 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:55:32 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:55:32 --> Final output sent to browser
DEBUG - 2025-04-10 11:55:32 --> Total execution time: 0.0096
INFO - 2025-04-10 11:55:54 --> Config Class Initialized
INFO - 2025-04-10 11:55:54 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:55:54 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:55:54 --> Utf8 Class Initialized
INFO - 2025-04-10 11:55:54 --> URI Class Initialized
INFO - 2025-04-10 11:55:54 --> Router Class Initialized
INFO - 2025-04-10 11:55:54 --> Output Class Initialized
INFO - 2025-04-10 11:55:54 --> Security Class Initialized
DEBUG - 2025-04-10 11:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:55:54 --> Input Class Initialized
INFO - 2025-04-10 11:55:54 --> Language Class Initialized
INFO - 2025-04-10 11:55:54 --> Language Class Initialized
INFO - 2025-04-10 11:55:54 --> Config Class Initialized
INFO - 2025-04-10 11:55:54 --> Loader Class Initialized
INFO - 2025-04-10 11:55:54 --> Helper loaded: url_helper
INFO - 2025-04-10 11:55:54 --> Helper loaded: file_helper
INFO - 2025-04-10 11:55:54 --> Helper loaded: html_helper
INFO - 2025-04-10 11:55:54 --> Helper loaded: form_helper
INFO - 2025-04-10 11:55:54 --> Helper loaded: text_helper
INFO - 2025-04-10 11:55:54 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:55:54 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:55:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:55:54 --> Database Driver Class Initialized
INFO - 2025-04-10 11:55:54 --> Email Class Initialized
INFO - 2025-04-10 11:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:55:54 --> Form Validation Class Initialized
INFO - 2025-04-10 11:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:55:54 --> Pagination Class Initialized
INFO - 2025-04-10 11:55:54 --> Controller Class Initialized
INFO - 2025-04-10 11:55:54 --> Model Class Initialized
INFO - 2025-04-10 11:55:54 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:55:54 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:55:54 --> Final output sent to browser
DEBUG - 2025-04-10 11:55:54 --> Total execution time: 0.0118
INFO - 2025-04-10 11:57:09 --> Config Class Initialized
INFO - 2025-04-10 11:57:09 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:57:09 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:57:09 --> Utf8 Class Initialized
INFO - 2025-04-10 11:57:09 --> URI Class Initialized
INFO - 2025-04-10 11:57:09 --> Router Class Initialized
INFO - 2025-04-10 11:57:09 --> Output Class Initialized
INFO - 2025-04-10 11:57:09 --> Security Class Initialized
DEBUG - 2025-04-10 11:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:57:09 --> Input Class Initialized
INFO - 2025-04-10 11:57:09 --> Language Class Initialized
INFO - 2025-04-10 11:57:09 --> Language Class Initialized
INFO - 2025-04-10 11:57:09 --> Config Class Initialized
INFO - 2025-04-10 11:57:09 --> Loader Class Initialized
INFO - 2025-04-10 11:57:09 --> Helper loaded: url_helper
INFO - 2025-04-10 11:57:09 --> Helper loaded: file_helper
INFO - 2025-04-10 11:57:09 --> Helper loaded: html_helper
INFO - 2025-04-10 11:57:09 --> Helper loaded: form_helper
INFO - 2025-04-10 11:57:09 --> Helper loaded: text_helper
INFO - 2025-04-10 11:57:09 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:57:09 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:57:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:57:09 --> Database Driver Class Initialized
INFO - 2025-04-10 11:57:09 --> Email Class Initialized
INFO - 2025-04-10 11:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:57:09 --> Form Validation Class Initialized
INFO - 2025-04-10 11:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:57:09 --> Pagination Class Initialized
INFO - 2025-04-10 11:57:09 --> Controller Class Initialized
INFO - 2025-04-10 11:57:09 --> Model Class Initialized
INFO - 2025-04-10 11:57:09 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:57:09 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:57:09 --> Final output sent to browser
DEBUG - 2025-04-10 11:57:09 --> Total execution time: 0.0069
INFO - 2025-04-10 11:57:23 --> Config Class Initialized
INFO - 2025-04-10 11:57:23 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:57:23 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:57:23 --> Utf8 Class Initialized
INFO - 2025-04-10 11:57:23 --> URI Class Initialized
INFO - 2025-04-10 11:57:23 --> Router Class Initialized
INFO - 2025-04-10 11:57:23 --> Output Class Initialized
INFO - 2025-04-10 11:57:23 --> Security Class Initialized
DEBUG - 2025-04-10 11:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:57:23 --> Input Class Initialized
INFO - 2025-04-10 11:57:23 --> Language Class Initialized
INFO - 2025-04-10 11:57:23 --> Language Class Initialized
INFO - 2025-04-10 11:57:23 --> Config Class Initialized
INFO - 2025-04-10 11:57:23 --> Loader Class Initialized
INFO - 2025-04-10 11:57:23 --> Helper loaded: url_helper
INFO - 2025-04-10 11:57:23 --> Helper loaded: file_helper
INFO - 2025-04-10 11:57:23 --> Helper loaded: html_helper
INFO - 2025-04-10 11:57:23 --> Helper loaded: form_helper
INFO - 2025-04-10 11:57:23 --> Helper loaded: text_helper
INFO - 2025-04-10 11:57:23 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:57:23 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:57:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:57:23 --> Database Driver Class Initialized
INFO - 2025-04-10 11:57:23 --> Email Class Initialized
INFO - 2025-04-10 11:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:57:23 --> Form Validation Class Initialized
INFO - 2025-04-10 11:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:57:23 --> Pagination Class Initialized
INFO - 2025-04-10 11:57:23 --> Controller Class Initialized
INFO - 2025-04-10 11:57:23 --> Model Class Initialized
INFO - 2025-04-10 11:57:23 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:57:23 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:57:23 --> Final output sent to browser
DEBUG - 2025-04-10 11:57:23 --> Total execution time: 0.0704
INFO - 2025-04-10 11:57:37 --> Config Class Initialized
INFO - 2025-04-10 11:57:37 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:57:37 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:57:37 --> Utf8 Class Initialized
INFO - 2025-04-10 11:57:37 --> URI Class Initialized
INFO - 2025-04-10 11:57:37 --> Router Class Initialized
INFO - 2025-04-10 11:57:37 --> Output Class Initialized
INFO - 2025-04-10 11:57:37 --> Security Class Initialized
DEBUG - 2025-04-10 11:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:57:37 --> Input Class Initialized
INFO - 2025-04-10 11:57:37 --> Language Class Initialized
INFO - 2025-04-10 11:57:37 --> Language Class Initialized
INFO - 2025-04-10 11:57:37 --> Config Class Initialized
INFO - 2025-04-10 11:57:37 --> Loader Class Initialized
INFO - 2025-04-10 11:57:37 --> Helper loaded: url_helper
INFO - 2025-04-10 11:57:37 --> Helper loaded: file_helper
INFO - 2025-04-10 11:57:37 --> Helper loaded: html_helper
INFO - 2025-04-10 11:57:37 --> Helper loaded: form_helper
INFO - 2025-04-10 11:57:37 --> Helper loaded: text_helper
INFO - 2025-04-10 11:57:37 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:57:37 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:57:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:57:37 --> Database Driver Class Initialized
INFO - 2025-04-10 11:57:37 --> Email Class Initialized
INFO - 2025-04-10 11:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:57:37 --> Form Validation Class Initialized
INFO - 2025-04-10 11:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:57:37 --> Pagination Class Initialized
INFO - 2025-04-10 11:57:37 --> Controller Class Initialized
INFO - 2025-04-10 11:57:37 --> Model Class Initialized
INFO - 2025-04-10 11:57:37 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:57:37 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 11:57:37 --> Final output sent to browser
DEBUG - 2025-04-10 11:57:37 --> Total execution time: 0.0085
INFO - 2025-04-10 11:58:07 --> Config Class Initialized
INFO - 2025-04-10 11:58:07 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:58:07 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:58:07 --> Utf8 Class Initialized
INFO - 2025-04-10 11:58:07 --> URI Class Initialized
INFO - 2025-04-10 11:58:07 --> Router Class Initialized
INFO - 2025-04-10 11:58:07 --> Output Class Initialized
INFO - 2025-04-10 11:58:07 --> Security Class Initialized
DEBUG - 2025-04-10 11:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:58:07 --> Input Class Initialized
INFO - 2025-04-10 11:58:07 --> Language Class Initialized
INFO - 2025-04-10 11:58:07 --> Language Class Initialized
INFO - 2025-04-10 11:58:07 --> Config Class Initialized
INFO - 2025-04-10 11:58:07 --> Loader Class Initialized
INFO - 2025-04-10 11:58:07 --> Helper loaded: url_helper
INFO - 2025-04-10 11:58:07 --> Helper loaded: file_helper
INFO - 2025-04-10 11:58:07 --> Helper loaded: html_helper
INFO - 2025-04-10 11:58:07 --> Helper loaded: form_helper
INFO - 2025-04-10 11:58:07 --> Helper loaded: text_helper
INFO - 2025-04-10 11:58:07 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:58:07 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:58:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:58:07 --> Database Driver Class Initialized
INFO - 2025-04-10 11:58:07 --> Email Class Initialized
INFO - 2025-04-10 11:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:58:07 --> Form Validation Class Initialized
INFO - 2025-04-10 11:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:58:07 --> Pagination Class Initialized
INFO - 2025-04-10 11:58:07 --> Controller Class Initialized
INFO - 2025-04-10 11:58:07 --> Model Class Initialized
INFO - 2025-04-10 11:58:07 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:58:07 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 11:58:07 --> Severity: error --> Exception: Call to undefined method Api_model::get_api_user_by_id() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 282
INFO - 2025-04-10 11:58:24 --> Config Class Initialized
INFO - 2025-04-10 11:58:24 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:58:24 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:58:24 --> Utf8 Class Initialized
INFO - 2025-04-10 11:58:24 --> URI Class Initialized
INFO - 2025-04-10 11:58:24 --> Router Class Initialized
INFO - 2025-04-10 11:58:24 --> Output Class Initialized
INFO - 2025-04-10 11:58:24 --> Security Class Initialized
DEBUG - 2025-04-10 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:58:24 --> Input Class Initialized
INFO - 2025-04-10 11:58:24 --> Language Class Initialized
INFO - 2025-04-10 11:58:24 --> Language Class Initialized
INFO - 2025-04-10 11:58:24 --> Config Class Initialized
INFO - 2025-04-10 11:58:24 --> Loader Class Initialized
INFO - 2025-04-10 11:58:24 --> Helper loaded: url_helper
INFO - 2025-04-10 11:58:24 --> Helper loaded: file_helper
INFO - 2025-04-10 11:58:24 --> Helper loaded: html_helper
INFO - 2025-04-10 11:58:24 --> Helper loaded: form_helper
INFO - 2025-04-10 11:58:24 --> Helper loaded: text_helper
INFO - 2025-04-10 11:58:24 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:58:24 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:58:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:58:24 --> Database Driver Class Initialized
INFO - 2025-04-10 11:58:24 --> Email Class Initialized
INFO - 2025-04-10 11:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:58:24 --> Form Validation Class Initialized
INFO - 2025-04-10 11:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:58:24 --> Pagination Class Initialized
INFO - 2025-04-10 11:58:24 --> Controller Class Initialized
INFO - 2025-04-10 11:58:24 --> Model Class Initialized
INFO - 2025-04-10 11:58:24 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:58:24 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 11:58:24 --> Severity: error --> Exception: Call to undefined method Api_model::get_api_user_by_id() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 282
INFO - 2025-04-10 11:58:25 --> Config Class Initialized
INFO - 2025-04-10 11:58:25 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:58:25 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:58:25 --> Utf8 Class Initialized
INFO - 2025-04-10 11:58:25 --> URI Class Initialized
INFO - 2025-04-10 11:58:25 --> Router Class Initialized
INFO - 2025-04-10 11:58:25 --> Output Class Initialized
INFO - 2025-04-10 11:58:25 --> Security Class Initialized
DEBUG - 2025-04-10 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:58:25 --> Input Class Initialized
INFO - 2025-04-10 11:58:25 --> Language Class Initialized
INFO - 2025-04-10 11:58:25 --> Language Class Initialized
INFO - 2025-04-10 11:58:25 --> Config Class Initialized
INFO - 2025-04-10 11:58:25 --> Loader Class Initialized
INFO - 2025-04-10 11:58:25 --> Helper loaded: url_helper
INFO - 2025-04-10 11:58:25 --> Helper loaded: file_helper
INFO - 2025-04-10 11:58:25 --> Helper loaded: html_helper
INFO - 2025-04-10 11:58:25 --> Helper loaded: form_helper
INFO - 2025-04-10 11:58:25 --> Helper loaded: text_helper
INFO - 2025-04-10 11:58:25 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:58:25 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:58:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:58:25 --> Database Driver Class Initialized
INFO - 2025-04-10 11:58:25 --> Email Class Initialized
INFO - 2025-04-10 11:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:58:25 --> Form Validation Class Initialized
INFO - 2025-04-10 11:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:58:25 --> Pagination Class Initialized
INFO - 2025-04-10 11:58:25 --> Controller Class Initialized
INFO - 2025-04-10 11:58:25 --> Model Class Initialized
INFO - 2025-04-10 11:58:25 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:58:25 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 11:58:25 --> Severity: error --> Exception: Call to undefined method Api_model::get_api_user_by_id() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 282
INFO - 2025-04-10 11:58:45 --> Config Class Initialized
INFO - 2025-04-10 11:58:45 --> Hooks Class Initialized
DEBUG - 2025-04-10 11:58:45 --> UTF-8 Support Enabled
INFO - 2025-04-10 11:58:45 --> Utf8 Class Initialized
INFO - 2025-04-10 11:58:45 --> URI Class Initialized
INFO - 2025-04-10 11:58:45 --> Router Class Initialized
INFO - 2025-04-10 11:58:45 --> Output Class Initialized
INFO - 2025-04-10 11:58:45 --> Security Class Initialized
DEBUG - 2025-04-10 11:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 11:58:45 --> Input Class Initialized
INFO - 2025-04-10 11:58:45 --> Language Class Initialized
INFO - 2025-04-10 11:58:45 --> Language Class Initialized
INFO - 2025-04-10 11:58:45 --> Config Class Initialized
INFO - 2025-04-10 11:58:45 --> Loader Class Initialized
INFO - 2025-04-10 11:58:45 --> Helper loaded: url_helper
INFO - 2025-04-10 11:58:45 --> Helper loaded: file_helper
INFO - 2025-04-10 11:58:45 --> Helper loaded: html_helper
INFO - 2025-04-10 11:58:45 --> Helper loaded: form_helper
INFO - 2025-04-10 11:58:45 --> Helper loaded: text_helper
INFO - 2025-04-10 11:58:45 --> Helper loaded: lang_helper
INFO - 2025-04-10 11:58:45 --> Helper loaded: directory_helper
INFO - 2025-04-10 11:58:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 11:58:45 --> Database Driver Class Initialized
INFO - 2025-04-10 11:58:45 --> Email Class Initialized
INFO - 2025-04-10 11:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 11:58:45 --> Form Validation Class Initialized
INFO - 2025-04-10 11:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 11:58:45 --> Pagination Class Initialized
INFO - 2025-04-10 11:58:45 --> Controller Class Initialized
INFO - 2025-04-10 11:58:45 --> Model Class Initialized
INFO - 2025-04-10 11:58:45 --> Helper loaded: security_helper
DEBUG - 2025-04-10 11:58:45 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
ERROR - 2025-04-10 11:58:45 --> Severity: error --> Exception: Call to undefined method Api_model::get_api_user_by_id() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Apiv2.php 282
INFO - 2025-04-10 12:00:51 --> Config Class Initialized
INFO - 2025-04-10 12:00:51 --> Hooks Class Initialized
DEBUG - 2025-04-10 12:00:51 --> UTF-8 Support Enabled
INFO - 2025-04-10 12:00:51 --> Utf8 Class Initialized
INFO - 2025-04-10 12:00:51 --> URI Class Initialized
INFO - 2025-04-10 12:00:51 --> Router Class Initialized
INFO - 2025-04-10 12:00:51 --> Output Class Initialized
INFO - 2025-04-10 12:00:51 --> Security Class Initialized
DEBUG - 2025-04-10 12:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 12:00:51 --> Input Class Initialized
INFO - 2025-04-10 12:00:51 --> Language Class Initialized
INFO - 2025-04-10 12:00:51 --> Language Class Initialized
INFO - 2025-04-10 12:00:51 --> Config Class Initialized
INFO - 2025-04-10 12:00:51 --> Loader Class Initialized
INFO - 2025-04-10 12:00:51 --> Helper loaded: url_helper
INFO - 2025-04-10 12:00:51 --> Helper loaded: file_helper
INFO - 2025-04-10 12:00:51 --> Helper loaded: html_helper
INFO - 2025-04-10 12:00:51 --> Helper loaded: form_helper
INFO - 2025-04-10 12:00:51 --> Helper loaded: text_helper
INFO - 2025-04-10 12:00:51 --> Helper loaded: lang_helper
INFO - 2025-04-10 12:00:51 --> Helper loaded: directory_helper
INFO - 2025-04-10 12:00:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 12:00:51 --> Database Driver Class Initialized
INFO - 2025-04-10 12:00:51 --> Email Class Initialized
INFO - 2025-04-10 12:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 12:00:51 --> Form Validation Class Initialized
INFO - 2025-04-10 12:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 12:00:51 --> Pagination Class Initialized
INFO - 2025-04-10 12:00:51 --> Controller Class Initialized
INFO - 2025-04-10 12:00:51 --> Model Class Initialized
INFO - 2025-04-10 12:00:51 --> Helper loaded: security_helper
DEBUG - 2025-04-10 12:00:51 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 12:00:51 --> Final output sent to browser
DEBUG - 2025-04-10 12:00:51 --> Total execution time: 0.0083
INFO - 2025-04-10 12:03:34 --> Config Class Initialized
INFO - 2025-04-10 12:03:34 --> Hooks Class Initialized
DEBUG - 2025-04-10 12:03:34 --> UTF-8 Support Enabled
INFO - 2025-04-10 12:03:34 --> Utf8 Class Initialized
INFO - 2025-04-10 12:03:34 --> URI Class Initialized
INFO - 2025-04-10 12:03:34 --> Router Class Initialized
INFO - 2025-04-10 12:03:34 --> Output Class Initialized
INFO - 2025-04-10 12:03:34 --> Security Class Initialized
DEBUG - 2025-04-10 12:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 12:03:34 --> Input Class Initialized
INFO - 2025-04-10 12:03:34 --> Language Class Initialized
INFO - 2025-04-10 12:03:34 --> Language Class Initialized
INFO - 2025-04-10 12:03:34 --> Config Class Initialized
INFO - 2025-04-10 12:03:34 --> Loader Class Initialized
INFO - 2025-04-10 12:03:34 --> Helper loaded: url_helper
INFO - 2025-04-10 12:03:34 --> Helper loaded: file_helper
INFO - 2025-04-10 12:03:34 --> Helper loaded: html_helper
INFO - 2025-04-10 12:03:34 --> Helper loaded: form_helper
INFO - 2025-04-10 12:03:34 --> Helper loaded: text_helper
INFO - 2025-04-10 12:03:34 --> Helper loaded: lang_helper
INFO - 2025-04-10 12:03:34 --> Helper loaded: directory_helper
INFO - 2025-04-10 12:03:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 12:03:34 --> Database Driver Class Initialized
INFO - 2025-04-10 12:03:34 --> Email Class Initialized
INFO - 2025-04-10 12:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 12:03:34 --> Form Validation Class Initialized
INFO - 2025-04-10 12:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 12:03:34 --> Pagination Class Initialized
INFO - 2025-04-10 12:03:34 --> Controller Class Initialized
INFO - 2025-04-10 12:03:34 --> Model Class Initialized
INFO - 2025-04-10 12:03:34 --> Helper loaded: security_helper
DEBUG - 2025-04-10 12:03:34 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 12:03:34 --> Final output sent to browser
DEBUG - 2025-04-10 12:03:34 --> Total execution time: 0.0203
INFO - 2025-04-10 12:03:55 --> Config Class Initialized
INFO - 2025-04-10 12:03:55 --> Hooks Class Initialized
DEBUG - 2025-04-10 12:03:55 --> UTF-8 Support Enabled
INFO - 2025-04-10 12:03:55 --> Utf8 Class Initialized
INFO - 2025-04-10 12:03:55 --> URI Class Initialized
INFO - 2025-04-10 12:03:55 --> Router Class Initialized
INFO - 2025-04-10 12:03:55 --> Output Class Initialized
INFO - 2025-04-10 12:03:55 --> Security Class Initialized
DEBUG - 2025-04-10 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 12:03:55 --> Input Class Initialized
INFO - 2025-04-10 12:03:55 --> Language Class Initialized
INFO - 2025-04-10 12:03:55 --> Language Class Initialized
INFO - 2025-04-10 12:03:55 --> Config Class Initialized
INFO - 2025-04-10 12:03:55 --> Loader Class Initialized
INFO - 2025-04-10 12:03:55 --> Helper loaded: url_helper
INFO - 2025-04-10 12:03:55 --> Helper loaded: file_helper
INFO - 2025-04-10 12:03:55 --> Helper loaded: html_helper
INFO - 2025-04-10 12:03:55 --> Helper loaded: form_helper
INFO - 2025-04-10 12:03:55 --> Helper loaded: text_helper
INFO - 2025-04-10 12:03:55 --> Helper loaded: lang_helper
INFO - 2025-04-10 12:03:55 --> Helper loaded: directory_helper
INFO - 2025-04-10 12:03:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 12:03:55 --> Database Driver Class Initialized
INFO - 2025-04-10 12:03:55 --> Email Class Initialized
INFO - 2025-04-10 12:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 12:03:55 --> Form Validation Class Initialized
INFO - 2025-04-10 12:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 12:03:55 --> Pagination Class Initialized
INFO - 2025-04-10 12:03:55 --> Controller Class Initialized
INFO - 2025-04-10 12:03:55 --> Model Class Initialized
INFO - 2025-04-10 12:03:55 --> Helper loaded: security_helper
DEBUG - 2025-04-10 12:03:55 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 12:03:55 --> Final output sent to browser
DEBUG - 2025-04-10 12:03:55 --> Total execution time: 0.0065
INFO - 2025-04-10 12:04:03 --> Config Class Initialized
INFO - 2025-04-10 12:04:03 --> Hooks Class Initialized
DEBUG - 2025-04-10 12:04:03 --> UTF-8 Support Enabled
INFO - 2025-04-10 12:04:03 --> Utf8 Class Initialized
INFO - 2025-04-10 12:04:03 --> URI Class Initialized
INFO - 2025-04-10 12:04:03 --> Router Class Initialized
INFO - 2025-04-10 12:04:03 --> Output Class Initialized
INFO - 2025-04-10 12:04:03 --> Security Class Initialized
DEBUG - 2025-04-10 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 12:04:03 --> Input Class Initialized
INFO - 2025-04-10 12:04:03 --> Language Class Initialized
INFO - 2025-04-10 12:04:03 --> Language Class Initialized
INFO - 2025-04-10 12:04:03 --> Config Class Initialized
INFO - 2025-04-10 12:04:03 --> Loader Class Initialized
INFO - 2025-04-10 12:04:03 --> Helper loaded: url_helper
INFO - 2025-04-10 12:04:03 --> Helper loaded: file_helper
INFO - 2025-04-10 12:04:03 --> Helper loaded: html_helper
INFO - 2025-04-10 12:04:03 --> Helper loaded: form_helper
INFO - 2025-04-10 12:04:03 --> Helper loaded: text_helper
INFO - 2025-04-10 12:04:03 --> Helper loaded: lang_helper
INFO - 2025-04-10 12:04:03 --> Helper loaded: directory_helper
INFO - 2025-04-10 12:04:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 12:04:03 --> Database Driver Class Initialized
INFO - 2025-04-10 12:04:03 --> Email Class Initialized
INFO - 2025-04-10 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 12:04:03 --> Form Validation Class Initialized
INFO - 2025-04-10 12:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 12:04:03 --> Pagination Class Initialized
INFO - 2025-04-10 12:04:03 --> Controller Class Initialized
INFO - 2025-04-10 12:04:03 --> Model Class Initialized
INFO - 2025-04-10 12:04:03 --> Helper loaded: security_helper
DEBUG - 2025-04-10 12:04:03 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 12:04:03 --> Final output sent to browser
DEBUG - 2025-04-10 12:04:03 --> Total execution time: 0.0070
INFO - 2025-04-10 12:04:20 --> Config Class Initialized
INFO - 2025-04-10 12:04:20 --> Hooks Class Initialized
DEBUG - 2025-04-10 12:04:20 --> UTF-8 Support Enabled
INFO - 2025-04-10 12:04:20 --> Utf8 Class Initialized
INFO - 2025-04-10 12:04:20 --> URI Class Initialized
INFO - 2025-04-10 12:04:20 --> Router Class Initialized
INFO - 2025-04-10 12:04:20 --> Output Class Initialized
INFO - 2025-04-10 12:04:20 --> Security Class Initialized
DEBUG - 2025-04-10 12:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-10 12:04:20 --> Input Class Initialized
INFO - 2025-04-10 12:04:20 --> Language Class Initialized
INFO - 2025-04-10 12:04:20 --> Language Class Initialized
INFO - 2025-04-10 12:04:20 --> Config Class Initialized
INFO - 2025-04-10 12:04:20 --> Loader Class Initialized
INFO - 2025-04-10 12:04:20 --> Helper loaded: url_helper
INFO - 2025-04-10 12:04:20 --> Helper loaded: file_helper
INFO - 2025-04-10 12:04:20 --> Helper loaded: html_helper
INFO - 2025-04-10 12:04:20 --> Helper loaded: form_helper
INFO - 2025-04-10 12:04:20 --> Helper loaded: text_helper
INFO - 2025-04-10 12:04:20 --> Helper loaded: lang_helper
INFO - 2025-04-10 12:04:20 --> Helper loaded: directory_helper
INFO - 2025-04-10 12:04:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-10 12:04:20 --> Database Driver Class Initialized
INFO - 2025-04-10 12:04:20 --> Email Class Initialized
INFO - 2025-04-10 12:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-10 12:04:20 --> Form Validation Class Initialized
INFO - 2025-04-10 12:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-10 12:04:20 --> Pagination Class Initialized
INFO - 2025-04-10 12:04:20 --> Controller Class Initialized
INFO - 2025-04-10 12:04:20 --> Model Class Initialized
INFO - 2025-04-10 12:04:20 --> Helper loaded: security_helper
DEBUG - 2025-04-10 12:04:20 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-10 12:04:20 --> Final output sent to browser
DEBUG - 2025-04-10 12:04:20 --> Total execution time: 0.0789
