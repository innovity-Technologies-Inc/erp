<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-28 00:00:00 --> Config Class Initialized
INFO - 2025-03-28 00:00:00 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:00:00 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:00:00 --> Utf8 Class Initialized
INFO - 2025-03-28 00:00:00 --> URI Class Initialized
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:00:00 --> Router Class Initialized
INFO - 2025-03-28 00:00:00 --> Output Class Initialized
INFO - 2025-03-28 00:00:00 --> Security Class Initialized
DEBUG - 2025-03-28 00:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:00:00 --> Input Class Initialized
INFO - 2025-03-28 00:00:00 --> Language Class Initialized
INFO - 2025-03-28 00:00:00 --> Language Class Initialized
INFO - 2025-03-28 00:00:00 --> Config Class Initialized
INFO - 2025-03-28 00:00:00 --> Loader Class Initialized
INFO - 2025-03-28 00:00:00 --> Helper loaded: url_helper
INFO - 2025-03-28 00:00:00 --> Helper loaded: file_helper
INFO - 2025-03-28 00:00:00 --> Helper loaded: html_helper
INFO - 2025-03-28 00:00:00 --> Helper loaded: form_helper
INFO - 2025-03-28 00:00:00 --> Helper loaded: text_helper
INFO - 2025-03-28 00:00:00 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:00:00 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:00:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:00:00 --> Database Driver Class Initialized
INFO - 2025-03-28 00:00:00 --> Email Class Initialized
INFO - 2025-03-28 00:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:00:00 --> Form Validation Class Initialized
INFO - 2025-03-28 00:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:00:00 --> Pagination Class Initialized
INFO - 2025-03-28 00:00:00 --> Controller Class Initialized
DEBUG - 2025-03-28 00:00:00 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:00:00 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:00:00 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 00:00:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 00:00:00 --> Model Class Initialized
ERROR - 2025-03-28 00:00:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 00:00:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 00:00:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 00:00:00 --> Final output sent to browser
DEBUG - 2025-03-28 00:00:00 --> Total execution time: 0.1109
INFO - 2025-03-28 00:00:01 --> Config Class Initialized
INFO - 2025-03-28 00:00:01 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:00:01 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:00:01 --> Utf8 Class Initialized
INFO - 2025-03-28 00:00:01 --> URI Class Initialized
DEBUG - 2025-03-28 00:00:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:00:01 --> Router Class Initialized
INFO - 2025-03-28 00:00:01 --> Output Class Initialized
INFO - 2025-03-28 00:00:01 --> Security Class Initialized
DEBUG - 2025-03-28 00:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:00:01 --> Input Class Initialized
INFO - 2025-03-28 00:00:01 --> Language Class Initialized
INFO - 2025-03-28 00:00:01 --> Language Class Initialized
INFO - 2025-03-28 00:00:01 --> Config Class Initialized
INFO - 2025-03-28 00:00:01 --> Loader Class Initialized
INFO - 2025-03-28 00:00:01 --> Helper loaded: url_helper
INFO - 2025-03-28 00:00:01 --> Helper loaded: file_helper
INFO - 2025-03-28 00:00:01 --> Helper loaded: html_helper
INFO - 2025-03-28 00:00:01 --> Helper loaded: form_helper
INFO - 2025-03-28 00:00:01 --> Helper loaded: text_helper
INFO - 2025-03-28 00:00:01 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:00:01 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:00:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:00:01 --> Database Driver Class Initialized
INFO - 2025-03-28 00:00:01 --> Email Class Initialized
INFO - 2025-03-28 00:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:00:01 --> Form Validation Class Initialized
INFO - 2025-03-28 00:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:00:01 --> Pagination Class Initialized
INFO - 2025-03-28 00:00:01 --> Controller Class Initialized
DEBUG - 2025-03-28 00:00:01 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:00:01 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:00:01 --> Model Class Initialized
ERROR - 2025-03-28 00:00:01 --> ========= getCustomerList() START =========
ERROR - 2025-03-28 00:00:01 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-28 00:00:01 --> Received customer_id: null
ERROR - 2025-03-28 00:00:01 --> Received customfiled: null
ERROR - 2025-03-28 00:00:01 --> Pagination info: start=0, length=50
ERROR - 2025-03-28 00:00:01 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-28 00:00:01 --> Search value: 
ERROR - 2025-03-28 00:00:01 --> Total unfiltered records: 15
ERROR - 2025-03-28 00:00:01 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-28 00:00:01 --> Records fetched from DB: 15
ERROR - 2025-03-28 00:00:01 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-28 00:00:01 --> ========= getCustomerList() END =========
INFO - 2025-03-28 00:00:11 --> Config Class Initialized
INFO - 2025-03-28 00:00:11 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:00:11 --> Utf8 Class Initialized
INFO - 2025-03-28 00:00:11 --> URI Class Initialized
DEBUG - 2025-03-28 00:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:00:11 --> Router Class Initialized
INFO - 2025-03-28 00:00:11 --> Output Class Initialized
INFO - 2025-03-28 00:00:11 --> Security Class Initialized
DEBUG - 2025-03-28 00:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:00:11 --> Input Class Initialized
INFO - 2025-03-28 00:00:11 --> Language Class Initialized
INFO - 2025-03-28 00:00:11 --> Language Class Initialized
INFO - 2025-03-28 00:00:11 --> Config Class Initialized
INFO - 2025-03-28 00:00:11 --> Loader Class Initialized
INFO - 2025-03-28 00:00:11 --> Helper loaded: url_helper
INFO - 2025-03-28 00:00:11 --> Helper loaded: file_helper
INFO - 2025-03-28 00:00:11 --> Helper loaded: html_helper
INFO - 2025-03-28 00:00:11 --> Helper loaded: form_helper
INFO - 2025-03-28 00:00:11 --> Helper loaded: text_helper
INFO - 2025-03-28 00:00:11 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:00:11 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:00:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:00:11 --> Database Driver Class Initialized
INFO - 2025-03-28 00:00:11 --> Email Class Initialized
INFO - 2025-03-28 00:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:00:11 --> Form Validation Class Initialized
INFO - 2025-03-28 00:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:00:11 --> Pagination Class Initialized
INFO - 2025-03-28 00:00:11 --> Controller Class Initialized
DEBUG - 2025-03-28 00:00:11 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:00:11 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:00:11 --> Model Class Initialized
ERROR - 2025-03-28 00:00:11 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-28 00:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 00:00:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 00:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 00:00:11 --> Model Class Initialized
ERROR - 2025-03-28 00:00:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 00:00:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 00:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 00:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 00:00:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 00:00:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 00:00:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-28 00:00:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 00:00:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 00:00:12 --> Final output sent to browser
DEBUG - 2025-03-28 00:00:12 --> Total execution time: 0.1441
INFO - 2025-03-28 00:00:17 --> Config Class Initialized
INFO - 2025-03-28 00:00:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:00:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:00:17 --> Utf8 Class Initialized
INFO - 2025-03-28 00:00:17 --> URI Class Initialized
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:00:17 --> Router Class Initialized
INFO - 2025-03-28 00:00:17 --> Output Class Initialized
INFO - 2025-03-28 00:00:17 --> Security Class Initialized
DEBUG - 2025-03-28 00:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:00:17 --> Input Class Initialized
INFO - 2025-03-28 00:00:17 --> Language Class Initialized
INFO - 2025-03-28 00:00:17 --> Language Class Initialized
INFO - 2025-03-28 00:00:17 --> Config Class Initialized
INFO - 2025-03-28 00:00:17 --> Loader Class Initialized
INFO - 2025-03-28 00:00:17 --> Helper loaded: url_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: file_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: html_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: form_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: text_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:00:17 --> Database Driver Class Initialized
INFO - 2025-03-28 00:00:17 --> Email Class Initialized
INFO - 2025-03-28 00:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:00:17 --> Form Validation Class Initialized
INFO - 2025-03-28 00:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:00:17 --> Pagination Class Initialized
INFO - 2025-03-28 00:00:17 --> Controller Class Initialized
DEBUG - 2025-03-28 00:00:17 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:00:17 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:00:17 --> Model Class Initialized
ERROR - 2025-03-28 00:00:17 --> DEBUG: File Upload Attempt - Filename: 
INFO - 2025-03-28 00:00:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 00:00:17 --> Config Class Initialized
INFO - 2025-03-28 00:00:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:00:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:00:17 --> Utf8 Class Initialized
INFO - 2025-03-28 00:00:17 --> URI Class Initialized
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:00:17 --> Router Class Initialized
INFO - 2025-03-28 00:00:17 --> Output Class Initialized
INFO - 2025-03-28 00:00:17 --> Security Class Initialized
DEBUG - 2025-03-28 00:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:00:17 --> Input Class Initialized
INFO - 2025-03-28 00:00:17 --> Language Class Initialized
INFO - 2025-03-28 00:00:17 --> Language Class Initialized
INFO - 2025-03-28 00:00:17 --> Config Class Initialized
INFO - 2025-03-28 00:00:17 --> Loader Class Initialized
INFO - 2025-03-28 00:00:17 --> Helper loaded: url_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: file_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: html_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: form_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: text_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:00:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:00:17 --> Database Driver Class Initialized
INFO - 2025-03-28 00:00:17 --> Email Class Initialized
INFO - 2025-03-28 00:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:00:17 --> Form Validation Class Initialized
INFO - 2025-03-28 00:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:00:17 --> Pagination Class Initialized
INFO - 2025-03-28 00:00:17 --> Controller Class Initialized
DEBUG - 2025-03-28 00:00:17 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:00:17 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:00:17 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 00:00:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 00:00:17 --> Model Class Initialized
ERROR - 2025-03-28 00:00:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 00:00:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 00:00:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 00:00:17 --> Final output sent to browser
DEBUG - 2025-03-28 00:00:17 --> Total execution time: 0.1110
INFO - 2025-03-28 00:00:18 --> Config Class Initialized
INFO - 2025-03-28 00:00:18 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:00:18 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:00:18 --> Utf8 Class Initialized
INFO - 2025-03-28 00:00:18 --> URI Class Initialized
DEBUG - 2025-03-28 00:00:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:00:18 --> Router Class Initialized
INFO - 2025-03-28 00:00:18 --> Output Class Initialized
INFO - 2025-03-28 00:00:18 --> Security Class Initialized
DEBUG - 2025-03-28 00:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:00:18 --> Input Class Initialized
INFO - 2025-03-28 00:00:18 --> Language Class Initialized
INFO - 2025-03-28 00:00:18 --> Language Class Initialized
INFO - 2025-03-28 00:00:18 --> Config Class Initialized
INFO - 2025-03-28 00:00:18 --> Loader Class Initialized
INFO - 2025-03-28 00:00:18 --> Helper loaded: url_helper
INFO - 2025-03-28 00:00:18 --> Helper loaded: file_helper
INFO - 2025-03-28 00:00:18 --> Helper loaded: html_helper
INFO - 2025-03-28 00:00:18 --> Helper loaded: form_helper
INFO - 2025-03-28 00:00:18 --> Helper loaded: text_helper
INFO - 2025-03-28 00:00:18 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:00:18 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:00:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:00:18 --> Database Driver Class Initialized
INFO - 2025-03-28 00:00:18 --> Email Class Initialized
INFO - 2025-03-28 00:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:00:18 --> Form Validation Class Initialized
INFO - 2025-03-28 00:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:00:18 --> Pagination Class Initialized
INFO - 2025-03-28 00:00:18 --> Controller Class Initialized
DEBUG - 2025-03-28 00:00:18 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:00:18 --> Model Class Initialized
DEBUG - 2025-03-28 00:00:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:00:18 --> Model Class Initialized
ERROR - 2025-03-28 00:00:18 --> ========= getCustomerList() START =========
ERROR - 2025-03-28 00:00:18 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-28 00:00:18 --> Received customer_id: null
ERROR - 2025-03-28 00:00:18 --> Received customfiled: null
ERROR - 2025-03-28 00:00:18 --> Pagination info: start=0, length=50
ERROR - 2025-03-28 00:00:18 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-28 00:00:18 --> Search value: 
ERROR - 2025-03-28 00:00:18 --> Total unfiltered records: 15
ERROR - 2025-03-28 00:00:18 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-28 00:00:18 --> Records fetched from DB: 15
ERROR - 2025-03-28 00:00:18 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-28 00:00:18 --> ========= getCustomerList() END =========
INFO - 2025-03-28 00:17:29 --> Config Class Initialized
INFO - 2025-03-28 00:17:29 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:17:29 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:17:29 --> Utf8 Class Initialized
INFO - 2025-03-28 00:17:29 --> URI Class Initialized
INFO - 2025-03-28 00:17:29 --> Router Class Initialized
INFO - 2025-03-28 00:17:29 --> Output Class Initialized
INFO - 2025-03-28 00:17:29 --> Security Class Initialized
DEBUG - 2025-03-28 00:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:17:29 --> Input Class Initialized
INFO - 2025-03-28 00:17:29 --> Language Class Initialized
INFO - 2025-03-28 00:17:29 --> Language Class Initialized
INFO - 2025-03-28 00:17:29 --> Config Class Initialized
INFO - 2025-03-28 00:17:29 --> Loader Class Initialized
INFO - 2025-03-28 00:17:29 --> Helper loaded: url_helper
INFO - 2025-03-28 00:17:29 --> Helper loaded: file_helper
INFO - 2025-03-28 00:17:29 --> Helper loaded: html_helper
INFO - 2025-03-28 00:17:29 --> Helper loaded: form_helper
INFO - 2025-03-28 00:17:29 --> Helper loaded: text_helper
INFO - 2025-03-28 00:17:29 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:17:29 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:17:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:17:29 --> Database Driver Class Initialized
INFO - 2025-03-28 00:17:29 --> Email Class Initialized
INFO - 2025-03-28 00:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:17:29 --> Form Validation Class Initialized
INFO - 2025-03-28 00:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:17:29 --> Pagination Class Initialized
INFO - 2025-03-28 00:17:29 --> Controller Class Initialized
INFO - 2025-03-28 00:17:29 --> Model Class Initialized
INFO - 2025-03-28 00:17:29 --> Final output sent to browser
DEBUG - 2025-03-28 00:17:29 --> Total execution time: 0.0227
INFO - 2025-03-28 00:18:16 --> Config Class Initialized
INFO - 2025-03-28 00:18:16 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:18:16 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:18:16 --> Utf8 Class Initialized
INFO - 2025-03-28 00:18:16 --> URI Class Initialized
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:18:16 --> Router Class Initialized
INFO - 2025-03-28 00:18:16 --> Output Class Initialized
INFO - 2025-03-28 00:18:16 --> Security Class Initialized
DEBUG - 2025-03-28 00:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:18:16 --> Input Class Initialized
INFO - 2025-03-28 00:18:16 --> Language Class Initialized
INFO - 2025-03-28 00:18:16 --> Language Class Initialized
INFO - 2025-03-28 00:18:16 --> Config Class Initialized
INFO - 2025-03-28 00:18:16 --> Loader Class Initialized
INFO - 2025-03-28 00:18:16 --> Helper loaded: url_helper
INFO - 2025-03-28 00:18:16 --> Helper loaded: file_helper
INFO - 2025-03-28 00:18:16 --> Helper loaded: html_helper
INFO - 2025-03-28 00:18:16 --> Helper loaded: form_helper
INFO - 2025-03-28 00:18:16 --> Helper loaded: text_helper
INFO - 2025-03-28 00:18:16 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:18:16 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:18:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:18:16 --> Database Driver Class Initialized
INFO - 2025-03-28 00:18:16 --> Email Class Initialized
INFO - 2025-03-28 00:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:18:16 --> Form Validation Class Initialized
INFO - 2025-03-28 00:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:18:16 --> Pagination Class Initialized
INFO - 2025-03-28 00:18:16 --> Controller Class Initialized
DEBUG - 2025-03-28 00:18:16 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:18:16 --> Model Class Initialized
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:18:16 --> Model Class Initialized
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 00:18:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 00:18:16 --> Model Class Initialized
ERROR - 2025-03-28 00:18:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 00:18:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 00:18:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 00:18:16 --> Final output sent to browser
DEBUG - 2025-03-28 00:18:16 --> Total execution time: 0.1989
INFO - 2025-03-28 00:18:17 --> Config Class Initialized
INFO - 2025-03-28 00:18:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:18:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:18:17 --> Utf8 Class Initialized
INFO - 2025-03-28 00:18:17 --> URI Class Initialized
DEBUG - 2025-03-28 00:18:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:18:17 --> Router Class Initialized
INFO - 2025-03-28 00:18:17 --> Output Class Initialized
INFO - 2025-03-28 00:18:17 --> Security Class Initialized
DEBUG - 2025-03-28 00:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:18:17 --> Input Class Initialized
INFO - 2025-03-28 00:18:17 --> Language Class Initialized
INFO - 2025-03-28 00:18:17 --> Language Class Initialized
INFO - 2025-03-28 00:18:17 --> Config Class Initialized
INFO - 2025-03-28 00:18:17 --> Loader Class Initialized
INFO - 2025-03-28 00:18:17 --> Helper loaded: url_helper
INFO - 2025-03-28 00:18:17 --> Helper loaded: file_helper
INFO - 2025-03-28 00:18:17 --> Helper loaded: html_helper
INFO - 2025-03-28 00:18:17 --> Helper loaded: form_helper
INFO - 2025-03-28 00:18:17 --> Helper loaded: text_helper
INFO - 2025-03-28 00:18:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:18:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:18:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:18:17 --> Database Driver Class Initialized
INFO - 2025-03-28 00:18:17 --> Email Class Initialized
INFO - 2025-03-28 00:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:18:17 --> Form Validation Class Initialized
INFO - 2025-03-28 00:18:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:18:17 --> Pagination Class Initialized
INFO - 2025-03-28 00:18:17 --> Controller Class Initialized
DEBUG - 2025-03-28 00:18:17 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:18:17 --> Model Class Initialized
DEBUG - 2025-03-28 00:18:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:18:17 --> Model Class Initialized
ERROR - 2025-03-28 00:18:17 --> ========= getCustomerList() START =========
ERROR - 2025-03-28 00:18:17 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-28 00:18:17 --> Received customer_id: null
ERROR - 2025-03-28 00:18:17 --> Received customfiled: null
ERROR - 2025-03-28 00:18:17 --> Pagination info: start=0, length=50
ERROR - 2025-03-28 00:18:17 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-28 00:18:17 --> Search value: 
ERROR - 2025-03-28 00:18:17 --> Total unfiltered records: 15
ERROR - 2025-03-28 00:18:17 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-28 00:18:17 --> Records fetched from DB: 15
ERROR - 2025-03-28 00:18:17 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-28 00:18:17 --> ========= getCustomerList() END =========
INFO - 2025-03-28 00:18:35 --> Config Class Initialized
INFO - 2025-03-28 00:18:35 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:18:35 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:18:35 --> Utf8 Class Initialized
INFO - 2025-03-28 00:18:35 --> URI Class Initialized
INFO - 2025-03-28 00:18:35 --> Router Class Initialized
INFO - 2025-03-28 00:18:35 --> Output Class Initialized
INFO - 2025-03-28 00:18:35 --> Security Class Initialized
DEBUG - 2025-03-28 00:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:18:35 --> Input Class Initialized
INFO - 2025-03-28 00:18:35 --> Language Class Initialized
INFO - 2025-03-28 00:18:35 --> Language Class Initialized
INFO - 2025-03-28 00:18:35 --> Config Class Initialized
INFO - 2025-03-28 00:18:35 --> Loader Class Initialized
INFO - 2025-03-28 00:18:35 --> Helper loaded: url_helper
INFO - 2025-03-28 00:18:35 --> Helper loaded: file_helper
INFO - 2025-03-28 00:18:35 --> Helper loaded: html_helper
INFO - 2025-03-28 00:18:35 --> Helper loaded: form_helper
INFO - 2025-03-28 00:18:35 --> Helper loaded: text_helper
INFO - 2025-03-28 00:18:35 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:18:35 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:18:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:18:35 --> Database Driver Class Initialized
INFO - 2025-03-28 00:18:35 --> Email Class Initialized
INFO - 2025-03-28 00:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:18:35 --> Form Validation Class Initialized
INFO - 2025-03-28 00:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:18:35 --> Pagination Class Initialized
INFO - 2025-03-28 00:18:35 --> Controller Class Initialized
INFO - 2025-03-28 00:18:35 --> Model Class Initialized
INFO - 2025-03-28 00:18:35 --> Final output sent to browser
DEBUG - 2025-03-28 00:18:35 --> Total execution time: 0.0095
INFO - 2025-03-28 00:18:45 --> Config Class Initialized
INFO - 2025-03-28 00:18:45 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:18:45 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:18:45 --> Utf8 Class Initialized
INFO - 2025-03-28 00:18:45 --> URI Class Initialized
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:18:45 --> Router Class Initialized
INFO - 2025-03-28 00:18:45 --> Output Class Initialized
INFO - 2025-03-28 00:18:45 --> Security Class Initialized
DEBUG - 2025-03-28 00:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:18:45 --> Input Class Initialized
INFO - 2025-03-28 00:18:45 --> Language Class Initialized
INFO - 2025-03-28 00:18:45 --> Language Class Initialized
INFO - 2025-03-28 00:18:45 --> Config Class Initialized
INFO - 2025-03-28 00:18:45 --> Loader Class Initialized
INFO - 2025-03-28 00:18:45 --> Helper loaded: url_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: file_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: html_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: form_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: text_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:18:45 --> Database Driver Class Initialized
INFO - 2025-03-28 00:18:45 --> Email Class Initialized
INFO - 2025-03-28 00:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:18:45 --> Form Validation Class Initialized
INFO - 2025-03-28 00:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:18:45 --> Pagination Class Initialized
INFO - 2025-03-28 00:18:45 --> Controller Class Initialized
DEBUG - 2025-03-28 00:18:45 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:18:45 --> Model Class Initialized
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:18:45 --> Model Class Initialized
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 00:18:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 00:18:45 --> Model Class Initialized
ERROR - 2025-03-28 00:18:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 00:18:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 00:18:45 --> Final output sent to browser
DEBUG - 2025-03-28 00:18:45 --> Total execution time: 0.1100
INFO - 2025-03-28 00:18:45 --> Config Class Initialized
INFO - 2025-03-28 00:18:45 --> Hooks Class Initialized
DEBUG - 2025-03-28 00:18:45 --> UTF-8 Support Enabled
INFO - 2025-03-28 00:18:45 --> Utf8 Class Initialized
INFO - 2025-03-28 00:18:45 --> URI Class Initialized
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-28 00:18:45 --> Router Class Initialized
INFO - 2025-03-28 00:18:45 --> Output Class Initialized
INFO - 2025-03-28 00:18:45 --> Security Class Initialized
DEBUG - 2025-03-28 00:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 00:18:45 --> Input Class Initialized
INFO - 2025-03-28 00:18:45 --> Language Class Initialized
INFO - 2025-03-28 00:18:45 --> Language Class Initialized
INFO - 2025-03-28 00:18:45 --> Config Class Initialized
INFO - 2025-03-28 00:18:45 --> Loader Class Initialized
INFO - 2025-03-28 00:18:45 --> Helper loaded: url_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: file_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: html_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: form_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: text_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: lang_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: directory_helper
INFO - 2025-03-28 00:18:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 00:18:45 --> Database Driver Class Initialized
INFO - 2025-03-28 00:18:45 --> Email Class Initialized
INFO - 2025-03-28 00:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 00:18:45 --> Form Validation Class Initialized
INFO - 2025-03-28 00:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 00:18:45 --> Pagination Class Initialized
INFO - 2025-03-28 00:18:45 --> Controller Class Initialized
DEBUG - 2025-03-28 00:18:45 --> Customer MX_Controller Initialized
INFO - 2025-03-28 00:18:45 --> Model Class Initialized
DEBUG - 2025-03-28 00:18:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 00:18:45 --> Model Class Initialized
ERROR - 2025-03-28 00:18:45 --> ========= getCustomerList() START =========
ERROR - 2025-03-28 00:18:45 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-28 00:18:45 --> Received customer_id: null
ERROR - 2025-03-28 00:18:45 --> Received customfiled: null
ERROR - 2025-03-28 00:18:45 --> Pagination info: start=0, length=50
ERROR - 2025-03-28 00:18:45 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-28 00:18:45 --> Search value: 
ERROR - 2025-03-28 00:18:45 --> Total unfiltered records: 15
ERROR - 2025-03-28 00:18:45 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-28 00:18:45 --> Records fetched from DB: 15
ERROR - 2025-03-28 00:18:45 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-28 00:18:45 --> ========= getCustomerList() END =========
INFO - 2025-03-28 09:27:21 --> Config Class Initialized
INFO - 2025-03-28 09:27:21 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:21 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:21 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:21 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:27:21 --> Router Class Initialized
INFO - 2025-03-28 09:27:21 --> Output Class Initialized
INFO - 2025-03-28 09:27:21 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:21 --> Input Class Initialized
INFO - 2025-03-28 09:27:21 --> Language Class Initialized
INFO - 2025-03-28 09:27:21 --> Language Class Initialized
INFO - 2025-03-28 09:27:21 --> Config Class Initialized
INFO - 2025-03-28 09:27:21 --> Loader Class Initialized
INFO - 2025-03-28 09:27:21 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:21 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:21 --> Email Class Initialized
INFO - 2025-03-28 09:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:21 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:21 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:21 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:21 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:27:21 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:27:21 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:27:21 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:27:21 --> Model Class Initialized
INFO - 2025-03-28 09:27:21 --> Config Class Initialized
INFO - 2025-03-28 09:27:21 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:21 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:21 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:21 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 09:27:21 --> Router Class Initialized
INFO - 2025-03-28 09:27:21 --> Output Class Initialized
INFO - 2025-03-28 09:27:21 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:21 --> Input Class Initialized
INFO - 2025-03-28 09:27:21 --> Language Class Initialized
INFO - 2025-03-28 09:27:21 --> Language Class Initialized
INFO - 2025-03-28 09:27:21 --> Config Class Initialized
INFO - 2025-03-28 09:27:21 --> Loader Class Initialized
INFO - 2025-03-28 09:27:21 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:21 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:21 --> Email Class Initialized
INFO - 2025-03-28 09:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:21 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:21 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:21 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:21 --> Auth MX_Controller Initialized
INFO - 2025-03-28 09:27:21 --> Model Class Initialized
DEBUG - 2025-03-28 09:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-28 09:27:21 --> Model Class Initialized
DEBUG - 2025-03-28 09:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 09:27:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 09:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 09:27:21 --> Model Class Initialized
DEBUG - 2025-03-28 09:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-28 09:27:21 --> Final output sent to browser
DEBUG - 2025-03-28 09:27:21 --> Total execution time: 0.0195
INFO - 2025-03-28 09:27:35 --> Config Class Initialized
INFO - 2025-03-28 09:27:35 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:35 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:35 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:35 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 09:27:35 --> Router Class Initialized
INFO - 2025-03-28 09:27:35 --> Output Class Initialized
INFO - 2025-03-28 09:27:35 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:35 --> Input Class Initialized
INFO - 2025-03-28 09:27:35 --> Language Class Initialized
INFO - 2025-03-28 09:27:35 --> Language Class Initialized
INFO - 2025-03-28 09:27:35 --> Config Class Initialized
INFO - 2025-03-28 09:27:35 --> Loader Class Initialized
INFO - 2025-03-28 09:27:35 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:35 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:35 --> Email Class Initialized
INFO - 2025-03-28 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:35 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:35 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:35 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:35 --> Auth MX_Controller Initialized
INFO - 2025-03-28 09:27:35 --> Model Class Initialized
DEBUG - 2025-03-28 09:27:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-28 09:27:35 --> Model Class Initialized
INFO - 2025-03-28 09:27:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 09:27:35 --> Config Class Initialized
INFO - 2025-03-28 09:27:35 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:35 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:35 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:35 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 09:27:35 --> Router Class Initialized
INFO - 2025-03-28 09:27:35 --> Output Class Initialized
INFO - 2025-03-28 09:27:35 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:35 --> Input Class Initialized
INFO - 2025-03-28 09:27:35 --> Language Class Initialized
INFO - 2025-03-28 09:27:35 --> Language Class Initialized
INFO - 2025-03-28 09:27:35 --> Config Class Initialized
INFO - 2025-03-28 09:27:35 --> Loader Class Initialized
INFO - 2025-03-28 09:27:35 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:35 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:35 --> Email Class Initialized
INFO - 2025-03-28 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:35 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:35 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:35 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:35 --> Home MX_Controller Initialized
INFO - 2025-03-28 09:27:35 --> Model Class Initialized
DEBUG - 2025-03-28 09:27:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-28 09:27:35 --> Model Class Initialized
DEBUG - 2025-03-28 09:27:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 09:27:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 09:27:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 09:27:35 --> Model Class Initialized
ERROR - 2025-03-28 09:27:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 09:27:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 09:27:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 09:27:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 09:27:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 09:27:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 09:27:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-28 09:27:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 09:27:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 09:27:36 --> Final output sent to browser
DEBUG - 2025-03-28 09:27:36 --> Total execution time: 0.7289
INFO - 2025-03-28 09:27:40 --> Config Class Initialized
INFO - 2025-03-28 09:27:40 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:40 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:40 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:40 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:27:40 --> Router Class Initialized
INFO - 2025-03-28 09:27:40 --> Output Class Initialized
INFO - 2025-03-28 09:27:40 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:40 --> Input Class Initialized
INFO - 2025-03-28 09:27:40 --> Language Class Initialized
INFO - 2025-03-28 09:27:40 --> Language Class Initialized
INFO - 2025-03-28 09:27:40 --> Config Class Initialized
INFO - 2025-03-28 09:27:40 --> Loader Class Initialized
INFO - 2025-03-28 09:27:40 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:40 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:40 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:40 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:40 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:40 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:40 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:40 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:40 --> Email Class Initialized
INFO - 2025-03-28 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:40 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:40 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:40 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:40 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:27:40 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:27:40 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:27:40 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:27:40 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 15:27:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 15:27:41 --> Model Class Initialized
ERROR - 2025-03-28 15:27:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 15:27:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 15:27:41 --> Final output sent to browser
DEBUG - 2025-03-28 15:27:41 --> Total execution time: 0.1427
INFO - 2025-03-28 09:27:41 --> Config Class Initialized
INFO - 2025-03-28 09:27:41 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:41 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:41 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:41 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:27:41 --> Router Class Initialized
INFO - 2025-03-28 09:27:41 --> Output Class Initialized
INFO - 2025-03-28 09:27:41 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:41 --> Input Class Initialized
INFO - 2025-03-28 09:27:41 --> Language Class Initialized
INFO - 2025-03-28 09:27:41 --> Language Class Initialized
INFO - 2025-03-28 09:27:41 --> Config Class Initialized
INFO - 2025-03-28 09:27:41 --> Loader Class Initialized
INFO - 2025-03-28 09:27:41 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:41 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:41 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:41 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:41 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:41 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:41 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:41 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:41 --> Email Class Initialized
INFO - 2025-03-28 09:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:41 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:41 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:41 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:41 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:27:41 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:27:41 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:27:41 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:27:41 --> Model Class Initialized
INFO - 2025-03-28 15:27:41 --> Final output sent to browser
DEBUG - 2025-03-28 15:27:41 --> Total execution time: 0.0565
INFO - 2025-03-28 09:27:46 --> Config Class Initialized
INFO - 2025-03-28 09:27:46 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:46 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:46 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:46 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:27:46 --> Router Class Initialized
INFO - 2025-03-28 09:27:46 --> Output Class Initialized
INFO - 2025-03-28 09:27:46 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:46 --> Input Class Initialized
INFO - 2025-03-28 09:27:46 --> Language Class Initialized
INFO - 2025-03-28 09:27:46 --> Language Class Initialized
INFO - 2025-03-28 09:27:46 --> Config Class Initialized
INFO - 2025-03-28 09:27:46 --> Loader Class Initialized
INFO - 2025-03-28 09:27:46 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:46 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:46 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:46 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:46 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:46 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:46 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:46 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:46 --> Email Class Initialized
INFO - 2025-03-28 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:46 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:46 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:46 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:46 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:27:46 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:27:46 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:27:46 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:27:46 --> Model Class Initialized
INFO - 2025-03-28 15:27:46 --> Final output sent to browser
DEBUG - 2025-03-28 15:27:46 --> Total execution time: 0.0666
INFO - 2025-03-28 09:27:51 --> Config Class Initialized
INFO - 2025-03-28 09:27:51 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:27:51 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:27:51 --> Utf8 Class Initialized
INFO - 2025-03-28 09:27:51 --> URI Class Initialized
DEBUG - 2025-03-28 09:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:27:51 --> Router Class Initialized
INFO - 2025-03-28 09:27:51 --> Output Class Initialized
INFO - 2025-03-28 09:27:51 --> Security Class Initialized
DEBUG - 2025-03-28 09:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:27:51 --> Input Class Initialized
INFO - 2025-03-28 09:27:51 --> Language Class Initialized
INFO - 2025-03-28 09:27:51 --> Language Class Initialized
INFO - 2025-03-28 09:27:51 --> Config Class Initialized
INFO - 2025-03-28 09:27:51 --> Loader Class Initialized
INFO - 2025-03-28 09:27:51 --> Helper loaded: url_helper
INFO - 2025-03-28 09:27:51 --> Helper loaded: file_helper
INFO - 2025-03-28 09:27:51 --> Helper loaded: html_helper
INFO - 2025-03-28 09:27:51 --> Helper loaded: form_helper
INFO - 2025-03-28 09:27:51 --> Helper loaded: text_helper
INFO - 2025-03-28 09:27:51 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:27:51 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:27:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:27:51 --> Database Driver Class Initialized
INFO - 2025-03-28 09:27:51 --> Email Class Initialized
INFO - 2025-03-28 09:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:27:51 --> Form Validation Class Initialized
INFO - 2025-03-28 09:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:27:51 --> Pagination Class Initialized
INFO - 2025-03-28 09:27:51 --> Controller Class Initialized
DEBUG - 2025-03-28 09:27:51 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:27:51 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:27:51 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:27:51 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:27:51 --> Model Class Initialized
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 15:27:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 15:27:51 --> Model Class Initialized
ERROR - 2025-03-28 15:27:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 15:27:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 15:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 15:27:51 --> Final output sent to browser
DEBUG - 2025-03-28 15:27:51 --> Total execution time: 0.1555
INFO - 2025-03-28 09:28:18 --> Config Class Initialized
INFO - 2025-03-28 09:28:18 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:28:18 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:28:18 --> Utf8 Class Initialized
INFO - 2025-03-28 09:28:18 --> URI Class Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-28 09:28:18 --> Router Class Initialized
INFO - 2025-03-28 09:28:18 --> Output Class Initialized
INFO - 2025-03-28 09:28:18 --> Security Class Initialized
DEBUG - 2025-03-28 09:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:28:18 --> Input Class Initialized
INFO - 2025-03-28 09:28:18 --> Language Class Initialized
INFO - 2025-03-28 09:28:18 --> Language Class Initialized
INFO - 2025-03-28 09:28:18 --> Config Class Initialized
INFO - 2025-03-28 09:28:18 --> Loader Class Initialized
INFO - 2025-03-28 09:28:18 --> Helper loaded: url_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: file_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: html_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: form_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: text_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:28:18 --> Database Driver Class Initialized
INFO - 2025-03-28 09:28:18 --> Email Class Initialized
INFO - 2025-03-28 09:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:28:18 --> Form Validation Class Initialized
INFO - 2025-03-28 09:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:28:18 --> Pagination Class Initialized
INFO - 2025-03-28 09:28:18 --> Controller Class Initialized
DEBUG - 2025-03-28 09:28:18 --> Purchase MX_Controller Initialized
INFO - 2025-03-28 09:28:18 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-28 09:28:18 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 09:28:18 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 09:28:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 09:28:18 --> Model Class Initialized
ERROR - 2025-03-28 09:28:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 09:28:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 09:28:18 --> Final output sent to browser
DEBUG - 2025-03-28 09:28:18 --> Total execution time: 0.0964
INFO - 2025-03-28 09:28:18 --> Config Class Initialized
INFO - 2025-03-28 09:28:18 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:28:18 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:28:18 --> Utf8 Class Initialized
INFO - 2025-03-28 09:28:18 --> URI Class Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-28 09:28:18 --> Router Class Initialized
INFO - 2025-03-28 09:28:18 --> Output Class Initialized
INFO - 2025-03-28 09:28:18 --> Security Class Initialized
DEBUG - 2025-03-28 09:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:28:18 --> Input Class Initialized
INFO - 2025-03-28 09:28:18 --> Language Class Initialized
INFO - 2025-03-28 09:28:18 --> Language Class Initialized
INFO - 2025-03-28 09:28:18 --> Config Class Initialized
INFO - 2025-03-28 09:28:18 --> Loader Class Initialized
INFO - 2025-03-28 09:28:18 --> Helper loaded: url_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: file_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: html_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: form_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: text_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:28:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:28:18 --> Database Driver Class Initialized
INFO - 2025-03-28 09:28:18 --> Email Class Initialized
INFO - 2025-03-28 09:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:28:18 --> Form Validation Class Initialized
INFO - 2025-03-28 09:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:28:18 --> Pagination Class Initialized
INFO - 2025-03-28 09:28:18 --> Controller Class Initialized
DEBUG - 2025-03-28 09:28:18 --> Purchase MX_Controller Initialized
INFO - 2025-03-28 09:28:18 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-28 09:28:18 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 09:28:18 --> Model Class Initialized
INFO - 2025-03-28 09:28:18 --> Final output sent to browser
DEBUG - 2025-03-28 09:28:18 --> Total execution time: 0.0299
INFO - 2025-03-28 09:28:21 --> Config Class Initialized
INFO - 2025-03-28 09:28:21 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:28:21 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:28:21 --> Utf8 Class Initialized
INFO - 2025-03-28 09:28:21 --> URI Class Initialized
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-28 09:28:21 --> Router Class Initialized
INFO - 2025-03-28 09:28:21 --> Output Class Initialized
INFO - 2025-03-28 09:28:21 --> Security Class Initialized
DEBUG - 2025-03-28 09:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:28:21 --> Input Class Initialized
INFO - 2025-03-28 09:28:21 --> Language Class Initialized
INFO - 2025-03-28 09:28:21 --> Language Class Initialized
INFO - 2025-03-28 09:28:21 --> Config Class Initialized
INFO - 2025-03-28 09:28:21 --> Loader Class Initialized
INFO - 2025-03-28 09:28:21 --> Helper loaded: url_helper
INFO - 2025-03-28 09:28:21 --> Helper loaded: file_helper
INFO - 2025-03-28 09:28:21 --> Helper loaded: html_helper
INFO - 2025-03-28 09:28:21 --> Helper loaded: form_helper
INFO - 2025-03-28 09:28:21 --> Helper loaded: text_helper
INFO - 2025-03-28 09:28:21 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:28:21 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:28:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:28:21 --> Database Driver Class Initialized
INFO - 2025-03-28 09:28:21 --> Email Class Initialized
INFO - 2025-03-28 09:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:28:21 --> Form Validation Class Initialized
INFO - 2025-03-28 09:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:28:21 --> Pagination Class Initialized
INFO - 2025-03-28 09:28:21 --> Controller Class Initialized
DEBUG - 2025-03-28 09:28:21 --> Purchase MX_Controller Initialized
INFO - 2025-03-28 09:28:21 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-28 09:28:21 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 09:28:21 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 09:28:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 09:28:21 --> Model Class Initialized
ERROR - 2025-03-28 09:28:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 09:28:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 09:28:21 --> Final output sent to browser
DEBUG - 2025-03-28 09:28:21 --> Total execution time: 0.1486
INFO - 2025-03-28 09:28:21 --> Config Class Initialized
INFO - 2025-03-28 09:28:21 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:28:21 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:28:21 --> Utf8 Class Initialized
INFO - 2025-03-28 09:28:21 --> URI Class Initialized
DEBUG - 2025-03-28 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-28 09:28:22 --> Router Class Initialized
INFO - 2025-03-28 09:28:22 --> Output Class Initialized
INFO - 2025-03-28 09:28:22 --> Security Class Initialized
DEBUG - 2025-03-28 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:28:22 --> Input Class Initialized
INFO - 2025-03-28 09:28:22 --> Language Class Initialized
INFO - 2025-03-28 09:28:22 --> Language Class Initialized
INFO - 2025-03-28 09:28:22 --> Config Class Initialized
INFO - 2025-03-28 09:28:22 --> Loader Class Initialized
INFO - 2025-03-28 09:28:22 --> Helper loaded: url_helper
INFO - 2025-03-28 09:28:22 --> Helper loaded: file_helper
INFO - 2025-03-28 09:28:22 --> Helper loaded: html_helper
INFO - 2025-03-28 09:28:22 --> Helper loaded: form_helper
INFO - 2025-03-28 09:28:22 --> Helper loaded: text_helper
INFO - 2025-03-28 09:28:22 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:28:22 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:28:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:28:22 --> Database Driver Class Initialized
INFO - 2025-03-28 09:28:22 --> Email Class Initialized
INFO - 2025-03-28 09:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:28:22 --> Form Validation Class Initialized
INFO - 2025-03-28 09:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:28:22 --> Pagination Class Initialized
INFO - 2025-03-28 09:28:22 --> Controller Class Initialized
DEBUG - 2025-03-28 09:28:22 --> Purchase MX_Controller Initialized
INFO - 2025-03-28 09:28:22 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-28 09:28:22 --> Model Class Initialized
DEBUG - 2025-03-28 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 09:28:22 --> Model Class Initialized
INFO - 2025-03-28 09:28:22 --> Final output sent to browser
DEBUG - 2025-03-28 09:28:22 --> Total execution time: 0.0331
INFO - 2025-03-28 09:28:29 --> Config Class Initialized
INFO - 2025-03-28 09:28:29 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:28:29 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:28:29 --> Utf8 Class Initialized
INFO - 2025-03-28 09:28:29 --> URI Class Initialized
DEBUG - 2025-03-28 09:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:28:29 --> Router Class Initialized
INFO - 2025-03-28 09:28:29 --> Output Class Initialized
INFO - 2025-03-28 09:28:29 --> Security Class Initialized
DEBUG - 2025-03-28 09:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:28:29 --> Input Class Initialized
INFO - 2025-03-28 09:28:29 --> Language Class Initialized
INFO - 2025-03-28 09:28:29 --> Language Class Initialized
INFO - 2025-03-28 09:28:29 --> Config Class Initialized
INFO - 2025-03-28 09:28:29 --> Loader Class Initialized
INFO - 2025-03-28 09:28:29 --> Helper loaded: url_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: file_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: html_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: form_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: text_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:28:29 --> Database Driver Class Initialized
INFO - 2025-03-28 09:28:29 --> Email Class Initialized
INFO - 2025-03-28 09:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:28:29 --> Form Validation Class Initialized
INFO - 2025-03-28 09:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:28:29 --> Pagination Class Initialized
INFO - 2025-03-28 09:28:29 --> Controller Class Initialized
DEBUG - 2025-03-28 09:28:29 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 15:28:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
ERROR - 2025-03-28 15:28:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 15:28:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 15:28:29 --> Final output sent to browser
DEBUG - 2025-03-28 15:28:29 --> Total execution time: 0.0877
INFO - 2025-03-28 09:28:29 --> Config Class Initialized
INFO - 2025-03-28 09:28:29 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:28:29 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:28:29 --> Utf8 Class Initialized
INFO - 2025-03-28 09:28:29 --> URI Class Initialized
DEBUG - 2025-03-28 09:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:28:29 --> Router Class Initialized
INFO - 2025-03-28 09:28:29 --> Output Class Initialized
INFO - 2025-03-28 09:28:29 --> Security Class Initialized
DEBUG - 2025-03-28 09:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:28:29 --> Input Class Initialized
INFO - 2025-03-28 09:28:29 --> Language Class Initialized
INFO - 2025-03-28 09:28:29 --> Language Class Initialized
INFO - 2025-03-28 09:28:29 --> Config Class Initialized
INFO - 2025-03-28 09:28:29 --> Loader Class Initialized
INFO - 2025-03-28 09:28:29 --> Helper loaded: url_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: file_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: html_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: form_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: text_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:28:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:28:29 --> Database Driver Class Initialized
INFO - 2025-03-28 09:28:29 --> Email Class Initialized
INFO - 2025-03-28 09:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:28:29 --> Form Validation Class Initialized
INFO - 2025-03-28 09:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:28:29 --> Pagination Class Initialized
INFO - 2025-03-28 09:28:29 --> Controller Class Initialized
DEBUG - 2025-03-28 09:28:29 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:28:29 --> Model Class Initialized
INFO - 2025-03-28 15:28:29 --> Final output sent to browser
DEBUG - 2025-03-28 15:28:29 --> Total execution time: 0.0792
INFO - 2025-03-28 09:28:54 --> Config Class Initialized
INFO - 2025-03-28 09:28:54 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:28:54 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:28:54 --> Utf8 Class Initialized
INFO - 2025-03-28 09:28:54 --> URI Class Initialized
DEBUG - 2025-03-28 09:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:28:54 --> Router Class Initialized
INFO - 2025-03-28 09:28:54 --> Output Class Initialized
INFO - 2025-03-28 09:28:54 --> Security Class Initialized
DEBUG - 2025-03-28 09:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:28:54 --> Input Class Initialized
INFO - 2025-03-28 09:28:54 --> Language Class Initialized
INFO - 2025-03-28 09:28:54 --> Language Class Initialized
INFO - 2025-03-28 09:28:54 --> Config Class Initialized
INFO - 2025-03-28 09:28:54 --> Loader Class Initialized
INFO - 2025-03-28 09:28:54 --> Helper loaded: url_helper
INFO - 2025-03-28 09:28:54 --> Helper loaded: file_helper
INFO - 2025-03-28 09:28:54 --> Helper loaded: html_helper
INFO - 2025-03-28 09:28:54 --> Helper loaded: form_helper
INFO - 2025-03-28 09:28:54 --> Helper loaded: text_helper
INFO - 2025-03-28 09:28:54 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:28:54 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:28:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:28:54 --> Database Driver Class Initialized
INFO - 2025-03-28 09:28:54 --> Email Class Initialized
INFO - 2025-03-28 09:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:28:54 --> Form Validation Class Initialized
INFO - 2025-03-28 09:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:28:54 --> Pagination Class Initialized
INFO - 2025-03-28 09:28:54 --> Controller Class Initialized
DEBUG - 2025-03-28 09:28:54 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:28:54 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:28:54 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:28:54 --> Model Class Initialized
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:28:54 --> Model Class Initialized
ERROR - 2025-03-28 15:28:54 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-28 15:28:54 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-28 15:28:54 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-28 15:28:54 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 15:28:54 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 15:28:54 --> Model Class Initialized
ERROR - 2025-03-28 15:28:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 15:28:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-28 15:28:54 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 15:28:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 15:28:54 --> Final output sent to browser
DEBUG - 2025-03-28 15:28:54 --> Total execution time: 0.0951
INFO - 2025-03-28 09:29:03 --> Config Class Initialized
INFO - 2025-03-28 09:29:03 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:29:03 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:29:03 --> Utf8 Class Initialized
INFO - 2025-03-28 09:29:03 --> URI Class Initialized
DEBUG - 2025-03-28 09:29:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:29:03 --> Router Class Initialized
INFO - 2025-03-28 09:29:03 --> Output Class Initialized
INFO - 2025-03-28 09:29:03 --> Security Class Initialized
DEBUG - 2025-03-28 09:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:29:03 --> Input Class Initialized
INFO - 2025-03-28 09:29:03 --> Language Class Initialized
INFO - 2025-03-28 09:29:03 --> Language Class Initialized
INFO - 2025-03-28 09:29:03 --> Config Class Initialized
INFO - 2025-03-28 09:29:03 --> Loader Class Initialized
INFO - 2025-03-28 09:29:03 --> Helper loaded: url_helper
INFO - 2025-03-28 09:29:03 --> Helper loaded: file_helper
INFO - 2025-03-28 09:29:03 --> Helper loaded: html_helper
INFO - 2025-03-28 09:29:03 --> Helper loaded: form_helper
INFO - 2025-03-28 09:29:03 --> Helper loaded: text_helper
INFO - 2025-03-28 09:29:03 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:29:03 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:29:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:29:03 --> Database Driver Class Initialized
INFO - 2025-03-28 09:29:03 --> Email Class Initialized
INFO - 2025-03-28 09:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:29:03 --> Form Validation Class Initialized
INFO - 2025-03-28 09:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:29:03 --> Pagination Class Initialized
INFO - 2025-03-28 09:29:03 --> Controller Class Initialized
DEBUG - 2025-03-28 09:29:03 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:29:03 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:29:03 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:29:03 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:29:03 --> Model Class Initialized
INFO - 2025-03-28 15:29:03 --> Final output sent to browser
DEBUG - 2025-03-28 15:29:03 --> Total execution time: 0.0156
INFO - 2025-03-28 09:29:04 --> Config Class Initialized
INFO - 2025-03-28 09:29:04 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:29:04 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:29:04 --> Utf8 Class Initialized
INFO - 2025-03-28 09:29:04 --> URI Class Initialized
DEBUG - 2025-03-28 09:29:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:29:04 --> Router Class Initialized
INFO - 2025-03-28 09:29:04 --> Output Class Initialized
INFO - 2025-03-28 09:29:04 --> Security Class Initialized
DEBUG - 2025-03-28 09:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:29:04 --> Input Class Initialized
INFO - 2025-03-28 09:29:04 --> Language Class Initialized
INFO - 2025-03-28 09:29:04 --> Language Class Initialized
INFO - 2025-03-28 09:29:04 --> Config Class Initialized
INFO - 2025-03-28 09:29:04 --> Loader Class Initialized
INFO - 2025-03-28 09:29:04 --> Helper loaded: url_helper
INFO - 2025-03-28 09:29:04 --> Helper loaded: file_helper
INFO - 2025-03-28 09:29:04 --> Helper loaded: html_helper
INFO - 2025-03-28 09:29:04 --> Helper loaded: form_helper
INFO - 2025-03-28 09:29:04 --> Helper loaded: text_helper
INFO - 2025-03-28 09:29:04 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:29:04 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:29:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:29:04 --> Database Driver Class Initialized
INFO - 2025-03-28 09:29:04 --> Email Class Initialized
INFO - 2025-03-28 09:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:29:04 --> Form Validation Class Initialized
INFO - 2025-03-28 09:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:29:04 --> Pagination Class Initialized
INFO - 2025-03-28 09:29:04 --> Controller Class Initialized
DEBUG - 2025-03-28 09:29:04 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:29:04 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:29:04 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:29:04 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:29:04 --> Model Class Initialized
INFO - 2025-03-28 15:29:04 --> Final output sent to browser
DEBUG - 2025-03-28 15:29:04 --> Total execution time: 0.0098
INFO - 2025-03-28 09:29:10 --> Config Class Initialized
INFO - 2025-03-28 09:29:10 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:29:10 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:29:10 --> Utf8 Class Initialized
INFO - 2025-03-28 09:29:10 --> URI Class Initialized
DEBUG - 2025-03-28 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:29:10 --> Router Class Initialized
INFO - 2025-03-28 09:29:10 --> Output Class Initialized
INFO - 2025-03-28 09:29:10 --> Security Class Initialized
DEBUG - 2025-03-28 09:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:29:10 --> Input Class Initialized
INFO - 2025-03-28 09:29:10 --> Language Class Initialized
INFO - 2025-03-28 09:29:10 --> Language Class Initialized
INFO - 2025-03-28 09:29:10 --> Config Class Initialized
INFO - 2025-03-28 09:29:10 --> Loader Class Initialized
INFO - 2025-03-28 09:29:10 --> Helper loaded: url_helper
INFO - 2025-03-28 09:29:10 --> Helper loaded: file_helper
INFO - 2025-03-28 09:29:10 --> Helper loaded: html_helper
INFO - 2025-03-28 09:29:10 --> Helper loaded: form_helper
INFO - 2025-03-28 09:29:10 --> Helper loaded: text_helper
INFO - 2025-03-28 09:29:10 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:29:10 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:29:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:29:10 --> Database Driver Class Initialized
INFO - 2025-03-28 09:29:10 --> Email Class Initialized
INFO - 2025-03-28 09:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:29:10 --> Form Validation Class Initialized
INFO - 2025-03-28 09:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:29:10 --> Pagination Class Initialized
INFO - 2025-03-28 09:29:10 --> Controller Class Initialized
DEBUG - 2025-03-28 09:29:10 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:29:10 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:29:10 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:29:10 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:29:10 --> Model Class Initialized
INFO - 2025-03-28 15:29:10 --> Final output sent to browser
DEBUG - 2025-03-28 15:29:10 --> Total execution time: 0.0124
INFO - 2025-03-28 09:29:12 --> Config Class Initialized
INFO - 2025-03-28 09:29:12 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:29:12 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:29:12 --> Utf8 Class Initialized
INFO - 2025-03-28 09:29:12 --> URI Class Initialized
DEBUG - 2025-03-28 09:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:29:12 --> Router Class Initialized
INFO - 2025-03-28 09:29:12 --> Output Class Initialized
INFO - 2025-03-28 09:29:12 --> Security Class Initialized
DEBUG - 2025-03-28 09:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:29:12 --> Input Class Initialized
INFO - 2025-03-28 09:29:12 --> Language Class Initialized
INFO - 2025-03-28 09:29:12 --> Language Class Initialized
INFO - 2025-03-28 09:29:12 --> Config Class Initialized
INFO - 2025-03-28 09:29:12 --> Loader Class Initialized
INFO - 2025-03-28 09:29:12 --> Helper loaded: url_helper
INFO - 2025-03-28 09:29:12 --> Helper loaded: file_helper
INFO - 2025-03-28 09:29:12 --> Helper loaded: html_helper
INFO - 2025-03-28 09:29:12 --> Helper loaded: form_helper
INFO - 2025-03-28 09:29:12 --> Helper loaded: text_helper
INFO - 2025-03-28 09:29:12 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:29:12 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:29:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:29:12 --> Database Driver Class Initialized
INFO - 2025-03-28 09:29:12 --> Email Class Initialized
INFO - 2025-03-28 09:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:29:12 --> Form Validation Class Initialized
INFO - 2025-03-28 09:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:29:12 --> Pagination Class Initialized
INFO - 2025-03-28 09:29:12 --> Controller Class Initialized
DEBUG - 2025-03-28 09:29:12 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:29:12 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:29:12 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:29:12 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:29:12 --> Model Class Initialized
INFO - 2025-03-28 15:29:12 --> Final output sent to browser
DEBUG - 2025-03-28 15:29:12 --> Total execution time: 0.0223
INFO - 2025-03-28 09:29:15 --> Config Class Initialized
INFO - 2025-03-28 09:29:15 --> Hooks Class Initialized
DEBUG - 2025-03-28 09:29:15 --> UTF-8 Support Enabled
INFO - 2025-03-28 09:29:15 --> Utf8 Class Initialized
INFO - 2025-03-28 09:29:15 --> URI Class Initialized
DEBUG - 2025-03-28 09:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-28 09:29:15 --> Router Class Initialized
INFO - 2025-03-28 09:29:15 --> Output Class Initialized
INFO - 2025-03-28 09:29:15 --> Security Class Initialized
DEBUG - 2025-03-28 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 09:29:15 --> Input Class Initialized
INFO - 2025-03-28 09:29:15 --> Language Class Initialized
INFO - 2025-03-28 09:29:15 --> Language Class Initialized
INFO - 2025-03-28 09:29:15 --> Config Class Initialized
INFO - 2025-03-28 09:29:15 --> Loader Class Initialized
INFO - 2025-03-28 09:29:15 --> Helper loaded: url_helper
INFO - 2025-03-28 09:29:15 --> Helper loaded: file_helper
INFO - 2025-03-28 09:29:15 --> Helper loaded: html_helper
INFO - 2025-03-28 09:29:15 --> Helper loaded: form_helper
INFO - 2025-03-28 09:29:15 --> Helper loaded: text_helper
INFO - 2025-03-28 09:29:15 --> Helper loaded: lang_helper
INFO - 2025-03-28 09:29:15 --> Helper loaded: directory_helper
INFO - 2025-03-28 09:29:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 09:29:15 --> Database Driver Class Initialized
INFO - 2025-03-28 09:29:15 --> Email Class Initialized
INFO - 2025-03-28 09:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 09:29:15 --> Form Validation Class Initialized
INFO - 2025-03-28 09:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 09:29:15 --> Pagination Class Initialized
INFO - 2025-03-28 09:29:15 --> Controller Class Initialized
DEBUG - 2025-03-28 09:29:15 --> Invoice MX_Controller Initialized
INFO - 2025-03-28 15:29:15 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-28 15:29:15 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-28 15:29:15 --> Model Class Initialized
DEBUG - 2025-03-28 15:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-28 15:29:15 --> Model Class Initialized
INFO - 2025-03-28 15:29:15 --> Final output sent to browser
DEBUG - 2025-03-28 15:29:15 --> Total execution time: 0.0094
INFO - 2025-03-28 19:58:28 --> Config Class Initialized
INFO - 2025-03-28 19:58:28 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:58:28 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:58:28 --> Utf8 Class Initialized
INFO - 2025-03-28 19:58:28 --> URI Class Initialized
DEBUG - 2025-03-28 19:58:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 19:58:28 --> Router Class Initialized
INFO - 2025-03-28 19:58:28 --> Output Class Initialized
INFO - 2025-03-28 19:58:28 --> Security Class Initialized
DEBUG - 2025-03-28 19:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:58:28 --> Input Class Initialized
INFO - 2025-03-28 19:58:28 --> Language Class Initialized
INFO - 2025-03-28 19:58:28 --> Language Class Initialized
INFO - 2025-03-28 19:58:28 --> Config Class Initialized
INFO - 2025-03-28 19:58:28 --> Loader Class Initialized
INFO - 2025-03-28 19:58:28 --> Helper loaded: url_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: file_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: html_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: form_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: text_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:58:28 --> Database Driver Class Initialized
INFO - 2025-03-28 19:58:28 --> Email Class Initialized
INFO - 2025-03-28 19:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:58:28 --> Form Validation Class Initialized
INFO - 2025-03-28 19:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:58:28 --> Pagination Class Initialized
INFO - 2025-03-28 19:58:28 --> Controller Class Initialized
DEBUG - 2025-03-28 19:58:28 --> Home MX_Controller Initialized
INFO - 2025-03-28 19:58:28 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-28 19:58:28 --> Model Class Initialized
INFO - 2025-03-28 19:58:28 --> Config Class Initialized
INFO - 2025-03-28 19:58:28 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:58:28 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:58:28 --> Utf8 Class Initialized
INFO - 2025-03-28 19:58:28 --> URI Class Initialized
DEBUG - 2025-03-28 19:58:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 19:58:28 --> Router Class Initialized
INFO - 2025-03-28 19:58:28 --> Output Class Initialized
INFO - 2025-03-28 19:58:28 --> Security Class Initialized
DEBUG - 2025-03-28 19:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:58:28 --> Input Class Initialized
INFO - 2025-03-28 19:58:28 --> Language Class Initialized
INFO - 2025-03-28 19:58:28 --> Language Class Initialized
INFO - 2025-03-28 19:58:28 --> Config Class Initialized
INFO - 2025-03-28 19:58:28 --> Loader Class Initialized
INFO - 2025-03-28 19:58:28 --> Helper loaded: url_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: file_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: html_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: form_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: text_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:58:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:58:28 --> Database Driver Class Initialized
INFO - 2025-03-28 19:58:28 --> Email Class Initialized
INFO - 2025-03-28 19:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:58:28 --> Form Validation Class Initialized
INFO - 2025-03-28 19:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:58:28 --> Pagination Class Initialized
INFO - 2025-03-28 19:58:28 --> Controller Class Initialized
DEBUG - 2025-03-28 19:58:28 --> Auth MX_Controller Initialized
INFO - 2025-03-28 19:58:28 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-28 19:58:28 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:58:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:58:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:58:28 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-28 19:58:28 --> Final output sent to browser
DEBUG - 2025-03-28 19:58:28 --> Total execution time: 0.0261
INFO - 2025-03-28 19:58:37 --> Config Class Initialized
INFO - 2025-03-28 19:58:37 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:58:37 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:58:37 --> Utf8 Class Initialized
INFO - 2025-03-28 19:58:37 --> URI Class Initialized
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 19:58:37 --> Router Class Initialized
INFO - 2025-03-28 19:58:37 --> Output Class Initialized
INFO - 2025-03-28 19:58:37 --> Security Class Initialized
DEBUG - 2025-03-28 19:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:58:37 --> Input Class Initialized
INFO - 2025-03-28 19:58:37 --> Language Class Initialized
INFO - 2025-03-28 19:58:37 --> Language Class Initialized
INFO - 2025-03-28 19:58:37 --> Config Class Initialized
INFO - 2025-03-28 19:58:37 --> Loader Class Initialized
INFO - 2025-03-28 19:58:37 --> Helper loaded: url_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: file_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: html_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: form_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: text_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:58:37 --> Database Driver Class Initialized
INFO - 2025-03-28 19:58:37 --> Email Class Initialized
INFO - 2025-03-28 19:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:58:37 --> Form Validation Class Initialized
INFO - 2025-03-28 19:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:58:37 --> Pagination Class Initialized
INFO - 2025-03-28 19:58:37 --> Controller Class Initialized
DEBUG - 2025-03-28 19:58:37 --> Auth MX_Controller Initialized
INFO - 2025-03-28 19:58:37 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-28 19:58:37 --> Model Class Initialized
INFO - 2025-03-28 19:58:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 19:58:37 --> Config Class Initialized
INFO - 2025-03-28 19:58:37 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:58:37 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:58:37 --> Utf8 Class Initialized
INFO - 2025-03-28 19:58:37 --> URI Class Initialized
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 19:58:37 --> Router Class Initialized
INFO - 2025-03-28 19:58:37 --> Output Class Initialized
INFO - 2025-03-28 19:58:37 --> Security Class Initialized
DEBUG - 2025-03-28 19:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:58:37 --> Input Class Initialized
INFO - 2025-03-28 19:58:37 --> Language Class Initialized
INFO - 2025-03-28 19:58:37 --> Language Class Initialized
INFO - 2025-03-28 19:58:37 --> Config Class Initialized
INFO - 2025-03-28 19:58:37 --> Loader Class Initialized
INFO - 2025-03-28 19:58:37 --> Helper loaded: url_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: file_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: html_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: form_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: text_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:58:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:58:37 --> Database Driver Class Initialized
INFO - 2025-03-28 19:58:37 --> Email Class Initialized
INFO - 2025-03-28 19:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:58:37 --> Form Validation Class Initialized
INFO - 2025-03-28 19:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:58:37 --> Pagination Class Initialized
INFO - 2025-03-28 19:58:37 --> Controller Class Initialized
DEBUG - 2025-03-28 19:58:37 --> Home MX_Controller Initialized
INFO - 2025-03-28 19:58:37 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-28 19:58:37 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:58:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:58:37 --> Model Class Initialized
ERROR - 2025-03-28 19:58:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 19:58:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 19:58:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 19:58:37 --> Final output sent to browser
DEBUG - 2025-03-28 19:58:37 --> Total execution time: 0.5178
INFO - 2025-03-28 19:58:47 --> Config Class Initialized
INFO - 2025-03-28 19:58:47 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:58:47 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:58:47 --> Utf8 Class Initialized
INFO - 2025-03-28 19:58:47 --> URI Class Initialized
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:58:47 --> Router Class Initialized
INFO - 2025-03-28 19:58:47 --> Output Class Initialized
INFO - 2025-03-28 19:58:47 --> Security Class Initialized
DEBUG - 2025-03-28 19:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:58:47 --> Input Class Initialized
INFO - 2025-03-28 19:58:47 --> Language Class Initialized
INFO - 2025-03-28 19:58:47 --> Language Class Initialized
INFO - 2025-03-28 19:58:47 --> Config Class Initialized
INFO - 2025-03-28 19:58:47 --> Loader Class Initialized
INFO - 2025-03-28 19:58:47 --> Helper loaded: url_helper
INFO - 2025-03-28 19:58:47 --> Helper loaded: file_helper
INFO - 2025-03-28 19:58:47 --> Helper loaded: html_helper
INFO - 2025-03-28 19:58:47 --> Helper loaded: form_helper
INFO - 2025-03-28 19:58:47 --> Helper loaded: text_helper
INFO - 2025-03-28 19:58:47 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:58:47 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:58:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:58:47 --> Database Driver Class Initialized
INFO - 2025-03-28 19:58:47 --> Email Class Initialized
INFO - 2025-03-28 19:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:58:47 --> Form Validation Class Initialized
INFO - 2025-03-28 19:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:58:47 --> Pagination Class Initialized
INFO - 2025-03-28 19:58:47 --> Controller Class Initialized
DEBUG - 2025-03-28 19:58:47 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:58:47 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:58:47 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:58:47 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:58:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:58:47 --> Model Class Initialized
ERROR - 2025-03-28 19:58:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 19:58:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 19:58:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 19:58:47 --> Final output sent to browser
DEBUG - 2025-03-28 19:58:47 --> Total execution time: 0.0969
INFO - 2025-03-28 19:58:56 --> Config Class Initialized
INFO - 2025-03-28 19:58:56 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:58:56 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:58:56 --> Utf8 Class Initialized
INFO - 2025-03-28 19:58:56 --> URI Class Initialized
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:58:56 --> Router Class Initialized
INFO - 2025-03-28 19:58:56 --> Output Class Initialized
INFO - 2025-03-28 19:58:56 --> Security Class Initialized
DEBUG - 2025-03-28 19:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:58:56 --> Input Class Initialized
INFO - 2025-03-28 19:58:56 --> Language Class Initialized
INFO - 2025-03-28 19:58:56 --> Language Class Initialized
INFO - 2025-03-28 19:58:56 --> Config Class Initialized
INFO - 2025-03-28 19:58:56 --> Loader Class Initialized
INFO - 2025-03-28 19:58:56 --> Helper loaded: url_helper
INFO - 2025-03-28 19:58:56 --> Helper loaded: file_helper
INFO - 2025-03-28 19:58:56 --> Helper loaded: html_helper
INFO - 2025-03-28 19:58:56 --> Helper loaded: form_helper
INFO - 2025-03-28 19:58:56 --> Helper loaded: text_helper
INFO - 2025-03-28 19:58:56 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:58:56 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:58:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:58:56 --> Database Driver Class Initialized
INFO - 2025-03-28 19:58:56 --> Email Class Initialized
INFO - 2025-03-28 19:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:58:56 --> Form Validation Class Initialized
INFO - 2025-03-28 19:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:58:56 --> Pagination Class Initialized
INFO - 2025-03-28 19:58:56 --> Controller Class Initialized
DEBUG - 2025-03-28 19:58:56 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:58:56 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:58:56 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:58:56 --> Model Class Initialized
DEBUG - 2025-03-28 19:58:56 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:58:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:58:56 --> Model Class Initialized
ERROR - 2025-03-28 19:58:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 19:58:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 19:58:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 19:58:56 --> Final output sent to browser
DEBUG - 2025-03-28 19:58:56 --> Total execution time: 0.1172
INFO - 2025-03-28 19:59:34 --> Config Class Initialized
INFO - 2025-03-28 19:59:34 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:59:34 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:59:34 --> Utf8 Class Initialized
INFO - 2025-03-28 19:59:34 --> URI Class Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:59:34 --> Router Class Initialized
INFO - 2025-03-28 19:59:34 --> Output Class Initialized
INFO - 2025-03-28 19:59:34 --> Security Class Initialized
DEBUG - 2025-03-28 19:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:59:34 --> Input Class Initialized
INFO - 2025-03-28 19:59:34 --> Language Class Initialized
INFO - 2025-03-28 19:59:34 --> Language Class Initialized
INFO - 2025-03-28 19:59:34 --> Config Class Initialized
INFO - 2025-03-28 19:59:34 --> Loader Class Initialized
INFO - 2025-03-28 19:59:34 --> Helper loaded: url_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: file_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: html_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: form_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: text_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:59:34 --> Database Driver Class Initialized
INFO - 2025-03-28 19:59:34 --> Email Class Initialized
INFO - 2025-03-28 19:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:59:34 --> Form Validation Class Initialized
INFO - 2025-03-28 19:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:59:34 --> Pagination Class Initialized
INFO - 2025-03-28 19:59:34 --> Controller Class Initialized
DEBUG - 2025-03-28 19:59:34 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:59:34 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:59:34 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:59:34 --> Model Class Initialized
INFO - 2025-03-28 19:59:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 19:59:34 --> INFO: Category Created Successfully -> Beverage
INFO - 2025-03-28 19:59:34 --> Config Class Initialized
INFO - 2025-03-28 19:59:34 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:59:34 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:59:34 --> Utf8 Class Initialized
INFO - 2025-03-28 19:59:34 --> URI Class Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:59:34 --> Router Class Initialized
INFO - 2025-03-28 19:59:34 --> Output Class Initialized
INFO - 2025-03-28 19:59:34 --> Security Class Initialized
DEBUG - 2025-03-28 19:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:59:34 --> Input Class Initialized
INFO - 2025-03-28 19:59:34 --> Language Class Initialized
INFO - 2025-03-28 19:59:34 --> Language Class Initialized
INFO - 2025-03-28 19:59:34 --> Config Class Initialized
INFO - 2025-03-28 19:59:34 --> Loader Class Initialized
INFO - 2025-03-28 19:59:34 --> Helper loaded: url_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: file_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: html_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: form_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: text_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:59:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:59:34 --> Database Driver Class Initialized
INFO - 2025-03-28 19:59:34 --> Email Class Initialized
INFO - 2025-03-28 19:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:59:34 --> Form Validation Class Initialized
INFO - 2025-03-28 19:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:59:34 --> Pagination Class Initialized
INFO - 2025-03-28 19:59:34 --> Controller Class Initialized
DEBUG - 2025-03-28 19:59:34 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:59:34 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:59:34 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:59:34 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:59:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:59:34 --> Model Class Initialized
ERROR - 2025-03-28 19:59:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 19:59:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 19:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 19:59:34 --> Final output sent to browser
DEBUG - 2025-03-28 19:59:34 --> Total execution time: 0.0779
INFO - 2025-03-28 19:59:37 --> Config Class Initialized
INFO - 2025-03-28 19:59:37 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:59:37 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:59:37 --> Utf8 Class Initialized
INFO - 2025-03-28 19:59:37 --> URI Class Initialized
DEBUG - 2025-03-28 19:59:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:59:37 --> Router Class Initialized
INFO - 2025-03-28 19:59:37 --> Output Class Initialized
INFO - 2025-03-28 19:59:37 --> Security Class Initialized
DEBUG - 2025-03-28 19:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:59:37 --> Input Class Initialized
INFO - 2025-03-28 19:59:37 --> Language Class Initialized
INFO - 2025-03-28 19:59:37 --> Language Class Initialized
INFO - 2025-03-28 19:59:37 --> Config Class Initialized
INFO - 2025-03-28 19:59:37 --> Loader Class Initialized
INFO - 2025-03-28 19:59:37 --> Helper loaded: url_helper
INFO - 2025-03-28 19:59:37 --> Helper loaded: file_helper
INFO - 2025-03-28 19:59:37 --> Helper loaded: html_helper
INFO - 2025-03-28 19:59:37 --> Helper loaded: form_helper
INFO - 2025-03-28 19:59:37 --> Helper loaded: text_helper
INFO - 2025-03-28 19:59:37 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:59:37 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:59:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:59:37 --> Database Driver Class Initialized
INFO - 2025-03-28 19:59:37 --> Email Class Initialized
INFO - 2025-03-28 19:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:59:37 --> Form Validation Class Initialized
INFO - 2025-03-28 19:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:59:37 --> Pagination Class Initialized
INFO - 2025-03-28 19:59:37 --> Controller Class Initialized
DEBUG - 2025-03-28 19:59:37 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:59:37 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:59:37 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:59:37 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:37 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 19:59:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:59:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:59:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:59:37 --> Model Class Initialized
ERROR - 2025-03-28 19:59:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 19:59:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 19:59:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 19:59:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 19:59:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 19:59:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 19:59:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 19:59:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 19:59:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 19:59:38 --> Final output sent to browser
DEBUG - 2025-03-28 19:59:38 --> Total execution time: 0.1256
INFO - 2025-03-28 19:59:53 --> Config Class Initialized
INFO - 2025-03-28 19:59:53 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:59:53 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:59:53 --> Utf8 Class Initialized
INFO - 2025-03-28 19:59:53 --> URI Class Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:59:53 --> Router Class Initialized
INFO - 2025-03-28 19:59:53 --> Output Class Initialized
INFO - 2025-03-28 19:59:53 --> Security Class Initialized
DEBUG - 2025-03-28 19:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:59:53 --> Input Class Initialized
INFO - 2025-03-28 19:59:53 --> Language Class Initialized
INFO - 2025-03-28 19:59:53 --> Language Class Initialized
INFO - 2025-03-28 19:59:53 --> Config Class Initialized
INFO - 2025-03-28 19:59:53 --> Loader Class Initialized
INFO - 2025-03-28 19:59:53 --> Helper loaded: url_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: file_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: html_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: form_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: text_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:59:53 --> Database Driver Class Initialized
INFO - 2025-03-28 19:59:53 --> Email Class Initialized
INFO - 2025-03-28 19:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:59:53 --> Form Validation Class Initialized
INFO - 2025-03-28 19:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:59:53 --> Pagination Class Initialized
INFO - 2025-03-28 19:59:53 --> Controller Class Initialized
DEBUG - 2025-03-28 19:59:53 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:59:53 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:59:53 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:59:53 --> Model Class Initialized
INFO - 2025-03-28 19:59:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 19:59:53 --> INFO: Category Created Successfully -> Beverage->Cold Drinks
INFO - 2025-03-28 19:59:53 --> Config Class Initialized
INFO - 2025-03-28 19:59:53 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:59:53 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:59:53 --> Utf8 Class Initialized
INFO - 2025-03-28 19:59:53 --> URI Class Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:59:53 --> Router Class Initialized
INFO - 2025-03-28 19:59:53 --> Output Class Initialized
INFO - 2025-03-28 19:59:53 --> Security Class Initialized
DEBUG - 2025-03-28 19:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:59:53 --> Input Class Initialized
INFO - 2025-03-28 19:59:53 --> Language Class Initialized
INFO - 2025-03-28 19:59:53 --> Language Class Initialized
INFO - 2025-03-28 19:59:53 --> Config Class Initialized
INFO - 2025-03-28 19:59:53 --> Loader Class Initialized
INFO - 2025-03-28 19:59:53 --> Helper loaded: url_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: file_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: html_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: form_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: text_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:59:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:59:53 --> Database Driver Class Initialized
INFO - 2025-03-28 19:59:53 --> Email Class Initialized
INFO - 2025-03-28 19:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:59:53 --> Form Validation Class Initialized
INFO - 2025-03-28 19:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:59:53 --> Pagination Class Initialized
INFO - 2025-03-28 19:59:53 --> Controller Class Initialized
DEBUG - 2025-03-28 19:59:53 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:59:53 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:59:53 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:59:53 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:59:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:59:53 --> Model Class Initialized
ERROR - 2025-03-28 19:59:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 19:59:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 19:59:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 19:59:53 --> Final output sent to browser
DEBUG - 2025-03-28 19:59:53 --> Total execution time: 0.1202
INFO - 2025-03-28 19:59:56 --> Config Class Initialized
INFO - 2025-03-28 19:59:56 --> Hooks Class Initialized
DEBUG - 2025-03-28 19:59:56 --> UTF-8 Support Enabled
INFO - 2025-03-28 19:59:56 --> Utf8 Class Initialized
INFO - 2025-03-28 19:59:56 --> URI Class Initialized
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 19:59:56 --> Router Class Initialized
INFO - 2025-03-28 19:59:56 --> Output Class Initialized
INFO - 2025-03-28 19:59:56 --> Security Class Initialized
DEBUG - 2025-03-28 19:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 19:59:56 --> Input Class Initialized
INFO - 2025-03-28 19:59:56 --> Language Class Initialized
INFO - 2025-03-28 19:59:56 --> Language Class Initialized
INFO - 2025-03-28 19:59:56 --> Config Class Initialized
INFO - 2025-03-28 19:59:56 --> Loader Class Initialized
INFO - 2025-03-28 19:59:56 --> Helper loaded: url_helper
INFO - 2025-03-28 19:59:56 --> Helper loaded: file_helper
INFO - 2025-03-28 19:59:56 --> Helper loaded: html_helper
INFO - 2025-03-28 19:59:56 --> Helper loaded: form_helper
INFO - 2025-03-28 19:59:56 --> Helper loaded: text_helper
INFO - 2025-03-28 19:59:56 --> Helper loaded: lang_helper
INFO - 2025-03-28 19:59:56 --> Helper loaded: directory_helper
INFO - 2025-03-28 19:59:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 19:59:56 --> Database Driver Class Initialized
INFO - 2025-03-28 19:59:56 --> Email Class Initialized
INFO - 2025-03-28 19:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 19:59:56 --> Form Validation Class Initialized
INFO - 2025-03-28 19:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 19:59:56 --> Pagination Class Initialized
INFO - 2025-03-28 19:59:56 --> Controller Class Initialized
DEBUG - 2025-03-28 19:59:56 --> Product MX_Controller Initialized
INFO - 2025-03-28 19:59:56 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 19:59:56 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 19:59:56 --> Model Class Initialized
DEBUG - 2025-03-28 19:59:56 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 19:59:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 19:59:56 --> Model Class Initialized
ERROR - 2025-03-28 19:59:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 19:59:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 19:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 19:59:56 --> Final output sent to browser
DEBUG - 2025-03-28 19:59:56 --> Total execution time: 0.1317
INFO - 2025-03-28 20:00:42 --> Config Class Initialized
INFO - 2025-03-28 20:00:42 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:00:42 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:00:42 --> Utf8 Class Initialized
INFO - 2025-03-28 20:00:42 --> URI Class Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:00:42 --> Router Class Initialized
INFO - 2025-03-28 20:00:42 --> Output Class Initialized
INFO - 2025-03-28 20:00:42 --> Security Class Initialized
DEBUG - 2025-03-28 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:00:42 --> Input Class Initialized
INFO - 2025-03-28 20:00:42 --> Language Class Initialized
INFO - 2025-03-28 20:00:42 --> Language Class Initialized
INFO - 2025-03-28 20:00:42 --> Config Class Initialized
INFO - 2025-03-28 20:00:42 --> Loader Class Initialized
INFO - 2025-03-28 20:00:42 --> Helper loaded: url_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: file_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: html_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: form_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: text_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:00:42 --> Database Driver Class Initialized
INFO - 2025-03-28 20:00:42 --> Email Class Initialized
INFO - 2025-03-28 20:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:00:42 --> Form Validation Class Initialized
INFO - 2025-03-28 20:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:00:42 --> Pagination Class Initialized
INFO - 2025-03-28 20:00:42 --> Controller Class Initialized
DEBUG - 2025-03-28 20:00:42 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:00:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:00:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:00:42 --> Model Class Initialized
INFO - 2025-03-28 20:00:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:00:42 --> INFO: Category Created Successfully -> Beverage->Cold Drinks->Mineral Water
INFO - 2025-03-28 20:00:42 --> Config Class Initialized
INFO - 2025-03-28 20:00:42 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:00:42 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:00:42 --> Utf8 Class Initialized
INFO - 2025-03-28 20:00:42 --> URI Class Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:00:42 --> Router Class Initialized
INFO - 2025-03-28 20:00:42 --> Output Class Initialized
INFO - 2025-03-28 20:00:42 --> Security Class Initialized
DEBUG - 2025-03-28 20:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:00:42 --> Input Class Initialized
INFO - 2025-03-28 20:00:42 --> Language Class Initialized
INFO - 2025-03-28 20:00:42 --> Language Class Initialized
INFO - 2025-03-28 20:00:42 --> Config Class Initialized
INFO - 2025-03-28 20:00:42 --> Loader Class Initialized
INFO - 2025-03-28 20:00:42 --> Helper loaded: url_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: file_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: html_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: form_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: text_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:00:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:00:42 --> Database Driver Class Initialized
INFO - 2025-03-28 20:00:42 --> Email Class Initialized
INFO - 2025-03-28 20:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:00:42 --> Form Validation Class Initialized
INFO - 2025-03-28 20:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:00:42 --> Pagination Class Initialized
INFO - 2025-03-28 20:00:42 --> Controller Class Initialized
DEBUG - 2025-03-28 20:00:42 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:00:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:00:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:00:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:00:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:00:42 --> Model Class Initialized
ERROR - 2025-03-28 20:00:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:00:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:00:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:00:42 --> Final output sent to browser
DEBUG - 2025-03-28 20:00:42 --> Total execution time: 0.1361
INFO - 2025-03-28 20:00:48 --> Config Class Initialized
INFO - 2025-03-28 20:00:48 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:00:48 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:00:48 --> Utf8 Class Initialized
INFO - 2025-03-28 20:00:48 --> URI Class Initialized
DEBUG - 2025-03-28 20:00:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:00:48 --> Router Class Initialized
INFO - 2025-03-28 20:00:48 --> Output Class Initialized
INFO - 2025-03-28 20:00:48 --> Security Class Initialized
DEBUG - 2025-03-28 20:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:00:48 --> Input Class Initialized
INFO - 2025-03-28 20:00:48 --> Language Class Initialized
INFO - 2025-03-28 20:00:48 --> Language Class Initialized
INFO - 2025-03-28 20:00:48 --> Config Class Initialized
INFO - 2025-03-28 20:00:48 --> Loader Class Initialized
INFO - 2025-03-28 20:00:48 --> Helper loaded: url_helper
INFO - 2025-03-28 20:00:48 --> Helper loaded: file_helper
INFO - 2025-03-28 20:00:48 --> Helper loaded: html_helper
INFO - 2025-03-28 20:00:48 --> Helper loaded: form_helper
INFO - 2025-03-28 20:00:48 --> Helper loaded: text_helper
INFO - 2025-03-28 20:00:48 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:00:48 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:00:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:00:48 --> Database Driver Class Initialized
INFO - 2025-03-28 20:00:48 --> Email Class Initialized
INFO - 2025-03-28 20:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:00:48 --> Form Validation Class Initialized
INFO - 2025-03-28 20:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:00:48 --> Pagination Class Initialized
INFO - 2025-03-28 20:00:48 --> Controller Class Initialized
DEBUG - 2025-03-28 20:00:48 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:00:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:00:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:00:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:00:48 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"35","category_name":"Beverage->Cold Drinks->Mineral Water","parent_id":"34","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:00:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:00:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:00:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:00:48 --> Model Class Initialized
ERROR - 2025-03-28 20:00:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:00:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:00:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:00:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:00:49 --> Final output sent to browser
DEBUG - 2025-03-28 20:00:49 --> Total execution time: 0.1207
INFO - 2025-03-28 20:01:06 --> Config Class Initialized
INFO - 2025-03-28 20:01:06 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:06 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:06 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:06 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:06 --> Router Class Initialized
INFO - 2025-03-28 20:01:06 --> Output Class Initialized
INFO - 2025-03-28 20:01:06 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:06 --> Input Class Initialized
INFO - 2025-03-28 20:01:06 --> Language Class Initialized
INFO - 2025-03-28 20:01:06 --> Language Class Initialized
INFO - 2025-03-28 20:01:06 --> Config Class Initialized
INFO - 2025-03-28 20:01:06 --> Loader Class Initialized
INFO - 2025-03-28 20:01:06 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:06 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:06 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:06 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:06 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:06 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:06 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:06 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:06 --> Email Class Initialized
INFO - 2025-03-28 20:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:06 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:06 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:06 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:06 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:06 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:06 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:06 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:01:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:01:06 --> Model Class Initialized
ERROR - 2025-03-28 20:01:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:01:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:01:06 --> Final output sent to browser
DEBUG - 2025-03-28 20:01:06 --> Total execution time: 0.1232
INFO - 2025-03-28 20:01:10 --> Config Class Initialized
INFO - 2025-03-28 20:01:10 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:10 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:10 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:10 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:10 --> Router Class Initialized
INFO - 2025-03-28 20:01:10 --> Output Class Initialized
INFO - 2025-03-28 20:01:10 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:10 --> Input Class Initialized
INFO - 2025-03-28 20:01:10 --> Language Class Initialized
INFO - 2025-03-28 20:01:10 --> Language Class Initialized
INFO - 2025-03-28 20:01:10 --> Config Class Initialized
INFO - 2025-03-28 20:01:10 --> Loader Class Initialized
INFO - 2025-03-28 20:01:10 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:10 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:10 --> Email Class Initialized
INFO - 2025-03-28 20:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:10 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:10 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:10 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:10 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:10 --> Model Class Initialized
INFO - 2025-03-28 20:01:10 --> Config Class Initialized
INFO - 2025-03-28 20:01:10 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:10 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:10 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:10 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:10 --> Router Class Initialized
INFO - 2025-03-28 20:01:10 --> Output Class Initialized
INFO - 2025-03-28 20:01:10 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:10 --> Input Class Initialized
INFO - 2025-03-28 20:01:10 --> Language Class Initialized
INFO - 2025-03-28 20:01:10 --> Language Class Initialized
INFO - 2025-03-28 20:01:10 --> Config Class Initialized
INFO - 2025-03-28 20:01:10 --> Loader Class Initialized
INFO - 2025-03-28 20:01:10 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:10 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:10 --> Email Class Initialized
INFO - 2025-03-28 20:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:10 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:10 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:10 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:10 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:01:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:01:10 --> Model Class Initialized
ERROR - 2025-03-28 20:01:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:01:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:01:10 --> Final output sent to browser
DEBUG - 2025-03-28 20:01:10 --> Total execution time: 0.1330
INFO - 2025-03-28 20:01:12 --> Config Class Initialized
INFO - 2025-03-28 20:01:12 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:12 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:12 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:12 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:12 --> Router Class Initialized
INFO - 2025-03-28 20:01:12 --> Output Class Initialized
INFO - 2025-03-28 20:01:12 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:12 --> Input Class Initialized
INFO - 2025-03-28 20:01:12 --> Language Class Initialized
INFO - 2025-03-28 20:01:12 --> Language Class Initialized
INFO - 2025-03-28 20:01:12 --> Config Class Initialized
INFO - 2025-03-28 20:01:12 --> Loader Class Initialized
INFO - 2025-03-28 20:01:12 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:12 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:12 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:12 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:12 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:12 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:12 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:12 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:12 --> Email Class Initialized
INFO - 2025-03-28 20:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:12 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:12 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:12 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:12 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:12 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:12 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:12 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:12 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:01:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:01:12 --> Model Class Initialized
ERROR - 2025-03-28 20:01:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:01:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:01:12 --> Final output sent to browser
DEBUG - 2025-03-28 20:01:12 --> Total execution time: 0.0929
INFO - 2025-03-28 20:01:23 --> Config Class Initialized
INFO - 2025-03-28 20:01:23 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:23 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:23 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:23 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:23 --> Router Class Initialized
INFO - 2025-03-28 20:01:23 --> Output Class Initialized
INFO - 2025-03-28 20:01:23 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:23 --> Input Class Initialized
INFO - 2025-03-28 20:01:23 --> Language Class Initialized
INFO - 2025-03-28 20:01:23 --> Language Class Initialized
INFO - 2025-03-28 20:01:23 --> Config Class Initialized
INFO - 2025-03-28 20:01:23 --> Loader Class Initialized
INFO - 2025-03-28 20:01:23 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:23 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:23 --> Email Class Initialized
INFO - 2025-03-28 20:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:23 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:23 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:23 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:23 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:23 --> Model Class Initialized
INFO - 2025-03-28 20:01:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:01:23 --> INFO: Category Created Successfully -> Beverage->Mineral Water
INFO - 2025-03-28 20:01:23 --> Config Class Initialized
INFO - 2025-03-28 20:01:23 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:23 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:23 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:23 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:23 --> Router Class Initialized
INFO - 2025-03-28 20:01:23 --> Output Class Initialized
INFO - 2025-03-28 20:01:23 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:23 --> Input Class Initialized
INFO - 2025-03-28 20:01:23 --> Language Class Initialized
INFO - 2025-03-28 20:01:23 --> Language Class Initialized
INFO - 2025-03-28 20:01:23 --> Config Class Initialized
INFO - 2025-03-28 20:01:23 --> Loader Class Initialized
INFO - 2025-03-28 20:01:23 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:23 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:23 --> Email Class Initialized
INFO - 2025-03-28 20:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:23 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:23 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:23 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:23 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:01:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:01:23 --> Model Class Initialized
ERROR - 2025-03-28 20:01:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:01:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:01:23 --> Final output sent to browser
DEBUG - 2025-03-28 20:01:23 --> Total execution time: 0.1133
INFO - 2025-03-28 20:01:27 --> Config Class Initialized
INFO - 2025-03-28 20:01:27 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:27 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:27 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:27 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:27 --> Router Class Initialized
INFO - 2025-03-28 20:01:27 --> Output Class Initialized
INFO - 2025-03-28 20:01:27 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:27 --> Input Class Initialized
INFO - 2025-03-28 20:01:27 --> Language Class Initialized
INFO - 2025-03-28 20:01:27 --> Language Class Initialized
INFO - 2025-03-28 20:01:27 --> Config Class Initialized
INFO - 2025-03-28 20:01:27 --> Loader Class Initialized
INFO - 2025-03-28 20:01:27 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:27 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:27 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:27 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:27 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:27 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:27 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:27 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:27 --> Email Class Initialized
INFO - 2025-03-28 20:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:27 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:27 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:27 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:27 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:27 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:27 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:27 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:27 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:01:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:01:27 --> Model Class Initialized
ERROR - 2025-03-28 20:01:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:01:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:01:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:01:27 --> Final output sent to browser
DEBUG - 2025-03-28 20:01:27 --> Total execution time: 0.1129
INFO - 2025-03-28 20:01:51 --> Config Class Initialized
INFO - 2025-03-28 20:01:51 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:51 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:51 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:51 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:51 --> Router Class Initialized
INFO - 2025-03-28 20:01:51 --> Output Class Initialized
INFO - 2025-03-28 20:01:51 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:51 --> Input Class Initialized
INFO - 2025-03-28 20:01:51 --> Language Class Initialized
INFO - 2025-03-28 20:01:51 --> Language Class Initialized
INFO - 2025-03-28 20:01:51 --> Config Class Initialized
INFO - 2025-03-28 20:01:51 --> Loader Class Initialized
INFO - 2025-03-28 20:01:51 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:51 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:51 --> Email Class Initialized
INFO - 2025-03-28 20:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:51 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:51 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:51 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:51 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:51 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:51 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:51 --> Model Class Initialized
INFO - 2025-03-28 20:01:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:01:51 --> INFO: Category Created Successfully -> Beverage->Cold Drinks->Cola
INFO - 2025-03-28 20:01:51 --> Config Class Initialized
INFO - 2025-03-28 20:01:51 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:01:51 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:01:51 --> Utf8 Class Initialized
INFO - 2025-03-28 20:01:51 --> URI Class Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:01:51 --> Router Class Initialized
INFO - 2025-03-28 20:01:51 --> Output Class Initialized
INFO - 2025-03-28 20:01:51 --> Security Class Initialized
DEBUG - 2025-03-28 20:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:01:51 --> Input Class Initialized
INFO - 2025-03-28 20:01:51 --> Language Class Initialized
INFO - 2025-03-28 20:01:51 --> Language Class Initialized
INFO - 2025-03-28 20:01:51 --> Config Class Initialized
INFO - 2025-03-28 20:01:51 --> Loader Class Initialized
INFO - 2025-03-28 20:01:51 --> Helper loaded: url_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: file_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: html_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: form_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: text_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:01:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:01:51 --> Database Driver Class Initialized
INFO - 2025-03-28 20:01:51 --> Email Class Initialized
INFO - 2025-03-28 20:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:01:51 --> Form Validation Class Initialized
INFO - 2025-03-28 20:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:01:51 --> Pagination Class Initialized
INFO - 2025-03-28 20:01:51 --> Controller Class Initialized
DEBUG - 2025-03-28 20:01:51 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:01:51 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:01:51 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:01:51 --> Model Class Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:01:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:01:51 --> Model Class Initialized
ERROR - 2025-03-28 20:01:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:01:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:01:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:01:52 --> Final output sent to browser
DEBUG - 2025-03-28 20:01:52 --> Total execution time: 0.1292
INFO - 2025-03-28 20:02:00 --> Config Class Initialized
INFO - 2025-03-28 20:02:00 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:02:00 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:02:00 --> Utf8 Class Initialized
INFO - 2025-03-28 20:02:00 --> URI Class Initialized
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:02:00 --> Router Class Initialized
INFO - 2025-03-28 20:02:00 --> Output Class Initialized
INFO - 2025-03-28 20:02:00 --> Security Class Initialized
DEBUG - 2025-03-28 20:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:02:00 --> Input Class Initialized
INFO - 2025-03-28 20:02:00 --> Language Class Initialized
INFO - 2025-03-28 20:02:00 --> Language Class Initialized
INFO - 2025-03-28 20:02:00 --> Config Class Initialized
INFO - 2025-03-28 20:02:00 --> Loader Class Initialized
INFO - 2025-03-28 20:02:00 --> Helper loaded: url_helper
INFO - 2025-03-28 20:02:00 --> Helper loaded: file_helper
INFO - 2025-03-28 20:02:00 --> Helper loaded: html_helper
INFO - 2025-03-28 20:02:00 --> Helper loaded: form_helper
INFO - 2025-03-28 20:02:00 --> Helper loaded: text_helper
INFO - 2025-03-28 20:02:00 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:02:00 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:02:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:02:00 --> Database Driver Class Initialized
INFO - 2025-03-28 20:02:00 --> Email Class Initialized
INFO - 2025-03-28 20:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:02:00 --> Form Validation Class Initialized
INFO - 2025-03-28 20:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:02:00 --> Pagination Class Initialized
INFO - 2025-03-28 20:02:00 --> Controller Class Initialized
DEBUG - 2025-03-28 20:02:00 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 20:02:00 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:02:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:02:00 --> Model Class Initialized
ERROR - 2025-03-28 20:02:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:02:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:02:00 --> Final output sent to browser
DEBUG - 2025-03-28 20:02:00 --> Total execution time: 0.1182
INFO - 2025-03-28 20:04:43 --> Config Class Initialized
INFO - 2025-03-28 20:04:43 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:04:43 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:04:43 --> Utf8 Class Initialized
INFO - 2025-03-28 20:04:43 --> URI Class Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:04:43 --> Router Class Initialized
INFO - 2025-03-28 20:04:43 --> Output Class Initialized
INFO - 2025-03-28 20:04:43 --> Security Class Initialized
DEBUG - 2025-03-28 20:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:04:43 --> Input Class Initialized
INFO - 2025-03-28 20:04:43 --> Language Class Initialized
INFO - 2025-03-28 20:04:43 --> Language Class Initialized
INFO - 2025-03-28 20:04:43 --> Config Class Initialized
INFO - 2025-03-28 20:04:43 --> Loader Class Initialized
INFO - 2025-03-28 20:04:43 --> Helper loaded: url_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: file_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: html_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: form_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: text_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:04:43 --> Database Driver Class Initialized
INFO - 2025-03-28 20:04:43 --> Email Class Initialized
INFO - 2025-03-28 20:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:04:43 --> Form Validation Class Initialized
INFO - 2025-03-28 20:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:04:43 --> Pagination Class Initialized
INFO - 2025-03-28 20:04:43 --> Controller Class Initialized
DEBUG - 2025-03-28 20:04:43 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:04:43 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:04:43 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:04:43 --> Model Class Initialized
INFO - 2025-03-28 20:04:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:04:43 --> INFO: Category Created Successfully -> Food
INFO - 2025-03-28 20:04:43 --> Config Class Initialized
INFO - 2025-03-28 20:04:43 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:04:43 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:04:43 --> Utf8 Class Initialized
INFO - 2025-03-28 20:04:43 --> URI Class Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:04:43 --> Router Class Initialized
INFO - 2025-03-28 20:04:43 --> Output Class Initialized
INFO - 2025-03-28 20:04:43 --> Security Class Initialized
DEBUG - 2025-03-28 20:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:04:43 --> Input Class Initialized
INFO - 2025-03-28 20:04:43 --> Language Class Initialized
INFO - 2025-03-28 20:04:43 --> Language Class Initialized
INFO - 2025-03-28 20:04:43 --> Config Class Initialized
INFO - 2025-03-28 20:04:43 --> Loader Class Initialized
INFO - 2025-03-28 20:04:43 --> Helper loaded: url_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: file_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: html_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: form_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: text_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:04:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:04:43 --> Database Driver Class Initialized
INFO - 2025-03-28 20:04:43 --> Email Class Initialized
INFO - 2025-03-28 20:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:04:43 --> Form Validation Class Initialized
INFO - 2025-03-28 20:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:04:43 --> Pagination Class Initialized
INFO - 2025-03-28 20:04:43 --> Controller Class Initialized
DEBUG - 2025-03-28 20:04:43 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:04:43 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:04:43 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:04:43 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:04:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:04:43 --> Model Class Initialized
ERROR - 2025-03-28 20:04:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:04:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:04:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:04:43 --> Final output sent to browser
DEBUG - 2025-03-28 20:04:43 --> Total execution time: 0.1428
INFO - 2025-03-28 20:04:58 --> Config Class Initialized
INFO - 2025-03-28 20:04:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:04:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:04:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:04:58 --> URI Class Initialized
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:04:58 --> Router Class Initialized
INFO - 2025-03-28 20:04:58 --> Output Class Initialized
INFO - 2025-03-28 20:04:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:04:58 --> Input Class Initialized
INFO - 2025-03-28 20:04:58 --> Language Class Initialized
INFO - 2025-03-28 20:04:58 --> Language Class Initialized
INFO - 2025-03-28 20:04:58 --> Config Class Initialized
INFO - 2025-03-28 20:04:58 --> Loader Class Initialized
INFO - 2025-03-28 20:04:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:04:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:04:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:04:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:04:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:04:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:04:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:04:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:04:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:04:58 --> Email Class Initialized
INFO - 2025-03-28 20:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:04:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:04:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:04:58 --> Controller Class Initialized
DEBUG - 2025-03-28 20:04:58 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:04:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:04:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:04:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:04:58 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:04:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:04:58 --> Model Class Initialized
ERROR - 2025-03-28 20:04:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:04:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:04:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:04:59 --> Final output sent to browser
DEBUG - 2025-03-28 20:04:59 --> Total execution time: 0.1410
INFO - 2025-03-28 20:05:15 --> Config Class Initialized
INFO - 2025-03-28 20:05:15 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:15 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:15 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:15 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:15 --> Router Class Initialized
INFO - 2025-03-28 20:05:15 --> Output Class Initialized
INFO - 2025-03-28 20:05:15 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:15 --> Input Class Initialized
INFO - 2025-03-28 20:05:15 --> Language Class Initialized
INFO - 2025-03-28 20:05:15 --> Language Class Initialized
INFO - 2025-03-28 20:05:15 --> Config Class Initialized
INFO - 2025-03-28 20:05:15 --> Loader Class Initialized
INFO - 2025-03-28 20:05:15 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:15 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:15 --> Email Class Initialized
INFO - 2025-03-28 20:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:15 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:15 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:15 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:15 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:15 --> Model Class Initialized
INFO - 2025-03-28 20:05:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:05:15 --> INFO: Category Created Successfully -> Food->Rice & Grains
INFO - 2025-03-28 20:05:15 --> Config Class Initialized
INFO - 2025-03-28 20:05:15 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:15 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:15 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:15 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:15 --> Router Class Initialized
INFO - 2025-03-28 20:05:15 --> Output Class Initialized
INFO - 2025-03-28 20:05:15 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:15 --> Input Class Initialized
INFO - 2025-03-28 20:05:15 --> Language Class Initialized
INFO - 2025-03-28 20:05:15 --> Language Class Initialized
INFO - 2025-03-28 20:05:15 --> Config Class Initialized
INFO - 2025-03-28 20:05:15 --> Loader Class Initialized
INFO - 2025-03-28 20:05:15 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:15 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:15 --> Email Class Initialized
INFO - 2025-03-28 20:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:15 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:15 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:15 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:15 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:05:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:05:15 --> Model Class Initialized
ERROR - 2025-03-28 20:05:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:05:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:05:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:05:15 --> Final output sent to browser
DEBUG - 2025-03-28 20:05:15 --> Total execution time: 0.1479
INFO - 2025-03-28 20:05:23 --> Config Class Initialized
INFO - 2025-03-28 20:05:23 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:23 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:23 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:23 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:23 --> Router Class Initialized
INFO - 2025-03-28 20:05:23 --> Output Class Initialized
INFO - 2025-03-28 20:05:23 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:23 --> Input Class Initialized
INFO - 2025-03-28 20:05:23 --> Language Class Initialized
INFO - 2025-03-28 20:05:23 --> Language Class Initialized
INFO - 2025-03-28 20:05:23 --> Config Class Initialized
INFO - 2025-03-28 20:05:23 --> Loader Class Initialized
INFO - 2025-03-28 20:05:23 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:23 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:23 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:23 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:23 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:23 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:23 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:23 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:23 --> Email Class Initialized
INFO - 2025-03-28 20:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:23 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:23 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:23 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:23 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:23 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:05:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:05:23 --> Model Class Initialized
ERROR - 2025-03-28 20:05:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:05:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:05:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:05:23 --> Final output sent to browser
DEBUG - 2025-03-28 20:05:23 --> Total execution time: 0.0898
INFO - 2025-03-28 20:05:35 --> Config Class Initialized
INFO - 2025-03-28 20:05:35 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:35 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:35 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:35 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:35 --> Router Class Initialized
INFO - 2025-03-28 20:05:35 --> Output Class Initialized
INFO - 2025-03-28 20:05:35 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:35 --> Input Class Initialized
INFO - 2025-03-28 20:05:35 --> Language Class Initialized
INFO - 2025-03-28 20:05:35 --> Language Class Initialized
INFO - 2025-03-28 20:05:35 --> Config Class Initialized
INFO - 2025-03-28 20:05:35 --> Loader Class Initialized
INFO - 2025-03-28 20:05:35 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:35 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:35 --> Email Class Initialized
INFO - 2025-03-28 20:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:35 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:35 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:35 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:35 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:35 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:35 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:35 --> Model Class Initialized
INFO - 2025-03-28 20:05:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:05:35 --> INFO: Category Created Successfully -> Food->Rice & Grains->Basmati Rice
INFO - 2025-03-28 20:05:35 --> Config Class Initialized
INFO - 2025-03-28 20:05:35 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:35 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:35 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:35 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:35 --> Router Class Initialized
INFO - 2025-03-28 20:05:35 --> Output Class Initialized
INFO - 2025-03-28 20:05:35 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:35 --> Input Class Initialized
INFO - 2025-03-28 20:05:35 --> Language Class Initialized
INFO - 2025-03-28 20:05:35 --> Language Class Initialized
INFO - 2025-03-28 20:05:35 --> Config Class Initialized
INFO - 2025-03-28 20:05:35 --> Loader Class Initialized
INFO - 2025-03-28 20:05:35 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:35 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:35 --> Email Class Initialized
INFO - 2025-03-28 20:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:35 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:35 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:35 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:35 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:35 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:35 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:35 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:05:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:05:35 --> Model Class Initialized
ERROR - 2025-03-28 20:05:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:05:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:05:35 --> Final output sent to browser
DEBUG - 2025-03-28 20:05:35 --> Total execution time: 0.1294
INFO - 2025-03-28 20:05:44 --> Config Class Initialized
INFO - 2025-03-28 20:05:44 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:44 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:44 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:44 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:44 --> Router Class Initialized
INFO - 2025-03-28 20:05:44 --> Output Class Initialized
INFO - 2025-03-28 20:05:44 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:44 --> Input Class Initialized
INFO - 2025-03-28 20:05:44 --> Language Class Initialized
INFO - 2025-03-28 20:05:44 --> Language Class Initialized
INFO - 2025-03-28 20:05:44 --> Config Class Initialized
INFO - 2025-03-28 20:05:44 --> Loader Class Initialized
INFO - 2025-03-28 20:05:44 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:44 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:44 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:44 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:44 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:44 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:44 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:44 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:44 --> Email Class Initialized
INFO - 2025-03-28 20:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:44 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:44 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:44 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:44 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:44 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:05:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:05:44 --> Model Class Initialized
ERROR - 2025-03-28 20:05:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:05:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:05:44 --> Final output sent to browser
DEBUG - 2025-03-28 20:05:44 --> Total execution time: 0.1185
INFO - 2025-03-28 20:05:52 --> Config Class Initialized
INFO - 2025-03-28 20:05:52 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:52 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:52 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:52 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:52 --> Router Class Initialized
INFO - 2025-03-28 20:05:52 --> Output Class Initialized
INFO - 2025-03-28 20:05:52 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:52 --> Input Class Initialized
INFO - 2025-03-28 20:05:52 --> Language Class Initialized
INFO - 2025-03-28 20:05:52 --> Language Class Initialized
INFO - 2025-03-28 20:05:52 --> Config Class Initialized
INFO - 2025-03-28 20:05:52 --> Loader Class Initialized
INFO - 2025-03-28 20:05:52 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:52 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:52 --> Email Class Initialized
INFO - 2025-03-28 20:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:52 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:52 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:52 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:52 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:52 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:52 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:52 --> Model Class Initialized
INFO - 2025-03-28 20:05:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:05:52 --> INFO: Category Created Successfully -> Food->Rice & Grains->Parboiled Rice
INFO - 2025-03-28 20:05:52 --> Config Class Initialized
INFO - 2025-03-28 20:05:52 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:52 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:52 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:52 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:52 --> Router Class Initialized
INFO - 2025-03-28 20:05:52 --> Output Class Initialized
INFO - 2025-03-28 20:05:52 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:52 --> Input Class Initialized
INFO - 2025-03-28 20:05:52 --> Language Class Initialized
INFO - 2025-03-28 20:05:52 --> Language Class Initialized
INFO - 2025-03-28 20:05:52 --> Config Class Initialized
INFO - 2025-03-28 20:05:52 --> Loader Class Initialized
INFO - 2025-03-28 20:05:52 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:52 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:52 --> Email Class Initialized
INFO - 2025-03-28 20:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:52 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:52 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:52 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:52 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:52 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:52 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:52 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:05:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:05:52 --> Model Class Initialized
ERROR - 2025-03-28 20:05:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:05:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:05:52 --> Final output sent to browser
DEBUG - 2025-03-28 20:05:52 --> Total execution time: 0.1278
INFO - 2025-03-28 20:05:58 --> Config Class Initialized
INFO - 2025-03-28 20:05:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:05:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:05:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:05:58 --> URI Class Initialized
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:05:58 --> Router Class Initialized
INFO - 2025-03-28 20:05:58 --> Output Class Initialized
INFO - 2025-03-28 20:05:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:05:58 --> Input Class Initialized
INFO - 2025-03-28 20:05:58 --> Language Class Initialized
INFO - 2025-03-28 20:05:58 --> Language Class Initialized
INFO - 2025-03-28 20:05:58 --> Config Class Initialized
INFO - 2025-03-28 20:05:58 --> Loader Class Initialized
INFO - 2025-03-28 20:05:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:05:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:05:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:05:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:05:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:05:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:05:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:05:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:05:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:05:58 --> Email Class Initialized
INFO - 2025-03-28 20:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:05:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:05:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:05:58 --> Controller Class Initialized
DEBUG - 2025-03-28 20:05:58 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:05:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:05:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:05:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:05:58 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:05:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:05:58 --> Model Class Initialized
ERROR - 2025-03-28 20:05:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:05:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:05:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:05:58 --> Final output sent to browser
DEBUG - 2025-03-28 20:05:58 --> Total execution time: 0.1416
INFO - 2025-03-28 20:06:05 --> Config Class Initialized
INFO - 2025-03-28 20:06:05 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:05 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:05 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:05 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:05 --> Router Class Initialized
INFO - 2025-03-28 20:06:05 --> Output Class Initialized
INFO - 2025-03-28 20:06:05 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:05 --> Input Class Initialized
INFO - 2025-03-28 20:06:05 --> Language Class Initialized
INFO - 2025-03-28 20:06:05 --> Language Class Initialized
INFO - 2025-03-28 20:06:05 --> Config Class Initialized
INFO - 2025-03-28 20:06:05 --> Loader Class Initialized
INFO - 2025-03-28 20:06:05 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:05 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:05 --> Email Class Initialized
INFO - 2025-03-28 20:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:05 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:05 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:05 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:05 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:05 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:05 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:05 --> Model Class Initialized
INFO - 2025-03-28 20:06:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:06:05 --> INFO: Category Created Successfully -> Food->Rice & Grains->Brown Rice
INFO - 2025-03-28 20:06:05 --> Config Class Initialized
INFO - 2025-03-28 20:06:05 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:05 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:05 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:05 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:05 --> Router Class Initialized
INFO - 2025-03-28 20:06:05 --> Output Class Initialized
INFO - 2025-03-28 20:06:05 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:05 --> Input Class Initialized
INFO - 2025-03-28 20:06:05 --> Language Class Initialized
INFO - 2025-03-28 20:06:05 --> Language Class Initialized
INFO - 2025-03-28 20:06:05 --> Config Class Initialized
INFO - 2025-03-28 20:06:05 --> Loader Class Initialized
INFO - 2025-03-28 20:06:05 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:05 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:05 --> Email Class Initialized
INFO - 2025-03-28 20:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:05 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:05 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:05 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:05 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:05 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:05 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:05 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:05 --> Model Class Initialized
ERROR - 2025-03-28 20:06:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:06:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:06:05 --> Final output sent to browser
DEBUG - 2025-03-28 20:06:05 --> Total execution time: 0.1199
INFO - 2025-03-28 20:06:12 --> Config Class Initialized
INFO - 2025-03-28 20:06:12 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:12 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:12 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:12 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:12 --> Router Class Initialized
INFO - 2025-03-28 20:06:12 --> Output Class Initialized
INFO - 2025-03-28 20:06:12 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:12 --> Input Class Initialized
INFO - 2025-03-28 20:06:12 --> Language Class Initialized
INFO - 2025-03-28 20:06:12 --> Language Class Initialized
INFO - 2025-03-28 20:06:12 --> Config Class Initialized
INFO - 2025-03-28 20:06:12 --> Loader Class Initialized
INFO - 2025-03-28 20:06:12 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:12 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:12 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:12 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:12 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:12 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:12 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:12 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:12 --> Email Class Initialized
INFO - 2025-03-28 20:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:12 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:12 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:12 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:12 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:12 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:12 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:12 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:12 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:12 --> Model Class Initialized
ERROR - 2025-03-28 20:06:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:06:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:06:12 --> Final output sent to browser
DEBUG - 2025-03-28 20:06:12 --> Total execution time: 0.1137
INFO - 2025-03-28 20:06:19 --> Config Class Initialized
INFO - 2025-03-28 20:06:19 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:19 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:19 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:19 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:19 --> Router Class Initialized
INFO - 2025-03-28 20:06:19 --> Output Class Initialized
INFO - 2025-03-28 20:06:19 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:19 --> Input Class Initialized
INFO - 2025-03-28 20:06:19 --> Language Class Initialized
INFO - 2025-03-28 20:06:19 --> Language Class Initialized
INFO - 2025-03-28 20:06:19 --> Config Class Initialized
INFO - 2025-03-28 20:06:19 --> Loader Class Initialized
INFO - 2025-03-28 20:06:19 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:19 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:19 --> Email Class Initialized
INFO - 2025-03-28 20:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:19 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:19 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:19 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:19 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:19 --> Model Class Initialized
INFO - 2025-03-28 20:06:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:06:19 --> INFO: Category Created Successfully -> Food->Rice & Grains->Lentils & Pulses
INFO - 2025-03-28 20:06:19 --> Config Class Initialized
INFO - 2025-03-28 20:06:19 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:19 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:19 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:19 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:19 --> Router Class Initialized
INFO - 2025-03-28 20:06:19 --> Output Class Initialized
INFO - 2025-03-28 20:06:19 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:19 --> Input Class Initialized
INFO - 2025-03-28 20:06:19 --> Language Class Initialized
INFO - 2025-03-28 20:06:19 --> Language Class Initialized
INFO - 2025-03-28 20:06:19 --> Config Class Initialized
INFO - 2025-03-28 20:06:19 --> Loader Class Initialized
INFO - 2025-03-28 20:06:19 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:19 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:19 --> Email Class Initialized
INFO - 2025-03-28 20:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:19 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:19 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:19 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:19 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:19 --> Model Class Initialized
ERROR - 2025-03-28 20:06:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:06:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:06:19 --> Final output sent to browser
DEBUG - 2025-03-28 20:06:19 --> Total execution time: 0.1126
INFO - 2025-03-28 20:06:24 --> Config Class Initialized
INFO - 2025-03-28 20:06:24 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:24 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:24 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:24 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:24 --> Router Class Initialized
INFO - 2025-03-28 20:06:24 --> Output Class Initialized
INFO - 2025-03-28 20:06:24 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:24 --> Input Class Initialized
INFO - 2025-03-28 20:06:24 --> Language Class Initialized
INFO - 2025-03-28 20:06:24 --> Language Class Initialized
INFO - 2025-03-28 20:06:24 --> Config Class Initialized
INFO - 2025-03-28 20:06:24 --> Loader Class Initialized
INFO - 2025-03-28 20:06:24 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:24 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:24 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:24 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:24 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:24 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:24 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:24 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:24 --> Email Class Initialized
INFO - 2025-03-28 20:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:24 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:24 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:24 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:24 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:24 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:24 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:24 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:24 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:24 --> Model Class Initialized
ERROR - 2025-03-28 20:06:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:06:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:06:24 --> Final output sent to browser
DEBUG - 2025-03-28 20:06:24 --> Total execution time: 0.1253
INFO - 2025-03-28 20:06:33 --> Config Class Initialized
INFO - 2025-03-28 20:06:33 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:33 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:33 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:33 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:33 --> Router Class Initialized
INFO - 2025-03-28 20:06:33 --> Output Class Initialized
INFO - 2025-03-28 20:06:33 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:33 --> Input Class Initialized
INFO - 2025-03-28 20:06:33 --> Language Class Initialized
INFO - 2025-03-28 20:06:33 --> Language Class Initialized
INFO - 2025-03-28 20:06:33 --> Config Class Initialized
INFO - 2025-03-28 20:06:33 --> Loader Class Initialized
INFO - 2025-03-28 20:06:33 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:33 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:33 --> Email Class Initialized
INFO - 2025-03-28 20:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:33 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:33 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:33 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:33 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:33 --> Model Class Initialized
INFO - 2025-03-28 20:06:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:06:33 --> INFO: Category Created Successfully -> Food->Rice & Grains->Quinoa
INFO - 2025-03-28 20:06:33 --> Config Class Initialized
INFO - 2025-03-28 20:06:33 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:33 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:33 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:33 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:33 --> Router Class Initialized
INFO - 2025-03-28 20:06:33 --> Output Class Initialized
INFO - 2025-03-28 20:06:33 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:33 --> Input Class Initialized
INFO - 2025-03-28 20:06:33 --> Language Class Initialized
INFO - 2025-03-28 20:06:33 --> Language Class Initialized
INFO - 2025-03-28 20:06:33 --> Config Class Initialized
INFO - 2025-03-28 20:06:33 --> Loader Class Initialized
INFO - 2025-03-28 20:06:33 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:33 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:33 --> Email Class Initialized
INFO - 2025-03-28 20:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:33 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:33 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:33 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:33 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:33 --> Model Class Initialized
ERROR - 2025-03-28 20:06:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:06:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:06:33 --> Final output sent to browser
DEBUG - 2025-03-28 20:06:33 --> Total execution time: 0.1170
INFO - 2025-03-28 20:06:44 --> Config Class Initialized
INFO - 2025-03-28 20:06:44 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:44 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:44 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:44 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:44 --> Router Class Initialized
INFO - 2025-03-28 20:06:44 --> Output Class Initialized
INFO - 2025-03-28 20:06:44 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:44 --> Input Class Initialized
INFO - 2025-03-28 20:06:44 --> Language Class Initialized
INFO - 2025-03-28 20:06:44 --> Language Class Initialized
INFO - 2025-03-28 20:06:44 --> Config Class Initialized
INFO - 2025-03-28 20:06:44 --> Loader Class Initialized
INFO - 2025-03-28 20:06:44 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:44 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:44 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:44 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:44 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:44 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:44 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:44 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:44 --> Email Class Initialized
INFO - 2025-03-28 20:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:44 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:44 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:44 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:44 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:44 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:44 --> Model Class Initialized
ERROR - 2025-03-28 20:06:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:06:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:06:44 --> Final output sent to browser
DEBUG - 2025-03-28 20:06:44 --> Total execution time: 0.0919
INFO - 2025-03-28 20:06:48 --> Config Class Initialized
INFO - 2025-03-28 20:06:48 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:48 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:48 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:48 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:48 --> Router Class Initialized
INFO - 2025-03-28 20:06:48 --> Output Class Initialized
INFO - 2025-03-28 20:06:48 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:48 --> Input Class Initialized
INFO - 2025-03-28 20:06:48 --> Language Class Initialized
INFO - 2025-03-28 20:06:48 --> Language Class Initialized
INFO - 2025-03-28 20:06:48 --> Config Class Initialized
INFO - 2025-03-28 20:06:48 --> Loader Class Initialized
INFO - 2025-03-28 20:06:48 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:48 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:48 --> Email Class Initialized
INFO - 2025-03-28 20:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:48 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:48 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:48 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:48 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:48 --> Model Class Initialized
INFO - 2025-03-28 20:06:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:06:48 --> INFO: Category Created Successfully -> Noodles & Pasta
INFO - 2025-03-28 20:06:48 --> Config Class Initialized
INFO - 2025-03-28 20:06:48 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:48 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:48 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:48 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:48 --> Router Class Initialized
INFO - 2025-03-28 20:06:48 --> Output Class Initialized
INFO - 2025-03-28 20:06:48 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:48 --> Input Class Initialized
INFO - 2025-03-28 20:06:48 --> Language Class Initialized
INFO - 2025-03-28 20:06:48 --> Language Class Initialized
INFO - 2025-03-28 20:06:48 --> Config Class Initialized
INFO - 2025-03-28 20:06:48 --> Loader Class Initialized
INFO - 2025-03-28 20:06:48 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:48 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:48 --> Email Class Initialized
INFO - 2025-03-28 20:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:48 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:48 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:48 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:48 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:48 --> Model Class Initialized
ERROR - 2025-03-28 20:06:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:06:48 --> Final output sent to browser
DEBUG - 2025-03-28 20:06:48 --> Total execution time: 0.1450
INFO - 2025-03-28 20:06:59 --> Config Class Initialized
INFO - 2025-03-28 20:06:59 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:59 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:59 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:59 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:59 --> Router Class Initialized
INFO - 2025-03-28 20:06:59 --> Output Class Initialized
INFO - 2025-03-28 20:06:59 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:59 --> Input Class Initialized
INFO - 2025-03-28 20:06:59 --> Language Class Initialized
INFO - 2025-03-28 20:06:59 --> Language Class Initialized
INFO - 2025-03-28 20:06:59 --> Config Class Initialized
INFO - 2025-03-28 20:06:59 --> Loader Class Initialized
INFO - 2025-03-28 20:06:59 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:59 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:59 --> Email Class Initialized
INFO - 2025-03-28 20:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:59 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:59 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:59 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:59 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:59 --> Model Class Initialized
INFO - 2025-03-28 20:06:59 --> Config Class Initialized
INFO - 2025-03-28 20:06:59 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:06:59 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:06:59 --> Utf8 Class Initialized
INFO - 2025-03-28 20:06:59 --> URI Class Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:06:59 --> Router Class Initialized
INFO - 2025-03-28 20:06:59 --> Output Class Initialized
INFO - 2025-03-28 20:06:59 --> Security Class Initialized
DEBUG - 2025-03-28 20:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:06:59 --> Input Class Initialized
INFO - 2025-03-28 20:06:59 --> Language Class Initialized
INFO - 2025-03-28 20:06:59 --> Language Class Initialized
INFO - 2025-03-28 20:06:59 --> Config Class Initialized
INFO - 2025-03-28 20:06:59 --> Loader Class Initialized
INFO - 2025-03-28 20:06:59 --> Helper loaded: url_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: file_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: html_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: form_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: text_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:06:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:06:59 --> Database Driver Class Initialized
INFO - 2025-03-28 20:06:59 --> Email Class Initialized
INFO - 2025-03-28 20:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:06:59 --> Form Validation Class Initialized
INFO - 2025-03-28 20:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:06:59 --> Pagination Class Initialized
INFO - 2025-03-28 20:06:59 --> Controller Class Initialized
DEBUG - 2025-03-28 20:06:59 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:06:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:06:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:06:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:06:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:06:59 --> Model Class Initialized
ERROR - 2025-03-28 20:06:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:06:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:06:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:07:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:07:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:07:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:07:00 --> Final output sent to browser
DEBUG - 2025-03-28 20:07:00 --> Total execution time: 0.1105
INFO - 2025-03-28 20:07:15 --> Config Class Initialized
INFO - 2025-03-28 20:07:15 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:07:15 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:07:15 --> Utf8 Class Initialized
INFO - 2025-03-28 20:07:15 --> URI Class Initialized
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:07:15 --> Router Class Initialized
INFO - 2025-03-28 20:07:15 --> Output Class Initialized
INFO - 2025-03-28 20:07:15 --> Security Class Initialized
DEBUG - 2025-03-28 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:07:15 --> Input Class Initialized
INFO - 2025-03-28 20:07:15 --> Language Class Initialized
INFO - 2025-03-28 20:07:15 --> Language Class Initialized
INFO - 2025-03-28 20:07:15 --> Config Class Initialized
INFO - 2025-03-28 20:07:15 --> Loader Class Initialized
INFO - 2025-03-28 20:07:15 --> Helper loaded: url_helper
INFO - 2025-03-28 20:07:15 --> Helper loaded: file_helper
INFO - 2025-03-28 20:07:15 --> Helper loaded: html_helper
INFO - 2025-03-28 20:07:15 --> Helper loaded: form_helper
INFO - 2025-03-28 20:07:15 --> Helper loaded: text_helper
INFO - 2025-03-28 20:07:15 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:07:15 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:07:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:07:15 --> Database Driver Class Initialized
INFO - 2025-03-28 20:07:15 --> Email Class Initialized
INFO - 2025-03-28 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:07:15 --> Form Validation Class Initialized
INFO - 2025-03-28 20:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:07:15 --> Pagination Class Initialized
INFO - 2025-03-28 20:07:15 --> Controller Class Initialized
DEBUG - 2025-03-28 20:07:15 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:07:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:07:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:07:15 --> Model Class Initialized
DEBUG - 2025-03-28 20:07:15 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:07:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:07:15 --> Model Class Initialized
ERROR - 2025-03-28 20:07:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:07:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:07:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:07:15 --> Final output sent to browser
DEBUG - 2025-03-28 20:07:15 --> Total execution time: 0.1433
INFO - 2025-03-28 20:09:44 --> Config Class Initialized
INFO - 2025-03-28 20:09:44 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:09:44 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:09:44 --> Utf8 Class Initialized
INFO - 2025-03-28 20:09:44 --> URI Class Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:09:44 --> Router Class Initialized
INFO - 2025-03-28 20:09:44 --> Output Class Initialized
INFO - 2025-03-28 20:09:44 --> Security Class Initialized
DEBUG - 2025-03-28 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:09:44 --> Input Class Initialized
INFO - 2025-03-28 20:09:44 --> Language Class Initialized
INFO - 2025-03-28 20:09:44 --> Language Class Initialized
INFO - 2025-03-28 20:09:44 --> Config Class Initialized
INFO - 2025-03-28 20:09:44 --> Loader Class Initialized
INFO - 2025-03-28 20:09:44 --> Helper loaded: url_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: file_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: html_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: form_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: text_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:09:44 --> Database Driver Class Initialized
INFO - 2025-03-28 20:09:44 --> Email Class Initialized
INFO - 2025-03-28 20:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:09:44 --> Form Validation Class Initialized
INFO - 2025-03-28 20:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:09:44 --> Pagination Class Initialized
INFO - 2025-03-28 20:09:44 --> Controller Class Initialized
DEBUG - 2025-03-28 20:09:44 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:09:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:09:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:09:44 --> Model Class Initialized
INFO - 2025-03-28 20:09:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:09:44 --> INFO: Category Created Successfully -> Food->Rice & Grains->Instant Noodles
INFO - 2025-03-28 20:09:44 --> Config Class Initialized
INFO - 2025-03-28 20:09:44 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:09:44 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:09:44 --> Utf8 Class Initialized
INFO - 2025-03-28 20:09:44 --> URI Class Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:09:44 --> Router Class Initialized
INFO - 2025-03-28 20:09:44 --> Output Class Initialized
INFO - 2025-03-28 20:09:44 --> Security Class Initialized
DEBUG - 2025-03-28 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:09:44 --> Input Class Initialized
INFO - 2025-03-28 20:09:44 --> Language Class Initialized
INFO - 2025-03-28 20:09:44 --> Language Class Initialized
INFO - 2025-03-28 20:09:44 --> Config Class Initialized
INFO - 2025-03-28 20:09:44 --> Loader Class Initialized
INFO - 2025-03-28 20:09:44 --> Helper loaded: url_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: file_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: html_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: form_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: text_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:09:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:09:44 --> Database Driver Class Initialized
INFO - 2025-03-28 20:09:44 --> Email Class Initialized
INFO - 2025-03-28 20:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:09:44 --> Form Validation Class Initialized
INFO - 2025-03-28 20:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:09:44 --> Pagination Class Initialized
INFO - 2025-03-28 20:09:44 --> Controller Class Initialized
DEBUG - 2025-03-28 20:09:44 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:09:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:09:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:09:44 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:09:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:09:44 --> Model Class Initialized
ERROR - 2025-03-28 20:09:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:09:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:09:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:09:44 --> Final output sent to browser
DEBUG - 2025-03-28 20:09:44 --> Total execution time: 0.1124
INFO - 2025-03-28 20:09:47 --> Config Class Initialized
INFO - 2025-03-28 20:09:47 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:09:47 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:09:47 --> Utf8 Class Initialized
INFO - 2025-03-28 20:09:47 --> URI Class Initialized
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:09:47 --> Router Class Initialized
INFO - 2025-03-28 20:09:47 --> Output Class Initialized
INFO - 2025-03-28 20:09:47 --> Security Class Initialized
DEBUG - 2025-03-28 20:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:09:47 --> Input Class Initialized
INFO - 2025-03-28 20:09:47 --> Language Class Initialized
INFO - 2025-03-28 20:09:47 --> Language Class Initialized
INFO - 2025-03-28 20:09:47 --> Config Class Initialized
INFO - 2025-03-28 20:09:47 --> Loader Class Initialized
INFO - 2025-03-28 20:09:47 --> Helper loaded: url_helper
INFO - 2025-03-28 20:09:47 --> Helper loaded: file_helper
INFO - 2025-03-28 20:09:47 --> Helper loaded: html_helper
INFO - 2025-03-28 20:09:47 --> Helper loaded: form_helper
INFO - 2025-03-28 20:09:47 --> Helper loaded: text_helper
INFO - 2025-03-28 20:09:47 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:09:47 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:09:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:09:47 --> Database Driver Class Initialized
INFO - 2025-03-28 20:09:47 --> Email Class Initialized
INFO - 2025-03-28 20:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:09:47 --> Form Validation Class Initialized
INFO - 2025-03-28 20:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:09:47 --> Pagination Class Initialized
INFO - 2025-03-28 20:09:47 --> Controller Class Initialized
DEBUG - 2025-03-28 20:09:47 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:09:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:09:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:09:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:09:47 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"46","category_name":"Food->Rice & Grains->Instant Noodles","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:09:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:09:47 --> Model Class Initialized
ERROR - 2025-03-28 20:09:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:09:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:09:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:09:47 --> Final output sent to browser
DEBUG - 2025-03-28 20:09:47 --> Total execution time: 0.1567
INFO - 2025-03-28 20:10:29 --> Config Class Initialized
INFO - 2025-03-28 20:10:29 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:10:29 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:10:29 --> Utf8 Class Initialized
INFO - 2025-03-28 20:10:29 --> URI Class Initialized
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:10:29 --> Router Class Initialized
INFO - 2025-03-28 20:10:29 --> Output Class Initialized
INFO - 2025-03-28 20:10:29 --> Security Class Initialized
DEBUG - 2025-03-28 20:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:10:29 --> Input Class Initialized
INFO - 2025-03-28 20:10:29 --> Language Class Initialized
INFO - 2025-03-28 20:10:29 --> Language Class Initialized
INFO - 2025-03-28 20:10:29 --> Config Class Initialized
INFO - 2025-03-28 20:10:29 --> Loader Class Initialized
INFO - 2025-03-28 20:10:29 --> Helper loaded: url_helper
INFO - 2025-03-28 20:10:29 --> Helper loaded: file_helper
INFO - 2025-03-28 20:10:29 --> Helper loaded: html_helper
INFO - 2025-03-28 20:10:29 --> Helper loaded: form_helper
INFO - 2025-03-28 20:10:29 --> Helper loaded: text_helper
INFO - 2025-03-28 20:10:29 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:10:29 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:10:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:10:29 --> Database Driver Class Initialized
INFO - 2025-03-28 20:10:29 --> Email Class Initialized
INFO - 2025-03-28 20:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:10:29 --> Form Validation Class Initialized
INFO - 2025-03-28 20:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:10:29 --> Pagination Class Initialized
INFO - 2025-03-28 20:10:29 --> Controller Class Initialized
DEBUG - 2025-03-28 20:10:29 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:10:29 --> Model Class Initialized
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:10:29 --> Model Class Initialized
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:10:29 --> Model Class Initialized
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:10:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:10:29 --> Model Class Initialized
ERROR - 2025-03-28 20:10:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:10:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:10:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:10:29 --> Final output sent to browser
DEBUG - 2025-03-28 20:10:29 --> Total execution time: 0.0985
INFO - 2025-03-28 20:10:42 --> Config Class Initialized
INFO - 2025-03-28 20:10:42 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:10:42 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:10:42 --> Utf8 Class Initialized
INFO - 2025-03-28 20:10:42 --> URI Class Initialized
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:10:42 --> Router Class Initialized
INFO - 2025-03-28 20:10:42 --> Output Class Initialized
INFO - 2025-03-28 20:10:42 --> Security Class Initialized
DEBUG - 2025-03-28 20:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:10:42 --> Input Class Initialized
INFO - 2025-03-28 20:10:42 --> Language Class Initialized
INFO - 2025-03-28 20:10:42 --> Language Class Initialized
INFO - 2025-03-28 20:10:42 --> Config Class Initialized
INFO - 2025-03-28 20:10:42 --> Loader Class Initialized
INFO - 2025-03-28 20:10:42 --> Helper loaded: url_helper
INFO - 2025-03-28 20:10:42 --> Helper loaded: file_helper
INFO - 2025-03-28 20:10:42 --> Helper loaded: html_helper
INFO - 2025-03-28 20:10:42 --> Helper loaded: form_helper
INFO - 2025-03-28 20:10:42 --> Helper loaded: text_helper
INFO - 2025-03-28 20:10:42 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:10:42 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:10:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:10:42 --> Database Driver Class Initialized
INFO - 2025-03-28 20:10:42 --> Email Class Initialized
INFO - 2025-03-28 20:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:10:42 --> Form Validation Class Initialized
INFO - 2025-03-28 20:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:10:42 --> Pagination Class Initialized
INFO - 2025-03-28 20:10:42 --> Controller Class Initialized
DEBUG - 2025-03-28 20:10:42 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:10:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:10:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:10:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:10:42 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"46","category_name":"Food->Rice & Grains->Instant Noodles","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:10:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:10:42 --> Model Class Initialized
ERROR - 2025-03-28 20:10:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:10:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:10:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:10:42 --> Final output sent to browser
DEBUG - 2025-03-28 20:10:42 --> Total execution time: 0.1225
INFO - 2025-03-28 20:11:18 --> Config Class Initialized
INFO - 2025-03-28 20:11:18 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:11:18 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:11:18 --> Utf8 Class Initialized
INFO - 2025-03-28 20:11:18 --> URI Class Initialized
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:11:18 --> Router Class Initialized
INFO - 2025-03-28 20:11:18 --> Output Class Initialized
INFO - 2025-03-28 20:11:18 --> Security Class Initialized
DEBUG - 2025-03-28 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:11:18 --> Input Class Initialized
INFO - 2025-03-28 20:11:18 --> Language Class Initialized
INFO - 2025-03-28 20:11:18 --> Language Class Initialized
INFO - 2025-03-28 20:11:18 --> Config Class Initialized
INFO - 2025-03-28 20:11:18 --> Loader Class Initialized
INFO - 2025-03-28 20:11:18 --> Helper loaded: url_helper
INFO - 2025-03-28 20:11:18 --> Helper loaded: file_helper
INFO - 2025-03-28 20:11:18 --> Helper loaded: html_helper
INFO - 2025-03-28 20:11:18 --> Helper loaded: form_helper
INFO - 2025-03-28 20:11:18 --> Helper loaded: text_helper
INFO - 2025-03-28 20:11:18 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:11:18 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:11:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:11:18 --> Database Driver Class Initialized
INFO - 2025-03-28 20:11:18 --> Email Class Initialized
INFO - 2025-03-28 20:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:11:18 --> Form Validation Class Initialized
INFO - 2025-03-28 20:11:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:11:18 --> Pagination Class Initialized
INFO - 2025-03-28 20:11:18 --> Controller Class Initialized
DEBUG - 2025-03-28 20:11:18 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:11:18 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:11:18 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:11:18 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:11:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:11:18 --> Model Class Initialized
ERROR - 2025-03-28 20:11:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:11:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:11:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:11:18 --> Final output sent to browser
DEBUG - 2025-03-28 20:11:18 --> Total execution time: 0.1594
INFO - 2025-03-28 20:11:45 --> Config Class Initialized
INFO - 2025-03-28 20:11:45 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:11:45 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:11:45 --> Utf8 Class Initialized
INFO - 2025-03-28 20:11:45 --> URI Class Initialized
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:11:45 --> Router Class Initialized
INFO - 2025-03-28 20:11:45 --> Output Class Initialized
INFO - 2025-03-28 20:11:45 --> Security Class Initialized
DEBUG - 2025-03-28 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:11:45 --> Input Class Initialized
INFO - 2025-03-28 20:11:45 --> Language Class Initialized
INFO - 2025-03-28 20:11:45 --> Language Class Initialized
INFO - 2025-03-28 20:11:45 --> Config Class Initialized
INFO - 2025-03-28 20:11:45 --> Loader Class Initialized
INFO - 2025-03-28 20:11:45 --> Helper loaded: url_helper
INFO - 2025-03-28 20:11:45 --> Helper loaded: file_helper
INFO - 2025-03-28 20:11:45 --> Helper loaded: html_helper
INFO - 2025-03-28 20:11:45 --> Helper loaded: form_helper
INFO - 2025-03-28 20:11:45 --> Helper loaded: text_helper
INFO - 2025-03-28 20:11:45 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:11:45 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:11:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:11:45 --> Database Driver Class Initialized
INFO - 2025-03-28 20:11:45 --> Email Class Initialized
INFO - 2025-03-28 20:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:11:45 --> Form Validation Class Initialized
INFO - 2025-03-28 20:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:11:45 --> Pagination Class Initialized
INFO - 2025-03-28 20:11:45 --> Controller Class Initialized
DEBUG - 2025-03-28 20:11:45 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:11:45 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:11:45 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:11:45 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:45 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"46","category_name":"Food->Rice & Grains->Instant Noodles","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:11:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:11:45 --> Model Class Initialized
ERROR - 2025-03-28 20:11:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:11:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:11:45 --> Final output sent to browser
DEBUG - 2025-03-28 20:11:45 --> Total execution time: 0.0884
INFO - 2025-03-28 20:11:58 --> Config Class Initialized
INFO - 2025-03-28 20:11:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:11:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:11:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:11:58 --> URI Class Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:11:58 --> Router Class Initialized
INFO - 2025-03-28 20:11:58 --> Output Class Initialized
INFO - 2025-03-28 20:11:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:11:58 --> Input Class Initialized
INFO - 2025-03-28 20:11:58 --> Language Class Initialized
INFO - 2025-03-28 20:11:58 --> Language Class Initialized
INFO - 2025-03-28 20:11:58 --> Config Class Initialized
INFO - 2025-03-28 20:11:58 --> Loader Class Initialized
INFO - 2025-03-28 20:11:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:11:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:11:58 --> Email Class Initialized
INFO - 2025-03-28 20:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:11:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:11:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:11:58 --> Controller Class Initialized
DEBUG - 2025-03-28 20:11:58 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:11:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:11:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:11:58 --> Model Class Initialized
INFO - 2025-03-28 20:11:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:11:58 --> INFO: Category Created Successfully -> Food->Noodles & Pasta
INFO - 2025-03-28 20:11:58 --> Config Class Initialized
INFO - 2025-03-28 20:11:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:11:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:11:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:11:58 --> URI Class Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:11:58 --> Router Class Initialized
INFO - 2025-03-28 20:11:58 --> Output Class Initialized
INFO - 2025-03-28 20:11:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:11:58 --> Input Class Initialized
INFO - 2025-03-28 20:11:58 --> Language Class Initialized
INFO - 2025-03-28 20:11:58 --> Language Class Initialized
INFO - 2025-03-28 20:11:58 --> Config Class Initialized
INFO - 2025-03-28 20:11:58 --> Loader Class Initialized
INFO - 2025-03-28 20:11:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:11:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:11:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:11:58 --> Email Class Initialized
INFO - 2025-03-28 20:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:11:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:11:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:11:58 --> Controller Class Initialized
DEBUG - 2025-03-28 20:11:58 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:11:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:11:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:11:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:11:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:11:58 --> Model Class Initialized
ERROR - 2025-03-28 20:11:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:11:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:11:58 --> Final output sent to browser
DEBUG - 2025-03-28 20:11:58 --> Total execution time: 0.1545
INFO - 2025-03-28 20:12:08 --> Config Class Initialized
INFO - 2025-03-28 20:12:08 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:12:08 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:12:08 --> Utf8 Class Initialized
INFO - 2025-03-28 20:12:08 --> URI Class Initialized
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:12:08 --> Router Class Initialized
INFO - 2025-03-28 20:12:08 --> Output Class Initialized
INFO - 2025-03-28 20:12:08 --> Security Class Initialized
DEBUG - 2025-03-28 20:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:12:08 --> Input Class Initialized
INFO - 2025-03-28 20:12:08 --> Language Class Initialized
INFO - 2025-03-28 20:12:08 --> Language Class Initialized
INFO - 2025-03-28 20:12:08 --> Config Class Initialized
INFO - 2025-03-28 20:12:08 --> Loader Class Initialized
INFO - 2025-03-28 20:12:08 --> Helper loaded: url_helper
INFO - 2025-03-28 20:12:08 --> Helper loaded: file_helper
INFO - 2025-03-28 20:12:08 --> Helper loaded: html_helper
INFO - 2025-03-28 20:12:08 --> Helper loaded: form_helper
INFO - 2025-03-28 20:12:08 --> Helper loaded: text_helper
INFO - 2025-03-28 20:12:08 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:12:08 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:12:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:12:08 --> Database Driver Class Initialized
INFO - 2025-03-28 20:12:08 --> Email Class Initialized
INFO - 2025-03-28 20:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:12:08 --> Form Validation Class Initialized
INFO - 2025-03-28 20:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:12:08 --> Pagination Class Initialized
INFO - 2025-03-28 20:12:08 --> Controller Class Initialized
DEBUG - 2025-03-28 20:12:08 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:12:08 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:12:08 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:12:08 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:08 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"46","category_name":"Food->Rice & Grains->Instant Noodles","parent_id":"39","status":"1"},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"47","category_name":"Food->Noodles & Pasta","parent_id":"38","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"46","category_name":"Food->Rice & Grains->Instant Noodles","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:12:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:12:08 --> Model Class Initialized
ERROR - 2025-03-28 20:12:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:12:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:12:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:12:08 --> Final output sent to browser
DEBUG - 2025-03-28 20:12:08 --> Total execution time: 0.0925
INFO - 2025-03-28 20:12:13 --> Config Class Initialized
INFO - 2025-03-28 20:12:13 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:12:13 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:12:13 --> Utf8 Class Initialized
INFO - 2025-03-28 20:12:13 --> URI Class Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:12:13 --> Router Class Initialized
INFO - 2025-03-28 20:12:13 --> Output Class Initialized
INFO - 2025-03-28 20:12:13 --> Security Class Initialized
DEBUG - 2025-03-28 20:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:12:13 --> Input Class Initialized
INFO - 2025-03-28 20:12:13 --> Language Class Initialized
INFO - 2025-03-28 20:12:13 --> Language Class Initialized
INFO - 2025-03-28 20:12:13 --> Config Class Initialized
INFO - 2025-03-28 20:12:13 --> Loader Class Initialized
INFO - 2025-03-28 20:12:13 --> Helper loaded: url_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: file_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: html_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: form_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: text_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:12:13 --> Database Driver Class Initialized
INFO - 2025-03-28 20:12:13 --> Email Class Initialized
INFO - 2025-03-28 20:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:12:13 --> Form Validation Class Initialized
INFO - 2025-03-28 20:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:12:13 --> Pagination Class Initialized
INFO - 2025-03-28 20:12:13 --> Controller Class Initialized
DEBUG - 2025-03-28 20:12:13 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:12:13 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:12:13 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:12:13 --> Model Class Initialized
INFO - 2025-03-28 20:12:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:12:13 --> INFO: Category Updated Successfully -> Food->Noodles & Pasta->Food->Rice & Grains->Instant Noodles
INFO - 2025-03-28 20:12:13 --> Config Class Initialized
INFO - 2025-03-28 20:12:13 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:12:13 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:12:13 --> Utf8 Class Initialized
INFO - 2025-03-28 20:12:13 --> URI Class Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:12:13 --> Router Class Initialized
INFO - 2025-03-28 20:12:13 --> Output Class Initialized
INFO - 2025-03-28 20:12:13 --> Security Class Initialized
DEBUG - 2025-03-28 20:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:12:13 --> Input Class Initialized
INFO - 2025-03-28 20:12:13 --> Language Class Initialized
INFO - 2025-03-28 20:12:13 --> Language Class Initialized
INFO - 2025-03-28 20:12:13 --> Config Class Initialized
INFO - 2025-03-28 20:12:13 --> Loader Class Initialized
INFO - 2025-03-28 20:12:13 --> Helper loaded: url_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: file_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: html_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: form_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: text_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:12:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:12:13 --> Database Driver Class Initialized
INFO - 2025-03-28 20:12:13 --> Email Class Initialized
INFO - 2025-03-28 20:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:12:13 --> Form Validation Class Initialized
INFO - 2025-03-28 20:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:12:13 --> Pagination Class Initialized
INFO - 2025-03-28 20:12:13 --> Controller Class Initialized
DEBUG - 2025-03-28 20:12:13 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:12:13 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:12:13 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:12:13 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:12:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:12:13 --> Model Class Initialized
ERROR - 2025-03-28 20:12:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:12:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:12:13 --> Final output sent to browser
DEBUG - 2025-03-28 20:12:13 --> Total execution time: 0.1319
INFO - 2025-03-28 20:12:21 --> Config Class Initialized
INFO - 2025-03-28 20:12:21 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:12:21 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:12:21 --> Utf8 Class Initialized
INFO - 2025-03-28 20:12:21 --> URI Class Initialized
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:12:21 --> Router Class Initialized
INFO - 2025-03-28 20:12:21 --> Output Class Initialized
INFO - 2025-03-28 20:12:21 --> Security Class Initialized
DEBUG - 2025-03-28 20:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:12:21 --> Input Class Initialized
INFO - 2025-03-28 20:12:21 --> Language Class Initialized
INFO - 2025-03-28 20:12:21 --> Language Class Initialized
INFO - 2025-03-28 20:12:21 --> Config Class Initialized
INFO - 2025-03-28 20:12:21 --> Loader Class Initialized
INFO - 2025-03-28 20:12:21 --> Helper loaded: url_helper
INFO - 2025-03-28 20:12:21 --> Helper loaded: file_helper
INFO - 2025-03-28 20:12:21 --> Helper loaded: html_helper
INFO - 2025-03-28 20:12:21 --> Helper loaded: form_helper
INFO - 2025-03-28 20:12:21 --> Helper loaded: text_helper
INFO - 2025-03-28 20:12:21 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:12:21 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:12:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:12:21 --> Database Driver Class Initialized
INFO - 2025-03-28 20:12:21 --> Email Class Initialized
INFO - 2025-03-28 20:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:12:21 --> Form Validation Class Initialized
INFO - 2025-03-28 20:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:12:21 --> Pagination Class Initialized
INFO - 2025-03-28 20:12:21 --> Controller Class Initialized
DEBUG - 2025-03-28 20:12:21 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:12:21 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:12:21 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:12:21 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:21 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"46","category_name":"Food->Noodles & Pasta->Food->Rice & Grains->Instant Noodles","parent_id":"47","status":"1"},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"47","category_name":"Food->Noodles & Pasta","parent_id":"38","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"},{"category_id":"46","category_name":"Food->Noodles & Pasta->Food->Rice & Grains->Instant Noodles","parent_id":"47","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:12:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:12:21 --> Model Class Initialized
ERROR - 2025-03-28 20:12:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:12:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:12:21 --> Final output sent to browser
DEBUG - 2025-03-28 20:12:21 --> Total execution time: 0.1210
INFO - 2025-03-28 20:12:33 --> Config Class Initialized
INFO - 2025-03-28 20:12:33 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:12:33 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:12:33 --> Utf8 Class Initialized
INFO - 2025-03-28 20:12:33 --> URI Class Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:12:33 --> Router Class Initialized
INFO - 2025-03-28 20:12:33 --> Output Class Initialized
INFO - 2025-03-28 20:12:33 --> Security Class Initialized
DEBUG - 2025-03-28 20:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:12:33 --> Input Class Initialized
INFO - 2025-03-28 20:12:33 --> Language Class Initialized
INFO - 2025-03-28 20:12:33 --> Language Class Initialized
INFO - 2025-03-28 20:12:33 --> Config Class Initialized
INFO - 2025-03-28 20:12:33 --> Loader Class Initialized
INFO - 2025-03-28 20:12:33 --> Helper loaded: url_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: file_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: html_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: form_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: text_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:12:33 --> Database Driver Class Initialized
INFO - 2025-03-28 20:12:33 --> Email Class Initialized
INFO - 2025-03-28 20:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:12:33 --> Form Validation Class Initialized
INFO - 2025-03-28 20:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:12:33 --> Pagination Class Initialized
INFO - 2025-03-28 20:12:33 --> Controller Class Initialized
DEBUG - 2025-03-28 20:12:33 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:12:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:12:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:12:33 --> Model Class Initialized
INFO - 2025-03-28 20:12:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:12:33 --> INFO: Category Updated Successfully -> Food->Noodles & Pasta->Instant Noodles
INFO - 2025-03-28 20:12:33 --> Config Class Initialized
INFO - 2025-03-28 20:12:33 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:12:33 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:12:33 --> Utf8 Class Initialized
INFO - 2025-03-28 20:12:33 --> URI Class Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:12:33 --> Router Class Initialized
INFO - 2025-03-28 20:12:33 --> Output Class Initialized
INFO - 2025-03-28 20:12:33 --> Security Class Initialized
DEBUG - 2025-03-28 20:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:12:33 --> Input Class Initialized
INFO - 2025-03-28 20:12:33 --> Language Class Initialized
INFO - 2025-03-28 20:12:33 --> Language Class Initialized
INFO - 2025-03-28 20:12:33 --> Config Class Initialized
INFO - 2025-03-28 20:12:33 --> Loader Class Initialized
INFO - 2025-03-28 20:12:33 --> Helper loaded: url_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: file_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: html_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: form_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: text_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:12:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:12:33 --> Database Driver Class Initialized
INFO - 2025-03-28 20:12:33 --> Email Class Initialized
INFO - 2025-03-28 20:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:12:33 --> Form Validation Class Initialized
INFO - 2025-03-28 20:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:12:33 --> Pagination Class Initialized
INFO - 2025-03-28 20:12:33 --> Controller Class Initialized
DEBUG - 2025-03-28 20:12:33 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:12:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:12:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:12:33 --> Model Class Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:12:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:12:33 --> Model Class Initialized
ERROR - 2025-03-28 20:12:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:12:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:12:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:12:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:12:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:12:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:12:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:12:34 --> Final output sent to browser
DEBUG - 2025-03-28 20:12:34 --> Total execution time: 0.1136
INFO - 2025-03-28 20:13:01 --> Config Class Initialized
INFO - 2025-03-28 20:13:01 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:01 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:01 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:01 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:01 --> Router Class Initialized
INFO - 2025-03-28 20:13:01 --> Output Class Initialized
INFO - 2025-03-28 20:13:01 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:01 --> Input Class Initialized
INFO - 2025-03-28 20:13:01 --> Language Class Initialized
INFO - 2025-03-28 20:13:01 --> Language Class Initialized
INFO - 2025-03-28 20:13:01 --> Config Class Initialized
INFO - 2025-03-28 20:13:01 --> Loader Class Initialized
INFO - 2025-03-28 20:13:01 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:01 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:01 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:01 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:01 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:01 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:01 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:01 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:01 --> Email Class Initialized
INFO - 2025-03-28 20:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:01 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:01 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:01 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:01 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:01 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"47","category_name":"Food->Noodles & Pasta","parent_id":"38","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"},{"category_id":"46","category_name":"Food->Noodles & Pasta->Instant Noodles","parent_id":"47","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:13:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:13:01 --> Model Class Initialized
ERROR - 2025-03-28 20:13:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:13:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:13:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:13:01 --> Final output sent to browser
DEBUG - 2025-03-28 20:13:01 --> Total execution time: 0.1265
INFO - 2025-03-28 20:13:09 --> Config Class Initialized
INFO - 2025-03-28 20:13:09 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:09 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:09 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:09 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:09 --> Router Class Initialized
INFO - 2025-03-28 20:13:09 --> Output Class Initialized
INFO - 2025-03-28 20:13:09 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:09 --> Input Class Initialized
INFO - 2025-03-28 20:13:09 --> Language Class Initialized
INFO - 2025-03-28 20:13:09 --> Language Class Initialized
INFO - 2025-03-28 20:13:09 --> Config Class Initialized
INFO - 2025-03-28 20:13:09 --> Loader Class Initialized
INFO - 2025-03-28 20:13:09 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:09 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:09 --> Email Class Initialized
INFO - 2025-03-28 20:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:09 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:09 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:09 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:09 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:09 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:09 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:09 --> Model Class Initialized
INFO - 2025-03-28 20:13:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:13:09 --> INFO: Category Created Successfully -> Food->Noodles & Pasta->Egg Noodles
INFO - 2025-03-28 20:13:09 --> Config Class Initialized
INFO - 2025-03-28 20:13:09 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:09 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:09 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:09 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:09 --> Router Class Initialized
INFO - 2025-03-28 20:13:09 --> Output Class Initialized
INFO - 2025-03-28 20:13:09 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:09 --> Input Class Initialized
INFO - 2025-03-28 20:13:09 --> Language Class Initialized
INFO - 2025-03-28 20:13:09 --> Language Class Initialized
INFO - 2025-03-28 20:13:09 --> Config Class Initialized
INFO - 2025-03-28 20:13:09 --> Loader Class Initialized
INFO - 2025-03-28 20:13:09 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:09 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:09 --> Email Class Initialized
INFO - 2025-03-28 20:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:09 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:09 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:09 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:09 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:09 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:09 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:09 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:13:09 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:13:09 --> Model Class Initialized
ERROR - 2025-03-28 20:13:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:13:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:13:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:13:09 --> Final output sent to browser
DEBUG - 2025-03-28 20:13:09 --> Total execution time: 0.1229
INFO - 2025-03-28 20:13:16 --> Config Class Initialized
INFO - 2025-03-28 20:13:16 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:16 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:16 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:16 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:16 --> Router Class Initialized
INFO - 2025-03-28 20:13:16 --> Output Class Initialized
INFO - 2025-03-28 20:13:16 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:16 --> Input Class Initialized
INFO - 2025-03-28 20:13:16 --> Language Class Initialized
INFO - 2025-03-28 20:13:16 --> Language Class Initialized
INFO - 2025-03-28 20:13:16 --> Config Class Initialized
INFO - 2025-03-28 20:13:16 --> Loader Class Initialized
INFO - 2025-03-28 20:13:16 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:16 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:16 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:16 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:16 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:16 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:16 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:16 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:16 --> Email Class Initialized
INFO - 2025-03-28 20:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:16 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:16 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:16 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:16 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:16 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:16 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:16 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:16 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"47","category_name":"Food->Noodles & Pasta","parent_id":"38","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"},{"category_id":"48","category_name":"Food->Noodles & Pasta->Egg Noodles","parent_id":"47","status":"1"},{"category_id":"46","category_name":"Food->Noodles & Pasta->Instant Noodles","parent_id":"47","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:13:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:13:16 --> Model Class Initialized
ERROR - 2025-03-28 20:13:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:13:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:13:16 --> Final output sent to browser
DEBUG - 2025-03-28 20:13:16 --> Total execution time: 0.1185
INFO - 2025-03-28 20:13:23 --> Config Class Initialized
INFO - 2025-03-28 20:13:23 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:23 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:23 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:23 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:23 --> Router Class Initialized
INFO - 2025-03-28 20:13:23 --> Output Class Initialized
INFO - 2025-03-28 20:13:23 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:23 --> Input Class Initialized
INFO - 2025-03-28 20:13:23 --> Language Class Initialized
INFO - 2025-03-28 20:13:23 --> Language Class Initialized
INFO - 2025-03-28 20:13:23 --> Config Class Initialized
INFO - 2025-03-28 20:13:23 --> Loader Class Initialized
INFO - 2025-03-28 20:13:23 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:23 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:23 --> Email Class Initialized
INFO - 2025-03-28 20:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:23 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:23 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:23 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:23 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:23 --> Model Class Initialized
INFO - 2025-03-28 20:13:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:13:23 --> INFO: Category Created Successfully -> Food->Noodles & Pasta->Spaghetti
INFO - 2025-03-28 20:13:23 --> Config Class Initialized
INFO - 2025-03-28 20:13:23 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:23 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:23 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:23 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:23 --> Router Class Initialized
INFO - 2025-03-28 20:13:23 --> Output Class Initialized
INFO - 2025-03-28 20:13:23 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:23 --> Input Class Initialized
INFO - 2025-03-28 20:13:23 --> Language Class Initialized
INFO - 2025-03-28 20:13:23 --> Language Class Initialized
INFO - 2025-03-28 20:13:23 --> Config Class Initialized
INFO - 2025-03-28 20:13:23 --> Loader Class Initialized
INFO - 2025-03-28 20:13:23 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:23 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:23 --> Email Class Initialized
INFO - 2025-03-28 20:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:23 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:23 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:23 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:23 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:23 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:13:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:13:23 --> Model Class Initialized
ERROR - 2025-03-28 20:13:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:13:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:13:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:13:23 --> Final output sent to browser
DEBUG - 2025-03-28 20:13:23 --> Total execution time: 0.1247
INFO - 2025-03-28 20:13:31 --> Config Class Initialized
INFO - 2025-03-28 20:13:31 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:31 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:31 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:31 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:31 --> Router Class Initialized
INFO - 2025-03-28 20:13:31 --> Output Class Initialized
INFO - 2025-03-28 20:13:31 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:31 --> Input Class Initialized
INFO - 2025-03-28 20:13:31 --> Language Class Initialized
INFO - 2025-03-28 20:13:31 --> Language Class Initialized
INFO - 2025-03-28 20:13:31 --> Config Class Initialized
INFO - 2025-03-28 20:13:31 --> Loader Class Initialized
INFO - 2025-03-28 20:13:31 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:31 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:31 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:31 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:31 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:31 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:31 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:31 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:31 --> Email Class Initialized
INFO - 2025-03-28 20:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:31 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:31 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:31 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:31 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:31 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:31 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:31 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:31 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"33","category_name":"Beverage","parent_id":null,"status":"1"},{"category_id":"38","category_name":"Food","parent_id":null,"status":"1"},{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food->Veg Pakora->small","parent_id":"27","status":"1"},{"category_id":"34","category_name":"Beverage->Cold Drinks","parent_id":"33","status":"1"},{"category_id":"36","category_name":"Beverage->Mineral Water","parent_id":"33","status":"1"},{"category_id":"37","category_name":"Beverage->Cold Drinks->Cola","parent_id":"34","status":"1"},{"category_id":"47","category_name":"Food->Noodles & Pasta","parent_id":"38","status":"1"},{"category_id":"39","category_name":"Food->Rice & Grains","parent_id":"38","status":"1"},{"category_id":"40","category_name":"Food->Rice & Grains->Basmati Rice","parent_id":"39","status":"1"},{"category_id":"42","category_name":"Food->Rice & Grains->Brown Rice","parent_id":"39","status":"1"},{"category_id":"43","category_name":"Food->Rice & Grains->Lentils & Pulses","parent_id":"39","status":"1"},{"category_id":"41","category_name":"Food->Rice & Grains->Parboiled Rice","parent_id":"39","status":"1"},{"category_id":"44","category_name":"Food->Rice & Grains->Quinoa","parent_id":"39","status":"1"},{"category_id":"48","category_name":"Food->Noodles & Pasta->Egg Noodles","parent_id":"47","status":"1"},{"category_id":"46","category_name":"Food->Noodles & Pasta->Instant Noodles","parent_id":"47","status":"1"},{"category_id":"49","category_name":"Food->Noodles & Pasta->Spaghetti","parent_id":"47","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:13:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:13:31 --> Model Class Initialized
ERROR - 2025-03-28 20:13:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:13:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:13:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:13:31 --> Final output sent to browser
DEBUG - 2025-03-28 20:13:31 --> Total execution time: 0.1423
INFO - 2025-03-28 20:13:40 --> Config Class Initialized
INFO - 2025-03-28 20:13:40 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:40 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:40 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:40 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:40 --> Router Class Initialized
INFO - 2025-03-28 20:13:40 --> Output Class Initialized
INFO - 2025-03-28 20:13:40 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:40 --> Input Class Initialized
INFO - 2025-03-28 20:13:40 --> Language Class Initialized
INFO - 2025-03-28 20:13:40 --> Language Class Initialized
INFO - 2025-03-28 20:13:40 --> Config Class Initialized
INFO - 2025-03-28 20:13:40 --> Loader Class Initialized
INFO - 2025-03-28 20:13:40 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:40 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:40 --> Email Class Initialized
INFO - 2025-03-28 20:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:40 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:40 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:40 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:40 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:40 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:40 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:40 --> Model Class Initialized
INFO - 2025-03-28 20:13:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:13:40 --> INFO: Category Created Successfully -> Food->Noodles & Pasta->Macaroni
INFO - 2025-03-28 20:13:40 --> Config Class Initialized
INFO - 2025-03-28 20:13:40 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:13:40 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:13:40 --> Utf8 Class Initialized
INFO - 2025-03-28 20:13:40 --> URI Class Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:13:40 --> Router Class Initialized
INFO - 2025-03-28 20:13:40 --> Output Class Initialized
INFO - 2025-03-28 20:13:40 --> Security Class Initialized
DEBUG - 2025-03-28 20:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:13:40 --> Input Class Initialized
INFO - 2025-03-28 20:13:40 --> Language Class Initialized
INFO - 2025-03-28 20:13:40 --> Language Class Initialized
INFO - 2025-03-28 20:13:40 --> Config Class Initialized
INFO - 2025-03-28 20:13:40 --> Loader Class Initialized
INFO - 2025-03-28 20:13:40 --> Helper loaded: url_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: file_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: html_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: form_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: text_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:13:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:13:40 --> Database Driver Class Initialized
INFO - 2025-03-28 20:13:40 --> Email Class Initialized
INFO - 2025-03-28 20:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:13:40 --> Form Validation Class Initialized
INFO - 2025-03-28 20:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:13:40 --> Pagination Class Initialized
INFO - 2025-03-28 20:13:40 --> Controller Class Initialized
DEBUG - 2025-03-28 20:13:40 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:13:40 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:13:40 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:13:40 --> Model Class Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:13:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:13:40 --> Model Class Initialized
ERROR - 2025-03-28 20:13:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:13:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:13:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:13:40 --> Final output sent to browser
DEBUG - 2025-03-28 20:13:40 --> Total execution time: 0.1360
INFO - 2025-03-28 20:14:58 --> Config Class Initialized
INFO - 2025-03-28 20:14:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:14:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:14:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:14:58 --> URI Class Initialized
INFO - 2025-03-28 20:14:58 --> Router Class Initialized
INFO - 2025-03-28 20:14:58 --> Output Class Initialized
INFO - 2025-03-28 20:14:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:14:58 --> Input Class Initialized
INFO - 2025-03-28 20:14:58 --> Language Class Initialized
INFO - 2025-03-28 20:14:58 --> Language Class Initialized
INFO - 2025-03-28 20:14:58 --> Config Class Initialized
INFO - 2025-03-28 20:14:58 --> Loader Class Initialized
INFO - 2025-03-28 20:14:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:14:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:14:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:14:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:14:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:14:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:14:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:14:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:14:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:14:58 --> Email Class Initialized
INFO - 2025-03-28 20:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:14:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:14:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:14:58 --> Controller Class Initialized
INFO - 2025-03-28 20:14:58 --> Model Class Initialized
INFO - 2025-03-28 20:14:58 --> Final output sent to browser
DEBUG - 2025-03-28 20:14:58 --> Total execution time: 0.0138
INFO - 2025-03-28 20:20:35 --> Config Class Initialized
INFO - 2025-03-28 20:20:35 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:20:35 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:20:35 --> Utf8 Class Initialized
INFO - 2025-03-28 20:20:35 --> URI Class Initialized
INFO - 2025-03-28 20:20:35 --> Router Class Initialized
INFO - 2025-03-28 20:20:35 --> Output Class Initialized
INFO - 2025-03-28 20:20:35 --> Security Class Initialized
DEBUG - 2025-03-28 20:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:20:35 --> Input Class Initialized
INFO - 2025-03-28 20:20:35 --> Language Class Initialized
INFO - 2025-03-28 20:20:35 --> Language Class Initialized
INFO - 2025-03-28 20:20:35 --> Config Class Initialized
INFO - 2025-03-28 20:20:35 --> Loader Class Initialized
INFO - 2025-03-28 20:20:35 --> Helper loaded: url_helper
INFO - 2025-03-28 20:20:35 --> Helper loaded: file_helper
INFO - 2025-03-28 20:20:35 --> Helper loaded: html_helper
INFO - 2025-03-28 20:20:35 --> Helper loaded: form_helper
INFO - 2025-03-28 20:20:35 --> Helper loaded: text_helper
INFO - 2025-03-28 20:20:35 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:20:35 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:20:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:20:35 --> Database Driver Class Initialized
INFO - 2025-03-28 20:20:35 --> Email Class Initialized
INFO - 2025-03-28 20:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:20:35 --> Form Validation Class Initialized
INFO - 2025-03-28 20:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:20:35 --> Pagination Class Initialized
INFO - 2025-03-28 20:20:35 --> Controller Class Initialized
INFO - 2025-03-28 20:20:35 --> Model Class Initialized
INFO - 2025-03-28 20:20:35 --> Final output sent to browser
DEBUG - 2025-03-28 20:20:35 --> Total execution time: 0.0176
INFO - 2025-03-28 20:29:58 --> Config Class Initialized
INFO - 2025-03-28 20:29:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:29:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:29:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:29:58 --> URI Class Initialized
INFO - 2025-03-28 20:29:58 --> Router Class Initialized
INFO - 2025-03-28 20:29:58 --> Output Class Initialized
INFO - 2025-03-28 20:29:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:29:58 --> Input Class Initialized
INFO - 2025-03-28 20:29:58 --> Language Class Initialized
INFO - 2025-03-28 20:29:58 --> Language Class Initialized
INFO - 2025-03-28 20:29:58 --> Config Class Initialized
INFO - 2025-03-28 20:29:58 --> Loader Class Initialized
INFO - 2025-03-28 20:29:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:29:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:29:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:29:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:29:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:29:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:29:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:29:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:29:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:29:58 --> Email Class Initialized
INFO - 2025-03-28 20:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:29:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:29:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:29:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:29:58 --> Controller Class Initialized
INFO - 2025-03-28 20:29:58 --> Model Class Initialized
ERROR - 2025-03-28 20:29:58 --> Severity: Warning --> Undefined variable $customer_email /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1147
INFO - 2025-03-28 20:29:58 --> Final output sent to browser
DEBUG - 2025-03-28 20:29:58 --> Total execution time: 0.0157
INFO - 2025-03-28 20:30:39 --> Config Class Initialized
INFO - 2025-03-28 20:30:39 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:30:39 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:30:39 --> Utf8 Class Initialized
INFO - 2025-03-28 20:30:39 --> URI Class Initialized
INFO - 2025-03-28 20:30:39 --> Router Class Initialized
INFO - 2025-03-28 20:30:39 --> Output Class Initialized
INFO - 2025-03-28 20:30:39 --> Security Class Initialized
DEBUG - 2025-03-28 20:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:30:39 --> Input Class Initialized
INFO - 2025-03-28 20:30:39 --> Language Class Initialized
INFO - 2025-03-28 20:30:39 --> Language Class Initialized
INFO - 2025-03-28 20:30:39 --> Config Class Initialized
INFO - 2025-03-28 20:30:39 --> Loader Class Initialized
INFO - 2025-03-28 20:30:39 --> Helper loaded: url_helper
INFO - 2025-03-28 20:30:39 --> Helper loaded: file_helper
INFO - 2025-03-28 20:30:39 --> Helper loaded: html_helper
INFO - 2025-03-28 20:30:39 --> Helper loaded: form_helper
INFO - 2025-03-28 20:30:39 --> Helper loaded: text_helper
INFO - 2025-03-28 20:30:39 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:30:39 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:30:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:30:39 --> Database Driver Class Initialized
INFO - 2025-03-28 20:30:39 --> Email Class Initialized
INFO - 2025-03-28 20:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:30:39 --> Form Validation Class Initialized
INFO - 2025-03-28 20:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:30:39 --> Pagination Class Initialized
INFO - 2025-03-28 20:30:39 --> Controller Class Initialized
INFO - 2025-03-28 20:30:39 --> Model Class Initialized
ERROR - 2025-03-28 20:30:39 --> Severity: Warning --> Undefined variable $customer_email /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1147
INFO - 2025-03-28 20:30:39 --> Final output sent to browser
DEBUG - 2025-03-28 20:30:39 --> Total execution time: 0.0079
INFO - 2025-03-28 20:33:35 --> Config Class Initialized
INFO - 2025-03-28 20:33:35 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:33:35 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:33:35 --> Utf8 Class Initialized
INFO - 2025-03-28 20:33:35 --> URI Class Initialized
INFO - 2025-03-28 20:33:35 --> Router Class Initialized
INFO - 2025-03-28 20:33:35 --> Output Class Initialized
INFO - 2025-03-28 20:33:35 --> Security Class Initialized
DEBUG - 2025-03-28 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:33:35 --> Input Class Initialized
INFO - 2025-03-28 20:33:35 --> Language Class Initialized
INFO - 2025-03-28 20:33:35 --> Language Class Initialized
INFO - 2025-03-28 20:33:35 --> Config Class Initialized
INFO - 2025-03-28 20:33:35 --> Loader Class Initialized
INFO - 2025-03-28 20:33:35 --> Helper loaded: url_helper
INFO - 2025-03-28 20:33:35 --> Helper loaded: file_helper
INFO - 2025-03-28 20:33:35 --> Helper loaded: html_helper
INFO - 2025-03-28 20:33:35 --> Helper loaded: form_helper
INFO - 2025-03-28 20:33:35 --> Helper loaded: text_helper
INFO - 2025-03-28 20:33:35 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:33:35 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:33:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:33:35 --> Database Driver Class Initialized
INFO - 2025-03-28 20:33:35 --> Email Class Initialized
INFO - 2025-03-28 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:33:35 --> Form Validation Class Initialized
INFO - 2025-03-28 20:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:33:35 --> Pagination Class Initialized
INFO - 2025-03-28 20:33:35 --> Controller Class Initialized
INFO - 2025-03-28 20:33:35 --> Model Class Initialized
INFO - 2025-03-28 20:33:35 --> Final output sent to browser
DEBUG - 2025-03-28 20:33:35 --> Total execution time: 0.0116
INFO - 2025-03-28 20:34:38 --> Config Class Initialized
INFO - 2025-03-28 20:34:38 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:34:38 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:34:38 --> Utf8 Class Initialized
INFO - 2025-03-28 20:34:38 --> URI Class Initialized
INFO - 2025-03-28 20:34:38 --> Router Class Initialized
INFO - 2025-03-28 20:34:38 --> Output Class Initialized
INFO - 2025-03-28 20:34:38 --> Security Class Initialized
DEBUG - 2025-03-28 20:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:34:38 --> Input Class Initialized
INFO - 2025-03-28 20:34:38 --> Language Class Initialized
INFO - 2025-03-28 20:34:38 --> Language Class Initialized
INFO - 2025-03-28 20:34:38 --> Config Class Initialized
INFO - 2025-03-28 20:34:38 --> Loader Class Initialized
INFO - 2025-03-28 20:34:38 --> Helper loaded: url_helper
INFO - 2025-03-28 20:34:38 --> Helper loaded: file_helper
INFO - 2025-03-28 20:34:38 --> Helper loaded: html_helper
INFO - 2025-03-28 20:34:38 --> Helper loaded: form_helper
INFO - 2025-03-28 20:34:38 --> Helper loaded: text_helper
INFO - 2025-03-28 20:34:38 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:34:38 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:34:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:34:38 --> Database Driver Class Initialized
INFO - 2025-03-28 20:34:38 --> Email Class Initialized
INFO - 2025-03-28 20:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:34:38 --> Form Validation Class Initialized
INFO - 2025-03-28 20:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:34:38 --> Pagination Class Initialized
INFO - 2025-03-28 20:34:38 --> Controller Class Initialized
INFO - 2025-03-28 20:34:38 --> Model Class Initialized
INFO - 2025-03-28 20:34:38 --> Final output sent to browser
DEBUG - 2025-03-28 20:34:38 --> Total execution time: 0.0102
INFO - 2025-03-28 20:45:28 --> Config Class Initialized
INFO - 2025-03-28 20:45:28 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:45:28 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:45:28 --> Utf8 Class Initialized
INFO - 2025-03-28 20:45:28 --> URI Class Initialized
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:45:28 --> Router Class Initialized
INFO - 2025-03-28 20:45:28 --> Output Class Initialized
INFO - 2025-03-28 20:45:28 --> Security Class Initialized
DEBUG - 2025-03-28 20:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:45:28 --> Input Class Initialized
INFO - 2025-03-28 20:45:28 --> Language Class Initialized
INFO - 2025-03-28 20:45:28 --> Language Class Initialized
INFO - 2025-03-28 20:45:28 --> Config Class Initialized
INFO - 2025-03-28 20:45:28 --> Loader Class Initialized
INFO - 2025-03-28 20:45:28 --> Helper loaded: url_helper
INFO - 2025-03-28 20:45:28 --> Helper loaded: file_helper
INFO - 2025-03-28 20:45:28 --> Helper loaded: html_helper
INFO - 2025-03-28 20:45:28 --> Helper loaded: form_helper
INFO - 2025-03-28 20:45:28 --> Helper loaded: text_helper
INFO - 2025-03-28 20:45:28 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:45:28 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:45:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:45:28 --> Database Driver Class Initialized
INFO - 2025-03-28 20:45:28 --> Email Class Initialized
INFO - 2025-03-28 20:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:45:28 --> Form Validation Class Initialized
INFO - 2025-03-28 20:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:45:28 --> Pagination Class Initialized
INFO - 2025-03-28 20:45:28 --> Controller Class Initialized
DEBUG - 2025-03-28 20:45:28 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:45:28 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:45:28 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:45:28 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:45:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:45:28 --> Model Class Initialized
ERROR - 2025-03-28 20:45:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:45:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:45:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:45:28 --> Final output sent to browser
DEBUG - 2025-03-28 20:45:28 --> Total execution time: 0.2259
INFO - 2025-03-28 20:45:39 --> Config Class Initialized
INFO - 2025-03-28 20:45:39 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:45:39 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:45:39 --> Utf8 Class Initialized
INFO - 2025-03-28 20:45:39 --> URI Class Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:45:39 --> Router Class Initialized
INFO - 2025-03-28 20:45:39 --> Output Class Initialized
INFO - 2025-03-28 20:45:39 --> Security Class Initialized
DEBUG - 2025-03-28 20:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:45:39 --> Input Class Initialized
INFO - 2025-03-28 20:45:39 --> Language Class Initialized
INFO - 2025-03-28 20:45:39 --> Language Class Initialized
INFO - 2025-03-28 20:45:39 --> Config Class Initialized
INFO - 2025-03-28 20:45:39 --> Loader Class Initialized
INFO - 2025-03-28 20:45:39 --> Helper loaded: url_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: file_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: html_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: form_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: text_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:45:39 --> Database Driver Class Initialized
INFO - 2025-03-28 20:45:39 --> Email Class Initialized
INFO - 2025-03-28 20:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:45:39 --> Form Validation Class Initialized
INFO - 2025-03-28 20:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:45:39 --> Pagination Class Initialized
INFO - 2025-03-28 20:45:39 --> Controller Class Initialized
DEBUG - 2025-03-28 20:45:39 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:45:39 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:45:39 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:45:39 --> Model Class Initialized
INFO - 2025-03-28 20:45:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:45:39 --> Config Class Initialized
INFO - 2025-03-28 20:45:39 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:45:39 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:45:39 --> Utf8 Class Initialized
INFO - 2025-03-28 20:45:39 --> URI Class Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:45:39 --> Router Class Initialized
INFO - 2025-03-28 20:45:39 --> Output Class Initialized
INFO - 2025-03-28 20:45:39 --> Security Class Initialized
DEBUG - 2025-03-28 20:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:45:39 --> Input Class Initialized
INFO - 2025-03-28 20:45:39 --> Language Class Initialized
INFO - 2025-03-28 20:45:39 --> Language Class Initialized
INFO - 2025-03-28 20:45:39 --> Config Class Initialized
INFO - 2025-03-28 20:45:39 --> Loader Class Initialized
INFO - 2025-03-28 20:45:39 --> Helper loaded: url_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: file_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: html_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: form_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: text_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:45:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:45:39 --> Database Driver Class Initialized
INFO - 2025-03-28 20:45:39 --> Email Class Initialized
INFO - 2025-03-28 20:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:45:39 --> Form Validation Class Initialized
INFO - 2025-03-28 20:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:45:39 --> Pagination Class Initialized
INFO - 2025-03-28 20:45:39 --> Controller Class Initialized
DEBUG - 2025-03-28 20:45:39 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:45:39 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:45:39 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:45:39 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:45:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:45:39 --> Model Class Initialized
ERROR - 2025-03-28 20:45:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:45:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:45:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:45:39 --> Final output sent to browser
DEBUG - 2025-03-28 20:45:39 --> Total execution time: 0.1247
INFO - 2025-03-28 20:45:48 --> Config Class Initialized
INFO - 2025-03-28 20:45:48 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:45:48 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:45:48 --> Utf8 Class Initialized
INFO - 2025-03-28 20:45:48 --> URI Class Initialized
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:45:48 --> Router Class Initialized
INFO - 2025-03-28 20:45:48 --> Output Class Initialized
INFO - 2025-03-28 20:45:48 --> Security Class Initialized
DEBUG - 2025-03-28 20:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:45:48 --> Input Class Initialized
INFO - 2025-03-28 20:45:48 --> Language Class Initialized
INFO - 2025-03-28 20:45:48 --> Language Class Initialized
INFO - 2025-03-28 20:45:48 --> Config Class Initialized
INFO - 2025-03-28 20:45:48 --> Loader Class Initialized
INFO - 2025-03-28 20:45:48 --> Helper loaded: url_helper
INFO - 2025-03-28 20:45:48 --> Helper loaded: file_helper
INFO - 2025-03-28 20:45:48 --> Helper loaded: html_helper
INFO - 2025-03-28 20:45:48 --> Helper loaded: form_helper
INFO - 2025-03-28 20:45:48 --> Helper loaded: text_helper
INFO - 2025-03-28 20:45:48 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:45:48 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:45:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:45:48 --> Database Driver Class Initialized
INFO - 2025-03-28 20:45:48 --> Email Class Initialized
INFO - 2025-03-28 20:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:45:48 --> Form Validation Class Initialized
INFO - 2025-03-28 20:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:45:48 --> Pagination Class Initialized
INFO - 2025-03-28 20:45:48 --> Controller Class Initialized
DEBUG - 2025-03-28 20:45:48 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:45:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:45:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:45:48 --> Model Class Initialized
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:45:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:45:48 --> Model Class Initialized
ERROR - 2025-03-28 20:45:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:45:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:45:48 --> Final output sent to browser
DEBUG - 2025-03-28 20:45:48 --> Total execution time: 0.1000
INFO - 2025-03-28 20:46:01 --> Config Class Initialized
INFO - 2025-03-28 20:46:01 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:46:01 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:46:01 --> Utf8 Class Initialized
INFO - 2025-03-28 20:46:01 --> URI Class Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:46:01 --> Router Class Initialized
INFO - 2025-03-28 20:46:01 --> Output Class Initialized
INFO - 2025-03-28 20:46:01 --> Security Class Initialized
DEBUG - 2025-03-28 20:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:46:01 --> Input Class Initialized
INFO - 2025-03-28 20:46:01 --> Language Class Initialized
INFO - 2025-03-28 20:46:01 --> Language Class Initialized
INFO - 2025-03-28 20:46:01 --> Config Class Initialized
INFO - 2025-03-28 20:46:01 --> Loader Class Initialized
INFO - 2025-03-28 20:46:01 --> Helper loaded: url_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: file_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: html_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: form_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: text_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:46:01 --> Database Driver Class Initialized
INFO - 2025-03-28 20:46:01 --> Email Class Initialized
INFO - 2025-03-28 20:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:46:01 --> Form Validation Class Initialized
INFO - 2025-03-28 20:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:46:01 --> Pagination Class Initialized
INFO - 2025-03-28 20:46:01 --> Controller Class Initialized
DEBUG - 2025-03-28 20:46:01 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:46:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:46:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:46:01 --> Model Class Initialized
INFO - 2025-03-28 20:46:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:46:01 --> Config Class Initialized
INFO - 2025-03-28 20:46:01 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:46:01 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:46:01 --> Utf8 Class Initialized
INFO - 2025-03-28 20:46:01 --> URI Class Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:46:01 --> Router Class Initialized
INFO - 2025-03-28 20:46:01 --> Output Class Initialized
INFO - 2025-03-28 20:46:01 --> Security Class Initialized
DEBUG - 2025-03-28 20:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:46:01 --> Input Class Initialized
INFO - 2025-03-28 20:46:01 --> Language Class Initialized
INFO - 2025-03-28 20:46:01 --> Language Class Initialized
INFO - 2025-03-28 20:46:01 --> Config Class Initialized
INFO - 2025-03-28 20:46:01 --> Loader Class Initialized
INFO - 2025-03-28 20:46:01 --> Helper loaded: url_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: file_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: html_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: form_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: text_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:46:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:46:01 --> Database Driver Class Initialized
INFO - 2025-03-28 20:46:01 --> Email Class Initialized
INFO - 2025-03-28 20:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:46:01 --> Form Validation Class Initialized
INFO - 2025-03-28 20:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:46:01 --> Pagination Class Initialized
INFO - 2025-03-28 20:46:01 --> Controller Class Initialized
DEBUG - 2025-03-28 20:46:01 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:46:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:46:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:46:01 --> Model Class Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:46:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:46:01 --> Model Class Initialized
ERROR - 2025-03-28 20:46:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:46:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:46:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:46:01 --> Final output sent to browser
DEBUG - 2025-03-28 20:46:01 --> Total execution time: 0.1236
INFO - 2025-03-28 20:49:59 --> Config Class Initialized
INFO - 2025-03-28 20:49:59 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:49:59 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:49:59 --> Utf8 Class Initialized
INFO - 2025-03-28 20:49:59 --> URI Class Initialized
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:49:59 --> Router Class Initialized
INFO - 2025-03-28 20:49:59 --> Output Class Initialized
INFO - 2025-03-28 20:49:59 --> Security Class Initialized
DEBUG - 2025-03-28 20:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:49:59 --> Input Class Initialized
INFO - 2025-03-28 20:49:59 --> Language Class Initialized
INFO - 2025-03-28 20:49:59 --> Language Class Initialized
INFO - 2025-03-28 20:49:59 --> Config Class Initialized
INFO - 2025-03-28 20:49:59 --> Loader Class Initialized
INFO - 2025-03-28 20:49:59 --> Helper loaded: url_helper
INFO - 2025-03-28 20:49:59 --> Helper loaded: file_helper
INFO - 2025-03-28 20:49:59 --> Helper loaded: html_helper
INFO - 2025-03-28 20:49:59 --> Helper loaded: form_helper
INFO - 2025-03-28 20:49:59 --> Helper loaded: text_helper
INFO - 2025-03-28 20:49:59 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:49:59 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:49:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:49:59 --> Database Driver Class Initialized
INFO - 2025-03-28 20:49:59 --> Email Class Initialized
INFO - 2025-03-28 20:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:49:59 --> Form Validation Class Initialized
INFO - 2025-03-28 20:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:49:59 --> Pagination Class Initialized
INFO - 2025-03-28 20:49:59 --> Controller Class Initialized
DEBUG - 2025-03-28 20:49:59 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:49:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:49:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:49:59 --> Model Class Initialized
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:49:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:49:59 --> Model Class Initialized
ERROR - 2025-03-28 20:49:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:49:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:49:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:49:59 --> Final output sent to browser
DEBUG - 2025-03-28 20:49:59 --> Total execution time: 0.1293
INFO - 2025-03-28 20:50:19 --> Config Class Initialized
INFO - 2025-03-28 20:50:19 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:50:19 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:50:19 --> Utf8 Class Initialized
INFO - 2025-03-28 20:50:19 --> URI Class Initialized
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:50:19 --> Router Class Initialized
INFO - 2025-03-28 20:50:19 --> Output Class Initialized
INFO - 2025-03-28 20:50:19 --> Security Class Initialized
DEBUG - 2025-03-28 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:50:19 --> Input Class Initialized
INFO - 2025-03-28 20:50:19 --> Language Class Initialized
INFO - 2025-03-28 20:50:19 --> Language Class Initialized
INFO - 2025-03-28 20:50:19 --> Config Class Initialized
INFO - 2025-03-28 20:50:19 --> Loader Class Initialized
INFO - 2025-03-28 20:50:19 --> Helper loaded: url_helper
INFO - 2025-03-28 20:50:19 --> Helper loaded: file_helper
INFO - 2025-03-28 20:50:19 --> Helper loaded: html_helper
INFO - 2025-03-28 20:50:19 --> Helper loaded: form_helper
INFO - 2025-03-28 20:50:19 --> Helper loaded: text_helper
INFO - 2025-03-28 20:50:19 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:50:19 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:50:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:50:19 --> Database Driver Class Initialized
INFO - 2025-03-28 20:50:19 --> Email Class Initialized
INFO - 2025-03-28 20:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:50:19 --> Form Validation Class Initialized
INFO - 2025-03-28 20:50:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:50:19 --> Pagination Class Initialized
INFO - 2025-03-28 20:50:19 --> Controller Class Initialized
DEBUG - 2025-03-28 20:50:19 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:50:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:50:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:50:19 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:50:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:50:19 --> Model Class Initialized
ERROR - 2025-03-28 20:50:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:50:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:50:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:50:19 --> Final output sent to browser
DEBUG - 2025-03-28 20:50:19 --> Total execution time: 0.1360
INFO - 2025-03-28 20:50:21 --> Config Class Initialized
INFO - 2025-03-28 20:50:21 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:50:21 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:50:21 --> Utf8 Class Initialized
INFO - 2025-03-28 20:50:21 --> URI Class Initialized
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:50:21 --> Router Class Initialized
INFO - 2025-03-28 20:50:21 --> Output Class Initialized
INFO - 2025-03-28 20:50:21 --> Security Class Initialized
DEBUG - 2025-03-28 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:50:21 --> Input Class Initialized
INFO - 2025-03-28 20:50:21 --> Language Class Initialized
INFO - 2025-03-28 20:50:21 --> Language Class Initialized
INFO - 2025-03-28 20:50:21 --> Config Class Initialized
INFO - 2025-03-28 20:50:21 --> Loader Class Initialized
INFO - 2025-03-28 20:50:21 --> Helper loaded: url_helper
INFO - 2025-03-28 20:50:21 --> Helper loaded: file_helper
INFO - 2025-03-28 20:50:21 --> Helper loaded: html_helper
INFO - 2025-03-28 20:50:21 --> Helper loaded: form_helper
INFO - 2025-03-28 20:50:21 --> Helper loaded: text_helper
INFO - 2025-03-28 20:50:21 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:50:21 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:50:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:50:21 --> Database Driver Class Initialized
INFO - 2025-03-28 20:50:21 --> Email Class Initialized
INFO - 2025-03-28 20:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:50:21 --> Form Validation Class Initialized
INFO - 2025-03-28 20:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:50:21 --> Pagination Class Initialized
INFO - 2025-03-28 20:50:21 --> Controller Class Initialized
DEBUG - 2025-03-28 20:50:21 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:50:21 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:50:21 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:50:21 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:50:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:50:21 --> Model Class Initialized
ERROR - 2025-03-28 20:50:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:50:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:50:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:50:21 --> Final output sent to browser
DEBUG - 2025-03-28 20:50:21 --> Total execution time: 0.1936
INFO - 2025-03-28 20:50:47 --> Config Class Initialized
INFO - 2025-03-28 20:50:47 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:50:47 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:50:47 --> Utf8 Class Initialized
INFO - 2025-03-28 20:50:47 --> URI Class Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:50:47 --> Router Class Initialized
INFO - 2025-03-28 20:50:47 --> Output Class Initialized
INFO - 2025-03-28 20:50:47 --> Security Class Initialized
DEBUG - 2025-03-28 20:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:50:47 --> Input Class Initialized
INFO - 2025-03-28 20:50:47 --> Language Class Initialized
INFO - 2025-03-28 20:50:47 --> Language Class Initialized
INFO - 2025-03-28 20:50:47 --> Config Class Initialized
INFO - 2025-03-28 20:50:47 --> Loader Class Initialized
INFO - 2025-03-28 20:50:47 --> Helper loaded: url_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: file_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: html_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: form_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: text_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:50:47 --> Database Driver Class Initialized
INFO - 2025-03-28 20:50:47 --> Email Class Initialized
INFO - 2025-03-28 20:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:50:47 --> Form Validation Class Initialized
INFO - 2025-03-28 20:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:50:47 --> Pagination Class Initialized
INFO - 2025-03-28 20:50:47 --> Controller Class Initialized
DEBUG - 2025-03-28 20:50:47 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:50:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:50:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:50:47 --> Model Class Initialized
INFO - 2025-03-28 20:50:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:50:47 --> Config Class Initialized
INFO - 2025-03-28 20:50:47 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:50:47 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:50:47 --> Utf8 Class Initialized
INFO - 2025-03-28 20:50:47 --> URI Class Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:50:47 --> Router Class Initialized
INFO - 2025-03-28 20:50:47 --> Output Class Initialized
INFO - 2025-03-28 20:50:47 --> Security Class Initialized
DEBUG - 2025-03-28 20:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:50:47 --> Input Class Initialized
INFO - 2025-03-28 20:50:47 --> Language Class Initialized
INFO - 2025-03-28 20:50:47 --> Language Class Initialized
INFO - 2025-03-28 20:50:47 --> Config Class Initialized
INFO - 2025-03-28 20:50:47 --> Loader Class Initialized
INFO - 2025-03-28 20:50:47 --> Helper loaded: url_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: file_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: html_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: form_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: text_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:50:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:50:47 --> Database Driver Class Initialized
INFO - 2025-03-28 20:50:47 --> Email Class Initialized
INFO - 2025-03-28 20:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:50:47 --> Form Validation Class Initialized
INFO - 2025-03-28 20:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:50:47 --> Pagination Class Initialized
INFO - 2025-03-28 20:50:47 --> Controller Class Initialized
DEBUG - 2025-03-28 20:50:47 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:50:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:50:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:50:47 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:50:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:50:47 --> Model Class Initialized
ERROR - 2025-03-28 20:50:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:50:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:50:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:50:47 --> Final output sent to browser
DEBUG - 2025-03-28 20:50:47 --> Total execution time: 0.0909
INFO - 2025-03-28 20:50:58 --> Config Class Initialized
INFO - 2025-03-28 20:50:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:50:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:50:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:50:58 --> URI Class Initialized
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:50:58 --> Router Class Initialized
INFO - 2025-03-28 20:50:58 --> Output Class Initialized
INFO - 2025-03-28 20:50:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:50:58 --> Input Class Initialized
INFO - 2025-03-28 20:50:58 --> Language Class Initialized
INFO - 2025-03-28 20:50:58 --> Language Class Initialized
INFO - 2025-03-28 20:50:58 --> Config Class Initialized
INFO - 2025-03-28 20:50:58 --> Loader Class Initialized
INFO - 2025-03-28 20:50:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:50:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:50:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:50:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:50:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:50:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:50:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:50:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:50:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:50:58 --> Email Class Initialized
INFO - 2025-03-28 20:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:50:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:50:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:50:58 --> Controller Class Initialized
DEBUG - 2025-03-28 20:50:58 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:50:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:50:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:50:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:50:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:50:58 --> Model Class Initialized
ERROR - 2025-03-28 20:50:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:50:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:50:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:50:58 --> Final output sent to browser
DEBUG - 2025-03-28 20:50:58 --> Total execution time: 0.1044
INFO - 2025-03-28 20:51:58 --> Config Class Initialized
INFO - 2025-03-28 20:51:58 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:51:58 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:51:58 --> Utf8 Class Initialized
INFO - 2025-03-28 20:51:58 --> URI Class Initialized
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:51:58 --> Router Class Initialized
INFO - 2025-03-28 20:51:58 --> Output Class Initialized
INFO - 2025-03-28 20:51:58 --> Security Class Initialized
DEBUG - 2025-03-28 20:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:51:58 --> Input Class Initialized
INFO - 2025-03-28 20:51:58 --> Language Class Initialized
INFO - 2025-03-28 20:51:58 --> Language Class Initialized
INFO - 2025-03-28 20:51:58 --> Config Class Initialized
INFO - 2025-03-28 20:51:58 --> Loader Class Initialized
INFO - 2025-03-28 20:51:58 --> Helper loaded: url_helper
INFO - 2025-03-28 20:51:58 --> Helper loaded: file_helper
INFO - 2025-03-28 20:51:58 --> Helper loaded: html_helper
INFO - 2025-03-28 20:51:58 --> Helper loaded: form_helper
INFO - 2025-03-28 20:51:58 --> Helper loaded: text_helper
INFO - 2025-03-28 20:51:58 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:51:58 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:51:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:51:58 --> Database Driver Class Initialized
INFO - 2025-03-28 20:51:58 --> Email Class Initialized
INFO - 2025-03-28 20:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:51:58 --> Form Validation Class Initialized
INFO - 2025-03-28 20:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:51:58 --> Pagination Class Initialized
INFO - 2025-03-28 20:51:58 --> Controller Class Initialized
DEBUG - 2025-03-28 20:51:58 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:51:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:51:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:51:58 --> Model Class Initialized
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:51:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:51:58 --> Model Class Initialized
ERROR - 2025-03-28 20:51:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:51:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:51:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:51:58 --> Final output sent to browser
DEBUG - 2025-03-28 20:51:58 --> Total execution time: 0.1370
INFO - 2025-03-28 20:52:42 --> Config Class Initialized
INFO - 2025-03-28 20:52:42 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:52:42 --> Utf8 Class Initialized
INFO - 2025-03-28 20:52:42 --> URI Class Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:52:42 --> Router Class Initialized
INFO - 2025-03-28 20:52:42 --> Output Class Initialized
INFO - 2025-03-28 20:52:42 --> Security Class Initialized
DEBUG - 2025-03-28 20:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:52:42 --> Input Class Initialized
INFO - 2025-03-28 20:52:42 --> Language Class Initialized
INFO - 2025-03-28 20:52:42 --> Language Class Initialized
INFO - 2025-03-28 20:52:42 --> Config Class Initialized
INFO - 2025-03-28 20:52:42 --> Loader Class Initialized
INFO - 2025-03-28 20:52:42 --> Helper loaded: url_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: file_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: html_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: form_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: text_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:52:42 --> Database Driver Class Initialized
INFO - 2025-03-28 20:52:42 --> Email Class Initialized
INFO - 2025-03-28 20:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:52:42 --> Form Validation Class Initialized
INFO - 2025-03-28 20:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:52:42 --> Pagination Class Initialized
INFO - 2025-03-28 20:52:42 --> Controller Class Initialized
DEBUG - 2025-03-28 20:52:42 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:52:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:52:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:52:42 --> Model Class Initialized
INFO - 2025-03-28 20:52:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 20:52:42 --> Config Class Initialized
INFO - 2025-03-28 20:52:42 --> Hooks Class Initialized
DEBUG - 2025-03-28 20:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-28 20:52:42 --> Utf8 Class Initialized
INFO - 2025-03-28 20:52:42 --> URI Class Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 20:52:42 --> Router Class Initialized
INFO - 2025-03-28 20:52:42 --> Output Class Initialized
INFO - 2025-03-28 20:52:42 --> Security Class Initialized
DEBUG - 2025-03-28 20:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 20:52:42 --> Input Class Initialized
INFO - 2025-03-28 20:52:42 --> Language Class Initialized
INFO - 2025-03-28 20:52:42 --> Language Class Initialized
INFO - 2025-03-28 20:52:42 --> Config Class Initialized
INFO - 2025-03-28 20:52:42 --> Loader Class Initialized
INFO - 2025-03-28 20:52:42 --> Helper loaded: url_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: file_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: html_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: form_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: text_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: lang_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: directory_helper
INFO - 2025-03-28 20:52:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 20:52:42 --> Database Driver Class Initialized
INFO - 2025-03-28 20:52:42 --> Email Class Initialized
INFO - 2025-03-28 20:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 20:52:42 --> Form Validation Class Initialized
INFO - 2025-03-28 20:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 20:52:42 --> Pagination Class Initialized
INFO - 2025-03-28 20:52:42 --> Controller Class Initialized
DEBUG - 2025-03-28 20:52:42 --> Product MX_Controller Initialized
INFO - 2025-03-28 20:52:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 20:52:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 20:52:42 --> Model Class Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 20:52:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 20:52:42 --> Model Class Initialized
ERROR - 2025-03-28 20:52:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 20:52:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 20:52:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 20:52:42 --> Final output sent to browser
DEBUG - 2025-03-28 20:52:42 --> Total execution time: 0.1411
INFO - 2025-03-28 21:00:03 --> Config Class Initialized
INFO - 2025-03-28 21:00:03 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:00:03 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:00:03 --> Utf8 Class Initialized
INFO - 2025-03-28 21:00:03 --> URI Class Initialized
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:00:03 --> Router Class Initialized
INFO - 2025-03-28 21:00:03 --> Output Class Initialized
INFO - 2025-03-28 21:00:03 --> Security Class Initialized
DEBUG - 2025-03-28 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:00:03 --> Input Class Initialized
INFO - 2025-03-28 21:00:03 --> Language Class Initialized
INFO - 2025-03-28 21:00:03 --> Language Class Initialized
INFO - 2025-03-28 21:00:03 --> Config Class Initialized
INFO - 2025-03-28 21:00:03 --> Loader Class Initialized
INFO - 2025-03-28 21:00:03 --> Helper loaded: url_helper
INFO - 2025-03-28 21:00:03 --> Helper loaded: file_helper
INFO - 2025-03-28 21:00:03 --> Helper loaded: html_helper
INFO - 2025-03-28 21:00:03 --> Helper loaded: form_helper
INFO - 2025-03-28 21:00:03 --> Helper loaded: text_helper
INFO - 2025-03-28 21:00:03 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:00:03 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:00:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:00:03 --> Database Driver Class Initialized
INFO - 2025-03-28 21:00:03 --> Email Class Initialized
INFO - 2025-03-28 21:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:00:03 --> Form Validation Class Initialized
INFO - 2025-03-28 21:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:00:03 --> Pagination Class Initialized
INFO - 2025-03-28 21:00:03 --> Controller Class Initialized
DEBUG - 2025-03-28 21:00:03 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:00:03 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:00:03 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:00:03 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:00:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:00:03 --> Model Class Initialized
ERROR - 2025-03-28 21:00:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:00:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:00:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:00:03 --> Final output sent to browser
DEBUG - 2025-03-28 21:00:03 --> Total execution time: 0.1552
INFO - 2025-03-28 21:00:08 --> Config Class Initialized
INFO - 2025-03-28 21:00:08 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:00:08 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:00:08 --> Utf8 Class Initialized
INFO - 2025-03-28 21:00:08 --> URI Class Initialized
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:00:08 --> Router Class Initialized
INFO - 2025-03-28 21:00:08 --> Output Class Initialized
INFO - 2025-03-28 21:00:08 --> Security Class Initialized
DEBUG - 2025-03-28 21:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:00:08 --> Input Class Initialized
INFO - 2025-03-28 21:00:08 --> Language Class Initialized
INFO - 2025-03-28 21:00:08 --> Language Class Initialized
INFO - 2025-03-28 21:00:08 --> Config Class Initialized
INFO - 2025-03-28 21:00:08 --> Loader Class Initialized
INFO - 2025-03-28 21:00:08 --> Helper loaded: url_helper
INFO - 2025-03-28 21:00:08 --> Helper loaded: file_helper
INFO - 2025-03-28 21:00:08 --> Helper loaded: html_helper
INFO - 2025-03-28 21:00:08 --> Helper loaded: form_helper
INFO - 2025-03-28 21:00:08 --> Helper loaded: text_helper
INFO - 2025-03-28 21:00:08 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:00:08 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:00:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:00:08 --> Database Driver Class Initialized
INFO - 2025-03-28 21:00:08 --> Email Class Initialized
INFO - 2025-03-28 21:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:00:08 --> Form Validation Class Initialized
INFO - 2025-03-28 21:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:00:08 --> Pagination Class Initialized
INFO - 2025-03-28 21:00:08 --> Controller Class Initialized
DEBUG - 2025-03-28 21:00:08 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:00:08 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:00:08 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:00:08 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:00:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:00:08 --> Model Class Initialized
ERROR - 2025-03-28 21:00:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:00:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:00:08 --> Final output sent to browser
DEBUG - 2025-03-28 21:00:08 --> Total execution time: 0.1218
INFO - 2025-03-28 21:00:22 --> Config Class Initialized
INFO - 2025-03-28 21:00:22 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:00:22 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:00:22 --> Utf8 Class Initialized
INFO - 2025-03-28 21:00:22 --> URI Class Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:00:22 --> Router Class Initialized
INFO - 2025-03-28 21:00:22 --> Output Class Initialized
INFO - 2025-03-28 21:00:22 --> Security Class Initialized
DEBUG - 2025-03-28 21:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:00:22 --> Input Class Initialized
INFO - 2025-03-28 21:00:22 --> Language Class Initialized
INFO - 2025-03-28 21:00:22 --> Language Class Initialized
INFO - 2025-03-28 21:00:22 --> Config Class Initialized
INFO - 2025-03-28 21:00:22 --> Loader Class Initialized
INFO - 2025-03-28 21:00:22 --> Helper loaded: url_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: file_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: html_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: form_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: text_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:00:22 --> Database Driver Class Initialized
INFO - 2025-03-28 21:00:22 --> Email Class Initialized
INFO - 2025-03-28 21:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:00:22 --> Form Validation Class Initialized
INFO - 2025-03-28 21:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:00:22 --> Pagination Class Initialized
INFO - 2025-03-28 21:00:22 --> Controller Class Initialized
DEBUG - 2025-03-28 21:00:22 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:00:22 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:00:22 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:00:22 --> Model Class Initialized
INFO - 2025-03-28 21:00:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 21:00:22 --> Config Class Initialized
INFO - 2025-03-28 21:00:22 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:00:22 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:00:22 --> Utf8 Class Initialized
INFO - 2025-03-28 21:00:22 --> URI Class Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:00:22 --> Router Class Initialized
INFO - 2025-03-28 21:00:22 --> Output Class Initialized
INFO - 2025-03-28 21:00:22 --> Security Class Initialized
DEBUG - 2025-03-28 21:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:00:22 --> Input Class Initialized
INFO - 2025-03-28 21:00:22 --> Language Class Initialized
INFO - 2025-03-28 21:00:22 --> Language Class Initialized
INFO - 2025-03-28 21:00:22 --> Config Class Initialized
INFO - 2025-03-28 21:00:22 --> Loader Class Initialized
INFO - 2025-03-28 21:00:22 --> Helper loaded: url_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: file_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: html_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: form_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: text_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:00:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:00:22 --> Database Driver Class Initialized
INFO - 2025-03-28 21:00:22 --> Email Class Initialized
INFO - 2025-03-28 21:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:00:22 --> Form Validation Class Initialized
INFO - 2025-03-28 21:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:00:22 --> Pagination Class Initialized
INFO - 2025-03-28 21:00:22 --> Controller Class Initialized
DEBUG - 2025-03-28 21:00:22 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:00:22 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:00:22 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:00:22 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:00:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:00:22 --> Model Class Initialized
ERROR - 2025-03-28 21:00:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:00:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:00:22 --> Final output sent to browser
DEBUG - 2025-03-28 21:00:22 --> Total execution time: 0.0955
INFO - 2025-03-28 21:00:39 --> Config Class Initialized
INFO - 2025-03-28 21:00:39 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:00:39 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:00:39 --> Utf8 Class Initialized
INFO - 2025-03-28 21:00:39 --> URI Class Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:00:39 --> Router Class Initialized
INFO - 2025-03-28 21:00:39 --> Output Class Initialized
INFO - 2025-03-28 21:00:39 --> Security Class Initialized
DEBUG - 2025-03-28 21:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:00:39 --> Input Class Initialized
INFO - 2025-03-28 21:00:39 --> Language Class Initialized
INFO - 2025-03-28 21:00:39 --> Language Class Initialized
INFO - 2025-03-28 21:00:39 --> Config Class Initialized
INFO - 2025-03-28 21:00:39 --> Loader Class Initialized
INFO - 2025-03-28 21:00:39 --> Helper loaded: url_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: file_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: html_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: form_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: text_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:00:39 --> Database Driver Class Initialized
INFO - 2025-03-28 21:00:39 --> Email Class Initialized
INFO - 2025-03-28 21:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:00:39 --> Form Validation Class Initialized
INFO - 2025-03-28 21:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:00:39 --> Pagination Class Initialized
INFO - 2025-03-28 21:00:39 --> Controller Class Initialized
DEBUG - 2025-03-28 21:00:39 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:00:39 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:00:39 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:00:39 --> Model Class Initialized
INFO - 2025-03-28 21:00:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 21:00:39 --> Config Class Initialized
INFO - 2025-03-28 21:00:39 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:00:39 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:00:39 --> Utf8 Class Initialized
INFO - 2025-03-28 21:00:39 --> URI Class Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:00:39 --> Router Class Initialized
INFO - 2025-03-28 21:00:39 --> Output Class Initialized
INFO - 2025-03-28 21:00:39 --> Security Class Initialized
DEBUG - 2025-03-28 21:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:00:39 --> Input Class Initialized
INFO - 2025-03-28 21:00:39 --> Language Class Initialized
INFO - 2025-03-28 21:00:39 --> Language Class Initialized
INFO - 2025-03-28 21:00:39 --> Config Class Initialized
INFO - 2025-03-28 21:00:39 --> Loader Class Initialized
INFO - 2025-03-28 21:00:39 --> Helper loaded: url_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: file_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: html_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: form_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: text_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:00:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:00:39 --> Database Driver Class Initialized
INFO - 2025-03-28 21:00:39 --> Email Class Initialized
INFO - 2025-03-28 21:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:00:39 --> Form Validation Class Initialized
INFO - 2025-03-28 21:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:00:39 --> Pagination Class Initialized
INFO - 2025-03-28 21:00:39 --> Controller Class Initialized
DEBUG - 2025-03-28 21:00:39 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:00:39 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:00:39 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:00:39 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:00:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:00:39 --> Model Class Initialized
ERROR - 2025-03-28 21:00:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:00:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:00:39 --> Final output sent to browser
DEBUG - 2025-03-28 21:00:39 --> Total execution time: 0.1314
INFO - 2025-03-28 21:00:52 --> Config Class Initialized
INFO - 2025-03-28 21:00:52 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:00:52 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:00:52 --> Utf8 Class Initialized
INFO - 2025-03-28 21:00:52 --> URI Class Initialized
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:00:52 --> Router Class Initialized
INFO - 2025-03-28 21:00:52 --> Output Class Initialized
INFO - 2025-03-28 21:00:52 --> Security Class Initialized
DEBUG - 2025-03-28 21:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:00:52 --> Input Class Initialized
INFO - 2025-03-28 21:00:52 --> Language Class Initialized
INFO - 2025-03-28 21:00:52 --> Language Class Initialized
INFO - 2025-03-28 21:00:52 --> Config Class Initialized
INFO - 2025-03-28 21:00:52 --> Loader Class Initialized
INFO - 2025-03-28 21:00:52 --> Helper loaded: url_helper
INFO - 2025-03-28 21:00:52 --> Helper loaded: file_helper
INFO - 2025-03-28 21:00:52 --> Helper loaded: html_helper
INFO - 2025-03-28 21:00:52 --> Helper loaded: form_helper
INFO - 2025-03-28 21:00:52 --> Helper loaded: text_helper
INFO - 2025-03-28 21:00:52 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:00:52 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:00:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:00:52 --> Database Driver Class Initialized
INFO - 2025-03-28 21:00:52 --> Email Class Initialized
INFO - 2025-03-28 21:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:00:52 --> Form Validation Class Initialized
INFO - 2025-03-28 21:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:00:52 --> Pagination Class Initialized
INFO - 2025-03-28 21:00:52 --> Controller Class Initialized
DEBUG - 2025-03-28 21:00:52 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:00:52 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:00:52 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:00:52 --> Model Class Initialized
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:00:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:00:52 --> Model Class Initialized
ERROR - 2025-03-28 21:00:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:00:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:00:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:00:52 --> Final output sent to browser
DEBUG - 2025-03-28 21:00:52 --> Total execution time: 0.1430
INFO - 2025-03-28 21:07:59 --> Config Class Initialized
INFO - 2025-03-28 21:07:59 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:07:59 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:07:59 --> Utf8 Class Initialized
INFO - 2025-03-28 21:07:59 --> URI Class Initialized
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:07:59 --> Router Class Initialized
INFO - 2025-03-28 21:07:59 --> Output Class Initialized
INFO - 2025-03-28 21:07:59 --> Security Class Initialized
DEBUG - 2025-03-28 21:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:07:59 --> Input Class Initialized
INFO - 2025-03-28 21:07:59 --> Language Class Initialized
INFO - 2025-03-28 21:07:59 --> Language Class Initialized
INFO - 2025-03-28 21:07:59 --> Config Class Initialized
INFO - 2025-03-28 21:07:59 --> Loader Class Initialized
INFO - 2025-03-28 21:07:59 --> Helper loaded: url_helper
INFO - 2025-03-28 21:07:59 --> Helper loaded: file_helper
INFO - 2025-03-28 21:07:59 --> Helper loaded: html_helper
INFO - 2025-03-28 21:07:59 --> Helper loaded: form_helper
INFO - 2025-03-28 21:07:59 --> Helper loaded: text_helper
INFO - 2025-03-28 21:07:59 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:07:59 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:07:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:07:59 --> Database Driver Class Initialized
INFO - 2025-03-28 21:07:59 --> Email Class Initialized
INFO - 2025-03-28 21:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:07:59 --> Form Validation Class Initialized
INFO - 2025-03-28 21:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:07:59 --> Pagination Class Initialized
INFO - 2025-03-28 21:07:59 --> Controller Class Initialized
DEBUG - 2025-03-28 21:07:59 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:07:59 --> Model Class Initialized
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:07:59 --> Model Class Initialized
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:07:59 --> Model Class Initialized
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:07:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:07:59 --> Model Class Initialized
ERROR - 2025-03-28 21:07:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:07:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:07:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:07:59 --> Final output sent to browser
DEBUG - 2025-03-28 21:07:59 --> Total execution time: 0.1273
INFO - 2025-03-28 21:08:00 --> Config Class Initialized
INFO - 2025-03-28 21:08:00 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:00 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:00 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:00 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:00 --> Router Class Initialized
INFO - 2025-03-28 21:08:00 --> Output Class Initialized
INFO - 2025-03-28 21:08:00 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:00 --> Input Class Initialized
INFO - 2025-03-28 21:08:00 --> Language Class Initialized
INFO - 2025-03-28 21:08:00 --> Language Class Initialized
INFO - 2025-03-28 21:08:00 --> Config Class Initialized
INFO - 2025-03-28 21:08:00 --> Loader Class Initialized
INFO - 2025-03-28 21:08:00 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:00 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:00 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:00 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:00 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:00 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:00 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:00 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:00 --> Email Class Initialized
INFO - 2025-03-28 21:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:00 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:00 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:00 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:00 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:00 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:00 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:00 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:00 --> Model Class Initialized
ERROR - 2025-03-28 21:08:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 21:08:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:01 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:01 --> Total execution time: 0.1832
INFO - 2025-03-28 21:08:04 --> Config Class Initialized
INFO - 2025-03-28 21:08:04 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:04 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:04 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:04 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:04 --> Router Class Initialized
INFO - 2025-03-28 21:08:04 --> Output Class Initialized
INFO - 2025-03-28 21:08:04 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:04 --> Input Class Initialized
INFO - 2025-03-28 21:08:04 --> Language Class Initialized
INFO - 2025-03-28 21:08:04 --> Language Class Initialized
INFO - 2025-03-28 21:08:04 --> Config Class Initialized
INFO - 2025-03-28 21:08:04 --> Loader Class Initialized
INFO - 2025-03-28 21:08:04 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:04 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:04 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:04 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:04 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:04 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:04 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:04 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:04 --> Email Class Initialized
INFO - 2025-03-28 21:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:04 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:04 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:04 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:04 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:04 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:04 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:04 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:04 --> Model Class Initialized
ERROR - 2025-03-28 21:08:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:04 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:04 --> Total execution time: 0.1376
INFO - 2025-03-28 21:08:07 --> Config Class Initialized
INFO - 2025-03-28 21:08:07 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:07 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:07 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:07 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:07 --> Router Class Initialized
INFO - 2025-03-28 21:08:07 --> Output Class Initialized
INFO - 2025-03-28 21:08:07 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:07 --> Input Class Initialized
INFO - 2025-03-28 21:08:07 --> Language Class Initialized
INFO - 2025-03-28 21:08:07 --> Language Class Initialized
INFO - 2025-03-28 21:08:07 --> Config Class Initialized
INFO - 2025-03-28 21:08:07 --> Loader Class Initialized
INFO - 2025-03-28 21:08:07 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:07 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:07 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:07 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:07 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:07 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:07 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:07 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:07 --> Email Class Initialized
INFO - 2025-03-28 21:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:07 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:07 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:07 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:07 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:07 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:07 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:07 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:07 --> Model Class Initialized
ERROR - 2025-03-28 21:08:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 21:08:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:08 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:08 --> Total execution time: 0.1550
INFO - 2025-03-28 21:08:12 --> Config Class Initialized
INFO - 2025-03-28 21:08:12 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:12 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:12 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:12 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:12 --> Router Class Initialized
INFO - 2025-03-28 21:08:12 --> Output Class Initialized
INFO - 2025-03-28 21:08:12 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:12 --> Input Class Initialized
INFO - 2025-03-28 21:08:12 --> Language Class Initialized
INFO - 2025-03-28 21:08:12 --> Language Class Initialized
INFO - 2025-03-28 21:08:12 --> Config Class Initialized
INFO - 2025-03-28 21:08:12 --> Loader Class Initialized
INFO - 2025-03-28 21:08:12 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:12 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:12 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:12 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:12 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:12 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:12 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:12 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:12 --> Email Class Initialized
INFO - 2025-03-28 21:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:12 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:12 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:12 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:12 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:12 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:12 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:12 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:12 --> Model Class Initialized
ERROR - 2025-03-28 21:08:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:12 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:12 --> Total execution time: 0.1537
INFO - 2025-03-28 21:08:17 --> Config Class Initialized
INFO - 2025-03-28 21:08:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:17 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:17 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:17 --> Router Class Initialized
INFO - 2025-03-28 21:08:17 --> Output Class Initialized
INFO - 2025-03-28 21:08:17 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:17 --> Input Class Initialized
INFO - 2025-03-28 21:08:17 --> Language Class Initialized
INFO - 2025-03-28 21:08:17 --> Language Class Initialized
INFO - 2025-03-28 21:08:17 --> Config Class Initialized
INFO - 2025-03-28 21:08:17 --> Loader Class Initialized
INFO - 2025-03-28 21:08:17 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:17 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:17 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:17 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:17 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:17 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:17 --> Email Class Initialized
INFO - 2025-03-28 21:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:17 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:17 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:17 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:17 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:17 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:17 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:17 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:17 --> Model Class Initialized
ERROR - 2025-03-28 21:08:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:18 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:18 --> Total execution time: 0.1134
INFO - 2025-03-28 21:08:27 --> Config Class Initialized
INFO - 2025-03-28 21:08:27 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:27 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:27 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:27 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:27 --> Router Class Initialized
INFO - 2025-03-28 21:08:27 --> Output Class Initialized
INFO - 2025-03-28 21:08:27 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:27 --> Input Class Initialized
INFO - 2025-03-28 21:08:27 --> Language Class Initialized
INFO - 2025-03-28 21:08:27 --> Language Class Initialized
INFO - 2025-03-28 21:08:27 --> Config Class Initialized
INFO - 2025-03-28 21:08:27 --> Loader Class Initialized
INFO - 2025-03-28 21:08:27 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:27 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:27 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:27 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:27 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:27 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:27 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:27 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:27 --> Email Class Initialized
INFO - 2025-03-28 21:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:27 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:27 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:27 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:27 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:27 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:27 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:27 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:27 --> Model Class Initialized
ERROR - 2025-03-28 21:08:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:27 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:27 --> Total execution time: 0.1308
INFO - 2025-03-28 21:08:38 --> Config Class Initialized
INFO - 2025-03-28 21:08:38 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:38 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:38 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:38 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:38 --> Router Class Initialized
INFO - 2025-03-28 21:08:38 --> Output Class Initialized
INFO - 2025-03-28 21:08:38 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:38 --> Input Class Initialized
INFO - 2025-03-28 21:08:38 --> Language Class Initialized
INFO - 2025-03-28 21:08:38 --> Language Class Initialized
INFO - 2025-03-28 21:08:38 --> Config Class Initialized
INFO - 2025-03-28 21:08:38 --> Loader Class Initialized
INFO - 2025-03-28 21:08:38 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:38 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:38 --> Email Class Initialized
INFO - 2025-03-28 21:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:38 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:38 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:38 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:38 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:38 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:38 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:38 --> Model Class Initialized
INFO - 2025-03-28 21:08:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 21:08:38 --> Config Class Initialized
INFO - 2025-03-28 21:08:38 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:38 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:38 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:38 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:38 --> Router Class Initialized
INFO - 2025-03-28 21:08:38 --> Output Class Initialized
INFO - 2025-03-28 21:08:38 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:38 --> Input Class Initialized
INFO - 2025-03-28 21:08:38 --> Language Class Initialized
INFO - 2025-03-28 21:08:38 --> Language Class Initialized
INFO - 2025-03-28 21:08:38 --> Config Class Initialized
INFO - 2025-03-28 21:08:38 --> Loader Class Initialized
INFO - 2025-03-28 21:08:38 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:38 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:38 --> Email Class Initialized
INFO - 2025-03-28 21:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:38 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:38 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:38 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:38 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:38 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:38 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:38 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:38 --> Model Class Initialized
ERROR - 2025-03-28 21:08:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:38 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:38 --> Total execution time: 0.1404
INFO - 2025-03-28 21:08:48 --> Config Class Initialized
INFO - 2025-03-28 21:08:48 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:08:48 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:08:48 --> Utf8 Class Initialized
INFO - 2025-03-28 21:08:48 --> URI Class Initialized
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:08:48 --> Router Class Initialized
INFO - 2025-03-28 21:08:48 --> Output Class Initialized
INFO - 2025-03-28 21:08:48 --> Security Class Initialized
DEBUG - 2025-03-28 21:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:08:48 --> Input Class Initialized
INFO - 2025-03-28 21:08:48 --> Language Class Initialized
INFO - 2025-03-28 21:08:48 --> Language Class Initialized
INFO - 2025-03-28 21:08:48 --> Config Class Initialized
INFO - 2025-03-28 21:08:48 --> Loader Class Initialized
INFO - 2025-03-28 21:08:48 --> Helper loaded: url_helper
INFO - 2025-03-28 21:08:48 --> Helper loaded: file_helper
INFO - 2025-03-28 21:08:48 --> Helper loaded: html_helper
INFO - 2025-03-28 21:08:48 --> Helper loaded: form_helper
INFO - 2025-03-28 21:08:48 --> Helper loaded: text_helper
INFO - 2025-03-28 21:08:48 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:08:48 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:08:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:08:48 --> Database Driver Class Initialized
INFO - 2025-03-28 21:08:48 --> Email Class Initialized
INFO - 2025-03-28 21:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:08:48 --> Form Validation Class Initialized
INFO - 2025-03-28 21:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:08:48 --> Pagination Class Initialized
INFO - 2025-03-28 21:08:48 --> Controller Class Initialized
DEBUG - 2025-03-28 21:08:48 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:08:48 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:08:48 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:08:48 --> Model Class Initialized
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:08:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:08:48 --> Model Class Initialized
ERROR - 2025-03-28 21:08:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:08:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:08:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:08:48 --> Final output sent to browser
DEBUG - 2025-03-28 21:08:48 --> Total execution time: 0.1185
INFO - 2025-03-28 21:09:16 --> Config Class Initialized
INFO - 2025-03-28 21:09:16 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:09:16 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:09:16 --> Utf8 Class Initialized
INFO - 2025-03-28 21:09:16 --> URI Class Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:09:16 --> Router Class Initialized
INFO - 2025-03-28 21:09:16 --> Output Class Initialized
INFO - 2025-03-28 21:09:16 --> Security Class Initialized
DEBUG - 2025-03-28 21:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:09:16 --> Input Class Initialized
INFO - 2025-03-28 21:09:16 --> Language Class Initialized
INFO - 2025-03-28 21:09:16 --> Language Class Initialized
INFO - 2025-03-28 21:09:16 --> Config Class Initialized
INFO - 2025-03-28 21:09:16 --> Loader Class Initialized
INFO - 2025-03-28 21:09:16 --> Helper loaded: url_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: file_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: html_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: form_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: text_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:09:16 --> Database Driver Class Initialized
INFO - 2025-03-28 21:09:16 --> Email Class Initialized
INFO - 2025-03-28 21:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:09:16 --> Form Validation Class Initialized
INFO - 2025-03-28 21:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:09:16 --> Pagination Class Initialized
INFO - 2025-03-28 21:09:16 --> Controller Class Initialized
DEBUG - 2025-03-28 21:09:16 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:09:16 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:09:16 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:09:16 --> Model Class Initialized
INFO - 2025-03-28 21:09:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 21:09:16 --> Config Class Initialized
INFO - 2025-03-28 21:09:16 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:09:16 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:09:16 --> Utf8 Class Initialized
INFO - 2025-03-28 21:09:16 --> URI Class Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:09:16 --> Router Class Initialized
INFO - 2025-03-28 21:09:16 --> Output Class Initialized
INFO - 2025-03-28 21:09:16 --> Security Class Initialized
DEBUG - 2025-03-28 21:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:09:16 --> Input Class Initialized
INFO - 2025-03-28 21:09:16 --> Language Class Initialized
INFO - 2025-03-28 21:09:16 --> Language Class Initialized
INFO - 2025-03-28 21:09:16 --> Config Class Initialized
INFO - 2025-03-28 21:09:16 --> Loader Class Initialized
INFO - 2025-03-28 21:09:16 --> Helper loaded: url_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: file_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: html_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: form_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: text_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:09:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:09:16 --> Database Driver Class Initialized
INFO - 2025-03-28 21:09:16 --> Email Class Initialized
INFO - 2025-03-28 21:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:09:16 --> Form Validation Class Initialized
INFO - 2025-03-28 21:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:09:16 --> Pagination Class Initialized
INFO - 2025-03-28 21:09:16 --> Controller Class Initialized
DEBUG - 2025-03-28 21:09:16 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:09:16 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:09:16 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:09:16 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:09:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:09:16 --> Model Class Initialized
ERROR - 2025-03-28 21:09:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:09:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:09:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:09:16 --> Final output sent to browser
DEBUG - 2025-03-28 21:09:16 --> Total execution time: 0.1348
INFO - 2025-03-28 21:09:32 --> Config Class Initialized
INFO - 2025-03-28 21:09:32 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:09:32 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:09:32 --> Utf8 Class Initialized
INFO - 2025-03-28 21:09:32 --> URI Class Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:09:32 --> Router Class Initialized
INFO - 2025-03-28 21:09:32 --> Output Class Initialized
INFO - 2025-03-28 21:09:32 --> Security Class Initialized
DEBUG - 2025-03-28 21:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:09:32 --> Input Class Initialized
INFO - 2025-03-28 21:09:32 --> Language Class Initialized
INFO - 2025-03-28 21:09:32 --> Language Class Initialized
INFO - 2025-03-28 21:09:32 --> Config Class Initialized
INFO - 2025-03-28 21:09:32 --> Loader Class Initialized
INFO - 2025-03-28 21:09:32 --> Helper loaded: url_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: file_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: html_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: form_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: text_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:09:32 --> Database Driver Class Initialized
INFO - 2025-03-28 21:09:32 --> Email Class Initialized
INFO - 2025-03-28 21:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:09:32 --> Form Validation Class Initialized
INFO - 2025-03-28 21:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:09:32 --> Pagination Class Initialized
INFO - 2025-03-28 21:09:32 --> Controller Class Initialized
DEBUG - 2025-03-28 21:09:32 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:09:32 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:09:32 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:09:32 --> Model Class Initialized
INFO - 2025-03-28 21:09:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 21:09:32 --> Config Class Initialized
INFO - 2025-03-28 21:09:32 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:09:32 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:09:32 --> Utf8 Class Initialized
INFO - 2025-03-28 21:09:32 --> URI Class Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:09:32 --> Router Class Initialized
INFO - 2025-03-28 21:09:32 --> Output Class Initialized
INFO - 2025-03-28 21:09:32 --> Security Class Initialized
DEBUG - 2025-03-28 21:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:09:32 --> Input Class Initialized
INFO - 2025-03-28 21:09:32 --> Language Class Initialized
INFO - 2025-03-28 21:09:32 --> Language Class Initialized
INFO - 2025-03-28 21:09:32 --> Config Class Initialized
INFO - 2025-03-28 21:09:32 --> Loader Class Initialized
INFO - 2025-03-28 21:09:32 --> Helper loaded: url_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: file_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: html_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: form_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: text_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:09:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:09:32 --> Database Driver Class Initialized
INFO - 2025-03-28 21:09:32 --> Email Class Initialized
INFO - 2025-03-28 21:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:09:32 --> Form Validation Class Initialized
INFO - 2025-03-28 21:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:09:32 --> Pagination Class Initialized
INFO - 2025-03-28 21:09:32 --> Controller Class Initialized
DEBUG - 2025-03-28 21:09:32 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:09:32 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:09:32 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:09:32 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:09:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:09:32 --> Model Class Initialized
ERROR - 2025-03-28 21:09:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:09:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:09:32 --> Final output sent to browser
DEBUG - 2025-03-28 21:09:32 --> Total execution time: 0.0778
INFO - 2025-03-28 21:09:50 --> Config Class Initialized
INFO - 2025-03-28 21:09:50 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:09:50 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:09:50 --> Utf8 Class Initialized
INFO - 2025-03-28 21:09:50 --> URI Class Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:09:50 --> Router Class Initialized
INFO - 2025-03-28 21:09:50 --> Output Class Initialized
INFO - 2025-03-28 21:09:50 --> Security Class Initialized
DEBUG - 2025-03-28 21:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:09:50 --> Input Class Initialized
INFO - 2025-03-28 21:09:50 --> Language Class Initialized
INFO - 2025-03-28 21:09:50 --> Language Class Initialized
INFO - 2025-03-28 21:09:50 --> Config Class Initialized
INFO - 2025-03-28 21:09:50 --> Loader Class Initialized
INFO - 2025-03-28 21:09:50 --> Helper loaded: url_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: file_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: html_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: form_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: text_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:09:50 --> Database Driver Class Initialized
INFO - 2025-03-28 21:09:50 --> Email Class Initialized
INFO - 2025-03-28 21:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:09:50 --> Form Validation Class Initialized
INFO - 2025-03-28 21:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:09:50 --> Pagination Class Initialized
INFO - 2025-03-28 21:09:50 --> Controller Class Initialized
DEBUG - 2025-03-28 21:09:50 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:09:50 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:09:50 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:09:50 --> Model Class Initialized
INFO - 2025-03-28 21:09:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 21:09:50 --> Config Class Initialized
INFO - 2025-03-28 21:09:50 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:09:50 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:09:50 --> Utf8 Class Initialized
INFO - 2025-03-28 21:09:50 --> URI Class Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:09:50 --> Router Class Initialized
INFO - 2025-03-28 21:09:50 --> Output Class Initialized
INFO - 2025-03-28 21:09:50 --> Security Class Initialized
DEBUG - 2025-03-28 21:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:09:50 --> Input Class Initialized
INFO - 2025-03-28 21:09:50 --> Language Class Initialized
INFO - 2025-03-28 21:09:50 --> Language Class Initialized
INFO - 2025-03-28 21:09:50 --> Config Class Initialized
INFO - 2025-03-28 21:09:50 --> Loader Class Initialized
INFO - 2025-03-28 21:09:50 --> Helper loaded: url_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: file_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: html_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: form_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: text_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:09:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:09:50 --> Database Driver Class Initialized
INFO - 2025-03-28 21:09:50 --> Email Class Initialized
INFO - 2025-03-28 21:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:09:50 --> Form Validation Class Initialized
INFO - 2025-03-28 21:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:09:50 --> Pagination Class Initialized
INFO - 2025-03-28 21:09:50 --> Controller Class Initialized
DEBUG - 2025-03-28 21:09:50 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:09:50 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:09:50 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:09:50 --> Model Class Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:09:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:09:50 --> Model Class Initialized
ERROR - 2025-03-28 21:09:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:09:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:09:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:09:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:09:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:09:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:09:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:09:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:09:51 --> Final output sent to browser
DEBUG - 2025-03-28 21:09:51 --> Total execution time: 0.1467
INFO - 2025-03-28 21:10:10 --> Config Class Initialized
INFO - 2025-03-28 21:10:10 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:10:10 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:10:10 --> Utf8 Class Initialized
INFO - 2025-03-28 21:10:10 --> URI Class Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:10:10 --> Router Class Initialized
INFO - 2025-03-28 21:10:10 --> Output Class Initialized
INFO - 2025-03-28 21:10:10 --> Security Class Initialized
DEBUG - 2025-03-28 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:10:10 --> Input Class Initialized
INFO - 2025-03-28 21:10:10 --> Language Class Initialized
INFO - 2025-03-28 21:10:10 --> Language Class Initialized
INFO - 2025-03-28 21:10:10 --> Config Class Initialized
INFO - 2025-03-28 21:10:10 --> Loader Class Initialized
INFO - 2025-03-28 21:10:10 --> Helper loaded: url_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: file_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: html_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: form_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: text_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:10:10 --> Database Driver Class Initialized
INFO - 2025-03-28 21:10:10 --> Email Class Initialized
INFO - 2025-03-28 21:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:10:10 --> Form Validation Class Initialized
INFO - 2025-03-28 21:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:10:10 --> Pagination Class Initialized
INFO - 2025-03-28 21:10:10 --> Controller Class Initialized
DEBUG - 2025-03-28 21:10:10 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:10:10 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:10:10 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:10:10 --> Model Class Initialized
INFO - 2025-03-28 21:10:10 --> Config Class Initialized
INFO - 2025-03-28 21:10:10 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:10:10 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:10:10 --> Utf8 Class Initialized
INFO - 2025-03-28 21:10:10 --> URI Class Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:10:10 --> Router Class Initialized
INFO - 2025-03-28 21:10:10 --> Output Class Initialized
INFO - 2025-03-28 21:10:10 --> Security Class Initialized
DEBUG - 2025-03-28 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:10:10 --> Input Class Initialized
INFO - 2025-03-28 21:10:10 --> Language Class Initialized
INFO - 2025-03-28 21:10:10 --> Language Class Initialized
INFO - 2025-03-28 21:10:10 --> Config Class Initialized
INFO - 2025-03-28 21:10:10 --> Loader Class Initialized
INFO - 2025-03-28 21:10:10 --> Helper loaded: url_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: file_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: html_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: form_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: text_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:10:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:10:10 --> Database Driver Class Initialized
INFO - 2025-03-28 21:10:10 --> Email Class Initialized
INFO - 2025-03-28 21:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:10:10 --> Form Validation Class Initialized
INFO - 2025-03-28 21:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:10:10 --> Pagination Class Initialized
INFO - 2025-03-28 21:10:10 --> Controller Class Initialized
DEBUG - 2025-03-28 21:10:10 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:10:10 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:10:10 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:10:10 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:10:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:10:10 --> Model Class Initialized
ERROR - 2025-03-28 21:10:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:10:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:10:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:10:10 --> Final output sent to browser
DEBUG - 2025-03-28 21:10:10 --> Total execution time: 0.1249
INFO - 2025-03-28 21:10:28 --> Config Class Initialized
INFO - 2025-03-28 21:10:28 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:10:28 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:10:28 --> Utf8 Class Initialized
INFO - 2025-03-28 21:10:28 --> URI Class Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:10:28 --> Router Class Initialized
INFO - 2025-03-28 21:10:28 --> Output Class Initialized
INFO - 2025-03-28 21:10:28 --> Security Class Initialized
DEBUG - 2025-03-28 21:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:10:28 --> Input Class Initialized
INFO - 2025-03-28 21:10:28 --> Language Class Initialized
INFO - 2025-03-28 21:10:28 --> Language Class Initialized
INFO - 2025-03-28 21:10:28 --> Config Class Initialized
INFO - 2025-03-28 21:10:28 --> Loader Class Initialized
INFO - 2025-03-28 21:10:28 --> Helper loaded: url_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: file_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: html_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: form_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: text_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:10:28 --> Database Driver Class Initialized
INFO - 2025-03-28 21:10:28 --> Email Class Initialized
INFO - 2025-03-28 21:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:10:28 --> Form Validation Class Initialized
INFO - 2025-03-28 21:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:10:28 --> Pagination Class Initialized
INFO - 2025-03-28 21:10:28 --> Controller Class Initialized
DEBUG - 2025-03-28 21:10:28 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:10:28 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:10:28 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:10:28 --> Model Class Initialized
INFO - 2025-03-28 21:10:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 21:10:28 --> Config Class Initialized
INFO - 2025-03-28 21:10:28 --> Hooks Class Initialized
DEBUG - 2025-03-28 21:10:28 --> UTF-8 Support Enabled
INFO - 2025-03-28 21:10:28 --> Utf8 Class Initialized
INFO - 2025-03-28 21:10:28 --> URI Class Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 21:10:28 --> Router Class Initialized
INFO - 2025-03-28 21:10:28 --> Output Class Initialized
INFO - 2025-03-28 21:10:28 --> Security Class Initialized
DEBUG - 2025-03-28 21:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 21:10:28 --> Input Class Initialized
INFO - 2025-03-28 21:10:28 --> Language Class Initialized
INFO - 2025-03-28 21:10:28 --> Language Class Initialized
INFO - 2025-03-28 21:10:28 --> Config Class Initialized
INFO - 2025-03-28 21:10:28 --> Loader Class Initialized
INFO - 2025-03-28 21:10:28 --> Helper loaded: url_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: file_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: html_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: form_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: text_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: lang_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: directory_helper
INFO - 2025-03-28 21:10:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 21:10:28 --> Database Driver Class Initialized
INFO - 2025-03-28 21:10:28 --> Email Class Initialized
INFO - 2025-03-28 21:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 21:10:28 --> Form Validation Class Initialized
INFO - 2025-03-28 21:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 21:10:28 --> Pagination Class Initialized
INFO - 2025-03-28 21:10:28 --> Controller Class Initialized
DEBUG - 2025-03-28 21:10:28 --> Product MX_Controller Initialized
INFO - 2025-03-28 21:10:28 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 21:10:28 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 21:10:28 --> Model Class Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 21:10:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 21:10:28 --> Model Class Initialized
ERROR - 2025-03-28 21:10:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 21:10:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 21:10:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 21:10:28 --> Final output sent to browser
DEBUG - 2025-03-28 21:10:28 --> Total execution time: 0.1195
INFO - 2025-03-28 22:28:55 --> Config Class Initialized
INFO - 2025-03-28 22:28:55 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:28:55 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:28:55 --> Utf8 Class Initialized
INFO - 2025-03-28 22:28:55 --> URI Class Initialized
DEBUG - 2025-03-28 22:28:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:28:55 --> Router Class Initialized
INFO - 2025-03-28 22:28:55 --> Output Class Initialized
INFO - 2025-03-28 22:28:55 --> Security Class Initialized
DEBUG - 2025-03-28 22:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:28:55 --> Input Class Initialized
INFO - 2025-03-28 22:28:55 --> Language Class Initialized
INFO - 2025-03-28 22:28:55 --> Language Class Initialized
INFO - 2025-03-28 22:28:55 --> Config Class Initialized
INFO - 2025-03-28 22:28:55 --> Loader Class Initialized
INFO - 2025-03-28 22:28:55 --> Helper loaded: url_helper
INFO - 2025-03-28 22:28:55 --> Helper loaded: file_helper
INFO - 2025-03-28 22:28:55 --> Helper loaded: html_helper
INFO - 2025-03-28 22:28:55 --> Helper loaded: form_helper
INFO - 2025-03-28 22:28:55 --> Helper loaded: text_helper
INFO - 2025-03-28 22:28:55 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:28:55 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:28:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:28:55 --> Database Driver Class Initialized
INFO - 2025-03-28 22:28:55 --> Email Class Initialized
INFO - 2025-03-28 22:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:28:55 --> Form Validation Class Initialized
INFO - 2025-03-28 22:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:28:55 --> Pagination Class Initialized
INFO - 2025-03-28 22:28:55 --> Controller Class Initialized
DEBUG - 2025-03-28 22:28:55 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:28:55 --> Model Class Initialized
DEBUG - 2025-03-28 22:28:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:28:55 --> Model Class Initialized
DEBUG - 2025-03-28 22:28:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:28:55 --> Model Class Initialized
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:28:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:28:56 --> Model Class Initialized
ERROR - 2025-03-28 22:28:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:28:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:28:56 --> Final output sent to browser
DEBUG - 2025-03-28 22:28:56 --> Total execution time: 0.7803
INFO - 2025-03-28 22:28:56 --> Config Class Initialized
INFO - 2025-03-28 22:28:56 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:28:56 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:28:56 --> Utf8 Class Initialized
INFO - 2025-03-28 22:28:56 --> URI Class Initialized
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:28:56 --> Router Class Initialized
INFO - 2025-03-28 22:28:56 --> Output Class Initialized
INFO - 2025-03-28 22:28:56 --> Security Class Initialized
DEBUG - 2025-03-28 22:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:28:56 --> Input Class Initialized
INFO - 2025-03-28 22:28:56 --> Language Class Initialized
INFO - 2025-03-28 22:28:56 --> Language Class Initialized
INFO - 2025-03-28 22:28:56 --> Config Class Initialized
INFO - 2025-03-28 22:28:56 --> Loader Class Initialized
INFO - 2025-03-28 22:28:56 --> Helper loaded: url_helper
INFO - 2025-03-28 22:28:56 --> Helper loaded: file_helper
INFO - 2025-03-28 22:28:56 --> Helper loaded: html_helper
INFO - 2025-03-28 22:28:56 --> Helper loaded: form_helper
INFO - 2025-03-28 22:28:56 --> Helper loaded: text_helper
INFO - 2025-03-28 22:28:56 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:28:56 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:28:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:28:56 --> Database Driver Class Initialized
INFO - 2025-03-28 22:28:56 --> Email Class Initialized
INFO - 2025-03-28 22:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:28:56 --> Form Validation Class Initialized
INFO - 2025-03-28 22:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:28:56 --> Pagination Class Initialized
INFO - 2025-03-28 22:28:56 --> Controller Class Initialized
DEBUG - 2025-03-28 22:28:56 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:28:56 --> Model Class Initialized
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:28:56 --> Model Class Initialized
DEBUG - 2025-03-28 22:28:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:28:56 --> Model Class Initialized
ERROR - 2025-03-28 22:28:56 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:28:56 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:28:56 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:28:56 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:28:56 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:28:56 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:28:56 --> Final output sent to browser
DEBUG - 2025-03-28 22:28:56 --> Total execution time: 0.0444
INFO - 2025-03-28 22:29:16 --> Config Class Initialized
INFO - 2025-03-28 22:29:16 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:29:16 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:29:16 --> Utf8 Class Initialized
INFO - 2025-03-28 22:29:16 --> URI Class Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:29:16 --> Router Class Initialized
INFO - 2025-03-28 22:29:16 --> Output Class Initialized
INFO - 2025-03-28 22:29:16 --> Security Class Initialized
DEBUG - 2025-03-28 22:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:29:16 --> Input Class Initialized
INFO - 2025-03-28 22:29:16 --> Language Class Initialized
INFO - 2025-03-28 22:29:16 --> Language Class Initialized
INFO - 2025-03-28 22:29:16 --> Config Class Initialized
INFO - 2025-03-28 22:29:16 --> Loader Class Initialized
INFO - 2025-03-28 22:29:16 --> Helper loaded: url_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: file_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: html_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: form_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: text_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:29:16 --> Database Driver Class Initialized
INFO - 2025-03-28 22:29:16 --> Email Class Initialized
INFO - 2025-03-28 22:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:29:16 --> Form Validation Class Initialized
INFO - 2025-03-28 22:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:29:16 --> Pagination Class Initialized
INFO - 2025-03-28 22:29:16 --> Controller Class Initialized
DEBUG - 2025-03-28 22:29:16 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:29:16 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:29:16 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:29:16 --> Model Class Initialized
INFO - 2025-03-28 22:29:16 --> Config Class Initialized
INFO - 2025-03-28 22:29:16 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:29:16 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:29:16 --> Utf8 Class Initialized
INFO - 2025-03-28 22:29:16 --> URI Class Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-28 22:29:16 --> Router Class Initialized
INFO - 2025-03-28 22:29:16 --> Output Class Initialized
INFO - 2025-03-28 22:29:16 --> Security Class Initialized
DEBUG - 2025-03-28 22:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:29:16 --> Input Class Initialized
INFO - 2025-03-28 22:29:16 --> Language Class Initialized
INFO - 2025-03-28 22:29:16 --> Language Class Initialized
INFO - 2025-03-28 22:29:16 --> Config Class Initialized
INFO - 2025-03-28 22:29:16 --> Loader Class Initialized
INFO - 2025-03-28 22:29:16 --> Helper loaded: url_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: file_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: html_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: form_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: text_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:29:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:29:16 --> Database Driver Class Initialized
INFO - 2025-03-28 22:29:16 --> Email Class Initialized
INFO - 2025-03-28 22:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:29:16 --> Form Validation Class Initialized
INFO - 2025-03-28 22:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:29:16 --> Pagination Class Initialized
INFO - 2025-03-28 22:29:16 --> Controller Class Initialized
DEBUG - 2025-03-28 22:29:16 --> Auth MX_Controller Initialized
INFO - 2025-03-28 22:29:16 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-28 22:29:16 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:29:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:29:16 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-28 22:29:16 --> Final output sent to browser
DEBUG - 2025-03-28 22:29:16 --> Total execution time: 0.0140
INFO - 2025-03-28 22:29:23 --> Config Class Initialized
INFO - 2025-03-28 22:29:23 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:29:23 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:29:23 --> Utf8 Class Initialized
INFO - 2025-03-28 22:29:23 --> URI Class Initialized
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:29:23 --> Router Class Initialized
INFO - 2025-03-28 22:29:23 --> Output Class Initialized
INFO - 2025-03-28 22:29:23 --> Security Class Initialized
DEBUG - 2025-03-28 22:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:29:23 --> Input Class Initialized
INFO - 2025-03-28 22:29:23 --> Language Class Initialized
INFO - 2025-03-28 22:29:23 --> Language Class Initialized
INFO - 2025-03-28 22:29:23 --> Config Class Initialized
INFO - 2025-03-28 22:29:23 --> Loader Class Initialized
INFO - 2025-03-28 22:29:23 --> Helper loaded: url_helper
INFO - 2025-03-28 22:29:23 --> Helper loaded: file_helper
INFO - 2025-03-28 22:29:23 --> Helper loaded: html_helper
INFO - 2025-03-28 22:29:23 --> Helper loaded: form_helper
INFO - 2025-03-28 22:29:23 --> Helper loaded: text_helper
INFO - 2025-03-28 22:29:23 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:29:23 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:29:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:29:23 --> Database Driver Class Initialized
INFO - 2025-03-28 22:29:23 --> Email Class Initialized
INFO - 2025-03-28 22:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:29:23 --> Form Validation Class Initialized
INFO - 2025-03-28 22:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:29:23 --> Pagination Class Initialized
INFO - 2025-03-28 22:29:23 --> Controller Class Initialized
DEBUG - 2025-03-28 22:29:23 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:29:23 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:29:23 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:29:23 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:29:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:29:23 --> Model Class Initialized
ERROR - 2025-03-28 22:29:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:29:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:29:23 --> Final output sent to browser
DEBUG - 2025-03-28 22:29:23 --> Total execution time: 0.0905
INFO - 2025-03-28 22:29:25 --> Config Class Initialized
INFO - 2025-03-28 22:29:25 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:29:25 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:29:25 --> Utf8 Class Initialized
INFO - 2025-03-28 22:29:25 --> URI Class Initialized
DEBUG - 2025-03-28 22:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:29:25 --> Router Class Initialized
INFO - 2025-03-28 22:29:25 --> Output Class Initialized
INFO - 2025-03-28 22:29:25 --> Security Class Initialized
DEBUG - 2025-03-28 22:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:29:25 --> Input Class Initialized
INFO - 2025-03-28 22:29:25 --> Language Class Initialized
INFO - 2025-03-28 22:29:25 --> Language Class Initialized
INFO - 2025-03-28 22:29:25 --> Config Class Initialized
INFO - 2025-03-28 22:29:25 --> Loader Class Initialized
INFO - 2025-03-28 22:29:25 --> Helper loaded: url_helper
INFO - 2025-03-28 22:29:25 --> Helper loaded: file_helper
INFO - 2025-03-28 22:29:25 --> Helper loaded: html_helper
INFO - 2025-03-28 22:29:25 --> Helper loaded: form_helper
INFO - 2025-03-28 22:29:25 --> Helper loaded: text_helper
INFO - 2025-03-28 22:29:25 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:29:25 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:29:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:29:25 --> Database Driver Class Initialized
INFO - 2025-03-28 22:29:25 --> Email Class Initialized
INFO - 2025-03-28 22:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:29:25 --> Form Validation Class Initialized
INFO - 2025-03-28 22:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:29:25 --> Pagination Class Initialized
INFO - 2025-03-28 22:29:25 --> Controller Class Initialized
DEBUG - 2025-03-28 22:29:25 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:29:25 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:29:25 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:29:25 --> Model Class Initialized
ERROR - 2025-03-28 22:29:25 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:25 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:25 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:25 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:25 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:25 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:29:25 --> Final output sent to browser
DEBUG - 2025-03-28 22:29:25 --> Total execution time: 0.0374
INFO - 2025-03-28 22:29:27 --> Config Class Initialized
INFO - 2025-03-28 22:29:27 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:29:27 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:29:27 --> Utf8 Class Initialized
INFO - 2025-03-28 22:29:27 --> URI Class Initialized
DEBUG - 2025-03-28 22:29:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:29:27 --> Router Class Initialized
INFO - 2025-03-28 22:29:27 --> Output Class Initialized
INFO - 2025-03-28 22:29:27 --> Security Class Initialized
DEBUG - 2025-03-28 22:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:29:27 --> Input Class Initialized
INFO - 2025-03-28 22:29:27 --> Language Class Initialized
INFO - 2025-03-28 22:29:27 --> Language Class Initialized
INFO - 2025-03-28 22:29:27 --> Config Class Initialized
INFO - 2025-03-28 22:29:27 --> Loader Class Initialized
INFO - 2025-03-28 22:29:27 --> Helper loaded: url_helper
INFO - 2025-03-28 22:29:27 --> Helper loaded: file_helper
INFO - 2025-03-28 22:29:27 --> Helper loaded: html_helper
INFO - 2025-03-28 22:29:27 --> Helper loaded: form_helper
INFO - 2025-03-28 22:29:27 --> Helper loaded: text_helper
INFO - 2025-03-28 22:29:27 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:29:27 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:29:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:29:27 --> Database Driver Class Initialized
INFO - 2025-03-28 22:29:27 --> Email Class Initialized
INFO - 2025-03-28 22:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:29:27 --> Form Validation Class Initialized
INFO - 2025-03-28 22:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:29:27 --> Pagination Class Initialized
INFO - 2025-03-28 22:29:27 --> Controller Class Initialized
DEBUG - 2025-03-28 22:29:27 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:29:27 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:29:27 --> Model Class Initialized
DEBUG - 2025-03-28 22:29:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:29:27 --> Model Class Initialized
ERROR - 2025-03-28 22:29:27 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:27 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:27 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:27 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:27 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:29:27 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:29:27 --> Final output sent to browser
DEBUG - 2025-03-28 22:29:27 --> Total execution time: 0.0170
INFO - 2025-03-28 22:31:20 --> Config Class Initialized
INFO - 2025-03-28 22:31:20 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:31:20 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:31:20 --> Utf8 Class Initialized
INFO - 2025-03-28 22:31:20 --> URI Class Initialized
DEBUG - 2025-03-28 22:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:31:20 --> Router Class Initialized
INFO - 2025-03-28 22:31:20 --> Output Class Initialized
INFO - 2025-03-28 22:31:20 --> Security Class Initialized
DEBUG - 2025-03-28 22:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:31:20 --> Input Class Initialized
INFO - 2025-03-28 22:31:20 --> Language Class Initialized
INFO - 2025-03-28 22:31:20 --> Language Class Initialized
INFO - 2025-03-28 22:31:20 --> Config Class Initialized
INFO - 2025-03-28 22:31:20 --> Loader Class Initialized
INFO - 2025-03-28 22:31:20 --> Helper loaded: url_helper
INFO - 2025-03-28 22:31:20 --> Helper loaded: file_helper
INFO - 2025-03-28 22:31:20 --> Helper loaded: html_helper
INFO - 2025-03-28 22:31:20 --> Helper loaded: form_helper
INFO - 2025-03-28 22:31:20 --> Helper loaded: text_helper
INFO - 2025-03-28 22:31:20 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:31:20 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:31:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:31:20 --> Database Driver Class Initialized
INFO - 2025-03-28 22:31:20 --> Email Class Initialized
INFO - 2025-03-28 22:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:31:20 --> Form Validation Class Initialized
INFO - 2025-03-28 22:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:31:20 --> Pagination Class Initialized
INFO - 2025-03-28 22:31:20 --> Controller Class Initialized
DEBUG - 2025-03-28 22:31:20 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:31:20 --> Model Class Initialized
DEBUG - 2025-03-28 22:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:31:20 --> Model Class Initialized
DEBUG - 2025-03-28 22:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:31:20 --> Model Class Initialized
ERROR - 2025-03-28 22:31:20 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:31:20 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:31:20 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:31:20 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:31:20 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:31:20 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:31:20 --> Final output sent to browser
DEBUG - 2025-03-28 22:31:20 --> Total execution time: 0.0501
INFO - 2025-03-28 22:33:01 --> Config Class Initialized
INFO - 2025-03-28 22:33:01 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:33:01 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:33:01 --> Utf8 Class Initialized
INFO - 2025-03-28 22:33:01 --> URI Class Initialized
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:33:01 --> Router Class Initialized
INFO - 2025-03-28 22:33:01 --> Output Class Initialized
INFO - 2025-03-28 22:33:01 --> Security Class Initialized
DEBUG - 2025-03-28 22:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:33:01 --> Input Class Initialized
INFO - 2025-03-28 22:33:01 --> Language Class Initialized
INFO - 2025-03-28 22:33:01 --> Language Class Initialized
INFO - 2025-03-28 22:33:01 --> Config Class Initialized
INFO - 2025-03-28 22:33:01 --> Loader Class Initialized
INFO - 2025-03-28 22:33:01 --> Helper loaded: url_helper
INFO - 2025-03-28 22:33:01 --> Helper loaded: file_helper
INFO - 2025-03-28 22:33:01 --> Helper loaded: html_helper
INFO - 2025-03-28 22:33:01 --> Helper loaded: form_helper
INFO - 2025-03-28 22:33:01 --> Helper loaded: text_helper
INFO - 2025-03-28 22:33:01 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:33:01 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:33:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:33:01 --> Database Driver Class Initialized
INFO - 2025-03-28 22:33:01 --> Email Class Initialized
INFO - 2025-03-28 22:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:33:01 --> Form Validation Class Initialized
INFO - 2025-03-28 22:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:33:01 --> Pagination Class Initialized
INFO - 2025-03-28 22:33:01 --> Controller Class Initialized
DEBUG - 2025-03-28 22:33:01 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:33:01 --> Model Class Initialized
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:33:01 --> Model Class Initialized
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:33:01 --> Model Class Initialized
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:33:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:33:01 --> Model Class Initialized
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 115
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-03-28 22:33:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:33:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:33:01 --> Final output sent to browser
DEBUG - 2025-03-28 22:33:01 --> Total execution time: 0.1559
INFO - 2025-03-28 22:36:42 --> Config Class Initialized
INFO - 2025-03-28 22:36:42 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:36:42 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:36:42 --> Utf8 Class Initialized
INFO - 2025-03-28 22:36:42 --> URI Class Initialized
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:36:42 --> Router Class Initialized
INFO - 2025-03-28 22:36:42 --> Output Class Initialized
INFO - 2025-03-28 22:36:42 --> Security Class Initialized
DEBUG - 2025-03-28 22:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:36:42 --> Input Class Initialized
INFO - 2025-03-28 22:36:42 --> Language Class Initialized
INFO - 2025-03-28 22:36:42 --> Language Class Initialized
INFO - 2025-03-28 22:36:42 --> Config Class Initialized
INFO - 2025-03-28 22:36:42 --> Loader Class Initialized
INFO - 2025-03-28 22:36:42 --> Helper loaded: url_helper
INFO - 2025-03-28 22:36:42 --> Helper loaded: file_helper
INFO - 2025-03-28 22:36:42 --> Helper loaded: html_helper
INFO - 2025-03-28 22:36:42 --> Helper loaded: form_helper
INFO - 2025-03-28 22:36:42 --> Helper loaded: text_helper
INFO - 2025-03-28 22:36:42 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:36:42 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:36:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:36:42 --> Database Driver Class Initialized
INFO - 2025-03-28 22:36:42 --> Email Class Initialized
INFO - 2025-03-28 22:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:36:42 --> Form Validation Class Initialized
INFO - 2025-03-28 22:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:36:42 --> Pagination Class Initialized
INFO - 2025-03-28 22:36:42 --> Controller Class Initialized
DEBUG - 2025-03-28 22:36:42 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:36:42 --> Model Class Initialized
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:36:42 --> Model Class Initialized
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:36:42 --> Model Class Initialized
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:36:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:36:42 --> Model Class Initialized
ERROR - 2025-03-28 22:36:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:36:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:36:42 --> Final output sent to browser
DEBUG - 2025-03-28 22:36:42 --> Total execution time: 0.0999
INFO - 2025-03-28 22:36:43 --> Config Class Initialized
INFO - 2025-03-28 22:36:43 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:36:43 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:36:43 --> Utf8 Class Initialized
INFO - 2025-03-28 22:36:43 --> URI Class Initialized
DEBUG - 2025-03-28 22:36:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:36:43 --> Router Class Initialized
INFO - 2025-03-28 22:36:43 --> Output Class Initialized
INFO - 2025-03-28 22:36:43 --> Security Class Initialized
DEBUG - 2025-03-28 22:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:36:43 --> Input Class Initialized
INFO - 2025-03-28 22:36:43 --> Language Class Initialized
INFO - 2025-03-28 22:36:43 --> Language Class Initialized
INFO - 2025-03-28 22:36:43 --> Config Class Initialized
INFO - 2025-03-28 22:36:43 --> Loader Class Initialized
INFO - 2025-03-28 22:36:43 --> Helper loaded: url_helper
INFO - 2025-03-28 22:36:43 --> Helper loaded: file_helper
INFO - 2025-03-28 22:36:43 --> Helper loaded: html_helper
INFO - 2025-03-28 22:36:43 --> Helper loaded: form_helper
INFO - 2025-03-28 22:36:43 --> Helper loaded: text_helper
INFO - 2025-03-28 22:36:43 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:36:43 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:36:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:36:43 --> Database Driver Class Initialized
INFO - 2025-03-28 22:36:43 --> Email Class Initialized
INFO - 2025-03-28 22:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:36:43 --> Form Validation Class Initialized
INFO - 2025-03-28 22:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:36:43 --> Pagination Class Initialized
INFO - 2025-03-28 22:36:43 --> Controller Class Initialized
DEBUG - 2025-03-28 22:36:43 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:36:43 --> Model Class Initialized
DEBUG - 2025-03-28 22:36:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:36:43 --> Model Class Initialized
DEBUG - 2025-03-28 22:36:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:36:43 --> Model Class Initialized
ERROR - 2025-03-28 22:36:43 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:36:43 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:36:43 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:36:43 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:36:43 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:36:43 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:36:43 --> Final output sent to browser
DEBUG - 2025-03-28 22:36:43 --> Total execution time: 0.0398
INFO - 2025-03-28 22:49:27 --> Config Class Initialized
INFO - 2025-03-28 22:49:27 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:49:27 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:49:27 --> Utf8 Class Initialized
INFO - 2025-03-28 22:49:27 --> URI Class Initialized
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:49:27 --> Router Class Initialized
INFO - 2025-03-28 22:49:27 --> Output Class Initialized
INFO - 2025-03-28 22:49:27 --> Security Class Initialized
DEBUG - 2025-03-28 22:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:49:27 --> Input Class Initialized
INFO - 2025-03-28 22:49:27 --> Language Class Initialized
INFO - 2025-03-28 22:49:27 --> Language Class Initialized
INFO - 2025-03-28 22:49:27 --> Config Class Initialized
INFO - 2025-03-28 22:49:27 --> Loader Class Initialized
INFO - 2025-03-28 22:49:27 --> Helper loaded: url_helper
INFO - 2025-03-28 22:49:27 --> Helper loaded: file_helper
INFO - 2025-03-28 22:49:27 --> Helper loaded: html_helper
INFO - 2025-03-28 22:49:27 --> Helper loaded: form_helper
INFO - 2025-03-28 22:49:27 --> Helper loaded: text_helper
INFO - 2025-03-28 22:49:27 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:49:27 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:49:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:49:27 --> Database Driver Class Initialized
INFO - 2025-03-28 22:49:27 --> Email Class Initialized
INFO - 2025-03-28 22:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:49:27 --> Form Validation Class Initialized
INFO - 2025-03-28 22:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:49:27 --> Pagination Class Initialized
INFO - 2025-03-28 22:49:27 --> Controller Class Initialized
DEBUG - 2025-03-28 22:49:27 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:49:27 --> Model Class Initialized
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:49:27 --> Model Class Initialized
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:49:27 --> Model Class Initialized
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:49:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:49:27 --> Model Class Initialized
ERROR - 2025-03-28 22:49:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:49:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:49:27 --> Final output sent to browser
DEBUG - 2025-03-28 22:49:27 --> Total execution time: 0.1434
INFO - 2025-03-28 22:49:28 --> Config Class Initialized
INFO - 2025-03-28 22:49:28 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:49:28 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:49:28 --> Utf8 Class Initialized
INFO - 2025-03-28 22:49:28 --> URI Class Initialized
DEBUG - 2025-03-28 22:49:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:49:28 --> Router Class Initialized
INFO - 2025-03-28 22:49:28 --> Output Class Initialized
INFO - 2025-03-28 22:49:28 --> Security Class Initialized
DEBUG - 2025-03-28 22:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:49:28 --> Input Class Initialized
INFO - 2025-03-28 22:49:28 --> Language Class Initialized
INFO - 2025-03-28 22:49:28 --> Language Class Initialized
INFO - 2025-03-28 22:49:28 --> Config Class Initialized
INFO - 2025-03-28 22:49:28 --> Loader Class Initialized
INFO - 2025-03-28 22:49:28 --> Helper loaded: url_helper
INFO - 2025-03-28 22:49:28 --> Helper loaded: file_helper
INFO - 2025-03-28 22:49:28 --> Helper loaded: html_helper
INFO - 2025-03-28 22:49:28 --> Helper loaded: form_helper
INFO - 2025-03-28 22:49:28 --> Helper loaded: text_helper
INFO - 2025-03-28 22:49:28 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:49:28 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:49:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:49:28 --> Database Driver Class Initialized
INFO - 2025-03-28 22:49:28 --> Email Class Initialized
INFO - 2025-03-28 22:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:49:28 --> Form Validation Class Initialized
INFO - 2025-03-28 22:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:49:28 --> Pagination Class Initialized
INFO - 2025-03-28 22:49:28 --> Controller Class Initialized
DEBUG - 2025-03-28 22:49:28 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:49:28 --> Model Class Initialized
DEBUG - 2025-03-28 22:49:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:49:28 --> Model Class Initialized
DEBUG - 2025-03-28 22:49:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:49:28 --> Model Class Initialized
ERROR - 2025-03-28 22:49:28 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`image`, `c`.`supplier_price`, `c`.`supplier_id`, `m`.`supplier_name`, `pc`.`ca' at line 1 /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-28 22:49:33 --> Config Class Initialized
INFO - 2025-03-28 22:49:33 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:49:33 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:49:33 --> Utf8 Class Initialized
INFO - 2025-03-28 22:49:33 --> URI Class Initialized
DEBUG - 2025-03-28 22:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:49:33 --> Router Class Initialized
INFO - 2025-03-28 22:49:33 --> Output Class Initialized
INFO - 2025-03-28 22:49:33 --> Security Class Initialized
DEBUG - 2025-03-28 22:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:49:33 --> Input Class Initialized
INFO - 2025-03-28 22:49:33 --> Language Class Initialized
INFO - 2025-03-28 22:49:33 --> Language Class Initialized
INFO - 2025-03-28 22:49:33 --> Config Class Initialized
INFO - 2025-03-28 22:49:33 --> Loader Class Initialized
INFO - 2025-03-28 22:49:33 --> Helper loaded: url_helper
INFO - 2025-03-28 22:49:33 --> Helper loaded: file_helper
INFO - 2025-03-28 22:49:33 --> Helper loaded: html_helper
INFO - 2025-03-28 22:49:33 --> Helper loaded: form_helper
INFO - 2025-03-28 22:49:33 --> Helper loaded: text_helper
INFO - 2025-03-28 22:49:33 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:49:33 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:49:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:49:33 --> Database Driver Class Initialized
INFO - 2025-03-28 22:49:33 --> Email Class Initialized
INFO - 2025-03-28 22:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:49:33 --> Form Validation Class Initialized
INFO - 2025-03-28 22:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:49:33 --> Pagination Class Initialized
INFO - 2025-03-28 22:49:33 --> Controller Class Initialized
DEBUG - 2025-03-28 22:49:33 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:49:33 --> Model Class Initialized
DEBUG - 2025-03-28 22:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:49:33 --> Model Class Initialized
DEBUG - 2025-03-28 22:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:49:33 --> Model Class Initialized
ERROR - 2025-03-28 22:49:33 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`image`, `c`.`supplier_price`, `c`.`supplier_id`, `m`.`supplier_name`, `pc`.`ca' at line 1 /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-28 22:50:00 --> Config Class Initialized
INFO - 2025-03-28 22:50:00 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:50:00 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:50:00 --> Utf8 Class Initialized
INFO - 2025-03-28 22:50:00 --> URI Class Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:50:00 --> Router Class Initialized
INFO - 2025-03-28 22:50:00 --> Output Class Initialized
INFO - 2025-03-28 22:50:00 --> Security Class Initialized
DEBUG - 2025-03-28 22:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:50:00 --> Input Class Initialized
INFO - 2025-03-28 22:50:00 --> Language Class Initialized
INFO - 2025-03-28 22:50:00 --> Language Class Initialized
INFO - 2025-03-28 22:50:00 --> Config Class Initialized
INFO - 2025-03-28 22:50:00 --> Loader Class Initialized
INFO - 2025-03-28 22:50:00 --> Helper loaded: url_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: file_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: html_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: form_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: text_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:50:00 --> Database Driver Class Initialized
INFO - 2025-03-28 22:50:00 --> Email Class Initialized
INFO - 2025-03-28 22:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:50:00 --> Form Validation Class Initialized
INFO - 2025-03-28 22:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:50:00 --> Pagination Class Initialized
INFO - 2025-03-28 22:50:00 --> Controller Class Initialized
DEBUG - 2025-03-28 22:50:00 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:50:00 --> Model Class Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:50:00 --> Model Class Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:50:00 --> Model Class Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:50:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:50:00 --> Model Class Initialized
ERROR - 2025-03-28 22:50:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:50:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:50:00 --> Final output sent to browser
DEBUG - 2025-03-28 22:50:00 --> Total execution time: 0.1632
INFO - 2025-03-28 22:50:00 --> Config Class Initialized
INFO - 2025-03-28 22:50:00 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:50:00 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:50:00 --> Utf8 Class Initialized
INFO - 2025-03-28 22:50:00 --> URI Class Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:50:00 --> Router Class Initialized
INFO - 2025-03-28 22:50:00 --> Output Class Initialized
INFO - 2025-03-28 22:50:00 --> Security Class Initialized
DEBUG - 2025-03-28 22:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:50:00 --> Input Class Initialized
INFO - 2025-03-28 22:50:00 --> Language Class Initialized
INFO - 2025-03-28 22:50:00 --> Language Class Initialized
INFO - 2025-03-28 22:50:00 --> Config Class Initialized
INFO - 2025-03-28 22:50:00 --> Loader Class Initialized
INFO - 2025-03-28 22:50:00 --> Helper loaded: url_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: file_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: html_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: form_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: text_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:50:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:50:00 --> Database Driver Class Initialized
INFO - 2025-03-28 22:50:00 --> Email Class Initialized
INFO - 2025-03-28 22:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:50:00 --> Form Validation Class Initialized
INFO - 2025-03-28 22:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:50:00 --> Pagination Class Initialized
INFO - 2025-03-28 22:50:00 --> Controller Class Initialized
DEBUG - 2025-03-28 22:50:00 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:50:00 --> Model Class Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:50:00 --> Model Class Initialized
DEBUG - 2025-03-28 22:50:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:50:00 --> Model Class Initialized
ERROR - 2025-03-28 22:50:00 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`image`, `c`.`supplier_price`, `c`.`supplier_id`, `m`.`supplier_name`, `pc`.`ca' at line 1 /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-28 22:52:08 --> Config Class Initialized
INFO - 2025-03-28 22:52:08 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:52:08 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:52:08 --> Utf8 Class Initialized
INFO - 2025-03-28 22:52:08 --> URI Class Initialized
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:52:08 --> Router Class Initialized
INFO - 2025-03-28 22:52:08 --> Output Class Initialized
INFO - 2025-03-28 22:52:08 --> Security Class Initialized
DEBUG - 2025-03-28 22:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:52:08 --> Input Class Initialized
INFO - 2025-03-28 22:52:08 --> Language Class Initialized
INFO - 2025-03-28 22:52:08 --> Language Class Initialized
INFO - 2025-03-28 22:52:08 --> Config Class Initialized
INFO - 2025-03-28 22:52:08 --> Loader Class Initialized
INFO - 2025-03-28 22:52:08 --> Helper loaded: url_helper
INFO - 2025-03-28 22:52:08 --> Helper loaded: file_helper
INFO - 2025-03-28 22:52:08 --> Helper loaded: html_helper
INFO - 2025-03-28 22:52:08 --> Helper loaded: form_helper
INFO - 2025-03-28 22:52:08 --> Helper loaded: text_helper
INFO - 2025-03-28 22:52:08 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:52:08 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:52:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:52:08 --> Database Driver Class Initialized
INFO - 2025-03-28 22:52:08 --> Email Class Initialized
INFO - 2025-03-28 22:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:52:08 --> Form Validation Class Initialized
INFO - 2025-03-28 22:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:52:08 --> Pagination Class Initialized
INFO - 2025-03-28 22:52:08 --> Controller Class Initialized
DEBUG - 2025-03-28 22:52:08 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:52:08 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:52:08 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:52:08 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:52:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:52:08 --> Model Class Initialized
ERROR - 2025-03-28 22:52:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:52:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:52:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:52:08 --> Final output sent to browser
DEBUG - 2025-03-28 22:52:08 --> Total execution time: 0.1414
INFO - 2025-03-28 22:52:09 --> Config Class Initialized
INFO - 2025-03-28 22:52:09 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:52:09 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:52:09 --> Utf8 Class Initialized
INFO - 2025-03-28 22:52:09 --> URI Class Initialized
DEBUG - 2025-03-28 22:52:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:52:09 --> Router Class Initialized
INFO - 2025-03-28 22:52:09 --> Output Class Initialized
INFO - 2025-03-28 22:52:09 --> Security Class Initialized
DEBUG - 2025-03-28 22:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:52:09 --> Input Class Initialized
INFO - 2025-03-28 22:52:09 --> Language Class Initialized
INFO - 2025-03-28 22:52:09 --> Language Class Initialized
INFO - 2025-03-28 22:52:09 --> Config Class Initialized
INFO - 2025-03-28 22:52:09 --> Loader Class Initialized
INFO - 2025-03-28 22:52:09 --> Helper loaded: url_helper
INFO - 2025-03-28 22:52:09 --> Helper loaded: file_helper
INFO - 2025-03-28 22:52:09 --> Helper loaded: html_helper
INFO - 2025-03-28 22:52:09 --> Helper loaded: form_helper
INFO - 2025-03-28 22:52:09 --> Helper loaded: text_helper
INFO - 2025-03-28 22:52:09 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:52:09 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:52:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:52:09 --> Database Driver Class Initialized
INFO - 2025-03-28 22:52:09 --> Email Class Initialized
INFO - 2025-03-28 22:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:52:09 --> Form Validation Class Initialized
INFO - 2025-03-28 22:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:52:09 --> Pagination Class Initialized
INFO - 2025-03-28 22:52:09 --> Controller Class Initialized
DEBUG - 2025-03-28 22:52:09 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:52:09 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:52:09 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:52:09 --> Model Class Initialized
ERROR - 2025-03-28 22:52:09 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`image`, `c`.`supplier_price`, `c`.`supplier_id`, `m`.`supplier_name`, `pc`.`ca' at line 1 /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-28 22:52:17 --> Config Class Initialized
INFO - 2025-03-28 22:52:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:52:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:52:17 --> Utf8 Class Initialized
INFO - 2025-03-28 22:52:17 --> URI Class Initialized
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:52:17 --> Router Class Initialized
INFO - 2025-03-28 22:52:17 --> Output Class Initialized
INFO - 2025-03-28 22:52:17 --> Security Class Initialized
DEBUG - 2025-03-28 22:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:52:17 --> Input Class Initialized
INFO - 2025-03-28 22:52:17 --> Language Class Initialized
INFO - 2025-03-28 22:52:17 --> Language Class Initialized
INFO - 2025-03-28 22:52:17 --> Config Class Initialized
INFO - 2025-03-28 22:52:17 --> Loader Class Initialized
INFO - 2025-03-28 22:52:17 --> Helper loaded: url_helper
INFO - 2025-03-28 22:52:17 --> Helper loaded: file_helper
INFO - 2025-03-28 22:52:17 --> Helper loaded: html_helper
INFO - 2025-03-28 22:52:17 --> Helper loaded: form_helper
INFO - 2025-03-28 22:52:17 --> Helper loaded: text_helper
INFO - 2025-03-28 22:52:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:52:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:52:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:52:17 --> Database Driver Class Initialized
INFO - 2025-03-28 22:52:17 --> Email Class Initialized
INFO - 2025-03-28 22:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:52:17 --> Form Validation Class Initialized
INFO - 2025-03-28 22:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:52:17 --> Pagination Class Initialized
INFO - 2025-03-28 22:52:17 --> Controller Class Initialized
DEBUG - 2025-03-28 22:52:17 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:52:17 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:52:17 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:52:17 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:52:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:52:17 --> Model Class Initialized
ERROR - 2025-03-28 22:52:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:52:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:52:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:52:17 --> Final output sent to browser
DEBUG - 2025-03-28 22:52:17 --> Total execution time: 0.1049
INFO - 2025-03-28 22:52:18 --> Config Class Initialized
INFO - 2025-03-28 22:52:18 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:52:18 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:52:18 --> Utf8 Class Initialized
INFO - 2025-03-28 22:52:18 --> URI Class Initialized
DEBUG - 2025-03-28 22:52:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:52:18 --> Router Class Initialized
INFO - 2025-03-28 22:52:18 --> Output Class Initialized
INFO - 2025-03-28 22:52:18 --> Security Class Initialized
DEBUG - 2025-03-28 22:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:52:18 --> Input Class Initialized
INFO - 2025-03-28 22:52:18 --> Language Class Initialized
INFO - 2025-03-28 22:52:18 --> Language Class Initialized
INFO - 2025-03-28 22:52:18 --> Config Class Initialized
INFO - 2025-03-28 22:52:18 --> Loader Class Initialized
INFO - 2025-03-28 22:52:18 --> Helper loaded: url_helper
INFO - 2025-03-28 22:52:18 --> Helper loaded: file_helper
INFO - 2025-03-28 22:52:18 --> Helper loaded: html_helper
INFO - 2025-03-28 22:52:18 --> Helper loaded: form_helper
INFO - 2025-03-28 22:52:18 --> Helper loaded: text_helper
INFO - 2025-03-28 22:52:18 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:52:18 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:52:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:52:18 --> Database Driver Class Initialized
INFO - 2025-03-28 22:52:18 --> Email Class Initialized
INFO - 2025-03-28 22:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:52:18 --> Form Validation Class Initialized
INFO - 2025-03-28 22:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:52:18 --> Pagination Class Initialized
INFO - 2025-03-28 22:52:18 --> Controller Class Initialized
DEBUG - 2025-03-28 22:52:18 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:52:18 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:52:18 --> Model Class Initialized
DEBUG - 2025-03-28 22:52:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:52:18 --> Model Class Initialized
ERROR - 2025-03-28 22:52:18 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`image`, `c`.`supplier_price`, `c`.`supplier_id`, `m`.`supplier_name`, `pc`.`ca' at line 1 /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-28 22:57:03 --> Config Class Initialized
INFO - 2025-03-28 22:57:03 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:03 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:03 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:03 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:03 --> Router Class Initialized
INFO - 2025-03-28 22:57:03 --> Output Class Initialized
INFO - 2025-03-28 22:57:03 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:03 --> Input Class Initialized
INFO - 2025-03-28 22:57:03 --> Language Class Initialized
INFO - 2025-03-28 22:57:03 --> Language Class Initialized
INFO - 2025-03-28 22:57:03 --> Config Class Initialized
INFO - 2025-03-28 22:57:03 --> Loader Class Initialized
INFO - 2025-03-28 22:57:03 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:03 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:03 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:03 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:03 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:03 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:03 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:03 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:03 --> Email Class Initialized
INFO - 2025-03-28 22:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:03 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:03 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:03 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:03 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:03 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:03 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:03 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:57:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:57:03 --> Model Class Initialized
ERROR - 2025-03-28 22:57:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:57:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:57:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:57:03 --> Final output sent to browser
DEBUG - 2025-03-28 22:57:03 --> Total execution time: 0.1512
INFO - 2025-03-28 22:57:04 --> Config Class Initialized
INFO - 2025-03-28 22:57:04 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:04 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:04 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:04 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:04 --> Router Class Initialized
INFO - 2025-03-28 22:57:04 --> Output Class Initialized
INFO - 2025-03-28 22:57:04 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:04 --> Input Class Initialized
INFO - 2025-03-28 22:57:04 --> Language Class Initialized
INFO - 2025-03-28 22:57:04 --> Language Class Initialized
INFO - 2025-03-28 22:57:04 --> Config Class Initialized
INFO - 2025-03-28 22:57:04 --> Loader Class Initialized
INFO - 2025-03-28 22:57:04 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:04 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:04 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:04 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:04 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:04 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:04 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:04 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:04 --> Email Class Initialized
INFO - 2025-03-28 22:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:04 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:04 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:04 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:04 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:04 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:04 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:04 --> Model Class Initialized
ERROR - 2025-03-28 22:57:04 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:57:04 --> Final output sent to browser
DEBUG - 2025-03-28 22:57:04 --> Total execution time: 0.0072
INFO - 2025-03-28 22:57:33 --> Config Class Initialized
INFO - 2025-03-28 22:57:33 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:33 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:33 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:33 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:33 --> Router Class Initialized
INFO - 2025-03-28 22:57:33 --> Output Class Initialized
INFO - 2025-03-28 22:57:33 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:33 --> Input Class Initialized
INFO - 2025-03-28 22:57:33 --> Language Class Initialized
INFO - 2025-03-28 22:57:33 --> Language Class Initialized
INFO - 2025-03-28 22:57:33 --> Config Class Initialized
INFO - 2025-03-28 22:57:33 --> Loader Class Initialized
INFO - 2025-03-28 22:57:33 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:33 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:33 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:33 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:33 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:33 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:33 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:33 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:33 --> Email Class Initialized
INFO - 2025-03-28 22:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:33 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:33 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:33 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:33 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:33 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:33 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:33 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:57:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:57:33 --> Model Class Initialized
ERROR - 2025-03-28 22:57:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:57:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:57:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:57:33 --> Final output sent to browser
DEBUG - 2025-03-28 22:57:33 --> Total execution time: 0.1463
INFO - 2025-03-28 22:57:34 --> Config Class Initialized
INFO - 2025-03-28 22:57:34 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:34 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:34 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:34 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:34 --> Router Class Initialized
INFO - 2025-03-28 22:57:34 --> Output Class Initialized
INFO - 2025-03-28 22:57:34 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:34 --> Input Class Initialized
INFO - 2025-03-28 22:57:34 --> Language Class Initialized
INFO - 2025-03-28 22:57:34 --> Language Class Initialized
INFO - 2025-03-28 22:57:34 --> Config Class Initialized
INFO - 2025-03-28 22:57:34 --> Loader Class Initialized
INFO - 2025-03-28 22:57:34 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:34 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:34 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:34 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:34 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:34 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:34 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:34 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:34 --> Email Class Initialized
INFO - 2025-03-28 22:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:34 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:34 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:34 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:34 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:34 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:34 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:34 --> Model Class Initialized
ERROR - 2025-03-28 22:57:34 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`image`, `c`.`supplier_price`, `c`.`supplier_id`, `m`.`supplier_name`, `pc`.`ca' at line 1 /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-28 22:57:41 --> Config Class Initialized
INFO - 2025-03-28 22:57:41 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:41 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:41 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:41 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:41 --> Router Class Initialized
INFO - 2025-03-28 22:57:41 --> Output Class Initialized
INFO - 2025-03-28 22:57:41 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:41 --> Input Class Initialized
INFO - 2025-03-28 22:57:41 --> Language Class Initialized
INFO - 2025-03-28 22:57:41 --> Language Class Initialized
INFO - 2025-03-28 22:57:41 --> Config Class Initialized
INFO - 2025-03-28 22:57:41 --> Loader Class Initialized
INFO - 2025-03-28 22:57:41 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:41 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:41 --> Email Class Initialized
INFO - 2025-03-28 22:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:41 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:41 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:41 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:41 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:41 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:41 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:41 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:57:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:57:41 --> Model Class Initialized
ERROR - 2025-03-28 22:57:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:57:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:57:41 --> Final output sent to browser
DEBUG - 2025-03-28 22:57:41 --> Total execution time: 0.0945
INFO - 2025-03-28 22:57:41 --> Config Class Initialized
INFO - 2025-03-28 22:57:41 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:41 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:41 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:41 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:41 --> Router Class Initialized
INFO - 2025-03-28 22:57:41 --> Output Class Initialized
INFO - 2025-03-28 22:57:41 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:41 --> Input Class Initialized
INFO - 2025-03-28 22:57:41 --> Language Class Initialized
INFO - 2025-03-28 22:57:41 --> Language Class Initialized
INFO - 2025-03-28 22:57:41 --> Config Class Initialized
INFO - 2025-03-28 22:57:41 --> Loader Class Initialized
INFO - 2025-03-28 22:57:41 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:41 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:41 --> Email Class Initialized
INFO - 2025-03-28 22:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:41 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:41 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:41 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:41 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:41 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:41 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:41 --> Model Class Initialized
ERROR - 2025-03-28 22:57:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:57:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:57:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:57:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:57:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-28 22:57:41 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:57:41 --> Final output sent to browser
DEBUG - 2025-03-28 22:57:41 --> Total execution time: 0.0426
INFO - 2025-03-28 22:57:53 --> Config Class Initialized
INFO - 2025-03-28 22:57:53 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:53 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:53 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:53 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:53 --> Router Class Initialized
INFO - 2025-03-28 22:57:53 --> Output Class Initialized
INFO - 2025-03-28 22:57:53 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:53 --> Input Class Initialized
INFO - 2025-03-28 22:57:53 --> Language Class Initialized
INFO - 2025-03-28 22:57:53 --> Language Class Initialized
INFO - 2025-03-28 22:57:53 --> Config Class Initialized
INFO - 2025-03-28 22:57:53 --> Loader Class Initialized
INFO - 2025-03-28 22:57:53 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:53 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:53 --> Email Class Initialized
INFO - 2025-03-28 22:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:53 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:53 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:53 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:53 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:53 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:53 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:53 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:57:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:57:53 --> Model Class Initialized
ERROR - 2025-03-28 22:57:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:57:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:57:53 --> Final output sent to browser
DEBUG - 2025-03-28 22:57:53 --> Total execution time: 0.1297
INFO - 2025-03-28 22:57:53 --> Config Class Initialized
INFO - 2025-03-28 22:57:53 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:57:53 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:57:53 --> Utf8 Class Initialized
INFO - 2025-03-28 22:57:53 --> URI Class Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:57:53 --> Router Class Initialized
INFO - 2025-03-28 22:57:53 --> Output Class Initialized
INFO - 2025-03-28 22:57:53 --> Security Class Initialized
DEBUG - 2025-03-28 22:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:57:53 --> Input Class Initialized
INFO - 2025-03-28 22:57:53 --> Language Class Initialized
INFO - 2025-03-28 22:57:53 --> Language Class Initialized
INFO - 2025-03-28 22:57:53 --> Config Class Initialized
INFO - 2025-03-28 22:57:53 --> Loader Class Initialized
INFO - 2025-03-28 22:57:53 --> Helper loaded: url_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: file_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: html_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: form_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: text_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:57:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:57:53 --> Database Driver Class Initialized
INFO - 2025-03-28 22:57:53 --> Email Class Initialized
INFO - 2025-03-28 22:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:57:53 --> Form Validation Class Initialized
INFO - 2025-03-28 22:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:57:53 --> Pagination Class Initialized
INFO - 2025-03-28 22:57:53 --> Controller Class Initialized
DEBUG - 2025-03-28 22:57:53 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:57:53 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:57:53 --> Model Class Initialized
DEBUG - 2025-03-28 22:57:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:57:53 --> Model Class Initialized
ERROR - 2025-03-28 22:57:53 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:57:53 --> Final output sent to browser
DEBUG - 2025-03-28 22:57:53 --> Total execution time: 0.0066
INFO - 2025-03-28 22:58:06 --> Config Class Initialized
INFO - 2025-03-28 22:58:06 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:58:06 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:58:06 --> Utf8 Class Initialized
INFO - 2025-03-28 22:58:06 --> URI Class Initialized
DEBUG - 2025-03-28 22:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:58:06 --> Router Class Initialized
INFO - 2025-03-28 22:58:06 --> Output Class Initialized
INFO - 2025-03-28 22:58:06 --> Security Class Initialized
DEBUG - 2025-03-28 22:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:58:06 --> Input Class Initialized
INFO - 2025-03-28 22:58:06 --> Language Class Initialized
INFO - 2025-03-28 22:58:06 --> Language Class Initialized
INFO - 2025-03-28 22:58:06 --> Config Class Initialized
INFO - 2025-03-28 22:58:06 --> Loader Class Initialized
INFO - 2025-03-28 22:58:06 --> Helper loaded: url_helper
INFO - 2025-03-28 22:58:06 --> Helper loaded: file_helper
INFO - 2025-03-28 22:58:06 --> Helper loaded: html_helper
INFO - 2025-03-28 22:58:06 --> Helper loaded: form_helper
INFO - 2025-03-28 22:58:06 --> Helper loaded: text_helper
INFO - 2025-03-28 22:58:06 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:58:06 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:58:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:58:06 --> Database Driver Class Initialized
INFO - 2025-03-28 22:58:06 --> Email Class Initialized
INFO - 2025-03-28 22:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:58:06 --> Form Validation Class Initialized
INFO - 2025-03-28 22:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:58:06 --> Pagination Class Initialized
INFO - 2025-03-28 22:58:06 --> Controller Class Initialized
DEBUG - 2025-03-28 22:58:06 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:58:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:58:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:58:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:58:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:58:06 --> Model Class Initialized
ERROR - 2025-03-28 22:58:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:58:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:58:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:58:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:58:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:58:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-28 22:58:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:58:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:58:07 --> Final output sent to browser
DEBUG - 2025-03-28 22:58:07 --> Total execution time: 0.1540
INFO - 2025-03-28 22:58:12 --> Config Class Initialized
INFO - 2025-03-28 22:58:12 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:58:12 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:58:12 --> Utf8 Class Initialized
INFO - 2025-03-28 22:58:12 --> URI Class Initialized
DEBUG - 2025-03-28 22:58:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:58:12 --> Router Class Initialized
INFO - 2025-03-28 22:58:12 --> Output Class Initialized
INFO - 2025-03-28 22:58:12 --> Security Class Initialized
DEBUG - 2025-03-28 22:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:58:12 --> Input Class Initialized
INFO - 2025-03-28 22:58:12 --> Language Class Initialized
INFO - 2025-03-28 22:58:12 --> Language Class Initialized
INFO - 2025-03-28 22:58:12 --> Config Class Initialized
INFO - 2025-03-28 22:58:12 --> Loader Class Initialized
INFO - 2025-03-28 22:58:12 --> Helper loaded: url_helper
INFO - 2025-03-28 22:58:12 --> Helper loaded: file_helper
INFO - 2025-03-28 22:58:12 --> Helper loaded: html_helper
INFO - 2025-03-28 22:58:12 --> Helper loaded: form_helper
INFO - 2025-03-28 22:58:12 --> Helper loaded: text_helper
INFO - 2025-03-28 22:58:12 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:58:12 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:58:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:58:12 --> Database Driver Class Initialized
INFO - 2025-03-28 22:58:12 --> Email Class Initialized
INFO - 2025-03-28 22:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:58:12 --> Form Validation Class Initialized
INFO - 2025-03-28 22:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:58:12 --> Pagination Class Initialized
INFO - 2025-03-28 22:58:12 --> Controller Class Initialized
DEBUG - 2025-03-28 22:58:12 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:58:12 --> Model Class Initialized
DEBUG - 2025-03-28 22:58:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:58:12 --> Model Class Initialized
DEBUG - 2025-03-28 22:58:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:58:12 --> Model Class Initialized
INFO - 2025-03-28 22:58:12 --> Final output sent to browser
DEBUG - 2025-03-28 22:58:12 --> Total execution time: 0.0104
INFO - 2025-03-28 22:58:17 --> Config Class Initialized
INFO - 2025-03-28 22:58:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:58:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:58:17 --> Utf8 Class Initialized
INFO - 2025-03-28 22:58:17 --> URI Class Initialized
DEBUG - 2025-03-28 22:58:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:58:17 --> Router Class Initialized
INFO - 2025-03-28 22:58:17 --> Output Class Initialized
INFO - 2025-03-28 22:58:17 --> Security Class Initialized
DEBUG - 2025-03-28 22:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:58:17 --> Input Class Initialized
INFO - 2025-03-28 22:58:17 --> Language Class Initialized
INFO - 2025-03-28 22:58:17 --> Language Class Initialized
INFO - 2025-03-28 22:58:17 --> Config Class Initialized
INFO - 2025-03-28 22:58:17 --> Loader Class Initialized
INFO - 2025-03-28 22:58:17 --> Helper loaded: url_helper
INFO - 2025-03-28 22:58:17 --> Helper loaded: file_helper
INFO - 2025-03-28 22:58:17 --> Helper loaded: html_helper
INFO - 2025-03-28 22:58:17 --> Helper loaded: form_helper
INFO - 2025-03-28 22:58:17 --> Helper loaded: text_helper
INFO - 2025-03-28 22:58:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:58:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:58:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:58:17 --> Database Driver Class Initialized
INFO - 2025-03-28 22:58:17 --> Email Class Initialized
INFO - 2025-03-28 22:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:58:17 --> Form Validation Class Initialized
INFO - 2025-03-28 22:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:58:17 --> Pagination Class Initialized
INFO - 2025-03-28 22:58:17 --> Controller Class Initialized
DEBUG - 2025-03-28 22:58:17 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:58:17 --> Model Class Initialized
DEBUG - 2025-03-28 22:58:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:58:17 --> Model Class Initialized
DEBUG - 2025-03-28 22:58:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:58:17 --> Model Class Initialized
INFO - 2025-03-28 22:58:17 --> Final output sent to browser
DEBUG - 2025-03-28 22:58:17 --> Total execution time: 0.0094
INFO - 2025-03-28 22:59:06 --> Config Class Initialized
INFO - 2025-03-28 22:59:06 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:59:06 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:59:06 --> Utf8 Class Initialized
INFO - 2025-03-28 22:59:06 --> URI Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:59:06 --> Router Class Initialized
INFO - 2025-03-28 22:59:06 --> Output Class Initialized
INFO - 2025-03-28 22:59:06 --> Security Class Initialized
DEBUG - 2025-03-28 22:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:59:06 --> Input Class Initialized
INFO - 2025-03-28 22:59:06 --> Language Class Initialized
INFO - 2025-03-28 22:59:06 --> Language Class Initialized
INFO - 2025-03-28 22:59:06 --> Config Class Initialized
INFO - 2025-03-28 22:59:06 --> Loader Class Initialized
INFO - 2025-03-28 22:59:06 --> Helper loaded: url_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: file_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: html_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: form_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: text_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:59:06 --> Database Driver Class Initialized
INFO - 2025-03-28 22:59:06 --> Email Class Initialized
INFO - 2025-03-28 22:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:59:06 --> Form Validation Class Initialized
INFO - 2025-03-28 22:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:59:06 --> Pagination Class Initialized
INFO - 2025-03-28 22:59:06 --> Controller Class Initialized
DEBUG - 2025-03-28 22:59:06 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
INFO - 2025-03-28 22:59:06 --> Upload Class Initialized
INFO - 2025-03-28 22:59:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 22:59:06 --> Config Class Initialized
INFO - 2025-03-28 22:59:06 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:59:06 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:59:06 --> Utf8 Class Initialized
INFO - 2025-03-28 22:59:06 --> URI Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:59:06 --> Router Class Initialized
INFO - 2025-03-28 22:59:06 --> Output Class Initialized
INFO - 2025-03-28 22:59:06 --> Security Class Initialized
DEBUG - 2025-03-28 22:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:59:06 --> Input Class Initialized
INFO - 2025-03-28 22:59:06 --> Language Class Initialized
INFO - 2025-03-28 22:59:06 --> Language Class Initialized
INFO - 2025-03-28 22:59:06 --> Config Class Initialized
INFO - 2025-03-28 22:59:06 --> Loader Class Initialized
INFO - 2025-03-28 22:59:06 --> Helper loaded: url_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: file_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: html_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: form_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: text_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:59:06 --> Database Driver Class Initialized
INFO - 2025-03-28 22:59:06 --> Email Class Initialized
INFO - 2025-03-28 22:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:59:06 --> Form Validation Class Initialized
INFO - 2025-03-28 22:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:59:06 --> Pagination Class Initialized
INFO - 2025-03-28 22:59:06 --> Controller Class Initialized
DEBUG - 2025-03-28 22:59:06 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:59:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
ERROR - 2025-03-28 22:59:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:59:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:59:06 --> Final output sent to browser
DEBUG - 2025-03-28 22:59:06 --> Total execution time: 0.0814
INFO - 2025-03-28 22:59:06 --> Config Class Initialized
INFO - 2025-03-28 22:59:06 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:59:06 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:59:06 --> Utf8 Class Initialized
INFO - 2025-03-28 22:59:06 --> URI Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 22:59:06 --> Router Class Initialized
INFO - 2025-03-28 22:59:06 --> Output Class Initialized
INFO - 2025-03-28 22:59:06 --> Security Class Initialized
DEBUG - 2025-03-28 22:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:59:06 --> Input Class Initialized
INFO - 2025-03-28 22:59:06 --> Language Class Initialized
INFO - 2025-03-28 22:59:06 --> Language Class Initialized
INFO - 2025-03-28 22:59:06 --> Config Class Initialized
INFO - 2025-03-28 22:59:06 --> Loader Class Initialized
INFO - 2025-03-28 22:59:06 --> Helper loaded: url_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: file_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: html_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: form_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: text_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:59:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:59:06 --> Database Driver Class Initialized
INFO - 2025-03-28 22:59:06 --> Email Class Initialized
INFO - 2025-03-28 22:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:59:06 --> Form Validation Class Initialized
INFO - 2025-03-28 22:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:59:06 --> Pagination Class Initialized
INFO - 2025-03-28 22:59:06 --> Controller Class Initialized
DEBUG - 2025-03-28 22:59:06 --> Product MX_Controller Initialized
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:59:06 --> Model Class Initialized
ERROR - 2025-03-28 22:59:06 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 22:59:06 --> Final output sent to browser
DEBUG - 2025-03-28 22:59:06 --> Total execution time: 0.0096
INFO - 2025-03-28 22:59:28 --> Config Class Initialized
INFO - 2025-03-28 22:59:28 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:59:28 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:59:28 --> Utf8 Class Initialized
INFO - 2025-03-28 22:59:28 --> URI Class Initialized
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-28 22:59:28 --> Router Class Initialized
INFO - 2025-03-28 22:59:28 --> Output Class Initialized
INFO - 2025-03-28 22:59:28 --> Security Class Initialized
DEBUG - 2025-03-28 22:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:59:28 --> Input Class Initialized
INFO - 2025-03-28 22:59:28 --> Language Class Initialized
INFO - 2025-03-28 22:59:28 --> Language Class Initialized
INFO - 2025-03-28 22:59:28 --> Config Class Initialized
INFO - 2025-03-28 22:59:28 --> Loader Class Initialized
INFO - 2025-03-28 22:59:28 --> Helper loaded: url_helper
INFO - 2025-03-28 22:59:28 --> Helper loaded: file_helper
INFO - 2025-03-28 22:59:28 --> Helper loaded: html_helper
INFO - 2025-03-28 22:59:28 --> Helper loaded: form_helper
INFO - 2025-03-28 22:59:28 --> Helper loaded: text_helper
INFO - 2025-03-28 22:59:28 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:59:28 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:59:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:59:28 --> Database Driver Class Initialized
INFO - 2025-03-28 22:59:28 --> Email Class Initialized
INFO - 2025-03-28 22:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:59:28 --> Form Validation Class Initialized
INFO - 2025-03-28 22:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:59:28 --> Pagination Class Initialized
INFO - 2025-03-28 22:59:28 --> Controller Class Initialized
DEBUG - 2025-03-28 22:59:28 --> Supplier MX_Controller Initialized
INFO - 2025-03-28 22:59:28 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:59:28 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:59:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:59:28 --> Model Class Initialized
ERROR - 2025-03-28 22:59:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:59:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:59:28 --> Final output sent to browser
DEBUG - 2025-03-28 22:59:28 --> Total execution time: 0.1403
INFO - 2025-03-28 22:59:29 --> Config Class Initialized
INFO - 2025-03-28 22:59:29 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:59:29 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:59:29 --> Utf8 Class Initialized
INFO - 2025-03-28 22:59:29 --> URI Class Initialized
DEBUG - 2025-03-28 22:59:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-28 22:59:29 --> Router Class Initialized
INFO - 2025-03-28 22:59:29 --> Output Class Initialized
INFO - 2025-03-28 22:59:29 --> Security Class Initialized
DEBUG - 2025-03-28 22:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:59:29 --> Input Class Initialized
INFO - 2025-03-28 22:59:29 --> Language Class Initialized
INFO - 2025-03-28 22:59:29 --> Language Class Initialized
INFO - 2025-03-28 22:59:29 --> Config Class Initialized
INFO - 2025-03-28 22:59:29 --> Loader Class Initialized
INFO - 2025-03-28 22:59:29 --> Helper loaded: url_helper
INFO - 2025-03-28 22:59:29 --> Helper loaded: file_helper
INFO - 2025-03-28 22:59:29 --> Helper loaded: html_helper
INFO - 2025-03-28 22:59:29 --> Helper loaded: form_helper
INFO - 2025-03-28 22:59:29 --> Helper loaded: text_helper
INFO - 2025-03-28 22:59:29 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:59:29 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:59:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:59:29 --> Database Driver Class Initialized
INFO - 2025-03-28 22:59:29 --> Email Class Initialized
INFO - 2025-03-28 22:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:59:29 --> Form Validation Class Initialized
INFO - 2025-03-28 22:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:59:29 --> Pagination Class Initialized
INFO - 2025-03-28 22:59:29 --> Controller Class Initialized
DEBUG - 2025-03-28 22:59:29 --> Supplier MX_Controller Initialized
INFO - 2025-03-28 22:59:29 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:59:29 --> Model Class Initialized
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$address2 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 224
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$phone /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 226
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$emailnumber /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 227
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$email_address /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 228
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$contact /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 229
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$fax /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 230
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$address2 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 224
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$phone /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 226
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$emailnumber /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 227
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$email_address /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 228
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$contact /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 229
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$fax /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 230
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$address2 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 224
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$phone /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 226
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$emailnumber /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 227
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$email_address /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 228
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$contact /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 229
ERROR - 2025-03-28 22:59:29 --> Severity: Warning --> Undefined property: stdClass::$fax /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 230
ERROR - 2025-03-28 22:59:29 --> DEBUG: Supplier List JSON Response -> {"draw":1,"iTotalRecords":3,"iTotalDisplayRecords":3,"aaData":[{"sl":1,"supplier_name":"AG agro","address":"Ahsan Tower, 76 Bir Uttam A.k. Khandakar Sarak, Mohakhali, C\\A , ","address2":null,"mobile":"8801867449163","phone":null,"email":null,"email_address":null,"contact":null,"fax":null,"city":"Dhaka","state":"","zip":"1213","country":"Bangladesh","balance":"245.70","button":" <a href=\"http:\/\/localhost:8000\/edit_supplier\/3\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"Update\"><i class=\"pe-7s-note\" aria-hidden=\"true\"><\/i><\/a> <a onclick=\"supplierdelete(3)\" href=\"javascript:void(0)\"  class=\"btn btn-danger btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"Delete \"><i class=\"pe-7s-trash\" aria-hidden=\"true\"><\/i><\/a>"},{"sl":2,"supplier_name":"Danish","address":"abc","address2":null,"mobile":"01949452343","phone":null,"email":null,"email_address":null,"contact":null,"fax":null,"city":"dhaka","state":"","zip":"4000","country":"Bangladesh","balance":"100.00","button":" <a href=\"http:\/\/localhost:8000\/edit_supplier\/2\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"Update\"><i class=\"pe-7s-note\" aria-hidden=\"true\"><\/i><\/a> <a onclick=\"supplierdelete(2)\" href=\"javascript:void(0)\"  class=\"btn btn-danger btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"Delete \"><i class=\"pe-7s-trash\" aria-hidden=\"true\"><\/i><\/a>"},{"sl":3,"supplier_name":"Pran Company Limited","address":"","address2":null,"mobile":"","phone":null,"email":null,"email_address":null,"contact":null,"fax":null,"city":"","state":"","zip":"","country":"","balance":"0.00","button":" <a href=\"http:\/\/localhost:8000\/edit_supplier\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"Update\"><i class=\"pe-7s-note\" aria-hidden=\"true\"><\/i><\/a> <a onclick=\"supplierdelete(1)\" href=\"javascript:void(0)\"  class=\"btn btn-danger btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"Delete \"><i class=\"pe-7s-trash\" aria-hidden=\"true\"><\/i><\/a>"}]}
INFO - 2025-03-28 22:59:32 --> Config Class Initialized
INFO - 2025-03-28 22:59:32 --> Hooks Class Initialized
DEBUG - 2025-03-28 22:59:32 --> UTF-8 Support Enabled
INFO - 2025-03-28 22:59:32 --> Utf8 Class Initialized
INFO - 2025-03-28 22:59:32 --> URI Class Initialized
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-28 22:59:32 --> Router Class Initialized
INFO - 2025-03-28 22:59:32 --> Output Class Initialized
INFO - 2025-03-28 22:59:32 --> Security Class Initialized
DEBUG - 2025-03-28 22:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 22:59:32 --> Input Class Initialized
INFO - 2025-03-28 22:59:32 --> Language Class Initialized
INFO - 2025-03-28 22:59:32 --> Language Class Initialized
INFO - 2025-03-28 22:59:32 --> Config Class Initialized
INFO - 2025-03-28 22:59:32 --> Loader Class Initialized
INFO - 2025-03-28 22:59:32 --> Helper loaded: url_helper
INFO - 2025-03-28 22:59:32 --> Helper loaded: file_helper
INFO - 2025-03-28 22:59:32 --> Helper loaded: html_helper
INFO - 2025-03-28 22:59:32 --> Helper loaded: form_helper
INFO - 2025-03-28 22:59:32 --> Helper loaded: text_helper
INFO - 2025-03-28 22:59:32 --> Helper loaded: lang_helper
INFO - 2025-03-28 22:59:32 --> Helper loaded: directory_helper
INFO - 2025-03-28 22:59:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 22:59:32 --> Database Driver Class Initialized
INFO - 2025-03-28 22:59:32 --> Email Class Initialized
INFO - 2025-03-28 22:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 22:59:32 --> Form Validation Class Initialized
INFO - 2025-03-28 22:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 22:59:32 --> Pagination Class Initialized
INFO - 2025-03-28 22:59:32 --> Controller Class Initialized
DEBUG - 2025-03-28 22:59:32 --> Supplier MX_Controller Initialized
INFO - 2025-03-28 22:59:32 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 22:59:32 --> Model Class Initialized
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 22:59:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 22:59:32 --> Model Class Initialized
ERROR - 2025-03-28 22:59:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 22:59:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/form.php
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 22:59:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 22:59:32 --> Final output sent to browser
DEBUG - 2025-03-28 22:59:32 --> Total execution time: 0.1832
INFO - 2025-03-28 23:00:25 --> Config Class Initialized
INFO - 2025-03-28 23:00:25 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:00:25 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:00:25 --> Utf8 Class Initialized
INFO - 2025-03-28 23:00:25 --> URI Class Initialized
DEBUG - 2025-03-28 23:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-28 23:00:25 --> Router Class Initialized
INFO - 2025-03-28 23:00:25 --> Output Class Initialized
INFO - 2025-03-28 23:00:25 --> Security Class Initialized
DEBUG - 2025-03-28 23:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:00:25 --> Input Class Initialized
INFO - 2025-03-28 23:00:25 --> Language Class Initialized
INFO - 2025-03-28 23:00:25 --> Language Class Initialized
INFO - 2025-03-28 23:00:25 --> Config Class Initialized
INFO - 2025-03-28 23:00:25 --> Loader Class Initialized
INFO - 2025-03-28 23:00:25 --> Helper loaded: url_helper
INFO - 2025-03-28 23:00:25 --> Helper loaded: file_helper
INFO - 2025-03-28 23:00:25 --> Helper loaded: html_helper
INFO - 2025-03-28 23:00:25 --> Helper loaded: form_helper
INFO - 2025-03-28 23:00:25 --> Helper loaded: text_helper
INFO - 2025-03-28 23:00:25 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:00:25 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:00:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:00:25 --> Database Driver Class Initialized
INFO - 2025-03-28 23:00:25 --> Email Class Initialized
INFO - 2025-03-28 23:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:00:25 --> Form Validation Class Initialized
INFO - 2025-03-28 23:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:00:25 --> Pagination Class Initialized
INFO - 2025-03-28 23:00:25 --> Controller Class Initialized
DEBUG - 2025-03-28 23:00:25 --> Supplier MX_Controller Initialized
INFO - 2025-03-28 23:00:25 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:00:25 --> Model Class Initialized
INFO - 2025-03-28 23:00:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 23:00:25 --> Final output sent to browser
DEBUG - 2025-03-28 23:00:25 --> Total execution time: 0.0456
INFO - 2025-03-28 23:00:31 --> Config Class Initialized
INFO - 2025-03-28 23:00:31 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:00:31 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:00:31 --> Utf8 Class Initialized
INFO - 2025-03-28 23:00:31 --> URI Class Initialized
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:00:31 --> Router Class Initialized
INFO - 2025-03-28 23:00:31 --> Output Class Initialized
INFO - 2025-03-28 23:00:31 --> Security Class Initialized
DEBUG - 2025-03-28 23:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:00:31 --> Input Class Initialized
INFO - 2025-03-28 23:00:31 --> Language Class Initialized
INFO - 2025-03-28 23:00:31 --> Language Class Initialized
INFO - 2025-03-28 23:00:31 --> Config Class Initialized
INFO - 2025-03-28 23:00:31 --> Loader Class Initialized
INFO - 2025-03-28 23:00:31 --> Helper loaded: url_helper
INFO - 2025-03-28 23:00:31 --> Helper loaded: file_helper
INFO - 2025-03-28 23:00:31 --> Helper loaded: html_helper
INFO - 2025-03-28 23:00:31 --> Helper loaded: form_helper
INFO - 2025-03-28 23:00:31 --> Helper loaded: text_helper
INFO - 2025-03-28 23:00:31 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:00:31 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:00:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:00:31 --> Database Driver Class Initialized
INFO - 2025-03-28 23:00:31 --> Email Class Initialized
INFO - 2025-03-28 23:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:00:31 --> Form Validation Class Initialized
INFO - 2025-03-28 23:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:00:31 --> Pagination Class Initialized
INFO - 2025-03-28 23:00:31 --> Controller Class Initialized
DEBUG - 2025-03-28 23:00:31 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:00:31 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:00:31 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:00:31 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:00:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:00:31 --> Model Class Initialized
ERROR - 2025-03-28 23:00:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:00:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:00:31 --> Final output sent to browser
DEBUG - 2025-03-28 23:00:31 --> Total execution time: 0.1324
INFO - 2025-03-28 23:00:32 --> Config Class Initialized
INFO - 2025-03-28 23:00:32 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:00:32 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:00:32 --> Utf8 Class Initialized
INFO - 2025-03-28 23:00:32 --> URI Class Initialized
DEBUG - 2025-03-28 23:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:00:32 --> Router Class Initialized
INFO - 2025-03-28 23:00:32 --> Output Class Initialized
INFO - 2025-03-28 23:00:32 --> Security Class Initialized
DEBUG - 2025-03-28 23:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:00:32 --> Input Class Initialized
INFO - 2025-03-28 23:00:32 --> Language Class Initialized
INFO - 2025-03-28 23:00:32 --> Language Class Initialized
INFO - 2025-03-28 23:00:32 --> Config Class Initialized
INFO - 2025-03-28 23:00:32 --> Loader Class Initialized
INFO - 2025-03-28 23:00:32 --> Helper loaded: url_helper
INFO - 2025-03-28 23:00:32 --> Helper loaded: file_helper
INFO - 2025-03-28 23:00:32 --> Helper loaded: html_helper
INFO - 2025-03-28 23:00:32 --> Helper loaded: form_helper
INFO - 2025-03-28 23:00:32 --> Helper loaded: text_helper
INFO - 2025-03-28 23:00:32 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:00:32 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:00:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:00:32 --> Database Driver Class Initialized
INFO - 2025-03-28 23:00:32 --> Email Class Initialized
INFO - 2025-03-28 23:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:00:32 --> Form Validation Class Initialized
INFO - 2025-03-28 23:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:00:32 --> Pagination Class Initialized
INFO - 2025-03-28 23:00:32 --> Controller Class Initialized
DEBUG - 2025-03-28 23:00:32 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:00:32 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:00:32 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:00:32 --> Model Class Initialized
ERROR - 2025-03-28 23:00:32 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 23:00:32 --> Final output sent to browser
DEBUG - 2025-03-28 23:00:32 --> Total execution time: 0.0121
INFO - 2025-03-28 23:00:34 --> Config Class Initialized
INFO - 2025-03-28 23:00:34 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:00:34 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:00:34 --> Utf8 Class Initialized
INFO - 2025-03-28 23:00:34 --> URI Class Initialized
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:00:34 --> Router Class Initialized
INFO - 2025-03-28 23:00:34 --> Output Class Initialized
INFO - 2025-03-28 23:00:34 --> Security Class Initialized
DEBUG - 2025-03-28 23:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:00:34 --> Input Class Initialized
INFO - 2025-03-28 23:00:34 --> Language Class Initialized
INFO - 2025-03-28 23:00:34 --> Language Class Initialized
INFO - 2025-03-28 23:00:34 --> Config Class Initialized
INFO - 2025-03-28 23:00:34 --> Loader Class Initialized
INFO - 2025-03-28 23:00:34 --> Helper loaded: url_helper
INFO - 2025-03-28 23:00:34 --> Helper loaded: file_helper
INFO - 2025-03-28 23:00:34 --> Helper loaded: html_helper
INFO - 2025-03-28 23:00:34 --> Helper loaded: form_helper
INFO - 2025-03-28 23:00:34 --> Helper loaded: text_helper
INFO - 2025-03-28 23:00:34 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:00:34 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:00:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:00:34 --> Database Driver Class Initialized
INFO - 2025-03-28 23:00:34 --> Email Class Initialized
INFO - 2025-03-28 23:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:00:34 --> Form Validation Class Initialized
INFO - 2025-03-28 23:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:00:34 --> Pagination Class Initialized
INFO - 2025-03-28 23:00:34 --> Controller Class Initialized
DEBUG - 2025-03-28 23:00:34 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:00:34 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:00:34 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:00:34 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:00:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:00:34 --> Model Class Initialized
ERROR - 2025-03-28 23:00:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:00:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:00:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:00:34 --> Final output sent to browser
DEBUG - 2025-03-28 23:00:34 --> Total execution time: 0.1467
INFO - 2025-03-28 23:00:39 --> Config Class Initialized
INFO - 2025-03-28 23:00:39 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:00:39 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:00:39 --> Utf8 Class Initialized
INFO - 2025-03-28 23:00:39 --> URI Class Initialized
DEBUG - 2025-03-28 23:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:00:39 --> Router Class Initialized
INFO - 2025-03-28 23:00:39 --> Output Class Initialized
INFO - 2025-03-28 23:00:39 --> Security Class Initialized
DEBUG - 2025-03-28 23:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:00:39 --> Input Class Initialized
INFO - 2025-03-28 23:00:39 --> Language Class Initialized
INFO - 2025-03-28 23:00:39 --> Language Class Initialized
INFO - 2025-03-28 23:00:39 --> Config Class Initialized
INFO - 2025-03-28 23:00:39 --> Loader Class Initialized
INFO - 2025-03-28 23:00:39 --> Helper loaded: url_helper
INFO - 2025-03-28 23:00:39 --> Helper loaded: file_helper
INFO - 2025-03-28 23:00:39 --> Helper loaded: html_helper
INFO - 2025-03-28 23:00:39 --> Helper loaded: form_helper
INFO - 2025-03-28 23:00:39 --> Helper loaded: text_helper
INFO - 2025-03-28 23:00:39 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:00:39 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:00:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:00:39 --> Database Driver Class Initialized
INFO - 2025-03-28 23:00:39 --> Email Class Initialized
INFO - 2025-03-28 23:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:00:39 --> Form Validation Class Initialized
INFO - 2025-03-28 23:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:00:39 --> Pagination Class Initialized
INFO - 2025-03-28 23:00:39 --> Controller Class Initialized
DEBUG - 2025-03-28 23:00:39 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:00:39 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:00:39 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:00:39 --> Model Class Initialized
INFO - 2025-03-28 23:00:39 --> Final output sent to browser
DEBUG - 2025-03-28 23:00:39 --> Total execution time: 0.0084
INFO - 2025-03-28 23:00:50 --> Config Class Initialized
INFO - 2025-03-28 23:00:50 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:00:50 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:00:50 --> Utf8 Class Initialized
INFO - 2025-03-28 23:00:50 --> URI Class Initialized
DEBUG - 2025-03-28 23:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:00:50 --> Router Class Initialized
INFO - 2025-03-28 23:00:50 --> Output Class Initialized
INFO - 2025-03-28 23:00:50 --> Security Class Initialized
DEBUG - 2025-03-28 23:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:00:50 --> Input Class Initialized
INFO - 2025-03-28 23:00:50 --> Language Class Initialized
INFO - 2025-03-28 23:00:50 --> Language Class Initialized
INFO - 2025-03-28 23:00:50 --> Config Class Initialized
INFO - 2025-03-28 23:00:50 --> Loader Class Initialized
INFO - 2025-03-28 23:00:50 --> Helper loaded: url_helper
INFO - 2025-03-28 23:00:50 --> Helper loaded: file_helper
INFO - 2025-03-28 23:00:50 --> Helper loaded: html_helper
INFO - 2025-03-28 23:00:50 --> Helper loaded: form_helper
INFO - 2025-03-28 23:00:50 --> Helper loaded: text_helper
INFO - 2025-03-28 23:00:50 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:00:50 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:00:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:00:50 --> Database Driver Class Initialized
INFO - 2025-03-28 23:00:50 --> Email Class Initialized
INFO - 2025-03-28 23:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:00:50 --> Form Validation Class Initialized
INFO - 2025-03-28 23:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:00:50 --> Pagination Class Initialized
INFO - 2025-03-28 23:00:50 --> Controller Class Initialized
DEBUG - 2025-03-28 23:00:50 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:00:50 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:00:50 --> Model Class Initialized
DEBUG - 2025-03-28 23:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:00:50 --> Model Class Initialized
INFO - 2025-03-28 23:00:50 --> Final output sent to browser
DEBUG - 2025-03-28 23:00:50 --> Total execution time: 0.0137
INFO - 2025-03-28 23:01:04 --> Config Class Initialized
INFO - 2025-03-28 23:01:04 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:04 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:04 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:04 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:04 --> Router Class Initialized
INFO - 2025-03-28 23:01:04 --> Output Class Initialized
INFO - 2025-03-28 23:01:04 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:04 --> Input Class Initialized
INFO - 2025-03-28 23:01:04 --> Language Class Initialized
INFO - 2025-03-28 23:01:04 --> Language Class Initialized
INFO - 2025-03-28 23:01:04 --> Config Class Initialized
INFO - 2025-03-28 23:01:04 --> Loader Class Initialized
INFO - 2025-03-28 23:01:04 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:04 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:04 --> Email Class Initialized
INFO - 2025-03-28 23:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:04 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:04 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:04 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:04 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
INFO - 2025-03-28 23:01:04 --> Upload Class Initialized
INFO - 2025-03-28 23:01:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 23:01:04 --> Config Class Initialized
INFO - 2025-03-28 23:01:04 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:04 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:04 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:04 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:04 --> Router Class Initialized
INFO - 2025-03-28 23:01:04 --> Output Class Initialized
INFO - 2025-03-28 23:01:04 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:04 --> Input Class Initialized
INFO - 2025-03-28 23:01:04 --> Language Class Initialized
INFO - 2025-03-28 23:01:04 --> Language Class Initialized
INFO - 2025-03-28 23:01:04 --> Config Class Initialized
INFO - 2025-03-28 23:01:04 --> Loader Class Initialized
INFO - 2025-03-28 23:01:04 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:04 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:04 --> Email Class Initialized
INFO - 2025-03-28 23:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:04 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:04 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:04 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:04 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:01:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
ERROR - 2025-03-28 23:01:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:01:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:01:04 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:04 --> Total execution time: 0.0880
INFO - 2025-03-28 23:01:04 --> Config Class Initialized
INFO - 2025-03-28 23:01:04 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:04 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:04 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:04 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:04 --> Router Class Initialized
INFO - 2025-03-28 23:01:04 --> Output Class Initialized
INFO - 2025-03-28 23:01:04 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:04 --> Input Class Initialized
INFO - 2025-03-28 23:01:04 --> Language Class Initialized
INFO - 2025-03-28 23:01:04 --> Language Class Initialized
INFO - 2025-03-28 23:01:04 --> Config Class Initialized
INFO - 2025-03-28 23:01:04 --> Loader Class Initialized
INFO - 2025-03-28 23:01:04 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:04 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:04 --> Email Class Initialized
INFO - 2025-03-28 23:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:04 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:04 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:04 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:04 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:04 --> Model Class Initialized
ERROR - 2025-03-28 23:01:04 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 23:01:04 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:04 --> Total execution time: 0.0134
INFO - 2025-03-28 23:01:10 --> Config Class Initialized
INFO - 2025-03-28 23:01:10 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:10 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:10 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:10 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:10 --> Router Class Initialized
INFO - 2025-03-28 23:01:10 --> Output Class Initialized
INFO - 2025-03-28 23:01:10 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:10 --> Input Class Initialized
INFO - 2025-03-28 23:01:10 --> Language Class Initialized
INFO - 2025-03-28 23:01:10 --> Language Class Initialized
INFO - 2025-03-28 23:01:10 --> Config Class Initialized
INFO - 2025-03-28 23:01:10 --> Loader Class Initialized
INFO - 2025-03-28 23:01:10 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:10 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:10 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:10 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:10 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:10 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:10 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:10 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:10 --> Email Class Initialized
INFO - 2025-03-28 23:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:10 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:10 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:10 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:10 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:10 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:01:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:01:10 --> Model Class Initialized
ERROR - 2025-03-28 23:01:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:01:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:01:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:01:10 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:10 --> Total execution time: 0.1430
INFO - 2025-03-28 23:01:14 --> Config Class Initialized
INFO - 2025-03-28 23:01:14 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:14 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:14 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:14 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:14 --> Router Class Initialized
INFO - 2025-03-28 23:01:14 --> Output Class Initialized
INFO - 2025-03-28 23:01:14 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:14 --> Input Class Initialized
INFO - 2025-03-28 23:01:14 --> Language Class Initialized
INFO - 2025-03-28 23:01:14 --> Language Class Initialized
INFO - 2025-03-28 23:01:14 --> Config Class Initialized
INFO - 2025-03-28 23:01:14 --> Loader Class Initialized
INFO - 2025-03-28 23:01:14 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:14 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:14 --> Email Class Initialized
INFO - 2025-03-28 23:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:14 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:14 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:14 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:14 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:14 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:14 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:14 --> Model Class Initialized
INFO - 2025-03-28 23:01:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 23:01:14 --> Config Class Initialized
INFO - 2025-03-28 23:01:14 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:14 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:14 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:14 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:14 --> Router Class Initialized
INFO - 2025-03-28 23:01:14 --> Output Class Initialized
INFO - 2025-03-28 23:01:14 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:14 --> Input Class Initialized
INFO - 2025-03-28 23:01:14 --> Language Class Initialized
INFO - 2025-03-28 23:01:14 --> Language Class Initialized
INFO - 2025-03-28 23:01:14 --> Config Class Initialized
INFO - 2025-03-28 23:01:14 --> Loader Class Initialized
INFO - 2025-03-28 23:01:14 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:14 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:14 --> Email Class Initialized
INFO - 2025-03-28 23:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:14 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:14 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:14 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:14 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:14 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:14 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:14 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:01:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:01:14 --> Model Class Initialized
ERROR - 2025-03-28 23:01:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:01:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:01:15 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:15 --> Total execution time: 0.1117
INFO - 2025-03-28 23:01:15 --> Config Class Initialized
INFO - 2025-03-28 23:01:15 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:15 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:15 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:15 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:15 --> Router Class Initialized
INFO - 2025-03-28 23:01:15 --> Output Class Initialized
INFO - 2025-03-28 23:01:15 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:15 --> Input Class Initialized
INFO - 2025-03-28 23:01:15 --> Language Class Initialized
INFO - 2025-03-28 23:01:15 --> Language Class Initialized
INFO - 2025-03-28 23:01:15 --> Config Class Initialized
INFO - 2025-03-28 23:01:15 --> Loader Class Initialized
INFO - 2025-03-28 23:01:15 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:15 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:15 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:15 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:15 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:15 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:15 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:15 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:15 --> Email Class Initialized
INFO - 2025-03-28 23:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:15 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:15 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:15 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:15 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:15 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:15 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:15 --> Model Class Initialized
ERROR - 2025-03-28 23:01:15 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 23:01:15 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:15 --> Total execution time: 0.0077
INFO - 2025-03-28 23:01:26 --> Config Class Initialized
INFO - 2025-03-28 23:01:26 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:26 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:26 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:26 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:26 --> Router Class Initialized
INFO - 2025-03-28 23:01:26 --> Output Class Initialized
INFO - 2025-03-28 23:01:26 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:26 --> Input Class Initialized
INFO - 2025-03-28 23:01:26 --> Language Class Initialized
INFO - 2025-03-28 23:01:26 --> Language Class Initialized
INFO - 2025-03-28 23:01:26 --> Config Class Initialized
INFO - 2025-03-28 23:01:26 --> Loader Class Initialized
INFO - 2025-03-28 23:01:26 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:26 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:26 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:26 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:26 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:26 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:26 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:26 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:26 --> Email Class Initialized
INFO - 2025-03-28 23:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:26 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:26 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:26 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:26 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:26 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:26 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:26 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:01:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:01:26 --> Model Class Initialized
ERROR - 2025-03-28 23:01:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:01:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:01:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:01:26 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:26 --> Total execution time: 0.1375
INFO - 2025-03-28 23:01:40 --> Config Class Initialized
INFO - 2025-03-28 23:01:40 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:40 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:40 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:40 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:40 --> Router Class Initialized
INFO - 2025-03-28 23:01:40 --> Output Class Initialized
INFO - 2025-03-28 23:01:40 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:40 --> Input Class Initialized
INFO - 2025-03-28 23:01:40 --> Language Class Initialized
INFO - 2025-03-28 23:01:40 --> Language Class Initialized
INFO - 2025-03-28 23:01:40 --> Config Class Initialized
INFO - 2025-03-28 23:01:40 --> Loader Class Initialized
INFO - 2025-03-28 23:01:40 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:40 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:40 --> Email Class Initialized
INFO - 2025-03-28 23:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:40 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:40 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:40 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:40 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:40 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:40 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:40 --> Model Class Initialized
INFO - 2025-03-28 23:01:40 --> Upload Class Initialized
INFO - 2025-03-28 23:01:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 23:01:40 --> Config Class Initialized
INFO - 2025-03-28 23:01:40 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:40 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:40 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:40 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:40 --> Router Class Initialized
INFO - 2025-03-28 23:01:40 --> Output Class Initialized
INFO - 2025-03-28 23:01:40 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:40 --> Input Class Initialized
INFO - 2025-03-28 23:01:40 --> Language Class Initialized
INFO - 2025-03-28 23:01:40 --> Language Class Initialized
INFO - 2025-03-28 23:01:40 --> Config Class Initialized
INFO - 2025-03-28 23:01:40 --> Loader Class Initialized
INFO - 2025-03-28 23:01:40 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:40 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:40 --> Email Class Initialized
INFO - 2025-03-28 23:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:40 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:40 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:40 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:40 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:40 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:40 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:40 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:01:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:01:40 --> Model Class Initialized
ERROR - 2025-03-28 23:01:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:01:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:01:41 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:41 --> Total execution time: 0.1024
INFO - 2025-03-28 23:01:41 --> Config Class Initialized
INFO - 2025-03-28 23:01:41 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:41 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:41 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:41 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:41 --> Router Class Initialized
INFO - 2025-03-28 23:01:41 --> Output Class Initialized
INFO - 2025-03-28 23:01:41 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:41 --> Input Class Initialized
INFO - 2025-03-28 23:01:41 --> Language Class Initialized
INFO - 2025-03-28 23:01:41 --> Language Class Initialized
INFO - 2025-03-28 23:01:41 --> Config Class Initialized
INFO - 2025-03-28 23:01:41 --> Loader Class Initialized
INFO - 2025-03-28 23:01:41 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:41 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:41 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:41 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:41 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:41 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:41 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:41 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:41 --> Email Class Initialized
INFO - 2025-03-28 23:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:41 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:41 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:41 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:41 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:41 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:41 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:41 --> Model Class Initialized
ERROR - 2025-03-28 23:01:41 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 23:01:41 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:41 --> Total execution time: 0.0093
INFO - 2025-03-28 23:01:49 --> Config Class Initialized
INFO - 2025-03-28 23:01:49 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:01:49 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:01:49 --> Utf8 Class Initialized
INFO - 2025-03-28 23:01:49 --> URI Class Initialized
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:01:49 --> Router Class Initialized
INFO - 2025-03-28 23:01:49 --> Output Class Initialized
INFO - 2025-03-28 23:01:49 --> Security Class Initialized
DEBUG - 2025-03-28 23:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:01:49 --> Input Class Initialized
INFO - 2025-03-28 23:01:49 --> Language Class Initialized
INFO - 2025-03-28 23:01:49 --> Language Class Initialized
INFO - 2025-03-28 23:01:49 --> Config Class Initialized
INFO - 2025-03-28 23:01:49 --> Loader Class Initialized
INFO - 2025-03-28 23:01:49 --> Helper loaded: url_helper
INFO - 2025-03-28 23:01:49 --> Helper loaded: file_helper
INFO - 2025-03-28 23:01:49 --> Helper loaded: html_helper
INFO - 2025-03-28 23:01:49 --> Helper loaded: form_helper
INFO - 2025-03-28 23:01:49 --> Helper loaded: text_helper
INFO - 2025-03-28 23:01:49 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:01:49 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:01:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:01:49 --> Database Driver Class Initialized
INFO - 2025-03-28 23:01:49 --> Email Class Initialized
INFO - 2025-03-28 23:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:01:49 --> Form Validation Class Initialized
INFO - 2025-03-28 23:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:01:49 --> Pagination Class Initialized
INFO - 2025-03-28 23:01:49 --> Controller Class Initialized
DEBUG - 2025-03-28 23:01:49 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:01:49 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:01:49 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:01:49 --> Model Class Initialized
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:01:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:01:49 --> Model Class Initialized
ERROR - 2025-03-28 23:01:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:01:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:01:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:01:49 --> Final output sent to browser
DEBUG - 2025-03-28 23:01:49 --> Total execution time: 0.1317
INFO - 2025-03-28 23:02:00 --> Config Class Initialized
INFO - 2025-03-28 23:02:00 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:02:00 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:02:00 --> Utf8 Class Initialized
INFO - 2025-03-28 23:02:00 --> URI Class Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:02:00 --> Router Class Initialized
INFO - 2025-03-28 23:02:00 --> Output Class Initialized
INFO - 2025-03-28 23:02:00 --> Security Class Initialized
DEBUG - 2025-03-28 23:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:02:00 --> Input Class Initialized
INFO - 2025-03-28 23:02:00 --> Language Class Initialized
INFO - 2025-03-28 23:02:00 --> Language Class Initialized
INFO - 2025-03-28 23:02:00 --> Config Class Initialized
INFO - 2025-03-28 23:02:00 --> Loader Class Initialized
INFO - 2025-03-28 23:02:00 --> Helper loaded: url_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: file_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: html_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: form_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: text_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:02:00 --> Database Driver Class Initialized
INFO - 2025-03-28 23:02:00 --> Email Class Initialized
INFO - 2025-03-28 23:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:02:00 --> Form Validation Class Initialized
INFO - 2025-03-28 23:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:02:00 --> Pagination Class Initialized
INFO - 2025-03-28 23:02:00 --> Controller Class Initialized
DEBUG - 2025-03-28 23:02:00 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:02:00 --> Model Class Initialized
INFO - 2025-03-28 23:02:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 23:02:00 --> Config Class Initialized
INFO - 2025-03-28 23:02:00 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:02:00 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:02:00 --> Utf8 Class Initialized
INFO - 2025-03-28 23:02:00 --> URI Class Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:02:00 --> Router Class Initialized
INFO - 2025-03-28 23:02:00 --> Output Class Initialized
INFO - 2025-03-28 23:02:00 --> Security Class Initialized
DEBUG - 2025-03-28 23:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:02:00 --> Input Class Initialized
INFO - 2025-03-28 23:02:00 --> Language Class Initialized
INFO - 2025-03-28 23:02:00 --> Language Class Initialized
INFO - 2025-03-28 23:02:00 --> Config Class Initialized
INFO - 2025-03-28 23:02:00 --> Loader Class Initialized
INFO - 2025-03-28 23:02:00 --> Helper loaded: url_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: file_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: html_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: form_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: text_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:02:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:02:00 --> Database Driver Class Initialized
INFO - 2025-03-28 23:02:00 --> Email Class Initialized
INFO - 2025-03-28 23:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:02:00 --> Form Validation Class Initialized
INFO - 2025-03-28 23:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:02:00 --> Pagination Class Initialized
INFO - 2025-03-28 23:02:00 --> Controller Class Initialized
DEBUG - 2025-03-28 23:02:00 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:02:00 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:02:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:02:00 --> Model Class Initialized
ERROR - 2025-03-28 23:02:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:02:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:02:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:02:00 --> Final output sent to browser
DEBUG - 2025-03-28 23:02:00 --> Total execution time: 0.1121
INFO - 2025-03-28 23:02:01 --> Config Class Initialized
INFO - 2025-03-28 23:02:01 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:02:01 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:02:01 --> Utf8 Class Initialized
INFO - 2025-03-28 23:02:01 --> URI Class Initialized
DEBUG - 2025-03-28 23:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:02:01 --> Router Class Initialized
INFO - 2025-03-28 23:02:01 --> Output Class Initialized
INFO - 2025-03-28 23:02:01 --> Security Class Initialized
DEBUG - 2025-03-28 23:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:02:01 --> Input Class Initialized
INFO - 2025-03-28 23:02:01 --> Language Class Initialized
INFO - 2025-03-28 23:02:01 --> Language Class Initialized
INFO - 2025-03-28 23:02:01 --> Config Class Initialized
INFO - 2025-03-28 23:02:01 --> Loader Class Initialized
INFO - 2025-03-28 23:02:01 --> Helper loaded: url_helper
INFO - 2025-03-28 23:02:01 --> Helper loaded: file_helper
INFO - 2025-03-28 23:02:01 --> Helper loaded: html_helper
INFO - 2025-03-28 23:02:01 --> Helper loaded: form_helper
INFO - 2025-03-28 23:02:01 --> Helper loaded: text_helper
INFO - 2025-03-28 23:02:01 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:02:01 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:02:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:02:01 --> Database Driver Class Initialized
INFO - 2025-03-28 23:02:01 --> Email Class Initialized
INFO - 2025-03-28 23:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:02:01 --> Form Validation Class Initialized
INFO - 2025-03-28 23:02:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:02:01 --> Pagination Class Initialized
INFO - 2025-03-28 23:02:01 --> Controller Class Initialized
DEBUG - 2025-03-28 23:02:01 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:02:01 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:02:01 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:02:01 --> Model Class Initialized
ERROR - 2025-03-28 23:02:01 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 23:02:01 --> Final output sent to browser
DEBUG - 2025-03-28 23:02:01 --> Total execution time: 0.0084
INFO - 2025-03-28 23:02:05 --> Config Class Initialized
INFO - 2025-03-28 23:02:05 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:02:05 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:02:05 --> Utf8 Class Initialized
INFO - 2025-03-28 23:02:05 --> URI Class Initialized
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:02:05 --> Router Class Initialized
INFO - 2025-03-28 23:02:05 --> Output Class Initialized
INFO - 2025-03-28 23:02:05 --> Security Class Initialized
DEBUG - 2025-03-28 23:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:02:05 --> Input Class Initialized
INFO - 2025-03-28 23:02:05 --> Language Class Initialized
INFO - 2025-03-28 23:02:05 --> Language Class Initialized
INFO - 2025-03-28 23:02:05 --> Config Class Initialized
INFO - 2025-03-28 23:02:05 --> Loader Class Initialized
INFO - 2025-03-28 23:02:05 --> Helper loaded: url_helper
INFO - 2025-03-28 23:02:05 --> Helper loaded: file_helper
INFO - 2025-03-28 23:02:05 --> Helper loaded: html_helper
INFO - 2025-03-28 23:02:05 --> Helper loaded: form_helper
INFO - 2025-03-28 23:02:05 --> Helper loaded: text_helper
INFO - 2025-03-28 23:02:05 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:02:05 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:02:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:02:05 --> Database Driver Class Initialized
INFO - 2025-03-28 23:02:05 --> Email Class Initialized
INFO - 2025-03-28 23:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:02:05 --> Form Validation Class Initialized
INFO - 2025-03-28 23:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:02:05 --> Pagination Class Initialized
INFO - 2025-03-28 23:02:05 --> Controller Class Initialized
DEBUG - 2025-03-28 23:02:05 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:02:05 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:02:05 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:02:05 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:02:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:02:05 --> Model Class Initialized
ERROR - 2025-03-28 23:02:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:02:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:02:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:02:05 --> Final output sent to browser
DEBUG - 2025-03-28 23:02:05 --> Total execution time: 0.1105
INFO - 2025-03-28 23:02:17 --> Config Class Initialized
INFO - 2025-03-28 23:02:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:02:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:02:17 --> Utf8 Class Initialized
INFO - 2025-03-28 23:02:17 --> URI Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:02:17 --> Router Class Initialized
INFO - 2025-03-28 23:02:17 --> Output Class Initialized
INFO - 2025-03-28 23:02:17 --> Security Class Initialized
DEBUG - 2025-03-28 23:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:02:17 --> Input Class Initialized
INFO - 2025-03-28 23:02:17 --> Language Class Initialized
INFO - 2025-03-28 23:02:17 --> Language Class Initialized
INFO - 2025-03-28 23:02:17 --> Config Class Initialized
INFO - 2025-03-28 23:02:17 --> Loader Class Initialized
INFO - 2025-03-28 23:02:17 --> Helper loaded: url_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: file_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: html_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: form_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: text_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:02:17 --> Database Driver Class Initialized
INFO - 2025-03-28 23:02:17 --> Email Class Initialized
INFO - 2025-03-28 23:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:02:17 --> Form Validation Class Initialized
INFO - 2025-03-28 23:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:02:17 --> Pagination Class Initialized
INFO - 2025-03-28 23:02:17 --> Controller Class Initialized
DEBUG - 2025-03-28 23:02:17 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
INFO - 2025-03-28 23:02:17 --> Upload Class Initialized
INFO - 2025-03-28 23:02:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-28 23:02:17 --> Config Class Initialized
INFO - 2025-03-28 23:02:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:02:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:02:17 --> Utf8 Class Initialized
INFO - 2025-03-28 23:02:17 --> URI Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:02:17 --> Router Class Initialized
INFO - 2025-03-28 23:02:17 --> Output Class Initialized
INFO - 2025-03-28 23:02:17 --> Security Class Initialized
DEBUG - 2025-03-28 23:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:02:17 --> Input Class Initialized
INFO - 2025-03-28 23:02:17 --> Language Class Initialized
INFO - 2025-03-28 23:02:17 --> Language Class Initialized
INFO - 2025-03-28 23:02:17 --> Config Class Initialized
INFO - 2025-03-28 23:02:17 --> Loader Class Initialized
INFO - 2025-03-28 23:02:17 --> Helper loaded: url_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: file_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: html_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: form_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: text_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:02:17 --> Database Driver Class Initialized
INFO - 2025-03-28 23:02:17 --> Email Class Initialized
INFO - 2025-03-28 23:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:02:17 --> Form Validation Class Initialized
INFO - 2025-03-28 23:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:02:17 --> Pagination Class Initialized
INFO - 2025-03-28 23:02:17 --> Controller Class Initialized
DEBUG - 2025-03-28 23:02:17 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-28 23:02:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
ERROR - 2025-03-28 23:02:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-28 23:02:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-28 23:02:17 --> Final output sent to browser
DEBUG - 2025-03-28 23:02:17 --> Total execution time: 0.0961
INFO - 2025-03-28 23:02:17 --> Config Class Initialized
INFO - 2025-03-28 23:02:17 --> Hooks Class Initialized
DEBUG - 2025-03-28 23:02:17 --> UTF-8 Support Enabled
INFO - 2025-03-28 23:02:17 --> Utf8 Class Initialized
INFO - 2025-03-28 23:02:17 --> URI Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-28 23:02:17 --> Router Class Initialized
INFO - 2025-03-28 23:02:17 --> Output Class Initialized
INFO - 2025-03-28 23:02:17 --> Security Class Initialized
DEBUG - 2025-03-28 23:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-28 23:02:17 --> Input Class Initialized
INFO - 2025-03-28 23:02:17 --> Language Class Initialized
INFO - 2025-03-28 23:02:17 --> Language Class Initialized
INFO - 2025-03-28 23:02:17 --> Config Class Initialized
INFO - 2025-03-28 23:02:17 --> Loader Class Initialized
INFO - 2025-03-28 23:02:17 --> Helper loaded: url_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: file_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: html_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: form_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: text_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: lang_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: directory_helper
INFO - 2025-03-28 23:02:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-28 23:02:17 --> Database Driver Class Initialized
INFO - 2025-03-28 23:02:17 --> Email Class Initialized
INFO - 2025-03-28 23:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-28 23:02:17 --> Form Validation Class Initialized
INFO - 2025-03-28 23:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-28 23:02:17 --> Pagination Class Initialized
INFO - 2025-03-28 23:02:17 --> Controller Class Initialized
DEBUG - 2025-03-28 23:02:17 --> Product MX_Controller Initialized
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
DEBUG - 2025-03-28 23:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-28 23:02:17 --> Model Class Initialized
ERROR - 2025-03-28 23:02:17 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/cd23e47393890cd08fe0269c490e4dec.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-28 23:02:17 --> Final output sent to browser
DEBUG - 2025-03-28 23:02:17 --> Total execution time: 0.0110
