<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-26 12:57:30 --> Config Class Initialized
INFO - 2025-03-26 12:57:30 --> Hooks Class Initialized
DEBUG - 2025-03-26 12:57:30 --> UTF-8 Support Enabled
INFO - 2025-03-26 12:57:30 --> Utf8 Class Initialized
INFO - 2025-03-26 12:57:30 --> URI Class Initialized
INFO - 2025-03-26 12:57:30 --> Router Class Initialized
INFO - 2025-03-26 12:57:30 --> Output Class Initialized
INFO - 2025-03-26 12:57:30 --> Security Class Initialized
DEBUG - 2025-03-26 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-26 12:57:30 --> Input Class Initialized
INFO - 2025-03-26 12:57:30 --> Language Class Initialized
INFO - 2025-03-26 12:57:30 --> Language Class Initialized
INFO - 2025-03-26 12:57:30 --> Config Class Initialized
INFO - 2025-03-26 12:57:30 --> Loader Class Initialized
INFO - 2025-03-26 12:57:30 --> Helper loaded: url_helper
INFO - 2025-03-26 12:57:30 --> Helper loaded: file_helper
INFO - 2025-03-26 12:57:30 --> Helper loaded: html_helper
INFO - 2025-03-26 12:57:30 --> Helper loaded: form_helper
INFO - 2025-03-26 12:57:30 --> Helper loaded: text_helper
INFO - 2025-03-26 12:57:30 --> Helper loaded: lang_helper
INFO - 2025-03-26 12:57:30 --> Helper loaded: directory_helper
INFO - 2025-03-26 12:57:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-26 12:57:30 --> Database Driver Class Initialized
INFO - 2025-03-26 12:57:30 --> Email Class Initialized
INFO - 2025-03-26 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-26 12:57:30 --> Form Validation Class Initialized
INFO - 2025-03-26 12:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-26 12:57:30 --> Pagination Class Initialized
INFO - 2025-03-26 12:57:30 --> Controller Class Initialized
INFO - 2025-03-26 12:57:30 --> Model Class Initialized
INFO - 2025-03-26 12:57:30 --> Final output sent to browser
DEBUG - 2025-03-26 12:57:30 --> Total execution time: 0.0547
INFO - 2025-03-26 13:05:38 --> Config Class Initialized
INFO - 2025-03-26 13:05:38 --> Hooks Class Initialized
DEBUG - 2025-03-26 13:05:38 --> UTF-8 Support Enabled
INFO - 2025-03-26 13:05:38 --> Utf8 Class Initialized
INFO - 2025-03-26 13:05:38 --> URI Class Initialized
INFO - 2025-03-26 13:05:38 --> Router Class Initialized
INFO - 2025-03-26 13:05:38 --> Output Class Initialized
INFO - 2025-03-26 13:05:38 --> Security Class Initialized
DEBUG - 2025-03-26 13:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-26 13:05:38 --> Input Class Initialized
INFO - 2025-03-26 13:05:38 --> Language Class Initialized
INFO - 2025-03-26 13:05:38 --> Language Class Initialized
INFO - 2025-03-26 13:05:38 --> Config Class Initialized
INFO - 2025-03-26 13:05:38 --> Loader Class Initialized
INFO - 2025-03-26 13:05:38 --> Helper loaded: url_helper
INFO - 2025-03-26 13:05:38 --> Helper loaded: file_helper
INFO - 2025-03-26 13:05:38 --> Helper loaded: html_helper
INFO - 2025-03-26 13:05:38 --> Helper loaded: form_helper
INFO - 2025-03-26 13:05:38 --> Helper loaded: text_helper
INFO - 2025-03-26 13:05:38 --> Helper loaded: lang_helper
INFO - 2025-03-26 13:05:38 --> Helper loaded: directory_helper
INFO - 2025-03-26 13:05:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-26 13:05:38 --> Database Driver Class Initialized
INFO - 2025-03-26 13:05:38 --> Email Class Initialized
INFO - 2025-03-26 13:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-26 13:05:38 --> Form Validation Class Initialized
INFO - 2025-03-26 13:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-26 13:05:38 --> Pagination Class Initialized
INFO - 2025-03-26 13:05:38 --> Controller Class Initialized
INFO - 2025-03-26 13:05:38 --> Model Class Initialized
INFO - 2025-03-26 13:05:38 --> Final output sent to browser
DEBUG - 2025-03-26 13:05:38 --> Total execution time: 0.0102
INFO - 2025-03-26 13:23:22 --> Config Class Initialized
INFO - 2025-03-26 13:23:22 --> Hooks Class Initialized
DEBUG - 2025-03-26 13:23:22 --> UTF-8 Support Enabled
INFO - 2025-03-26 13:23:22 --> Utf8 Class Initialized
INFO - 2025-03-26 13:23:22 --> URI Class Initialized
INFO - 2025-03-26 13:23:22 --> Router Class Initialized
INFO - 2025-03-26 13:23:22 --> Output Class Initialized
INFO - 2025-03-26 13:23:22 --> Security Class Initialized
DEBUG - 2025-03-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-26 13:23:22 --> Input Class Initialized
INFO - 2025-03-26 13:23:22 --> Language Class Initialized
INFO - 2025-03-26 13:23:22 --> Language Class Initialized
INFO - 2025-03-26 13:23:22 --> Config Class Initialized
INFO - 2025-03-26 13:23:22 --> Loader Class Initialized
INFO - 2025-03-26 13:23:22 --> Helper loaded: url_helper
INFO - 2025-03-26 13:23:22 --> Helper loaded: file_helper
INFO - 2025-03-26 13:23:22 --> Helper loaded: html_helper
INFO - 2025-03-26 13:23:22 --> Helper loaded: form_helper
INFO - 2025-03-26 13:23:22 --> Helper loaded: text_helper
INFO - 2025-03-26 13:23:22 --> Helper loaded: lang_helper
INFO - 2025-03-26 13:23:22 --> Helper loaded: directory_helper
INFO - 2025-03-26 13:23:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-26 13:23:22 --> Database Driver Class Initialized
INFO - 2025-03-26 13:23:22 --> Email Class Initialized
INFO - 2025-03-26 13:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-26 13:23:22 --> Form Validation Class Initialized
INFO - 2025-03-26 13:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-26 13:23:22 --> Pagination Class Initialized
INFO - 2025-03-26 13:23:22 --> Controller Class Initialized
INFO - 2025-03-26 13:23:22 --> Model Class Initialized
DEBUG - 2025-03-26 13:23:22 --> ==== [API] product_stock() called ====
DEBUG - 2025-03-26 13:23:22 --> Received GET param start: NULL
DEBUG - 2025-03-26 13:23:22 --> Normalized start value: 0
DEBUG - 2025-03-26 13:23:22 --> Raw stok_report from model: array (
  0 => 
  array (
    'stock_qty' => 477.0,
    'product_id' => '123456',
    'product_name' => 'Pran Juice',
    'product_model' => '',
    'unit' => 'Pcs',
    'price' => '25',
    'totalPurchaseQnty' => '572.00',
    'totalSalesQnty' => '95.00',
    'total_sale_price' => 11925.0,
  ),
  1 => 
  array (
    'stock_qty' => 129.0,
    'product_id' => '51252612252670',
    'product_name' => 'Vegetable Pakora',
    'product_model' => NULL,
    'unit' => 'Box',
    'price' => '29.72',
    'totalPurchaseQnty' => '164.00',
    'totalSalesQnty' => '35.00',
    'total_sale_price' => 3833.8799999999997,
  ),
  2 => 
  array (
    'stock_qty' => -20.0,
    'product_id' => '5998830',
    'product_name' => 'Pran Mango Juice',
    'product_model' => NULL,
    'unit' => 'Pcs',
    'price' => '25',
    'totalPurchaseQnty' => 0,
    'totalSalesQnty' => '20.00',
    'total_sale_price' => -500.0,
  ),
  3 => 
  array (
    'stock_qty' => 0,
    'product_id' => '79291734',
    'product_name' => 'Ruhi Fish',
    'product_model' => NULL,
    'unit' => 'Pcs',
    'price' => '350',
    'totalPurchaseQnty' => 0,
    'totalSalesQnty' => 0,
    'total_sale_price' => 0,
  ),
  4 => 
  array (
    'stock_qty' => 10.0,
    'product_id' => '84213421',
    'product_name' => 'Ruhi',
    'product_model' => NULL,
    'unit' => 'Pcs',
    'price' => '10',
    'totalPurchaseQnty' => '15.00',
    'totalSalesQnty' => '5.00',
    'total_sale_price' => 100.0,
  ),
)
DEBUG - 2025-03-26 13:23:22 --> Returning response with stock data: {"status":"ok","stock":[{"stock_qty":477,"product_id":"123456","product_name":"Pran Juice","product_model":"","unit":"Pcs","price":"25","totalPurchaseQnty":"572.00","totalSalesQnty":"95.00","total_sale_price":11925,"sl":1,"SubTotalOut":95,"SubTotalIn":572,"SubTotalStock":477},{"stock_qty":129,"product_id":"51252612252670","product_name":"Vegetable Pakora","product_model":null,"unit":"Box","price":"29.72","totalPurchaseQnty":"164.00","totalSalesQnty":"35.00","total_sale_price":3833.8799999999997,"sl":2,"SubTotalOut":130,"SubTotalIn":736,"SubTotalStock":606},{"stock_qty":-20,"product_id":"5998830","product_name":"Pran Mango Juice","product_model":null,"unit":"Pcs","price":"25","totalPurchaseQnty":0,"totalSalesQnty":"20.00","total_sale_price":-500,"sl":3,"SubTotalOut":150,"SubTotalIn":736,"SubTotalStock":586},{"stock_qty":0,"product_id":"79291734","product_name":"Ruhi Fish","product_model":null,"unit":"Pcs","price":"350","totalPurchaseQnty":0,"totalSalesQnty":0,"total_sale_price":0,"sl":4,"SubTotalOut":150,"SubTotalIn":736,"SubTotalStock":586},{"stock_qty":10,"product_id":"84213421","product_name":"Ruhi","product_model":null,"unit":"Pcs","price":"10","totalPurchaseQnty":"15.00","totalSalesQnty":"5.00","total_sale_price":100,"sl":5,"SubTotalOut":155,"SubTotalIn":751,"SubTotalStock":596}],"total_val":5,"permission":"read"}
DEBUG - 2025-03-26 13:23:22 --> Final JSON output: {"response":{"status":"ok","stock":[{"stock_qty":477,"product_id":"123456","product_name":"Pran Juice","product_model":"","unit":"Pcs","price":"25","totalPurchaseQnty":"572.00","totalSalesQnty":"95.00","total_sale_price":11925,"sl":1,"SubTotalOut":95,"SubTotalIn":572,"SubTotalStock":477},{"stock_qty":129,"product_id":"51252612252670","product_name":"Vegetable Pakora","product_model":null,"unit":"Box","price":"29.72","totalPurchaseQnty":"164.00","totalSalesQnty":"35.00","total_sale_price":3833.8799999999997,"sl":2,"SubTotalOut":130,"SubTotalIn":736,"SubTotalStock":606},{"stock_qty":-20,"product_id":"5998830","product_name":"Pran Mango Juice","product_model":null,"unit":"Pcs","price":"25","totalPurchaseQnty":0,"totalSalesQnty":"20.00","total_sale_price":-500,"sl":3,"SubTotalOut":150,"SubTotalIn":736,"SubTotalStock":586},{"stock_qty":0,"product_id":"79291734","product_name":"Ruhi Fish","product_model":null,"unit":"Pcs","price":"350","totalPurchaseQnty":0,"totalSalesQnty":0,"total_sale_price":0,"sl":4,"SubTotalOut":150,"SubTotalIn":736,"SubTotalStock":586},{"stock_qty":10,"product_id":"84213421","product_name":"Ruhi","product_model":null,"unit":"Pcs","price":"10","totalPurchaseQnty":"15.00","totalSalesQnty":"5.00","total_sale_price":100,"sl":5,"SubTotalOut":155,"SubTotalIn":751,"SubTotalStock":596}],"total_val":5,"permission":"read"}}
INFO - 2025-03-26 13:23:22 --> Final output sent to browser
DEBUG - 2025-03-26 13:23:22 --> Total execution time: 0.0136
