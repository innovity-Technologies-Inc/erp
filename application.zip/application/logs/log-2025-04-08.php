<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-08 08:41:10 --> Config Class Initialized
INFO - 2025-04-08 08:41:10 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:41:10 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:41:10 --> Utf8 Class Initialized
INFO - 2025-04-08 08:41:10 --> URI Class Initialized
DEBUG - 2025-04-08 08:41:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-08 08:41:10 --> Router Class Initialized
INFO - 2025-04-08 08:41:10 --> Output Class Initialized
INFO - 2025-04-08 08:41:10 --> Security Class Initialized
DEBUG - 2025-04-08 08:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:41:10 --> Input Class Initialized
INFO - 2025-04-08 08:41:10 --> Language Class Initialized
INFO - 2025-04-08 08:41:10 --> Language Class Initialized
INFO - 2025-04-08 08:41:10 --> Config Class Initialized
INFO - 2025-04-08 08:41:10 --> Loader Class Initialized
INFO - 2025-04-08 08:41:10 --> Helper loaded: url_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: file_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: html_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: form_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: text_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:41:10 --> Database Driver Class Initialized
INFO - 2025-04-08 08:41:10 --> Email Class Initialized
INFO - 2025-04-08 08:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:41:10 --> Form Validation Class Initialized
INFO - 2025-04-08 08:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:41:10 --> Pagination Class Initialized
INFO - 2025-04-08 08:41:10 --> Controller Class Initialized
DEBUG - 2025-04-08 08:41:10 --> Customer MX_Controller Initialized
INFO - 2025-04-08 08:41:10 --> Model Class Initialized
DEBUG - 2025-04-08 08:41:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 08:41:10 --> Model Class Initialized
INFO - 2025-04-08 08:41:10 --> Config Class Initialized
INFO - 2025-04-08 08:41:10 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:41:10 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:41:10 --> Utf8 Class Initialized
INFO - 2025-04-08 08:41:10 --> URI Class Initialized
DEBUG - 2025-04-08 08:41:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-08 08:41:10 --> Router Class Initialized
INFO - 2025-04-08 08:41:10 --> Output Class Initialized
INFO - 2025-04-08 08:41:10 --> Security Class Initialized
DEBUG - 2025-04-08 08:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:41:10 --> Input Class Initialized
INFO - 2025-04-08 08:41:10 --> Language Class Initialized
INFO - 2025-04-08 08:41:10 --> Language Class Initialized
INFO - 2025-04-08 08:41:10 --> Config Class Initialized
INFO - 2025-04-08 08:41:10 --> Loader Class Initialized
INFO - 2025-04-08 08:41:10 --> Helper loaded: url_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: file_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: html_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: form_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: text_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:41:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:41:10 --> Database Driver Class Initialized
INFO - 2025-04-08 08:41:10 --> Email Class Initialized
INFO - 2025-04-08 08:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:41:10 --> Form Validation Class Initialized
INFO - 2025-04-08 08:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:41:10 --> Pagination Class Initialized
INFO - 2025-04-08 08:41:10 --> Controller Class Initialized
DEBUG - 2025-04-08 08:41:10 --> Auth MX_Controller Initialized
INFO - 2025-04-08 08:41:10 --> Model Class Initialized
DEBUG - 2025-04-08 08:41:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-08 08:41:10 --> Model Class Initialized
DEBUG - 2025-04-08 08:41:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 08:41:10 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 08:41:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 08:41:10 --> Model Class Initialized
DEBUG - 2025-04-08 08:41:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-08 08:41:10 --> Final output sent to browser
DEBUG - 2025-04-08 08:41:10 --> Total execution time: 0.0251
INFO - 2025-04-08 08:41:21 --> Config Class Initialized
INFO - 2025-04-08 08:41:21 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:41:21 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:41:21 --> Utf8 Class Initialized
INFO - 2025-04-08 08:41:21 --> URI Class Initialized
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-08 08:41:21 --> Router Class Initialized
INFO - 2025-04-08 08:41:21 --> Output Class Initialized
INFO - 2025-04-08 08:41:21 --> Security Class Initialized
DEBUG - 2025-04-08 08:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:41:21 --> Input Class Initialized
INFO - 2025-04-08 08:41:21 --> Language Class Initialized
INFO - 2025-04-08 08:41:21 --> Language Class Initialized
INFO - 2025-04-08 08:41:21 --> Config Class Initialized
INFO - 2025-04-08 08:41:21 --> Loader Class Initialized
INFO - 2025-04-08 08:41:21 --> Helper loaded: url_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: file_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: html_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: form_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: text_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:41:21 --> Database Driver Class Initialized
INFO - 2025-04-08 08:41:21 --> Email Class Initialized
INFO - 2025-04-08 08:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:41:21 --> Form Validation Class Initialized
INFO - 2025-04-08 08:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:41:21 --> Pagination Class Initialized
INFO - 2025-04-08 08:41:21 --> Controller Class Initialized
DEBUG - 2025-04-08 08:41:21 --> Auth MX_Controller Initialized
INFO - 2025-04-08 08:41:21 --> Model Class Initialized
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-08 08:41:21 --> Model Class Initialized
INFO - 2025-04-08 08:41:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-08 08:41:21 --> Config Class Initialized
INFO - 2025-04-08 08:41:21 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:41:21 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:41:21 --> Utf8 Class Initialized
INFO - 2025-04-08 08:41:21 --> URI Class Initialized
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-08 08:41:21 --> Router Class Initialized
INFO - 2025-04-08 08:41:21 --> Output Class Initialized
INFO - 2025-04-08 08:41:21 --> Security Class Initialized
DEBUG - 2025-04-08 08:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:41:21 --> Input Class Initialized
INFO - 2025-04-08 08:41:21 --> Language Class Initialized
INFO - 2025-04-08 08:41:21 --> Language Class Initialized
INFO - 2025-04-08 08:41:21 --> Config Class Initialized
INFO - 2025-04-08 08:41:21 --> Loader Class Initialized
INFO - 2025-04-08 08:41:21 --> Helper loaded: url_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: file_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: html_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: form_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: text_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:41:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:41:21 --> Database Driver Class Initialized
INFO - 2025-04-08 08:41:21 --> Email Class Initialized
INFO - 2025-04-08 08:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:41:21 --> Form Validation Class Initialized
INFO - 2025-04-08 08:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:41:21 --> Pagination Class Initialized
INFO - 2025-04-08 08:41:21 --> Controller Class Initialized
DEBUG - 2025-04-08 08:41:21 --> Home MX_Controller Initialized
INFO - 2025-04-08 08:41:21 --> Model Class Initialized
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-08 08:41:21 --> Model Class Initialized
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 08:41:21 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 08:41:21 --> Model Class Initialized
ERROR - 2025-04-08 08:41:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 08:41:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 08:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 08:41:21 --> Final output sent to browser
DEBUG - 2025-04-08 08:41:21 --> Total execution time: 0.5907
INFO - 2025-04-08 08:43:31 --> Config Class Initialized
INFO - 2025-04-08 08:43:31 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:43:31 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:43:31 --> Utf8 Class Initialized
INFO - 2025-04-08 08:43:31 --> URI Class Initialized
DEBUG - 2025-04-08 08:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 08:43:31 --> Router Class Initialized
INFO - 2025-04-08 08:43:31 --> Output Class Initialized
INFO - 2025-04-08 08:43:31 --> Security Class Initialized
DEBUG - 2025-04-08 08:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:43:31 --> Input Class Initialized
INFO - 2025-04-08 08:43:31 --> Language Class Initialized
INFO - 2025-04-08 08:43:31 --> Language Class Initialized
INFO - 2025-04-08 08:43:31 --> Config Class Initialized
INFO - 2025-04-08 08:43:31 --> Loader Class Initialized
INFO - 2025-04-08 08:43:31 --> Helper loaded: url_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: file_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: html_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: form_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: text_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:43:31 --> Database Driver Class Initialized
INFO - 2025-04-08 08:43:31 --> Email Class Initialized
INFO - 2025-04-08 08:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:43:31 --> Form Validation Class Initialized
INFO - 2025-04-08 08:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:43:31 --> Pagination Class Initialized
INFO - 2025-04-08 08:43:31 --> Controller Class Initialized
DEBUG - 2025-04-08 08:43:31 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 14:43:31 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
ERROR - 2025-04-08 14:43:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 14:43:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 14:43:31 --> Final output sent to browser
DEBUG - 2025-04-08 14:43:31 --> Total execution time: 0.1471
INFO - 2025-04-08 08:43:31 --> Config Class Initialized
INFO - 2025-04-08 08:43:31 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:43:31 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:43:31 --> Utf8 Class Initialized
INFO - 2025-04-08 08:43:31 --> URI Class Initialized
DEBUG - 2025-04-08 08:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 08:43:31 --> Router Class Initialized
INFO - 2025-04-08 08:43:31 --> Output Class Initialized
INFO - 2025-04-08 08:43:31 --> Security Class Initialized
DEBUG - 2025-04-08 08:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:43:31 --> Input Class Initialized
INFO - 2025-04-08 08:43:31 --> Language Class Initialized
INFO - 2025-04-08 08:43:31 --> Language Class Initialized
INFO - 2025-04-08 08:43:31 --> Config Class Initialized
INFO - 2025-04-08 08:43:31 --> Loader Class Initialized
INFO - 2025-04-08 08:43:31 --> Helper loaded: url_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: file_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: html_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: form_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: text_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:43:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:43:31 --> Database Driver Class Initialized
INFO - 2025-04-08 08:43:31 --> Email Class Initialized
INFO - 2025-04-08 08:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:43:31 --> Form Validation Class Initialized
INFO - 2025-04-08 08:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:43:31 --> Pagination Class Initialized
INFO - 2025-04-08 08:43:31 --> Controller Class Initialized
DEBUG - 2025-04-08 08:43:31 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
DEBUG - 2025-04-08 14:43:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 14:43:31 --> Model Class Initialized
INFO - 2025-04-08 14:43:31 --> Final output sent to browser
DEBUG - 2025-04-08 14:43:31 --> Total execution time: 0.0526
INFO - 2025-04-08 08:52:37 --> Config Class Initialized
INFO - 2025-04-08 08:52:37 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:52:37 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:52:37 --> Utf8 Class Initialized
INFO - 2025-04-08 08:52:37 --> URI Class Initialized
DEBUG - 2025-04-08 08:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 08:52:37 --> Router Class Initialized
INFO - 2025-04-08 08:52:37 --> Output Class Initialized
INFO - 2025-04-08 08:52:37 --> Security Class Initialized
DEBUG - 2025-04-08 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:52:37 --> Input Class Initialized
INFO - 2025-04-08 08:52:37 --> Language Class Initialized
INFO - 2025-04-08 08:52:37 --> Language Class Initialized
INFO - 2025-04-08 08:52:37 --> Config Class Initialized
INFO - 2025-04-08 08:52:37 --> Loader Class Initialized
INFO - 2025-04-08 08:52:37 --> Helper loaded: url_helper
INFO - 2025-04-08 08:52:37 --> Helper loaded: file_helper
INFO - 2025-04-08 08:52:37 --> Helper loaded: html_helper
INFO - 2025-04-08 08:52:37 --> Helper loaded: form_helper
INFO - 2025-04-08 08:52:37 --> Helper loaded: text_helper
INFO - 2025-04-08 08:52:37 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:52:37 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:52:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:52:37 --> Database Driver Class Initialized
INFO - 2025-04-08 08:52:37 --> Email Class Initialized
INFO - 2025-04-08 08:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:52:37 --> Form Validation Class Initialized
INFO - 2025-04-08 08:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:52:37 --> Pagination Class Initialized
INFO - 2025-04-08 08:52:37 --> Controller Class Initialized
DEBUG - 2025-04-08 08:52:37 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 14:52:37 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 14:52:37 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 14:52:37 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 14:52:37 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 14:52:37 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 14:52:37 --> Model Class Initialized
ERROR - 2025-04-08 14:52:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 14:52:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/terms_list.php
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 14:52:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 14:52:37 --> Final output sent to browser
DEBUG - 2025-04-08 14:52:37 --> Total execution time: 0.1481
INFO - 2025-04-08 08:52:48 --> Config Class Initialized
INFO - 2025-04-08 08:52:48 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:52:48 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:52:48 --> Utf8 Class Initialized
INFO - 2025-04-08 08:52:48 --> URI Class Initialized
DEBUG - 2025-04-08 08:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 08:52:48 --> Router Class Initialized
INFO - 2025-04-08 08:52:48 --> Output Class Initialized
INFO - 2025-04-08 08:52:48 --> Security Class Initialized
DEBUG - 2025-04-08 08:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:52:48 --> Input Class Initialized
INFO - 2025-04-08 08:52:48 --> Language Class Initialized
INFO - 2025-04-08 08:52:48 --> Language Class Initialized
INFO - 2025-04-08 08:52:48 --> Config Class Initialized
INFO - 2025-04-08 08:52:48 --> Loader Class Initialized
INFO - 2025-04-08 08:52:48 --> Helper loaded: url_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: file_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: html_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: form_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: text_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:52:48 --> Database Driver Class Initialized
INFO - 2025-04-08 08:52:48 --> Email Class Initialized
INFO - 2025-04-08 08:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:52:48 --> Form Validation Class Initialized
INFO - 2025-04-08 08:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:52:48 --> Pagination Class Initialized
INFO - 2025-04-08 08:52:48 --> Controller Class Initialized
DEBUG - 2025-04-08 08:52:48 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 14:52:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
ERROR - 2025-04-08 14:52:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 14:52:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 14:52:48 --> Final output sent to browser
DEBUG - 2025-04-08 14:52:48 --> Total execution time: 0.1720
INFO - 2025-04-08 08:52:48 --> Config Class Initialized
INFO - 2025-04-08 08:52:48 --> Hooks Class Initialized
DEBUG - 2025-04-08 08:52:48 --> UTF-8 Support Enabled
INFO - 2025-04-08 08:52:48 --> Utf8 Class Initialized
INFO - 2025-04-08 08:52:48 --> URI Class Initialized
DEBUG - 2025-04-08 08:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 08:52:48 --> Router Class Initialized
INFO - 2025-04-08 08:52:48 --> Output Class Initialized
INFO - 2025-04-08 08:52:48 --> Security Class Initialized
DEBUG - 2025-04-08 08:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 08:52:48 --> Input Class Initialized
INFO - 2025-04-08 08:52:48 --> Language Class Initialized
INFO - 2025-04-08 08:52:48 --> Language Class Initialized
INFO - 2025-04-08 08:52:48 --> Config Class Initialized
INFO - 2025-04-08 08:52:48 --> Loader Class Initialized
INFO - 2025-04-08 08:52:48 --> Helper loaded: url_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: file_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: html_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: form_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: text_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: lang_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: directory_helper
INFO - 2025-04-08 08:52:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 08:52:48 --> Database Driver Class Initialized
INFO - 2025-04-08 08:52:48 --> Email Class Initialized
INFO - 2025-04-08 08:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 08:52:48 --> Form Validation Class Initialized
INFO - 2025-04-08 08:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 08:52:48 --> Pagination Class Initialized
INFO - 2025-04-08 08:52:48 --> Controller Class Initialized
DEBUG - 2025-04-08 08:52:48 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
DEBUG - 2025-04-08 14:52:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 14:52:48 --> Model Class Initialized
INFO - 2025-04-08 14:52:48 --> Final output sent to browser
DEBUG - 2025-04-08 14:52:48 --> Total execution time: 0.0571
INFO - 2025-04-08 09:48:22 --> Config Class Initialized
INFO - 2025-04-08 09:48:22 --> Hooks Class Initialized
DEBUG - 2025-04-08 09:48:22 --> UTF-8 Support Enabled
INFO - 2025-04-08 09:48:22 --> Utf8 Class Initialized
INFO - 2025-04-08 09:48:22 --> URI Class Initialized
DEBUG - 2025-04-08 09:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 09:48:22 --> Router Class Initialized
INFO - 2025-04-08 09:48:22 --> Output Class Initialized
INFO - 2025-04-08 09:48:22 --> Security Class Initialized
DEBUG - 2025-04-08 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 09:48:22 --> Input Class Initialized
INFO - 2025-04-08 09:48:22 --> Language Class Initialized
INFO - 2025-04-08 09:48:22 --> Language Class Initialized
INFO - 2025-04-08 09:48:22 --> Config Class Initialized
INFO - 2025-04-08 09:48:22 --> Loader Class Initialized
INFO - 2025-04-08 09:48:22 --> Helper loaded: url_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: file_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: html_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: form_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: text_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: lang_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: directory_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 09:48:22 --> Database Driver Class Initialized
INFO - 2025-04-08 09:48:22 --> Email Class Initialized
INFO - 2025-04-08 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 09:48:22 --> Form Validation Class Initialized
INFO - 2025-04-08 09:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 09:48:22 --> Pagination Class Initialized
INFO - 2025-04-08 09:48:22 --> Controller Class Initialized
DEBUG - 2025-04-08 09:48:22 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 15:48:22 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
ERROR - 2025-04-08 15:48:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 15:48:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 15:48:22 --> Final output sent to browser
DEBUG - 2025-04-08 15:48:22 --> Total execution time: 0.5436
INFO - 2025-04-08 09:48:22 --> Config Class Initialized
INFO - 2025-04-08 09:48:22 --> Hooks Class Initialized
DEBUG - 2025-04-08 09:48:22 --> UTF-8 Support Enabled
INFO - 2025-04-08 09:48:22 --> Utf8 Class Initialized
INFO - 2025-04-08 09:48:22 --> URI Class Initialized
DEBUG - 2025-04-08 09:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 09:48:22 --> Router Class Initialized
INFO - 2025-04-08 09:48:22 --> Output Class Initialized
INFO - 2025-04-08 09:48:22 --> Security Class Initialized
DEBUG - 2025-04-08 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 09:48:22 --> Input Class Initialized
INFO - 2025-04-08 09:48:22 --> Language Class Initialized
INFO - 2025-04-08 09:48:22 --> Language Class Initialized
INFO - 2025-04-08 09:48:22 --> Config Class Initialized
INFO - 2025-04-08 09:48:22 --> Loader Class Initialized
INFO - 2025-04-08 09:48:22 --> Helper loaded: url_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: file_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: html_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: form_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: text_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: lang_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: directory_helper
INFO - 2025-04-08 09:48:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 09:48:22 --> Database Driver Class Initialized
INFO - 2025-04-08 09:48:22 --> Email Class Initialized
INFO - 2025-04-08 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 09:48:22 --> Form Validation Class Initialized
INFO - 2025-04-08 09:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 09:48:22 --> Pagination Class Initialized
INFO - 2025-04-08 09:48:22 --> Controller Class Initialized
DEBUG - 2025-04-08 09:48:22 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
DEBUG - 2025-04-08 15:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 15:48:22 --> Model Class Initialized
INFO - 2025-04-08 15:48:22 --> Final output sent to browser
DEBUG - 2025-04-08 15:48:22 --> Total execution time: 0.0526
INFO - 2025-04-08 10:55:20 --> Config Class Initialized
INFO - 2025-04-08 10:55:20 --> Hooks Class Initialized
DEBUG - 2025-04-08 10:55:20 --> UTF-8 Support Enabled
INFO - 2025-04-08 10:55:20 --> Utf8 Class Initialized
INFO - 2025-04-08 10:55:20 --> URI Class Initialized
DEBUG - 2025-04-08 10:55:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 10:55:20 --> Router Class Initialized
INFO - 2025-04-08 10:55:20 --> Output Class Initialized
INFO - 2025-04-08 10:55:20 --> Security Class Initialized
DEBUG - 2025-04-08 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 10:55:20 --> Input Class Initialized
INFO - 2025-04-08 10:55:20 --> Language Class Initialized
INFO - 2025-04-08 10:55:20 --> Language Class Initialized
INFO - 2025-04-08 10:55:20 --> Config Class Initialized
INFO - 2025-04-08 10:55:20 --> Loader Class Initialized
INFO - 2025-04-08 10:55:20 --> Helper loaded: url_helper
INFO - 2025-04-08 10:55:20 --> Helper loaded: file_helper
INFO - 2025-04-08 10:55:20 --> Helper loaded: html_helper
INFO - 2025-04-08 10:55:20 --> Helper loaded: form_helper
INFO - 2025-04-08 10:55:20 --> Helper loaded: text_helper
INFO - 2025-04-08 10:55:20 --> Helper loaded: lang_helper
INFO - 2025-04-08 10:55:20 --> Helper loaded: directory_helper
INFO - 2025-04-08 10:55:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 10:55:20 --> Database Driver Class Initialized
INFO - 2025-04-08 10:55:20 --> Email Class Initialized
INFO - 2025-04-08 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 10:55:20 --> Form Validation Class Initialized
INFO - 2025-04-08 10:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 10:55:20 --> Pagination Class Initialized
INFO - 2025-04-08 10:55:20 --> Controller Class Initialized
DEBUG - 2025-04-08 10:55:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 16:55:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:55:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 16:55:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:55:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 16:55:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:55:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 16:55:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:55:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 16:55:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 16:55:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 16:55:20 --> Model Class Initialized
ERROR - 2025-04-08 16:55:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 16:55:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 16:55:21 --> Final output sent to browser
DEBUG - 2025-04-08 16:55:21 --> Total execution time: 0.7182
INFO - 2025-04-08 10:55:21 --> Config Class Initialized
INFO - 2025-04-08 10:55:21 --> Hooks Class Initialized
DEBUG - 2025-04-08 10:55:21 --> UTF-8 Support Enabled
INFO - 2025-04-08 10:55:21 --> Utf8 Class Initialized
INFO - 2025-04-08 10:55:21 --> URI Class Initialized
DEBUG - 2025-04-08 10:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 10:55:21 --> Router Class Initialized
INFO - 2025-04-08 10:55:21 --> Output Class Initialized
INFO - 2025-04-08 10:55:21 --> Security Class Initialized
DEBUG - 2025-04-08 10:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 10:55:21 --> Input Class Initialized
INFO - 2025-04-08 10:55:21 --> Language Class Initialized
INFO - 2025-04-08 10:55:21 --> Language Class Initialized
INFO - 2025-04-08 10:55:21 --> Config Class Initialized
INFO - 2025-04-08 10:55:21 --> Loader Class Initialized
INFO - 2025-04-08 10:55:21 --> Helper loaded: url_helper
INFO - 2025-04-08 10:55:21 --> Helper loaded: file_helper
INFO - 2025-04-08 10:55:21 --> Helper loaded: html_helper
INFO - 2025-04-08 10:55:21 --> Helper loaded: form_helper
INFO - 2025-04-08 10:55:21 --> Helper loaded: text_helper
INFO - 2025-04-08 10:55:21 --> Helper loaded: lang_helper
INFO - 2025-04-08 10:55:21 --> Helper loaded: directory_helper
INFO - 2025-04-08 10:55:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 10:55:21 --> Database Driver Class Initialized
INFO - 2025-04-08 10:55:21 --> Email Class Initialized
INFO - 2025-04-08 10:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 10:55:21 --> Form Validation Class Initialized
INFO - 2025-04-08 10:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 10:55:21 --> Pagination Class Initialized
INFO - 2025-04-08 10:55:21 --> Controller Class Initialized
DEBUG - 2025-04-08 10:55:21 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 16:55:21 --> Model Class Initialized
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 16:55:21 --> Model Class Initialized
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 16:55:21 --> Model Class Initialized
DEBUG - 2025-04-08 16:55:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 16:55:21 --> Model Class Initialized
INFO - 2025-04-08 16:55:21 --> Final output sent to browser
DEBUG - 2025-04-08 16:55:21 --> Total execution time: 0.0499
INFO - 2025-04-08 10:57:05 --> Config Class Initialized
INFO - 2025-04-08 10:57:05 --> Hooks Class Initialized
DEBUG - 2025-04-08 10:57:05 --> UTF-8 Support Enabled
INFO - 2025-04-08 10:57:05 --> Utf8 Class Initialized
INFO - 2025-04-08 10:57:05 --> URI Class Initialized
DEBUG - 2025-04-08 10:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 10:57:05 --> Router Class Initialized
INFO - 2025-04-08 10:57:05 --> Output Class Initialized
INFO - 2025-04-08 10:57:05 --> Security Class Initialized
DEBUG - 2025-04-08 10:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 10:57:05 --> Input Class Initialized
INFO - 2025-04-08 10:57:05 --> Language Class Initialized
INFO - 2025-04-08 10:57:05 --> Language Class Initialized
INFO - 2025-04-08 10:57:05 --> Config Class Initialized
INFO - 2025-04-08 10:57:05 --> Loader Class Initialized
INFO - 2025-04-08 10:57:05 --> Helper loaded: url_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: file_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: html_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: form_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: text_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: lang_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: directory_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 10:57:05 --> Database Driver Class Initialized
INFO - 2025-04-08 10:57:05 --> Email Class Initialized
INFO - 2025-04-08 10:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 10:57:05 --> Form Validation Class Initialized
INFO - 2025-04-08 10:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 10:57:05 --> Pagination Class Initialized
INFO - 2025-04-08 10:57:05 --> Controller Class Initialized
DEBUG - 2025-04-08 10:57:05 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 16:57:05 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
ERROR - 2025-04-08 16:57:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 16:57:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 16:57:05 --> Final output sent to browser
DEBUG - 2025-04-08 16:57:05 --> Total execution time: 0.1785
INFO - 2025-04-08 10:57:05 --> Config Class Initialized
INFO - 2025-04-08 10:57:05 --> Hooks Class Initialized
DEBUG - 2025-04-08 10:57:05 --> UTF-8 Support Enabled
INFO - 2025-04-08 10:57:05 --> Utf8 Class Initialized
INFO - 2025-04-08 10:57:05 --> URI Class Initialized
DEBUG - 2025-04-08 10:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 10:57:05 --> Router Class Initialized
INFO - 2025-04-08 10:57:05 --> Output Class Initialized
INFO - 2025-04-08 10:57:05 --> Security Class Initialized
DEBUG - 2025-04-08 10:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 10:57:05 --> Input Class Initialized
INFO - 2025-04-08 10:57:05 --> Language Class Initialized
INFO - 2025-04-08 10:57:05 --> Language Class Initialized
INFO - 2025-04-08 10:57:05 --> Config Class Initialized
INFO - 2025-04-08 10:57:05 --> Loader Class Initialized
INFO - 2025-04-08 10:57:05 --> Helper loaded: url_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: file_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: html_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: form_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: text_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: lang_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: directory_helper
INFO - 2025-04-08 10:57:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 10:57:05 --> Database Driver Class Initialized
INFO - 2025-04-08 10:57:05 --> Email Class Initialized
INFO - 2025-04-08 10:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 10:57:05 --> Form Validation Class Initialized
INFO - 2025-04-08 10:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 10:57:05 --> Pagination Class Initialized
INFO - 2025-04-08 10:57:05 --> Controller Class Initialized
DEBUG - 2025-04-08 10:57:05 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
DEBUG - 2025-04-08 16:57:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 16:57:05 --> Model Class Initialized
INFO - 2025-04-08 16:57:05 --> Final output sent to browser
DEBUG - 2025-04-08 16:57:05 --> Total execution time: 0.0395
INFO - 2025-04-08 10:59:20 --> Config Class Initialized
INFO - 2025-04-08 10:59:20 --> Hooks Class Initialized
DEBUG - 2025-04-08 10:59:20 --> UTF-8 Support Enabled
INFO - 2025-04-08 10:59:20 --> Utf8 Class Initialized
INFO - 2025-04-08 10:59:20 --> URI Class Initialized
DEBUG - 2025-04-08 10:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 10:59:20 --> Router Class Initialized
INFO - 2025-04-08 10:59:20 --> Output Class Initialized
INFO - 2025-04-08 10:59:20 --> Security Class Initialized
DEBUG - 2025-04-08 10:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 10:59:20 --> Input Class Initialized
INFO - 2025-04-08 10:59:20 --> Language Class Initialized
INFO - 2025-04-08 10:59:20 --> Language Class Initialized
INFO - 2025-04-08 10:59:20 --> Config Class Initialized
INFO - 2025-04-08 10:59:20 --> Loader Class Initialized
INFO - 2025-04-08 10:59:20 --> Helper loaded: url_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: file_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: html_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: form_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: text_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: lang_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: directory_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 10:59:20 --> Database Driver Class Initialized
INFO - 2025-04-08 10:59:20 --> Email Class Initialized
INFO - 2025-04-08 10:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 10:59:20 --> Form Validation Class Initialized
INFO - 2025-04-08 10:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 10:59:20 --> Pagination Class Initialized
INFO - 2025-04-08 10:59:20 --> Controller Class Initialized
DEBUG - 2025-04-08 10:59:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 16:59:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
ERROR - 2025-04-08 16:59:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 16:59:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 16:59:20 --> Final output sent to browser
DEBUG - 2025-04-08 16:59:20 --> Total execution time: 0.2008
INFO - 2025-04-08 10:59:20 --> Config Class Initialized
INFO - 2025-04-08 10:59:20 --> Hooks Class Initialized
DEBUG - 2025-04-08 10:59:20 --> UTF-8 Support Enabled
INFO - 2025-04-08 10:59:20 --> Utf8 Class Initialized
INFO - 2025-04-08 10:59:20 --> URI Class Initialized
DEBUG - 2025-04-08 10:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 10:59:20 --> Router Class Initialized
INFO - 2025-04-08 10:59:20 --> Output Class Initialized
INFO - 2025-04-08 10:59:20 --> Security Class Initialized
DEBUG - 2025-04-08 10:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 10:59:20 --> Input Class Initialized
INFO - 2025-04-08 10:59:20 --> Language Class Initialized
INFO - 2025-04-08 10:59:20 --> Language Class Initialized
INFO - 2025-04-08 10:59:20 --> Config Class Initialized
INFO - 2025-04-08 10:59:20 --> Loader Class Initialized
INFO - 2025-04-08 10:59:20 --> Helper loaded: url_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: file_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: html_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: form_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: text_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: lang_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: directory_helper
INFO - 2025-04-08 10:59:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 10:59:20 --> Database Driver Class Initialized
INFO - 2025-04-08 10:59:20 --> Email Class Initialized
INFO - 2025-04-08 10:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 10:59:20 --> Form Validation Class Initialized
INFO - 2025-04-08 10:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 10:59:20 --> Pagination Class Initialized
INFO - 2025-04-08 10:59:20 --> Controller Class Initialized
DEBUG - 2025-04-08 10:59:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
DEBUG - 2025-04-08 16:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 16:59:20 --> Model Class Initialized
INFO - 2025-04-08 16:59:20 --> Final output sent to browser
DEBUG - 2025-04-08 16:59:20 --> Total execution time: 0.0644
INFO - 2025-04-08 11:02:06 --> Config Class Initialized
INFO - 2025-04-08 11:02:06 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:02:06 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:02:06 --> Utf8 Class Initialized
INFO - 2025-04-08 11:02:06 --> URI Class Initialized
DEBUG - 2025-04-08 11:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:02:06 --> Router Class Initialized
INFO - 2025-04-08 11:02:06 --> Output Class Initialized
INFO - 2025-04-08 11:02:06 --> Security Class Initialized
DEBUG - 2025-04-08 11:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:02:06 --> Input Class Initialized
INFO - 2025-04-08 11:02:06 --> Language Class Initialized
INFO - 2025-04-08 11:02:06 --> Language Class Initialized
INFO - 2025-04-08 11:02:06 --> Config Class Initialized
INFO - 2025-04-08 11:02:06 --> Loader Class Initialized
INFO - 2025-04-08 11:02:06 --> Helper loaded: url_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: file_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: html_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: form_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: text_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:02:06 --> Database Driver Class Initialized
INFO - 2025-04-08 11:02:06 --> Email Class Initialized
INFO - 2025-04-08 11:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:02:06 --> Form Validation Class Initialized
INFO - 2025-04-08 11:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:02:06 --> Pagination Class Initialized
INFO - 2025-04-08 11:02:06 --> Controller Class Initialized
DEBUG - 2025-04-08 11:02:06 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:02:06 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
ERROR - 2025-04-08 17:02:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:02:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:02:06 --> Final output sent to browser
DEBUG - 2025-04-08 17:02:06 --> Total execution time: 0.2032
INFO - 2025-04-08 11:02:06 --> Config Class Initialized
INFO - 2025-04-08 11:02:06 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:02:06 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:02:06 --> Utf8 Class Initialized
INFO - 2025-04-08 11:02:06 --> URI Class Initialized
DEBUG - 2025-04-08 11:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:02:06 --> Router Class Initialized
INFO - 2025-04-08 11:02:06 --> Output Class Initialized
INFO - 2025-04-08 11:02:06 --> Security Class Initialized
DEBUG - 2025-04-08 11:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:02:06 --> Input Class Initialized
INFO - 2025-04-08 11:02:06 --> Language Class Initialized
INFO - 2025-04-08 11:02:06 --> Language Class Initialized
INFO - 2025-04-08 11:02:06 --> Config Class Initialized
INFO - 2025-04-08 11:02:06 --> Loader Class Initialized
INFO - 2025-04-08 11:02:06 --> Helper loaded: url_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: file_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: html_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: form_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: text_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:02:06 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:02:06 --> Database Driver Class Initialized
INFO - 2025-04-08 11:02:06 --> Email Class Initialized
INFO - 2025-04-08 11:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:02:06 --> Form Validation Class Initialized
INFO - 2025-04-08 11:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:02:06 --> Pagination Class Initialized
INFO - 2025-04-08 11:02:06 --> Controller Class Initialized
DEBUG - 2025-04-08 11:02:06 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:02:06 --> Model Class Initialized
INFO - 2025-04-08 17:02:06 --> Final output sent to browser
DEBUG - 2025-04-08 17:02:06 --> Total execution time: 0.0428
INFO - 2025-04-08 11:02:50 --> Config Class Initialized
INFO - 2025-04-08 11:02:50 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:02:50 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:02:50 --> Utf8 Class Initialized
INFO - 2025-04-08 11:02:50 --> URI Class Initialized
DEBUG - 2025-04-08 11:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:02:50 --> Router Class Initialized
INFO - 2025-04-08 11:02:50 --> Output Class Initialized
INFO - 2025-04-08 11:02:50 --> Security Class Initialized
DEBUG - 2025-04-08 11:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:02:50 --> Input Class Initialized
INFO - 2025-04-08 11:02:50 --> Language Class Initialized
INFO - 2025-04-08 11:02:50 --> Language Class Initialized
INFO - 2025-04-08 11:02:50 --> Config Class Initialized
INFO - 2025-04-08 11:02:50 --> Loader Class Initialized
INFO - 2025-04-08 11:02:50 --> Helper loaded: url_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: file_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: html_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: form_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: text_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:02:50 --> Database Driver Class Initialized
INFO - 2025-04-08 11:02:50 --> Email Class Initialized
INFO - 2025-04-08 11:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:02:50 --> Form Validation Class Initialized
INFO - 2025-04-08 11:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:02:50 --> Pagination Class Initialized
INFO - 2025-04-08 11:02:50 --> Controller Class Initialized
DEBUG - 2025-04-08 11:02:50 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:02:50 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
ERROR - 2025-04-08 17:02:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:02:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:02:50 --> Final output sent to browser
DEBUG - 2025-04-08 17:02:50 --> Total execution time: 0.1648
INFO - 2025-04-08 11:02:50 --> Config Class Initialized
INFO - 2025-04-08 11:02:50 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:02:50 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:02:50 --> Utf8 Class Initialized
INFO - 2025-04-08 11:02:50 --> URI Class Initialized
DEBUG - 2025-04-08 11:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:02:50 --> Router Class Initialized
INFO - 2025-04-08 11:02:50 --> Output Class Initialized
INFO - 2025-04-08 11:02:50 --> Security Class Initialized
DEBUG - 2025-04-08 11:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:02:50 --> Input Class Initialized
INFO - 2025-04-08 11:02:50 --> Language Class Initialized
INFO - 2025-04-08 11:02:50 --> Language Class Initialized
INFO - 2025-04-08 11:02:50 --> Config Class Initialized
INFO - 2025-04-08 11:02:50 --> Loader Class Initialized
INFO - 2025-04-08 11:02:50 --> Helper loaded: url_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: file_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: html_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: form_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: text_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:02:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:02:50 --> Database Driver Class Initialized
INFO - 2025-04-08 11:02:50 --> Email Class Initialized
INFO - 2025-04-08 11:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:02:50 --> Form Validation Class Initialized
INFO - 2025-04-08 11:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:02:50 --> Pagination Class Initialized
INFO - 2025-04-08 11:02:50 --> Controller Class Initialized
DEBUG - 2025-04-08 11:02:50 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:02:50 --> Model Class Initialized
INFO - 2025-04-08 17:02:50 --> Final output sent to browser
DEBUG - 2025-04-08 17:02:50 --> Total execution time: 0.0407
INFO - 2025-04-08 11:03:05 --> Config Class Initialized
INFO - 2025-04-08 11:03:05 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:03:05 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:03:05 --> Utf8 Class Initialized
INFO - 2025-04-08 11:03:05 --> URI Class Initialized
INFO - 2025-04-08 11:03:05 --> Router Class Initialized
INFO - 2025-04-08 11:03:05 --> Output Class Initialized
INFO - 2025-04-08 11:03:05 --> Security Class Initialized
DEBUG - 2025-04-08 11:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:03:05 --> Input Class Initialized
INFO - 2025-04-08 11:03:05 --> Language Class Initialized
ERROR - 2025-04-08 11:03:05 --> 404 Page Not Found: /index
INFO - 2025-04-08 11:03:09 --> Config Class Initialized
INFO - 2025-04-08 11:03:09 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:03:09 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:03:09 --> Utf8 Class Initialized
INFO - 2025-04-08 11:03:09 --> URI Class Initialized
DEBUG - 2025-04-08 11:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:03:09 --> Router Class Initialized
INFO - 2025-04-08 11:03:09 --> Output Class Initialized
INFO - 2025-04-08 11:03:09 --> Security Class Initialized
DEBUG - 2025-04-08 11:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:03:09 --> Input Class Initialized
INFO - 2025-04-08 11:03:09 --> Language Class Initialized
INFO - 2025-04-08 11:03:09 --> Language Class Initialized
INFO - 2025-04-08 11:03:09 --> Config Class Initialized
INFO - 2025-04-08 11:03:09 --> Loader Class Initialized
INFO - 2025-04-08 11:03:09 --> Helper loaded: url_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: file_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: html_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: form_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: text_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:03:09 --> Database Driver Class Initialized
INFO - 2025-04-08 11:03:09 --> Email Class Initialized
INFO - 2025-04-08 11:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:03:09 --> Form Validation Class Initialized
INFO - 2025-04-08 11:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:03:09 --> Pagination Class Initialized
INFO - 2025-04-08 11:03:09 --> Controller Class Initialized
DEBUG - 2025-04-08 11:03:09 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:03:09 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
ERROR - 2025-04-08 17:03:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:03:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:03:09 --> Final output sent to browser
DEBUG - 2025-04-08 17:03:09 --> Total execution time: 0.1641
INFO - 2025-04-08 11:03:09 --> Config Class Initialized
INFO - 2025-04-08 11:03:09 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:03:09 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:03:09 --> Utf8 Class Initialized
INFO - 2025-04-08 11:03:09 --> URI Class Initialized
DEBUG - 2025-04-08 11:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:03:09 --> Router Class Initialized
INFO - 2025-04-08 11:03:09 --> Output Class Initialized
INFO - 2025-04-08 11:03:09 --> Security Class Initialized
DEBUG - 2025-04-08 11:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:03:09 --> Input Class Initialized
INFO - 2025-04-08 11:03:09 --> Language Class Initialized
INFO - 2025-04-08 11:03:09 --> Language Class Initialized
INFO - 2025-04-08 11:03:09 --> Config Class Initialized
INFO - 2025-04-08 11:03:09 --> Loader Class Initialized
INFO - 2025-04-08 11:03:09 --> Helper loaded: url_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: file_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: html_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: form_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: text_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:03:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:03:09 --> Database Driver Class Initialized
INFO - 2025-04-08 11:03:09 --> Email Class Initialized
INFO - 2025-04-08 11:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:03:09 --> Form Validation Class Initialized
INFO - 2025-04-08 11:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:03:09 --> Pagination Class Initialized
INFO - 2025-04-08 11:03:09 --> Controller Class Initialized
DEBUG - 2025-04-08 11:03:09 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:03:09 --> Model Class Initialized
INFO - 2025-04-08 17:03:09 --> Final output sent to browser
DEBUG - 2025-04-08 17:03:09 --> Total execution time: 0.0368
INFO - 2025-04-08 11:03:42 --> Config Class Initialized
INFO - 2025-04-08 11:03:42 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:03:42 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:03:42 --> Utf8 Class Initialized
INFO - 2025-04-08 11:03:42 --> URI Class Initialized
DEBUG - 2025-04-08 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:03:42 --> Router Class Initialized
INFO - 2025-04-08 11:03:42 --> Output Class Initialized
INFO - 2025-04-08 11:03:42 --> Security Class Initialized
DEBUG - 2025-04-08 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:03:42 --> Input Class Initialized
INFO - 2025-04-08 11:03:42 --> Language Class Initialized
INFO - 2025-04-08 11:03:42 --> Language Class Initialized
INFO - 2025-04-08 11:03:42 --> Config Class Initialized
INFO - 2025-04-08 11:03:42 --> Loader Class Initialized
INFO - 2025-04-08 11:03:42 --> Helper loaded: url_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: file_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: html_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: form_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: text_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:03:42 --> Database Driver Class Initialized
INFO - 2025-04-08 11:03:42 --> Email Class Initialized
INFO - 2025-04-08 11:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:03:42 --> Form Validation Class Initialized
INFO - 2025-04-08 11:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:03:42 --> Pagination Class Initialized
INFO - 2025-04-08 11:03:42 --> Controller Class Initialized
DEBUG - 2025-04-08 11:03:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:03:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
ERROR - 2025-04-08 17:03:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:03:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:03:42 --> Final output sent to browser
DEBUG - 2025-04-08 17:03:42 --> Total execution time: 0.1738
INFO - 2025-04-08 11:03:42 --> Config Class Initialized
INFO - 2025-04-08 11:03:42 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:03:42 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:03:42 --> Utf8 Class Initialized
INFO - 2025-04-08 11:03:42 --> URI Class Initialized
DEBUG - 2025-04-08 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:03:42 --> Router Class Initialized
INFO - 2025-04-08 11:03:42 --> Output Class Initialized
INFO - 2025-04-08 11:03:42 --> Security Class Initialized
DEBUG - 2025-04-08 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:03:42 --> Input Class Initialized
INFO - 2025-04-08 11:03:42 --> Language Class Initialized
INFO - 2025-04-08 11:03:42 --> Language Class Initialized
INFO - 2025-04-08 11:03:42 --> Config Class Initialized
INFO - 2025-04-08 11:03:42 --> Loader Class Initialized
INFO - 2025-04-08 11:03:42 --> Helper loaded: url_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: file_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: html_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: form_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: text_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:03:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:03:42 --> Database Driver Class Initialized
INFO - 2025-04-08 11:03:42 --> Email Class Initialized
INFO - 2025-04-08 11:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:03:42 --> Form Validation Class Initialized
INFO - 2025-04-08 11:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:03:42 --> Pagination Class Initialized
INFO - 2025-04-08 11:03:42 --> Controller Class Initialized
DEBUG - 2025-04-08 11:03:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
DEBUG - 2025-04-08 17:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:03:42 --> Model Class Initialized
INFO - 2025-04-08 17:03:42 --> Final output sent to browser
DEBUG - 2025-04-08 17:03:42 --> Total execution time: 0.0627
INFO - 2025-04-08 11:08:50 --> Config Class Initialized
INFO - 2025-04-08 11:08:50 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:08:50 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:08:50 --> Utf8 Class Initialized
INFO - 2025-04-08 11:08:50 --> URI Class Initialized
DEBUG - 2025-04-08 11:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:08:50 --> Router Class Initialized
INFO - 2025-04-08 11:08:50 --> Output Class Initialized
INFO - 2025-04-08 11:08:50 --> Security Class Initialized
DEBUG - 2025-04-08 11:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:08:50 --> Input Class Initialized
INFO - 2025-04-08 11:08:50 --> Language Class Initialized
INFO - 2025-04-08 11:08:50 --> Language Class Initialized
INFO - 2025-04-08 11:08:50 --> Config Class Initialized
INFO - 2025-04-08 11:08:50 --> Loader Class Initialized
INFO - 2025-04-08 11:08:50 --> Helper loaded: url_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: file_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: html_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: form_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: text_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:08:50 --> Database Driver Class Initialized
INFO - 2025-04-08 11:08:50 --> Email Class Initialized
INFO - 2025-04-08 11:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:08:50 --> Form Validation Class Initialized
INFO - 2025-04-08 11:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:08:50 --> Pagination Class Initialized
INFO - 2025-04-08 11:08:50 --> Controller Class Initialized
DEBUG - 2025-04-08 11:08:50 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:08:50 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
ERROR - 2025-04-08 17:08:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:08:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:08:50 --> Final output sent to browser
DEBUG - 2025-04-08 17:08:50 --> Total execution time: 0.1462
INFO - 2025-04-08 11:08:50 --> Config Class Initialized
INFO - 2025-04-08 11:08:50 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:08:50 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:08:50 --> Utf8 Class Initialized
INFO - 2025-04-08 11:08:50 --> URI Class Initialized
DEBUG - 2025-04-08 11:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:08:50 --> Router Class Initialized
INFO - 2025-04-08 11:08:50 --> Output Class Initialized
INFO - 2025-04-08 11:08:50 --> Security Class Initialized
DEBUG - 2025-04-08 11:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:08:50 --> Input Class Initialized
INFO - 2025-04-08 11:08:50 --> Language Class Initialized
INFO - 2025-04-08 11:08:50 --> Language Class Initialized
INFO - 2025-04-08 11:08:50 --> Config Class Initialized
INFO - 2025-04-08 11:08:50 --> Loader Class Initialized
INFO - 2025-04-08 11:08:50 --> Helper loaded: url_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: file_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: html_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: form_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: text_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:08:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:08:50 --> Database Driver Class Initialized
INFO - 2025-04-08 11:08:50 --> Email Class Initialized
INFO - 2025-04-08 11:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:08:50 --> Form Validation Class Initialized
INFO - 2025-04-08 11:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:08:50 --> Pagination Class Initialized
INFO - 2025-04-08 11:08:50 --> Controller Class Initialized
DEBUG - 2025-04-08 11:08:50 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:08:50 --> Model Class Initialized
INFO - 2025-04-08 17:08:50 --> Final output sent to browser
DEBUG - 2025-04-08 17:08:50 --> Total execution time: 0.0665
INFO - 2025-04-08 11:08:53 --> Config Class Initialized
INFO - 2025-04-08 11:08:53 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:08:53 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:08:53 --> Utf8 Class Initialized
INFO - 2025-04-08 11:08:53 --> URI Class Initialized
DEBUG - 2025-04-08 11:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:08:53 --> Router Class Initialized
INFO - 2025-04-08 11:08:53 --> Output Class Initialized
INFO - 2025-04-08 11:08:53 --> Security Class Initialized
DEBUG - 2025-04-08 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:08:53 --> Input Class Initialized
INFO - 2025-04-08 11:08:53 --> Language Class Initialized
INFO - 2025-04-08 11:08:53 --> Language Class Initialized
INFO - 2025-04-08 11:08:53 --> Config Class Initialized
INFO - 2025-04-08 11:08:53 --> Loader Class Initialized
INFO - 2025-04-08 11:08:53 --> Helper loaded: url_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: file_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: html_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: form_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: text_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:08:53 --> Database Driver Class Initialized
INFO - 2025-04-08 11:08:53 --> Email Class Initialized
INFO - 2025-04-08 11:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:08:53 --> Form Validation Class Initialized
INFO - 2025-04-08 11:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:08:53 --> Pagination Class Initialized
INFO - 2025-04-08 11:08:53 --> Controller Class Initialized
DEBUG - 2025-04-08 11:08:53 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:08:53 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
ERROR - 2025-04-08 17:08:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:08:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:08:53 --> Final output sent to browser
DEBUG - 2025-04-08 17:08:53 --> Total execution time: 0.0993
INFO - 2025-04-08 11:08:53 --> Config Class Initialized
INFO - 2025-04-08 11:08:53 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:08:53 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:08:53 --> Utf8 Class Initialized
INFO - 2025-04-08 11:08:53 --> URI Class Initialized
DEBUG - 2025-04-08 11:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:08:53 --> Router Class Initialized
INFO - 2025-04-08 11:08:53 --> Output Class Initialized
INFO - 2025-04-08 11:08:53 --> Security Class Initialized
DEBUG - 2025-04-08 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:08:53 --> Input Class Initialized
INFO - 2025-04-08 11:08:53 --> Language Class Initialized
INFO - 2025-04-08 11:08:53 --> Language Class Initialized
INFO - 2025-04-08 11:08:53 --> Config Class Initialized
INFO - 2025-04-08 11:08:53 --> Loader Class Initialized
INFO - 2025-04-08 11:08:53 --> Helper loaded: url_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: file_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: html_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: form_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: text_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:08:53 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:08:53 --> Database Driver Class Initialized
INFO - 2025-04-08 11:08:53 --> Email Class Initialized
INFO - 2025-04-08 11:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:08:53 --> Form Validation Class Initialized
INFO - 2025-04-08 11:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:08:53 --> Pagination Class Initialized
INFO - 2025-04-08 11:08:53 --> Controller Class Initialized
DEBUG - 2025-04-08 11:08:53 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
DEBUG - 2025-04-08 17:08:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:08:53 --> Model Class Initialized
INFO - 2025-04-08 17:08:54 --> Final output sent to browser
DEBUG - 2025-04-08 17:08:54 --> Total execution time: 0.0330
INFO - 2025-04-08 11:11:29 --> Config Class Initialized
INFO - 2025-04-08 11:11:29 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:11:29 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:11:29 --> Utf8 Class Initialized
INFO - 2025-04-08 11:11:29 --> URI Class Initialized
DEBUG - 2025-04-08 11:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:11:29 --> Router Class Initialized
INFO - 2025-04-08 11:11:29 --> Output Class Initialized
INFO - 2025-04-08 11:11:29 --> Security Class Initialized
DEBUG - 2025-04-08 11:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:11:29 --> Input Class Initialized
INFO - 2025-04-08 11:11:29 --> Language Class Initialized
INFO - 2025-04-08 11:11:29 --> Language Class Initialized
INFO - 2025-04-08 11:11:29 --> Config Class Initialized
INFO - 2025-04-08 11:11:29 --> Loader Class Initialized
INFO - 2025-04-08 11:11:29 --> Helper loaded: url_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: file_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: html_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: form_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: text_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:11:29 --> Database Driver Class Initialized
INFO - 2025-04-08 11:11:29 --> Email Class Initialized
INFO - 2025-04-08 11:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:11:29 --> Form Validation Class Initialized
INFO - 2025-04-08 11:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:11:29 --> Pagination Class Initialized
INFO - 2025-04-08 11:11:29 --> Controller Class Initialized
DEBUG - 2025-04-08 11:11:29 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:11:29 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
ERROR - 2025-04-08 17:11:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:11:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:11:29 --> Final output sent to browser
DEBUG - 2025-04-08 17:11:29 --> Total execution time: 0.1144
INFO - 2025-04-08 11:11:29 --> Config Class Initialized
INFO - 2025-04-08 11:11:29 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:11:29 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:11:29 --> Utf8 Class Initialized
INFO - 2025-04-08 11:11:29 --> URI Class Initialized
DEBUG - 2025-04-08 11:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:11:29 --> Router Class Initialized
INFO - 2025-04-08 11:11:29 --> Output Class Initialized
INFO - 2025-04-08 11:11:29 --> Security Class Initialized
DEBUG - 2025-04-08 11:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:11:29 --> Input Class Initialized
INFO - 2025-04-08 11:11:29 --> Language Class Initialized
INFO - 2025-04-08 11:11:29 --> Language Class Initialized
INFO - 2025-04-08 11:11:29 --> Config Class Initialized
INFO - 2025-04-08 11:11:29 --> Loader Class Initialized
INFO - 2025-04-08 11:11:29 --> Helper loaded: url_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: file_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: html_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: form_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: text_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:11:29 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:11:29 --> Database Driver Class Initialized
INFO - 2025-04-08 11:11:29 --> Email Class Initialized
INFO - 2025-04-08 11:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:11:29 --> Form Validation Class Initialized
INFO - 2025-04-08 11:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:11:29 --> Pagination Class Initialized
INFO - 2025-04-08 11:11:29 --> Controller Class Initialized
DEBUG - 2025-04-08 11:11:29 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:11:29 --> Model Class Initialized
INFO - 2025-04-08 17:11:29 --> Final output sent to browser
DEBUG - 2025-04-08 17:11:29 --> Total execution time: 0.0431
INFO - 2025-04-08 11:11:32 --> Config Class Initialized
INFO - 2025-04-08 11:11:32 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:11:32 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:11:32 --> Utf8 Class Initialized
INFO - 2025-04-08 11:11:32 --> URI Class Initialized
DEBUG - 2025-04-08 11:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:11:32 --> Router Class Initialized
INFO - 2025-04-08 11:11:32 --> Output Class Initialized
INFO - 2025-04-08 11:11:32 --> Security Class Initialized
DEBUG - 2025-04-08 11:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:11:32 --> Input Class Initialized
INFO - 2025-04-08 11:11:32 --> Language Class Initialized
INFO - 2025-04-08 11:11:32 --> Language Class Initialized
INFO - 2025-04-08 11:11:32 --> Config Class Initialized
INFO - 2025-04-08 11:11:32 --> Loader Class Initialized
INFO - 2025-04-08 11:11:32 --> Helper loaded: url_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: file_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: html_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: form_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: text_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:11:32 --> Database Driver Class Initialized
INFO - 2025-04-08 11:11:32 --> Email Class Initialized
INFO - 2025-04-08 11:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:11:32 --> Form Validation Class Initialized
INFO - 2025-04-08 11:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:11:32 --> Pagination Class Initialized
INFO - 2025-04-08 11:11:32 --> Controller Class Initialized
DEBUG - 2025-04-08 11:11:32 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:11:32 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
ERROR - 2025-04-08 17:11:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:11:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:11:32 --> Final output sent to browser
DEBUG - 2025-04-08 17:11:32 --> Total execution time: 0.1759
INFO - 2025-04-08 11:11:32 --> Config Class Initialized
INFO - 2025-04-08 11:11:32 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:11:32 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:11:32 --> Utf8 Class Initialized
INFO - 2025-04-08 11:11:32 --> URI Class Initialized
DEBUG - 2025-04-08 11:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:11:32 --> Router Class Initialized
INFO - 2025-04-08 11:11:32 --> Output Class Initialized
INFO - 2025-04-08 11:11:32 --> Security Class Initialized
DEBUG - 2025-04-08 11:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:11:32 --> Input Class Initialized
INFO - 2025-04-08 11:11:32 --> Language Class Initialized
INFO - 2025-04-08 11:11:32 --> Language Class Initialized
INFO - 2025-04-08 11:11:32 --> Config Class Initialized
INFO - 2025-04-08 11:11:32 --> Loader Class Initialized
INFO - 2025-04-08 11:11:32 --> Helper loaded: url_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: file_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: html_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: form_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: text_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:11:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:11:32 --> Database Driver Class Initialized
INFO - 2025-04-08 11:11:32 --> Email Class Initialized
INFO - 2025-04-08 11:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:11:32 --> Form Validation Class Initialized
INFO - 2025-04-08 11:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:11:32 --> Pagination Class Initialized
INFO - 2025-04-08 11:11:32 --> Controller Class Initialized
DEBUG - 2025-04-08 11:11:32 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:11:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:11:32 --> Model Class Initialized
INFO - 2025-04-08 17:11:32 --> Final output sent to browser
DEBUG - 2025-04-08 17:11:32 --> Total execution time: 0.0448
INFO - 2025-04-08 11:12:31 --> Config Class Initialized
INFO - 2025-04-08 11:12:31 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:12:31 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:12:31 --> Utf8 Class Initialized
INFO - 2025-04-08 11:12:31 --> URI Class Initialized
DEBUG - 2025-04-08 11:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:12:31 --> Router Class Initialized
INFO - 2025-04-08 11:12:31 --> Output Class Initialized
INFO - 2025-04-08 11:12:31 --> Security Class Initialized
DEBUG - 2025-04-08 11:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:12:31 --> Input Class Initialized
INFO - 2025-04-08 11:12:31 --> Language Class Initialized
INFO - 2025-04-08 11:12:31 --> Language Class Initialized
INFO - 2025-04-08 11:12:31 --> Config Class Initialized
INFO - 2025-04-08 11:12:31 --> Loader Class Initialized
INFO - 2025-04-08 11:12:31 --> Helper loaded: url_helper
INFO - 2025-04-08 11:12:31 --> Helper loaded: file_helper
INFO - 2025-04-08 11:12:31 --> Helper loaded: html_helper
INFO - 2025-04-08 11:12:31 --> Helper loaded: form_helper
INFO - 2025-04-08 11:12:31 --> Helper loaded: text_helper
INFO - 2025-04-08 11:12:31 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:12:31 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:12:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:12:31 --> Database Driver Class Initialized
INFO - 2025-04-08 11:12:31 --> Email Class Initialized
INFO - 2025-04-08 11:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:12:31 --> Form Validation Class Initialized
INFO - 2025-04-08 11:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:12:31 --> Pagination Class Initialized
INFO - 2025-04-08 11:12:31 --> Controller Class Initialized
DEBUG - 2025-04-08 11:12:31 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:12:31 --> Model Class Initialized
DEBUG - 2025-04-08 17:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:12:31 --> Model Class Initialized
DEBUG - 2025-04-08 17:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:12:31 --> Model Class Initialized
DEBUG - 2025-04-08 17:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:12:31 --> Model Class Initialized
DEBUG - 2025-04-08 17:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:12:31 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:12:31 --> Model Class Initialized
ERROR - 2025-04-08 17:12:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:12:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:12:32 --> Final output sent to browser
DEBUG - 2025-04-08 17:12:32 --> Total execution time: 0.1410
INFO - 2025-04-08 11:12:32 --> Config Class Initialized
INFO - 2025-04-08 11:12:32 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:12:32 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:12:32 --> Utf8 Class Initialized
INFO - 2025-04-08 11:12:32 --> URI Class Initialized
DEBUG - 2025-04-08 11:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:12:32 --> Router Class Initialized
INFO - 2025-04-08 11:12:32 --> Output Class Initialized
INFO - 2025-04-08 11:12:32 --> Security Class Initialized
DEBUG - 2025-04-08 11:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:12:32 --> Input Class Initialized
INFO - 2025-04-08 11:12:32 --> Language Class Initialized
INFO - 2025-04-08 11:12:32 --> Language Class Initialized
INFO - 2025-04-08 11:12:32 --> Config Class Initialized
INFO - 2025-04-08 11:12:32 --> Loader Class Initialized
INFO - 2025-04-08 11:12:32 --> Helper loaded: url_helper
INFO - 2025-04-08 11:12:32 --> Helper loaded: file_helper
INFO - 2025-04-08 11:12:32 --> Helper loaded: html_helper
INFO - 2025-04-08 11:12:32 --> Helper loaded: form_helper
INFO - 2025-04-08 11:12:32 --> Helper loaded: text_helper
INFO - 2025-04-08 11:12:32 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:12:32 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:12:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:12:32 --> Database Driver Class Initialized
INFO - 2025-04-08 11:12:32 --> Email Class Initialized
INFO - 2025-04-08 11:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:12:32 --> Form Validation Class Initialized
INFO - 2025-04-08 11:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:12:32 --> Pagination Class Initialized
INFO - 2025-04-08 11:12:32 --> Controller Class Initialized
DEBUG - 2025-04-08 11:12:32 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:12:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:12:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:12:32 --> Model Class Initialized
DEBUG - 2025-04-08 17:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:12:32 --> Model Class Initialized
INFO - 2025-04-08 17:12:32 --> Final output sent to browser
DEBUG - 2025-04-08 17:12:32 --> Total execution time: 0.0428
INFO - 2025-04-08 11:13:44 --> Config Class Initialized
INFO - 2025-04-08 11:13:44 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:13:44 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:13:44 --> Utf8 Class Initialized
INFO - 2025-04-08 11:13:44 --> URI Class Initialized
DEBUG - 2025-04-08 11:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:13:44 --> Router Class Initialized
INFO - 2025-04-08 11:13:44 --> Output Class Initialized
INFO - 2025-04-08 11:13:44 --> Security Class Initialized
DEBUG - 2025-04-08 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:13:44 --> Input Class Initialized
INFO - 2025-04-08 11:13:44 --> Language Class Initialized
INFO - 2025-04-08 11:13:44 --> Language Class Initialized
INFO - 2025-04-08 11:13:44 --> Config Class Initialized
INFO - 2025-04-08 11:13:44 --> Loader Class Initialized
INFO - 2025-04-08 11:13:44 --> Helper loaded: url_helper
INFO - 2025-04-08 11:13:44 --> Helper loaded: file_helper
INFO - 2025-04-08 11:13:44 --> Helper loaded: html_helper
INFO - 2025-04-08 11:13:44 --> Helper loaded: form_helper
INFO - 2025-04-08 11:13:44 --> Helper loaded: text_helper
INFO - 2025-04-08 11:13:44 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:13:44 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:13:44 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:13:44 --> Database Driver Class Initialized
INFO - 2025-04-08 11:13:44 --> Email Class Initialized
INFO - 2025-04-08 11:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:13:44 --> Form Validation Class Initialized
INFO - 2025-04-08 11:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:13:44 --> Pagination Class Initialized
INFO - 2025-04-08 11:13:44 --> Controller Class Initialized
DEBUG - 2025-04-08 11:13:44 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:13:44 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:13:44 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:13:44 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:13:44 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:13:44 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:13:44 --> Model Class Initialized
ERROR - 2025-04-08 17:13:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:13:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:13:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:13:44 --> Final output sent to browser
DEBUG - 2025-04-08 17:13:44 --> Total execution time: 0.1908
INFO - 2025-04-08 11:13:45 --> Config Class Initialized
INFO - 2025-04-08 11:13:45 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:13:45 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:13:45 --> Utf8 Class Initialized
INFO - 2025-04-08 11:13:45 --> URI Class Initialized
DEBUG - 2025-04-08 11:13:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:13:45 --> Router Class Initialized
INFO - 2025-04-08 11:13:45 --> Output Class Initialized
INFO - 2025-04-08 11:13:45 --> Security Class Initialized
DEBUG - 2025-04-08 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:13:45 --> Input Class Initialized
INFO - 2025-04-08 11:13:45 --> Language Class Initialized
INFO - 2025-04-08 11:13:45 --> Language Class Initialized
INFO - 2025-04-08 11:13:45 --> Config Class Initialized
INFO - 2025-04-08 11:13:45 --> Loader Class Initialized
INFO - 2025-04-08 11:13:45 --> Helper loaded: url_helper
INFO - 2025-04-08 11:13:45 --> Helper loaded: file_helper
INFO - 2025-04-08 11:13:45 --> Helper loaded: html_helper
INFO - 2025-04-08 11:13:45 --> Helper loaded: form_helper
INFO - 2025-04-08 11:13:45 --> Helper loaded: text_helper
INFO - 2025-04-08 11:13:45 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:13:45 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:13:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:13:45 --> Database Driver Class Initialized
INFO - 2025-04-08 11:13:45 --> Email Class Initialized
INFO - 2025-04-08 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:13:45 --> Form Validation Class Initialized
INFO - 2025-04-08 11:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:13:45 --> Pagination Class Initialized
INFO - 2025-04-08 11:13:45 --> Controller Class Initialized
DEBUG - 2025-04-08 11:13:45 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:13:45 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:13:45 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:13:45 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:13:45 --> Model Class Initialized
INFO - 2025-04-08 17:13:45 --> Final output sent to browser
DEBUG - 2025-04-08 17:13:45 --> Total execution time: 0.0364
INFO - 2025-04-08 11:13:54 --> Config Class Initialized
INFO - 2025-04-08 11:13:54 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:13:54 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:13:54 --> Utf8 Class Initialized
INFO - 2025-04-08 11:13:54 --> URI Class Initialized
DEBUG - 2025-04-08 11:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:13:54 --> Router Class Initialized
INFO - 2025-04-08 11:13:54 --> Output Class Initialized
INFO - 2025-04-08 11:13:54 --> Security Class Initialized
DEBUG - 2025-04-08 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:13:54 --> Input Class Initialized
INFO - 2025-04-08 11:13:54 --> Language Class Initialized
INFO - 2025-04-08 11:13:54 --> Language Class Initialized
INFO - 2025-04-08 11:13:54 --> Config Class Initialized
INFO - 2025-04-08 11:13:54 --> Loader Class Initialized
INFO - 2025-04-08 11:13:54 --> Helper loaded: url_helper
INFO - 2025-04-08 11:13:54 --> Helper loaded: file_helper
INFO - 2025-04-08 11:13:54 --> Helper loaded: html_helper
INFO - 2025-04-08 11:13:54 --> Helper loaded: form_helper
INFO - 2025-04-08 11:13:54 --> Helper loaded: text_helper
INFO - 2025-04-08 11:13:54 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:13:54 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:13:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:13:54 --> Database Driver Class Initialized
INFO - 2025-04-08 11:13:54 --> Email Class Initialized
INFO - 2025-04-08 11:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:13:54 --> Form Validation Class Initialized
INFO - 2025-04-08 11:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:13:54 --> Pagination Class Initialized
INFO - 2025-04-08 11:13:54 --> Controller Class Initialized
DEBUG - 2025-04-08 11:13:54 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:13:54 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:13:54 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:13:54 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:13:54 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:13:54 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:13:54 --> Model Class Initialized
ERROR - 2025-04-08 17:13:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:13:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:13:54 --> Final output sent to browser
DEBUG - 2025-04-08 17:13:54 --> Total execution time: 0.1555
INFO - 2025-04-08 11:13:55 --> Config Class Initialized
INFO - 2025-04-08 11:13:55 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:13:55 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:13:55 --> Utf8 Class Initialized
INFO - 2025-04-08 11:13:55 --> URI Class Initialized
DEBUG - 2025-04-08 11:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:13:55 --> Router Class Initialized
INFO - 2025-04-08 11:13:55 --> Output Class Initialized
INFO - 2025-04-08 11:13:55 --> Security Class Initialized
DEBUG - 2025-04-08 11:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:13:55 --> Input Class Initialized
INFO - 2025-04-08 11:13:55 --> Language Class Initialized
INFO - 2025-04-08 11:13:55 --> Language Class Initialized
INFO - 2025-04-08 11:13:55 --> Config Class Initialized
INFO - 2025-04-08 11:13:55 --> Loader Class Initialized
INFO - 2025-04-08 11:13:55 --> Helper loaded: url_helper
INFO - 2025-04-08 11:13:55 --> Helper loaded: file_helper
INFO - 2025-04-08 11:13:55 --> Helper loaded: html_helper
INFO - 2025-04-08 11:13:55 --> Helper loaded: form_helper
INFO - 2025-04-08 11:13:55 --> Helper loaded: text_helper
INFO - 2025-04-08 11:13:55 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:13:55 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:13:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:13:55 --> Database Driver Class Initialized
INFO - 2025-04-08 11:13:55 --> Email Class Initialized
INFO - 2025-04-08 11:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:13:55 --> Form Validation Class Initialized
INFO - 2025-04-08 11:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:13:55 --> Pagination Class Initialized
INFO - 2025-04-08 11:13:55 --> Controller Class Initialized
DEBUG - 2025-04-08 11:13:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:13:55 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:13:55 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:13:55 --> Model Class Initialized
DEBUG - 2025-04-08 17:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:13:55 --> Model Class Initialized
INFO - 2025-04-08 17:13:55 --> Final output sent to browser
DEBUG - 2025-04-08 17:13:55 --> Total execution time: 0.0366
INFO - 2025-04-08 11:33:24 --> Config Class Initialized
INFO - 2025-04-08 11:33:24 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:33:24 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:33:24 --> Utf8 Class Initialized
INFO - 2025-04-08 11:33:24 --> URI Class Initialized
DEBUG - 2025-04-08 11:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:33:24 --> Router Class Initialized
INFO - 2025-04-08 11:33:24 --> Output Class Initialized
INFO - 2025-04-08 11:33:24 --> Security Class Initialized
DEBUG - 2025-04-08 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:33:24 --> Input Class Initialized
INFO - 2025-04-08 11:33:24 --> Language Class Initialized
INFO - 2025-04-08 11:33:24 --> Language Class Initialized
INFO - 2025-04-08 11:33:24 --> Config Class Initialized
INFO - 2025-04-08 11:33:24 --> Loader Class Initialized
INFO - 2025-04-08 11:33:24 --> Helper loaded: url_helper
INFO - 2025-04-08 11:33:24 --> Helper loaded: file_helper
INFO - 2025-04-08 11:33:24 --> Helper loaded: html_helper
INFO - 2025-04-08 11:33:24 --> Helper loaded: form_helper
INFO - 2025-04-08 11:33:24 --> Helper loaded: text_helper
INFO - 2025-04-08 11:33:24 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:33:24 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:33:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:33:24 --> Database Driver Class Initialized
INFO - 2025-04-08 11:33:24 --> Email Class Initialized
INFO - 2025-04-08 11:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:33:24 --> Form Validation Class Initialized
INFO - 2025-04-08 11:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:33:24 --> Pagination Class Initialized
INFO - 2025-04-08 11:33:24 --> Controller Class Initialized
DEBUG - 2025-04-08 11:33:24 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:33:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:33:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:33:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:33:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:33:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:33:24 --> Model Class Initialized
ERROR - 2025-04-08 17:33:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:33:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:33:24 --> Final output sent to browser
DEBUG - 2025-04-08 17:33:24 --> Total execution time: 0.2942
INFO - 2025-04-08 11:33:25 --> Config Class Initialized
INFO - 2025-04-08 11:33:25 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:33:25 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:33:25 --> Utf8 Class Initialized
INFO - 2025-04-08 11:33:25 --> URI Class Initialized
DEBUG - 2025-04-08 11:33:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:33:25 --> Router Class Initialized
INFO - 2025-04-08 11:33:25 --> Output Class Initialized
INFO - 2025-04-08 11:33:25 --> Security Class Initialized
DEBUG - 2025-04-08 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:33:25 --> Input Class Initialized
INFO - 2025-04-08 11:33:25 --> Language Class Initialized
INFO - 2025-04-08 11:33:25 --> Language Class Initialized
INFO - 2025-04-08 11:33:25 --> Config Class Initialized
INFO - 2025-04-08 11:33:25 --> Loader Class Initialized
INFO - 2025-04-08 11:33:25 --> Helper loaded: url_helper
INFO - 2025-04-08 11:33:25 --> Helper loaded: file_helper
INFO - 2025-04-08 11:33:25 --> Helper loaded: html_helper
INFO - 2025-04-08 11:33:25 --> Helper loaded: form_helper
INFO - 2025-04-08 11:33:25 --> Helper loaded: text_helper
INFO - 2025-04-08 11:33:25 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:33:25 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:33:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:33:25 --> Database Driver Class Initialized
INFO - 2025-04-08 11:33:25 --> Email Class Initialized
INFO - 2025-04-08 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:33:25 --> Form Validation Class Initialized
INFO - 2025-04-08 11:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:33:25 --> Pagination Class Initialized
INFO - 2025-04-08 11:33:25 --> Controller Class Initialized
DEBUG - 2025-04-08 11:33:25 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:33:25 --> Model Class Initialized
DEBUG - 2025-04-08 17:33:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:33:25 --> Model Class Initialized
DEBUG - 2025-04-08 17:33:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:33:25 --> Model Class Initialized
DEBUG - 2025-04-08 17:33:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:33:25 --> Model Class Initialized
INFO - 2025-04-08 17:33:25 --> Final output sent to browser
DEBUG - 2025-04-08 17:33:25 --> Total execution time: 0.0366
INFO - 2025-04-08 11:43:24 --> Config Class Initialized
INFO - 2025-04-08 11:43:24 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:43:24 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:43:24 --> Utf8 Class Initialized
INFO - 2025-04-08 11:43:24 --> URI Class Initialized
DEBUG - 2025-04-08 11:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:43:24 --> Router Class Initialized
INFO - 2025-04-08 11:43:24 --> Output Class Initialized
INFO - 2025-04-08 11:43:24 --> Security Class Initialized
DEBUG - 2025-04-08 11:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:43:24 --> Input Class Initialized
INFO - 2025-04-08 11:43:24 --> Language Class Initialized
INFO - 2025-04-08 11:43:24 --> Language Class Initialized
INFO - 2025-04-08 11:43:24 --> Config Class Initialized
INFO - 2025-04-08 11:43:24 --> Loader Class Initialized
INFO - 2025-04-08 11:43:24 --> Helper loaded: url_helper
INFO - 2025-04-08 11:43:24 --> Helper loaded: file_helper
INFO - 2025-04-08 11:43:24 --> Helper loaded: html_helper
INFO - 2025-04-08 11:43:24 --> Helper loaded: form_helper
INFO - 2025-04-08 11:43:24 --> Helper loaded: text_helper
INFO - 2025-04-08 11:43:24 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:43:24 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:43:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:43:24 --> Database Driver Class Initialized
INFO - 2025-04-08 11:43:24 --> Email Class Initialized
INFO - 2025-04-08 11:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:43:24 --> Form Validation Class Initialized
INFO - 2025-04-08 11:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:43:24 --> Pagination Class Initialized
INFO - 2025-04-08 11:43:24 --> Controller Class Initialized
DEBUG - 2025-04-08 11:43:24 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:43:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:43:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:43:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:43:24 --> Model Class Initialized
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:43:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:43:24 --> Model Class Initialized
ERROR - 2025-04-08 17:43:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:43:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:43:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-08 17:43:24 --> Severity: Warning --> Undefined variable $total_amount /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 80
ERROR - 2025-04-08 17:43:24 --> Severity: Warning --> Undefined variable $total_paid /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 81
ERROR - 2025-04-08 17:43:24 --> Severity: Warning --> Undefined variable $total_due /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 82
ERROR - 2025-04-08 17:43:24 --> Severity: Warning --> Undefined variable $invoice_payments /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 90
ERROR - 2025-04-08 17:43:24 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 90
INFO - 2025-04-08 11:49:46 --> Config Class Initialized
INFO - 2025-04-08 11:49:46 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:49:46 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:49:46 --> Utf8 Class Initialized
INFO - 2025-04-08 11:49:46 --> URI Class Initialized
DEBUG - 2025-04-08 11:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:49:46 --> Router Class Initialized
INFO - 2025-04-08 11:49:46 --> Output Class Initialized
INFO - 2025-04-08 11:49:46 --> Security Class Initialized
DEBUG - 2025-04-08 11:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:49:46 --> Input Class Initialized
INFO - 2025-04-08 11:49:46 --> Language Class Initialized
INFO - 2025-04-08 11:49:46 --> Language Class Initialized
INFO - 2025-04-08 11:49:46 --> Config Class Initialized
INFO - 2025-04-08 11:49:46 --> Loader Class Initialized
INFO - 2025-04-08 11:49:46 --> Helper loaded: url_helper
INFO - 2025-04-08 11:49:46 --> Helper loaded: file_helper
INFO - 2025-04-08 11:49:46 --> Helper loaded: html_helper
INFO - 2025-04-08 11:49:46 --> Helper loaded: form_helper
INFO - 2025-04-08 11:49:46 --> Helper loaded: text_helper
INFO - 2025-04-08 11:49:46 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:49:46 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:49:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:49:46 --> Database Driver Class Initialized
INFO - 2025-04-08 11:49:46 --> Email Class Initialized
INFO - 2025-04-08 11:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:49:46 --> Form Validation Class Initialized
INFO - 2025-04-08 11:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:49:46 --> Pagination Class Initialized
INFO - 2025-04-08 11:49:46 --> Controller Class Initialized
DEBUG - 2025-04-08 11:49:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:49:46 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:49:46 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:49:46 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:49:46 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:49:46 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:49:46 --> Model Class Initialized
ERROR - 2025-04-08 17:49:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:49:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:49:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-08 17:49:46 --> Severity: Warning --> Undefined variable $total_amount /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 80
ERROR - 2025-04-08 17:49:46 --> Severity: Warning --> Undefined variable $total_paid /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 81
ERROR - 2025-04-08 17:49:46 --> Severity: Warning --> Undefined variable $total_due /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 82
ERROR - 2025-04-08 17:49:46 --> Severity: Warning --> Undefined variable $invoice_payments /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 90
ERROR - 2025-04-08 17:49:46 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 90
INFO - 2025-04-08 11:49:48 --> Config Class Initialized
INFO - 2025-04-08 11:49:48 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:49:48 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:49:48 --> Utf8 Class Initialized
INFO - 2025-04-08 11:49:48 --> URI Class Initialized
DEBUG - 2025-04-08 11:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:49:48 --> Router Class Initialized
INFO - 2025-04-08 11:49:48 --> Output Class Initialized
INFO - 2025-04-08 11:49:48 --> Security Class Initialized
DEBUG - 2025-04-08 11:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:49:48 --> Input Class Initialized
INFO - 2025-04-08 11:49:48 --> Language Class Initialized
INFO - 2025-04-08 11:49:48 --> Language Class Initialized
INFO - 2025-04-08 11:49:48 --> Config Class Initialized
INFO - 2025-04-08 11:49:48 --> Loader Class Initialized
INFO - 2025-04-08 11:49:48 --> Helper loaded: url_helper
INFO - 2025-04-08 11:49:48 --> Helper loaded: file_helper
INFO - 2025-04-08 11:49:48 --> Helper loaded: html_helper
INFO - 2025-04-08 11:49:48 --> Helper loaded: form_helper
INFO - 2025-04-08 11:49:48 --> Helper loaded: text_helper
INFO - 2025-04-08 11:49:48 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:49:48 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:49:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:49:48 --> Database Driver Class Initialized
INFO - 2025-04-08 11:49:48 --> Email Class Initialized
INFO - 2025-04-08 11:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:49:48 --> Form Validation Class Initialized
INFO - 2025-04-08 11:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:49:48 --> Pagination Class Initialized
INFO - 2025-04-08 11:49:48 --> Controller Class Initialized
DEBUG - 2025-04-08 11:49:48 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:49:48 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:49:48 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:49:48 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:49:48 --> Model Class Initialized
DEBUG - 2025-04-08 17:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:49:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:49:48 --> Model Class Initialized
ERROR - 2025-04-08 17:49:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:49:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:49:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:49:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:49:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-08 17:49:49 --> Severity: Warning --> Undefined variable $total_amount /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 80
ERROR - 2025-04-08 17:49:49 --> Severity: Warning --> Undefined variable $total_paid /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 81
ERROR - 2025-04-08 17:49:49 --> Severity: Warning --> Undefined variable $total_due /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 82
ERROR - 2025-04-08 17:49:49 --> Severity: Warning --> Undefined variable $invoice_payments /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 90
ERROR - 2025-04-08 17:49:49 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php 90
INFO - 2025-04-08 11:53:03 --> Config Class Initialized
INFO - 2025-04-08 11:53:03 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:53:03 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:53:03 --> Utf8 Class Initialized
INFO - 2025-04-08 11:53:03 --> URI Class Initialized
DEBUG - 2025-04-08 11:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 11:53:03 --> Router Class Initialized
INFO - 2025-04-08 11:53:03 --> Output Class Initialized
INFO - 2025-04-08 11:53:03 --> Security Class Initialized
DEBUG - 2025-04-08 11:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:53:03 --> Input Class Initialized
INFO - 2025-04-08 11:53:03 --> Language Class Initialized
INFO - 2025-04-08 11:53:03 --> Language Class Initialized
INFO - 2025-04-08 11:53:03 --> Config Class Initialized
INFO - 2025-04-08 11:53:03 --> Loader Class Initialized
INFO - 2025-04-08 11:53:03 --> Helper loaded: url_helper
INFO - 2025-04-08 11:53:03 --> Helper loaded: file_helper
INFO - 2025-04-08 11:53:03 --> Helper loaded: html_helper
INFO - 2025-04-08 11:53:03 --> Helper loaded: form_helper
INFO - 2025-04-08 11:53:03 --> Helper loaded: text_helper
INFO - 2025-04-08 11:53:03 --> Helper loaded: lang_helper
INFO - 2025-04-08 11:53:03 --> Helper loaded: directory_helper
INFO - 2025-04-08 11:53:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 11:53:03 --> Database Driver Class Initialized
INFO - 2025-04-08 11:53:03 --> Email Class Initialized
INFO - 2025-04-08 11:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 11:53:03 --> Form Validation Class Initialized
INFO - 2025-04-08 11:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 11:53:03 --> Pagination Class Initialized
INFO - 2025-04-08 11:53:03 --> Controller Class Initialized
DEBUG - 2025-04-08 11:53:03 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 17:53:03 --> Model Class Initialized
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 17:53:03 --> Model Class Initialized
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 17:53:03 --> Model Class Initialized
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 17:53:03 --> Model Class Initialized
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 17:53:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 17:53:03 --> Model Class Initialized
ERROR - 2025-04-08 17:53:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 17:53:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 17:53:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 17:53:03 --> Final output sent to browser
DEBUG - 2025-04-08 17:53:03 --> Total execution time: 0.1818
INFO - 2025-04-08 11:53:03 --> Config Class Initialized
INFO - 2025-04-08 11:53:03 --> Hooks Class Initialized
DEBUG - 2025-04-08 11:53:03 --> UTF-8 Support Enabled
INFO - 2025-04-08 11:53:03 --> Utf8 Class Initialized
INFO - 2025-04-08 11:53:03 --> URI Class Initialized
INFO - 2025-04-08 11:53:03 --> Router Class Initialized
INFO - 2025-04-08 11:53:03 --> Output Class Initialized
INFO - 2025-04-08 11:53:03 --> Security Class Initialized
DEBUG - 2025-04-08 11:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 11:53:03 --> Input Class Initialized
INFO - 2025-04-08 11:53:03 --> Language Class Initialized
ERROR - 2025-04-08 11:53:03 --> 404 Page Not Found: /index
INFO - 2025-04-08 16:48:42 --> Config Class Initialized
INFO - 2025-04-08 16:48:42 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:48:42 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:48:42 --> Utf8 Class Initialized
INFO - 2025-04-08 16:48:42 --> URI Class Initialized
DEBUG - 2025-04-08 16:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 16:48:42 --> Router Class Initialized
INFO - 2025-04-08 16:48:42 --> Output Class Initialized
INFO - 2025-04-08 16:48:42 --> Security Class Initialized
DEBUG - 2025-04-08 16:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:48:42 --> Input Class Initialized
INFO - 2025-04-08 16:48:42 --> Language Class Initialized
INFO - 2025-04-08 16:48:42 --> Language Class Initialized
INFO - 2025-04-08 16:48:42 --> Config Class Initialized
INFO - 2025-04-08 16:48:42 --> Loader Class Initialized
INFO - 2025-04-08 16:48:42 --> Helper loaded: url_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: file_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: html_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: form_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: text_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: lang_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: directory_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 16:48:42 --> Database Driver Class Initialized
INFO - 2025-04-08 16:48:42 --> Email Class Initialized
INFO - 2025-04-08 16:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 16:48:42 --> Form Validation Class Initialized
INFO - 2025-04-08 16:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 16:48:42 --> Pagination Class Initialized
INFO - 2025-04-08 16:48:42 --> Controller Class Initialized
DEBUG - 2025-04-08 16:48:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 22:48:42 --> Model Class Initialized
DEBUG - 2025-04-08 22:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 22:48:42 --> Model Class Initialized
DEBUG - 2025-04-08 22:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 22:48:42 --> Model Class Initialized
DEBUG - 2025-04-08 22:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 22:48:42 --> Model Class Initialized
INFO - 2025-04-08 16:48:42 --> Config Class Initialized
INFO - 2025-04-08 16:48:42 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:48:42 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:48:42 --> Utf8 Class Initialized
INFO - 2025-04-08 16:48:42 --> URI Class Initialized
DEBUG - 2025-04-08 16:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-08 16:48:42 --> Router Class Initialized
INFO - 2025-04-08 16:48:42 --> Output Class Initialized
INFO - 2025-04-08 16:48:42 --> Security Class Initialized
DEBUG - 2025-04-08 16:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:48:42 --> Input Class Initialized
INFO - 2025-04-08 16:48:42 --> Language Class Initialized
INFO - 2025-04-08 16:48:42 --> Language Class Initialized
INFO - 2025-04-08 16:48:42 --> Config Class Initialized
INFO - 2025-04-08 16:48:42 --> Loader Class Initialized
INFO - 2025-04-08 16:48:42 --> Helper loaded: url_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: file_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: html_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: form_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: text_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: lang_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: directory_helper
INFO - 2025-04-08 16:48:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 16:48:42 --> Database Driver Class Initialized
INFO - 2025-04-08 16:48:42 --> Email Class Initialized
INFO - 2025-04-08 16:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 16:48:42 --> Form Validation Class Initialized
INFO - 2025-04-08 16:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 16:48:42 --> Pagination Class Initialized
INFO - 2025-04-08 16:48:42 --> Controller Class Initialized
DEBUG - 2025-04-08 16:48:42 --> Auth MX_Controller Initialized
INFO - 2025-04-08 16:48:42 --> Model Class Initialized
DEBUG - 2025-04-08 16:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-08 16:48:42 --> Model Class Initialized
DEBUG - 2025-04-08 16:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 16:48:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 16:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 16:48:42 --> Model Class Initialized
DEBUG - 2025-04-08 16:48:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-08 16:48:42 --> Final output sent to browser
DEBUG - 2025-04-08 16:48:42 --> Total execution time: 0.0248
INFO - 2025-04-08 16:48:55 --> Config Class Initialized
INFO - 2025-04-08 16:48:55 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:48:55 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:48:55 --> Utf8 Class Initialized
INFO - 2025-04-08 16:48:55 --> URI Class Initialized
DEBUG - 2025-04-08 16:48:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-08 16:48:55 --> Router Class Initialized
INFO - 2025-04-08 16:48:55 --> Output Class Initialized
INFO - 2025-04-08 16:48:55 --> Security Class Initialized
DEBUG - 2025-04-08 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:48:55 --> Input Class Initialized
INFO - 2025-04-08 16:48:55 --> Language Class Initialized
INFO - 2025-04-08 16:48:55 --> Language Class Initialized
INFO - 2025-04-08 16:48:55 --> Config Class Initialized
INFO - 2025-04-08 16:48:55 --> Loader Class Initialized
INFO - 2025-04-08 16:48:55 --> Helper loaded: url_helper
INFO - 2025-04-08 16:48:55 --> Helper loaded: file_helper
INFO - 2025-04-08 16:48:55 --> Helper loaded: html_helper
INFO - 2025-04-08 16:48:55 --> Helper loaded: form_helper
INFO - 2025-04-08 16:48:55 --> Helper loaded: text_helper
INFO - 2025-04-08 16:48:55 --> Helper loaded: lang_helper
INFO - 2025-04-08 16:48:55 --> Helper loaded: directory_helper
INFO - 2025-04-08 16:48:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 16:48:55 --> Database Driver Class Initialized
INFO - 2025-04-08 16:48:55 --> Email Class Initialized
INFO - 2025-04-08 16:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 16:48:55 --> Form Validation Class Initialized
INFO - 2025-04-08 16:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 16:48:55 --> Pagination Class Initialized
INFO - 2025-04-08 16:48:55 --> Controller Class Initialized
DEBUG - 2025-04-08 16:48:55 --> Auth MX_Controller Initialized
INFO - 2025-04-08 16:48:55 --> Model Class Initialized
DEBUG - 2025-04-08 16:48:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-08 16:48:55 --> Model Class Initialized
INFO - 2025-04-08 16:48:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-08 16:48:56 --> Config Class Initialized
INFO - 2025-04-08 16:48:56 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:48:56 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:48:56 --> Utf8 Class Initialized
INFO - 2025-04-08 16:48:56 --> URI Class Initialized
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-08 16:48:56 --> Router Class Initialized
INFO - 2025-04-08 16:48:56 --> Output Class Initialized
INFO - 2025-04-08 16:48:56 --> Security Class Initialized
DEBUG - 2025-04-08 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:48:56 --> Input Class Initialized
INFO - 2025-04-08 16:48:56 --> Language Class Initialized
INFO - 2025-04-08 16:48:56 --> Language Class Initialized
INFO - 2025-04-08 16:48:56 --> Config Class Initialized
INFO - 2025-04-08 16:48:56 --> Loader Class Initialized
INFO - 2025-04-08 16:48:56 --> Helper loaded: url_helper
INFO - 2025-04-08 16:48:56 --> Helper loaded: file_helper
INFO - 2025-04-08 16:48:56 --> Helper loaded: html_helper
INFO - 2025-04-08 16:48:56 --> Helper loaded: form_helper
INFO - 2025-04-08 16:48:56 --> Helper loaded: text_helper
INFO - 2025-04-08 16:48:56 --> Helper loaded: lang_helper
INFO - 2025-04-08 16:48:56 --> Helper loaded: directory_helper
INFO - 2025-04-08 16:48:56 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 16:48:56 --> Database Driver Class Initialized
INFO - 2025-04-08 16:48:56 --> Email Class Initialized
INFO - 2025-04-08 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 16:48:56 --> Form Validation Class Initialized
INFO - 2025-04-08 16:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 16:48:56 --> Pagination Class Initialized
INFO - 2025-04-08 16:48:56 --> Controller Class Initialized
DEBUG - 2025-04-08 16:48:56 --> Home MX_Controller Initialized
INFO - 2025-04-08 16:48:56 --> Model Class Initialized
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-08 16:48:56 --> Model Class Initialized
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 16:48:56 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 16:48:56 --> Model Class Initialized
ERROR - 2025-04-08 16:48:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 16:48:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 16:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 16:48:56 --> Final output sent to browser
DEBUG - 2025-04-08 16:48:56 --> Total execution time: 0.4833
INFO - 2025-04-08 16:49:04 --> Config Class Initialized
INFO - 2025-04-08 16:49:04 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:49:04 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:49:04 --> Utf8 Class Initialized
INFO - 2025-04-08 16:49:04 --> URI Class Initialized
DEBUG - 2025-04-08 16:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 16:49:04 --> Router Class Initialized
INFO - 2025-04-08 16:49:04 --> Output Class Initialized
INFO - 2025-04-08 16:49:04 --> Security Class Initialized
DEBUG - 2025-04-08 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:49:04 --> Input Class Initialized
INFO - 2025-04-08 16:49:04 --> Language Class Initialized
INFO - 2025-04-08 16:49:04 --> Language Class Initialized
INFO - 2025-04-08 16:49:04 --> Config Class Initialized
INFO - 2025-04-08 16:49:04 --> Loader Class Initialized
INFO - 2025-04-08 16:49:04 --> Helper loaded: url_helper
INFO - 2025-04-08 16:49:04 --> Helper loaded: file_helper
INFO - 2025-04-08 16:49:04 --> Helper loaded: html_helper
INFO - 2025-04-08 16:49:04 --> Helper loaded: form_helper
INFO - 2025-04-08 16:49:04 --> Helper loaded: text_helper
INFO - 2025-04-08 16:49:04 --> Helper loaded: lang_helper
INFO - 2025-04-08 16:49:04 --> Helper loaded: directory_helper
INFO - 2025-04-08 16:49:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 16:49:04 --> Database Driver Class Initialized
INFO - 2025-04-08 16:49:04 --> Email Class Initialized
INFO - 2025-04-08 16:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 16:49:04 --> Form Validation Class Initialized
INFO - 2025-04-08 16:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 16:49:04 --> Pagination Class Initialized
INFO - 2025-04-08 16:49:04 --> Controller Class Initialized
DEBUG - 2025-04-08 16:49:04 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 22:49:04 --> Model Class Initialized
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 22:49:04 --> Model Class Initialized
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 22:49:04 --> Model Class Initialized
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 22:49:04 --> Model Class Initialized
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 22:49:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 22:49:04 --> Model Class Initialized
ERROR - 2025-04-08 22:49:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 22:49:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 22:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 22:49:04 --> Final output sent to browser
DEBUG - 2025-04-08 22:49:04 --> Total execution time: 0.4713
INFO - 2025-04-08 16:49:04 --> Config Class Initialized
INFO - 2025-04-08 16:49:04 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:49:04 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:49:04 --> Utf8 Class Initialized
INFO - 2025-04-08 16:49:04 --> URI Class Initialized
INFO - 2025-04-08 16:49:04 --> Router Class Initialized
INFO - 2025-04-08 16:49:04 --> Output Class Initialized
INFO - 2025-04-08 16:49:04 --> Security Class Initialized
DEBUG - 2025-04-08 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:49:04 --> Input Class Initialized
INFO - 2025-04-08 16:49:04 --> Language Class Initialized
ERROR - 2025-04-08 16:49:04 --> 404 Page Not Found: /index
INFO - 2025-04-08 16:50:44 --> Config Class Initialized
INFO - 2025-04-08 16:50:44 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:50:44 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:50:44 --> Utf8 Class Initialized
INFO - 2025-04-08 16:50:44 --> URI Class Initialized
DEBUG - 2025-04-08 16:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-08 16:50:44 --> Router Class Initialized
INFO - 2025-04-08 16:50:44 --> Output Class Initialized
INFO - 2025-04-08 16:50:44 --> Security Class Initialized
DEBUG - 2025-04-08 16:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:50:44 --> Input Class Initialized
INFO - 2025-04-08 16:50:44 --> Language Class Initialized
INFO - 2025-04-08 16:50:44 --> Language Class Initialized
INFO - 2025-04-08 16:50:44 --> Config Class Initialized
INFO - 2025-04-08 16:50:44 --> Loader Class Initialized
INFO - 2025-04-08 16:50:44 --> Helper loaded: url_helper
INFO - 2025-04-08 16:50:44 --> Helper loaded: file_helper
INFO - 2025-04-08 16:50:44 --> Helper loaded: html_helper
INFO - 2025-04-08 16:50:44 --> Helper loaded: form_helper
INFO - 2025-04-08 16:50:44 --> Helper loaded: text_helper
INFO - 2025-04-08 16:50:44 --> Helper loaded: lang_helper
INFO - 2025-04-08 16:50:44 --> Helper loaded: directory_helper
INFO - 2025-04-08 16:50:44 --> Helper loaded: dompdf_helper
INFO - 2025-04-08 16:50:44 --> Database Driver Class Initialized
INFO - 2025-04-08 16:50:44 --> Email Class Initialized
INFO - 2025-04-08 16:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-08 16:50:44 --> Form Validation Class Initialized
INFO - 2025-04-08 16:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-08 16:50:44 --> Pagination Class Initialized
INFO - 2025-04-08 16:50:44 --> Controller Class Initialized
DEBUG - 2025-04-08 16:50:44 --> Invoice MX_Controller Initialized
INFO - 2025-04-08 22:50:44 --> Model Class Initialized
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-08 22:50:44 --> Model Class Initialized
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-08 22:50:44 --> Model Class Initialized
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-08 22:50:44 --> Model Class Initialized
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-08 22:50:44 --> Template MX_Controller Initialized
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-08 22:50:44 --> Model Class Initialized
ERROR - 2025-04-08 22:50:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-08 22:50:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_payment.php
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-08 22:50:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-08 22:50:44 --> Final output sent to browser
DEBUG - 2025-04-08 22:50:44 --> Total execution time: 0.1785
INFO - 2025-04-08 16:50:44 --> Config Class Initialized
INFO - 2025-04-08 16:50:44 --> Hooks Class Initialized
DEBUG - 2025-04-08 16:50:44 --> UTF-8 Support Enabled
INFO - 2025-04-08 16:50:44 --> Utf8 Class Initialized
INFO - 2025-04-08 16:50:44 --> URI Class Initialized
INFO - 2025-04-08 16:50:44 --> Router Class Initialized
INFO - 2025-04-08 16:50:44 --> Output Class Initialized
INFO - 2025-04-08 16:50:44 --> Security Class Initialized
DEBUG - 2025-04-08 16:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-08 16:50:44 --> Input Class Initialized
INFO - 2025-04-08 16:50:44 --> Language Class Initialized
ERROR - 2025-04-08 16:50:44 --> 404 Page Not Found: /index
