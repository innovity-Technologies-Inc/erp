<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-12 00:26:07 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 00:26:07 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 00:26:07 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 00:26:07 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-12 00:26:07 --> Template MX_Controller Initialized
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-12 00:26:07 --> Model Class Initialized
ERROR - 2025-04-12 00:26:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-12 00:26:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-12 00:26:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-12 00:26:07 --> Final output sent to browser
DEBUG - 2025-04-12 00:26:07 --> Total execution time: 0.1234
INFO - 2025-04-12 00:26:08 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 00:26:08 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 00:26:08 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 00:26:08 --> Model Class Initialized
INFO - 2025-04-12 00:26:08 --> Final output sent to browser
DEBUG - 2025-04-12 00:26:08 --> Total execution time: 0.0627
INFO - 2025-04-12 00:26:13 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 00:26:13 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 00:26:13 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 00:26:13 --> Model Class Initialized
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-12 00:26:13 --> Template MX_Controller Initialized
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-12 00:26:13 --> Model Class Initialized
ERROR - 2025-04-12 00:26:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-12 00:26:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-12 00:26:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-12 00:26:13 --> Final output sent to browser
DEBUG - 2025-04-12 00:26:13 --> Total execution time: 0.1760
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-12 01:09:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
ERROR - 2025-04-12 01:09:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-12 01:09:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-12 01:09:20 --> Final output sent to browser
DEBUG - 2025-04-12 01:09:20 --> Total execution time: 0.1494
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
DEBUG - 2025-04-12 01:09:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 01:09:20 --> Model Class Initialized
INFO - 2025-04-12 01:09:20 --> Final output sent to browser
DEBUG - 2025-04-12 01:09:20 --> Total execution time: 0.0620
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
INFO - 2025-04-12 01:11:57 --> Final output sent to browser
DEBUG - 2025-04-12 01:11:57 --> Total execution time: 0.0083
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 01:11:57 --> Model Class Initialized
INFO - 2025-04-12 01:11:57 --> Final output sent to browser
DEBUG - 2025-04-12 01:11:57 --> Total execution time: 0.0134
INFO - 2025-04-12 01:11:58 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 01:11:58 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 01:11:58 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 01:11:58 --> Model Class Initialized
INFO - 2025-04-12 01:11:58 --> Final output sent to browser
DEBUG - 2025-04-12 01:11:58 --> Total execution time: 0.0162
INFO - 2025-04-12 01:11:59 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 01:11:59 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 01:11:59 --> Model Class Initialized
DEBUG - 2025-04-12 01:11:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 01:11:59 --> Model Class Initialized
INFO - 2025-04-12 01:11:59 --> Final output sent to browser
DEBUG - 2025-04-12 01:11:59 --> Total execution time: 0.0347
INFO - 2025-04-12 01:12:58 --> Model Class Initialized
DEBUG - 2025-04-12 01:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 01:12:58 --> Model Class Initialized
DEBUG - 2025-04-12 01:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 01:12:58 --> Model Class Initialized
DEBUG - 2025-04-12 01:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 01:12:58 --> Model Class Initialized
INFO - 2025-04-12 01:12:58 --> Final output sent to browser
DEBUG - 2025-04-12 01:12:58 --> Total execution time: 0.0138
INFO - 2025-04-12 02:31:42 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 02:31:42 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 02:31:42 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 02:31:42 --> Model Class Initialized
INFO - 2025-04-12 02:31:42 --> Final output sent to browser
DEBUG - 2025-04-12 02:31:42 --> Total execution time: 0.0119
INFO - 2025-04-12 02:31:43 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 02:31:43 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 02:31:43 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 02:31:43 --> Model Class Initialized
INFO - 2025-04-12 02:31:43 --> Final output sent to browser
DEBUG - 2025-04-12 02:31:43 --> Total execution time: 0.0178
INFO - 2025-04-12 02:31:47 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 02:31:47 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 02:31:47 --> Model Class Initialized
DEBUG - 2025-04-12 02:31:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 02:31:47 --> Model Class Initialized
INFO - 2025-04-12 02:31:47 --> Final output sent to browser
DEBUG - 2025-04-12 02:31:47 --> Total execution time: 0.0094
INFO - 2025-04-12 02:32:35 --> Model Class Initialized
DEBUG - 2025-04-12 02:32:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 02:32:35 --> Model Class Initialized
DEBUG - 2025-04-12 02:32:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 02:32:35 --> Model Class Initialized
DEBUG - 2025-04-12 02:32:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 02:32:35 --> Model Class Initialized
INFO - 2025-04-12 02:32:35 --> Final output sent to browser
DEBUG - 2025-04-12 02:32:35 --> Total execution time: 0.0198
INFO - 2025-04-12 02:32:36 --> Model Class Initialized
DEBUG - 2025-04-12 02:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 02:32:36 --> Model Class Initialized
DEBUG - 2025-04-12 02:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 02:32:36 --> Model Class Initialized
DEBUG - 2025-04-12 02:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 02:32:36 --> Model Class Initialized
INFO - 2025-04-12 02:32:36 --> Final output sent to browser
DEBUG - 2025-04-12 02:32:36 --> Total execution time: 0.0046
INFO - 2025-04-12 02:33:21 --> Model Class Initialized
DEBUG - 2025-04-12 02:33:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 02:33:21 --> Model Class Initialized
DEBUG - 2025-04-12 02:33:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 02:33:21 --> Model Class Initialized
DEBUG - 2025-04-12 02:33:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 02:33:21 --> Model Class Initialized
INFO - 2025-04-12 02:33:21 --> Final output sent to browser
DEBUG - 2025-04-12 02:33:21 --> Total execution time: 0.0069
INFO - 2025-04-12 02:33:24 --> Model Class Initialized
DEBUG - 2025-04-12 02:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-12 02:33:24 --> Model Class Initialized
DEBUG - 2025-04-12 02:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-12 02:33:24 --> Model Class Initialized
DEBUG - 2025-04-12 02:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-12 02:33:24 --> Model Class Initialized
INFO - 2025-04-12 02:33:24 --> Final output sent to browser
DEBUG - 2025-04-12 02:33:24 --> Total execution time: 0.0276
INFO - 2025-04-12 15:39:37 --> Config Class Initialized
INFO - 2025-04-12 15:39:37 --> Hooks Class Initialized
DEBUG - 2025-04-12 15:39:37 --> UTF-8 Support Enabled
INFO - 2025-04-12 15:39:37 --> Utf8 Class Initialized
INFO - 2025-04-12 15:39:37 --> URI Class Initialized
DEBUG - 2025-04-12 15:39:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-12 15:39:37 --> No URI present. Default controller set.
INFO - 2025-04-12 15:39:37 --> Router Class Initialized
INFO - 2025-04-12 15:39:37 --> Output Class Initialized
INFO - 2025-04-12 15:39:37 --> Security Class Initialized
DEBUG - 2025-04-12 15:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-12 15:39:37 --> Input Class Initialized
INFO - 2025-04-12 15:39:37 --> Language Class Initialized
INFO - 2025-04-12 15:39:37 --> Language Class Initialized
INFO - 2025-04-12 15:39:37 --> Config Class Initialized
INFO - 2025-04-12 15:39:37 --> Loader Class Initialized
INFO - 2025-04-12 15:39:37 --> Helper loaded: url_helper
INFO - 2025-04-12 15:39:37 --> Helper loaded: file_helper
INFO - 2025-04-12 15:39:37 --> Helper loaded: html_helper
INFO - 2025-04-12 15:39:37 --> Helper loaded: form_helper
INFO - 2025-04-12 15:39:37 --> Helper loaded: text_helper
INFO - 2025-04-12 15:39:37 --> Helper loaded: lang_helper
INFO - 2025-04-12 15:39:37 --> Helper loaded: directory_helper
INFO - 2025-04-12 15:39:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-12 15:39:37 --> Database Driver Class Initialized
INFO - 2025-04-12 15:39:37 --> Email Class Initialized
INFO - 2025-04-12 15:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-12 15:39:37 --> Form Validation Class Initialized
INFO - 2025-04-12 15:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-12 15:39:37 --> Pagination Class Initialized
INFO - 2025-04-12 15:39:37 --> Controller Class Initialized
DEBUG - 2025-04-12 15:39:37 --> Auth MX_Controller Initialized
INFO - 2025-04-12 15:39:37 --> Model Class Initialized
DEBUG - 2025-04-12 15:39:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-12 15:39:37 --> Model Class Initialized
DEBUG - 2025-04-12 15:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-12 15:39:38 --> Template MX_Controller Initialized
DEBUG - 2025-04-12 15:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-12 15:39:38 --> Model Class Initialized
DEBUG - 2025-04-12 15:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-12 15:39:38 --> Final output sent to browser
DEBUG - 2025-04-12 15:39:38 --> Total execution time: 0.0780
INFO - 2025-04-12 16:10:41 --> Config Class Initialized
INFO - 2025-04-12 16:10:41 --> Hooks Class Initialized
DEBUG - 2025-04-12 16:10:41 --> UTF-8 Support Enabled
INFO - 2025-04-12 16:10:41 --> Utf8 Class Initialized
INFO - 2025-04-12 16:10:41 --> URI Class Initialized
DEBUG - 2025-04-12 16:10:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-12 16:10:41 --> Router Class Initialized
INFO - 2025-04-12 16:10:41 --> Output Class Initialized
INFO - 2025-04-12 16:10:41 --> Security Class Initialized
DEBUG - 2025-04-12 16:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-12 16:10:41 --> Input Class Initialized
INFO - 2025-04-12 16:10:41 --> Language Class Initialized
INFO - 2025-04-12 16:10:41 --> Language Class Initialized
INFO - 2025-04-12 16:10:41 --> Config Class Initialized
INFO - 2025-04-12 16:10:41 --> Loader Class Initialized
INFO - 2025-04-12 16:10:41 --> Helper loaded: url_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: file_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: html_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: form_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: text_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: lang_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: directory_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-12 16:10:41 --> Database Driver Class Initialized
INFO - 2025-04-12 16:10:41 --> Email Class Initialized
INFO - 2025-04-12 16:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-12 16:10:41 --> Form Validation Class Initialized
INFO - 2025-04-12 16:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-12 16:10:41 --> Pagination Class Initialized
INFO - 2025-04-12 16:10:41 --> Controller Class Initialized
DEBUG - 2025-04-12 16:10:41 --> Home MX_Controller Initialized
INFO - 2025-04-12 16:10:41 --> Model Class Initialized
DEBUG - 2025-04-12 16:10:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-12 16:10:41 --> Model Class Initialized
INFO - 2025-04-12 16:10:41 --> Config Class Initialized
INFO - 2025-04-12 16:10:41 --> Hooks Class Initialized
DEBUG - 2025-04-12 16:10:41 --> UTF-8 Support Enabled
INFO - 2025-04-12 16:10:41 --> Utf8 Class Initialized
INFO - 2025-04-12 16:10:41 --> URI Class Initialized
DEBUG - 2025-04-12 16:10:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-12 16:10:41 --> Router Class Initialized
INFO - 2025-04-12 16:10:41 --> Output Class Initialized
INFO - 2025-04-12 16:10:41 --> Security Class Initialized
DEBUG - 2025-04-12 16:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-12 16:10:41 --> Input Class Initialized
INFO - 2025-04-12 16:10:41 --> Language Class Initialized
INFO - 2025-04-12 16:10:41 --> Language Class Initialized
INFO - 2025-04-12 16:10:41 --> Config Class Initialized
INFO - 2025-04-12 16:10:41 --> Loader Class Initialized
INFO - 2025-04-12 16:10:41 --> Helper loaded: url_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: file_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: html_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: form_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: text_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: lang_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: directory_helper
INFO - 2025-04-12 16:10:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-12 16:10:41 --> Database Driver Class Initialized
INFO - 2025-04-12 16:10:41 --> Email Class Initialized
INFO - 2025-04-12 16:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-12 16:10:41 --> Form Validation Class Initialized
INFO - 2025-04-12 16:10:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-12 16:10:41 --> Pagination Class Initialized
INFO - 2025-04-12 16:10:41 --> Controller Class Initialized
DEBUG - 2025-04-12 16:10:41 --> Auth MX_Controller Initialized
INFO - 2025-04-12 16:10:41 --> Model Class Initialized
DEBUG - 2025-04-12 16:10:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-12 16:10:41 --> Model Class Initialized
DEBUG - 2025-04-12 16:10:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-12 16:10:41 --> Template MX_Controller Initialized
DEBUG - 2025-04-12 16:10:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-12 16:10:41 --> Model Class Initialized
DEBUG - 2025-04-12 16:10:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-12 16:10:41 --> Final output sent to browser
DEBUG - 2025-04-12 16:10:41 --> Total execution time: 0.0336
INFO - 2025-04-12 16:10:49 --> Config Class Initialized
INFO - 2025-04-12 16:10:49 --> Hooks Class Initialized
DEBUG - 2025-04-12 16:10:49 --> UTF-8 Support Enabled
INFO - 2025-04-12 16:10:49 --> Utf8 Class Initialized
INFO - 2025-04-12 16:10:49 --> URI Class Initialized
DEBUG - 2025-04-12 16:10:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-12 16:10:49 --> Router Class Initialized
INFO - 2025-04-12 16:10:49 --> Output Class Initialized
INFO - 2025-04-12 16:10:49 --> Security Class Initialized
DEBUG - 2025-04-12 16:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-12 16:10:49 --> Input Class Initialized
INFO - 2025-04-12 16:10:49 --> Language Class Initialized
INFO - 2025-04-12 16:10:49 --> Language Class Initialized
INFO - 2025-04-12 16:10:49 --> Config Class Initialized
INFO - 2025-04-12 16:10:49 --> Loader Class Initialized
INFO - 2025-04-12 16:10:49 --> Helper loaded: url_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: file_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: html_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: form_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: text_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: lang_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: directory_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-12 16:10:49 --> Database Driver Class Initialized
INFO - 2025-04-12 16:10:49 --> Email Class Initialized
INFO - 2025-04-12 16:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-12 16:10:49 --> Form Validation Class Initialized
INFO - 2025-04-12 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-12 16:10:49 --> Pagination Class Initialized
INFO - 2025-04-12 16:10:49 --> Controller Class Initialized
DEBUG - 2025-04-12 16:10:49 --> Auth MX_Controller Initialized
INFO - 2025-04-12 16:10:49 --> Model Class Initialized
DEBUG - 2025-04-12 16:10:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-12 16:10:49 --> Model Class Initialized
INFO - 2025-04-12 16:10:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-12 16:10:49 --> Config Class Initialized
INFO - 2025-04-12 16:10:49 --> Hooks Class Initialized
DEBUG - 2025-04-12 16:10:49 --> UTF-8 Support Enabled
INFO - 2025-04-12 16:10:49 --> Utf8 Class Initialized
INFO - 2025-04-12 16:10:49 --> URI Class Initialized
DEBUG - 2025-04-12 16:10:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-12 16:10:49 --> Router Class Initialized
INFO - 2025-04-12 16:10:49 --> Output Class Initialized
INFO - 2025-04-12 16:10:49 --> Security Class Initialized
DEBUG - 2025-04-12 16:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-12 16:10:49 --> Input Class Initialized
INFO - 2025-04-12 16:10:49 --> Language Class Initialized
INFO - 2025-04-12 16:10:49 --> Language Class Initialized
INFO - 2025-04-12 16:10:49 --> Config Class Initialized
INFO - 2025-04-12 16:10:49 --> Loader Class Initialized
INFO - 2025-04-12 16:10:49 --> Helper loaded: url_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: file_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: html_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: form_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: text_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: lang_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: directory_helper
INFO - 2025-04-12 16:10:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-12 16:10:49 --> Database Driver Class Initialized
INFO - 2025-04-12 16:10:49 --> Email Class Initialized
INFO - 2025-04-12 16:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-12 16:10:49 --> Form Validation Class Initialized
INFO - 2025-04-12 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-12 16:10:49 --> Pagination Class Initialized
INFO - 2025-04-12 16:10:49 --> Controller Class Initialized
DEBUG - 2025-04-12 16:10:49 --> Home MX_Controller Initialized
INFO - 2025-04-12 16:10:49 --> Model Class Initialized
DEBUG - 2025-04-12 16:10:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-12 16:10:49 --> Model Class Initialized
DEBUG - 2025-04-12 16:10:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-12 16:10:49 --> Template MX_Controller Initialized
DEBUG - 2025-04-12 16:10:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-12 16:10:49 --> Model Class Initialized
ERROR - 2025-04-12 16:10:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-12 16:10:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-12 16:10:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-12 16:10:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-12 16:10:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-12 16:10:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-12 16:10:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-12 16:10:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-12 16:10:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-12 16:10:50 --> Final output sent to browser
DEBUG - 2025-04-12 16:10:50 --> Total execution time: 0.7114
