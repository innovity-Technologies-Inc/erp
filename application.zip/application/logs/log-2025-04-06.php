<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-06 06:53:23 --> Config Class Initialized
INFO - 2025-04-06 06:53:23 --> Hooks Class Initialized
DEBUG - 2025-04-06 06:53:23 --> UTF-8 Support Enabled
INFO - 2025-04-06 06:53:23 --> Utf8 Class Initialized
INFO - 2025-04-06 06:53:23 --> URI Class Initialized
INFO - 2025-04-06 06:53:23 --> Router Class Initialized
INFO - 2025-04-06 06:53:23 --> Output Class Initialized
INFO - 2025-04-06 06:53:23 --> Security Class Initialized
DEBUG - 2025-04-06 06:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-06 06:53:23 --> Input Class Initialized
INFO - 2025-04-06 06:53:23 --> Language Class Initialized
INFO - 2025-04-06 06:53:23 --> Language Class Initialized
INFO - 2025-04-06 06:53:23 --> Config Class Initialized
INFO - 2025-04-06 06:53:23 --> Loader Class Initialized
INFO - 2025-04-06 06:53:23 --> Helper loaded: url_helper
INFO - 2025-04-06 06:53:23 --> Helper loaded: file_helper
INFO - 2025-04-06 06:53:23 --> Helper loaded: html_helper
INFO - 2025-04-06 06:53:23 --> Helper loaded: form_helper
INFO - 2025-04-06 06:53:23 --> Helper loaded: text_helper
INFO - 2025-04-06 06:53:23 --> Helper loaded: lang_helper
INFO - 2025-04-06 06:53:23 --> Helper loaded: directory_helper
INFO - 2025-04-06 06:53:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-06 06:53:23 --> Database Driver Class Initialized
INFO - 2025-04-06 06:53:23 --> Email Class Initialized
INFO - 2025-04-06 06:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-06 06:53:23 --> Form Validation Class Initialized
INFO - 2025-04-06 06:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-06 06:53:23 --> Pagination Class Initialized
INFO - 2025-04-06 06:53:23 --> Controller Class Initialized
INFO - 2025-04-06 06:53:23 --> Model Class Initialized
INFO - 2025-04-06 06:53:23 --> Final output sent to browser
DEBUG - 2025-04-06 06:53:23 --> Total execution time: 0.0958
INFO - 2025-04-06 08:41:35 --> Config Class Initialized
INFO - 2025-04-06 08:41:35 --> Hooks Class Initialized
DEBUG - 2025-04-06 08:41:35 --> UTF-8 Support Enabled
INFO - 2025-04-06 08:41:35 --> Utf8 Class Initialized
INFO - 2025-04-06 08:41:35 --> URI Class Initialized
INFO - 2025-04-06 08:41:35 --> Router Class Initialized
INFO - 2025-04-06 08:41:35 --> Output Class Initialized
INFO - 2025-04-06 08:41:35 --> Security Class Initialized
DEBUG - 2025-04-06 08:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-06 08:41:35 --> Input Class Initialized
INFO - 2025-04-06 08:41:35 --> Language Class Initialized
INFO - 2025-04-06 08:41:35 --> Language Class Initialized
INFO - 2025-04-06 08:41:35 --> Config Class Initialized
INFO - 2025-04-06 08:41:35 --> Loader Class Initialized
INFO - 2025-04-06 08:41:35 --> Helper loaded: url_helper
INFO - 2025-04-06 08:41:35 --> Helper loaded: file_helper
INFO - 2025-04-06 08:41:35 --> Helper loaded: html_helper
INFO - 2025-04-06 08:41:35 --> Helper loaded: form_helper
INFO - 2025-04-06 08:41:35 --> Helper loaded: text_helper
INFO - 2025-04-06 08:41:35 --> Helper loaded: lang_helper
INFO - 2025-04-06 08:41:35 --> Helper loaded: directory_helper
INFO - 2025-04-06 08:41:35 --> Helper loaded: dompdf_helper
INFO - 2025-04-06 08:41:35 --> Database Driver Class Initialized
INFO - 2025-04-06 08:41:35 --> Email Class Initialized
INFO - 2025-04-06 08:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-06 08:41:35 --> Form Validation Class Initialized
INFO - 2025-04-06 08:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-06 08:41:35 --> Pagination Class Initialized
INFO - 2025-04-06 08:41:35 --> Controller Class Initialized
INFO - 2025-04-06 08:41:35 --> Model Class Initialized
DEBUG - 2025-04-06 08:41:35 --> 🧾 insert_invoice_payment API called
DEBUG - 2025-04-06 08:41:35 --> 📥 Raw Input: 
INFO - 2025-04-06 08:41:35 --> Final output sent to browser
DEBUG - 2025-04-06 08:41:35 --> Total execution time: 0.0388
INFO - 2025-04-06 08:44:25 --> Config Class Initialized
INFO - 2025-04-06 08:44:25 --> Hooks Class Initialized
DEBUG - 2025-04-06 08:44:25 --> UTF-8 Support Enabled
INFO - 2025-04-06 08:44:25 --> Utf8 Class Initialized
INFO - 2025-04-06 08:44:25 --> URI Class Initialized
INFO - 2025-04-06 08:44:25 --> Router Class Initialized
INFO - 2025-04-06 08:44:25 --> Output Class Initialized
INFO - 2025-04-06 08:44:25 --> Security Class Initialized
DEBUG - 2025-04-06 08:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-06 08:44:25 --> Input Class Initialized
INFO - 2025-04-06 08:44:25 --> Language Class Initialized
INFO - 2025-04-06 08:44:25 --> Language Class Initialized
INFO - 2025-04-06 08:44:25 --> Config Class Initialized
INFO - 2025-04-06 08:44:25 --> Loader Class Initialized
INFO - 2025-04-06 08:44:25 --> Helper loaded: url_helper
INFO - 2025-04-06 08:44:25 --> Helper loaded: file_helper
INFO - 2025-04-06 08:44:25 --> Helper loaded: html_helper
INFO - 2025-04-06 08:44:25 --> Helper loaded: form_helper
INFO - 2025-04-06 08:44:25 --> Helper loaded: text_helper
INFO - 2025-04-06 08:44:25 --> Helper loaded: lang_helper
INFO - 2025-04-06 08:44:25 --> Helper loaded: directory_helper
INFO - 2025-04-06 08:44:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-06 08:44:25 --> Database Driver Class Initialized
INFO - 2025-04-06 08:44:25 --> Email Class Initialized
INFO - 2025-04-06 08:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-06 08:44:25 --> Form Validation Class Initialized
INFO - 2025-04-06 08:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-06 08:44:25 --> Pagination Class Initialized
INFO - 2025-04-06 08:44:25 --> Controller Class Initialized
INFO - 2025-04-06 08:44:25 --> Model Class Initialized
DEBUG - 2025-04-06 08:44:25 --> 🧾 insert_invoice_payment API called
DEBUG - 2025-04-06 08:44:25 --> 📥 Parsed Input: Array
(
    [invoice_date] => 2025-04-06
    [createby] => 1
    [customer_id] => 1
    [paid_amount] => 350
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [total_amount] => 300
    [payment_type] => 1020502
    [payment_ref] => TXN-987654321
    [status] => 0
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 4
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

            [1] => Array
                (
                    [product_id] => 84213421
                    [product_quantity] => 5
                    [product_rate] => 10
                    [serial_no] => 
                )

            [2] => Array
                (
                    [product_id] => 34769578
                    [product_quantity] => 1
                    [product_rate] => 200
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-04-06 08:44:25 --> 📦 Parsed Products: Array
(
    [0] => Array
        (
            [product_id] => 123456
            [product_quantity] => 4
            [product_rate] => 25
            [serial_no] => ABC1234
        )

    [1] => Array
        (
            [product_id] => 84213421
            [product_quantity] => 5
            [product_rate] => 10
            [serial_no] => 
        )

    [2] => Array
        (
            [product_id] => 34769578
            [product_quantity] => 1
            [product_rate] => 200
            [serial_no] => 
        )

)

DEBUG - 2025-04-06 08:44:25 --> ✅ Invoice payment inserted with ID: 1
INFO - 2025-04-06 08:44:25 --> Final output sent to browser
DEBUG - 2025-04-06 08:44:25 --> Total execution time: 0.0371
INFO - 2025-04-06 08:58:35 --> Config Class Initialized
INFO - 2025-04-06 08:58:35 --> Hooks Class Initialized
DEBUG - 2025-04-06 08:58:35 --> UTF-8 Support Enabled
INFO - 2025-04-06 08:58:35 --> Utf8 Class Initialized
INFO - 2025-04-06 08:58:35 --> URI Class Initialized
INFO - 2025-04-06 08:58:35 --> Router Class Initialized
INFO - 2025-04-06 08:58:35 --> Output Class Initialized
INFO - 2025-04-06 08:58:35 --> Security Class Initialized
DEBUG - 2025-04-06 08:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-06 08:58:35 --> Input Class Initialized
INFO - 2025-04-06 08:58:35 --> Language Class Initialized
INFO - 2025-04-06 08:58:35 --> Language Class Initialized
INFO - 2025-04-06 08:58:35 --> Config Class Initialized
INFO - 2025-04-06 08:58:35 --> Loader Class Initialized
INFO - 2025-04-06 08:58:35 --> Helper loaded: url_helper
INFO - 2025-04-06 08:58:35 --> Helper loaded: file_helper
INFO - 2025-04-06 08:58:35 --> Helper loaded: html_helper
INFO - 2025-04-06 08:58:35 --> Helper loaded: form_helper
INFO - 2025-04-06 08:58:35 --> Helper loaded: text_helper
INFO - 2025-04-06 08:58:35 --> Helper loaded: lang_helper
INFO - 2025-04-06 08:58:35 --> Helper loaded: directory_helper
INFO - 2025-04-06 08:58:35 --> Helper loaded: dompdf_helper
INFO - 2025-04-06 08:58:35 --> Database Driver Class Initialized
INFO - 2025-04-06 08:58:35 --> Email Class Initialized
INFO - 2025-04-06 08:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-06 08:58:35 --> Form Validation Class Initialized
INFO - 2025-04-06 08:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-06 08:58:35 --> Pagination Class Initialized
INFO - 2025-04-06 08:58:35 --> Controller Class Initialized
INFO - 2025-04-06 08:58:35 --> Model Class Initialized
DEBUG - 2025-04-06 08:58:35 --> 🧾 insert_invoice_payment API called
DEBUG - 2025-04-06 08:58:35 --> 📥 Parsed Input: Array
(
    [invoice_date] => 2025-04-06
    [createby] => 1
    [customer_id] => 1
    [paid_amount] => 350
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [total_amount] => 300
    [payment_type] => 1020502
    [payment_ref] => TXN-987654321
    [status] => 0
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 4
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

            [1] => Array
                (
                    [product_id] => 84213421
                    [product_quantity] => 5
                    [product_rate] => 10
                    [serial_no] => 
                )

            [2] => Array
                (
                    [product_id] => 34769578
                    [product_quantity] => 1
                    [product_rate] => 200
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-04-06 08:58:35 --> 📦 Parsed Products: Array
(
    [0] => Array
        (
            [product_id] => 123456
            [product_quantity] => 4
            [product_rate] => 25
            [serial_no] => ABC1234
        )

    [1] => Array
        (
            [product_id] => 84213421
            [product_quantity] => 5
            [product_rate] => 10
            [serial_no] => 
        )

    [2] => Array
        (
            [product_id] => 34769578
            [product_quantity] => 1
            [product_rate] => 200
            [serial_no] => 
        )

)

DEBUG - 2025-04-06 08:58:35 --> ✅ Invoice payment inserted with ID: 2
INFO - 2025-04-06 08:58:35 --> Final output sent to browser
DEBUG - 2025-04-06 08:58:35 --> Total execution time: 0.0213
INFO - 2025-04-06 10:17:12 --> Config Class Initialized
INFO - 2025-04-06 10:17:12 --> Hooks Class Initialized
DEBUG - 2025-04-06 10:17:12 --> UTF-8 Support Enabled
INFO - 2025-04-06 10:17:12 --> Utf8 Class Initialized
INFO - 2025-04-06 10:17:12 --> URI Class Initialized
INFO - 2025-04-06 10:17:12 --> Router Class Initialized
INFO - 2025-04-06 10:17:12 --> Output Class Initialized
INFO - 2025-04-06 10:17:12 --> Security Class Initialized
DEBUG - 2025-04-06 10:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-06 10:17:12 --> Input Class Initialized
INFO - 2025-04-06 10:17:12 --> Language Class Initialized
INFO - 2025-04-06 10:17:12 --> Language Class Initialized
INFO - 2025-04-06 10:17:12 --> Config Class Initialized
INFO - 2025-04-06 10:17:12 --> Loader Class Initialized
INFO - 2025-04-06 10:17:12 --> Helper loaded: url_helper
INFO - 2025-04-06 10:17:12 --> Helper loaded: file_helper
INFO - 2025-04-06 10:17:12 --> Helper loaded: html_helper
INFO - 2025-04-06 10:17:12 --> Helper loaded: form_helper
INFO - 2025-04-06 10:17:12 --> Helper loaded: text_helper
INFO - 2025-04-06 10:17:12 --> Helper loaded: lang_helper
INFO - 2025-04-06 10:17:12 --> Helper loaded: directory_helper
INFO - 2025-04-06 10:17:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-06 10:17:12 --> Database Driver Class Initialized
INFO - 2025-04-06 10:17:12 --> Email Class Initialized
INFO - 2025-04-06 10:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-06 10:17:12 --> Form Validation Class Initialized
INFO - 2025-04-06 10:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-06 10:17:12 --> Pagination Class Initialized
INFO - 2025-04-06 10:17:12 --> Controller Class Initialized
INFO - 2025-04-06 10:17:12 --> Model Class Initialized
DEBUG - 2025-04-06 10:17:12 --> 🧾 insert_invoice_payment API called
DEBUG - 2025-04-06 10:17:12 --> 📥 Parsed Input: Array
(
    [invoice_date] => 2025-04-06
    [createby] => 1
    [customer_id] => 1
    [paid_amount] => 350
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [total_amount] => 300
    [payment_type] => 1020502
    [payment_ref] => TXN-987654321
    [status] => 0
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 4
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

            [1] => Array
                (
                    [product_id] => 84213421
                    [product_quantity] => 5
                    [product_rate] => 10
                    [serial_no] => 
                )

            [2] => Array
                (
                    [product_id] => 34769578
                    [product_quantity] => 1
                    [product_rate] => 200
                    [serial_no] => 
                )

        )

    [transaction_ref] => TTT-123456
)

DEBUG - 2025-04-06 10:17:12 --> 📦 Parsed Products: Array
(
    [0] => Array
        (
            [product_id] => 123456
            [product_quantity] => 4
            [product_rate] => 25
            [serial_no] => ABC1234
        )

    [1] => Array
        (
            [product_id] => 84213421
            [product_quantity] => 5
            [product_rate] => 10
            [serial_no] => 
        )

    [2] => Array
        (
            [product_id] => 34769578
            [product_quantity] => 1
            [product_rate] => 200
            [serial_no] => 
        )

)

DEBUG - 2025-04-06 10:17:12 --> ✅ Invoice payment inserted with ID: 3
INFO - 2025-04-06 10:17:12 --> Final output sent to browser
DEBUG - 2025-04-06 10:17:12 --> Total execution time: 0.0366
INFO - 2025-04-06 10:17:33 --> Config Class Initialized
INFO - 2025-04-06 10:17:33 --> Hooks Class Initialized
DEBUG - 2025-04-06 10:17:33 --> UTF-8 Support Enabled
INFO - 2025-04-06 10:17:33 --> Utf8 Class Initialized
INFO - 2025-04-06 10:17:33 --> URI Class Initialized
INFO - 2025-04-06 10:17:33 --> Router Class Initialized
INFO - 2025-04-06 10:17:33 --> Output Class Initialized
INFO - 2025-04-06 10:17:33 --> Security Class Initialized
DEBUG - 2025-04-06 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-06 10:17:33 --> Input Class Initialized
INFO - 2025-04-06 10:17:33 --> Language Class Initialized
INFO - 2025-04-06 10:17:33 --> Language Class Initialized
INFO - 2025-04-06 10:17:33 --> Config Class Initialized
INFO - 2025-04-06 10:17:33 --> Loader Class Initialized
INFO - 2025-04-06 10:17:33 --> Helper loaded: url_helper
INFO - 2025-04-06 10:17:33 --> Helper loaded: file_helper
INFO - 2025-04-06 10:17:33 --> Helper loaded: html_helper
INFO - 2025-04-06 10:17:33 --> Helper loaded: form_helper
INFO - 2025-04-06 10:17:33 --> Helper loaded: text_helper
INFO - 2025-04-06 10:17:33 --> Helper loaded: lang_helper
INFO - 2025-04-06 10:17:33 --> Helper loaded: directory_helper
INFO - 2025-04-06 10:17:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-06 10:17:33 --> Database Driver Class Initialized
INFO - 2025-04-06 10:17:33 --> Email Class Initialized
INFO - 2025-04-06 10:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-06 10:17:33 --> Form Validation Class Initialized
INFO - 2025-04-06 10:17:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-06 10:17:33 --> Pagination Class Initialized
INFO - 2025-04-06 10:17:33 --> Controller Class Initialized
INFO - 2025-04-06 10:17:33 --> Model Class Initialized
DEBUG - 2025-04-06 10:17:33 --> 🧾 insert_invoice_payment API called
DEBUG - 2025-04-06 10:17:33 --> 📥 Parsed Input: Array
(
    [invoice_date] => 2025-04-06
    [createby] => 1
    [customer_id] => 1
    [paid_amount] => 350
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [total_amount] => 300
    [payment_type] => 1020502
    [payment_ref] => TXN-987654321
    [status] => 0
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 4
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

            [1] => Array
                (
                    [product_id] => 84213421
                    [product_quantity] => 5
                    [product_rate] => 10
                    [serial_no] => 
                )

            [2] => Array
                (
                    [product_id] => 34769578
                    [product_quantity] => 1
                    [product_rate] => 200
                    [serial_no] => 
                )

        )

    [transaction_ref] => TTT-123456
)

DEBUG - 2025-04-06 10:17:33 --> 📦 Parsed Products: Array
(
    [0] => Array
        (
            [product_id] => 123456
            [product_quantity] => 4
            [product_rate] => 25
            [serial_no] => ABC1234
        )

    [1] => Array
        (
            [product_id] => 84213421
            [product_quantity] => 5
            [product_rate] => 10
            [serial_no] => 
        )

    [2] => Array
        (
            [product_id] => 34769578
            [product_quantity] => 1
            [product_rate] => 200
            [serial_no] => 
        )

)

INFO - 2025-04-06 10:17:33 --> Final output sent to browser
DEBUG - 2025-04-06 10:17:33 --> Total execution time: 0.0093
