<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-13 05:14:02 --> Config Class Initialized
INFO - 2025-04-13 05:14:02 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:02 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:02 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:02 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 05:14:02 --> Router Class Initialized
INFO - 2025-04-13 05:14:02 --> Output Class Initialized
INFO - 2025-04-13 05:14:02 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:02 --> Input Class Initialized
INFO - 2025-04-13 05:14:02 --> Language Class Initialized
INFO - 2025-04-13 05:14:02 --> Language Class Initialized
INFO - 2025-04-13 05:14:02 --> Config Class Initialized
INFO - 2025-04-13 05:14:02 --> Loader Class Initialized
INFO - 2025-04-13 05:14:02 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:02 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:02 --> Email Class Initialized
INFO - 2025-04-13 05:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:02 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:02 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:02 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:02 --> Report MX_Controller Initialized
INFO - 2025-04-13 05:14:02 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 05:14:02 --> Model Class Initialized
INFO - 2025-04-13 05:14:02 --> Config Class Initialized
INFO - 2025-04-13 05:14:02 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:02 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:02 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:02 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:14:02 --> Router Class Initialized
INFO - 2025-04-13 05:14:02 --> Output Class Initialized
INFO - 2025-04-13 05:14:02 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:02 --> Input Class Initialized
INFO - 2025-04-13 05:14:02 --> Language Class Initialized
INFO - 2025-04-13 05:14:02 --> Language Class Initialized
INFO - 2025-04-13 05:14:02 --> Config Class Initialized
INFO - 2025-04-13 05:14:02 --> Loader Class Initialized
INFO - 2025-04-13 05:14:02 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:02 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:02 --> Email Class Initialized
INFO - 2025-04-13 05:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:02 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:02 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:02 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:02 --> Auth MX_Controller Initialized
INFO - 2025-04-13 05:14:02 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-13 05:14:02 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:02 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:02 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-13 05:14:02 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:02 --> Total execution time: 0.0394
INFO - 2025-04-13 05:14:10 --> Config Class Initialized
INFO - 2025-04-13 05:14:10 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:10 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:10 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:10 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:14:10 --> Router Class Initialized
INFO - 2025-04-13 05:14:10 --> Output Class Initialized
INFO - 2025-04-13 05:14:10 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:10 --> Input Class Initialized
INFO - 2025-04-13 05:14:10 --> Language Class Initialized
INFO - 2025-04-13 05:14:10 --> Language Class Initialized
INFO - 2025-04-13 05:14:10 --> Config Class Initialized
INFO - 2025-04-13 05:14:10 --> Loader Class Initialized
INFO - 2025-04-13 05:14:10 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:10 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:10 --> Email Class Initialized
INFO - 2025-04-13 05:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:10 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:10 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:10 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:10 --> Auth MX_Controller Initialized
INFO - 2025-04-13 05:14:10 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-13 05:14:10 --> Model Class Initialized
INFO - 2025-04-13 05:14:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-13 05:14:10 --> Config Class Initialized
INFO - 2025-04-13 05:14:10 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:10 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:10 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:10 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:14:10 --> Router Class Initialized
INFO - 2025-04-13 05:14:10 --> Output Class Initialized
INFO - 2025-04-13 05:14:10 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:10 --> Input Class Initialized
INFO - 2025-04-13 05:14:10 --> Language Class Initialized
INFO - 2025-04-13 05:14:10 --> Language Class Initialized
INFO - 2025-04-13 05:14:10 --> Config Class Initialized
INFO - 2025-04-13 05:14:10 --> Loader Class Initialized
INFO - 2025-04-13 05:14:10 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:10 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:10 --> Email Class Initialized
INFO - 2025-04-13 05:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:10 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:10 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:10 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:10 --> Home MX_Controller Initialized
INFO - 2025-04-13 05:14:10 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-13 05:14:10 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:10 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:10 --> Model Class Initialized
ERROR - 2025-04-13 05:14:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:14:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:14:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:14:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:14:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:14:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:14:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-13 05:14:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:14:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:14:11 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:11 --> Total execution time: 1.0848
INFO - 2025-04-13 05:14:20 --> Config Class Initialized
INFO - 2025-04-13 05:14:20 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:20 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:20 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:20 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 05:14:20 --> Router Class Initialized
INFO - 2025-04-13 05:14:20 --> Output Class Initialized
INFO - 2025-04-13 05:14:20 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:20 --> Input Class Initialized
INFO - 2025-04-13 05:14:20 --> Language Class Initialized
INFO - 2025-04-13 05:14:20 --> Language Class Initialized
INFO - 2025-04-13 05:14:20 --> Config Class Initialized
INFO - 2025-04-13 05:14:20 --> Loader Class Initialized
INFO - 2025-04-13 05:14:20 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:20 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:20 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:20 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:20 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:20 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:20 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:20 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:20 --> Email Class Initialized
INFO - 2025-04-13 05:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:20 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:20 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:20 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:20 --> Report MX_Controller Initialized
INFO - 2025-04-13 05:14:20 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 05:14:20 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:20 --> Model Class Initialized
ERROR - 2025-04-13 05:14:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:14:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:14:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:14:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:14:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:14:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:14:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-13 05:14:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:14:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:14:21 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:21 --> Total execution time: 0.1886
INFO - 2025-04-13 05:14:21 --> Config Class Initialized
INFO - 2025-04-13 05:14:21 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:21 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:21 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:21 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 05:14:21 --> Router Class Initialized
INFO - 2025-04-13 05:14:21 --> Output Class Initialized
INFO - 2025-04-13 05:14:21 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:21 --> Input Class Initialized
INFO - 2025-04-13 05:14:21 --> Language Class Initialized
INFO - 2025-04-13 05:14:21 --> Language Class Initialized
INFO - 2025-04-13 05:14:21 --> Config Class Initialized
INFO - 2025-04-13 05:14:21 --> Loader Class Initialized
INFO - 2025-04-13 05:14:21 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:21 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:21 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:21 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:21 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:21 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:21 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:21 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:21 --> Email Class Initialized
INFO - 2025-04-13 05:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:21 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:21 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:21 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:21 --> Report MX_Controller Initialized
INFO - 2025-04-13 05:14:21 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 05:14:21 --> Model Class Initialized
INFO - 2025-04-13 05:14:21 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:21 --> Total execution time: 0.0112
INFO - 2025-04-13 05:14:28 --> Config Class Initialized
INFO - 2025-04-13 05:14:28 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:28 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:28 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:28 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 05:14:28 --> Router Class Initialized
INFO - 2025-04-13 05:14:28 --> Output Class Initialized
INFO - 2025-04-13 05:14:28 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:28 --> Input Class Initialized
INFO - 2025-04-13 05:14:28 --> Language Class Initialized
INFO - 2025-04-13 05:14:28 --> Language Class Initialized
INFO - 2025-04-13 05:14:28 --> Config Class Initialized
INFO - 2025-04-13 05:14:28 --> Loader Class Initialized
INFO - 2025-04-13 05:14:28 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:28 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:28 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:28 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:28 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:28 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:28 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:28 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:28 --> Email Class Initialized
INFO - 2025-04-13 05:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:28 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:28 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:28 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:28 --> Returns MX_Controller Initialized
INFO - 2025-04-13 05:14:28 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 05:14:28 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 05:14:28 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:28 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:28 --> Model Class Initialized
ERROR - 2025-04-13 05:14:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:14:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/wastage_return_list.php
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:14:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:14:28 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:28 --> Total execution time: 0.1906
INFO - 2025-04-13 05:14:30 --> Config Class Initialized
INFO - 2025-04-13 05:14:30 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:30 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:30 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:30 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 05:14:30 --> Router Class Initialized
INFO - 2025-04-13 05:14:30 --> Output Class Initialized
INFO - 2025-04-13 05:14:30 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:30 --> Input Class Initialized
INFO - 2025-04-13 05:14:30 --> Language Class Initialized
INFO - 2025-04-13 05:14:30 --> Language Class Initialized
INFO - 2025-04-13 05:14:30 --> Config Class Initialized
INFO - 2025-04-13 05:14:30 --> Loader Class Initialized
INFO - 2025-04-13 05:14:30 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:30 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:30 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:30 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:30 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:30 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:30 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:30 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:30 --> Email Class Initialized
INFO - 2025-04-13 05:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:30 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:30 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:30 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:30 --> Returns MX_Controller Initialized
INFO - 2025-04-13 05:14:30 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 05:14:30 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 05:14:30 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:30 --> Model Class Initialized
ERROR - 2025-04-13 05:14:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:14:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/return_supllier_list.php
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:14:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:14:30 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:30 --> Total execution time: 0.1692
INFO - 2025-04-13 05:14:32 --> Config Class Initialized
INFO - 2025-04-13 05:14:32 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:32 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:32 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:32 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 05:14:32 --> Router Class Initialized
INFO - 2025-04-13 05:14:32 --> Output Class Initialized
INFO - 2025-04-13 05:14:32 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:32 --> Input Class Initialized
INFO - 2025-04-13 05:14:32 --> Language Class Initialized
INFO - 2025-04-13 05:14:32 --> Language Class Initialized
INFO - 2025-04-13 05:14:32 --> Config Class Initialized
INFO - 2025-04-13 05:14:32 --> Loader Class Initialized
INFO - 2025-04-13 05:14:32 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:32 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:32 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:32 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:32 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:32 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:32 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:32 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:32 --> Email Class Initialized
INFO - 2025-04-13 05:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:32 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:32 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:32 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:32 --> Returns MX_Controller Initialized
INFO - 2025-04-13 05:14:32 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 05:14:32 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 05:14:32 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:32 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:32 --> Model Class Initialized
ERROR - 2025-04-13 05:14:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:14:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:14:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:14:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-13 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:14:33 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:33 --> Total execution time: 0.1985
INFO - 2025-04-13 05:14:37 --> Config Class Initialized
INFO - 2025-04-13 05:14:37 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:37 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:37 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:37 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 05:14:37 --> Router Class Initialized
INFO - 2025-04-13 05:14:37 --> Output Class Initialized
INFO - 2025-04-13 05:14:37 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:37 --> Input Class Initialized
INFO - 2025-04-13 05:14:37 --> Language Class Initialized
INFO - 2025-04-13 05:14:37 --> Language Class Initialized
INFO - 2025-04-13 05:14:37 --> Config Class Initialized
INFO - 2025-04-13 05:14:37 --> Loader Class Initialized
INFO - 2025-04-13 05:14:37 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:37 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:37 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:37 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:37 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:37 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:37 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:37 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:37 --> Email Class Initialized
INFO - 2025-04-13 05:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:37 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:37 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:37 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:37 --> Returns MX_Controller Initialized
INFO - 2025-04-13 05:14:37 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 05:14:37 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 05:14:37 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:37 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:37 --> Model Class Initialized
ERROR - 2025-04-13 05:14:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:14:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:14:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:14:37 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:37 --> Total execution time: 0.2158
INFO - 2025-04-13 05:14:49 --> Config Class Initialized
INFO - 2025-04-13 05:14:49 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:49 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:49 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:49 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-04-13 05:14:49 --> Router Class Initialized
INFO - 2025-04-13 05:14:49 --> Output Class Initialized
INFO - 2025-04-13 05:14:49 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:49 --> Input Class Initialized
INFO - 2025-04-13 05:14:49 --> Language Class Initialized
INFO - 2025-04-13 05:14:49 --> Language Class Initialized
INFO - 2025-04-13 05:14:49 --> Config Class Initialized
INFO - 2025-04-13 05:14:49 --> Loader Class Initialized
INFO - 2025-04-13 05:14:49 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:49 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:49 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:49 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:49 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:49 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:49 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:49 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:49 --> Email Class Initialized
INFO - 2025-04-13 05:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:50 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:50 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:50 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:50 --> Accounts MX_Controller Initialized
INFO - 2025-04-13 05:14:50 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 05:14:50 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:14:50 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:14:50 --> Model Class Initialized
ERROR - 2025-04-13 05:14:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:14:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:14:50 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:50 --> Total execution time: 0.1957
INFO - 2025-04-13 05:14:50 --> Config Class Initialized
INFO - 2025-04-13 05:14:50 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:14:50 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:14:50 --> Utf8 Class Initialized
INFO - 2025-04-13 05:14:50 --> URI Class Initialized
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-04-13 05:14:50 --> Router Class Initialized
INFO - 2025-04-13 05:14:50 --> Output Class Initialized
INFO - 2025-04-13 05:14:50 --> Security Class Initialized
DEBUG - 2025-04-13 05:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:14:50 --> Input Class Initialized
INFO - 2025-04-13 05:14:50 --> Language Class Initialized
INFO - 2025-04-13 05:14:50 --> Language Class Initialized
INFO - 2025-04-13 05:14:50 --> Config Class Initialized
INFO - 2025-04-13 05:14:50 --> Loader Class Initialized
INFO - 2025-04-13 05:14:50 --> Helper loaded: url_helper
INFO - 2025-04-13 05:14:50 --> Helper loaded: file_helper
INFO - 2025-04-13 05:14:50 --> Helper loaded: html_helper
INFO - 2025-04-13 05:14:50 --> Helper loaded: form_helper
INFO - 2025-04-13 05:14:50 --> Helper loaded: text_helper
INFO - 2025-04-13 05:14:50 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:14:50 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:14:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:14:50 --> Database Driver Class Initialized
INFO - 2025-04-13 05:14:50 --> Email Class Initialized
INFO - 2025-04-13 05:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:14:50 --> Form Validation Class Initialized
INFO - 2025-04-13 05:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:14:50 --> Pagination Class Initialized
INFO - 2025-04-13 05:14:50 --> Controller Class Initialized
DEBUG - 2025-04-13 05:14:50 --> Accounts MX_Controller Initialized
INFO - 2025-04-13 05:14:50 --> Model Class Initialized
DEBUG - 2025-04-13 05:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 05:14:50 --> Model Class Initialized
INFO - 2025-04-13 05:14:50 --> Final output sent to browser
DEBUG - 2025-04-13 05:14:50 --> Total execution time: 0.0636
INFO - 2025-04-13 05:15:11 --> Config Class Initialized
INFO - 2025-04-13 05:15:11 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:15:11 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:15:11 --> Utf8 Class Initialized
INFO - 2025-04-13 05:15:11 --> URI Class Initialized
DEBUG - 2025-04-13 05:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-04-13 05:15:11 --> Router Class Initialized
INFO - 2025-04-13 05:15:11 --> Output Class Initialized
INFO - 2025-04-13 05:15:11 --> Security Class Initialized
DEBUG - 2025-04-13 05:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:15:11 --> Input Class Initialized
INFO - 2025-04-13 05:15:11 --> Language Class Initialized
INFO - 2025-04-13 05:15:11 --> Language Class Initialized
INFO - 2025-04-13 05:15:11 --> Config Class Initialized
INFO - 2025-04-13 05:15:11 --> Loader Class Initialized
INFO - 2025-04-13 05:15:11 --> Helper loaded: url_helper
INFO - 2025-04-13 05:15:11 --> Helper loaded: file_helper
INFO - 2025-04-13 05:15:11 --> Helper loaded: html_helper
INFO - 2025-04-13 05:15:11 --> Helper loaded: form_helper
INFO - 2025-04-13 05:15:11 --> Helper loaded: text_helper
INFO - 2025-04-13 05:15:11 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:15:11 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:15:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:15:11 --> Database Driver Class Initialized
INFO - 2025-04-13 05:15:11 --> Email Class Initialized
INFO - 2025-04-13 05:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:15:11 --> Form Validation Class Initialized
INFO - 2025-04-13 05:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:15:11 --> Pagination Class Initialized
INFO - 2025-04-13 05:15:11 --> Controller Class Initialized
DEBUG - 2025-04-13 05:15:11 --> Accounts MX_Controller Initialized
INFO - 2025-04-13 05:15:11 --> Model Class Initialized
DEBUG - 2025-04-13 05:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 05:15:11 --> Model Class Initialized
INFO - 2025-04-13 05:15:11 --> Final output sent to browser
DEBUG - 2025-04-13 05:15:11 --> Total execution time: 0.1561
INFO - 2025-04-13 05:20:04 --> Config Class Initialized
INFO - 2025-04-13 05:20:04 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:20:04 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:20:04 --> Utf8 Class Initialized
INFO - 2025-04-13 05:20:04 --> URI Class Initialized
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:20:04 --> Router Class Initialized
INFO - 2025-04-13 05:20:04 --> Output Class Initialized
INFO - 2025-04-13 05:20:04 --> Security Class Initialized
DEBUG - 2025-04-13 05:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:20:04 --> Input Class Initialized
INFO - 2025-04-13 05:20:04 --> Language Class Initialized
INFO - 2025-04-13 05:20:04 --> Language Class Initialized
INFO - 2025-04-13 05:20:04 --> Config Class Initialized
INFO - 2025-04-13 05:20:04 --> Loader Class Initialized
INFO - 2025-04-13 05:20:04 --> Helper loaded: url_helper
INFO - 2025-04-13 05:20:04 --> Helper loaded: file_helper
INFO - 2025-04-13 05:20:04 --> Helper loaded: html_helper
INFO - 2025-04-13 05:20:04 --> Helper loaded: form_helper
INFO - 2025-04-13 05:20:04 --> Helper loaded: text_helper
INFO - 2025-04-13 05:20:04 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:20:04 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:20:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:20:04 --> Database Driver Class Initialized
INFO - 2025-04-13 05:20:04 --> Email Class Initialized
INFO - 2025-04-13 05:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:20:04 --> Form Validation Class Initialized
INFO - 2025-04-13 05:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:20:04 --> Pagination Class Initialized
INFO - 2025-04-13 05:20:04 --> Controller Class Initialized
DEBUG - 2025-04-13 05:20:04 --> Setting MX_Controller Initialized
INFO - 2025-04-13 05:20:04 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-04-13 05:20:04 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:20:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:20:04 --> Model Class Initialized
ERROR - 2025-04-13 05:20:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:20:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/setting.php
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:20:04 --> Final output sent to browser
DEBUG - 2025-04-13 05:20:04 --> Total execution time: 0.1311
INFO - 2025-04-13 05:20:21 --> Config Class Initialized
INFO - 2025-04-13 05:20:21 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:20:21 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:20:21 --> Utf8 Class Initialized
INFO - 2025-04-13 05:20:21 --> URI Class Initialized
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:20:21 --> Router Class Initialized
INFO - 2025-04-13 05:20:21 --> Output Class Initialized
INFO - 2025-04-13 05:20:21 --> Security Class Initialized
DEBUG - 2025-04-13 05:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:20:21 --> Input Class Initialized
INFO - 2025-04-13 05:20:21 --> Language Class Initialized
INFO - 2025-04-13 05:20:21 --> Language Class Initialized
INFO - 2025-04-13 05:20:21 --> Config Class Initialized
INFO - 2025-04-13 05:20:21 --> Loader Class Initialized
INFO - 2025-04-13 05:20:21 --> Helper loaded: url_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: file_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: html_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: form_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: text_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:20:21 --> Database Driver Class Initialized
INFO - 2025-04-13 05:20:21 --> Email Class Initialized
INFO - 2025-04-13 05:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:20:21 --> Form Validation Class Initialized
INFO - 2025-04-13 05:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:20:21 --> Pagination Class Initialized
INFO - 2025-04-13 05:20:21 --> Controller Class Initialized
DEBUG - 2025-04-13 05:20:21 --> Setting MX_Controller Initialized
INFO - 2025-04-13 05:20:21 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-04-13 05:20:21 --> Model Class Initialized
INFO - 2025-04-13 05:20:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-13 05:20:21 --> Config Class Initialized
INFO - 2025-04-13 05:20:21 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:20:21 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:20:21 --> Utf8 Class Initialized
INFO - 2025-04-13 05:20:21 --> URI Class Initialized
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:20:21 --> Router Class Initialized
INFO - 2025-04-13 05:20:21 --> Output Class Initialized
INFO - 2025-04-13 05:20:21 --> Security Class Initialized
DEBUG - 2025-04-13 05:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:20:21 --> Input Class Initialized
INFO - 2025-04-13 05:20:21 --> Language Class Initialized
INFO - 2025-04-13 05:20:21 --> Language Class Initialized
INFO - 2025-04-13 05:20:21 --> Config Class Initialized
INFO - 2025-04-13 05:20:21 --> Loader Class Initialized
INFO - 2025-04-13 05:20:21 --> Helper loaded: url_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: file_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: html_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: form_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: text_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:20:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:20:21 --> Database Driver Class Initialized
INFO - 2025-04-13 05:20:21 --> Email Class Initialized
INFO - 2025-04-13 05:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:20:21 --> Form Validation Class Initialized
INFO - 2025-04-13 05:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:20:21 --> Pagination Class Initialized
INFO - 2025-04-13 05:20:21 --> Controller Class Initialized
DEBUG - 2025-04-13 05:20:21 --> Setting MX_Controller Initialized
INFO - 2025-04-13 05:20:21 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-04-13 05:20:21 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:20:21 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:20:21 --> Model Class Initialized
ERROR - 2025-04-13 05:20:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:20:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/setting.php
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:20:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:20:21 --> Final output sent to browser
DEBUG - 2025-04-13 05:20:21 --> Total execution time: 0.1698
INFO - 2025-04-13 05:20:28 --> Config Class Initialized
INFO - 2025-04-13 05:20:28 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:20:28 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:20:28 --> Utf8 Class Initialized
INFO - 2025-04-13 05:20:28 --> URI Class Initialized
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:20:28 --> Router Class Initialized
INFO - 2025-04-13 05:20:28 --> Output Class Initialized
INFO - 2025-04-13 05:20:28 --> Security Class Initialized
DEBUG - 2025-04-13 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:20:28 --> Input Class Initialized
INFO - 2025-04-13 05:20:28 --> Language Class Initialized
INFO - 2025-04-13 05:20:28 --> Language Class Initialized
INFO - 2025-04-13 05:20:28 --> Config Class Initialized
INFO - 2025-04-13 05:20:28 --> Loader Class Initialized
INFO - 2025-04-13 05:20:28 --> Helper loaded: url_helper
INFO - 2025-04-13 05:20:28 --> Helper loaded: file_helper
INFO - 2025-04-13 05:20:28 --> Helper loaded: html_helper
INFO - 2025-04-13 05:20:28 --> Helper loaded: form_helper
INFO - 2025-04-13 05:20:28 --> Helper loaded: text_helper
INFO - 2025-04-13 05:20:28 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:20:28 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:20:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:20:28 --> Database Driver Class Initialized
INFO - 2025-04-13 05:20:28 --> Email Class Initialized
INFO - 2025-04-13 05:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:20:28 --> Form Validation Class Initialized
INFO - 2025-04-13 05:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:20:28 --> Pagination Class Initialized
INFO - 2025-04-13 05:20:28 --> Controller Class Initialized
DEBUG - 2025-04-13 05:20:28 --> Setting MX_Controller Initialized
INFO - 2025-04-13 05:20:28 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-04-13 05:20:28 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:20:28 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:20:28 --> Model Class Initialized
ERROR - 2025-04-13 05:20:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:20:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/currency/currency_form.php
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:20:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:20:28 --> Final output sent to browser
DEBUG - 2025-04-13 05:20:28 --> Total execution time: 0.1121
INFO - 2025-04-13 05:20:33 --> Config Class Initialized
INFO - 2025-04-13 05:20:33 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:20:33 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:20:33 --> Utf8 Class Initialized
INFO - 2025-04-13 05:20:33 --> URI Class Initialized
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 05:20:33 --> Router Class Initialized
INFO - 2025-04-13 05:20:33 --> Output Class Initialized
INFO - 2025-04-13 05:20:33 --> Security Class Initialized
DEBUG - 2025-04-13 05:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:20:33 --> Input Class Initialized
INFO - 2025-04-13 05:20:33 --> Language Class Initialized
INFO - 2025-04-13 05:20:33 --> Language Class Initialized
INFO - 2025-04-13 05:20:33 --> Config Class Initialized
INFO - 2025-04-13 05:20:33 --> Loader Class Initialized
INFO - 2025-04-13 05:20:33 --> Helper loaded: url_helper
INFO - 2025-04-13 05:20:33 --> Helper loaded: file_helper
INFO - 2025-04-13 05:20:33 --> Helper loaded: html_helper
INFO - 2025-04-13 05:20:33 --> Helper loaded: form_helper
INFO - 2025-04-13 05:20:33 --> Helper loaded: text_helper
INFO - 2025-04-13 05:20:33 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:20:33 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:20:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:20:33 --> Database Driver Class Initialized
INFO - 2025-04-13 05:20:33 --> Email Class Initialized
INFO - 2025-04-13 05:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:20:33 --> Form Validation Class Initialized
INFO - 2025-04-13 05:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:20:33 --> Pagination Class Initialized
INFO - 2025-04-13 05:20:33 --> Controller Class Initialized
DEBUG - 2025-04-13 05:20:33 --> Setting MX_Controller Initialized
INFO - 2025-04-13 05:20:33 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-04-13 05:20:33 --> Model Class Initialized
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 05:20:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 05:20:33 --> Model Class Initialized
ERROR - 2025-04-13 05:20:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 05:20:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/company_list.php
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 05:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 05:20:33 --> Final output sent to browser
DEBUG - 2025-04-13 05:20:33 --> Total execution time: 0.1812
INFO - 2025-04-13 05:21:34 --> Config Class Initialized
INFO - 2025-04-13 05:21:34 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:21:34 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:21:34 --> Utf8 Class Initialized
INFO - 2025-04-13 05:21:34 --> URI Class Initialized
DEBUG - 2025-04-13 05:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 05:21:34 --> Router Class Initialized
INFO - 2025-04-13 05:21:34 --> Output Class Initialized
INFO - 2025-04-13 05:21:34 --> Security Class Initialized
DEBUG - 2025-04-13 05:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:21:34 --> Input Class Initialized
INFO - 2025-04-13 05:21:34 --> Language Class Initialized
INFO - 2025-04-13 05:21:34 --> Language Class Initialized
INFO - 2025-04-13 05:21:34 --> Config Class Initialized
INFO - 2025-04-13 05:21:34 --> Loader Class Initialized
INFO - 2025-04-13 05:21:34 --> Helper loaded: url_helper
INFO - 2025-04-13 05:21:34 --> Helper loaded: file_helper
INFO - 2025-04-13 05:21:34 --> Helper loaded: html_helper
INFO - 2025-04-13 05:21:34 --> Helper loaded: form_helper
INFO - 2025-04-13 05:21:34 --> Helper loaded: text_helper
INFO - 2025-04-13 05:21:34 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:21:34 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:21:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:21:34 --> Database Driver Class Initialized
INFO - 2025-04-13 05:21:34 --> Email Class Initialized
INFO - 2025-04-13 05:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:21:34 --> Form Validation Class Initialized
INFO - 2025-04-13 05:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:21:34 --> Pagination Class Initialized
INFO - 2025-04-13 05:21:34 --> Controller Class Initialized
DEBUG - 2025-04-13 05:21:34 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 11:21:34 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 11:21:34 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 11:21:34 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 11:21:34 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 11:21:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 11:21:34 --> Model Class Initialized
ERROR - 2025-04-13 11:21:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 11:21:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 11:21:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 11:21:34 --> Final output sent to browser
DEBUG - 2025-04-13 11:21:34 --> Total execution time: 0.2014
INFO - 2025-04-13 05:21:35 --> Config Class Initialized
INFO - 2025-04-13 05:21:35 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:21:35 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:21:35 --> Utf8 Class Initialized
INFO - 2025-04-13 05:21:35 --> URI Class Initialized
DEBUG - 2025-04-13 05:21:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 05:21:35 --> Router Class Initialized
INFO - 2025-04-13 05:21:35 --> Output Class Initialized
INFO - 2025-04-13 05:21:35 --> Security Class Initialized
DEBUG - 2025-04-13 05:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:21:35 --> Input Class Initialized
INFO - 2025-04-13 05:21:35 --> Language Class Initialized
INFO - 2025-04-13 05:21:35 --> Language Class Initialized
INFO - 2025-04-13 05:21:35 --> Config Class Initialized
INFO - 2025-04-13 05:21:35 --> Loader Class Initialized
INFO - 2025-04-13 05:21:35 --> Helper loaded: url_helper
INFO - 2025-04-13 05:21:35 --> Helper loaded: file_helper
INFO - 2025-04-13 05:21:35 --> Helper loaded: html_helper
INFO - 2025-04-13 05:21:35 --> Helper loaded: form_helper
INFO - 2025-04-13 05:21:35 --> Helper loaded: text_helper
INFO - 2025-04-13 05:21:35 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:21:35 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:21:35 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:21:35 --> Database Driver Class Initialized
INFO - 2025-04-13 05:21:35 --> Email Class Initialized
INFO - 2025-04-13 05:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:21:35 --> Form Validation Class Initialized
INFO - 2025-04-13 05:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:21:35 --> Pagination Class Initialized
INFO - 2025-04-13 05:21:35 --> Controller Class Initialized
DEBUG - 2025-04-13 05:21:35 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 11:21:35 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 11:21:35 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 11:21:35 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 11:21:35 --> Model Class Initialized
INFO - 2025-04-13 11:21:35 --> Final output sent to browser
DEBUG - 2025-04-13 11:21:35 --> Total execution time: 0.0611
INFO - 2025-04-13 05:21:38 --> Config Class Initialized
INFO - 2025-04-13 05:21:38 --> Hooks Class Initialized
DEBUG - 2025-04-13 05:21:38 --> UTF-8 Support Enabled
INFO - 2025-04-13 05:21:38 --> Utf8 Class Initialized
INFO - 2025-04-13 05:21:38 --> URI Class Initialized
DEBUG - 2025-04-13 05:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 05:21:38 --> Router Class Initialized
INFO - 2025-04-13 05:21:38 --> Output Class Initialized
INFO - 2025-04-13 05:21:38 --> Security Class Initialized
DEBUG - 2025-04-13 05:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 05:21:38 --> Input Class Initialized
INFO - 2025-04-13 05:21:38 --> Language Class Initialized
INFO - 2025-04-13 05:21:38 --> Language Class Initialized
INFO - 2025-04-13 05:21:38 --> Config Class Initialized
INFO - 2025-04-13 05:21:38 --> Loader Class Initialized
INFO - 2025-04-13 05:21:38 --> Helper loaded: url_helper
INFO - 2025-04-13 05:21:38 --> Helper loaded: file_helper
INFO - 2025-04-13 05:21:38 --> Helper loaded: html_helper
INFO - 2025-04-13 05:21:38 --> Helper loaded: form_helper
INFO - 2025-04-13 05:21:38 --> Helper loaded: text_helper
INFO - 2025-04-13 05:21:38 --> Helper loaded: lang_helper
INFO - 2025-04-13 05:21:38 --> Helper loaded: directory_helper
INFO - 2025-04-13 05:21:38 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 05:21:38 --> Database Driver Class Initialized
INFO - 2025-04-13 05:21:38 --> Email Class Initialized
INFO - 2025-04-13 05:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 05:21:38 --> Form Validation Class Initialized
INFO - 2025-04-13 05:21:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 05:21:38 --> Pagination Class Initialized
INFO - 2025-04-13 05:21:38 --> Controller Class Initialized
DEBUG - 2025-04-13 05:21:38 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 11:21:38 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 11:21:38 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 11:21:38 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 11:21:38 --> Model Class Initialized
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 11:21:38 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 11:21:38 --> Model Class Initialized
ERROR - 2025-04-13 11:21:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 11:21:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-13 11:21:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 11:21:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 11:21:39 --> Final output sent to browser
DEBUG - 2025-04-13 11:21:39 --> Total execution time: 0.1824
INFO - 2025-04-13 09:12:20 --> Config Class Initialized
INFO - 2025-04-13 09:12:20 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:12:20 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:12:20 --> Utf8 Class Initialized
INFO - 2025-04-13 09:12:20 --> URI Class Initialized
DEBUG - 2025-04-13 09:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:12:20 --> Router Class Initialized
INFO - 2025-04-13 09:12:20 --> Output Class Initialized
INFO - 2025-04-13 09:12:20 --> Security Class Initialized
DEBUG - 2025-04-13 09:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:12:20 --> Input Class Initialized
INFO - 2025-04-13 09:12:20 --> Language Class Initialized
INFO - 2025-04-13 09:12:20 --> Language Class Initialized
INFO - 2025-04-13 09:12:20 --> Config Class Initialized
INFO - 2025-04-13 09:12:20 --> Loader Class Initialized
INFO - 2025-04-13 09:12:20 --> Helper loaded: url_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: file_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: html_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: form_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: text_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:12:20 --> Database Driver Class Initialized
INFO - 2025-04-13 09:12:20 --> Email Class Initialized
INFO - 2025-04-13 09:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:12:20 --> Form Validation Class Initialized
INFO - 2025-04-13 09:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:12:20 --> Pagination Class Initialized
INFO - 2025-04-13 09:12:20 --> Controller Class Initialized
DEBUG - 2025-04-13 09:12:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:12:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:12:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:12:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:12:20 --> Model Class Initialized
INFO - 2025-04-13 09:12:20 --> Config Class Initialized
INFO - 2025-04-13 09:12:20 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:12:20 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:12:20 --> Utf8 Class Initialized
INFO - 2025-04-13 09:12:20 --> URI Class Initialized
DEBUG - 2025-04-13 09:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 09:12:20 --> Router Class Initialized
INFO - 2025-04-13 09:12:20 --> Output Class Initialized
INFO - 2025-04-13 09:12:20 --> Security Class Initialized
DEBUG - 2025-04-13 09:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:12:20 --> Input Class Initialized
INFO - 2025-04-13 09:12:20 --> Language Class Initialized
INFO - 2025-04-13 09:12:20 --> Language Class Initialized
INFO - 2025-04-13 09:12:20 --> Config Class Initialized
INFO - 2025-04-13 09:12:20 --> Loader Class Initialized
INFO - 2025-04-13 09:12:20 --> Helper loaded: url_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: file_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: html_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: form_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: text_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:12:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:12:20 --> Database Driver Class Initialized
INFO - 2025-04-13 09:12:20 --> Email Class Initialized
INFO - 2025-04-13 09:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:12:20 --> Form Validation Class Initialized
INFO - 2025-04-13 09:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:12:20 --> Pagination Class Initialized
INFO - 2025-04-13 09:12:20 --> Controller Class Initialized
DEBUG - 2025-04-13 09:12:20 --> Auth MX_Controller Initialized
INFO - 2025-04-13 09:12:20 --> Model Class Initialized
DEBUG - 2025-04-13 09:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-13 09:12:20 --> Model Class Initialized
DEBUG - 2025-04-13 09:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:12:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:12:20 --> Model Class Initialized
DEBUG - 2025-04-13 09:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-13 09:12:20 --> Final output sent to browser
DEBUG - 2025-04-13 09:12:20 --> Total execution time: 0.0207
INFO - 2025-04-13 09:12:30 --> Config Class Initialized
INFO - 2025-04-13 09:12:30 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:12:30 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:12:30 --> Utf8 Class Initialized
INFO - 2025-04-13 09:12:30 --> URI Class Initialized
DEBUG - 2025-04-13 09:12:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 09:12:30 --> Router Class Initialized
INFO - 2025-04-13 09:12:30 --> Output Class Initialized
INFO - 2025-04-13 09:12:30 --> Security Class Initialized
DEBUG - 2025-04-13 09:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:12:30 --> Input Class Initialized
INFO - 2025-04-13 09:12:30 --> Language Class Initialized
INFO - 2025-04-13 09:12:30 --> Language Class Initialized
INFO - 2025-04-13 09:12:30 --> Config Class Initialized
INFO - 2025-04-13 09:12:30 --> Loader Class Initialized
INFO - 2025-04-13 09:12:30 --> Helper loaded: url_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: file_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: html_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: form_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: text_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:12:30 --> Database Driver Class Initialized
INFO - 2025-04-13 09:12:30 --> Email Class Initialized
INFO - 2025-04-13 09:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:12:30 --> Form Validation Class Initialized
INFO - 2025-04-13 09:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:12:30 --> Pagination Class Initialized
INFO - 2025-04-13 09:12:30 --> Controller Class Initialized
DEBUG - 2025-04-13 09:12:30 --> Auth MX_Controller Initialized
INFO - 2025-04-13 09:12:30 --> Model Class Initialized
DEBUG - 2025-04-13 09:12:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-13 09:12:30 --> Model Class Initialized
INFO - 2025-04-13 09:12:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-13 09:12:30 --> Config Class Initialized
INFO - 2025-04-13 09:12:30 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:12:30 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:12:30 --> Utf8 Class Initialized
INFO - 2025-04-13 09:12:30 --> URI Class Initialized
DEBUG - 2025-04-13 09:12:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-13 09:12:30 --> Router Class Initialized
INFO - 2025-04-13 09:12:30 --> Output Class Initialized
INFO - 2025-04-13 09:12:30 --> Security Class Initialized
DEBUG - 2025-04-13 09:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:12:30 --> Input Class Initialized
INFO - 2025-04-13 09:12:30 --> Language Class Initialized
INFO - 2025-04-13 09:12:30 --> Language Class Initialized
INFO - 2025-04-13 09:12:30 --> Config Class Initialized
INFO - 2025-04-13 09:12:30 --> Loader Class Initialized
INFO - 2025-04-13 09:12:30 --> Helper loaded: url_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: file_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: html_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: form_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: text_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:12:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:12:30 --> Database Driver Class Initialized
INFO - 2025-04-13 09:12:30 --> Email Class Initialized
INFO - 2025-04-13 09:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:12:30 --> Form Validation Class Initialized
INFO - 2025-04-13 09:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:12:30 --> Pagination Class Initialized
INFO - 2025-04-13 09:12:30 --> Controller Class Initialized
DEBUG - 2025-04-13 09:12:30 --> Home MX_Controller Initialized
INFO - 2025-04-13 09:12:30 --> Model Class Initialized
DEBUG - 2025-04-13 09:12:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-13 09:12:30 --> Model Class Initialized
DEBUG - 2025-04-13 09:12:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:12:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:12:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:12:30 --> Model Class Initialized
ERROR - 2025-04-13 09:12:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:12:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-13 09:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:12:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:12:31 --> Final output sent to browser
DEBUG - 2025-04-13 09:12:31 --> Total execution time: 0.7656
INFO - 2025-04-13 09:20:14 --> Config Class Initialized
INFO - 2025-04-13 09:20:14 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:20:14 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:20:14 --> Utf8 Class Initialized
INFO - 2025-04-13 09:20:14 --> URI Class Initialized
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:20:14 --> Router Class Initialized
INFO - 2025-04-13 09:20:14 --> Output Class Initialized
INFO - 2025-04-13 09:20:14 --> Security Class Initialized
DEBUG - 2025-04-13 09:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:20:14 --> Input Class Initialized
INFO - 2025-04-13 09:20:14 --> Language Class Initialized
INFO - 2025-04-13 09:20:14 --> Language Class Initialized
INFO - 2025-04-13 09:20:14 --> Config Class Initialized
INFO - 2025-04-13 09:20:14 --> Loader Class Initialized
INFO - 2025-04-13 09:20:14 --> Helper loaded: url_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: file_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: html_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: form_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: text_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:20:14 --> Database Driver Class Initialized
INFO - 2025-04-13 09:20:14 --> Email Class Initialized
INFO - 2025-04-13 09:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:20:14 --> Form Validation Class Initialized
INFO - 2025-04-13 09:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:20:14 --> Pagination Class Initialized
INFO - 2025-04-13 09:20:14 --> Controller Class Initialized
DEBUG - 2025-04-13 09:20:14 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:20:14 --> Model Class Initialized
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:20:14 --> Model Class Initialized
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:20:14 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:20:14 --> Model Class Initialized
ERROR - 2025-04-13 09:20:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:20:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:20:14 --> Final output sent to browser
DEBUG - 2025-04-13 09:20:14 --> Total execution time: 0.1915
INFO - 2025-04-13 09:20:14 --> Config Class Initialized
INFO - 2025-04-13 09:20:14 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:20:14 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:20:14 --> Utf8 Class Initialized
INFO - 2025-04-13 09:20:14 --> URI Class Initialized
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:20:14 --> Router Class Initialized
INFO - 2025-04-13 09:20:14 --> Output Class Initialized
INFO - 2025-04-13 09:20:14 --> Security Class Initialized
DEBUG - 2025-04-13 09:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:20:14 --> Input Class Initialized
INFO - 2025-04-13 09:20:14 --> Language Class Initialized
INFO - 2025-04-13 09:20:14 --> Language Class Initialized
INFO - 2025-04-13 09:20:14 --> Config Class Initialized
INFO - 2025-04-13 09:20:14 --> Loader Class Initialized
INFO - 2025-04-13 09:20:14 --> Helper loaded: url_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: file_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: html_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: form_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: text_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:20:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:20:14 --> Database Driver Class Initialized
INFO - 2025-04-13 09:20:14 --> Email Class Initialized
INFO - 2025-04-13 09:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:20:14 --> Form Validation Class Initialized
INFO - 2025-04-13 09:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:20:14 --> Pagination Class Initialized
INFO - 2025-04-13 09:20:14 --> Controller Class Initialized
DEBUG - 2025-04-13 09:20:14 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:20:14 --> Model Class Initialized
DEBUG - 2025-04-13 09:20:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:20:14 --> Model Class Initialized
INFO - 2025-04-13 09:20:14 --> Final output sent to browser
DEBUG - 2025-04-13 09:20:14 --> Total execution time: 0.0192
INFO - 2025-04-13 09:20:47 --> Config Class Initialized
INFO - 2025-04-13 09:20:47 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:20:47 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:20:47 --> Utf8 Class Initialized
INFO - 2025-04-13 09:20:47 --> URI Class Initialized
DEBUG - 2025-04-13 09:20:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:20:47 --> Router Class Initialized
INFO - 2025-04-13 09:20:47 --> Output Class Initialized
INFO - 2025-04-13 09:20:47 --> Security Class Initialized
DEBUG - 2025-04-13 09:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:20:47 --> Input Class Initialized
INFO - 2025-04-13 09:20:47 --> Language Class Initialized
INFO - 2025-04-13 09:20:47 --> Language Class Initialized
INFO - 2025-04-13 09:20:47 --> Config Class Initialized
INFO - 2025-04-13 09:20:47 --> Loader Class Initialized
INFO - 2025-04-13 09:20:47 --> Helper loaded: url_helper
INFO - 2025-04-13 09:20:47 --> Helper loaded: file_helper
INFO - 2025-04-13 09:20:47 --> Helper loaded: html_helper
INFO - 2025-04-13 09:20:47 --> Helper loaded: form_helper
INFO - 2025-04-13 09:20:47 --> Helper loaded: text_helper
INFO - 2025-04-13 09:20:47 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:20:47 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:20:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:20:47 --> Database Driver Class Initialized
INFO - 2025-04-13 09:20:47 --> Email Class Initialized
INFO - 2025-04-13 09:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:20:47 --> Form Validation Class Initialized
INFO - 2025-04-13 09:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:20:47 --> Pagination Class Initialized
INFO - 2025-04-13 09:20:47 --> Controller Class Initialized
DEBUG - 2025-04-13 09:20:47 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:20:47 --> Model Class Initialized
DEBUG - 2025-04-13 09:20:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:20:47 --> Model Class Initialized
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:20:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:20:48 --> Model Class Initialized
ERROR - 2025-04-13 09:20:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:20:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:20:48 --> Final output sent to browser
DEBUG - 2025-04-13 09:20:48 --> Total execution time: 0.2167
INFO - 2025-04-13 09:20:48 --> Config Class Initialized
INFO - 2025-04-13 09:20:48 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:20:48 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:20:48 --> Utf8 Class Initialized
INFO - 2025-04-13 09:20:48 --> URI Class Initialized
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:20:48 --> Router Class Initialized
INFO - 2025-04-13 09:20:48 --> Output Class Initialized
INFO - 2025-04-13 09:20:48 --> Security Class Initialized
DEBUG - 2025-04-13 09:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:20:48 --> Input Class Initialized
INFO - 2025-04-13 09:20:48 --> Language Class Initialized
INFO - 2025-04-13 09:20:48 --> Language Class Initialized
INFO - 2025-04-13 09:20:48 --> Config Class Initialized
INFO - 2025-04-13 09:20:48 --> Loader Class Initialized
INFO - 2025-04-13 09:20:48 --> Helper loaded: url_helper
INFO - 2025-04-13 09:20:48 --> Helper loaded: file_helper
INFO - 2025-04-13 09:20:48 --> Helper loaded: html_helper
INFO - 2025-04-13 09:20:48 --> Helper loaded: form_helper
INFO - 2025-04-13 09:20:48 --> Helper loaded: text_helper
INFO - 2025-04-13 09:20:48 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:20:48 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:20:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:20:48 --> Database Driver Class Initialized
INFO - 2025-04-13 09:20:48 --> Email Class Initialized
INFO - 2025-04-13 09:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:20:48 --> Form Validation Class Initialized
INFO - 2025-04-13 09:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:20:48 --> Pagination Class Initialized
INFO - 2025-04-13 09:20:48 --> Controller Class Initialized
DEBUG - 2025-04-13 09:20:48 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:20:48 --> Model Class Initialized
DEBUG - 2025-04-13 09:20:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:20:48 --> Model Class Initialized
INFO - 2025-04-13 09:20:48 --> Final output sent to browser
DEBUG - 2025-04-13 09:20:48 --> Total execution time: 0.0095
INFO - 2025-04-13 09:21:04 --> Config Class Initialized
INFO - 2025-04-13 09:21:04 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:04 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:04 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:04 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:21:04 --> Router Class Initialized
INFO - 2025-04-13 09:21:04 --> Output Class Initialized
INFO - 2025-04-13 09:21:04 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:04 --> Input Class Initialized
INFO - 2025-04-13 09:21:04 --> Language Class Initialized
INFO - 2025-04-13 09:21:04 --> Language Class Initialized
INFO - 2025-04-13 09:21:04 --> Config Class Initialized
INFO - 2025-04-13 09:21:04 --> Loader Class Initialized
INFO - 2025-04-13 09:21:04 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:04 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:04 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:04 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:04 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:04 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:04 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:04 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:04 --> Email Class Initialized
INFO - 2025-04-13 09:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:04 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:04 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:04 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:04 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:21:04 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:21:04 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:21:04 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:21:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:21:04 --> Model Class Initialized
ERROR - 2025-04-13 09:21:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:21:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:21:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:21:04 --> Final output sent to browser
DEBUG - 2025-04-13 09:21:04 --> Total execution time: 0.1371
INFO - 2025-04-13 09:21:11 --> Config Class Initialized
INFO - 2025-04-13 09:21:11 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:11 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:11 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:11 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:21:11 --> Router Class Initialized
INFO - 2025-04-13 09:21:11 --> Output Class Initialized
INFO - 2025-04-13 09:21:11 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:11 --> Input Class Initialized
INFO - 2025-04-13 09:21:11 --> Language Class Initialized
INFO - 2025-04-13 09:21:11 --> Language Class Initialized
INFO - 2025-04-13 09:21:11 --> Config Class Initialized
INFO - 2025-04-13 09:21:11 --> Loader Class Initialized
INFO - 2025-04-13 09:21:11 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:11 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:11 --> Email Class Initialized
INFO - 2025-04-13 09:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:11 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:11 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:11 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:11 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 15:21:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
ERROR - 2025-04-13 15:21:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 15:21:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 15:21:11 --> Final output sent to browser
DEBUG - 2025-04-13 15:21:11 --> Total execution time: 0.0935
INFO - 2025-04-13 09:21:11 --> Config Class Initialized
INFO - 2025-04-13 09:21:11 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:11 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:11 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:11 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:21:11 --> Router Class Initialized
INFO - 2025-04-13 09:21:11 --> Output Class Initialized
INFO - 2025-04-13 09:21:11 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:11 --> Input Class Initialized
INFO - 2025-04-13 09:21:11 --> Language Class Initialized
INFO - 2025-04-13 09:21:11 --> Language Class Initialized
INFO - 2025-04-13 09:21:11 --> Config Class Initialized
INFO - 2025-04-13 09:21:11 --> Loader Class Initialized
INFO - 2025-04-13 09:21:11 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:11 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:11 --> Email Class Initialized
INFO - 2025-04-13 09:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:11 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:11 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:11 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:11 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:21:11 --> Model Class Initialized
INFO - 2025-04-13 15:21:11 --> Final output sent to browser
DEBUG - 2025-04-13 15:21:11 --> Total execution time: 0.0420
INFO - 2025-04-13 09:21:17 --> Config Class Initialized
INFO - 2025-04-13 09:21:17 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:17 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:17 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:17 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:21:17 --> Router Class Initialized
INFO - 2025-04-13 09:21:17 --> Output Class Initialized
INFO - 2025-04-13 09:21:17 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:17 --> Input Class Initialized
INFO - 2025-04-13 09:21:17 --> Language Class Initialized
INFO - 2025-04-13 09:21:17 --> Language Class Initialized
INFO - 2025-04-13 09:21:17 --> Config Class Initialized
INFO - 2025-04-13 09:21:17 --> Loader Class Initialized
INFO - 2025-04-13 09:21:17 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:17 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:17 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:17 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:17 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:17 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:17 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:17 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:17 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:17 --> Email Class Initialized
INFO - 2025-04-13 09:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:17 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:17 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:17 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:17 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:21:17 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:21:17 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:21:17 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:21:17 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 15:21:17 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 15:21:17 --> Model Class Initialized
ERROR - 2025-04-13 15:21:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 15:21:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 15:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 15:21:17 --> Final output sent to browser
DEBUG - 2025-04-13 15:21:17 --> Total execution time: 0.1935
INFO - 2025-04-13 09:21:20 --> Config Class Initialized
INFO - 2025-04-13 09:21:20 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:20 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:20 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:20 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:21:20 --> Router Class Initialized
INFO - 2025-04-13 09:21:20 --> Output Class Initialized
INFO - 2025-04-13 09:21:20 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:20 --> Input Class Initialized
INFO - 2025-04-13 09:21:20 --> Language Class Initialized
INFO - 2025-04-13 09:21:20 --> Language Class Initialized
INFO - 2025-04-13 09:21:20 --> Config Class Initialized
INFO - 2025-04-13 09:21:20 --> Loader Class Initialized
INFO - 2025-04-13 09:21:20 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:20 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:20 --> Email Class Initialized
INFO - 2025-04-13 09:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:20 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:20 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:20 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 15:21:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
ERROR - 2025-04-13 15:21:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 15:21:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 15:21:20 --> Final output sent to browser
DEBUG - 2025-04-13 15:21:20 --> Total execution time: 0.1399
INFO - 2025-04-13 09:21:20 --> Config Class Initialized
INFO - 2025-04-13 09:21:20 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:20 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:20 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:20 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:21:20 --> Router Class Initialized
INFO - 2025-04-13 09:21:20 --> Output Class Initialized
INFO - 2025-04-13 09:21:20 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:20 --> Input Class Initialized
INFO - 2025-04-13 09:21:20 --> Language Class Initialized
INFO - 2025-04-13 09:21:20 --> Language Class Initialized
INFO - 2025-04-13 09:21:20 --> Config Class Initialized
INFO - 2025-04-13 09:21:20 --> Loader Class Initialized
INFO - 2025-04-13 09:21:20 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:20 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:20 --> Email Class Initialized
INFO - 2025-04-13 09:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:20 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:20 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:20 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
DEBUG - 2025-04-13 15:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:21:20 --> Model Class Initialized
INFO - 2025-04-13 15:21:20 --> Final output sent to browser
DEBUG - 2025-04-13 15:21:20 --> Total execution time: 0.0598
INFO - 2025-04-13 09:21:28 --> Config Class Initialized
INFO - 2025-04-13 09:21:28 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:28 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:28 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:28 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:21:28 --> Router Class Initialized
INFO - 2025-04-13 09:21:28 --> Output Class Initialized
INFO - 2025-04-13 09:21:28 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:28 --> Input Class Initialized
INFO - 2025-04-13 09:21:28 --> Language Class Initialized
INFO - 2025-04-13 09:21:28 --> Language Class Initialized
INFO - 2025-04-13 09:21:28 --> Config Class Initialized
INFO - 2025-04-13 09:21:28 --> Loader Class Initialized
INFO - 2025-04-13 09:21:28 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:28 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:28 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:28 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:28 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:28 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:28 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:28 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:28 --> Email Class Initialized
INFO - 2025-04-13 09:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:28 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:28 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:28 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:28 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:21:28 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:21:28 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:21:28 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:21:28 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:21:28 --> Model Class Initialized
ERROR - 2025-04-13 09:21:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:21:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:21:28 --> Final output sent to browser
DEBUG - 2025-04-13 09:21:28 --> Total execution time: 0.1595
INFO - 2025-04-13 09:21:31 --> Config Class Initialized
INFO - 2025-04-13 09:21:31 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:21:31 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:21:31 --> Utf8 Class Initialized
INFO - 2025-04-13 09:21:31 --> URI Class Initialized
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:21:31 --> Router Class Initialized
INFO - 2025-04-13 09:21:31 --> Output Class Initialized
INFO - 2025-04-13 09:21:31 --> Security Class Initialized
DEBUG - 2025-04-13 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:21:31 --> Input Class Initialized
INFO - 2025-04-13 09:21:31 --> Language Class Initialized
INFO - 2025-04-13 09:21:31 --> Language Class Initialized
INFO - 2025-04-13 09:21:31 --> Config Class Initialized
INFO - 2025-04-13 09:21:31 --> Loader Class Initialized
INFO - 2025-04-13 09:21:31 --> Helper loaded: url_helper
INFO - 2025-04-13 09:21:31 --> Helper loaded: file_helper
INFO - 2025-04-13 09:21:31 --> Helper loaded: html_helper
INFO - 2025-04-13 09:21:31 --> Helper loaded: form_helper
INFO - 2025-04-13 09:21:31 --> Helper loaded: text_helper
INFO - 2025-04-13 09:21:31 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:21:31 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:21:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:21:31 --> Database Driver Class Initialized
INFO - 2025-04-13 09:21:31 --> Email Class Initialized
INFO - 2025-04-13 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:21:31 --> Form Validation Class Initialized
INFO - 2025-04-13 09:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:21:31 --> Pagination Class Initialized
INFO - 2025-04-13 09:21:31 --> Controller Class Initialized
DEBUG - 2025-04-13 09:21:31 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:21:31 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:21:31 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:21:31 --> Model Class Initialized
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:21:31 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:21:31 --> Model Class Initialized
ERROR - 2025-04-13 09:21:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:21:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:21:31 --> Final output sent to browser
DEBUG - 2025-04-13 09:21:31 --> Total execution time: 0.1365
INFO - 2025-04-13 09:22:00 --> Config Class Initialized
INFO - 2025-04-13 09:22:00 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:22:00 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:22:00 --> Utf8 Class Initialized
INFO - 2025-04-13 09:22:00 --> URI Class Initialized
DEBUG - 2025-04-13 09:22:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:22:00 --> Router Class Initialized
INFO - 2025-04-13 09:22:00 --> Output Class Initialized
INFO - 2025-04-13 09:22:00 --> Security Class Initialized
DEBUG - 2025-04-13 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:22:00 --> Input Class Initialized
INFO - 2025-04-13 09:22:00 --> Language Class Initialized
INFO - 2025-04-13 09:22:00 --> Language Class Initialized
INFO - 2025-04-13 09:22:00 --> Config Class Initialized
INFO - 2025-04-13 09:22:00 --> Loader Class Initialized
INFO - 2025-04-13 09:22:00 --> Helper loaded: url_helper
INFO - 2025-04-13 09:22:00 --> Helper loaded: file_helper
INFO - 2025-04-13 09:22:00 --> Helper loaded: html_helper
INFO - 2025-04-13 09:22:00 --> Helper loaded: form_helper
INFO - 2025-04-13 09:22:00 --> Helper loaded: text_helper
INFO - 2025-04-13 09:22:00 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:22:00 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:22:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:22:00 --> Database Driver Class Initialized
INFO - 2025-04-13 09:22:00 --> Email Class Initialized
INFO - 2025-04-13 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:22:00 --> Form Validation Class Initialized
INFO - 2025-04-13 09:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:22:00 --> Pagination Class Initialized
INFO - 2025-04-13 09:22:00 --> Controller Class Initialized
DEBUG - 2025-04-13 09:22:00 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:22:00 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:22:00 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:22:00 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:22:00 --> Model Class Initialized
INFO - 2025-04-13 15:22:00 --> Final output sent to browser
DEBUG - 2025-04-13 15:22:00 --> Total execution time: 0.0197
INFO - 2025-04-13 09:22:01 --> Config Class Initialized
INFO - 2025-04-13 09:22:01 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:22:01 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:22:01 --> Utf8 Class Initialized
INFO - 2025-04-13 09:22:01 --> URI Class Initialized
DEBUG - 2025-04-13 09:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:22:01 --> Router Class Initialized
INFO - 2025-04-13 09:22:01 --> Output Class Initialized
INFO - 2025-04-13 09:22:01 --> Security Class Initialized
DEBUG - 2025-04-13 09:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:22:01 --> Input Class Initialized
INFO - 2025-04-13 09:22:01 --> Language Class Initialized
INFO - 2025-04-13 09:22:01 --> Language Class Initialized
INFO - 2025-04-13 09:22:01 --> Config Class Initialized
INFO - 2025-04-13 09:22:01 --> Loader Class Initialized
INFO - 2025-04-13 09:22:01 --> Helper loaded: url_helper
INFO - 2025-04-13 09:22:01 --> Helper loaded: file_helper
INFO - 2025-04-13 09:22:01 --> Helper loaded: html_helper
INFO - 2025-04-13 09:22:01 --> Helper loaded: form_helper
INFO - 2025-04-13 09:22:01 --> Helper loaded: text_helper
INFO - 2025-04-13 09:22:01 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:22:01 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:22:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:22:01 --> Database Driver Class Initialized
INFO - 2025-04-13 09:22:01 --> Email Class Initialized
INFO - 2025-04-13 09:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:22:01 --> Form Validation Class Initialized
INFO - 2025-04-13 09:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:22:01 --> Pagination Class Initialized
INFO - 2025-04-13 09:22:01 --> Controller Class Initialized
DEBUG - 2025-04-13 09:22:01 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:22:01 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:22:01 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:22:01 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:22:01 --> Model Class Initialized
INFO - 2025-04-13 15:22:01 --> Final output sent to browser
DEBUG - 2025-04-13 15:22:01 --> Total execution time: 0.0304
INFO - 2025-04-13 09:22:05 --> Config Class Initialized
INFO - 2025-04-13 09:22:05 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:22:05 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:22:05 --> Utf8 Class Initialized
INFO - 2025-04-13 09:22:05 --> URI Class Initialized
DEBUG - 2025-04-13 09:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:22:05 --> Router Class Initialized
INFO - 2025-04-13 09:22:05 --> Output Class Initialized
INFO - 2025-04-13 09:22:05 --> Security Class Initialized
DEBUG - 2025-04-13 09:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:22:05 --> Input Class Initialized
INFO - 2025-04-13 09:22:05 --> Language Class Initialized
INFO - 2025-04-13 09:22:05 --> Language Class Initialized
INFO - 2025-04-13 09:22:05 --> Config Class Initialized
INFO - 2025-04-13 09:22:05 --> Loader Class Initialized
INFO - 2025-04-13 09:22:05 --> Helper loaded: url_helper
INFO - 2025-04-13 09:22:05 --> Helper loaded: file_helper
INFO - 2025-04-13 09:22:05 --> Helper loaded: html_helper
INFO - 2025-04-13 09:22:05 --> Helper loaded: form_helper
INFO - 2025-04-13 09:22:05 --> Helper loaded: text_helper
INFO - 2025-04-13 09:22:05 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:22:05 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:22:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:22:05 --> Database Driver Class Initialized
INFO - 2025-04-13 09:22:05 --> Email Class Initialized
INFO - 2025-04-13 09:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:22:05 --> Form Validation Class Initialized
INFO - 2025-04-13 09:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:22:05 --> Pagination Class Initialized
INFO - 2025-04-13 09:22:05 --> Controller Class Initialized
DEBUG - 2025-04-13 09:22:05 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:22:05 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:22:05 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:22:05 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:22:05 --> Model Class Initialized
INFO - 2025-04-13 15:22:05 --> Final output sent to browser
DEBUG - 2025-04-13 15:22:05 --> Total execution time: 0.0089
INFO - 2025-04-13 09:22:25 --> Config Class Initialized
INFO - 2025-04-13 09:22:25 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:22:25 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:22:25 --> Utf8 Class Initialized
INFO - 2025-04-13 09:22:25 --> URI Class Initialized
DEBUG - 2025-04-13 09:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:22:25 --> Router Class Initialized
INFO - 2025-04-13 09:22:25 --> Output Class Initialized
INFO - 2025-04-13 09:22:25 --> Security Class Initialized
DEBUG - 2025-04-13 09:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:22:25 --> Input Class Initialized
INFO - 2025-04-13 09:22:25 --> Language Class Initialized
INFO - 2025-04-13 09:22:25 --> Language Class Initialized
INFO - 2025-04-13 09:22:25 --> Config Class Initialized
INFO - 2025-04-13 09:22:25 --> Loader Class Initialized
INFO - 2025-04-13 09:22:25 --> Helper loaded: url_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: file_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: html_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: form_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: text_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:22:25 --> Database Driver Class Initialized
INFO - 2025-04-13 09:22:25 --> Email Class Initialized
INFO - 2025-04-13 09:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:22:25 --> Form Validation Class Initialized
INFO - 2025-04-13 09:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:22:25 --> Pagination Class Initialized
INFO - 2025-04-13 09:22:25 --> Controller Class Initialized
DEBUG - 2025-04-13 09:22:25 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
INFO - 2025-04-13 15:22:25 --> Final output sent to browser
DEBUG - 2025-04-13 15:22:25 --> Total execution time: 0.0163
INFO - 2025-04-13 09:22:25 --> Config Class Initialized
INFO - 2025-04-13 09:22:25 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:22:25 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:22:25 --> Utf8 Class Initialized
INFO - 2025-04-13 09:22:25 --> URI Class Initialized
DEBUG - 2025-04-13 09:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:22:25 --> Router Class Initialized
INFO - 2025-04-13 09:22:25 --> Output Class Initialized
INFO - 2025-04-13 09:22:25 --> Security Class Initialized
DEBUG - 2025-04-13 09:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:22:25 --> Input Class Initialized
INFO - 2025-04-13 09:22:25 --> Language Class Initialized
INFO - 2025-04-13 09:22:25 --> Language Class Initialized
INFO - 2025-04-13 09:22:25 --> Config Class Initialized
INFO - 2025-04-13 09:22:25 --> Loader Class Initialized
INFO - 2025-04-13 09:22:25 --> Helper loaded: url_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: file_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: html_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: form_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: text_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:22:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:22:25 --> Database Driver Class Initialized
INFO - 2025-04-13 09:22:25 --> Email Class Initialized
INFO - 2025-04-13 09:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:22:25 --> Form Validation Class Initialized
INFO - 2025-04-13 09:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:22:25 --> Pagination Class Initialized
INFO - 2025-04-13 09:22:25 --> Controller Class Initialized
DEBUG - 2025-04-13 09:22:25 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:22:25 --> Model Class Initialized
INFO - 2025-04-13 15:22:25 --> Final output sent to browser
DEBUG - 2025-04-13 15:22:25 --> Total execution time: 0.0068
INFO - 2025-04-13 09:22:26 --> Config Class Initialized
INFO - 2025-04-13 09:22:26 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:22:26 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:22:26 --> Utf8 Class Initialized
INFO - 2025-04-13 09:22:26 --> URI Class Initialized
DEBUG - 2025-04-13 09:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:22:26 --> Router Class Initialized
INFO - 2025-04-13 09:22:26 --> Output Class Initialized
INFO - 2025-04-13 09:22:26 --> Security Class Initialized
DEBUG - 2025-04-13 09:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:22:26 --> Input Class Initialized
INFO - 2025-04-13 09:22:26 --> Language Class Initialized
INFO - 2025-04-13 09:22:26 --> Language Class Initialized
INFO - 2025-04-13 09:22:26 --> Config Class Initialized
INFO - 2025-04-13 09:22:26 --> Loader Class Initialized
INFO - 2025-04-13 09:22:26 --> Helper loaded: url_helper
INFO - 2025-04-13 09:22:26 --> Helper loaded: file_helper
INFO - 2025-04-13 09:22:26 --> Helper loaded: html_helper
INFO - 2025-04-13 09:22:26 --> Helper loaded: form_helper
INFO - 2025-04-13 09:22:26 --> Helper loaded: text_helper
INFO - 2025-04-13 09:22:26 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:22:26 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:22:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:22:26 --> Database Driver Class Initialized
INFO - 2025-04-13 09:22:26 --> Email Class Initialized
INFO - 2025-04-13 09:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:22:26 --> Form Validation Class Initialized
INFO - 2025-04-13 09:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:22:26 --> Pagination Class Initialized
INFO - 2025-04-13 09:22:26 --> Controller Class Initialized
DEBUG - 2025-04-13 09:22:26 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:22:26 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:22:26 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:22:26 --> Model Class Initialized
DEBUG - 2025-04-13 15:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:22:26 --> Model Class Initialized
INFO - 2025-04-13 15:22:26 --> Final output sent to browser
DEBUG - 2025-04-13 15:22:26 --> Total execution time: 0.0170
INFO - 2025-04-13 09:23:05 --> Config Class Initialized
INFO - 2025-04-13 09:23:05 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:23:05 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:23:05 --> Utf8 Class Initialized
INFO - 2025-04-13 09:23:05 --> URI Class Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:23:05 --> Router Class Initialized
INFO - 2025-04-13 09:23:05 --> Output Class Initialized
INFO - 2025-04-13 09:23:05 --> Security Class Initialized
DEBUG - 2025-04-13 09:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:23:05 --> Input Class Initialized
INFO - 2025-04-13 09:23:05 --> Language Class Initialized
INFO - 2025-04-13 09:23:05 --> Language Class Initialized
INFO - 2025-04-13 09:23:05 --> Config Class Initialized
INFO - 2025-04-13 09:23:05 --> Loader Class Initialized
INFO - 2025-04-13 09:23:05 --> Helper loaded: url_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: file_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: html_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: form_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: text_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:23:05 --> Database Driver Class Initialized
INFO - 2025-04-13 09:23:05 --> Email Class Initialized
INFO - 2025-04-13 09:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:23:05 --> Form Validation Class Initialized
INFO - 2025-04-13 09:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:23:05 --> Pagination Class Initialized
INFO - 2025-04-13 09:23:05 --> Controller Class Initialized
DEBUG - 2025-04-13 09:23:05 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:23:05 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:23:05 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:23:05 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:05 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-13 09:23:05 --> ✅ Proceeding with return_invoice_entry()
DEBUG - 2025-04-13 09:23:05 --> 📦 return_invoice_entry() returned Invoice ID: 3092305516
DEBUG - 2025-04-13 09:23:05 --> ⚙️ Web setting loaded: [{"is_autoapprove_v":"1"}]
DEBUG - 2025-04-13 09:23:05 --> ✅ Auto-approving return with ID: 3092305516
DEBUG - 2025-04-13 09:23:05 --> 🔁 autoapprove() called for invoice_id: 3092305516
DEBUG - 2025-04-13 09:23:05 --> 🧾 Found 1 vouchers to approve
DEBUG - 2025-04-13 09:23:05 --> 📝 Approving voucher: CV-52
DEBUG - 2025-04-13 09:23:05 --> 📥 acc_transaction insert: {"vid":"179","fyear":"1","VNo":"CV-52","Vtype":"CV","referenceNo":"3092305516","VDate":"2025-04-13","COAID":"1020101","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-13 09:23:05"}
DEBUG - 2025-04-13 09:23:05 --> 📥 acc_transaction insert: {"vid":"179","fyear":"1","VNo":"CV-52","Vtype":"CV","referenceNo":"3092305516","VDate":"2025-04-13","COAID":"3010301","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-13 09:23:05"}
DEBUG - 2025-04-13 09:23:05 --> ✅ Voucher approved: CV-52 | Result: true
INFO - 2025-04-13 09:23:05 --> Config Class Initialized
INFO - 2025-04-13 09:23:05 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:23:05 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:23:05 --> Utf8 Class Initialized
INFO - 2025-04-13 09:23:05 --> URI Class Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:23:05 --> Router Class Initialized
INFO - 2025-04-13 09:23:05 --> Output Class Initialized
INFO - 2025-04-13 09:23:05 --> Security Class Initialized
DEBUG - 2025-04-13 09:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:23:05 --> Input Class Initialized
INFO - 2025-04-13 09:23:05 --> Language Class Initialized
INFO - 2025-04-13 09:23:05 --> Language Class Initialized
INFO - 2025-04-13 09:23:05 --> Config Class Initialized
INFO - 2025-04-13 09:23:05 --> Loader Class Initialized
INFO - 2025-04-13 09:23:05 --> Helper loaded: url_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: file_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: html_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: form_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: text_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:23:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:23:05 --> Database Driver Class Initialized
INFO - 2025-04-13 09:23:05 --> Email Class Initialized
INFO - 2025-04-13 09:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:23:05 --> Form Validation Class Initialized
INFO - 2025-04-13 09:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:23:05 --> Pagination Class Initialized
INFO - 2025-04-13 09:23:05 --> Controller Class Initialized
DEBUG - 2025-04-13 09:23:05 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:23:05 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:23:05 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:23:05 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:23:05 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:23:05 --> Model Class Initialized
ERROR - 2025-04-13 09:23:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:23:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:23:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:23:05 --> Final output sent to browser
DEBUG - 2025-04-13 09:23:05 --> Total execution time: 0.1360
INFO - 2025-04-13 09:23:43 --> Config Class Initialized
INFO - 2025-04-13 09:23:43 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:23:43 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:23:43 --> Utf8 Class Initialized
INFO - 2025-04-13 09:23:43 --> URI Class Initialized
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:23:43 --> Router Class Initialized
INFO - 2025-04-13 09:23:43 --> Output Class Initialized
INFO - 2025-04-13 09:23:43 --> Security Class Initialized
DEBUG - 2025-04-13 09:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:23:43 --> Input Class Initialized
INFO - 2025-04-13 09:23:43 --> Language Class Initialized
INFO - 2025-04-13 09:23:43 --> Language Class Initialized
INFO - 2025-04-13 09:23:43 --> Config Class Initialized
INFO - 2025-04-13 09:23:43 --> Loader Class Initialized
INFO - 2025-04-13 09:23:43 --> Helper loaded: url_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: file_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: html_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: form_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: text_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:23:43 --> Database Driver Class Initialized
INFO - 2025-04-13 09:23:43 --> Email Class Initialized
INFO - 2025-04-13 09:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:23:43 --> Form Validation Class Initialized
INFO - 2025-04-13 09:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:23:43 --> Pagination Class Initialized
INFO - 2025-04-13 09:23:43 --> Controller Class Initialized
DEBUG - 2025-04-13 09:23:43 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:23:43 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:23:43 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:23:43 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:23:43 --> Model Class Initialized
ERROR - 2025-04-13 09:23:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:23:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:23:43 --> Final output sent to browser
DEBUG - 2025-04-13 09:23:43 --> Total execution time: 0.1704
INFO - 2025-04-13 09:23:43 --> Config Class Initialized
INFO - 2025-04-13 09:23:43 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:23:43 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:23:43 --> Utf8 Class Initialized
INFO - 2025-04-13 09:23:43 --> URI Class Initialized
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:23:43 --> Router Class Initialized
INFO - 2025-04-13 09:23:43 --> Output Class Initialized
INFO - 2025-04-13 09:23:43 --> Security Class Initialized
DEBUG - 2025-04-13 09:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:23:43 --> Input Class Initialized
INFO - 2025-04-13 09:23:43 --> Language Class Initialized
INFO - 2025-04-13 09:23:43 --> Language Class Initialized
INFO - 2025-04-13 09:23:43 --> Config Class Initialized
INFO - 2025-04-13 09:23:43 --> Loader Class Initialized
INFO - 2025-04-13 09:23:43 --> Helper loaded: url_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: file_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: html_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: form_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: text_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:23:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:23:43 --> Database Driver Class Initialized
INFO - 2025-04-13 09:23:43 --> Email Class Initialized
INFO - 2025-04-13 09:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:23:43 --> Form Validation Class Initialized
INFO - 2025-04-13 09:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:23:43 --> Pagination Class Initialized
INFO - 2025-04-13 09:23:43 --> Controller Class Initialized
DEBUG - 2025-04-13 09:23:43 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:23:43 --> Model Class Initialized
DEBUG - 2025-04-13 09:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:23:43 --> Model Class Initialized
INFO - 2025-04-13 09:23:43 --> Final output sent to browser
DEBUG - 2025-04-13 09:23:43 --> Total execution time: 0.0130
INFO - 2025-04-13 09:27:45 --> Config Class Initialized
INFO - 2025-04-13 09:27:45 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:27:45 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:27:45 --> Utf8 Class Initialized
INFO - 2025-04-13 09:27:45 --> URI Class Initialized
DEBUG - 2025-04-13 09:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:27:45 --> Router Class Initialized
INFO - 2025-04-13 09:27:45 --> Output Class Initialized
INFO - 2025-04-13 09:27:45 --> Security Class Initialized
DEBUG - 2025-04-13 09:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:27:45 --> Input Class Initialized
INFO - 2025-04-13 09:27:45 --> Language Class Initialized
INFO - 2025-04-13 09:27:45 --> Language Class Initialized
INFO - 2025-04-13 09:27:45 --> Config Class Initialized
INFO - 2025-04-13 09:27:45 --> Loader Class Initialized
INFO - 2025-04-13 09:27:45 --> Helper loaded: url_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: file_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: html_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: form_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: text_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:27:45 --> Database Driver Class Initialized
INFO - 2025-04-13 09:27:45 --> Email Class Initialized
INFO - 2025-04-13 09:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:27:45 --> Form Validation Class Initialized
INFO - 2025-04-13 09:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:27:45 --> Pagination Class Initialized
INFO - 2025-04-13 09:27:45 --> Controller Class Initialized
DEBUG - 2025-04-13 09:27:45 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 15:27:45 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
ERROR - 2025-04-13 15:27:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 15:27:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 15:27:45 --> Final output sent to browser
DEBUG - 2025-04-13 15:27:45 --> Total execution time: 0.2154
INFO - 2025-04-13 09:27:45 --> Config Class Initialized
INFO - 2025-04-13 09:27:45 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:27:45 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:27:45 --> Utf8 Class Initialized
INFO - 2025-04-13 09:27:45 --> URI Class Initialized
DEBUG - 2025-04-13 09:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:27:45 --> Router Class Initialized
INFO - 2025-04-13 09:27:45 --> Output Class Initialized
INFO - 2025-04-13 09:27:45 --> Security Class Initialized
DEBUG - 2025-04-13 09:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:27:45 --> Input Class Initialized
INFO - 2025-04-13 09:27:45 --> Language Class Initialized
INFO - 2025-04-13 09:27:45 --> Language Class Initialized
INFO - 2025-04-13 09:27:45 --> Config Class Initialized
INFO - 2025-04-13 09:27:45 --> Loader Class Initialized
INFO - 2025-04-13 09:27:45 --> Helper loaded: url_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: file_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: html_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: form_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: text_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:27:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:27:45 --> Database Driver Class Initialized
INFO - 2025-04-13 09:27:45 --> Email Class Initialized
INFO - 2025-04-13 09:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:27:45 --> Form Validation Class Initialized
INFO - 2025-04-13 09:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:27:45 --> Pagination Class Initialized
INFO - 2025-04-13 09:27:45 --> Controller Class Initialized
DEBUG - 2025-04-13 09:27:45 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:27:45 --> Model Class Initialized
INFO - 2025-04-13 15:27:45 --> Final output sent to browser
DEBUG - 2025-04-13 15:27:45 --> Total execution time: 0.0674
INFO - 2025-04-13 09:27:47 --> Config Class Initialized
INFO - 2025-04-13 09:27:47 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:27:47 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:27:47 --> Utf8 Class Initialized
INFO - 2025-04-13 09:27:47 --> URI Class Initialized
DEBUG - 2025-04-13 09:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:27:47 --> Router Class Initialized
INFO - 2025-04-13 09:27:47 --> Output Class Initialized
INFO - 2025-04-13 09:27:47 --> Security Class Initialized
DEBUG - 2025-04-13 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:27:47 --> Input Class Initialized
INFO - 2025-04-13 09:27:47 --> Language Class Initialized
INFO - 2025-04-13 09:27:47 --> Language Class Initialized
INFO - 2025-04-13 09:27:47 --> Config Class Initialized
INFO - 2025-04-13 09:27:47 --> Loader Class Initialized
INFO - 2025-04-13 09:27:47 --> Helper loaded: url_helper
INFO - 2025-04-13 09:27:47 --> Helper loaded: file_helper
INFO - 2025-04-13 09:27:47 --> Helper loaded: html_helper
INFO - 2025-04-13 09:27:47 --> Helper loaded: form_helper
INFO - 2025-04-13 09:27:47 --> Helper loaded: text_helper
INFO - 2025-04-13 09:27:47 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:27:47 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:27:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:27:47 --> Database Driver Class Initialized
INFO - 2025-04-13 09:27:47 --> Email Class Initialized
INFO - 2025-04-13 09:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:27:47 --> Form Validation Class Initialized
INFO - 2025-04-13 09:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:27:47 --> Pagination Class Initialized
INFO - 2025-04-13 09:27:47 --> Controller Class Initialized
DEBUG - 2025-04-13 09:27:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:27:47 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:27:47 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:27:47 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:27:47 --> Model Class Initialized
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 15:27:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 15:27:47 --> Model Class Initialized
ERROR - 2025-04-13 15:27:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 15:27:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-13 15:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 15:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 15:27:48 --> Final output sent to browser
DEBUG - 2025-04-13 15:27:48 --> Total execution time: 0.1814
INFO - 2025-04-13 09:28:00 --> Config Class Initialized
INFO - 2025-04-13 09:28:00 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:00 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:00 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:00 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:28:00 --> Router Class Initialized
INFO - 2025-04-13 09:28:00 --> Output Class Initialized
INFO - 2025-04-13 09:28:00 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:00 --> Input Class Initialized
INFO - 2025-04-13 09:28:00 --> Language Class Initialized
INFO - 2025-04-13 09:28:00 --> Language Class Initialized
INFO - 2025-04-13 09:28:00 --> Config Class Initialized
INFO - 2025-04-13 09:28:00 --> Loader Class Initialized
INFO - 2025-04-13 09:28:00 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:00 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:00 --> Email Class Initialized
INFO - 2025-04-13 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:00 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:00 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:00 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:00 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:28:00 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:28:00 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:28:00 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:28:00 --> Model Class Initialized
ERROR - 2025-04-13 09:28:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:28:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:28:00 --> Final output sent to browser
DEBUG - 2025-04-13 09:28:00 --> Total execution time: 0.1762
INFO - 2025-04-13 09:28:00 --> Config Class Initialized
INFO - 2025-04-13 09:28:00 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:00 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:00 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:00 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:28:00 --> Router Class Initialized
INFO - 2025-04-13 09:28:00 --> Output Class Initialized
INFO - 2025-04-13 09:28:00 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:00 --> Input Class Initialized
INFO - 2025-04-13 09:28:00 --> Language Class Initialized
INFO - 2025-04-13 09:28:00 --> Language Class Initialized
INFO - 2025-04-13 09:28:00 --> Config Class Initialized
INFO - 2025-04-13 09:28:00 --> Loader Class Initialized
INFO - 2025-04-13 09:28:00 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:00 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:00 --> Email Class Initialized
INFO - 2025-04-13 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:00 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:00 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:00 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:00 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:28:00 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:28:00 --> Model Class Initialized
INFO - 2025-04-13 09:28:00 --> Final output sent to browser
DEBUG - 2025-04-13 09:28:00 --> Total execution time: 0.0146
INFO - 2025-04-13 09:28:08 --> Config Class Initialized
INFO - 2025-04-13 09:28:08 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:08 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:08 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:08 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:28:08 --> Router Class Initialized
INFO - 2025-04-13 09:28:08 --> Output Class Initialized
INFO - 2025-04-13 09:28:08 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:08 --> Input Class Initialized
INFO - 2025-04-13 09:28:08 --> Language Class Initialized
INFO - 2025-04-13 09:28:08 --> Language Class Initialized
INFO - 2025-04-13 09:28:08 --> Config Class Initialized
INFO - 2025-04-13 09:28:08 --> Loader Class Initialized
INFO - 2025-04-13 09:28:08 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:08 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:08 --> Email Class Initialized
INFO - 2025-04-13 09:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:08 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:08 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:08 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:08 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 15:28:08 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
ERROR - 2025-04-13 15:28:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 15:28:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 15:28:08 --> Final output sent to browser
DEBUG - 2025-04-13 15:28:08 --> Total execution time: 0.1464
INFO - 2025-04-13 09:28:08 --> Config Class Initialized
INFO - 2025-04-13 09:28:08 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:08 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:08 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:08 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:28:08 --> Router Class Initialized
INFO - 2025-04-13 09:28:08 --> Output Class Initialized
INFO - 2025-04-13 09:28:08 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:08 --> Input Class Initialized
INFO - 2025-04-13 09:28:08 --> Language Class Initialized
INFO - 2025-04-13 09:28:08 --> Language Class Initialized
INFO - 2025-04-13 09:28:08 --> Config Class Initialized
INFO - 2025-04-13 09:28:08 --> Loader Class Initialized
INFO - 2025-04-13 09:28:08 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:08 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:08 --> Email Class Initialized
INFO - 2025-04-13 09:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:08 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:08 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:08 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:08 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:28:08 --> Model Class Initialized
INFO - 2025-04-13 15:28:08 --> Final output sent to browser
DEBUG - 2025-04-13 15:28:08 --> Total execution time: 0.0699
INFO - 2025-04-13 09:28:21 --> Config Class Initialized
INFO - 2025-04-13 09:28:21 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:21 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:21 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:21 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:28:21 --> Router Class Initialized
INFO - 2025-04-13 09:28:21 --> Output Class Initialized
INFO - 2025-04-13 09:28:21 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:21 --> Input Class Initialized
INFO - 2025-04-13 09:28:21 --> Language Class Initialized
INFO - 2025-04-13 09:28:21 --> Language Class Initialized
INFO - 2025-04-13 09:28:21 --> Config Class Initialized
INFO - 2025-04-13 09:28:21 --> Loader Class Initialized
INFO - 2025-04-13 09:28:21 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:21 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:21 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:21 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:21 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:21 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:21 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:21 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:21 --> Email Class Initialized
INFO - 2025-04-13 09:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:21 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:21 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:21 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:21 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:28:21 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:28:21 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:28:21 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:28:22 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:28:22 --> Model Class Initialized
ERROR - 2025-04-13 09:28:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:28:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:28:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:28:22 --> Final output sent to browser
DEBUG - 2025-04-13 09:28:22 --> Total execution time: 0.2113
INFO - 2025-04-13 09:28:24 --> Config Class Initialized
INFO - 2025-04-13 09:28:24 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:24 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:24 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:24 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:28:24 --> Router Class Initialized
INFO - 2025-04-13 09:28:24 --> Output Class Initialized
INFO - 2025-04-13 09:28:24 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:24 --> Input Class Initialized
INFO - 2025-04-13 09:28:24 --> Language Class Initialized
INFO - 2025-04-13 09:28:24 --> Language Class Initialized
INFO - 2025-04-13 09:28:24 --> Config Class Initialized
INFO - 2025-04-13 09:28:24 --> Loader Class Initialized
INFO - 2025-04-13 09:28:24 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:24 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:24 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:24 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:24 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:24 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:24 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:24 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:24 --> Email Class Initialized
INFO - 2025-04-13 09:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:24 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:24 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:24 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:24 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:28:24 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:28:24 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:28:24 --> Model Class Initialized
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:28:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:28:24 --> Model Class Initialized
ERROR - 2025-04-13 09:28:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:28:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:28:24 --> Final output sent to browser
DEBUG - 2025-04-13 09:28:24 --> Total execution time: 0.1874
INFO - 2025-04-13 09:28:42 --> Config Class Initialized
INFO - 2025-04-13 09:28:42 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:42 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:42 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:42 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:28:42 --> Router Class Initialized
INFO - 2025-04-13 09:28:42 --> Output Class Initialized
INFO - 2025-04-13 09:28:42 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:42 --> Input Class Initialized
INFO - 2025-04-13 09:28:42 --> Language Class Initialized
INFO - 2025-04-13 09:28:42 --> Language Class Initialized
INFO - 2025-04-13 09:28:42 --> Config Class Initialized
INFO - 2025-04-13 09:28:42 --> Loader Class Initialized
INFO - 2025-04-13 09:28:42 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:42 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:42 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:42 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:42 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:42 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:42 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:42 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:42 --> Email Class Initialized
INFO - 2025-04-13 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:42 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:42 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:42 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:28:42 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:28:42 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:28:42 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:28:42 --> Model Class Initialized
INFO - 2025-04-13 15:28:42 --> Final output sent to browser
DEBUG - 2025-04-13 15:28:42 --> Total execution time: 0.0132
INFO - 2025-04-13 09:28:43 --> Config Class Initialized
INFO - 2025-04-13 09:28:43 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:43 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:43 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:43 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:28:43 --> Router Class Initialized
INFO - 2025-04-13 09:28:43 --> Output Class Initialized
INFO - 2025-04-13 09:28:43 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:43 --> Input Class Initialized
INFO - 2025-04-13 09:28:43 --> Language Class Initialized
INFO - 2025-04-13 09:28:43 --> Language Class Initialized
INFO - 2025-04-13 09:28:43 --> Config Class Initialized
INFO - 2025-04-13 09:28:43 --> Loader Class Initialized
INFO - 2025-04-13 09:28:43 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:43 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:43 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:43 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:43 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:43 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:43 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:43 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:43 --> Email Class Initialized
INFO - 2025-04-13 09:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:43 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:43 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:43 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:43 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:28:43 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:28:43 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:28:43 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:28:43 --> Model Class Initialized
INFO - 2025-04-13 15:28:43 --> Final output sent to browser
DEBUG - 2025-04-13 15:28:43 --> Total execution time: 0.0178
INFO - 2025-04-13 09:28:46 --> Config Class Initialized
INFO - 2025-04-13 09:28:46 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:46 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:46 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:46 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:28:46 --> Router Class Initialized
INFO - 2025-04-13 09:28:46 --> Output Class Initialized
INFO - 2025-04-13 09:28:46 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:46 --> Input Class Initialized
INFO - 2025-04-13 09:28:46 --> Language Class Initialized
INFO - 2025-04-13 09:28:46 --> Language Class Initialized
INFO - 2025-04-13 09:28:46 --> Config Class Initialized
INFO - 2025-04-13 09:28:46 --> Loader Class Initialized
INFO - 2025-04-13 09:28:46 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:46 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:46 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:46 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:46 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:46 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:46 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:46 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:46 --> Email Class Initialized
INFO - 2025-04-13 09:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:46 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:46 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:46 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:28:46 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:28:46 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:28:46 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:28:46 --> Model Class Initialized
INFO - 2025-04-13 15:28:46 --> Final output sent to browser
DEBUG - 2025-04-13 15:28:46 --> Total execution time: 0.0066
INFO - 2025-04-13 09:28:58 --> Config Class Initialized
INFO - 2025-04-13 09:28:58 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:58 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:58 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:58 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:28:58 --> Router Class Initialized
INFO - 2025-04-13 09:28:58 --> Output Class Initialized
INFO - 2025-04-13 09:28:58 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:58 --> Input Class Initialized
INFO - 2025-04-13 09:28:58 --> Language Class Initialized
INFO - 2025-04-13 09:28:58 --> Language Class Initialized
INFO - 2025-04-13 09:28:58 --> Config Class Initialized
INFO - 2025-04-13 09:28:58 --> Loader Class Initialized
INFO - 2025-04-13 09:28:58 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:58 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:58 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:58 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:58 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:58 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:58 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:58 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:58 --> Email Class Initialized
INFO - 2025-04-13 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:58 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:58 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:58 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:28:58 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:28:58 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:28:58 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:28:58 --> Model Class Initialized
INFO - 2025-04-13 15:28:58 --> Final output sent to browser
DEBUG - 2025-04-13 15:28:58 --> Total execution time: 0.0131
INFO - 2025-04-13 09:28:59 --> Config Class Initialized
INFO - 2025-04-13 09:28:59 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:28:59 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:28:59 --> Utf8 Class Initialized
INFO - 2025-04-13 09:28:59 --> URI Class Initialized
DEBUG - 2025-04-13 09:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:28:59 --> Router Class Initialized
INFO - 2025-04-13 09:28:59 --> Output Class Initialized
INFO - 2025-04-13 09:28:59 --> Security Class Initialized
DEBUG - 2025-04-13 09:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:28:59 --> Input Class Initialized
INFO - 2025-04-13 09:28:59 --> Language Class Initialized
INFO - 2025-04-13 09:28:59 --> Language Class Initialized
INFO - 2025-04-13 09:28:59 --> Config Class Initialized
INFO - 2025-04-13 09:28:59 --> Loader Class Initialized
INFO - 2025-04-13 09:28:59 --> Helper loaded: url_helper
INFO - 2025-04-13 09:28:59 --> Helper loaded: file_helper
INFO - 2025-04-13 09:28:59 --> Helper loaded: html_helper
INFO - 2025-04-13 09:28:59 --> Helper loaded: form_helper
INFO - 2025-04-13 09:28:59 --> Helper loaded: text_helper
INFO - 2025-04-13 09:28:59 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:28:59 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:28:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:28:59 --> Database Driver Class Initialized
INFO - 2025-04-13 09:28:59 --> Email Class Initialized
INFO - 2025-04-13 09:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:28:59 --> Form Validation Class Initialized
INFO - 2025-04-13 09:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:28:59 --> Pagination Class Initialized
INFO - 2025-04-13 09:28:59 --> Controller Class Initialized
DEBUG - 2025-04-13 09:28:59 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:28:59 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:28:59 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:28:59 --> Model Class Initialized
DEBUG - 2025-04-13 15:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:28:59 --> Model Class Initialized
INFO - 2025-04-13 15:28:59 --> Final output sent to browser
DEBUG - 2025-04-13 15:28:59 --> Total execution time: 0.0203
INFO - 2025-04-13 09:29:02 --> Config Class Initialized
INFO - 2025-04-13 09:29:02 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:29:02 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:29:02 --> Utf8 Class Initialized
INFO - 2025-04-13 09:29:02 --> URI Class Initialized
DEBUG - 2025-04-13 09:29:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-13 09:29:02 --> Router Class Initialized
INFO - 2025-04-13 09:29:02 --> Output Class Initialized
INFO - 2025-04-13 09:29:02 --> Security Class Initialized
DEBUG - 2025-04-13 09:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:29:02 --> Input Class Initialized
INFO - 2025-04-13 09:29:02 --> Language Class Initialized
INFO - 2025-04-13 09:29:02 --> Language Class Initialized
INFO - 2025-04-13 09:29:02 --> Config Class Initialized
INFO - 2025-04-13 09:29:02 --> Loader Class Initialized
INFO - 2025-04-13 09:29:02 --> Helper loaded: url_helper
INFO - 2025-04-13 09:29:02 --> Helper loaded: file_helper
INFO - 2025-04-13 09:29:02 --> Helper loaded: html_helper
INFO - 2025-04-13 09:29:02 --> Helper loaded: form_helper
INFO - 2025-04-13 09:29:02 --> Helper loaded: text_helper
INFO - 2025-04-13 09:29:02 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:29:02 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:29:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:29:02 --> Database Driver Class Initialized
INFO - 2025-04-13 09:29:02 --> Email Class Initialized
INFO - 2025-04-13 09:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:29:02 --> Form Validation Class Initialized
INFO - 2025-04-13 09:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:29:02 --> Pagination Class Initialized
INFO - 2025-04-13 09:29:02 --> Controller Class Initialized
DEBUG - 2025-04-13 09:29:02 --> Invoice MX_Controller Initialized
INFO - 2025-04-13 15:29:02 --> Model Class Initialized
DEBUG - 2025-04-13 15:29:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-13 15:29:02 --> Model Class Initialized
DEBUG - 2025-04-13 15:29:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-13 15:29:02 --> Model Class Initialized
DEBUG - 2025-04-13 15:29:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 15:29:02 --> Model Class Initialized
INFO - 2025-04-13 15:29:02 --> Final output sent to browser
DEBUG - 2025-04-13 15:29:02 --> Total execution time: 0.0098
INFO - 2025-04-13 09:29:10 --> Config Class Initialized
INFO - 2025-04-13 09:29:10 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:29:10 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:29:10 --> Utf8 Class Initialized
INFO - 2025-04-13 09:29:10 --> URI Class Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:29:10 --> Router Class Initialized
INFO - 2025-04-13 09:29:10 --> Output Class Initialized
INFO - 2025-04-13 09:29:10 --> Security Class Initialized
DEBUG - 2025-04-13 09:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:29:10 --> Input Class Initialized
INFO - 2025-04-13 09:29:10 --> Language Class Initialized
INFO - 2025-04-13 09:29:10 --> Language Class Initialized
INFO - 2025-04-13 09:29:10 --> Config Class Initialized
INFO - 2025-04-13 09:29:10 --> Loader Class Initialized
INFO - 2025-04-13 09:29:10 --> Helper loaded: url_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: file_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: html_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: form_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: text_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:29:10 --> Database Driver Class Initialized
INFO - 2025-04-13 09:29:10 --> Email Class Initialized
INFO - 2025-04-13 09:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:29:10 --> Form Validation Class Initialized
INFO - 2025-04-13 09:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:29:10 --> Pagination Class Initialized
INFO - 2025-04-13 09:29:10 --> Controller Class Initialized
DEBUG - 2025-04-13 09:29:10 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:29:10 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:29:10 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:29:10 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:10 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-13 09:29:10 --> ✅ Proceeding with return_invoice_entry()
DEBUG - 2025-04-13 09:29:10 --> 📦 return_invoice_entry() returned Invoice ID: 3092910887
DEBUG - 2025-04-13 09:29:10 --> 🔁 autoapprove() called for invoice_id: 3092910887
DEBUG - 2025-04-13 09:29:10 --> 🧾 Found 1 vouchers to approve
DEBUG - 2025-04-13 09:29:10 --> 📝 Approving voucher: CV-53
DEBUG - 2025-04-13 09:29:10 --> 📥 acc_transaction insert: {"vid":"180","fyear":"1","VNo":"CV-53","Vtype":"CV","referenceNo":"3092910887","VDate":"2025-04-13","COAID":"1020101","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-13 09:29:10"}
DEBUG - 2025-04-13 09:29:10 --> 📥 acc_transaction insert: {"vid":"180","fyear":"1","VNo":"CV-53","Vtype":"CV","referenceNo":"3092910887","VDate":"2025-04-13","COAID":"3010301","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-13 09:29:10"}
DEBUG - 2025-04-13 09:29:10 --> ✅ Voucher approved: CV-53 | Result: true
INFO - 2025-04-13 09:29:10 --> Config Class Initialized
INFO - 2025-04-13 09:29:10 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:29:10 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:29:10 --> Utf8 Class Initialized
INFO - 2025-04-13 09:29:10 --> URI Class Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-13 09:29:10 --> Router Class Initialized
INFO - 2025-04-13 09:29:10 --> Output Class Initialized
INFO - 2025-04-13 09:29:10 --> Security Class Initialized
DEBUG - 2025-04-13 09:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:29:10 --> Input Class Initialized
INFO - 2025-04-13 09:29:10 --> Language Class Initialized
INFO - 2025-04-13 09:29:10 --> Language Class Initialized
INFO - 2025-04-13 09:29:10 --> Config Class Initialized
INFO - 2025-04-13 09:29:10 --> Loader Class Initialized
INFO - 2025-04-13 09:29:10 --> Helper loaded: url_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: file_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: html_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: form_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: text_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:29:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:29:10 --> Database Driver Class Initialized
INFO - 2025-04-13 09:29:10 --> Email Class Initialized
INFO - 2025-04-13 09:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:29:10 --> Form Validation Class Initialized
INFO - 2025-04-13 09:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:29:10 --> Pagination Class Initialized
INFO - 2025-04-13 09:29:10 --> Controller Class Initialized
DEBUG - 2025-04-13 09:29:10 --> Returns MX_Controller Initialized
INFO - 2025-04-13 09:29:10 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-13 09:29:10 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-13 09:29:10 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:29:10 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:29:10 --> Model Class Initialized
ERROR - 2025-04-13 09:29:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:29:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-13 09:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:29:11 --> Final output sent to browser
DEBUG - 2025-04-13 09:29:11 --> Total execution time: 0.1460
INFO - 2025-04-13 09:29:36 --> Config Class Initialized
INFO - 2025-04-13 09:29:36 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:29:36 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:29:36 --> Utf8 Class Initialized
INFO - 2025-04-13 09:29:36 --> URI Class Initialized
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:29:36 --> Router Class Initialized
INFO - 2025-04-13 09:29:36 --> Output Class Initialized
INFO - 2025-04-13 09:29:36 --> Security Class Initialized
DEBUG - 2025-04-13 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:29:36 --> Input Class Initialized
INFO - 2025-04-13 09:29:36 --> Language Class Initialized
INFO - 2025-04-13 09:29:36 --> Language Class Initialized
INFO - 2025-04-13 09:29:36 --> Config Class Initialized
INFO - 2025-04-13 09:29:36 --> Loader Class Initialized
INFO - 2025-04-13 09:29:36 --> Helper loaded: url_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: file_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: html_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: form_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: text_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:29:36 --> Database Driver Class Initialized
INFO - 2025-04-13 09:29:36 --> Email Class Initialized
INFO - 2025-04-13 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:29:36 --> Form Validation Class Initialized
INFO - 2025-04-13 09:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:29:36 --> Pagination Class Initialized
INFO - 2025-04-13 09:29:36 --> Controller Class Initialized
DEBUG - 2025-04-13 09:29:36 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:29:36 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:29:36 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-13 09:29:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-13 09:29:36 --> Model Class Initialized
ERROR - 2025-04-13 09:29:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-13 09:29:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-13 09:29:36 --> Final output sent to browser
DEBUG - 2025-04-13 09:29:36 --> Total execution time: 0.1662
INFO - 2025-04-13 09:29:36 --> Config Class Initialized
INFO - 2025-04-13 09:29:36 --> Hooks Class Initialized
DEBUG - 2025-04-13 09:29:36 --> UTF-8 Support Enabled
INFO - 2025-04-13 09:29:36 --> Utf8 Class Initialized
INFO - 2025-04-13 09:29:36 --> URI Class Initialized
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-13 09:29:36 --> Router Class Initialized
INFO - 2025-04-13 09:29:36 --> Output Class Initialized
INFO - 2025-04-13 09:29:36 --> Security Class Initialized
DEBUG - 2025-04-13 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-13 09:29:36 --> Input Class Initialized
INFO - 2025-04-13 09:29:36 --> Language Class Initialized
INFO - 2025-04-13 09:29:36 --> Language Class Initialized
INFO - 2025-04-13 09:29:36 --> Config Class Initialized
INFO - 2025-04-13 09:29:36 --> Loader Class Initialized
INFO - 2025-04-13 09:29:36 --> Helper loaded: url_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: file_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: html_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: form_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: text_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: lang_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: directory_helper
INFO - 2025-04-13 09:29:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-13 09:29:36 --> Database Driver Class Initialized
INFO - 2025-04-13 09:29:36 --> Email Class Initialized
INFO - 2025-04-13 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-13 09:29:36 --> Form Validation Class Initialized
INFO - 2025-04-13 09:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-13 09:29:36 --> Pagination Class Initialized
INFO - 2025-04-13 09:29:36 --> Controller Class Initialized
DEBUG - 2025-04-13 09:29:36 --> Report MX_Controller Initialized
INFO - 2025-04-13 09:29:36 --> Model Class Initialized
DEBUG - 2025-04-13 09:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-13 09:29:36 --> Model Class Initialized
INFO - 2025-04-13 09:29:36 --> Final output sent to browser
DEBUG - 2025-04-13 09:29:36 --> Total execution time: 0.0125
