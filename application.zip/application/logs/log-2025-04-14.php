<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-14 19:12:02 --> Config Class Initialized
INFO - 2025-04-14 19:12:02 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:02 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:02 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:02 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:12:02 --> Router Class Initialized
INFO - 2025-04-14 19:12:02 --> Output Class Initialized
INFO - 2025-04-14 19:12:02 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:02 --> Input Class Initialized
INFO - 2025-04-14 19:12:02 --> Language Class Initialized
INFO - 2025-04-14 19:12:02 --> Language Class Initialized
INFO - 2025-04-14 19:12:02 --> Config Class Initialized
INFO - 2025-04-14 19:12:02 --> Loader Class Initialized
INFO - 2025-04-14 19:12:02 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:02 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:02 --> Email Class Initialized
INFO - 2025-04-14 19:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:02 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:02 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:02 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:02 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:12:02 --> Model Class Initialized
DEBUG - 2025-04-14 19:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:12:02 --> Model Class Initialized
INFO - 2025-04-14 19:12:02 --> Config Class Initialized
INFO - 2025-04-14 19:12:02 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:02 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:02 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:02 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-14 19:12:02 --> Router Class Initialized
INFO - 2025-04-14 19:12:02 --> Output Class Initialized
INFO - 2025-04-14 19:12:02 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:02 --> Input Class Initialized
INFO - 2025-04-14 19:12:02 --> Language Class Initialized
INFO - 2025-04-14 19:12:02 --> Language Class Initialized
INFO - 2025-04-14 19:12:02 --> Config Class Initialized
INFO - 2025-04-14 19:12:02 --> Loader Class Initialized
INFO - 2025-04-14 19:12:02 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:02 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:02 --> Email Class Initialized
INFO - 2025-04-14 19:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:02 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:02 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:02 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:02 --> Auth MX_Controller Initialized
INFO - 2025-04-14 19:12:02 --> Model Class Initialized
DEBUG - 2025-04-14 19:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-14 19:12:02 --> Model Class Initialized
DEBUG - 2025-04-14 19:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:12:02 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:12:02 --> Model Class Initialized
DEBUG - 2025-04-14 19:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-14 19:12:02 --> Final output sent to browser
DEBUG - 2025-04-14 19:12:02 --> Total execution time: 0.0281
INFO - 2025-04-14 19:12:11 --> Config Class Initialized
INFO - 2025-04-14 19:12:11 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:11 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:11 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:11 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-14 19:12:11 --> Router Class Initialized
INFO - 2025-04-14 19:12:11 --> Output Class Initialized
INFO - 2025-04-14 19:12:11 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:11 --> Input Class Initialized
INFO - 2025-04-14 19:12:11 --> Language Class Initialized
INFO - 2025-04-14 19:12:11 --> Language Class Initialized
INFO - 2025-04-14 19:12:11 --> Config Class Initialized
INFO - 2025-04-14 19:12:11 --> Loader Class Initialized
INFO - 2025-04-14 19:12:11 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:11 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:11 --> Email Class Initialized
INFO - 2025-04-14 19:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:11 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:11 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:11 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:11 --> Auth MX_Controller Initialized
INFO - 2025-04-14 19:12:11 --> Model Class Initialized
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-14 19:12:11 --> Model Class Initialized
INFO - 2025-04-14 19:12:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-14 19:12:11 --> Config Class Initialized
INFO - 2025-04-14 19:12:11 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:11 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:11 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:11 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-14 19:12:11 --> Router Class Initialized
INFO - 2025-04-14 19:12:11 --> Output Class Initialized
INFO - 2025-04-14 19:12:11 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:11 --> Input Class Initialized
INFO - 2025-04-14 19:12:11 --> Language Class Initialized
INFO - 2025-04-14 19:12:11 --> Language Class Initialized
INFO - 2025-04-14 19:12:11 --> Config Class Initialized
INFO - 2025-04-14 19:12:11 --> Loader Class Initialized
INFO - 2025-04-14 19:12:11 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:11 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:11 --> Email Class Initialized
INFO - 2025-04-14 19:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:11 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:11 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:11 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:11 --> Home MX_Controller Initialized
INFO - 2025-04-14 19:12:11 --> Model Class Initialized
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-14 19:12:11 --> Model Class Initialized
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:12:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:12:11 --> Model Class Initialized
ERROR - 2025-04-14 19:12:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:12:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:12:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:12:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:12:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:12:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-14 19:12:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:12:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:12:12 --> Final output sent to browser
DEBUG - 2025-04-14 19:12:12 --> Total execution time: 0.7073
INFO - 2025-04-14 19:12:32 --> Config Class Initialized
INFO - 2025-04-14 19:12:32 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:32 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:32 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:32 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:12:32 --> Router Class Initialized
INFO - 2025-04-14 19:12:32 --> Output Class Initialized
INFO - 2025-04-14 19:12:32 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:32 --> Input Class Initialized
INFO - 2025-04-14 19:12:32 --> Language Class Initialized
INFO - 2025-04-14 19:12:32 --> Language Class Initialized
INFO - 2025-04-14 19:12:32 --> Config Class Initialized
INFO - 2025-04-14 19:12:32 --> Loader Class Initialized
INFO - 2025-04-14 19:12:32 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:32 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:32 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:32 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:32 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:32 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:32 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:32 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:32 --> Email Class Initialized
INFO - 2025-04-14 19:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:32 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:32 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:32 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:32 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:12:33 --> Config Class Initialized
INFO - 2025-04-14 19:12:33 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:33 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:33 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:33 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:12:33 --> Router Class Initialized
INFO - 2025-04-14 19:12:33 --> Output Class Initialized
INFO - 2025-04-14 19:12:33 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:33 --> Input Class Initialized
INFO - 2025-04-14 19:12:33 --> Language Class Initialized
INFO - 2025-04-14 19:12:33 --> Language Class Initialized
INFO - 2025-04-14 19:12:33 --> Config Class Initialized
INFO - 2025-04-14 19:12:33 --> Loader Class Initialized
INFO - 2025-04-14 19:12:33 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:33 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:33 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:33 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:33 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:33 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:33 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:33 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:33 --> Email Class Initialized
INFO - 2025-04-14 19:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:33 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:33 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:33 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:33 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:12:36 --> Config Class Initialized
INFO - 2025-04-14 19:12:36 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:36 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:36 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:36 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:12:36 --> Router Class Initialized
INFO - 2025-04-14 19:12:36 --> Output Class Initialized
INFO - 2025-04-14 19:12:36 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:36 --> Input Class Initialized
INFO - 2025-04-14 19:12:36 --> Language Class Initialized
INFO - 2025-04-14 19:12:36 --> Language Class Initialized
INFO - 2025-04-14 19:12:36 --> Config Class Initialized
INFO - 2025-04-14 19:12:36 --> Loader Class Initialized
INFO - 2025-04-14 19:12:36 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:36 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:36 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:36 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:36 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:36 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:36 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:36 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:36 --> Email Class Initialized
INFO - 2025-04-14 19:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:36 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:36 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:36 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:36 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:12:42 --> Config Class Initialized
INFO - 2025-04-14 19:12:42 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:42 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:42 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:42 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:12:42 --> Router Class Initialized
INFO - 2025-04-14 19:12:42 --> Output Class Initialized
INFO - 2025-04-14 19:12:42 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:42 --> Input Class Initialized
INFO - 2025-04-14 19:12:42 --> Language Class Initialized
INFO - 2025-04-14 19:12:42 --> Language Class Initialized
INFO - 2025-04-14 19:12:42 --> Config Class Initialized
INFO - 2025-04-14 19:12:42 --> Loader Class Initialized
INFO - 2025-04-14 19:12:42 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:42 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:42 --> Email Class Initialized
INFO - 2025-04-14 19:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:42 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:42 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:42 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:12:42 --> Config Class Initialized
INFO - 2025-04-14 19:12:42 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:42 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:42 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:42 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:12:42 --> Router Class Initialized
INFO - 2025-04-14 19:12:42 --> Output Class Initialized
INFO - 2025-04-14 19:12:42 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:42 --> Input Class Initialized
INFO - 2025-04-14 19:12:42 --> Language Class Initialized
INFO - 2025-04-14 19:12:42 --> Language Class Initialized
INFO - 2025-04-14 19:12:42 --> Config Class Initialized
INFO - 2025-04-14 19:12:42 --> Loader Class Initialized
INFO - 2025-04-14 19:12:42 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:42 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:42 --> Email Class Initialized
INFO - 2025-04-14 19:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:42 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:42 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:42 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:12:45 --> Config Class Initialized
INFO - 2025-04-14 19:12:45 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:12:45 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:12:45 --> Utf8 Class Initialized
INFO - 2025-04-14 19:12:45 --> URI Class Initialized
DEBUG - 2025-04-14 19:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:12:45 --> Router Class Initialized
INFO - 2025-04-14 19:12:45 --> Output Class Initialized
INFO - 2025-04-14 19:12:45 --> Security Class Initialized
DEBUG - 2025-04-14 19:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:12:45 --> Input Class Initialized
INFO - 2025-04-14 19:12:45 --> Language Class Initialized
INFO - 2025-04-14 19:12:45 --> Language Class Initialized
INFO - 2025-04-14 19:12:45 --> Config Class Initialized
INFO - 2025-04-14 19:12:45 --> Loader Class Initialized
INFO - 2025-04-14 19:12:45 --> Helper loaded: url_helper
INFO - 2025-04-14 19:12:45 --> Helper loaded: file_helper
INFO - 2025-04-14 19:12:45 --> Helper loaded: html_helper
INFO - 2025-04-14 19:12:45 --> Helper loaded: form_helper
INFO - 2025-04-14 19:12:45 --> Helper loaded: text_helper
INFO - 2025-04-14 19:12:45 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:12:45 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:12:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:12:45 --> Database Driver Class Initialized
INFO - 2025-04-14 19:12:45 --> Email Class Initialized
INFO - 2025-04-14 19:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:12:45 --> Form Validation Class Initialized
INFO - 2025-04-14 19:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:12:45 --> Pagination Class Initialized
INFO - 2025-04-14 19:12:45 --> Controller Class Initialized
DEBUG - 2025-04-14 19:12:45 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:20:30 --> Config Class Initialized
INFO - 2025-04-14 19:20:30 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:20:30 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:20:30 --> Utf8 Class Initialized
INFO - 2025-04-14 19:20:30 --> URI Class Initialized
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-14 19:20:30 --> Router Class Initialized
INFO - 2025-04-14 19:20:30 --> Output Class Initialized
INFO - 2025-04-14 19:20:30 --> Security Class Initialized
DEBUG - 2025-04-14 19:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:20:30 --> Input Class Initialized
INFO - 2025-04-14 19:20:30 --> Language Class Initialized
INFO - 2025-04-14 19:20:30 --> Language Class Initialized
INFO - 2025-04-14 19:20:30 --> Config Class Initialized
INFO - 2025-04-14 19:20:30 --> Loader Class Initialized
INFO - 2025-04-14 19:20:30 --> Helper loaded: url_helper
INFO - 2025-04-14 19:20:30 --> Helper loaded: file_helper
INFO - 2025-04-14 19:20:30 --> Helper loaded: html_helper
INFO - 2025-04-14 19:20:30 --> Helper loaded: form_helper
INFO - 2025-04-14 19:20:30 --> Helper loaded: text_helper
INFO - 2025-04-14 19:20:30 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:20:30 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:20:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:20:30 --> Database Driver Class Initialized
INFO - 2025-04-14 19:20:30 --> Email Class Initialized
INFO - 2025-04-14 19:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:20:30 --> Form Validation Class Initialized
INFO - 2025-04-14 19:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:20:30 --> Pagination Class Initialized
INFO - 2025-04-14 19:20:30 --> Controller Class Initialized
DEBUG - 2025-04-14 19:20:30 --> Home MX_Controller Initialized
INFO - 2025-04-14 19:20:30 --> Model Class Initialized
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-14 19:20:30 --> Model Class Initialized
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:20:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:20:30 --> Model Class Initialized
ERROR - 2025-04-14 19:20:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:20:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/out_of_stock.php
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:20:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:20:30 --> Final output sent to browser
DEBUG - 2025-04-14 19:20:30 --> Total execution time: 0.1525
INFO - 2025-04-14 19:24:47 --> Config Class Initialized
INFO - 2025-04-14 19:24:47 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:24:47 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:24:47 --> Utf8 Class Initialized
INFO - 2025-04-14 19:24:47 --> URI Class Initialized
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-14 19:24:47 --> Router Class Initialized
INFO - 2025-04-14 19:24:47 --> Output Class Initialized
INFO - 2025-04-14 19:24:47 --> Security Class Initialized
DEBUG - 2025-04-14 19:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:24:47 --> Input Class Initialized
INFO - 2025-04-14 19:24:47 --> Language Class Initialized
INFO - 2025-04-14 19:24:47 --> Language Class Initialized
INFO - 2025-04-14 19:24:47 --> Config Class Initialized
INFO - 2025-04-14 19:24:47 --> Loader Class Initialized
INFO - 2025-04-14 19:24:47 --> Helper loaded: url_helper
INFO - 2025-04-14 19:24:47 --> Helper loaded: file_helper
INFO - 2025-04-14 19:24:47 --> Helper loaded: html_helper
INFO - 2025-04-14 19:24:47 --> Helper loaded: form_helper
INFO - 2025-04-14 19:24:47 --> Helper loaded: text_helper
INFO - 2025-04-14 19:24:47 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:24:47 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:24:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:24:47 --> Database Driver Class Initialized
INFO - 2025-04-14 19:24:47 --> Email Class Initialized
INFO - 2025-04-14 19:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:24:47 --> Form Validation Class Initialized
INFO - 2025-04-14 19:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:24:47 --> Pagination Class Initialized
INFO - 2025-04-14 19:24:47 --> Controller Class Initialized
DEBUG - 2025-04-14 19:24:47 --> Home MX_Controller Initialized
INFO - 2025-04-14 19:24:47 --> Model Class Initialized
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-14 19:24:47 --> Model Class Initialized
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:24:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:24:47 --> Model Class Initialized
ERROR - 2025-04-14 19:24:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:24:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/out_of_stock.php
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:24:47 --> Final output sent to browser
DEBUG - 2025-04-14 19:24:47 --> Total execution time: 0.1080
INFO - 2025-04-14 19:24:51 --> Config Class Initialized
INFO - 2025-04-14 19:24:51 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:24:51 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:24:51 --> Utf8 Class Initialized
INFO - 2025-04-14 19:24:51 --> URI Class Initialized
DEBUG - 2025-04-14 19:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:24:51 --> Router Class Initialized
INFO - 2025-04-14 19:24:51 --> Output Class Initialized
INFO - 2025-04-14 19:24:51 --> Security Class Initialized
DEBUG - 2025-04-14 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:24:51 --> Input Class Initialized
INFO - 2025-04-14 19:24:51 --> Language Class Initialized
INFO - 2025-04-14 19:24:51 --> Language Class Initialized
INFO - 2025-04-14 19:24:51 --> Config Class Initialized
INFO - 2025-04-14 19:24:51 --> Loader Class Initialized
INFO - 2025-04-14 19:24:51 --> Helper loaded: url_helper
INFO - 2025-04-14 19:24:51 --> Helper loaded: file_helper
INFO - 2025-04-14 19:24:51 --> Helper loaded: html_helper
INFO - 2025-04-14 19:24:51 --> Helper loaded: form_helper
INFO - 2025-04-14 19:24:51 --> Helper loaded: text_helper
INFO - 2025-04-14 19:24:51 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:24:51 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:24:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:24:51 --> Database Driver Class Initialized
INFO - 2025-04-14 19:24:51 --> Email Class Initialized
INFO - 2025-04-14 19:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:24:51 --> Form Validation Class Initialized
INFO - 2025-04-14 19:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:24:51 --> Pagination Class Initialized
INFO - 2025-04-14 19:24:51 --> Controller Class Initialized
DEBUG - 2025-04-14 19:24:51 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:24:52 --> Config Class Initialized
INFO - 2025-04-14 19:24:52 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:24:52 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:24:52 --> Utf8 Class Initialized
INFO - 2025-04-14 19:24:52 --> URI Class Initialized
DEBUG - 2025-04-14 19:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:24:52 --> Router Class Initialized
INFO - 2025-04-14 19:24:52 --> Output Class Initialized
INFO - 2025-04-14 19:24:52 --> Security Class Initialized
DEBUG - 2025-04-14 19:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:24:52 --> Input Class Initialized
INFO - 2025-04-14 19:24:52 --> Language Class Initialized
INFO - 2025-04-14 19:24:52 --> Language Class Initialized
INFO - 2025-04-14 19:24:52 --> Config Class Initialized
INFO - 2025-04-14 19:24:52 --> Loader Class Initialized
INFO - 2025-04-14 19:24:52 --> Helper loaded: url_helper
INFO - 2025-04-14 19:24:52 --> Helper loaded: file_helper
INFO - 2025-04-14 19:24:52 --> Helper loaded: html_helper
INFO - 2025-04-14 19:24:52 --> Helper loaded: form_helper
INFO - 2025-04-14 19:24:52 --> Helper loaded: text_helper
INFO - 2025-04-14 19:24:52 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:24:52 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:24:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:24:52 --> Database Driver Class Initialized
INFO - 2025-04-14 19:24:52 --> Email Class Initialized
INFO - 2025-04-14 19:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:24:52 --> Form Validation Class Initialized
INFO - 2025-04-14 19:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:24:52 --> Pagination Class Initialized
INFO - 2025-04-14 19:24:52 --> Controller Class Initialized
DEBUG - 2025-04-14 19:24:52 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:24:56 --> Config Class Initialized
INFO - 2025-04-14 19:24:56 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:24:56 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:24:56 --> Utf8 Class Initialized
INFO - 2025-04-14 19:24:56 --> URI Class Initialized
DEBUG - 2025-04-14 19:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:24:56 --> Router Class Initialized
INFO - 2025-04-14 19:24:56 --> Output Class Initialized
INFO - 2025-04-14 19:24:56 --> Security Class Initialized
DEBUG - 2025-04-14 19:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:24:56 --> Input Class Initialized
INFO - 2025-04-14 19:24:56 --> Language Class Initialized
INFO - 2025-04-14 19:24:56 --> Language Class Initialized
INFO - 2025-04-14 19:24:56 --> Config Class Initialized
INFO - 2025-04-14 19:24:56 --> Loader Class Initialized
INFO - 2025-04-14 19:24:56 --> Helper loaded: url_helper
INFO - 2025-04-14 19:24:56 --> Helper loaded: file_helper
INFO - 2025-04-14 19:24:56 --> Helper loaded: html_helper
INFO - 2025-04-14 19:24:56 --> Helper loaded: form_helper
INFO - 2025-04-14 19:24:56 --> Helper loaded: text_helper
INFO - 2025-04-14 19:24:56 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:24:56 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:24:56 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:24:56 --> Database Driver Class Initialized
INFO - 2025-04-14 19:24:56 --> Email Class Initialized
INFO - 2025-04-14 19:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:24:56 --> Form Validation Class Initialized
INFO - 2025-04-14 19:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:24:56 --> Pagination Class Initialized
INFO - 2025-04-14 19:24:56 --> Controller Class Initialized
DEBUG - 2025-04-14 19:24:56 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:25:13 --> Config Class Initialized
INFO - 2025-04-14 19:25:13 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:13 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:13 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:13 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:25:13 --> Router Class Initialized
INFO - 2025-04-14 19:25:13 --> Output Class Initialized
INFO - 2025-04-14 19:25:13 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:13 --> Input Class Initialized
INFO - 2025-04-14 19:25:13 --> Language Class Initialized
INFO - 2025-04-14 19:25:13 --> Language Class Initialized
INFO - 2025-04-14 19:25:13 --> Config Class Initialized
INFO - 2025-04-14 19:25:13 --> Loader Class Initialized
INFO - 2025-04-14 19:25:13 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:13 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:13 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:13 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:13 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:13 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:13 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:13 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:13 --> Email Class Initialized
INFO - 2025-04-14 19:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:13 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:13 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:13 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:13 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:25:13 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:25:13 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:25:13 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:25:13 --> Model Class Initialized
ERROR - 2025-04-14 19:25:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:25:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:25:13 --> Final output sent to browser
DEBUG - 2025-04-14 19:25:13 --> Total execution time: 0.0923
INFO - 2025-04-14 19:25:14 --> Config Class Initialized
INFO - 2025-04-14 19:25:14 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:14 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:14 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:14 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:25:14 --> Router Class Initialized
INFO - 2025-04-14 19:25:14 --> Output Class Initialized
INFO - 2025-04-14 19:25:14 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:14 --> Input Class Initialized
INFO - 2025-04-14 19:25:14 --> Language Class Initialized
INFO - 2025-04-14 19:25:14 --> Language Class Initialized
INFO - 2025-04-14 19:25:14 --> Config Class Initialized
INFO - 2025-04-14 19:25:14 --> Loader Class Initialized
INFO - 2025-04-14 19:25:14 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:14 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:14 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:14 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:14 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:14 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:14 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:14 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:14 --> Email Class Initialized
INFO - 2025-04-14 19:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:14 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:14 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:14 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:14 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:25:14 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:25:14 --> Model Class Initialized
INFO - 2025-04-14 19:25:14 --> Final output sent to browser
DEBUG - 2025-04-14 19:25:14 --> Total execution time: 0.0136
INFO - 2025-04-14 19:25:24 --> Config Class Initialized
INFO - 2025-04-14 19:25:24 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:24 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:24 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:24 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 19:25:24 --> Router Class Initialized
INFO - 2025-04-14 19:25:24 --> Output Class Initialized
INFO - 2025-04-14 19:25:24 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:24 --> Input Class Initialized
INFO - 2025-04-14 19:25:24 --> Language Class Initialized
INFO - 2025-04-14 19:25:24 --> Language Class Initialized
INFO - 2025-04-14 19:25:24 --> Config Class Initialized
INFO - 2025-04-14 19:25:24 --> Loader Class Initialized
INFO - 2025-04-14 19:25:24 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:24 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:24 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:24 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:24 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:24 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:24 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:24 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:24 --> Email Class Initialized
INFO - 2025-04-14 19:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:24 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:24 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:24 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:24 --> Returns MX_Controller Initialized
INFO - 2025-04-14 19:25:24 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 19:25:24 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 19:25:24 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:25:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:25:24 --> Model Class Initialized
ERROR - 2025-04-14 19:25:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:25:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:25:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:25:24 --> Final output sent to browser
DEBUG - 2025-04-14 19:25:24 --> Total execution time: 0.1113
INFO - 2025-04-14 19:25:31 --> Config Class Initialized
INFO - 2025-04-14 19:25:31 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:31 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:31 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:31 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 19:25:31 --> Router Class Initialized
INFO - 2025-04-14 19:25:31 --> Output Class Initialized
INFO - 2025-04-14 19:25:31 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:31 --> Input Class Initialized
INFO - 2025-04-14 19:25:31 --> Language Class Initialized
INFO - 2025-04-14 19:25:31 --> Language Class Initialized
INFO - 2025-04-14 19:25:31 --> Config Class Initialized
INFO - 2025-04-14 19:25:31 --> Loader Class Initialized
INFO - 2025-04-14 19:25:31 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:31 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:31 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:31 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:31 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:31 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:31 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:31 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:31 --> Email Class Initialized
INFO - 2025-04-14 19:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:31 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:31 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:31 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:31 --> Returns MX_Controller Initialized
INFO - 2025-04-14 19:25:31 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 19:25:31 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 19:25:31 --> Model Class Initialized
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:25:31 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:25:31 --> Model Class Initialized
ERROR - 2025-04-14 19:25:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:25:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:25:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:25:31 --> Final output sent to browser
DEBUG - 2025-04-14 19:25:31 --> Total execution time: 0.1511
INFO - 2025-04-14 19:25:44 --> Config Class Initialized
INFO - 2025-04-14 19:25:44 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:44 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:44 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:44 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:25:44 --> Router Class Initialized
INFO - 2025-04-14 19:25:44 --> Output Class Initialized
INFO - 2025-04-14 19:25:44 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:44 --> Input Class Initialized
INFO - 2025-04-14 19:25:44 --> Language Class Initialized
INFO - 2025-04-14 19:25:44 --> Language Class Initialized
INFO - 2025-04-14 19:25:44 --> Config Class Initialized
INFO - 2025-04-14 19:25:44 --> Loader Class Initialized
INFO - 2025-04-14 19:25:44 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:44 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:44 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:44 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:44 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:44 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:44 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:44 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:44 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:44 --> Email Class Initialized
INFO - 2025-04-14 19:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:44 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:44 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:44 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:44 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:25:46 --> Config Class Initialized
INFO - 2025-04-14 19:25:46 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:46 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:46 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:46 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:25:46 --> Router Class Initialized
INFO - 2025-04-14 19:25:46 --> Output Class Initialized
INFO - 2025-04-14 19:25:46 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:46 --> Input Class Initialized
INFO - 2025-04-14 19:25:46 --> Language Class Initialized
INFO - 2025-04-14 19:25:46 --> Language Class Initialized
INFO - 2025-04-14 19:25:46 --> Config Class Initialized
INFO - 2025-04-14 19:25:46 --> Loader Class Initialized
INFO - 2025-04-14 19:25:46 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:46 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:46 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:46 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:46 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:46 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:46 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:46 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:46 --> Email Class Initialized
INFO - 2025-04-14 19:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:46 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:46 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:46 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:25:49 --> Config Class Initialized
INFO - 2025-04-14 19:25:49 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:49 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:49 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:49 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:25:49 --> Router Class Initialized
INFO - 2025-04-14 19:25:49 --> Output Class Initialized
INFO - 2025-04-14 19:25:49 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:49 --> Input Class Initialized
INFO - 2025-04-14 19:25:49 --> Language Class Initialized
INFO - 2025-04-14 19:25:49 --> Language Class Initialized
INFO - 2025-04-14 19:25:49 --> Config Class Initialized
INFO - 2025-04-14 19:25:49 --> Loader Class Initialized
INFO - 2025-04-14 19:25:49 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:49 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:49 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:49 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:49 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:49 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:49 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:49 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:49 --> Email Class Initialized
INFO - 2025-04-14 19:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:49 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:49 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:49 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:49 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:25:52 --> Config Class Initialized
INFO - 2025-04-14 19:25:52 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:25:52 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:25:52 --> Utf8 Class Initialized
INFO - 2025-04-14 19:25:52 --> URI Class Initialized
DEBUG - 2025-04-14 19:25:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 19:25:52 --> Router Class Initialized
INFO - 2025-04-14 19:25:52 --> Output Class Initialized
INFO - 2025-04-14 19:25:52 --> Security Class Initialized
DEBUG - 2025-04-14 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:25:52 --> Input Class Initialized
INFO - 2025-04-14 19:25:52 --> Language Class Initialized
INFO - 2025-04-14 19:25:52 --> Language Class Initialized
INFO - 2025-04-14 19:25:52 --> Config Class Initialized
INFO - 2025-04-14 19:25:52 --> Loader Class Initialized
INFO - 2025-04-14 19:25:52 --> Helper loaded: url_helper
INFO - 2025-04-14 19:25:52 --> Helper loaded: file_helper
INFO - 2025-04-14 19:25:52 --> Helper loaded: html_helper
INFO - 2025-04-14 19:25:52 --> Helper loaded: form_helper
INFO - 2025-04-14 19:25:52 --> Helper loaded: text_helper
INFO - 2025-04-14 19:25:52 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:25:52 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:25:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:25:52 --> Database Driver Class Initialized
INFO - 2025-04-14 19:25:52 --> Email Class Initialized
INFO - 2025-04-14 19:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:25:52 --> Form Validation Class Initialized
INFO - 2025-04-14 19:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:25:52 --> Pagination Class Initialized
INFO - 2025-04-14 19:25:52 --> Controller Class Initialized
DEBUG - 2025-04-14 19:25:52 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 19:26:08 --> Config Class Initialized
INFO - 2025-04-14 19:26:08 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:26:08 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:26:08 --> Utf8 Class Initialized
INFO - 2025-04-14 19:26:08 --> URI Class Initialized
DEBUG - 2025-04-14 19:26:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 19:26:08 --> Router Class Initialized
INFO - 2025-04-14 19:26:08 --> Output Class Initialized
INFO - 2025-04-14 19:26:08 --> Security Class Initialized
DEBUG - 2025-04-14 19:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:26:08 --> Input Class Initialized
INFO - 2025-04-14 19:26:08 --> Language Class Initialized
INFO - 2025-04-14 19:26:08 --> Language Class Initialized
INFO - 2025-04-14 19:26:08 --> Config Class Initialized
INFO - 2025-04-14 19:26:08 --> Loader Class Initialized
INFO - 2025-04-14 19:26:08 --> Helper loaded: url_helper
INFO - 2025-04-14 19:26:08 --> Helper loaded: file_helper
INFO - 2025-04-14 19:26:08 --> Helper loaded: html_helper
INFO - 2025-04-14 19:26:08 --> Helper loaded: form_helper
INFO - 2025-04-14 19:26:08 --> Helper loaded: text_helper
INFO - 2025-04-14 19:26:08 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:26:08 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:26:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:26:08 --> Database Driver Class Initialized
INFO - 2025-04-14 19:26:08 --> Email Class Initialized
INFO - 2025-04-14 19:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:26:08 --> Form Validation Class Initialized
INFO - 2025-04-14 19:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:26:08 --> Pagination Class Initialized
INFO - 2025-04-14 19:26:08 --> Controller Class Initialized
DEBUG - 2025-04-14 19:26:08 --> Returns MX_Controller Initialized
INFO - 2025-04-14 19:26:08 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 19:26:08 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 19:26:08 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:08 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-14 19:26:08 --> ✅ Proceeding with return_invoice_entry()
DEBUG - 2025-04-14 19:26:08 --> 📦 return_invoice_entry() returned Invoice ID: 3192608204
DEBUG - 2025-04-14 19:26:08 --> 🔁 autoapprove() called for invoice_id: 3192608204
DEBUG - 2025-04-14 19:26:08 --> 🧾 Found 1 vouchers to approve
DEBUG - 2025-04-14 19:26:08 --> 📝 Approving voucher: CV-54
DEBUG - 2025-04-14 19:26:08 --> 📥 acc_transaction insert: {"vid":"181","fyear":"1","VNo":"CV-54","Vtype":"CV","referenceNo":"3192608204","VDate":"2025-04-14","COAID":"1020101","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-14 19:26:08"}
DEBUG - 2025-04-14 19:26:08 --> 📥 acc_transaction insert: {"vid":"181","fyear":"1","VNo":"CV-54","Vtype":"CV","referenceNo":"3192608204","VDate":"2025-04-14","COAID":"3010301","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-14 19:26:08"}
DEBUG - 2025-04-14 19:26:08 --> ✅ Voucher approved: CV-54 | Result: true
ERROR - 2025-04-14 19:26:08 --> Severity: error --> Exception: Table 'b2b.product_return_details' doesn't exist /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-04-14 19:26:19 --> Config Class Initialized
INFO - 2025-04-14 19:26:19 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:26:19 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:26:19 --> Utf8 Class Initialized
INFO - 2025-04-14 19:26:19 --> URI Class Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 19:26:19 --> Router Class Initialized
INFO - 2025-04-14 19:26:19 --> Output Class Initialized
INFO - 2025-04-14 19:26:19 --> Security Class Initialized
DEBUG - 2025-04-14 19:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:26:19 --> Input Class Initialized
INFO - 2025-04-14 19:26:19 --> Language Class Initialized
INFO - 2025-04-14 19:26:19 --> Language Class Initialized
INFO - 2025-04-14 19:26:19 --> Config Class Initialized
INFO - 2025-04-14 19:26:19 --> Loader Class Initialized
INFO - 2025-04-14 19:26:19 --> Helper loaded: url_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: file_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: html_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: form_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: text_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:26:19 --> Database Driver Class Initialized
INFO - 2025-04-14 19:26:19 --> Email Class Initialized
INFO - 2025-04-14 19:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:26:19 --> Form Validation Class Initialized
INFO - 2025-04-14 19:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:26:19 --> Pagination Class Initialized
INFO - 2025-04-14 19:26:19 --> Controller Class Initialized
DEBUG - 2025-04-14 19:26:19 --> Returns MX_Controller Initialized
INFO - 2025-04-14 19:26:19 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 19:26:19 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 19:26:19 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:19 --> 🔁 return_invoice() called | finyear: 
ERROR - 2025-04-14 19:26:19 --> ❌ Financial year missing or invalid.
INFO - 2025-04-14 19:26:19 --> Config Class Initialized
INFO - 2025-04-14 19:26:19 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:26:19 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:26:19 --> Utf8 Class Initialized
INFO - 2025-04-14 19:26:19 --> URI Class Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 19:26:19 --> Router Class Initialized
INFO - 2025-04-14 19:26:19 --> Output Class Initialized
INFO - 2025-04-14 19:26:19 --> Security Class Initialized
DEBUG - 2025-04-14 19:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:26:19 --> Input Class Initialized
INFO - 2025-04-14 19:26:19 --> Language Class Initialized
INFO - 2025-04-14 19:26:19 --> Language Class Initialized
INFO - 2025-04-14 19:26:19 --> Config Class Initialized
INFO - 2025-04-14 19:26:19 --> Loader Class Initialized
INFO - 2025-04-14 19:26:19 --> Helper loaded: url_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: file_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: html_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: form_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: text_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:26:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:26:19 --> Database Driver Class Initialized
INFO - 2025-04-14 19:26:19 --> Email Class Initialized
INFO - 2025-04-14 19:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:26:19 --> Form Validation Class Initialized
INFO - 2025-04-14 19:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:26:19 --> Pagination Class Initialized
INFO - 2025-04-14 19:26:19 --> Controller Class Initialized
DEBUG - 2025-04-14 19:26:19 --> Returns MX_Controller Initialized
INFO - 2025-04-14 19:26:19 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 19:26:19 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 19:26:19 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:26:19 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:26:19 --> Model Class Initialized
ERROR - 2025-04-14 19:26:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:26:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:26:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:26:19 --> Final output sent to browser
DEBUG - 2025-04-14 19:26:19 --> Total execution time: 0.0941
INFO - 2025-04-14 19:26:30 --> Config Class Initialized
INFO - 2025-04-14 19:26:30 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:26:30 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:26:30 --> Utf8 Class Initialized
INFO - 2025-04-14 19:26:30 --> URI Class Initialized
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 19:26:30 --> Router Class Initialized
INFO - 2025-04-14 19:26:30 --> Output Class Initialized
INFO - 2025-04-14 19:26:30 --> Security Class Initialized
DEBUG - 2025-04-14 19:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:26:30 --> Input Class Initialized
INFO - 2025-04-14 19:26:30 --> Language Class Initialized
INFO - 2025-04-14 19:26:30 --> Language Class Initialized
INFO - 2025-04-14 19:26:30 --> Config Class Initialized
INFO - 2025-04-14 19:26:30 --> Loader Class Initialized
INFO - 2025-04-14 19:26:30 --> Helper loaded: url_helper
INFO - 2025-04-14 19:26:30 --> Helper loaded: file_helper
INFO - 2025-04-14 19:26:30 --> Helper loaded: html_helper
INFO - 2025-04-14 19:26:30 --> Helper loaded: form_helper
INFO - 2025-04-14 19:26:30 --> Helper loaded: text_helper
INFO - 2025-04-14 19:26:30 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:26:30 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:26:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:26:30 --> Database Driver Class Initialized
INFO - 2025-04-14 19:26:30 --> Email Class Initialized
INFO - 2025-04-14 19:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:26:30 --> Form Validation Class Initialized
INFO - 2025-04-14 19:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:26:30 --> Pagination Class Initialized
INFO - 2025-04-14 19:26:30 --> Controller Class Initialized
DEBUG - 2025-04-14 19:26:30 --> Returns MX_Controller Initialized
INFO - 2025-04-14 19:26:30 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 19:26:30 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 19:26:30 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:26:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:26:30 --> Model Class Initialized
ERROR - 2025-04-14 19:26:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:26:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:26:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:26:30 --> Final output sent to browser
DEBUG - 2025-04-14 19:26:30 --> Total execution time: 0.1148
INFO - 2025-04-14 19:26:32 --> Config Class Initialized
INFO - 2025-04-14 19:26:32 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:26:32 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:26:32 --> Utf8 Class Initialized
INFO - 2025-04-14 19:26:32 --> URI Class Initialized
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 19:26:32 --> Router Class Initialized
INFO - 2025-04-14 19:26:32 --> Output Class Initialized
INFO - 2025-04-14 19:26:32 --> Security Class Initialized
DEBUG - 2025-04-14 19:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:26:32 --> Input Class Initialized
INFO - 2025-04-14 19:26:32 --> Language Class Initialized
INFO - 2025-04-14 19:26:32 --> Language Class Initialized
INFO - 2025-04-14 19:26:32 --> Config Class Initialized
INFO - 2025-04-14 19:26:32 --> Loader Class Initialized
INFO - 2025-04-14 19:26:32 --> Helper loaded: url_helper
INFO - 2025-04-14 19:26:32 --> Helper loaded: file_helper
INFO - 2025-04-14 19:26:32 --> Helper loaded: html_helper
INFO - 2025-04-14 19:26:32 --> Helper loaded: form_helper
INFO - 2025-04-14 19:26:32 --> Helper loaded: text_helper
INFO - 2025-04-14 19:26:32 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:26:32 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:26:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:26:32 --> Database Driver Class Initialized
INFO - 2025-04-14 19:26:32 --> Email Class Initialized
INFO - 2025-04-14 19:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:26:32 --> Form Validation Class Initialized
INFO - 2025-04-14 19:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:26:32 --> Pagination Class Initialized
INFO - 2025-04-14 19:26:32 --> Controller Class Initialized
DEBUG - 2025-04-14 19:26:32 --> Returns MX_Controller Initialized
INFO - 2025-04-14 19:26:32 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 19:26:32 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 19:26:32 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:26:32 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:26:32 --> Model Class Initialized
ERROR - 2025-04-14 19:26:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:26:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:26:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:26:32 --> Final output sent to browser
DEBUG - 2025-04-14 19:26:32 --> Total execution time: 0.1223
INFO - 2025-04-14 19:26:48 --> Config Class Initialized
INFO - 2025-04-14 19:26:48 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:26:48 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:26:48 --> Utf8 Class Initialized
INFO - 2025-04-14 19:26:48 --> URI Class Initialized
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:26:48 --> Router Class Initialized
INFO - 2025-04-14 19:26:48 --> Output Class Initialized
INFO - 2025-04-14 19:26:48 --> Security Class Initialized
DEBUG - 2025-04-14 19:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:26:48 --> Input Class Initialized
INFO - 2025-04-14 19:26:48 --> Language Class Initialized
INFO - 2025-04-14 19:26:48 --> Language Class Initialized
INFO - 2025-04-14 19:26:48 --> Config Class Initialized
INFO - 2025-04-14 19:26:48 --> Loader Class Initialized
INFO - 2025-04-14 19:26:48 --> Helper loaded: url_helper
INFO - 2025-04-14 19:26:48 --> Helper loaded: file_helper
INFO - 2025-04-14 19:26:48 --> Helper loaded: html_helper
INFO - 2025-04-14 19:26:48 --> Helper loaded: form_helper
INFO - 2025-04-14 19:26:48 --> Helper loaded: text_helper
INFO - 2025-04-14 19:26:48 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:26:48 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:26:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:26:48 --> Database Driver Class Initialized
INFO - 2025-04-14 19:26:48 --> Email Class Initialized
INFO - 2025-04-14 19:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:26:48 --> Form Validation Class Initialized
INFO - 2025-04-14 19:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:26:48 --> Pagination Class Initialized
INFO - 2025-04-14 19:26:48 --> Controller Class Initialized
DEBUG - 2025-04-14 19:26:48 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:26:48 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:26:48 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:26:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:26:48 --> Model Class Initialized
ERROR - 2025-04-14 19:26:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:26:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:26:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 19:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:26:49 --> Final output sent to browser
DEBUG - 2025-04-14 19:26:49 --> Total execution time: 0.1176
INFO - 2025-04-14 19:26:49 --> Config Class Initialized
INFO - 2025-04-14 19:26:49 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:26:49 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:26:49 --> Utf8 Class Initialized
INFO - 2025-04-14 19:26:49 --> URI Class Initialized
DEBUG - 2025-04-14 19:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:26:49 --> Router Class Initialized
INFO - 2025-04-14 19:26:49 --> Output Class Initialized
INFO - 2025-04-14 19:26:49 --> Security Class Initialized
DEBUG - 2025-04-14 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:26:49 --> Input Class Initialized
INFO - 2025-04-14 19:26:49 --> Language Class Initialized
INFO - 2025-04-14 19:26:49 --> Language Class Initialized
INFO - 2025-04-14 19:26:49 --> Config Class Initialized
INFO - 2025-04-14 19:26:49 --> Loader Class Initialized
INFO - 2025-04-14 19:26:49 --> Helper loaded: url_helper
INFO - 2025-04-14 19:26:49 --> Helper loaded: file_helper
INFO - 2025-04-14 19:26:49 --> Helper loaded: html_helper
INFO - 2025-04-14 19:26:49 --> Helper loaded: form_helper
INFO - 2025-04-14 19:26:49 --> Helper loaded: text_helper
INFO - 2025-04-14 19:26:49 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:26:49 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:26:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:26:49 --> Database Driver Class Initialized
INFO - 2025-04-14 19:26:49 --> Email Class Initialized
INFO - 2025-04-14 19:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:26:49 --> Form Validation Class Initialized
INFO - 2025-04-14 19:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:26:49 --> Pagination Class Initialized
INFO - 2025-04-14 19:26:49 --> Controller Class Initialized
DEBUG - 2025-04-14 19:26:49 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:26:49 --> Model Class Initialized
DEBUG - 2025-04-14 19:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:26:49 --> Model Class Initialized
INFO - 2025-04-14 19:26:49 --> Final output sent to browser
DEBUG - 2025-04-14 19:26:49 --> Total execution time: 0.0118
INFO - 2025-04-14 19:41:07 --> Config Class Initialized
INFO - 2025-04-14 19:41:07 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:41:07 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:41:07 --> Utf8 Class Initialized
INFO - 2025-04-14 19:41:07 --> URI Class Initialized
DEBUG - 2025-04-14 19:41:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:41:07 --> Router Class Initialized
INFO - 2025-04-14 19:41:07 --> Output Class Initialized
INFO - 2025-04-14 19:41:07 --> Security Class Initialized
DEBUG - 2025-04-14 19:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:41:07 --> Input Class Initialized
INFO - 2025-04-14 19:41:07 --> Language Class Initialized
INFO - 2025-04-14 19:41:07 --> Language Class Initialized
INFO - 2025-04-14 19:41:07 --> Config Class Initialized
INFO - 2025-04-14 19:41:07 --> Loader Class Initialized
INFO - 2025-04-14 19:41:07 --> Helper loaded: url_helper
INFO - 2025-04-14 19:41:07 --> Helper loaded: file_helper
INFO - 2025-04-14 19:41:07 --> Helper loaded: html_helper
INFO - 2025-04-14 19:41:07 --> Helper loaded: form_helper
INFO - 2025-04-14 19:41:07 --> Helper loaded: text_helper
INFO - 2025-04-14 19:41:07 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:41:07 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:41:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:41:07 --> Database Driver Class Initialized
INFO - 2025-04-14 19:41:07 --> Email Class Initialized
INFO - 2025-04-14 19:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:41:07 --> Form Validation Class Initialized
INFO - 2025-04-14 19:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:41:07 --> Pagination Class Initialized
INFO - 2025-04-14 19:41:07 --> Controller Class Initialized
DEBUG - 2025-04-14 19:41:07 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:41:07 --> Model Class Initialized
DEBUG - 2025-04-14 19:41:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:41:07 --> Model Class Initialized
DEBUG - 2025-04-14 19:41:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:41:07 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:41:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:41:07 --> Model Class Initialized
ERROR - 2025-04-14 19:41:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:41:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:41:08 --> Final output sent to browser
DEBUG - 2025-04-14 19:41:08 --> Total execution time: 0.3709
INFO - 2025-04-14 19:41:08 --> Config Class Initialized
INFO - 2025-04-14 19:41:08 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:41:08 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:41:08 --> Utf8 Class Initialized
INFO - 2025-04-14 19:41:08 --> URI Class Initialized
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:41:08 --> Router Class Initialized
INFO - 2025-04-14 19:41:08 --> Output Class Initialized
INFO - 2025-04-14 19:41:08 --> Security Class Initialized
DEBUG - 2025-04-14 19:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:41:08 --> Input Class Initialized
INFO - 2025-04-14 19:41:08 --> Language Class Initialized
INFO - 2025-04-14 19:41:08 --> Language Class Initialized
INFO - 2025-04-14 19:41:08 --> Config Class Initialized
INFO - 2025-04-14 19:41:08 --> Loader Class Initialized
INFO - 2025-04-14 19:41:08 --> Helper loaded: url_helper
INFO - 2025-04-14 19:41:08 --> Helper loaded: file_helper
INFO - 2025-04-14 19:41:08 --> Helper loaded: html_helper
INFO - 2025-04-14 19:41:08 --> Helper loaded: form_helper
INFO - 2025-04-14 19:41:08 --> Helper loaded: text_helper
INFO - 2025-04-14 19:41:08 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:41:08 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:41:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:41:08 --> Database Driver Class Initialized
INFO - 2025-04-14 19:41:08 --> Email Class Initialized
INFO - 2025-04-14 19:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:41:08 --> Form Validation Class Initialized
INFO - 2025-04-14 19:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:41:08 --> Pagination Class Initialized
INFO - 2025-04-14 19:41:08 --> Controller Class Initialized
DEBUG - 2025-04-14 19:41:08 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:41:08 --> Model Class Initialized
DEBUG - 2025-04-14 19:41:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:41:08 --> Model Class Initialized
INFO - 2025-04-14 19:41:08 --> Final output sent to browser
DEBUG - 2025-04-14 19:41:08 --> Total execution time: 0.0169
INFO - 2025-04-14 19:45:18 --> Config Class Initialized
INFO - 2025-04-14 19:45:18 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:45:18 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:45:18 --> Utf8 Class Initialized
INFO - 2025-04-14 19:45:18 --> URI Class Initialized
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:45:18 --> Router Class Initialized
INFO - 2025-04-14 19:45:18 --> Output Class Initialized
INFO - 2025-04-14 19:45:18 --> Security Class Initialized
DEBUG - 2025-04-14 19:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:45:18 --> Input Class Initialized
INFO - 2025-04-14 19:45:18 --> Language Class Initialized
INFO - 2025-04-14 19:45:18 --> Language Class Initialized
INFO - 2025-04-14 19:45:18 --> Config Class Initialized
INFO - 2025-04-14 19:45:18 --> Loader Class Initialized
INFO - 2025-04-14 19:45:18 --> Helper loaded: url_helper
INFO - 2025-04-14 19:45:18 --> Helper loaded: file_helper
INFO - 2025-04-14 19:45:18 --> Helper loaded: html_helper
INFO - 2025-04-14 19:45:18 --> Helper loaded: form_helper
INFO - 2025-04-14 19:45:18 --> Helper loaded: text_helper
INFO - 2025-04-14 19:45:18 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:45:18 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:45:18 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:45:18 --> Database Driver Class Initialized
INFO - 2025-04-14 19:45:18 --> Email Class Initialized
INFO - 2025-04-14 19:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:45:18 --> Form Validation Class Initialized
INFO - 2025-04-14 19:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:45:18 --> Pagination Class Initialized
INFO - 2025-04-14 19:45:18 --> Controller Class Initialized
DEBUG - 2025-04-14 19:45:18 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:45:18 --> Model Class Initialized
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:45:18 --> Model Class Initialized
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:45:18 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:45:18 --> Model Class Initialized
ERROR - 2025-04-14 19:45:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:45:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_return.php
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:45:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:45:18 --> Final output sent to browser
DEBUG - 2025-04-14 19:45:18 --> Total execution time: 0.1284
INFO - 2025-04-14 19:45:23 --> Config Class Initialized
INFO - 2025-04-14 19:45:23 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:45:23 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:45:23 --> Utf8 Class Initialized
INFO - 2025-04-14 19:45:23 --> URI Class Initialized
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:45:23 --> Router Class Initialized
INFO - 2025-04-14 19:45:23 --> Output Class Initialized
INFO - 2025-04-14 19:45:23 --> Security Class Initialized
DEBUG - 2025-04-14 19:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:45:23 --> Input Class Initialized
INFO - 2025-04-14 19:45:23 --> Language Class Initialized
INFO - 2025-04-14 19:45:23 --> Language Class Initialized
INFO - 2025-04-14 19:45:23 --> Config Class Initialized
INFO - 2025-04-14 19:45:23 --> Loader Class Initialized
INFO - 2025-04-14 19:45:23 --> Helper loaded: url_helper
INFO - 2025-04-14 19:45:23 --> Helper loaded: file_helper
INFO - 2025-04-14 19:45:23 --> Helper loaded: html_helper
INFO - 2025-04-14 19:45:23 --> Helper loaded: form_helper
INFO - 2025-04-14 19:45:23 --> Helper loaded: text_helper
INFO - 2025-04-14 19:45:23 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:45:23 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:45:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:45:23 --> Database Driver Class Initialized
INFO - 2025-04-14 19:45:23 --> Email Class Initialized
INFO - 2025-04-14 19:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:45:23 --> Form Validation Class Initialized
INFO - 2025-04-14 19:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:45:23 --> Pagination Class Initialized
INFO - 2025-04-14 19:45:23 --> Controller Class Initialized
DEBUG - 2025-04-14 19:45:23 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:45:23 --> Model Class Initialized
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:45:23 --> Model Class Initialized
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:45:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:45:23 --> Model Class Initialized
ERROR - 2025-04-14 19:45:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:45:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_return.php
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:45:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:45:23 --> Final output sent to browser
DEBUG - 2025-04-14 19:45:23 --> Total execution time: 0.1241
INFO - 2025-04-14 19:45:48 --> Config Class Initialized
INFO - 2025-04-14 19:45:48 --> Hooks Class Initialized
DEBUG - 2025-04-14 19:45:48 --> UTF-8 Support Enabled
INFO - 2025-04-14 19:45:48 --> Utf8 Class Initialized
INFO - 2025-04-14 19:45:48 --> URI Class Initialized
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 19:45:48 --> Router Class Initialized
INFO - 2025-04-14 19:45:48 --> Output Class Initialized
INFO - 2025-04-14 19:45:48 --> Security Class Initialized
DEBUG - 2025-04-14 19:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 19:45:48 --> Input Class Initialized
INFO - 2025-04-14 19:45:48 --> Language Class Initialized
INFO - 2025-04-14 19:45:48 --> Language Class Initialized
INFO - 2025-04-14 19:45:48 --> Config Class Initialized
INFO - 2025-04-14 19:45:48 --> Loader Class Initialized
INFO - 2025-04-14 19:45:48 --> Helper loaded: url_helper
INFO - 2025-04-14 19:45:48 --> Helper loaded: file_helper
INFO - 2025-04-14 19:45:48 --> Helper loaded: html_helper
INFO - 2025-04-14 19:45:48 --> Helper loaded: form_helper
INFO - 2025-04-14 19:45:48 --> Helper loaded: text_helper
INFO - 2025-04-14 19:45:48 --> Helper loaded: lang_helper
INFO - 2025-04-14 19:45:48 --> Helper loaded: directory_helper
INFO - 2025-04-14 19:45:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 19:45:48 --> Database Driver Class Initialized
INFO - 2025-04-14 19:45:48 --> Email Class Initialized
INFO - 2025-04-14 19:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 19:45:48 --> Form Validation Class Initialized
INFO - 2025-04-14 19:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 19:45:48 --> Pagination Class Initialized
INFO - 2025-04-14 19:45:48 --> Controller Class Initialized
DEBUG - 2025-04-14 19:45:48 --> Report MX_Controller Initialized
INFO - 2025-04-14 19:45:48 --> Model Class Initialized
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 19:45:48 --> Model Class Initialized
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 19:45:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 19:45:48 --> Model Class Initialized
ERROR - 2025-04-14 19:45:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 19:45:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/supplier_return.php
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 19:45:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 19:45:48 --> Final output sent to browser
DEBUG - 2025-04-14 19:45:48 --> Total execution time: 0.0825
INFO - 2025-04-14 20:14:43 --> Config Class Initialized
INFO - 2025-04-14 20:14:43 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:43 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:43 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:43 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-14 20:14:43 --> Router Class Initialized
INFO - 2025-04-14 20:14:43 --> Output Class Initialized
INFO - 2025-04-14 20:14:43 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:43 --> Input Class Initialized
INFO - 2025-04-14 20:14:43 --> Language Class Initialized
INFO - 2025-04-14 20:14:43 --> Language Class Initialized
INFO - 2025-04-14 20:14:43 --> Config Class Initialized
INFO - 2025-04-14 20:14:43 --> Loader Class Initialized
INFO - 2025-04-14 20:14:43 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:43 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:43 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:43 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:43 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:43 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:43 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:43 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:43 --> Email Class Initialized
INFO - 2025-04-14 20:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:43 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:43 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:43 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:43 --> Home MX_Controller Initialized
INFO - 2025-04-14 20:14:43 --> Model Class Initialized
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-14 20:14:43 --> Model Class Initialized
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:14:43 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:14:43 --> Model Class Initialized
ERROR - 2025-04-14 20:14:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:14:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:14:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:14:43 --> Final output sent to browser
DEBUG - 2025-04-14 20:14:43 --> Total execution time: 0.4164
INFO - 2025-04-14 20:14:47 --> Config Class Initialized
INFO - 2025-04-14 20:14:47 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:47 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:47 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:47 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:47 --> Router Class Initialized
INFO - 2025-04-14 20:14:47 --> Output Class Initialized
INFO - 2025-04-14 20:14:47 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:47 --> Input Class Initialized
INFO - 2025-04-14 20:14:47 --> Language Class Initialized
INFO - 2025-04-14 20:14:47 --> Language Class Initialized
INFO - 2025-04-14 20:14:47 --> Config Class Initialized
INFO - 2025-04-14 20:14:47 --> Loader Class Initialized
INFO - 2025-04-14 20:14:47 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:47 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:47 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:47 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:47 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:47 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:47 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:47 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:47 --> Email Class Initialized
INFO - 2025-04-14 20:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:47 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:47 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:47 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:14:48 --> Config Class Initialized
INFO - 2025-04-14 20:14:48 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:48 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:48 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:48 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:48 --> Router Class Initialized
INFO - 2025-04-14 20:14:48 --> Output Class Initialized
INFO - 2025-04-14 20:14:48 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:48 --> Input Class Initialized
INFO - 2025-04-14 20:14:48 --> Language Class Initialized
INFO - 2025-04-14 20:14:48 --> Language Class Initialized
INFO - 2025-04-14 20:14:48 --> Config Class Initialized
INFO - 2025-04-14 20:14:48 --> Loader Class Initialized
INFO - 2025-04-14 20:14:48 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:48 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:48 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:48 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:48 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:48 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:48 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:48 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:48 --> Email Class Initialized
INFO - 2025-04-14 20:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:48 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:48 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:48 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:48 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:14:53 --> Config Class Initialized
INFO - 2025-04-14 20:14:53 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:53 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:53 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:53 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:53 --> Router Class Initialized
INFO - 2025-04-14 20:14:53 --> Output Class Initialized
INFO - 2025-04-14 20:14:53 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:53 --> Input Class Initialized
INFO - 2025-04-14 20:14:53 --> Language Class Initialized
INFO - 2025-04-14 20:14:53 --> Language Class Initialized
INFO - 2025-04-14 20:14:53 --> Config Class Initialized
INFO - 2025-04-14 20:14:53 --> Loader Class Initialized
INFO - 2025-04-14 20:14:53 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:53 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:53 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:53 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:53 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:53 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:53 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:53 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:53 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:53 --> Email Class Initialized
INFO - 2025-04-14 20:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:53 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:53 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:53 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:53 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:14:55 --> Config Class Initialized
INFO - 2025-04-14 20:14:55 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:55 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:55 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:55 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:55 --> Router Class Initialized
INFO - 2025-04-14 20:14:55 --> Output Class Initialized
INFO - 2025-04-14 20:14:55 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:55 --> Input Class Initialized
INFO - 2025-04-14 20:14:55 --> Language Class Initialized
INFO - 2025-04-14 20:14:55 --> Language Class Initialized
INFO - 2025-04-14 20:14:55 --> Config Class Initialized
INFO - 2025-04-14 20:14:55 --> Loader Class Initialized
INFO - 2025-04-14 20:14:55 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:55 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:55 --> Email Class Initialized
INFO - 2025-04-14 20:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:55 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:55 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:55 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:14:55 --> Config Class Initialized
INFO - 2025-04-14 20:14:55 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:55 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:55 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:55 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:55 --> Router Class Initialized
INFO - 2025-04-14 20:14:55 --> Output Class Initialized
INFO - 2025-04-14 20:14:55 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:55 --> Input Class Initialized
INFO - 2025-04-14 20:14:55 --> Language Class Initialized
INFO - 2025-04-14 20:14:55 --> Language Class Initialized
INFO - 2025-04-14 20:14:55 --> Config Class Initialized
INFO - 2025-04-14 20:14:55 --> Loader Class Initialized
INFO - 2025-04-14 20:14:55 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:55 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:55 --> Email Class Initialized
INFO - 2025-04-14 20:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:55 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:55 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:55 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:14:57 --> Config Class Initialized
INFO - 2025-04-14 20:14:57 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:57 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:57 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:57 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:57 --> Router Class Initialized
INFO - 2025-04-14 20:14:57 --> Output Class Initialized
INFO - 2025-04-14 20:14:57 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:57 --> Input Class Initialized
INFO - 2025-04-14 20:14:57 --> Language Class Initialized
INFO - 2025-04-14 20:14:57 --> Language Class Initialized
INFO - 2025-04-14 20:14:57 --> Config Class Initialized
INFO - 2025-04-14 20:14:57 --> Loader Class Initialized
INFO - 2025-04-14 20:14:57 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:57 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:57 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:57 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:57 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:57 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:57 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:57 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:57 --> Email Class Initialized
INFO - 2025-04-14 20:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:57 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:57 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:57 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:57 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:14:58 --> Config Class Initialized
INFO - 2025-04-14 20:14:58 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:58 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:58 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:58 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:58 --> Router Class Initialized
INFO - 2025-04-14 20:14:58 --> Output Class Initialized
INFO - 2025-04-14 20:14:58 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:58 --> Input Class Initialized
INFO - 2025-04-14 20:14:58 --> Language Class Initialized
INFO - 2025-04-14 20:14:58 --> Language Class Initialized
INFO - 2025-04-14 20:14:58 --> Config Class Initialized
INFO - 2025-04-14 20:14:58 --> Loader Class Initialized
INFO - 2025-04-14 20:14:58 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:58 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:58 --> Email Class Initialized
INFO - 2025-04-14 20:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:58 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:58 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:58 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:14:58 --> Config Class Initialized
INFO - 2025-04-14 20:14:58 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:14:58 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:14:58 --> Utf8 Class Initialized
INFO - 2025-04-14 20:14:58 --> URI Class Initialized
DEBUG - 2025-04-14 20:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:14:58 --> Router Class Initialized
INFO - 2025-04-14 20:14:58 --> Output Class Initialized
INFO - 2025-04-14 20:14:58 --> Security Class Initialized
DEBUG - 2025-04-14 20:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:14:58 --> Input Class Initialized
INFO - 2025-04-14 20:14:58 --> Language Class Initialized
INFO - 2025-04-14 20:14:58 --> Language Class Initialized
INFO - 2025-04-14 20:14:58 --> Config Class Initialized
INFO - 2025-04-14 20:14:58 --> Loader Class Initialized
INFO - 2025-04-14 20:14:58 --> Helper loaded: url_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: file_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: html_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: form_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: text_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:14:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:14:58 --> Database Driver Class Initialized
INFO - 2025-04-14 20:14:58 --> Email Class Initialized
INFO - 2025-04-14 20:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:14:58 --> Form Validation Class Initialized
INFO - 2025-04-14 20:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:14:58 --> Pagination Class Initialized
INFO - 2025-04-14 20:14:58 --> Controller Class Initialized
DEBUG - 2025-04-14 20:14:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:15:00 --> Config Class Initialized
INFO - 2025-04-14 20:15:00 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:15:00 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:15:00 --> Utf8 Class Initialized
INFO - 2025-04-14 20:15:00 --> URI Class Initialized
DEBUG - 2025-04-14 20:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:15:00 --> Router Class Initialized
INFO - 2025-04-14 20:15:00 --> Output Class Initialized
INFO - 2025-04-14 20:15:00 --> Security Class Initialized
DEBUG - 2025-04-14 20:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:15:00 --> Input Class Initialized
INFO - 2025-04-14 20:15:00 --> Language Class Initialized
INFO - 2025-04-14 20:15:00 --> Language Class Initialized
INFO - 2025-04-14 20:15:00 --> Config Class Initialized
INFO - 2025-04-14 20:15:00 --> Loader Class Initialized
INFO - 2025-04-14 20:15:00 --> Helper loaded: url_helper
INFO - 2025-04-14 20:15:00 --> Helper loaded: file_helper
INFO - 2025-04-14 20:15:00 --> Helper loaded: html_helper
INFO - 2025-04-14 20:15:00 --> Helper loaded: form_helper
INFO - 2025-04-14 20:15:00 --> Helper loaded: text_helper
INFO - 2025-04-14 20:15:00 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:15:00 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:15:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:15:00 --> Database Driver Class Initialized
INFO - 2025-04-14 20:15:00 --> Email Class Initialized
INFO - 2025-04-14 20:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:15:00 --> Form Validation Class Initialized
INFO - 2025-04-14 20:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:15:00 --> Pagination Class Initialized
INFO - 2025-04-14 20:15:00 --> Controller Class Initialized
DEBUG - 2025-04-14 20:15:00 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:15:20 --> Config Class Initialized
INFO - 2025-04-14 20:15:20 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:15:20 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:15:20 --> Utf8 Class Initialized
INFO - 2025-04-14 20:15:20 --> URI Class Initialized
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:15:20 --> Router Class Initialized
INFO - 2025-04-14 20:15:20 --> Output Class Initialized
INFO - 2025-04-14 20:15:20 --> Security Class Initialized
DEBUG - 2025-04-14 20:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:15:20 --> Input Class Initialized
INFO - 2025-04-14 20:15:20 --> Language Class Initialized
INFO - 2025-04-14 20:15:20 --> Language Class Initialized
INFO - 2025-04-14 20:15:20 --> Config Class Initialized
INFO - 2025-04-14 20:15:20 --> Loader Class Initialized
INFO - 2025-04-14 20:15:20 --> Helper loaded: url_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: file_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: html_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: form_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: text_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:15:20 --> Database Driver Class Initialized
INFO - 2025-04-14 20:15:20 --> Email Class Initialized
INFO - 2025-04-14 20:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:15:20 --> Form Validation Class Initialized
INFO - 2025-04-14 20:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:15:20 --> Pagination Class Initialized
INFO - 2025-04-14 20:15:20 --> Controller Class Initialized
DEBUG - 2025-04-14 20:15:20 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:15:20 --> Model Class Initialized
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:15:20 --> Model Class Initialized
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:15:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:15:20 --> Model Class Initialized
ERROR - 2025-04-14 20:15:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:15:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:15:20 --> Final output sent to browser
DEBUG - 2025-04-14 20:15:20 --> Total execution time: 0.0887
INFO - 2025-04-14 20:15:20 --> Config Class Initialized
INFO - 2025-04-14 20:15:20 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:15:20 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:15:20 --> Utf8 Class Initialized
INFO - 2025-04-14 20:15:20 --> URI Class Initialized
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:15:20 --> Router Class Initialized
INFO - 2025-04-14 20:15:20 --> Output Class Initialized
INFO - 2025-04-14 20:15:20 --> Security Class Initialized
DEBUG - 2025-04-14 20:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:15:20 --> Input Class Initialized
INFO - 2025-04-14 20:15:20 --> Language Class Initialized
INFO - 2025-04-14 20:15:20 --> Language Class Initialized
INFO - 2025-04-14 20:15:20 --> Config Class Initialized
INFO - 2025-04-14 20:15:20 --> Loader Class Initialized
INFO - 2025-04-14 20:15:20 --> Helper loaded: url_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: file_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: html_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: form_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: text_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:15:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:15:20 --> Database Driver Class Initialized
INFO - 2025-04-14 20:15:20 --> Email Class Initialized
INFO - 2025-04-14 20:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:15:20 --> Form Validation Class Initialized
INFO - 2025-04-14 20:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:15:20 --> Pagination Class Initialized
INFO - 2025-04-14 20:15:20 --> Controller Class Initialized
DEBUG - 2025-04-14 20:15:20 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:15:20 --> Model Class Initialized
DEBUG - 2025-04-14 20:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:15:20 --> Model Class Initialized
INFO - 2025-04-14 20:15:20 --> Final output sent to browser
DEBUG - 2025-04-14 20:15:20 --> Total execution time: 0.0092
INFO - 2025-04-14 20:16:06 --> Config Class Initialized
INFO - 2025-04-14 20:16:06 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:16:06 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:16:06 --> Utf8 Class Initialized
INFO - 2025-04-14 20:16:06 --> URI Class Initialized
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-14 20:16:06 --> No URI present. Default controller set.
INFO - 2025-04-14 20:16:06 --> Router Class Initialized
INFO - 2025-04-14 20:16:06 --> Output Class Initialized
INFO - 2025-04-14 20:16:06 --> Security Class Initialized
DEBUG - 2025-04-14 20:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:16:06 --> Input Class Initialized
INFO - 2025-04-14 20:16:06 --> Language Class Initialized
INFO - 2025-04-14 20:16:06 --> Language Class Initialized
INFO - 2025-04-14 20:16:06 --> Config Class Initialized
INFO - 2025-04-14 20:16:06 --> Loader Class Initialized
INFO - 2025-04-14 20:16:06 --> Helper loaded: url_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: file_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: html_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: form_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: text_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:16:06 --> Database Driver Class Initialized
INFO - 2025-04-14 20:16:06 --> Email Class Initialized
INFO - 2025-04-14 20:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:16:06 --> Form Validation Class Initialized
INFO - 2025-04-14 20:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:16:06 --> Pagination Class Initialized
INFO - 2025-04-14 20:16:06 --> Controller Class Initialized
DEBUG - 2025-04-14 20:16:06 --> Auth MX_Controller Initialized
INFO - 2025-04-14 20:16:06 --> Model Class Initialized
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-14 20:16:06 --> Model Class Initialized
INFO - 2025-04-14 20:16:06 --> Config Class Initialized
INFO - 2025-04-14 20:16:06 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:16:06 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:16:06 --> Utf8 Class Initialized
INFO - 2025-04-14 20:16:06 --> URI Class Initialized
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-14 20:16:06 --> Router Class Initialized
INFO - 2025-04-14 20:16:06 --> Output Class Initialized
INFO - 2025-04-14 20:16:06 --> Security Class Initialized
DEBUG - 2025-04-14 20:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:16:06 --> Input Class Initialized
INFO - 2025-04-14 20:16:06 --> Language Class Initialized
INFO - 2025-04-14 20:16:06 --> Language Class Initialized
INFO - 2025-04-14 20:16:06 --> Config Class Initialized
INFO - 2025-04-14 20:16:06 --> Loader Class Initialized
INFO - 2025-04-14 20:16:06 --> Helper loaded: url_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: file_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: html_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: form_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: text_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:16:06 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:16:06 --> Database Driver Class Initialized
INFO - 2025-04-14 20:16:06 --> Email Class Initialized
INFO - 2025-04-14 20:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:16:06 --> Form Validation Class Initialized
INFO - 2025-04-14 20:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:16:06 --> Pagination Class Initialized
INFO - 2025-04-14 20:16:06 --> Controller Class Initialized
DEBUG - 2025-04-14 20:16:06 --> Home MX_Controller Initialized
INFO - 2025-04-14 20:16:06 --> Model Class Initialized
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-14 20:16:06 --> Model Class Initialized
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:16:06 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:16:06 --> Model Class Initialized
ERROR - 2025-04-14 20:16:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:16:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:16:06 --> Final output sent to browser
DEBUG - 2025-04-14 20:16:06 --> Total execution time: 0.1607
INFO - 2025-04-14 20:16:13 --> Config Class Initialized
INFO - 2025-04-14 20:16:13 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:16:13 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:16:13 --> Utf8 Class Initialized
INFO - 2025-04-14 20:16:13 --> URI Class Initialized
DEBUG - 2025-04-14 20:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:16:13 --> Router Class Initialized
INFO - 2025-04-14 20:16:13 --> Output Class Initialized
INFO - 2025-04-14 20:16:13 --> Security Class Initialized
DEBUG - 2025-04-14 20:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:16:13 --> Input Class Initialized
INFO - 2025-04-14 20:16:13 --> Language Class Initialized
INFO - 2025-04-14 20:16:13 --> Language Class Initialized
INFO - 2025-04-14 20:16:13 --> Config Class Initialized
INFO - 2025-04-14 20:16:13 --> Loader Class Initialized
INFO - 2025-04-14 20:16:13 --> Helper loaded: url_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: file_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: html_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: form_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: text_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:16:13 --> Database Driver Class Initialized
INFO - 2025-04-14 20:16:13 --> Email Class Initialized
INFO - 2025-04-14 20:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:16:13 --> Form Validation Class Initialized
INFO - 2025-04-14 20:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:16:13 --> Pagination Class Initialized
INFO - 2025-04-14 20:16:13 --> Controller Class Initialized
DEBUG - 2025-04-14 20:16:13 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:16:13 --> Config Class Initialized
INFO - 2025-04-14 20:16:13 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:16:13 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:16:13 --> Utf8 Class Initialized
INFO - 2025-04-14 20:16:13 --> URI Class Initialized
DEBUG - 2025-04-14 20:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:16:13 --> Router Class Initialized
INFO - 2025-04-14 20:16:13 --> Output Class Initialized
INFO - 2025-04-14 20:16:13 --> Security Class Initialized
DEBUG - 2025-04-14 20:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:16:13 --> Input Class Initialized
INFO - 2025-04-14 20:16:13 --> Language Class Initialized
INFO - 2025-04-14 20:16:13 --> Language Class Initialized
INFO - 2025-04-14 20:16:13 --> Config Class Initialized
INFO - 2025-04-14 20:16:13 --> Loader Class Initialized
INFO - 2025-04-14 20:16:13 --> Helper loaded: url_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: file_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: html_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: form_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: text_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:16:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:16:13 --> Database Driver Class Initialized
INFO - 2025-04-14 20:16:13 --> Email Class Initialized
INFO - 2025-04-14 20:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:16:13 --> Form Validation Class Initialized
INFO - 2025-04-14 20:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:16:13 --> Pagination Class Initialized
INFO - 2025-04-14 20:16:13 --> Controller Class Initialized
DEBUG - 2025-04-14 20:16:13 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:16:15 --> Config Class Initialized
INFO - 2025-04-14 20:16:15 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:16:15 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:16:15 --> Utf8 Class Initialized
INFO - 2025-04-14 20:16:15 --> URI Class Initialized
DEBUG - 2025-04-14 20:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:16:15 --> Router Class Initialized
INFO - 2025-04-14 20:16:15 --> Output Class Initialized
INFO - 2025-04-14 20:16:15 --> Security Class Initialized
DEBUG - 2025-04-14 20:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:16:15 --> Input Class Initialized
INFO - 2025-04-14 20:16:15 --> Language Class Initialized
INFO - 2025-04-14 20:16:15 --> Language Class Initialized
INFO - 2025-04-14 20:16:15 --> Config Class Initialized
INFO - 2025-04-14 20:16:15 --> Loader Class Initialized
INFO - 2025-04-14 20:16:15 --> Helper loaded: url_helper
INFO - 2025-04-14 20:16:15 --> Helper loaded: file_helper
INFO - 2025-04-14 20:16:15 --> Helper loaded: html_helper
INFO - 2025-04-14 20:16:15 --> Helper loaded: form_helper
INFO - 2025-04-14 20:16:15 --> Helper loaded: text_helper
INFO - 2025-04-14 20:16:15 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:16:15 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:16:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:16:15 --> Database Driver Class Initialized
INFO - 2025-04-14 20:16:15 --> Email Class Initialized
INFO - 2025-04-14 20:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:16:15 --> Form Validation Class Initialized
INFO - 2025-04-14 20:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:16:15 --> Pagination Class Initialized
INFO - 2025-04-14 20:16:15 --> Controller Class Initialized
DEBUG - 2025-04-14 20:16:15 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:16:23 --> Config Class Initialized
INFO - 2025-04-14 20:16:23 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:16:23 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:16:23 --> Utf8 Class Initialized
INFO - 2025-04-14 20:16:23 --> URI Class Initialized
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:16:23 --> Router Class Initialized
INFO - 2025-04-14 20:16:23 --> Output Class Initialized
INFO - 2025-04-14 20:16:23 --> Security Class Initialized
DEBUG - 2025-04-14 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:16:23 --> Input Class Initialized
INFO - 2025-04-14 20:16:23 --> Language Class Initialized
INFO - 2025-04-14 20:16:23 --> Language Class Initialized
INFO - 2025-04-14 20:16:23 --> Config Class Initialized
INFO - 2025-04-14 20:16:23 --> Loader Class Initialized
INFO - 2025-04-14 20:16:23 --> Helper loaded: url_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: file_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: html_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: form_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: text_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:16:23 --> Database Driver Class Initialized
INFO - 2025-04-14 20:16:23 --> Email Class Initialized
INFO - 2025-04-14 20:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:16:23 --> Form Validation Class Initialized
INFO - 2025-04-14 20:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:16:23 --> Pagination Class Initialized
INFO - 2025-04-14 20:16:23 --> Controller Class Initialized
DEBUG - 2025-04-14 20:16:23 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:16:23 --> Model Class Initialized
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:16:23 --> Model Class Initialized
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:16:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:16:23 --> Model Class Initialized
ERROR - 2025-04-14 20:16:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:16:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:16:23 --> Final output sent to browser
DEBUG - 2025-04-14 20:16:23 --> Total execution time: 0.1289
INFO - 2025-04-14 20:16:23 --> Config Class Initialized
INFO - 2025-04-14 20:16:23 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:16:23 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:16:23 --> Utf8 Class Initialized
INFO - 2025-04-14 20:16:23 --> URI Class Initialized
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:16:23 --> Router Class Initialized
INFO - 2025-04-14 20:16:23 --> Output Class Initialized
INFO - 2025-04-14 20:16:23 --> Security Class Initialized
DEBUG - 2025-04-14 20:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:16:23 --> Input Class Initialized
INFO - 2025-04-14 20:16:23 --> Language Class Initialized
INFO - 2025-04-14 20:16:23 --> Language Class Initialized
INFO - 2025-04-14 20:16:23 --> Config Class Initialized
INFO - 2025-04-14 20:16:23 --> Loader Class Initialized
INFO - 2025-04-14 20:16:23 --> Helper loaded: url_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: file_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: html_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: form_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: text_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:16:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:16:23 --> Database Driver Class Initialized
INFO - 2025-04-14 20:16:23 --> Email Class Initialized
INFO - 2025-04-14 20:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:16:23 --> Form Validation Class Initialized
INFO - 2025-04-14 20:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:16:23 --> Pagination Class Initialized
INFO - 2025-04-14 20:16:23 --> Controller Class Initialized
DEBUG - 2025-04-14 20:16:23 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:16:23 --> Model Class Initialized
DEBUG - 2025-04-14 20:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:16:23 --> Model Class Initialized
INFO - 2025-04-14 20:16:23 --> Final output sent to browser
DEBUG - 2025-04-14 20:16:23 --> Total execution time: 0.0110
INFO - 2025-04-14 20:17:06 --> Config Class Initialized
INFO - 2025-04-14 20:17:06 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:06 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:06 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:06 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:17:06 --> Router Class Initialized
INFO - 2025-04-14 20:17:06 --> Output Class Initialized
INFO - 2025-04-14 20:17:06 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:06 --> Input Class Initialized
INFO - 2025-04-14 20:17:06 --> Language Class Initialized
INFO - 2025-04-14 20:17:06 --> Language Class Initialized
INFO - 2025-04-14 20:17:06 --> Config Class Initialized
INFO - 2025-04-14 20:17:06 --> Loader Class Initialized
INFO - 2025-04-14 20:17:06 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:06 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:06 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:06 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:06 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:06 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:06 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:06 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:06 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:06 --> Email Class Initialized
INFO - 2025-04-14 20:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:06 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:06 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:06 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:06 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:17:06 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:17:06 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:17:06 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:17:06 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:17:06 --> Model Class Initialized
ERROR - 2025-04-14 20:17:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:17:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:17:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:17:06 --> Final output sent to browser
DEBUG - 2025-04-14 20:17:06 --> Total execution time: 0.1254
INFO - 2025-04-14 20:17:12 --> Config Class Initialized
INFO - 2025-04-14 20:17:12 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:12 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:12 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:12 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:17:12 --> Router Class Initialized
INFO - 2025-04-14 20:17:12 --> Output Class Initialized
INFO - 2025-04-14 20:17:12 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:12 --> Input Class Initialized
INFO - 2025-04-14 20:17:12 --> Language Class Initialized
INFO - 2025-04-14 20:17:12 --> Language Class Initialized
INFO - 2025-04-14 20:17:12 --> Config Class Initialized
INFO - 2025-04-14 20:17:12 --> Loader Class Initialized
INFO - 2025-04-14 20:17:12 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:12 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:12 --> Email Class Initialized
INFO - 2025-04-14 20:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:12 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:12 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:12 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:12 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:17:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:17:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:17:12 --> Model Class Initialized
INFO - 2025-04-14 20:17:12 --> Config Class Initialized
INFO - 2025-04-14 20:17:12 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:12 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:12 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:12 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:17:12 --> Router Class Initialized
INFO - 2025-04-14 20:17:12 --> Output Class Initialized
INFO - 2025-04-14 20:17:12 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:12 --> Input Class Initialized
INFO - 2025-04-14 20:17:12 --> Language Class Initialized
INFO - 2025-04-14 20:17:12 --> Language Class Initialized
INFO - 2025-04-14 20:17:12 --> Config Class Initialized
INFO - 2025-04-14 20:17:12 --> Loader Class Initialized
INFO - 2025-04-14 20:17:12 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:12 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:12 --> Email Class Initialized
INFO - 2025-04-14 20:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:12 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:12 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:12 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:12 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:17:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:17:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:17:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:17:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:17:12 --> Model Class Initialized
ERROR - 2025-04-14 20:17:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:17:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:17:12 --> Final output sent to browser
DEBUG - 2025-04-14 20:17:12 --> Total execution time: 0.1285
INFO - 2025-04-14 20:17:16 --> Config Class Initialized
INFO - 2025-04-14 20:17:16 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:16 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:16 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:16 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:16 --> Router Class Initialized
INFO - 2025-04-14 20:17:16 --> Output Class Initialized
INFO - 2025-04-14 20:17:16 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:16 --> Input Class Initialized
INFO - 2025-04-14 20:17:16 --> Language Class Initialized
INFO - 2025-04-14 20:17:16 --> Language Class Initialized
INFO - 2025-04-14 20:17:16 --> Config Class Initialized
INFO - 2025-04-14 20:17:16 --> Loader Class Initialized
INFO - 2025-04-14 20:17:16 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:16 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:16 --> Email Class Initialized
INFO - 2025-04-14 20:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:16 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:16 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:16 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:17:16 --> Config Class Initialized
INFO - 2025-04-14 20:17:16 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:16 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:16 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:16 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:16 --> Router Class Initialized
INFO - 2025-04-14 20:17:16 --> Output Class Initialized
INFO - 2025-04-14 20:17:16 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:16 --> Input Class Initialized
INFO - 2025-04-14 20:17:16 --> Language Class Initialized
INFO - 2025-04-14 20:17:16 --> Language Class Initialized
INFO - 2025-04-14 20:17:16 --> Config Class Initialized
INFO - 2025-04-14 20:17:16 --> Loader Class Initialized
INFO - 2025-04-14 20:17:16 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:16 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:16 --> Email Class Initialized
INFO - 2025-04-14 20:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:16 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:16 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:16 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:17:19 --> Config Class Initialized
INFO - 2025-04-14 20:17:19 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:19 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:19 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:19 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:19 --> Router Class Initialized
INFO - 2025-04-14 20:17:19 --> Output Class Initialized
INFO - 2025-04-14 20:17:19 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:19 --> Input Class Initialized
INFO - 2025-04-14 20:17:19 --> Language Class Initialized
INFO - 2025-04-14 20:17:19 --> Language Class Initialized
INFO - 2025-04-14 20:17:19 --> Config Class Initialized
INFO - 2025-04-14 20:17:19 --> Loader Class Initialized
INFO - 2025-04-14 20:17:19 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:19 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:19 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:19 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:19 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:19 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:19 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:19 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:19 --> Email Class Initialized
INFO - 2025-04-14 20:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:19 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:19 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:19 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:19 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:17:23 --> Config Class Initialized
INFO - 2025-04-14 20:17:23 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:23 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:23 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:23 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:23 --> Router Class Initialized
INFO - 2025-04-14 20:17:23 --> Output Class Initialized
INFO - 2025-04-14 20:17:23 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:23 --> Input Class Initialized
INFO - 2025-04-14 20:17:23 --> Language Class Initialized
INFO - 2025-04-14 20:17:23 --> Language Class Initialized
INFO - 2025-04-14 20:17:23 --> Config Class Initialized
INFO - 2025-04-14 20:17:23 --> Loader Class Initialized
INFO - 2025-04-14 20:17:23 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:23 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:23 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:23 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:23 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:23 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:23 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:23 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:23 --> Email Class Initialized
INFO - 2025-04-14 20:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:23 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:23 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:23 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:23 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:17:24 --> Config Class Initialized
INFO - 2025-04-14 20:17:24 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:24 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:24 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:24 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:24 --> Router Class Initialized
INFO - 2025-04-14 20:17:24 --> Output Class Initialized
INFO - 2025-04-14 20:17:24 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:24 --> Input Class Initialized
INFO - 2025-04-14 20:17:24 --> Language Class Initialized
INFO - 2025-04-14 20:17:24 --> Language Class Initialized
INFO - 2025-04-14 20:17:24 --> Config Class Initialized
INFO - 2025-04-14 20:17:24 --> Loader Class Initialized
INFO - 2025-04-14 20:17:24 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:24 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:24 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:24 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:24 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:24 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:24 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:24 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:24 --> Email Class Initialized
INFO - 2025-04-14 20:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:24 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:24 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:24 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:24 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:17:26 --> Config Class Initialized
INFO - 2025-04-14 20:17:26 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:26 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:26 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:26 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:26 --> Router Class Initialized
INFO - 2025-04-14 20:17:26 --> Output Class Initialized
INFO - 2025-04-14 20:17:26 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:26 --> Input Class Initialized
INFO - 2025-04-14 20:17:26 --> Language Class Initialized
INFO - 2025-04-14 20:17:26 --> Language Class Initialized
INFO - 2025-04-14 20:17:26 --> Config Class Initialized
INFO - 2025-04-14 20:17:26 --> Loader Class Initialized
INFO - 2025-04-14 20:17:26 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:26 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:26 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:26 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:26 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:26 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:26 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:26 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:26 --> Email Class Initialized
INFO - 2025-04-14 20:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:26 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:26 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:26 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:26 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:17:40 --> Config Class Initialized
INFO - 2025-04-14 20:17:40 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:40 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:40 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:40 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:17:40 --> Router Class Initialized
INFO - 2025-04-14 20:17:40 --> Output Class Initialized
INFO - 2025-04-14 20:17:40 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:40 --> Input Class Initialized
INFO - 2025-04-14 20:17:40 --> Language Class Initialized
INFO - 2025-04-14 20:17:40 --> Language Class Initialized
INFO - 2025-04-14 20:17:40 --> Config Class Initialized
INFO - 2025-04-14 20:17:40 --> Loader Class Initialized
INFO - 2025-04-14 20:17:40 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:40 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:40 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:40 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:40 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:40 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:40 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:40 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:40 --> Email Class Initialized
INFO - 2025-04-14 20:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:40 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:40 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:40 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:40 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:17:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:17:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:17:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:17:40 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:17:40 --> Model Class Initialized
ERROR - 2025-04-14 20:17:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:17:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:17:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:17:40 --> Final output sent to browser
DEBUG - 2025-04-14 20:17:40 --> Total execution time: 0.0914
INFO - 2025-04-14 20:17:44 --> Config Class Initialized
INFO - 2025-04-14 20:17:44 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:44 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:44 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:44 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:17:44 --> Router Class Initialized
INFO - 2025-04-14 20:17:44 --> Output Class Initialized
INFO - 2025-04-14 20:17:44 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:44 --> Input Class Initialized
INFO - 2025-04-14 20:17:44 --> Language Class Initialized
INFO - 2025-04-14 20:17:44 --> Language Class Initialized
INFO - 2025-04-14 20:17:44 --> Config Class Initialized
INFO - 2025-04-14 20:17:44 --> Loader Class Initialized
INFO - 2025-04-14 20:17:44 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:44 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:44 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:44 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:44 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:44 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:44 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:44 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:44 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:44 --> Email Class Initialized
INFO - 2025-04-14 20:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:44 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:44 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:44 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:44 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:17:44 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:17:44 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:17:44 --> Model Class Initialized
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:17:44 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:17:44 --> Model Class Initialized
ERROR - 2025-04-14 20:17:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:17:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:17:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:17:44 --> Final output sent to browser
DEBUG - 2025-04-14 20:17:44 --> Total execution time: 0.1359
INFO - 2025-04-14 20:17:55 --> Config Class Initialized
INFO - 2025-04-14 20:17:55 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:55 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:55 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:55 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:55 --> Router Class Initialized
INFO - 2025-04-14 20:17:55 --> Output Class Initialized
INFO - 2025-04-14 20:17:55 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:55 --> Input Class Initialized
INFO - 2025-04-14 20:17:55 --> Language Class Initialized
INFO - 2025-04-14 20:17:55 --> Language Class Initialized
INFO - 2025-04-14 20:17:55 --> Config Class Initialized
INFO - 2025-04-14 20:17:55 --> Loader Class Initialized
INFO - 2025-04-14 20:17:55 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:55 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:55 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:55 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:55 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:55 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:55 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:55 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:55 --> Email Class Initialized
INFO - 2025-04-14 20:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:55 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:55 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:55 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:17:57 --> Config Class Initialized
INFO - 2025-04-14 20:17:57 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:17:57 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:17:57 --> Utf8 Class Initialized
INFO - 2025-04-14 20:17:57 --> URI Class Initialized
DEBUG - 2025-04-14 20:17:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:17:57 --> Router Class Initialized
INFO - 2025-04-14 20:17:57 --> Output Class Initialized
INFO - 2025-04-14 20:17:57 --> Security Class Initialized
DEBUG - 2025-04-14 20:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:17:57 --> Input Class Initialized
INFO - 2025-04-14 20:17:57 --> Language Class Initialized
INFO - 2025-04-14 20:17:57 --> Language Class Initialized
INFO - 2025-04-14 20:17:57 --> Config Class Initialized
INFO - 2025-04-14 20:17:57 --> Loader Class Initialized
INFO - 2025-04-14 20:17:57 --> Helper loaded: url_helper
INFO - 2025-04-14 20:17:57 --> Helper loaded: file_helper
INFO - 2025-04-14 20:17:57 --> Helper loaded: html_helper
INFO - 2025-04-14 20:17:57 --> Helper loaded: form_helper
INFO - 2025-04-14 20:17:57 --> Helper loaded: text_helper
INFO - 2025-04-14 20:17:57 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:17:57 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:17:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:17:57 --> Database Driver Class Initialized
INFO - 2025-04-14 20:17:57 --> Email Class Initialized
INFO - 2025-04-14 20:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:17:57 --> Form Validation Class Initialized
INFO - 2025-04-14 20:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:17:57 --> Pagination Class Initialized
INFO - 2025-04-14 20:17:57 --> Controller Class Initialized
DEBUG - 2025-04-14 20:17:57 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:18:07 --> Config Class Initialized
INFO - 2025-04-14 20:18:07 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:18:07 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:18:07 --> Utf8 Class Initialized
INFO - 2025-04-14 20:18:07 --> URI Class Initialized
DEBUG - 2025-04-14 20:18:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:18:07 --> Router Class Initialized
INFO - 2025-04-14 20:18:07 --> Output Class Initialized
INFO - 2025-04-14 20:18:07 --> Security Class Initialized
DEBUG - 2025-04-14 20:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:18:07 --> Input Class Initialized
INFO - 2025-04-14 20:18:07 --> Language Class Initialized
INFO - 2025-04-14 20:18:07 --> Language Class Initialized
INFO - 2025-04-14 20:18:07 --> Config Class Initialized
INFO - 2025-04-14 20:18:07 --> Loader Class Initialized
INFO - 2025-04-14 20:18:07 --> Helper loaded: url_helper
INFO - 2025-04-14 20:18:07 --> Helper loaded: file_helper
INFO - 2025-04-14 20:18:07 --> Helper loaded: html_helper
INFO - 2025-04-14 20:18:07 --> Helper loaded: form_helper
INFO - 2025-04-14 20:18:07 --> Helper loaded: text_helper
INFO - 2025-04-14 20:18:07 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:18:07 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:18:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:18:07 --> Database Driver Class Initialized
INFO - 2025-04-14 20:18:07 --> Email Class Initialized
INFO - 2025-04-14 20:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:18:07 --> Form Validation Class Initialized
INFO - 2025-04-14 20:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:18:07 --> Pagination Class Initialized
INFO - 2025-04-14 20:18:07 --> Controller Class Initialized
DEBUG - 2025-04-14 20:18:07 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:18:22 --> Config Class Initialized
INFO - 2025-04-14 20:18:22 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:18:22 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:18:22 --> Utf8 Class Initialized
INFO - 2025-04-14 20:18:22 --> URI Class Initialized
DEBUG - 2025-04-14 20:18:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:18:22 --> Router Class Initialized
INFO - 2025-04-14 20:18:22 --> Output Class Initialized
INFO - 2025-04-14 20:18:22 --> Security Class Initialized
DEBUG - 2025-04-14 20:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:18:22 --> Input Class Initialized
INFO - 2025-04-14 20:18:22 --> Language Class Initialized
INFO - 2025-04-14 20:18:22 --> Language Class Initialized
INFO - 2025-04-14 20:18:22 --> Config Class Initialized
INFO - 2025-04-14 20:18:22 --> Loader Class Initialized
INFO - 2025-04-14 20:18:22 --> Helper loaded: url_helper
INFO - 2025-04-14 20:18:22 --> Helper loaded: file_helper
INFO - 2025-04-14 20:18:22 --> Helper loaded: html_helper
INFO - 2025-04-14 20:18:22 --> Helper loaded: form_helper
INFO - 2025-04-14 20:18:22 --> Helper loaded: text_helper
INFO - 2025-04-14 20:18:22 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:18:22 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:18:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:18:22 --> Database Driver Class Initialized
INFO - 2025-04-14 20:18:22 --> Email Class Initialized
INFO - 2025-04-14 20:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:18:22 --> Form Validation Class Initialized
INFO - 2025-04-14 20:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:18:22 --> Pagination Class Initialized
INFO - 2025-04-14 20:18:22 --> Controller Class Initialized
DEBUG - 2025-04-14 20:18:22 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:18:22 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:18:22 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:18:22 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:22 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-14 20:18:22 --> ✅ Proceeding with return_invoice_entry()
ERROR - 2025-04-14 20:18:22 --> Severity: error --> Exception: Unknown column 'quantity' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-04-14 20:18:33 --> Config Class Initialized
INFO - 2025-04-14 20:18:33 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:18:33 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:18:33 --> Utf8 Class Initialized
INFO - 2025-04-14 20:18:33 --> URI Class Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:18:33 --> Router Class Initialized
INFO - 2025-04-14 20:18:33 --> Output Class Initialized
INFO - 2025-04-14 20:18:33 --> Security Class Initialized
DEBUG - 2025-04-14 20:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:18:33 --> Input Class Initialized
INFO - 2025-04-14 20:18:33 --> Language Class Initialized
INFO - 2025-04-14 20:18:33 --> Language Class Initialized
INFO - 2025-04-14 20:18:33 --> Config Class Initialized
INFO - 2025-04-14 20:18:33 --> Loader Class Initialized
INFO - 2025-04-14 20:18:33 --> Helper loaded: url_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: file_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: html_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: form_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: text_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:18:33 --> Database Driver Class Initialized
INFO - 2025-04-14 20:18:33 --> Email Class Initialized
INFO - 2025-04-14 20:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:18:33 --> Form Validation Class Initialized
INFO - 2025-04-14 20:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:18:33 --> Pagination Class Initialized
INFO - 2025-04-14 20:18:33 --> Controller Class Initialized
DEBUG - 2025-04-14 20:18:33 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:18:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:18:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:18:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:33 --> 🔁 return_invoice() called | finyear: 
ERROR - 2025-04-14 20:18:33 --> ❌ Financial year missing or invalid.
INFO - 2025-04-14 20:18:33 --> Config Class Initialized
INFO - 2025-04-14 20:18:33 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:18:33 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:18:33 --> Utf8 Class Initialized
INFO - 2025-04-14 20:18:33 --> URI Class Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:18:33 --> Router Class Initialized
INFO - 2025-04-14 20:18:33 --> Output Class Initialized
INFO - 2025-04-14 20:18:33 --> Security Class Initialized
DEBUG - 2025-04-14 20:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:18:33 --> Input Class Initialized
INFO - 2025-04-14 20:18:33 --> Language Class Initialized
INFO - 2025-04-14 20:18:33 --> Language Class Initialized
INFO - 2025-04-14 20:18:33 --> Config Class Initialized
INFO - 2025-04-14 20:18:33 --> Loader Class Initialized
INFO - 2025-04-14 20:18:33 --> Helper loaded: url_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: file_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: html_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: form_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: text_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:18:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:18:33 --> Database Driver Class Initialized
INFO - 2025-04-14 20:18:33 --> Email Class Initialized
INFO - 2025-04-14 20:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:18:33 --> Form Validation Class Initialized
INFO - 2025-04-14 20:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:18:33 --> Pagination Class Initialized
INFO - 2025-04-14 20:18:33 --> Controller Class Initialized
DEBUG - 2025-04-14 20:18:33 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:18:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:18:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:18:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:18:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:18:33 --> Model Class Initialized
ERROR - 2025-04-14 20:18:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:18:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:18:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:18:33 --> Final output sent to browser
DEBUG - 2025-04-14 20:18:33 --> Total execution time: 0.1106
INFO - 2025-04-14 20:18:40 --> Config Class Initialized
INFO - 2025-04-14 20:18:40 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:18:40 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:18:40 --> Utf8 Class Initialized
INFO - 2025-04-14 20:18:40 --> URI Class Initialized
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:18:40 --> Router Class Initialized
INFO - 2025-04-14 20:18:40 --> Output Class Initialized
INFO - 2025-04-14 20:18:40 --> Security Class Initialized
DEBUG - 2025-04-14 20:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:18:40 --> Input Class Initialized
INFO - 2025-04-14 20:18:40 --> Language Class Initialized
INFO - 2025-04-14 20:18:40 --> Language Class Initialized
INFO - 2025-04-14 20:18:40 --> Config Class Initialized
INFO - 2025-04-14 20:18:40 --> Loader Class Initialized
INFO - 2025-04-14 20:18:40 --> Helper loaded: url_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: file_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: html_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: form_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: text_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:18:40 --> Database Driver Class Initialized
INFO - 2025-04-14 20:18:40 --> Email Class Initialized
INFO - 2025-04-14 20:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:18:40 --> Form Validation Class Initialized
INFO - 2025-04-14 20:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:18:40 --> Pagination Class Initialized
INFO - 2025-04-14 20:18:40 --> Controller Class Initialized
DEBUG - 2025-04-14 20:18:40 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:18:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:18:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:18:40 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:18:40 --> Model Class Initialized
ERROR - 2025-04-14 20:18:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:18:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:18:40 --> Final output sent to browser
DEBUG - 2025-04-14 20:18:40 --> Total execution time: 0.1225
INFO - 2025-04-14 20:18:40 --> Config Class Initialized
INFO - 2025-04-14 20:18:40 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:18:40 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:18:40 --> Utf8 Class Initialized
INFO - 2025-04-14 20:18:40 --> URI Class Initialized
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:18:40 --> Router Class Initialized
INFO - 2025-04-14 20:18:40 --> Output Class Initialized
INFO - 2025-04-14 20:18:40 --> Security Class Initialized
DEBUG - 2025-04-14 20:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:18:40 --> Input Class Initialized
INFO - 2025-04-14 20:18:40 --> Language Class Initialized
INFO - 2025-04-14 20:18:40 --> Language Class Initialized
INFO - 2025-04-14 20:18:40 --> Config Class Initialized
INFO - 2025-04-14 20:18:40 --> Loader Class Initialized
INFO - 2025-04-14 20:18:40 --> Helper loaded: url_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: file_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: html_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: form_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: text_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:18:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:18:40 --> Database Driver Class Initialized
INFO - 2025-04-14 20:18:40 --> Email Class Initialized
INFO - 2025-04-14 20:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:18:40 --> Form Validation Class Initialized
INFO - 2025-04-14 20:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:18:40 --> Pagination Class Initialized
INFO - 2025-04-14 20:18:40 --> Controller Class Initialized
DEBUG - 2025-04-14 20:18:40 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:18:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:18:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:18:40 --> Model Class Initialized
INFO - 2025-04-14 20:18:40 --> Final output sent to browser
DEBUG - 2025-04-14 20:18:40 --> Total execution time: 0.0114
INFO - 2025-04-14 20:19:19 --> Config Class Initialized
INFO - 2025-04-14 20:19:19 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:19:19 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:19:19 --> Utf8 Class Initialized
INFO - 2025-04-14 20:19:19 --> URI Class Initialized
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:19:19 --> Router Class Initialized
INFO - 2025-04-14 20:19:19 --> Output Class Initialized
INFO - 2025-04-14 20:19:19 --> Security Class Initialized
DEBUG - 2025-04-14 20:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:19:19 --> Input Class Initialized
INFO - 2025-04-14 20:19:19 --> Language Class Initialized
INFO - 2025-04-14 20:19:19 --> Language Class Initialized
INFO - 2025-04-14 20:19:19 --> Config Class Initialized
INFO - 2025-04-14 20:19:19 --> Loader Class Initialized
INFO - 2025-04-14 20:19:19 --> Helper loaded: url_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: file_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: html_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: form_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: text_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:19:19 --> Database Driver Class Initialized
INFO - 2025-04-14 20:19:19 --> Email Class Initialized
INFO - 2025-04-14 20:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:19:19 --> Form Validation Class Initialized
INFO - 2025-04-14 20:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:19:19 --> Pagination Class Initialized
INFO - 2025-04-14 20:19:19 --> Controller Class Initialized
DEBUG - 2025-04-14 20:19:19 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:19:19 --> Model Class Initialized
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:19:19 --> Model Class Initialized
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:19:19 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:19:19 --> Model Class Initialized
ERROR - 2025-04-14 20:19:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:19:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:19:19 --> Final output sent to browser
DEBUG - 2025-04-14 20:19:19 --> Total execution time: 0.1128
INFO - 2025-04-14 20:19:19 --> Config Class Initialized
INFO - 2025-04-14 20:19:19 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:19:19 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:19:19 --> Utf8 Class Initialized
INFO - 2025-04-14 20:19:19 --> URI Class Initialized
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:19:19 --> Router Class Initialized
INFO - 2025-04-14 20:19:19 --> Output Class Initialized
INFO - 2025-04-14 20:19:19 --> Security Class Initialized
DEBUG - 2025-04-14 20:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:19:19 --> Input Class Initialized
INFO - 2025-04-14 20:19:19 --> Language Class Initialized
INFO - 2025-04-14 20:19:19 --> Language Class Initialized
INFO - 2025-04-14 20:19:19 --> Config Class Initialized
INFO - 2025-04-14 20:19:19 --> Loader Class Initialized
INFO - 2025-04-14 20:19:19 --> Helper loaded: url_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: file_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: html_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: form_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: text_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:19:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:19:19 --> Database Driver Class Initialized
INFO - 2025-04-14 20:19:19 --> Email Class Initialized
INFO - 2025-04-14 20:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:19:19 --> Form Validation Class Initialized
INFO - 2025-04-14 20:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:19:19 --> Pagination Class Initialized
INFO - 2025-04-14 20:19:19 --> Controller Class Initialized
DEBUG - 2025-04-14 20:19:19 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:19:19 --> Model Class Initialized
DEBUG - 2025-04-14 20:19:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:19:19 --> Model Class Initialized
INFO - 2025-04-14 20:19:19 --> Final output sent to browser
DEBUG - 2025-04-14 20:19:19 --> Total execution time: 0.0093
INFO - 2025-04-14 20:20:01 --> Config Class Initialized
INFO - 2025-04-14 20:20:01 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:20:01 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:20:01 --> Utf8 Class Initialized
INFO - 2025-04-14 20:20:01 --> URI Class Initialized
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:20:01 --> Router Class Initialized
INFO - 2025-04-14 20:20:01 --> Output Class Initialized
INFO - 2025-04-14 20:20:01 --> Security Class Initialized
DEBUG - 2025-04-14 20:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:20:01 --> Input Class Initialized
INFO - 2025-04-14 20:20:01 --> Language Class Initialized
INFO - 2025-04-14 20:20:01 --> Language Class Initialized
INFO - 2025-04-14 20:20:01 --> Config Class Initialized
INFO - 2025-04-14 20:20:01 --> Loader Class Initialized
INFO - 2025-04-14 20:20:01 --> Helper loaded: url_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: file_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: html_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: form_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: text_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:20:01 --> Database Driver Class Initialized
INFO - 2025-04-14 20:20:01 --> Email Class Initialized
INFO - 2025-04-14 20:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:20:01 --> Form Validation Class Initialized
INFO - 2025-04-14 20:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:20:01 --> Pagination Class Initialized
INFO - 2025-04-14 20:20:01 --> Controller Class Initialized
DEBUG - 2025-04-14 20:20:01 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:20:01 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:20:01 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:20:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:20:01 --> Model Class Initialized
ERROR - 2025-04-14 20:20:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:20:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-14 20:20:01 --> Severity: Warning --> Undefined variable $merchant_list /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php 26
ERROR - 2025-04-14 20:20:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php 26
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:20:01 --> Final output sent to browser
DEBUG - 2025-04-14 20:20:01 --> Total execution time: 0.1262
INFO - 2025-04-14 20:20:01 --> Config Class Initialized
INFO - 2025-04-14 20:20:01 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:20:01 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:20:01 --> Utf8 Class Initialized
INFO - 2025-04-14 20:20:01 --> URI Class Initialized
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:20:01 --> Router Class Initialized
INFO - 2025-04-14 20:20:01 --> Output Class Initialized
INFO - 2025-04-14 20:20:01 --> Security Class Initialized
DEBUG - 2025-04-14 20:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:20:01 --> Input Class Initialized
INFO - 2025-04-14 20:20:01 --> Language Class Initialized
INFO - 2025-04-14 20:20:01 --> Language Class Initialized
INFO - 2025-04-14 20:20:01 --> Config Class Initialized
INFO - 2025-04-14 20:20:01 --> Loader Class Initialized
INFO - 2025-04-14 20:20:01 --> Helper loaded: url_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: file_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: html_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: form_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: text_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:20:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:20:01 --> Database Driver Class Initialized
INFO - 2025-04-14 20:20:01 --> Email Class Initialized
INFO - 2025-04-14 20:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:20:01 --> Form Validation Class Initialized
INFO - 2025-04-14 20:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:20:01 --> Pagination Class Initialized
INFO - 2025-04-14 20:20:01 --> Controller Class Initialized
DEBUG - 2025-04-14 20:20:01 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:20:01 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:20:01 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:20:01 --> Model Class Initialized
INFO - 2025-04-14 20:20:01 --> Final output sent to browser
DEBUG - 2025-04-14 20:20:01 --> Total execution time: 0.0152
INFO - 2025-04-14 20:20:04 --> Config Class Initialized
INFO - 2025-04-14 20:20:04 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:20:04 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:20:04 --> Utf8 Class Initialized
INFO - 2025-04-14 20:20:04 --> URI Class Initialized
DEBUG - 2025-04-14 20:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:20:04 --> Router Class Initialized
INFO - 2025-04-14 20:20:04 --> Output Class Initialized
INFO - 2025-04-14 20:20:04 --> Security Class Initialized
DEBUG - 2025-04-14 20:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:20:04 --> Input Class Initialized
INFO - 2025-04-14 20:20:04 --> Language Class Initialized
INFO - 2025-04-14 20:20:04 --> Language Class Initialized
INFO - 2025-04-14 20:20:04 --> Config Class Initialized
INFO - 2025-04-14 20:20:04 --> Loader Class Initialized
INFO - 2025-04-14 20:20:04 --> Helper loaded: url_helper
INFO - 2025-04-14 20:20:04 --> Helper loaded: file_helper
INFO - 2025-04-14 20:20:04 --> Helper loaded: html_helper
INFO - 2025-04-14 20:20:04 --> Helper loaded: form_helper
INFO - 2025-04-14 20:20:04 --> Helper loaded: text_helper
INFO - 2025-04-14 20:20:04 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:20:04 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:20:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:20:04 --> Database Driver Class Initialized
INFO - 2025-04-14 20:20:04 --> Email Class Initialized
INFO - 2025-04-14 20:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:20:04 --> Form Validation Class Initialized
INFO - 2025-04-14 20:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:20:04 --> Pagination Class Initialized
INFO - 2025-04-14 20:20:04 --> Controller Class Initialized
DEBUG - 2025-04-14 20:20:04 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:20:04 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:20:04 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:20:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:20:04 --> Model Class Initialized
ERROR - 2025-04-14 20:20:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:20:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:20:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_return.php
DEBUG - 2025-04-14 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:20:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:20:05 --> Final output sent to browser
DEBUG - 2025-04-14 20:20:05 --> Total execution time: 0.1227
INFO - 2025-04-14 20:20:33 --> Config Class Initialized
INFO - 2025-04-14 20:20:33 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:20:33 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:20:33 --> Utf8 Class Initialized
INFO - 2025-04-14 20:20:33 --> URI Class Initialized
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:20:33 --> Router Class Initialized
INFO - 2025-04-14 20:20:33 --> Output Class Initialized
INFO - 2025-04-14 20:20:33 --> Security Class Initialized
DEBUG - 2025-04-14 20:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:20:33 --> Input Class Initialized
INFO - 2025-04-14 20:20:33 --> Language Class Initialized
INFO - 2025-04-14 20:20:33 --> Language Class Initialized
INFO - 2025-04-14 20:20:33 --> Config Class Initialized
INFO - 2025-04-14 20:20:33 --> Loader Class Initialized
INFO - 2025-04-14 20:20:33 --> Helper loaded: url_helper
INFO - 2025-04-14 20:20:33 --> Helper loaded: file_helper
INFO - 2025-04-14 20:20:33 --> Helper loaded: html_helper
INFO - 2025-04-14 20:20:33 --> Helper loaded: form_helper
INFO - 2025-04-14 20:20:33 --> Helper loaded: text_helper
INFO - 2025-04-14 20:20:33 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:20:33 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:20:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:20:33 --> Database Driver Class Initialized
INFO - 2025-04-14 20:20:33 --> Email Class Initialized
INFO - 2025-04-14 20:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:20:33 --> Form Validation Class Initialized
INFO - 2025-04-14 20:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:20:33 --> Pagination Class Initialized
INFO - 2025-04-14 20:20:33 --> Controller Class Initialized
DEBUG - 2025-04-14 20:20:33 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:20:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:20:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:20:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:20:33 --> Model Class Initialized
ERROR - 2025-04-14 20:20:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:20:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/supplier_return.php
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:20:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:20:33 --> Final output sent to browser
DEBUG - 2025-04-14 20:20:33 --> Total execution time: 0.1602
INFO - 2025-04-14 20:20:42 --> Config Class Initialized
INFO - 2025-04-14 20:20:42 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:20:42 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:20:42 --> Utf8 Class Initialized
INFO - 2025-04-14 20:20:42 --> URI Class Initialized
DEBUG - 2025-04-14 20:20:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:20:42 --> Router Class Initialized
INFO - 2025-04-14 20:20:42 --> Output Class Initialized
INFO - 2025-04-14 20:20:42 --> Security Class Initialized
DEBUG - 2025-04-14 20:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:20:42 --> Input Class Initialized
INFO - 2025-04-14 20:20:42 --> Language Class Initialized
INFO - 2025-04-14 20:20:42 --> Language Class Initialized
INFO - 2025-04-14 20:20:42 --> Config Class Initialized
INFO - 2025-04-14 20:20:42 --> Loader Class Initialized
INFO - 2025-04-14 20:20:42 --> Helper loaded: url_helper
INFO - 2025-04-14 20:20:42 --> Helper loaded: file_helper
INFO - 2025-04-14 20:20:42 --> Helper loaded: html_helper
INFO - 2025-04-14 20:20:42 --> Helper loaded: form_helper
INFO - 2025-04-14 20:20:42 --> Helper loaded: text_helper
INFO - 2025-04-14 20:20:42 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:20:42 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:20:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:20:42 --> Database Driver Class Initialized
INFO - 2025-04-14 20:20:42 --> Email Class Initialized
INFO - 2025-04-14 20:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:20:42 --> Form Validation Class Initialized
INFO - 2025-04-14 20:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:20:42 --> Pagination Class Initialized
INFO - 2025-04-14 20:20:42 --> Controller Class Initialized
DEBUG - 2025-04-14 20:20:42 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:20:42 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:20:42 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:20:42 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:20:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:20:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:20:42 --> Model Class Initialized
ERROR - 2025-04-14 20:20:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:20:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:20:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:20:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:20:43 --> Final output sent to browser
DEBUG - 2025-04-14 20:20:43 --> Total execution time: 0.1197
INFO - 2025-04-14 20:20:51 --> Config Class Initialized
INFO - 2025-04-14 20:20:51 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:20:51 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:20:51 --> Utf8 Class Initialized
INFO - 2025-04-14 20:20:51 --> URI Class Initialized
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:20:51 --> Router Class Initialized
INFO - 2025-04-14 20:20:51 --> Output Class Initialized
INFO - 2025-04-14 20:20:51 --> Security Class Initialized
DEBUG - 2025-04-14 20:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:20:51 --> Input Class Initialized
INFO - 2025-04-14 20:20:51 --> Language Class Initialized
INFO - 2025-04-14 20:20:51 --> Language Class Initialized
INFO - 2025-04-14 20:20:51 --> Config Class Initialized
INFO - 2025-04-14 20:20:51 --> Loader Class Initialized
INFO - 2025-04-14 20:20:51 --> Helper loaded: url_helper
INFO - 2025-04-14 20:20:51 --> Helper loaded: file_helper
INFO - 2025-04-14 20:20:51 --> Helper loaded: html_helper
INFO - 2025-04-14 20:20:51 --> Helper loaded: form_helper
INFO - 2025-04-14 20:20:51 --> Helper loaded: text_helper
INFO - 2025-04-14 20:20:51 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:20:51 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:20:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:20:51 --> Database Driver Class Initialized
INFO - 2025-04-14 20:20:51 --> Email Class Initialized
INFO - 2025-04-14 20:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:20:51 --> Form Validation Class Initialized
INFO - 2025-04-14 20:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:20:51 --> Pagination Class Initialized
INFO - 2025-04-14 20:20:51 --> Controller Class Initialized
DEBUG - 2025-04-14 20:20:51 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:20:51 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:20:51 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:20:51 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:20:51 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:20:51 --> Model Class Initialized
ERROR - 2025-04-14 20:20:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:20:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/wastage_return_list.php
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:20:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:20:51 --> Final output sent to browser
DEBUG - 2025-04-14 20:20:51 --> Total execution time: 0.0817
INFO - 2025-04-14 20:20:58 --> Config Class Initialized
INFO - 2025-04-14 20:20:58 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:20:58 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:20:58 --> Utf8 Class Initialized
INFO - 2025-04-14 20:20:58 --> URI Class Initialized
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:20:58 --> Router Class Initialized
INFO - 2025-04-14 20:20:58 --> Output Class Initialized
INFO - 2025-04-14 20:20:58 --> Security Class Initialized
DEBUG - 2025-04-14 20:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:20:58 --> Input Class Initialized
INFO - 2025-04-14 20:20:58 --> Language Class Initialized
INFO - 2025-04-14 20:20:58 --> Language Class Initialized
INFO - 2025-04-14 20:20:58 --> Config Class Initialized
INFO - 2025-04-14 20:20:58 --> Loader Class Initialized
INFO - 2025-04-14 20:20:58 --> Helper loaded: url_helper
INFO - 2025-04-14 20:20:58 --> Helper loaded: file_helper
INFO - 2025-04-14 20:20:58 --> Helper loaded: html_helper
INFO - 2025-04-14 20:20:58 --> Helper loaded: form_helper
INFO - 2025-04-14 20:20:58 --> Helper loaded: text_helper
INFO - 2025-04-14 20:20:58 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:20:58 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:20:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:20:58 --> Database Driver Class Initialized
INFO - 2025-04-14 20:20:58 --> Email Class Initialized
INFO - 2025-04-14 20:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:20:58 --> Form Validation Class Initialized
INFO - 2025-04-14 20:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:20:58 --> Pagination Class Initialized
INFO - 2025-04-14 20:20:58 --> Controller Class Initialized
DEBUG - 2025-04-14 20:20:58 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:20:58 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:20:58 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:20:58 --> Model Class Initialized
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:20:58 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:20:58 --> Model Class Initialized
ERROR - 2025-04-14 20:20:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:20:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:20:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:20:58 --> Final output sent to browser
DEBUG - 2025-04-14 20:20:58 --> Total execution time: 0.1176
INFO - 2025-04-14 20:25:03 --> Config Class Initialized
INFO - 2025-04-14 20:25:03 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:25:03 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:25:03 --> Utf8 Class Initialized
INFO - 2025-04-14 20:25:03 --> URI Class Initialized
DEBUG - 2025-04-14 20:25:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:25:03 --> Router Class Initialized
INFO - 2025-04-14 20:25:03 --> Output Class Initialized
INFO - 2025-04-14 20:25:03 --> Security Class Initialized
DEBUG - 2025-04-14 20:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:25:03 --> Input Class Initialized
INFO - 2025-04-14 20:25:03 --> Language Class Initialized
INFO - 2025-04-14 20:25:03 --> Language Class Initialized
INFO - 2025-04-14 20:25:03 --> Config Class Initialized
INFO - 2025-04-14 20:25:03 --> Loader Class Initialized
INFO - 2025-04-14 20:25:03 --> Helper loaded: url_helper
INFO - 2025-04-14 20:25:03 --> Helper loaded: file_helper
INFO - 2025-04-14 20:25:03 --> Helper loaded: html_helper
INFO - 2025-04-14 20:25:03 --> Helper loaded: form_helper
INFO - 2025-04-14 20:25:03 --> Helper loaded: text_helper
INFO - 2025-04-14 20:25:03 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:25:03 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:25:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:25:03 --> Database Driver Class Initialized
INFO - 2025-04-14 20:25:03 --> Email Class Initialized
INFO - 2025-04-14 20:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:25:03 --> Form Validation Class Initialized
INFO - 2025-04-14 20:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:25:03 --> Pagination Class Initialized
INFO - 2025-04-14 20:25:03 --> Controller Class Initialized
DEBUG - 2025-04-14 20:25:03 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:25:03 --> Model Class Initialized
DEBUG - 2025-04-14 20:25:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:25:03 --> Model Class Initialized
DEBUG - 2025-04-14 20:25:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:25:03 --> Model Class Initialized
DEBUG - 2025-04-14 20:25:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:25:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:25:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:25:03 --> Model Class Initialized
ERROR - 2025-04-14 20:25:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:25:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:25:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:25:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:25:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:25:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:25:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:25:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:25:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:25:04 --> Final output sent to browser
DEBUG - 2025-04-14 20:25:04 --> Total execution time: 0.1257
INFO - 2025-04-14 20:29:18 --> Config Class Initialized
INFO - 2025-04-14 20:29:18 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:18 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:18 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:18 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:29:18 --> Router Class Initialized
INFO - 2025-04-14 20:29:18 --> Output Class Initialized
INFO - 2025-04-14 20:29:18 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:18 --> Input Class Initialized
INFO - 2025-04-14 20:29:18 --> Language Class Initialized
INFO - 2025-04-14 20:29:18 --> Language Class Initialized
INFO - 2025-04-14 20:29:18 --> Config Class Initialized
INFO - 2025-04-14 20:29:18 --> Loader Class Initialized
INFO - 2025-04-14 20:29:18 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:18 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:18 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:18 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:18 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:18 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:18 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:18 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:18 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:18 --> Email Class Initialized
INFO - 2025-04-14 20:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:18 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:18 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:18 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:18 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:29:18 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:29:18 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:29:18 --> Model Class Initialized
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:29:18 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:29:18 --> Model Class Initialized
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 119
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
ERROR - 2025-04-14 20:29:18 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:29:18 --> Final output sent to browser
DEBUG - 2025-04-14 20:29:18 --> Total execution time: 0.4393
INFO - 2025-04-14 20:29:33 --> Config Class Initialized
INFO - 2025-04-14 20:29:33 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:33 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:33 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:33 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:29:33 --> Router Class Initialized
INFO - 2025-04-14 20:29:33 --> Output Class Initialized
INFO - 2025-04-14 20:29:33 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:33 --> Input Class Initialized
INFO - 2025-04-14 20:29:33 --> Language Class Initialized
INFO - 2025-04-14 20:29:33 --> Language Class Initialized
INFO - 2025-04-14 20:29:33 --> Config Class Initialized
INFO - 2025-04-14 20:29:33 --> Loader Class Initialized
INFO - 2025-04-14 20:29:33 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:33 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:33 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:33 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:33 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:33 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:33 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:33 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:33 --> Email Class Initialized
INFO - 2025-04-14 20:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:33 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:33 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:33 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:33 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:29:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:29:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:29:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:29:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:29:33 --> Model Class Initialized
ERROR - 2025-04-14 20:29:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:29:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:29:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:29:33 --> Final output sent to browser
DEBUG - 2025-04-14 20:29:33 --> Total execution time: 0.1239
INFO - 2025-04-14 20:29:36 --> Config Class Initialized
INFO - 2025-04-14 20:29:36 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:36 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:36 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:36 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:29:36 --> Router Class Initialized
INFO - 2025-04-14 20:29:36 --> Output Class Initialized
INFO - 2025-04-14 20:29:36 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:36 --> Input Class Initialized
INFO - 2025-04-14 20:29:36 --> Language Class Initialized
INFO - 2025-04-14 20:29:36 --> Language Class Initialized
INFO - 2025-04-14 20:29:36 --> Config Class Initialized
INFO - 2025-04-14 20:29:36 --> Loader Class Initialized
INFO - 2025-04-14 20:29:36 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:36 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:36 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:36 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:36 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:36 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:36 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:36 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:36 --> Email Class Initialized
INFO - 2025-04-14 20:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:36 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:36 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:36 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:36 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:29:36 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:29:36 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:29:36 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:29:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:29:36 --> Model Class Initialized
ERROR - 2025-04-14 20:29:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:29:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:29:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:29:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:29:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-14 20:29:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:29:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:29:37 --> Final output sent to browser
DEBUG - 2025-04-14 20:29:37 --> Total execution time: 0.1367
INFO - 2025-04-14 20:29:42 --> Config Class Initialized
INFO - 2025-04-14 20:29:42 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:42 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:42 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:42 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:29:42 --> Router Class Initialized
INFO - 2025-04-14 20:29:42 --> Output Class Initialized
INFO - 2025-04-14 20:29:42 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:42 --> Input Class Initialized
INFO - 2025-04-14 20:29:42 --> Language Class Initialized
INFO - 2025-04-14 20:29:42 --> Language Class Initialized
INFO - 2025-04-14 20:29:42 --> Config Class Initialized
INFO - 2025-04-14 20:29:42 --> Loader Class Initialized
INFO - 2025-04-14 20:29:42 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:42 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:42 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:42 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:42 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:42 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:42 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:42 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:42 --> Email Class Initialized
INFO - 2025-04-14 20:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:42 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:42 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:42 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:42 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:29:42 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:29:42 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:29:42 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:29:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:29:42 --> Model Class Initialized
ERROR - 2025-04-14 20:29:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:29:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:29:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:29:42 --> Final output sent to browser
DEBUG - 2025-04-14 20:29:42 --> Total execution time: 0.1230
INFO - 2025-04-14 20:29:43 --> Config Class Initialized
INFO - 2025-04-14 20:29:43 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:43 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:43 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:43 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:29:43 --> Router Class Initialized
INFO - 2025-04-14 20:29:43 --> Output Class Initialized
INFO - 2025-04-14 20:29:43 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:43 --> Input Class Initialized
INFO - 2025-04-14 20:29:43 --> Language Class Initialized
INFO - 2025-04-14 20:29:43 --> Language Class Initialized
INFO - 2025-04-14 20:29:43 --> Config Class Initialized
INFO - 2025-04-14 20:29:43 --> Loader Class Initialized
INFO - 2025-04-14 20:29:43 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:43 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:43 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:43 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:43 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:43 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:43 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:43 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:43 --> Email Class Initialized
INFO - 2025-04-14 20:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:43 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:43 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:43 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:43 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:29:43 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:29:43 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:29:43 --> Model Class Initialized
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:29:43 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:29:43 --> Model Class Initialized
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 119
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
ERROR - 2025-04-14 20:29:43 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:29:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:29:43 --> Final output sent to browser
DEBUG - 2025-04-14 20:29:43 --> Total execution time: 0.1181
INFO - 2025-04-14 20:29:45 --> Config Class Initialized
INFO - 2025-04-14 20:29:45 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:45 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:45 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:45 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:29:45 --> Router Class Initialized
INFO - 2025-04-14 20:29:45 --> Output Class Initialized
INFO - 2025-04-14 20:29:45 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:45 --> Input Class Initialized
INFO - 2025-04-14 20:29:45 --> Language Class Initialized
INFO - 2025-04-14 20:29:45 --> Language Class Initialized
INFO - 2025-04-14 20:29:45 --> Config Class Initialized
INFO - 2025-04-14 20:29:45 --> Loader Class Initialized
INFO - 2025-04-14 20:29:45 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:45 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:45 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:45 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:45 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:45 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:45 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:45 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:45 --> Email Class Initialized
INFO - 2025-04-14 20:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:45 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:45 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:45 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:45 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:29:45 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:29:45 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:29:45 --> Model Class Initialized
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:29:45 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:29:45 --> Model Class Initialized
ERROR - 2025-04-14 20:29:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:29:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:29:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:29:45 --> Final output sent to browser
DEBUG - 2025-04-14 20:29:45 --> Total execution time: 0.1196
INFO - 2025-04-14 20:29:52 --> Config Class Initialized
INFO - 2025-04-14 20:29:52 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:52 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:52 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:52 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:29:52 --> Router Class Initialized
INFO - 2025-04-14 20:29:52 --> Output Class Initialized
INFO - 2025-04-14 20:29:52 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:52 --> Input Class Initialized
INFO - 2025-04-14 20:29:52 --> Language Class Initialized
INFO - 2025-04-14 20:29:52 --> Language Class Initialized
INFO - 2025-04-14 20:29:52 --> Config Class Initialized
INFO - 2025-04-14 20:29:52 --> Loader Class Initialized
INFO - 2025-04-14 20:29:52 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:52 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:52 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:52 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:52 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:52 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:52 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:52 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:52 --> Email Class Initialized
INFO - 2025-04-14 20:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:52 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:52 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:52 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:52 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:29:59 --> Config Class Initialized
INFO - 2025-04-14 20:29:59 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:29:59 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:29:59 --> Utf8 Class Initialized
INFO - 2025-04-14 20:29:59 --> URI Class Initialized
DEBUG - 2025-04-14 20:29:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:29:59 --> Router Class Initialized
INFO - 2025-04-14 20:29:59 --> Output Class Initialized
INFO - 2025-04-14 20:29:59 --> Security Class Initialized
DEBUG - 2025-04-14 20:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:29:59 --> Input Class Initialized
INFO - 2025-04-14 20:29:59 --> Language Class Initialized
INFO - 2025-04-14 20:29:59 --> Language Class Initialized
INFO - 2025-04-14 20:29:59 --> Config Class Initialized
INFO - 2025-04-14 20:29:59 --> Loader Class Initialized
INFO - 2025-04-14 20:29:59 --> Helper loaded: url_helper
INFO - 2025-04-14 20:29:59 --> Helper loaded: file_helper
INFO - 2025-04-14 20:29:59 --> Helper loaded: html_helper
INFO - 2025-04-14 20:29:59 --> Helper loaded: form_helper
INFO - 2025-04-14 20:29:59 --> Helper loaded: text_helper
INFO - 2025-04-14 20:29:59 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:29:59 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:29:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:29:59 --> Database Driver Class Initialized
INFO - 2025-04-14 20:29:59 --> Email Class Initialized
INFO - 2025-04-14 20:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:29:59 --> Form Validation Class Initialized
INFO - 2025-04-14 20:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:29:59 --> Pagination Class Initialized
INFO - 2025-04-14 20:29:59 --> Controller Class Initialized
DEBUG - 2025-04-14 20:29:59 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:01 --> Config Class Initialized
INFO - 2025-04-14 20:30:01 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:01 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:01 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:01 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:01 --> Router Class Initialized
INFO - 2025-04-14 20:30:01 --> Output Class Initialized
INFO - 2025-04-14 20:30:01 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:01 --> Input Class Initialized
INFO - 2025-04-14 20:30:01 --> Language Class Initialized
INFO - 2025-04-14 20:30:01 --> Language Class Initialized
INFO - 2025-04-14 20:30:01 --> Config Class Initialized
INFO - 2025-04-14 20:30:01 --> Loader Class Initialized
INFO - 2025-04-14 20:30:01 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:01 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:01 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:01 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:01 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:01 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:01 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:01 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:01 --> Email Class Initialized
INFO - 2025-04-14 20:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:01 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:01 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:01 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:01 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:03 --> Config Class Initialized
INFO - 2025-04-14 20:30:03 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:03 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:03 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:03 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:03 --> Router Class Initialized
INFO - 2025-04-14 20:30:03 --> Output Class Initialized
INFO - 2025-04-14 20:30:03 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:03 --> Input Class Initialized
INFO - 2025-04-14 20:30:03 --> Language Class Initialized
INFO - 2025-04-14 20:30:03 --> Language Class Initialized
INFO - 2025-04-14 20:30:03 --> Config Class Initialized
INFO - 2025-04-14 20:30:03 --> Loader Class Initialized
INFO - 2025-04-14 20:30:03 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:03 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:03 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:03 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:03 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:03 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:03 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:03 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:03 --> Email Class Initialized
INFO - 2025-04-14 20:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:03 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:03 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:03 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:03 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:11 --> Config Class Initialized
INFO - 2025-04-14 20:30:11 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:11 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:11 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:11 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:11 --> Router Class Initialized
INFO - 2025-04-14 20:30:11 --> Output Class Initialized
INFO - 2025-04-14 20:30:11 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:11 --> Input Class Initialized
INFO - 2025-04-14 20:30:11 --> Language Class Initialized
INFO - 2025-04-14 20:30:11 --> Language Class Initialized
INFO - 2025-04-14 20:30:11 --> Config Class Initialized
INFO - 2025-04-14 20:30:11 --> Loader Class Initialized
INFO - 2025-04-14 20:30:11 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:11 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:11 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:11 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:11 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:11 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:11 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:11 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:11 --> Email Class Initialized
INFO - 2025-04-14 20:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:11 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:11 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:11 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:11 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:12 --> Config Class Initialized
INFO - 2025-04-14 20:30:12 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:12 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:12 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:12 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:12 --> Router Class Initialized
INFO - 2025-04-14 20:30:12 --> Output Class Initialized
INFO - 2025-04-14 20:30:12 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:12 --> Input Class Initialized
INFO - 2025-04-14 20:30:12 --> Language Class Initialized
INFO - 2025-04-14 20:30:12 --> Language Class Initialized
INFO - 2025-04-14 20:30:12 --> Config Class Initialized
INFO - 2025-04-14 20:30:12 --> Loader Class Initialized
INFO - 2025-04-14 20:30:12 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:12 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:12 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:12 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:12 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:12 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:12 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:12 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:12 --> Email Class Initialized
INFO - 2025-04-14 20:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:12 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:12 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:12 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:12 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:15 --> Config Class Initialized
INFO - 2025-04-14 20:30:15 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:15 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:15 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:15 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:15 --> Router Class Initialized
INFO - 2025-04-14 20:30:15 --> Output Class Initialized
INFO - 2025-04-14 20:30:15 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:15 --> Input Class Initialized
INFO - 2025-04-14 20:30:15 --> Language Class Initialized
INFO - 2025-04-14 20:30:15 --> Language Class Initialized
INFO - 2025-04-14 20:30:15 --> Config Class Initialized
INFO - 2025-04-14 20:30:15 --> Loader Class Initialized
INFO - 2025-04-14 20:30:15 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:15 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:15 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:15 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:15 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:15 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:15 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:15 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:15 --> Email Class Initialized
INFO - 2025-04-14 20:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:15 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:15 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:15 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:15 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:25 --> Config Class Initialized
INFO - 2025-04-14 20:30:25 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:25 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:25 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:25 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:25 --> Router Class Initialized
INFO - 2025-04-14 20:30:25 --> Output Class Initialized
INFO - 2025-04-14 20:30:25 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:25 --> Input Class Initialized
INFO - 2025-04-14 20:30:25 --> Language Class Initialized
INFO - 2025-04-14 20:30:25 --> Language Class Initialized
INFO - 2025-04-14 20:30:25 --> Config Class Initialized
INFO - 2025-04-14 20:30:25 --> Loader Class Initialized
INFO - 2025-04-14 20:30:25 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:25 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:25 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:25 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:25 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:25 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:25 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:25 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:25 --> Email Class Initialized
INFO - 2025-04-14 20:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:25 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:25 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:25 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:25 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:27 --> Config Class Initialized
INFO - 2025-04-14 20:30:27 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:27 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:27 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:27 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:27 --> Router Class Initialized
INFO - 2025-04-14 20:30:27 --> Output Class Initialized
INFO - 2025-04-14 20:30:27 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:27 --> Input Class Initialized
INFO - 2025-04-14 20:30:27 --> Language Class Initialized
INFO - 2025-04-14 20:30:27 --> Language Class Initialized
INFO - 2025-04-14 20:30:27 --> Config Class Initialized
INFO - 2025-04-14 20:30:27 --> Loader Class Initialized
INFO - 2025-04-14 20:30:27 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:27 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:27 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:27 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:27 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:27 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:27 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:27 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:27 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:27 --> Email Class Initialized
INFO - 2025-04-14 20:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:27 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:27 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:27 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:27 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:34 --> Config Class Initialized
INFO - 2025-04-14 20:30:34 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:34 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:34 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:34 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:34 --> Router Class Initialized
INFO - 2025-04-14 20:30:34 --> Output Class Initialized
INFO - 2025-04-14 20:30:34 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:34 --> Input Class Initialized
INFO - 2025-04-14 20:30:34 --> Language Class Initialized
INFO - 2025-04-14 20:30:34 --> Language Class Initialized
INFO - 2025-04-14 20:30:34 --> Config Class Initialized
INFO - 2025-04-14 20:30:34 --> Loader Class Initialized
INFO - 2025-04-14 20:30:34 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:34 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:34 --> Email Class Initialized
INFO - 2025-04-14 20:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:34 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:34 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:34 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:34 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:34 --> Config Class Initialized
INFO - 2025-04-14 20:30:34 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:34 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:34 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:34 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:34 --> Router Class Initialized
INFO - 2025-04-14 20:30:34 --> Output Class Initialized
INFO - 2025-04-14 20:30:34 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:34 --> Input Class Initialized
INFO - 2025-04-14 20:30:34 --> Language Class Initialized
INFO - 2025-04-14 20:30:34 --> Language Class Initialized
INFO - 2025-04-14 20:30:34 --> Config Class Initialized
INFO - 2025-04-14 20:30:34 --> Loader Class Initialized
INFO - 2025-04-14 20:30:34 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:34 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:34 --> Email Class Initialized
INFO - 2025-04-14 20:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:34 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:34 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:34 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:34 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:36 --> Config Class Initialized
INFO - 2025-04-14 20:30:36 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:36 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:36 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:36 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:36 --> Router Class Initialized
INFO - 2025-04-14 20:30:36 --> Output Class Initialized
INFO - 2025-04-14 20:30:36 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:36 --> Input Class Initialized
INFO - 2025-04-14 20:30:36 --> Language Class Initialized
INFO - 2025-04-14 20:30:36 --> Language Class Initialized
INFO - 2025-04-14 20:30:36 --> Config Class Initialized
INFO - 2025-04-14 20:30:36 --> Loader Class Initialized
INFO - 2025-04-14 20:30:36 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:36 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:36 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:36 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:36 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:36 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:36 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:36 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:36 --> Email Class Initialized
INFO - 2025-04-14 20:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:36 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:36 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:36 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:36 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:41 --> Config Class Initialized
INFO - 2025-04-14 20:30:41 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:41 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:41 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:41 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:41 --> Router Class Initialized
INFO - 2025-04-14 20:30:41 --> Output Class Initialized
INFO - 2025-04-14 20:30:41 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:41 --> Input Class Initialized
INFO - 2025-04-14 20:30:41 --> Language Class Initialized
INFO - 2025-04-14 20:30:41 --> Language Class Initialized
INFO - 2025-04-14 20:30:41 --> Config Class Initialized
INFO - 2025-04-14 20:30:41 --> Loader Class Initialized
INFO - 2025-04-14 20:30:41 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:41 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:41 --> Email Class Initialized
INFO - 2025-04-14 20:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:41 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:41 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:41 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:41 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:41 --> Config Class Initialized
INFO - 2025-04-14 20:30:41 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:41 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:41 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:41 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:30:41 --> Router Class Initialized
INFO - 2025-04-14 20:30:41 --> Output Class Initialized
INFO - 2025-04-14 20:30:41 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:41 --> Input Class Initialized
INFO - 2025-04-14 20:30:41 --> Language Class Initialized
INFO - 2025-04-14 20:30:41 --> Language Class Initialized
INFO - 2025-04-14 20:30:41 --> Config Class Initialized
INFO - 2025-04-14 20:30:41 --> Loader Class Initialized
INFO - 2025-04-14 20:30:41 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:41 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:41 --> Email Class Initialized
INFO - 2025-04-14 20:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:41 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:41 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:41 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:41 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:30:47 --> Config Class Initialized
INFO - 2025-04-14 20:30:47 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:30:47 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:30:47 --> Utf8 Class Initialized
INFO - 2025-04-14 20:30:47 --> URI Class Initialized
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:30:47 --> Router Class Initialized
INFO - 2025-04-14 20:30:47 --> Output Class Initialized
INFO - 2025-04-14 20:30:47 --> Security Class Initialized
DEBUG - 2025-04-14 20:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:30:47 --> Input Class Initialized
INFO - 2025-04-14 20:30:47 --> Language Class Initialized
INFO - 2025-04-14 20:30:47 --> Language Class Initialized
INFO - 2025-04-14 20:30:47 --> Config Class Initialized
INFO - 2025-04-14 20:30:47 --> Loader Class Initialized
INFO - 2025-04-14 20:30:47 --> Helper loaded: url_helper
INFO - 2025-04-14 20:30:47 --> Helper loaded: file_helper
INFO - 2025-04-14 20:30:47 --> Helper loaded: html_helper
INFO - 2025-04-14 20:30:47 --> Helper loaded: form_helper
INFO - 2025-04-14 20:30:47 --> Helper loaded: text_helper
INFO - 2025-04-14 20:30:47 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:30:47 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:30:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:30:47 --> Database Driver Class Initialized
INFO - 2025-04-14 20:30:47 --> Email Class Initialized
INFO - 2025-04-14 20:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:30:47 --> Form Validation Class Initialized
INFO - 2025-04-14 20:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:30:47 --> Pagination Class Initialized
INFO - 2025-04-14 20:30:47 --> Controller Class Initialized
DEBUG - 2025-04-14 20:30:47 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:30:47 --> Model Class Initialized
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:30:47 --> Model Class Initialized
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:30:47 --> Model Class Initialized
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:30:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:30:47 --> Model Class Initialized
ERROR - 2025-04-14 20:30:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:30:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:30:47 --> Final output sent to browser
DEBUG - 2025-04-14 20:30:47 --> Total execution time: 0.1277
INFO - 2025-04-14 20:31:01 --> Config Class Initialized
INFO - 2025-04-14 20:31:01 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:01 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:01 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:01 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:31:01 --> Router Class Initialized
INFO - 2025-04-14 20:31:01 --> Output Class Initialized
INFO - 2025-04-14 20:31:01 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:01 --> Input Class Initialized
INFO - 2025-04-14 20:31:01 --> Language Class Initialized
INFO - 2025-04-14 20:31:01 --> Language Class Initialized
INFO - 2025-04-14 20:31:01 --> Config Class Initialized
INFO - 2025-04-14 20:31:01 --> Loader Class Initialized
INFO - 2025-04-14 20:31:01 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:01 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:01 --> Email Class Initialized
INFO - 2025-04-14 20:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:01 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:01 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:01 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:01 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:31:01 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:31:01 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:31:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:31:01 --> Model Class Initialized
ERROR - 2025-04-14 20:31:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:31:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:31:01 --> Final output sent to browser
DEBUG - 2025-04-14 20:31:01 --> Total execution time: 0.1248
INFO - 2025-04-14 20:31:01 --> Config Class Initialized
INFO - 2025-04-14 20:31:01 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:01 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:01 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:01 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:31:01 --> Router Class Initialized
INFO - 2025-04-14 20:31:01 --> Output Class Initialized
INFO - 2025-04-14 20:31:01 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:01 --> Input Class Initialized
INFO - 2025-04-14 20:31:01 --> Language Class Initialized
INFO - 2025-04-14 20:31:01 --> Language Class Initialized
INFO - 2025-04-14 20:31:01 --> Config Class Initialized
INFO - 2025-04-14 20:31:01 --> Loader Class Initialized
INFO - 2025-04-14 20:31:01 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:01 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:01 --> Email Class Initialized
INFO - 2025-04-14 20:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:01 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:01 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:01 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:01 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:31:01 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:31:01 --> Model Class Initialized
INFO - 2025-04-14 20:31:01 --> Final output sent to browser
DEBUG - 2025-04-14 20:31:01 --> Total execution time: 0.0205
INFO - 2025-04-14 20:31:15 --> Config Class Initialized
INFO - 2025-04-14 20:31:15 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:15 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:15 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:15 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:31:15 --> Router Class Initialized
INFO - 2025-04-14 20:31:15 --> Output Class Initialized
INFO - 2025-04-14 20:31:15 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:15 --> Input Class Initialized
INFO - 2025-04-14 20:31:15 --> Language Class Initialized
INFO - 2025-04-14 20:31:15 --> Language Class Initialized
INFO - 2025-04-14 20:31:15 --> Config Class Initialized
INFO - 2025-04-14 20:31:15 --> Loader Class Initialized
INFO - 2025-04-14 20:31:15 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:15 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:15 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:15 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:15 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:15 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:15 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:15 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:15 --> Email Class Initialized
INFO - 2025-04-14 20:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:15 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:15 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:15 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:15 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:31:15 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:31:15 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:31:15 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:31:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:31:15 --> Model Class Initialized
ERROR - 2025-04-14 20:31:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:31:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:31:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:31:15 --> Final output sent to browser
DEBUG - 2025-04-14 20:31:15 --> Total execution time: 0.1253
INFO - 2025-04-14 20:31:20 --> Config Class Initialized
INFO - 2025-04-14 20:31:20 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:20 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:20 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:20 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:31:20 --> Router Class Initialized
INFO - 2025-04-14 20:31:20 --> Output Class Initialized
INFO - 2025-04-14 20:31:20 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:20 --> Input Class Initialized
INFO - 2025-04-14 20:31:20 --> Language Class Initialized
INFO - 2025-04-14 20:31:20 --> Language Class Initialized
INFO - 2025-04-14 20:31:20 --> Config Class Initialized
INFO - 2025-04-14 20:31:20 --> Loader Class Initialized
INFO - 2025-04-14 20:31:20 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:20 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:20 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:20 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:20 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:20 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:20 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:20 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:20 --> Email Class Initialized
INFO - 2025-04-14 20:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:20 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:20 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:20 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:20 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:31:20 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:31:20 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:31:20 --> Model Class Initialized
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:31:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:31:20 --> Model Class Initialized
ERROR - 2025-04-14 20:31:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:31:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:31:20 --> Final output sent to browser
DEBUG - 2025-04-14 20:31:20 --> Total execution time: 0.1318
INFO - 2025-04-14 20:31:41 --> Config Class Initialized
INFO - 2025-04-14 20:31:41 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:41 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:41 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:41 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:31:41 --> Router Class Initialized
INFO - 2025-04-14 20:31:41 --> Output Class Initialized
INFO - 2025-04-14 20:31:41 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:41 --> Input Class Initialized
INFO - 2025-04-14 20:31:41 --> Language Class Initialized
INFO - 2025-04-14 20:31:41 --> Language Class Initialized
INFO - 2025-04-14 20:31:41 --> Config Class Initialized
INFO - 2025-04-14 20:31:41 --> Loader Class Initialized
INFO - 2025-04-14 20:31:41 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:41 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:41 --> Email Class Initialized
INFO - 2025-04-14 20:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:41 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:41 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:41 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:41 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:31:41 --> Config Class Initialized
INFO - 2025-04-14 20:31:41 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:41 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:41 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:41 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:31:41 --> Router Class Initialized
INFO - 2025-04-14 20:31:41 --> Output Class Initialized
INFO - 2025-04-14 20:31:41 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:41 --> Input Class Initialized
INFO - 2025-04-14 20:31:41 --> Language Class Initialized
INFO - 2025-04-14 20:31:41 --> Language Class Initialized
INFO - 2025-04-14 20:31:41 --> Config Class Initialized
INFO - 2025-04-14 20:31:41 --> Loader Class Initialized
INFO - 2025-04-14 20:31:41 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:41 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:41 --> Email Class Initialized
INFO - 2025-04-14 20:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:41 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:41 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:41 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:41 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:31:42 --> Config Class Initialized
INFO - 2025-04-14 20:31:42 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:42 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:42 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:42 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:31:42 --> Router Class Initialized
INFO - 2025-04-14 20:31:42 --> Output Class Initialized
INFO - 2025-04-14 20:31:42 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:42 --> Input Class Initialized
INFO - 2025-04-14 20:31:42 --> Language Class Initialized
INFO - 2025-04-14 20:31:42 --> Language Class Initialized
INFO - 2025-04-14 20:31:42 --> Config Class Initialized
INFO - 2025-04-14 20:31:42 --> Loader Class Initialized
INFO - 2025-04-14 20:31:42 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:42 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:42 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:42 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:42 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:42 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:42 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:42 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:42 --> Email Class Initialized
INFO - 2025-04-14 20:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:42 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:42 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:42 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:31:44 --> Config Class Initialized
INFO - 2025-04-14 20:31:44 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:31:44 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:31:44 --> Utf8 Class Initialized
INFO - 2025-04-14 20:31:44 --> URI Class Initialized
DEBUG - 2025-04-14 20:31:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:31:44 --> Router Class Initialized
INFO - 2025-04-14 20:31:44 --> Output Class Initialized
INFO - 2025-04-14 20:31:44 --> Security Class Initialized
DEBUG - 2025-04-14 20:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:31:44 --> Input Class Initialized
INFO - 2025-04-14 20:31:44 --> Language Class Initialized
INFO - 2025-04-14 20:31:44 --> Language Class Initialized
INFO - 2025-04-14 20:31:44 --> Config Class Initialized
INFO - 2025-04-14 20:31:44 --> Loader Class Initialized
INFO - 2025-04-14 20:31:44 --> Helper loaded: url_helper
INFO - 2025-04-14 20:31:44 --> Helper loaded: file_helper
INFO - 2025-04-14 20:31:44 --> Helper loaded: html_helper
INFO - 2025-04-14 20:31:44 --> Helper loaded: form_helper
INFO - 2025-04-14 20:31:44 --> Helper loaded: text_helper
INFO - 2025-04-14 20:31:44 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:31:44 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:31:44 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:31:44 --> Database Driver Class Initialized
INFO - 2025-04-14 20:31:44 --> Email Class Initialized
INFO - 2025-04-14 20:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:31:44 --> Form Validation Class Initialized
INFO - 2025-04-14 20:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:31:44 --> Pagination Class Initialized
INFO - 2025-04-14 20:31:44 --> Controller Class Initialized
DEBUG - 2025-04-14 20:31:44 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:32:00 --> Config Class Initialized
INFO - 2025-04-14 20:32:00 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:00 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:00 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:00 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:32:00 --> Router Class Initialized
INFO - 2025-04-14 20:32:00 --> Output Class Initialized
INFO - 2025-04-14 20:32:00 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:00 --> Input Class Initialized
INFO - 2025-04-14 20:32:00 --> Language Class Initialized
INFO - 2025-04-14 20:32:00 --> Language Class Initialized
INFO - 2025-04-14 20:32:00 --> Config Class Initialized
INFO - 2025-04-14 20:32:00 --> Loader Class Initialized
INFO - 2025-04-14 20:32:00 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:00 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:00 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:00 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:00 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:00 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:00 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:00 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:00 --> Email Class Initialized
INFO - 2025-04-14 20:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:00 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:00 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:00 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:00 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:32:00 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:32:00 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:32:00 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:00 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-14 20:32:00 --> ✅ Proceeding with return_invoice_entry()
ERROR - 2025-04-14 20:32:00 --> Severity: error --> Exception: Unknown column 'quantity' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-04-14 20:32:08 --> Config Class Initialized
INFO - 2025-04-14 20:32:08 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:08 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:08 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:08 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:32:08 --> Router Class Initialized
INFO - 2025-04-14 20:32:08 --> Output Class Initialized
INFO - 2025-04-14 20:32:08 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:08 --> Input Class Initialized
INFO - 2025-04-14 20:32:08 --> Language Class Initialized
INFO - 2025-04-14 20:32:08 --> Language Class Initialized
INFO - 2025-04-14 20:32:08 --> Config Class Initialized
INFO - 2025-04-14 20:32:08 --> Loader Class Initialized
INFO - 2025-04-14 20:32:08 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:08 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:08 --> Email Class Initialized
INFO - 2025-04-14 20:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:08 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:08 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:08 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:08 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:32:08 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:32:08 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:32:08 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:08 --> 🔁 return_invoice() called | finyear: 
ERROR - 2025-04-14 20:32:08 --> ❌ Financial year missing or invalid.
INFO - 2025-04-14 20:32:08 --> Config Class Initialized
INFO - 2025-04-14 20:32:08 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:08 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:08 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:08 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:32:08 --> Router Class Initialized
INFO - 2025-04-14 20:32:08 --> Output Class Initialized
INFO - 2025-04-14 20:32:08 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:08 --> Input Class Initialized
INFO - 2025-04-14 20:32:08 --> Language Class Initialized
INFO - 2025-04-14 20:32:08 --> Language Class Initialized
INFO - 2025-04-14 20:32:08 --> Config Class Initialized
INFO - 2025-04-14 20:32:08 --> Loader Class Initialized
INFO - 2025-04-14 20:32:08 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:08 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:08 --> Email Class Initialized
INFO - 2025-04-14 20:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:08 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:08 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:08 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:08 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:32:08 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:32:08 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:32:08 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:32:08 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:32:08 --> Model Class Initialized
ERROR - 2025-04-14 20:32:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:32:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:32:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:32:08 --> Final output sent to browser
DEBUG - 2025-04-14 20:32:08 --> Total execution time: 0.0939
INFO - 2025-04-14 20:32:13 --> Config Class Initialized
INFO - 2025-04-14 20:32:13 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:13 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:13 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:13 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:32:13 --> Router Class Initialized
INFO - 2025-04-14 20:32:13 --> Output Class Initialized
INFO - 2025-04-14 20:32:13 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:13 --> Input Class Initialized
INFO - 2025-04-14 20:32:13 --> Language Class Initialized
INFO - 2025-04-14 20:32:13 --> Language Class Initialized
INFO - 2025-04-14 20:32:13 --> Config Class Initialized
INFO - 2025-04-14 20:32:13 --> Loader Class Initialized
INFO - 2025-04-14 20:32:13 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:13 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:13 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:13 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:13 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:13 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:13 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:13 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:13 --> Email Class Initialized
INFO - 2025-04-14 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:13 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:13 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:13 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:13 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:32:13 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:32:13 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:32:13 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:32:13 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:32:13 --> Model Class Initialized
ERROR - 2025-04-14 20:32:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:32:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:32:13 --> Final output sent to browser
DEBUG - 2025-04-14 20:32:13 --> Total execution time: 0.1119
INFO - 2025-04-14 20:32:19 --> Config Class Initialized
INFO - 2025-04-14 20:32:19 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:19 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:19 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:19 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:32:19 --> Router Class Initialized
INFO - 2025-04-14 20:32:19 --> Output Class Initialized
INFO - 2025-04-14 20:32:19 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:19 --> Input Class Initialized
INFO - 2025-04-14 20:32:19 --> Language Class Initialized
INFO - 2025-04-14 20:32:19 --> Language Class Initialized
INFO - 2025-04-14 20:32:19 --> Config Class Initialized
INFO - 2025-04-14 20:32:19 --> Loader Class Initialized
INFO - 2025-04-14 20:32:19 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:19 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:19 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:19 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:19 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:19 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:19 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:19 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:19 --> Email Class Initialized
INFO - 2025-04-14 20:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:19 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:19 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:19 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:19 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:32:19 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:32:19 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:32:19 --> Model Class Initialized
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:32:19 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:32:19 --> Model Class Initialized
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 119
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
ERROR - 2025-04-14 20:32:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:32:19 --> Final output sent to browser
DEBUG - 2025-04-14 20:32:19 --> Total execution time: 0.1302
INFO - 2025-04-14 20:32:25 --> Config Class Initialized
INFO - 2025-04-14 20:32:25 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:25 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:25 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:25 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:32:25 --> Router Class Initialized
INFO - 2025-04-14 20:32:25 --> Output Class Initialized
INFO - 2025-04-14 20:32:25 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:25 --> Input Class Initialized
INFO - 2025-04-14 20:32:25 --> Language Class Initialized
INFO - 2025-04-14 20:32:25 --> Language Class Initialized
INFO - 2025-04-14 20:32:25 --> Config Class Initialized
INFO - 2025-04-14 20:32:25 --> Loader Class Initialized
INFO - 2025-04-14 20:32:25 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:25 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:25 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:25 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:25 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:25 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:25 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:25 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:25 --> Email Class Initialized
INFO - 2025-04-14 20:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:25 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:25 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:25 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:25 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:32:25 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:32:25 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:32:25 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:32:25 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:32:25 --> Model Class Initialized
ERROR - 2025-04-14 20:32:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:32:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:32:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:32:25 --> Final output sent to browser
DEBUG - 2025-04-14 20:32:25 --> Total execution time: 0.0955
INFO - 2025-04-14 20:32:33 --> Config Class Initialized
INFO - 2025-04-14 20:32:33 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:33 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:33 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:33 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:32:33 --> Router Class Initialized
INFO - 2025-04-14 20:32:33 --> Output Class Initialized
INFO - 2025-04-14 20:32:33 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:33 --> Input Class Initialized
INFO - 2025-04-14 20:32:33 --> Language Class Initialized
INFO - 2025-04-14 20:32:33 --> Language Class Initialized
INFO - 2025-04-14 20:32:33 --> Config Class Initialized
INFO - 2025-04-14 20:32:33 --> Loader Class Initialized
INFO - 2025-04-14 20:32:33 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:33 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:33 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:33 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:33 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:33 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:33 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:33 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:33 --> Email Class Initialized
INFO - 2025-04-14 20:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:33 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:33 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:33 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:33 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:32:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:32:33 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:32:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:32:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:32:33 --> Model Class Initialized
ERROR - 2025-04-14 20:32:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:32:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:32:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:32:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:32:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:32:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:32:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:32:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:32:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:32:34 --> Final output sent to browser
DEBUG - 2025-04-14 20:32:34 --> Total execution time: 0.1379
INFO - 2025-04-14 20:32:34 --> Config Class Initialized
INFO - 2025-04-14 20:32:34 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:32:34 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:32:34 --> Utf8 Class Initialized
INFO - 2025-04-14 20:32:34 --> URI Class Initialized
DEBUG - 2025-04-14 20:32:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:32:34 --> Router Class Initialized
INFO - 2025-04-14 20:32:34 --> Output Class Initialized
INFO - 2025-04-14 20:32:34 --> Security Class Initialized
DEBUG - 2025-04-14 20:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:32:34 --> Input Class Initialized
INFO - 2025-04-14 20:32:34 --> Language Class Initialized
INFO - 2025-04-14 20:32:34 --> Language Class Initialized
INFO - 2025-04-14 20:32:34 --> Config Class Initialized
INFO - 2025-04-14 20:32:34 --> Loader Class Initialized
INFO - 2025-04-14 20:32:34 --> Helper loaded: url_helper
INFO - 2025-04-14 20:32:34 --> Helper loaded: file_helper
INFO - 2025-04-14 20:32:34 --> Helper loaded: html_helper
INFO - 2025-04-14 20:32:34 --> Helper loaded: form_helper
INFO - 2025-04-14 20:32:34 --> Helper loaded: text_helper
INFO - 2025-04-14 20:32:34 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:32:34 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:32:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:32:34 --> Database Driver Class Initialized
INFO - 2025-04-14 20:32:34 --> Email Class Initialized
INFO - 2025-04-14 20:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:32:34 --> Form Validation Class Initialized
INFO - 2025-04-14 20:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:32:34 --> Pagination Class Initialized
INFO - 2025-04-14 20:32:34 --> Controller Class Initialized
DEBUG - 2025-04-14 20:32:34 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:32:34 --> Model Class Initialized
DEBUG - 2025-04-14 20:32:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:32:34 --> Model Class Initialized
INFO - 2025-04-14 20:32:34 --> Final output sent to browser
DEBUG - 2025-04-14 20:32:34 --> Total execution time: 0.0231
INFO - 2025-04-14 20:33:02 --> Config Class Initialized
INFO - 2025-04-14 20:33:02 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:02 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:02 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:02 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:02 --> Router Class Initialized
INFO - 2025-04-14 20:33:02 --> Output Class Initialized
INFO - 2025-04-14 20:33:02 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:02 --> Input Class Initialized
INFO - 2025-04-14 20:33:02 --> Language Class Initialized
INFO - 2025-04-14 20:33:02 --> Language Class Initialized
INFO - 2025-04-14 20:33:02 --> Config Class Initialized
INFO - 2025-04-14 20:33:02 --> Loader Class Initialized
INFO - 2025-04-14 20:33:02 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:02 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:02 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:02 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:02 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:02 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:02 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:02 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:02 --> Email Class Initialized
INFO - 2025-04-14 20:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:02 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:02 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:02 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:02 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:07 --> Config Class Initialized
INFO - 2025-04-14 20:33:07 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:07 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:07 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:07 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:07 --> Router Class Initialized
INFO - 2025-04-14 20:33:07 --> Output Class Initialized
INFO - 2025-04-14 20:33:07 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:07 --> Input Class Initialized
INFO - 2025-04-14 20:33:07 --> Language Class Initialized
INFO - 2025-04-14 20:33:07 --> Language Class Initialized
INFO - 2025-04-14 20:33:07 --> Config Class Initialized
INFO - 2025-04-14 20:33:07 --> Loader Class Initialized
INFO - 2025-04-14 20:33:07 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:07 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:07 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:07 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:07 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:07 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:07 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:07 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:07 --> Email Class Initialized
INFO - 2025-04-14 20:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:07 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:07 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:07 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:07 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:09 --> Config Class Initialized
INFO - 2025-04-14 20:33:09 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:09 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:09 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:09 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:09 --> Router Class Initialized
INFO - 2025-04-14 20:33:09 --> Output Class Initialized
INFO - 2025-04-14 20:33:09 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:09 --> Input Class Initialized
INFO - 2025-04-14 20:33:09 --> Language Class Initialized
INFO - 2025-04-14 20:33:09 --> Language Class Initialized
INFO - 2025-04-14 20:33:09 --> Config Class Initialized
INFO - 2025-04-14 20:33:09 --> Loader Class Initialized
INFO - 2025-04-14 20:33:09 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:09 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:09 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:09 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:09 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:09 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:09 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:09 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:09 --> Email Class Initialized
INFO - 2025-04-14 20:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:09 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:09 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:09 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:09 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:14 --> Config Class Initialized
INFO - 2025-04-14 20:33:14 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:14 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:14 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:14 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:14 --> Router Class Initialized
INFO - 2025-04-14 20:33:14 --> Output Class Initialized
INFO - 2025-04-14 20:33:14 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:14 --> Input Class Initialized
INFO - 2025-04-14 20:33:14 --> Language Class Initialized
INFO - 2025-04-14 20:33:14 --> Language Class Initialized
INFO - 2025-04-14 20:33:14 --> Config Class Initialized
INFO - 2025-04-14 20:33:14 --> Loader Class Initialized
INFO - 2025-04-14 20:33:14 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:14 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:14 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:14 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:14 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:14 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:14 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:14 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:14 --> Email Class Initialized
INFO - 2025-04-14 20:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:14 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:14 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:14 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:14 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:16 --> Config Class Initialized
INFO - 2025-04-14 20:33:16 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:16 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:16 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:16 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:16 --> Router Class Initialized
INFO - 2025-04-14 20:33:16 --> Output Class Initialized
INFO - 2025-04-14 20:33:16 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:16 --> Input Class Initialized
INFO - 2025-04-14 20:33:16 --> Language Class Initialized
INFO - 2025-04-14 20:33:16 --> Language Class Initialized
INFO - 2025-04-14 20:33:16 --> Config Class Initialized
INFO - 2025-04-14 20:33:16 --> Loader Class Initialized
INFO - 2025-04-14 20:33:16 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:16 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:16 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:16 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:16 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:16 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:16 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:16 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:16 --> Email Class Initialized
INFO - 2025-04-14 20:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:16 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:16 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:16 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:17 --> Config Class Initialized
INFO - 2025-04-14 20:33:17 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:17 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:17 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:17 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:17 --> Router Class Initialized
INFO - 2025-04-14 20:33:17 --> Output Class Initialized
INFO - 2025-04-14 20:33:17 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:17 --> Input Class Initialized
INFO - 2025-04-14 20:33:17 --> Language Class Initialized
INFO - 2025-04-14 20:33:17 --> Language Class Initialized
INFO - 2025-04-14 20:33:17 --> Config Class Initialized
INFO - 2025-04-14 20:33:17 --> Loader Class Initialized
INFO - 2025-04-14 20:33:17 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:17 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:17 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:17 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:17 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:17 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:17 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:17 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:17 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:17 --> Email Class Initialized
INFO - 2025-04-14 20:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:17 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:17 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:17 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:17 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:24 --> Config Class Initialized
INFO - 2025-04-14 20:33:24 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:24 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:24 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:24 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:24 --> Router Class Initialized
INFO - 2025-04-14 20:33:24 --> Output Class Initialized
INFO - 2025-04-14 20:33:24 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:24 --> Input Class Initialized
INFO - 2025-04-14 20:33:24 --> Language Class Initialized
INFO - 2025-04-14 20:33:24 --> Language Class Initialized
INFO - 2025-04-14 20:33:24 --> Config Class Initialized
INFO - 2025-04-14 20:33:24 --> Loader Class Initialized
INFO - 2025-04-14 20:33:24 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:24 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:24 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:24 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:24 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:24 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:24 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:24 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:24 --> Email Class Initialized
INFO - 2025-04-14 20:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:24 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:24 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:24 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:24 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:26 --> Config Class Initialized
INFO - 2025-04-14 20:33:26 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:26 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:26 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:26 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:26 --> Router Class Initialized
INFO - 2025-04-14 20:33:26 --> Output Class Initialized
INFO - 2025-04-14 20:33:26 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:26 --> Input Class Initialized
INFO - 2025-04-14 20:33:26 --> Language Class Initialized
INFO - 2025-04-14 20:33:26 --> Language Class Initialized
INFO - 2025-04-14 20:33:26 --> Config Class Initialized
INFO - 2025-04-14 20:33:26 --> Loader Class Initialized
INFO - 2025-04-14 20:33:26 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:26 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:26 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:26 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:26 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:26 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:26 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:26 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:26 --> Email Class Initialized
INFO - 2025-04-14 20:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:26 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:26 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:26 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:26 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:31 --> Config Class Initialized
INFO - 2025-04-14 20:33:31 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:31 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:31 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:31 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:31 --> Router Class Initialized
INFO - 2025-04-14 20:33:31 --> Output Class Initialized
INFO - 2025-04-14 20:33:31 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:31 --> Input Class Initialized
INFO - 2025-04-14 20:33:31 --> Language Class Initialized
INFO - 2025-04-14 20:33:31 --> Language Class Initialized
INFO - 2025-04-14 20:33:31 --> Config Class Initialized
INFO - 2025-04-14 20:33:31 --> Loader Class Initialized
INFO - 2025-04-14 20:33:31 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:31 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:31 --> Email Class Initialized
INFO - 2025-04-14 20:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:31 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:31 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:31 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:31 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:31 --> Config Class Initialized
INFO - 2025-04-14 20:33:31 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:31 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:31 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:31 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:31 --> Router Class Initialized
INFO - 2025-04-14 20:33:31 --> Output Class Initialized
INFO - 2025-04-14 20:33:31 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:31 --> Input Class Initialized
INFO - 2025-04-14 20:33:31 --> Language Class Initialized
INFO - 2025-04-14 20:33:31 --> Language Class Initialized
INFO - 2025-04-14 20:33:31 --> Config Class Initialized
INFO - 2025-04-14 20:33:31 --> Loader Class Initialized
INFO - 2025-04-14 20:33:31 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:31 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:31 --> Email Class Initialized
INFO - 2025-04-14 20:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:31 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:31 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:31 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:31 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:34 --> Config Class Initialized
INFO - 2025-04-14 20:33:34 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:34 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:34 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:34 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:33:34 --> Router Class Initialized
INFO - 2025-04-14 20:33:34 --> Output Class Initialized
INFO - 2025-04-14 20:33:34 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:34 --> Input Class Initialized
INFO - 2025-04-14 20:33:34 --> Language Class Initialized
INFO - 2025-04-14 20:33:34 --> Language Class Initialized
INFO - 2025-04-14 20:33:34 --> Config Class Initialized
INFO - 2025-04-14 20:33:34 --> Loader Class Initialized
INFO - 2025-04-14 20:33:34 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:34 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:34 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:34 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:34 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:34 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:34 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:34 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:34 --> Email Class Initialized
INFO - 2025-04-14 20:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:34 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:34 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:34 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:34 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:33:40 --> Config Class Initialized
INFO - 2025-04-14 20:33:40 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:40 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:40 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:40 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:33:40 --> Router Class Initialized
INFO - 2025-04-14 20:33:40 --> Output Class Initialized
INFO - 2025-04-14 20:33:40 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:40 --> Input Class Initialized
INFO - 2025-04-14 20:33:40 --> Language Class Initialized
INFO - 2025-04-14 20:33:40 --> Language Class Initialized
INFO - 2025-04-14 20:33:40 --> Config Class Initialized
INFO - 2025-04-14 20:33:40 --> Loader Class Initialized
INFO - 2025-04-14 20:33:40 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:40 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:40 --> Email Class Initialized
INFO - 2025-04-14 20:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:40 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:40 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:40 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:40 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:33:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:33:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:33:40 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:33:40 --> Model Class Initialized
ERROR - 2025-04-14 20:33:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:33:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:33:40 --> Final output sent to browser
DEBUG - 2025-04-14 20:33:40 --> Total execution time: 0.1157
INFO - 2025-04-14 20:33:40 --> Config Class Initialized
INFO - 2025-04-14 20:33:40 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:40 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:40 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:40 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:33:40 --> Router Class Initialized
INFO - 2025-04-14 20:33:40 --> Output Class Initialized
INFO - 2025-04-14 20:33:40 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:40 --> Input Class Initialized
INFO - 2025-04-14 20:33:40 --> Language Class Initialized
INFO - 2025-04-14 20:33:40 --> Language Class Initialized
INFO - 2025-04-14 20:33:40 --> Config Class Initialized
INFO - 2025-04-14 20:33:40 --> Loader Class Initialized
INFO - 2025-04-14 20:33:40 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:40 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:40 --> Email Class Initialized
INFO - 2025-04-14 20:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:40 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:40 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:40 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:40 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:33:40 --> Model Class Initialized
DEBUG - 2025-04-14 20:33:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:33:40 --> Model Class Initialized
INFO - 2025-04-14 20:33:40 --> Final output sent to browser
DEBUG - 2025-04-14 20:33:40 --> Total execution time: 0.0133
INFO - 2025-04-14 20:33:55 --> Config Class Initialized
INFO - 2025-04-14 20:33:55 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:33:55 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:33:55 --> Utf8 Class Initialized
INFO - 2025-04-14 20:33:55 --> URI Class Initialized
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:33:55 --> Router Class Initialized
INFO - 2025-04-14 20:33:55 --> Output Class Initialized
INFO - 2025-04-14 20:33:55 --> Security Class Initialized
DEBUG - 2025-04-14 20:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:33:55 --> Input Class Initialized
INFO - 2025-04-14 20:33:55 --> Language Class Initialized
INFO - 2025-04-14 20:33:55 --> Language Class Initialized
INFO - 2025-04-14 20:33:55 --> Config Class Initialized
INFO - 2025-04-14 20:33:55 --> Loader Class Initialized
INFO - 2025-04-14 20:33:55 --> Helper loaded: url_helper
INFO - 2025-04-14 20:33:55 --> Helper loaded: file_helper
INFO - 2025-04-14 20:33:55 --> Helper loaded: html_helper
INFO - 2025-04-14 20:33:55 --> Helper loaded: form_helper
INFO - 2025-04-14 20:33:55 --> Helper loaded: text_helper
INFO - 2025-04-14 20:33:55 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:33:55 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:33:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:33:55 --> Database Driver Class Initialized
INFO - 2025-04-14 20:33:55 --> Email Class Initialized
INFO - 2025-04-14 20:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:33:55 --> Form Validation Class Initialized
INFO - 2025-04-14 20:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:33:55 --> Pagination Class Initialized
INFO - 2025-04-14 20:33:55 --> Controller Class Initialized
DEBUG - 2025-04-14 20:33:55 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:33:55 --> Model Class Initialized
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:33:55 --> Model Class Initialized
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:33:55 --> Model Class Initialized
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:33:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:33:55 --> Model Class Initialized
ERROR - 2025-04-14 20:33:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:33:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:33:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:33:55 --> Final output sent to browser
DEBUG - 2025-04-14 20:33:55 --> Total execution time: 0.1204
INFO - 2025-04-14 20:34:03 --> Config Class Initialized
INFO - 2025-04-14 20:34:03 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:34:03 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:34:03 --> Utf8 Class Initialized
INFO - 2025-04-14 20:34:03 --> URI Class Initialized
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:34:03 --> Router Class Initialized
INFO - 2025-04-14 20:34:03 --> Output Class Initialized
INFO - 2025-04-14 20:34:03 --> Security Class Initialized
DEBUG - 2025-04-14 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:34:03 --> Input Class Initialized
INFO - 2025-04-14 20:34:03 --> Language Class Initialized
INFO - 2025-04-14 20:34:03 --> Language Class Initialized
INFO - 2025-04-14 20:34:03 --> Config Class Initialized
INFO - 2025-04-14 20:34:03 --> Loader Class Initialized
INFO - 2025-04-14 20:34:03 --> Helper loaded: url_helper
INFO - 2025-04-14 20:34:03 --> Helper loaded: file_helper
INFO - 2025-04-14 20:34:03 --> Helper loaded: html_helper
INFO - 2025-04-14 20:34:03 --> Helper loaded: form_helper
INFO - 2025-04-14 20:34:03 --> Helper loaded: text_helper
INFO - 2025-04-14 20:34:03 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:34:03 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:34:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:34:03 --> Database Driver Class Initialized
INFO - 2025-04-14 20:34:03 --> Email Class Initialized
INFO - 2025-04-14 20:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:34:03 --> Form Validation Class Initialized
INFO - 2025-04-14 20:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:34:03 --> Pagination Class Initialized
INFO - 2025-04-14 20:34:03 --> Controller Class Initialized
DEBUG - 2025-04-14 20:34:03 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:34:03 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:34:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:34:03 --> Model Class Initialized
ERROR - 2025-04-14 20:34:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:34:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:34:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:34:03 --> Final output sent to browser
DEBUG - 2025-04-14 20:34:03 --> Total execution time: 0.1344
INFO - 2025-04-14 20:34:23 --> Config Class Initialized
INFO - 2025-04-14 20:34:23 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:34:23 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:34:23 --> Utf8 Class Initialized
INFO - 2025-04-14 20:34:23 --> URI Class Initialized
DEBUG - 2025-04-14 20:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:34:23 --> Router Class Initialized
INFO - 2025-04-14 20:34:23 --> Output Class Initialized
INFO - 2025-04-14 20:34:23 --> Security Class Initialized
DEBUG - 2025-04-14 20:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:34:23 --> Input Class Initialized
INFO - 2025-04-14 20:34:23 --> Language Class Initialized
INFO - 2025-04-14 20:34:23 --> Language Class Initialized
INFO - 2025-04-14 20:34:23 --> Config Class Initialized
INFO - 2025-04-14 20:34:23 --> Loader Class Initialized
INFO - 2025-04-14 20:34:23 --> Helper loaded: url_helper
INFO - 2025-04-14 20:34:23 --> Helper loaded: file_helper
INFO - 2025-04-14 20:34:23 --> Helper loaded: html_helper
INFO - 2025-04-14 20:34:23 --> Helper loaded: form_helper
INFO - 2025-04-14 20:34:23 --> Helper loaded: text_helper
INFO - 2025-04-14 20:34:23 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:34:23 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:34:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:34:23 --> Database Driver Class Initialized
INFO - 2025-04-14 20:34:23 --> Email Class Initialized
INFO - 2025-04-14 20:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:34:23 --> Form Validation Class Initialized
INFO - 2025-04-14 20:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:34:23 --> Pagination Class Initialized
INFO - 2025-04-14 20:34:23 --> Controller Class Initialized
DEBUG - 2025-04-14 20:34:23 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:34:24 --> Config Class Initialized
INFO - 2025-04-14 20:34:24 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:34:24 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:34:24 --> Utf8 Class Initialized
INFO - 2025-04-14 20:34:24 --> URI Class Initialized
DEBUG - 2025-04-14 20:34:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:34:24 --> Router Class Initialized
INFO - 2025-04-14 20:34:24 --> Output Class Initialized
INFO - 2025-04-14 20:34:24 --> Security Class Initialized
DEBUG - 2025-04-14 20:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:34:24 --> Input Class Initialized
INFO - 2025-04-14 20:34:24 --> Language Class Initialized
INFO - 2025-04-14 20:34:24 --> Language Class Initialized
INFO - 2025-04-14 20:34:24 --> Config Class Initialized
INFO - 2025-04-14 20:34:24 --> Loader Class Initialized
INFO - 2025-04-14 20:34:24 --> Helper loaded: url_helper
INFO - 2025-04-14 20:34:24 --> Helper loaded: file_helper
INFO - 2025-04-14 20:34:24 --> Helper loaded: html_helper
INFO - 2025-04-14 20:34:24 --> Helper loaded: form_helper
INFO - 2025-04-14 20:34:24 --> Helper loaded: text_helper
INFO - 2025-04-14 20:34:24 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:34:24 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:34:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:34:24 --> Database Driver Class Initialized
INFO - 2025-04-14 20:34:24 --> Email Class Initialized
INFO - 2025-04-14 20:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:34:24 --> Form Validation Class Initialized
INFO - 2025-04-14 20:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:34:24 --> Pagination Class Initialized
INFO - 2025-04-14 20:34:24 --> Controller Class Initialized
DEBUG - 2025-04-14 20:34:24 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:34:29 --> Config Class Initialized
INFO - 2025-04-14 20:34:29 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:34:29 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:34:29 --> Utf8 Class Initialized
INFO - 2025-04-14 20:34:29 --> URI Class Initialized
DEBUG - 2025-04-14 20:34:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-14 20:34:29 --> Router Class Initialized
INFO - 2025-04-14 20:34:29 --> Output Class Initialized
INFO - 2025-04-14 20:34:29 --> Security Class Initialized
DEBUG - 2025-04-14 20:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:34:29 --> Input Class Initialized
INFO - 2025-04-14 20:34:29 --> Language Class Initialized
INFO - 2025-04-14 20:34:29 --> Language Class Initialized
INFO - 2025-04-14 20:34:29 --> Config Class Initialized
INFO - 2025-04-14 20:34:29 --> Loader Class Initialized
INFO - 2025-04-14 20:34:29 --> Helper loaded: url_helper
INFO - 2025-04-14 20:34:29 --> Helper loaded: file_helper
INFO - 2025-04-14 20:34:29 --> Helper loaded: html_helper
INFO - 2025-04-14 20:34:29 --> Helper loaded: form_helper
INFO - 2025-04-14 20:34:29 --> Helper loaded: text_helper
INFO - 2025-04-14 20:34:29 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:34:29 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:34:29 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:34:29 --> Database Driver Class Initialized
INFO - 2025-04-14 20:34:29 --> Email Class Initialized
INFO - 2025-04-14 20:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:34:29 --> Form Validation Class Initialized
INFO - 2025-04-14 20:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:34:29 --> Pagination Class Initialized
INFO - 2025-04-14 20:34:29 --> Controller Class Initialized
DEBUG - 2025-04-14 20:34:29 --> Invoice MX_Controller Initialized
INFO - 2025-04-14 20:34:44 --> Config Class Initialized
INFO - 2025-04-14 20:34:44 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:34:44 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:34:44 --> Utf8 Class Initialized
INFO - 2025-04-14 20:34:44 --> URI Class Initialized
DEBUG - 2025-04-14 20:34:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:34:44 --> Router Class Initialized
INFO - 2025-04-14 20:34:44 --> Output Class Initialized
INFO - 2025-04-14 20:34:44 --> Security Class Initialized
DEBUG - 2025-04-14 20:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:34:44 --> Input Class Initialized
INFO - 2025-04-14 20:34:44 --> Language Class Initialized
INFO - 2025-04-14 20:34:44 --> Language Class Initialized
INFO - 2025-04-14 20:34:44 --> Config Class Initialized
INFO - 2025-04-14 20:34:44 --> Loader Class Initialized
INFO - 2025-04-14 20:34:44 --> Helper loaded: url_helper
INFO - 2025-04-14 20:34:44 --> Helper loaded: file_helper
INFO - 2025-04-14 20:34:44 --> Helper loaded: html_helper
INFO - 2025-04-14 20:34:44 --> Helper loaded: form_helper
INFO - 2025-04-14 20:34:44 --> Helper loaded: text_helper
INFO - 2025-04-14 20:34:44 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:34:44 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:34:44 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:34:44 --> Database Driver Class Initialized
INFO - 2025-04-14 20:34:44 --> Email Class Initialized
INFO - 2025-04-14 20:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:34:44 --> Form Validation Class Initialized
INFO - 2025-04-14 20:34:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:34:44 --> Pagination Class Initialized
INFO - 2025-04-14 20:34:44 --> Controller Class Initialized
DEBUG - 2025-04-14 20:34:44 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:34:44 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:34:44 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:34:44 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:44 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-14 20:34:44 --> ✅ Proceeding with return_invoice_entry()
ERROR - 2025-04-14 20:34:44 --> Severity: error --> Exception: Unknown column 'quantity' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-04-14 20:34:57 --> Config Class Initialized
INFO - 2025-04-14 20:34:57 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:34:57 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:34:57 --> Utf8 Class Initialized
INFO - 2025-04-14 20:34:57 --> URI Class Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:34:57 --> Router Class Initialized
INFO - 2025-04-14 20:34:57 --> Output Class Initialized
INFO - 2025-04-14 20:34:57 --> Security Class Initialized
DEBUG - 2025-04-14 20:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:34:57 --> Input Class Initialized
INFO - 2025-04-14 20:34:57 --> Language Class Initialized
INFO - 2025-04-14 20:34:57 --> Language Class Initialized
INFO - 2025-04-14 20:34:57 --> Config Class Initialized
INFO - 2025-04-14 20:34:57 --> Loader Class Initialized
INFO - 2025-04-14 20:34:57 --> Helper loaded: url_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: file_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: html_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: form_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: text_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:34:57 --> Database Driver Class Initialized
INFO - 2025-04-14 20:34:57 --> Email Class Initialized
INFO - 2025-04-14 20:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:34:57 --> Form Validation Class Initialized
INFO - 2025-04-14 20:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:34:57 --> Pagination Class Initialized
INFO - 2025-04-14 20:34:57 --> Controller Class Initialized
DEBUG - 2025-04-14 20:34:57 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:34:57 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:34:57 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:34:57 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:57 --> 🔁 return_invoice() called | finyear: 
ERROR - 2025-04-14 20:34:57 --> ❌ Financial year missing or invalid.
INFO - 2025-04-14 20:34:57 --> Config Class Initialized
INFO - 2025-04-14 20:34:57 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:34:57 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:34:57 --> Utf8 Class Initialized
INFO - 2025-04-14 20:34:57 --> URI Class Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:34:57 --> Router Class Initialized
INFO - 2025-04-14 20:34:57 --> Output Class Initialized
INFO - 2025-04-14 20:34:57 --> Security Class Initialized
DEBUG - 2025-04-14 20:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:34:57 --> Input Class Initialized
INFO - 2025-04-14 20:34:57 --> Language Class Initialized
INFO - 2025-04-14 20:34:57 --> Language Class Initialized
INFO - 2025-04-14 20:34:57 --> Config Class Initialized
INFO - 2025-04-14 20:34:57 --> Loader Class Initialized
INFO - 2025-04-14 20:34:57 --> Helper loaded: url_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: file_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: html_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: form_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: text_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:34:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:34:57 --> Database Driver Class Initialized
INFO - 2025-04-14 20:34:57 --> Email Class Initialized
INFO - 2025-04-14 20:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:34:57 --> Form Validation Class Initialized
INFO - 2025-04-14 20:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:34:57 --> Pagination Class Initialized
INFO - 2025-04-14 20:34:57 --> Controller Class Initialized
DEBUG - 2025-04-14 20:34:57 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:34:57 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:34:57 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:34:57 --> Model Class Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:34:57 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:34:57 --> Model Class Initialized
ERROR - 2025-04-14 20:34:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:34:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:34:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:34:57 --> Final output sent to browser
DEBUG - 2025-04-14 20:34:57 --> Total execution time: 0.1225
INFO - 2025-04-14 20:35:12 --> Config Class Initialized
INFO - 2025-04-14 20:35:12 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:35:12 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:35:12 --> Utf8 Class Initialized
INFO - 2025-04-14 20:35:12 --> URI Class Initialized
DEBUG - 2025-04-14 20:35:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:35:12 --> Router Class Initialized
INFO - 2025-04-14 20:35:12 --> Output Class Initialized
INFO - 2025-04-14 20:35:12 --> Security Class Initialized
DEBUG - 2025-04-14 20:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:35:12 --> Input Class Initialized
INFO - 2025-04-14 20:35:12 --> Language Class Initialized
INFO - 2025-04-14 20:35:12 --> Language Class Initialized
INFO - 2025-04-14 20:35:12 --> Config Class Initialized
INFO - 2025-04-14 20:35:12 --> Loader Class Initialized
INFO - 2025-04-14 20:35:12 --> Helper loaded: url_helper
INFO - 2025-04-14 20:35:12 --> Helper loaded: file_helper
INFO - 2025-04-14 20:35:12 --> Helper loaded: html_helper
INFO - 2025-04-14 20:35:12 --> Helper loaded: form_helper
INFO - 2025-04-14 20:35:12 --> Helper loaded: text_helper
INFO - 2025-04-14 20:35:12 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:35:12 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:35:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:35:12 --> Database Driver Class Initialized
INFO - 2025-04-14 20:35:12 --> Email Class Initialized
INFO - 2025-04-14 20:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:35:12 --> Form Validation Class Initialized
INFO - 2025-04-14 20:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:35:12 --> Pagination Class Initialized
INFO - 2025-04-14 20:35:12 --> Controller Class Initialized
DEBUG - 2025-04-14 20:35:12 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:35:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:35:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:35:12 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:35:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:35:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:35:12 --> Model Class Initialized
ERROR - 2025-04-14 20:35:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:35:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:35:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:35:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:35:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:35:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:35:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:35:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:35:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:35:13 --> Final output sent to browser
DEBUG - 2025-04-14 20:35:13 --> Total execution time: 0.1175
INFO - 2025-04-14 20:35:15 --> Config Class Initialized
INFO - 2025-04-14 20:35:15 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:35:15 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:35:15 --> Utf8 Class Initialized
INFO - 2025-04-14 20:35:15 --> URI Class Initialized
DEBUG - 2025-04-14 20:35:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:35:15 --> Router Class Initialized
INFO - 2025-04-14 20:35:15 --> Output Class Initialized
INFO - 2025-04-14 20:35:15 --> Security Class Initialized
DEBUG - 2025-04-14 20:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:35:15 --> Input Class Initialized
INFO - 2025-04-14 20:35:15 --> Language Class Initialized
INFO - 2025-04-14 20:35:15 --> Language Class Initialized
INFO - 2025-04-14 20:35:15 --> Config Class Initialized
INFO - 2025-04-14 20:35:15 --> Loader Class Initialized
INFO - 2025-04-14 20:35:15 --> Helper loaded: url_helper
INFO - 2025-04-14 20:35:15 --> Helper loaded: file_helper
INFO - 2025-04-14 20:35:15 --> Helper loaded: html_helper
INFO - 2025-04-14 20:35:15 --> Helper loaded: form_helper
INFO - 2025-04-14 20:35:15 --> Helper loaded: text_helper
INFO - 2025-04-14 20:35:15 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:35:15 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:35:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:35:15 --> Database Driver Class Initialized
INFO - 2025-04-14 20:35:15 --> Email Class Initialized
INFO - 2025-04-14 20:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:35:15 --> Form Validation Class Initialized
INFO - 2025-04-14 20:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:35:15 --> Pagination Class Initialized
INFO - 2025-04-14 20:35:15 --> Controller Class Initialized
DEBUG - 2025-04-14 20:35:15 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:35:15 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:35:15 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:35:15 --> Model Class Initialized
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
DEBUG - 2025-04-14 20:35:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:35:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:35:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:35:15 --> Model Class Initialized
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:35:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:35:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:35:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-14 20:35:16 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:35:16 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-14 20:35:16 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 119
ERROR - 2025-04-14 20:35:16 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:35:16 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-14 20:35:16 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
ERROR - 2025-04-14 20:35:16 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
DEBUG - 2025-04-14 20:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-14 20:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:35:16 --> Final output sent to browser
DEBUG - 2025-04-14 20:35:16 --> Total execution time: 0.1099
INFO - 2025-04-14 20:35:17 --> Config Class Initialized
INFO - 2025-04-14 20:35:17 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:35:17 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:35:17 --> Utf8 Class Initialized
INFO - 2025-04-14 20:35:17 --> URI Class Initialized
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-14 20:35:17 --> Router Class Initialized
INFO - 2025-04-14 20:35:17 --> Output Class Initialized
INFO - 2025-04-14 20:35:17 --> Security Class Initialized
DEBUG - 2025-04-14 20:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:35:17 --> Input Class Initialized
INFO - 2025-04-14 20:35:17 --> Language Class Initialized
INFO - 2025-04-14 20:35:17 --> Language Class Initialized
INFO - 2025-04-14 20:35:17 --> Config Class Initialized
INFO - 2025-04-14 20:35:17 --> Loader Class Initialized
INFO - 2025-04-14 20:35:17 --> Helper loaded: url_helper
INFO - 2025-04-14 20:35:17 --> Helper loaded: file_helper
INFO - 2025-04-14 20:35:17 --> Helper loaded: html_helper
INFO - 2025-04-14 20:35:17 --> Helper loaded: form_helper
INFO - 2025-04-14 20:35:17 --> Helper loaded: text_helper
INFO - 2025-04-14 20:35:17 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:35:17 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:35:17 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:35:17 --> Database Driver Class Initialized
INFO - 2025-04-14 20:35:17 --> Email Class Initialized
INFO - 2025-04-14 20:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:35:17 --> Form Validation Class Initialized
INFO - 2025-04-14 20:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:35:17 --> Pagination Class Initialized
INFO - 2025-04-14 20:35:17 --> Controller Class Initialized
DEBUG - 2025-04-14 20:35:17 --> Returns MX_Controller Initialized
INFO - 2025-04-14 20:35:17 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-14 20:35:17 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-14 20:35:17 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:35:17 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:35:17 --> Model Class Initialized
ERROR - 2025-04-14 20:35:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:35:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:35:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:35:17 --> Final output sent to browser
DEBUG - 2025-04-14 20:35:17 --> Total execution time: 0.1160
INFO - 2025-04-14 20:35:24 --> Config Class Initialized
INFO - 2025-04-14 20:35:24 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:35:24 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:35:24 --> Utf8 Class Initialized
INFO - 2025-04-14 20:35:24 --> URI Class Initialized
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:35:24 --> Router Class Initialized
INFO - 2025-04-14 20:35:24 --> Output Class Initialized
INFO - 2025-04-14 20:35:24 --> Security Class Initialized
DEBUG - 2025-04-14 20:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:35:24 --> Input Class Initialized
INFO - 2025-04-14 20:35:24 --> Language Class Initialized
INFO - 2025-04-14 20:35:24 --> Language Class Initialized
INFO - 2025-04-14 20:35:24 --> Config Class Initialized
INFO - 2025-04-14 20:35:24 --> Loader Class Initialized
INFO - 2025-04-14 20:35:24 --> Helper loaded: url_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: file_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: html_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: form_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: text_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:35:24 --> Database Driver Class Initialized
INFO - 2025-04-14 20:35:24 --> Email Class Initialized
INFO - 2025-04-14 20:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:35:24 --> Form Validation Class Initialized
INFO - 2025-04-14 20:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:35:24 --> Pagination Class Initialized
INFO - 2025-04-14 20:35:24 --> Controller Class Initialized
DEBUG - 2025-04-14 20:35:24 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:35:24 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:35:24 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-14 20:35:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-14 20:35:24 --> Model Class Initialized
ERROR - 2025-04-14 20:35:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-14 20:35:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-14 20:35:24 --> Final output sent to browser
DEBUG - 2025-04-14 20:35:24 --> Total execution time: 0.1190
INFO - 2025-04-14 20:35:24 --> Config Class Initialized
INFO - 2025-04-14 20:35:24 --> Hooks Class Initialized
DEBUG - 2025-04-14 20:35:24 --> UTF-8 Support Enabled
INFO - 2025-04-14 20:35:24 --> Utf8 Class Initialized
INFO - 2025-04-14 20:35:24 --> URI Class Initialized
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-14 20:35:24 --> Router Class Initialized
INFO - 2025-04-14 20:35:24 --> Output Class Initialized
INFO - 2025-04-14 20:35:24 --> Security Class Initialized
DEBUG - 2025-04-14 20:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-14 20:35:24 --> Input Class Initialized
INFO - 2025-04-14 20:35:24 --> Language Class Initialized
INFO - 2025-04-14 20:35:24 --> Language Class Initialized
INFO - 2025-04-14 20:35:24 --> Config Class Initialized
INFO - 2025-04-14 20:35:24 --> Loader Class Initialized
INFO - 2025-04-14 20:35:24 --> Helper loaded: url_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: file_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: html_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: form_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: text_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: lang_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: directory_helper
INFO - 2025-04-14 20:35:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-14 20:35:24 --> Database Driver Class Initialized
INFO - 2025-04-14 20:35:24 --> Email Class Initialized
INFO - 2025-04-14 20:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-14 20:35:24 --> Form Validation Class Initialized
INFO - 2025-04-14 20:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-14 20:35:24 --> Pagination Class Initialized
INFO - 2025-04-14 20:35:24 --> Controller Class Initialized
DEBUG - 2025-04-14 20:35:24 --> Report MX_Controller Initialized
INFO - 2025-04-14 20:35:24 --> Model Class Initialized
DEBUG - 2025-04-14 20:35:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-14 20:35:24 --> Model Class Initialized
INFO - 2025-04-14 20:35:24 --> Final output sent to browser
DEBUG - 2025-04-14 20:35:24 --> Total execution time: 0.0108
