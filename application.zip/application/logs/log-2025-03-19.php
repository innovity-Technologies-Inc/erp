<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-19 00:20:15 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:20:15 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:20:15 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:20:15 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:20:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:20:15 --> Model Class Initialized
ERROR - 2025-03-19 00:20:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:20:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:20:16 --> Final output sent to browser
DEBUG - 2025-03-19 00:20:16 --> Total execution time: 0.1332
INFO - 2025-03-19 00:20:16 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:20:16 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:20:16 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:20:16 --> Model Class Initialized
INFO - 2025-03-19 00:20:16 --> Final output sent to browser
DEBUG - 2025-03-19 00:20:16 --> Total execution time: 0.0478
INFO - 2025-03-19 00:20:26 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:20:26 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:20:26 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:20:26 --> Model Class Initialized
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:20:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:20:26 --> Model Class Initialized
ERROR - 2025-03-19 00:20:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:20:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:20:26 --> Final output sent to browser
DEBUG - 2025-03-19 00:20:26 --> Total execution time: 0.1489
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:22:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
ERROR - 2025-03-19 00:22:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:22:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:22:31 --> Final output sent to browser
DEBUG - 2025-03-19 00:22:31 --> Total execution time: 0.1074
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:22:31 --> Model Class Initialized
INFO - 2025-03-19 00:22:32 --> Final output sent to browser
DEBUG - 2025-03-19 00:22:32 --> Total execution time: 0.0392
INFO - 2025-03-19 00:22:37 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:22:37 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:22:37 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:22:37 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:22:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:22:37 --> Model Class Initialized
ERROR - 2025-03-19 00:22:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:22:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:22:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:22:37 --> Final output sent to browser
DEBUG - 2025-03-19 00:22:37 --> Total execution time: 0.0962
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:22:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
ERROR - 2025-03-19 00:22:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:22:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:22:55 --> Final output sent to browser
DEBUG - 2025-03-19 00:22:55 --> Total execution time: 0.0986
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
DEBUG - 2025-03-19 00:22:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:22:55 --> Model Class Initialized
INFO - 2025-03-19 00:22:55 --> Final output sent to browser
DEBUG - 2025-03-19 00:22:55 --> Total execution time: 0.0383
INFO - 2025-03-19 00:23:07 --> Model Class Initialized
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:23:07 --> Model Class Initialized
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:23:07 --> Model Class Initialized
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:23:07 --> Model Class Initialized
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:23:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:23:07 --> Model Class Initialized
ERROR - 2025-03-19 00:23:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:23:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:23:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:23:07 --> Final output sent to browser
DEBUG - 2025-03-19 00:23:07 --> Total execution time: 0.1570
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:26:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
ERROR - 2025-03-19 00:26:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:26:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:26:00 --> Final output sent to browser
DEBUG - 2025-03-19 00:26:00 --> Total execution time: 0.1648
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:26:00 --> Model Class Initialized
INFO - 2025-03-19 00:26:00 --> Final output sent to browser
DEBUG - 2025-03-19 00:26:00 --> Total execution time: 0.0616
INFO - 2025-03-19 00:26:09 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 00:26:09 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 00:26:09 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 00:26:09 --> Model Class Initialized
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 00:26:09 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 00:26:09 --> Model Class Initialized
ERROR - 2025-03-19 00:26:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 00:26:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 00:26:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 00:26:09 --> Final output sent to browser
DEBUG - 2025-03-19 00:26:09 --> Total execution time: 0.1778
INFO - 2025-03-19 01:00:32 --> Model Class Initialized
DEBUG - 2025-03-19 01:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:00:32 --> Model Class Initialized
DEBUG - 2025-03-19 01:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:00:32 --> Model Class Initialized
DEBUG - 2025-03-19 01:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:00:32 --> Model Class Initialized
ERROR - 2025-03-19 01:00:32 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:00:32 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:00:32 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-19 01:00:32 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-19 01:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 01:00:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 01:00:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 01:00:32 --> Model Class Initialized
ERROR - 2025-03-19 01:00:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 01:00:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 01:00:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 01:00:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 01:00:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 01:00:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-19 01:00:33 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-19 01:00:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-19 01:00:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 01:00:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 01:00:33 --> Final output sent to browser
DEBUG - 2025-03-19 01:00:33 --> Total execution time: 0.6395
INFO - 2025-03-19 01:25:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:25:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:25:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:25:55 --> Model Class Initialized
ERROR - 2025-03-19 01:25:55 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:25:55 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:25:55 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-19 01:25:55 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 01:25:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 01:25:55 --> Model Class Initialized
ERROR - 2025-03-19 01:25:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 01:25:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-19 01:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 01:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 01:25:55 --> Final output sent to browser
DEBUG - 2025-03-19 01:25:55 --> Total execution time: 0.1054
INFO - 2025-03-19 01:49:33 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:49:33 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:49:33 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:49:33 --> Model Class Initialized
ERROR - 2025-03-19 01:49:33 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:49:33 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:49:33 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-19 01:49:33 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-19 01:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 01:49:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 01:49:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 01:49:33 --> Model Class Initialized
ERROR - 2025-03-19 01:49:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 01:49:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 01:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 01:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 01:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 01:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-19 01:49:34 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-19 01:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-19 01:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 01:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 01:49:34 --> Final output sent to browser
DEBUG - 2025-03-19 01:49:34 --> Total execution time: 0.8789
INFO - 2025-03-19 01:49:42 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:49:42 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:49:42 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:49:42 --> Model Class Initialized
INFO - 2025-03-19 01:49:42 --> Final output sent to browser
DEBUG - 2025-03-19 01:49:42 --> Total execution time: 0.0064
INFO - 2025-03-19 01:49:44 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:49:44 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:49:44 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:49:44 --> Model Class Initialized
INFO - 2025-03-19 01:49:44 --> Final output sent to browser
DEBUG - 2025-03-19 01:49:44 --> Total execution time: 0.0086
INFO - 2025-03-19 01:49:51 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:49:51 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:49:51 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:49:51 --> Model Class Initialized
INFO - 2025-03-19 01:49:51 --> Final output sent to browser
DEBUG - 2025-03-19 01:49:51 --> Total execution time: 0.0105
INFO - 2025-03-19 01:49:53 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:49:53 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:49:53 --> Model Class Initialized
DEBUG - 2025-03-19 01:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:49:53 --> Model Class Initialized
INFO - 2025-03-19 01:49:53 --> Final output sent to browser
DEBUG - 2025-03-19 01:49:53 --> Total execution time: 0.0082
INFO - 2025-03-19 01:50:02 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:50:02 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:50:02 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:50:02 --> Model Class Initialized
INFO - 2025-03-19 01:50:02 --> Final output sent to browser
DEBUG - 2025-03-19 01:50:02 --> Total execution time: 0.0059
INFO - 2025-03-19 01:50:05 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:50:05 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:50:05 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:50:05 --> Model Class Initialized
INFO - 2025-03-19 01:50:05 --> Final output sent to browser
DEBUG - 2025-03-19 01:50:05 --> Total execution time: 0.0095
INFO - 2025-03-19 01:50:09 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:50:09 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:50:09 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:50:09 --> Model Class Initialized
INFO - 2025-03-19 01:50:09 --> Final output sent to browser
DEBUG - 2025-03-19 01:50:09 --> Total execution time: 0.0128
INFO - 2025-03-19 01:50:11 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:50:11 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:50:11 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:50:11 --> Model Class Initialized
INFO - 2025-03-19 01:50:11 --> Final output sent to browser
DEBUG - 2025-03-19 01:50:11 --> Total execution time: 0.0088
INFO - 2025-03-19 01:50:12 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:50:12 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:50:12 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:50:12 --> Model Class Initialized
INFO - 2025-03-19 01:50:12 --> Final output sent to browser
DEBUG - 2025-03-19 01:50:12 --> Total execution time: 0.0114
INFO - 2025-03-19 01:50:15 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:50:15 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:50:15 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:50:15 --> Model Class Initialized
INFO - 2025-03-19 01:50:15 --> Final output sent to browser
DEBUG - 2025-03-19 01:50:15 --> Total execution time: 0.0199
INFO - 2025-03-19 01:50:17 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:50:17 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:50:17 --> Model Class Initialized
DEBUG - 2025-03-19 01:50:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:50:17 --> Model Class Initialized
INFO - 2025-03-19 01:50:17 --> Final output sent to browser
DEBUG - 2025-03-19 01:50:17 --> Total execution time: 0.0085
INFO - 2025-03-19 01:51:22 --> Model Class Initialized
DEBUG - 2025-03-19 01:51:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:51:22 --> Model Class Initialized
DEBUG - 2025-03-19 01:51:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:51:22 --> Model Class Initialized
DEBUG - 2025-03-19 01:51:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:51:22 --> Model Class Initialized
INFO - 2025-03-19 01:51:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-03-19 01:51:22 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 478
ERROR - 2025-03-19 01:51:22 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 479
DEBUG - 2025-03-19 01:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html_manual.php
INFO - 2025-03-19 01:51:23 --> Final output sent to browser
DEBUG - 2025-03-19 01:51:23 --> Total execution time: 0.0838
INFO - 2025-03-19 01:51:24 --> Model Class Initialized
DEBUG - 2025-03-19 01:51:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:51:24 --> Model Class Initialized
DEBUG - 2025-03-19 01:51:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:51:24 --> Model Class Initialized
DEBUG - 2025-03-19 01:51:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:51:24 --> Model Class Initialized
ERROR - 2025-03-19 01:51:24 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:51:24 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-19 01:51:24 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-19 01:51:24 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-19 01:51:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 01:51:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 01:51:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 01:51:24 --> Model Class Initialized
ERROR - 2025-03-19 01:51:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 01:51:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 01:51:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 01:51:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 01:51:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 01:51:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-19 01:51:25 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-19 01:51:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-19 01:51:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 01:51:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 01:51:25 --> Final output sent to browser
DEBUG - 2025-03-19 01:51:25 --> Total execution time: 0.1462
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 01:52:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
ERROR - 2025-03-19 01:52:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 01:52:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 01:52:23 --> Final output sent to browser
DEBUG - 2025-03-19 01:52:23 --> Total execution time: 0.0997
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:52:23 --> Model Class Initialized
INFO - 2025-03-19 01:52:23 --> Final output sent to browser
DEBUG - 2025-03-19 01:52:23 --> Total execution time: 0.0408
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 01:52:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
ERROR - 2025-03-19 01:52:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 01:52:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 01:52:55 --> Final output sent to browser
DEBUG - 2025-03-19 01:52:55 --> Total execution time: 0.1285
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
DEBUG - 2025-03-19 01:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:52:55 --> Model Class Initialized
INFO - 2025-03-19 01:52:55 --> Final output sent to browser
DEBUG - 2025-03-19 01:52:55 --> Total execution time: 0.0670
INFO - 2025-03-19 01:53:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 01:53:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 01:53:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 01:53:23 --> Model Class Initialized
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 01:53:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 01:53:23 --> Model Class Initialized
ERROR - 2025-03-19 01:53:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 01:53:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 01:53:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 01:53:23 --> Final output sent to browser
DEBUG - 2025-03-19 01:53:23 --> Total execution time: 0.1619
INFO - 2025-03-19 04:57:39 --> Config Class Initialized
INFO - 2025-03-19 04:57:39 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:57:39 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:57:39 --> Utf8 Class Initialized
INFO - 2025-03-19 04:57:39 --> URI Class Initialized
DEBUG - 2025-03-19 04:57:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:57:39 --> Router Class Initialized
INFO - 2025-03-19 04:57:39 --> Output Class Initialized
INFO - 2025-03-19 04:57:39 --> Security Class Initialized
DEBUG - 2025-03-19 04:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:57:39 --> Input Class Initialized
INFO - 2025-03-19 04:57:39 --> Language Class Initialized
INFO - 2025-03-19 04:57:39 --> Language Class Initialized
INFO - 2025-03-19 04:57:39 --> Config Class Initialized
INFO - 2025-03-19 04:57:39 --> Loader Class Initialized
INFO - 2025-03-19 04:57:39 --> Helper loaded: url_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: file_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: html_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: form_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: text_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:57:39 --> Database Driver Class Initialized
INFO - 2025-03-19 04:57:39 --> Email Class Initialized
INFO - 2025-03-19 04:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:57:39 --> Form Validation Class Initialized
INFO - 2025-03-19 04:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:57:39 --> Pagination Class Initialized
INFO - 2025-03-19 04:57:39 --> Controller Class Initialized
DEBUG - 2025-03-19 04:57:39 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:57:39 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:57:39 --> Model Class Initialized
INFO - 2025-03-19 04:57:39 --> Config Class Initialized
INFO - 2025-03-19 04:57:39 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:57:39 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:57:39 --> Utf8 Class Initialized
INFO - 2025-03-19 04:57:39 --> URI Class Initialized
DEBUG - 2025-03-19 04:57:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-19 04:57:39 --> Router Class Initialized
INFO - 2025-03-19 04:57:39 --> Output Class Initialized
INFO - 2025-03-19 04:57:39 --> Security Class Initialized
DEBUG - 2025-03-19 04:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:57:39 --> Input Class Initialized
INFO - 2025-03-19 04:57:39 --> Language Class Initialized
INFO - 2025-03-19 04:57:39 --> Language Class Initialized
INFO - 2025-03-19 04:57:39 --> Config Class Initialized
INFO - 2025-03-19 04:57:39 --> Loader Class Initialized
INFO - 2025-03-19 04:57:39 --> Helper loaded: url_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: file_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: html_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: form_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: text_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:57:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:57:39 --> Database Driver Class Initialized
INFO - 2025-03-19 04:57:39 --> Email Class Initialized
INFO - 2025-03-19 04:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:57:39 --> Form Validation Class Initialized
INFO - 2025-03-19 04:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:57:39 --> Pagination Class Initialized
INFO - 2025-03-19 04:57:39 --> Controller Class Initialized
DEBUG - 2025-03-19 04:57:39 --> Auth MX_Controller Initialized
INFO - 2025-03-19 04:57:39 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-19 04:57:39 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:57:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:57:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:57:39 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-19 04:57:39 --> Final output sent to browser
DEBUG - 2025-03-19 04:57:39 --> Total execution time: 0.0177
INFO - 2025-03-19 04:57:50 --> Config Class Initialized
INFO - 2025-03-19 04:57:50 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:57:50 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:57:50 --> Utf8 Class Initialized
INFO - 2025-03-19 04:57:50 --> URI Class Initialized
DEBUG - 2025-03-19 04:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-19 04:57:50 --> Router Class Initialized
INFO - 2025-03-19 04:57:50 --> Output Class Initialized
INFO - 2025-03-19 04:57:50 --> Security Class Initialized
DEBUG - 2025-03-19 04:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:57:50 --> Input Class Initialized
INFO - 2025-03-19 04:57:50 --> Language Class Initialized
INFO - 2025-03-19 04:57:50 --> Language Class Initialized
INFO - 2025-03-19 04:57:50 --> Config Class Initialized
INFO - 2025-03-19 04:57:50 --> Loader Class Initialized
INFO - 2025-03-19 04:57:50 --> Helper loaded: url_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: file_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: html_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: form_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: text_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:57:50 --> Database Driver Class Initialized
INFO - 2025-03-19 04:57:50 --> Email Class Initialized
INFO - 2025-03-19 04:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:57:50 --> Form Validation Class Initialized
INFO - 2025-03-19 04:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:57:50 --> Pagination Class Initialized
INFO - 2025-03-19 04:57:50 --> Controller Class Initialized
DEBUG - 2025-03-19 04:57:50 --> Auth MX_Controller Initialized
INFO - 2025-03-19 04:57:50 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-19 04:57:50 --> Model Class Initialized
INFO - 2025-03-19 04:57:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-19 04:57:50 --> Config Class Initialized
INFO - 2025-03-19 04:57:50 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:57:50 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:57:50 --> Utf8 Class Initialized
INFO - 2025-03-19 04:57:50 --> URI Class Initialized
DEBUG - 2025-03-19 04:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-19 04:57:50 --> Router Class Initialized
INFO - 2025-03-19 04:57:50 --> Output Class Initialized
INFO - 2025-03-19 04:57:50 --> Security Class Initialized
DEBUG - 2025-03-19 04:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:57:50 --> Input Class Initialized
INFO - 2025-03-19 04:57:50 --> Language Class Initialized
INFO - 2025-03-19 04:57:50 --> Language Class Initialized
INFO - 2025-03-19 04:57:50 --> Config Class Initialized
INFO - 2025-03-19 04:57:50 --> Loader Class Initialized
INFO - 2025-03-19 04:57:50 --> Helper loaded: url_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: file_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: html_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: form_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: text_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:57:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:57:50 --> Database Driver Class Initialized
INFO - 2025-03-19 04:57:50 --> Email Class Initialized
INFO - 2025-03-19 04:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:57:50 --> Form Validation Class Initialized
INFO - 2025-03-19 04:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:57:50 --> Pagination Class Initialized
INFO - 2025-03-19 04:57:50 --> Controller Class Initialized
DEBUG - 2025-03-19 04:57:50 --> Home MX_Controller Initialized
INFO - 2025-03-19 04:57:50 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-19 04:57:50 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:57:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:57:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:57:50 --> Model Class Initialized
ERROR - 2025-03-19 04:57:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 04:57:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 04:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 04:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 04:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 04:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 04:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-19 04:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 04:57:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 04:57:51 --> Final output sent to browser
DEBUG - 2025-03-19 04:57:51 --> Total execution time: 0.5292
INFO - 2025-03-19 04:57:57 --> Config Class Initialized
INFO - 2025-03-19 04:57:57 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:57:57 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:57:57 --> Utf8 Class Initialized
INFO - 2025-03-19 04:57:57 --> URI Class Initialized
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:57:57 --> Router Class Initialized
INFO - 2025-03-19 04:57:57 --> Output Class Initialized
INFO - 2025-03-19 04:57:57 --> Security Class Initialized
DEBUG - 2025-03-19 04:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:57:57 --> Input Class Initialized
INFO - 2025-03-19 04:57:57 --> Language Class Initialized
INFO - 2025-03-19 04:57:57 --> Language Class Initialized
INFO - 2025-03-19 04:57:57 --> Config Class Initialized
INFO - 2025-03-19 04:57:57 --> Loader Class Initialized
INFO - 2025-03-19 04:57:57 --> Helper loaded: url_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: file_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: html_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: form_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: text_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:57:57 --> Database Driver Class Initialized
INFO - 2025-03-19 04:57:57 --> Email Class Initialized
INFO - 2025-03-19 04:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:57:57 --> Form Validation Class Initialized
INFO - 2025-03-19 04:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:57:57 --> Pagination Class Initialized
INFO - 2025-03-19 04:57:57 --> Controller Class Initialized
DEBUG - 2025-03-19 04:57:57 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:57:57 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:57:57 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:57:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:57:57 --> Model Class Initialized
ERROR - 2025-03-19 04:57:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 04:57:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/due_report.php
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 04:57:57 --> Final output sent to browser
DEBUG - 2025-03-19 04:57:57 --> Total execution time: 0.1278
INFO - 2025-03-19 04:57:57 --> Config Class Initialized
INFO - 2025-03-19 04:57:57 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:57:57 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:57:57 --> Utf8 Class Initialized
INFO - 2025-03-19 04:57:57 --> URI Class Initialized
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:57:57 --> Router Class Initialized
INFO - 2025-03-19 04:57:57 --> Output Class Initialized
INFO - 2025-03-19 04:57:57 --> Security Class Initialized
DEBUG - 2025-03-19 04:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:57:57 --> Input Class Initialized
INFO - 2025-03-19 04:57:57 --> Language Class Initialized
INFO - 2025-03-19 04:57:57 --> Language Class Initialized
INFO - 2025-03-19 04:57:57 --> Config Class Initialized
INFO - 2025-03-19 04:57:57 --> Loader Class Initialized
INFO - 2025-03-19 04:57:57 --> Helper loaded: url_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: file_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: html_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: form_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: text_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:57:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:57:57 --> Database Driver Class Initialized
INFO - 2025-03-19 04:57:57 --> Email Class Initialized
INFO - 2025-03-19 04:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:57:57 --> Form Validation Class Initialized
INFO - 2025-03-19 04:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:57:57 --> Pagination Class Initialized
INFO - 2025-03-19 04:57:57 --> Controller Class Initialized
DEBUG - 2025-03-19 04:57:57 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:57:57 --> Model Class Initialized
DEBUG - 2025-03-19 04:57:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:57:57 --> Model Class Initialized
INFO - 2025-03-19 04:57:57 --> Final output sent to browser
DEBUG - 2025-03-19 04:57:57 --> Total execution time: 0.0076
INFO - 2025-03-19 04:58:01 --> Config Class Initialized
INFO - 2025-03-19 04:58:01 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:58:01 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:58:01 --> Utf8 Class Initialized
INFO - 2025-03-19 04:58:01 --> URI Class Initialized
DEBUG - 2025-03-19 04:58:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:58:01 --> Router Class Initialized
INFO - 2025-03-19 04:58:01 --> Output Class Initialized
INFO - 2025-03-19 04:58:01 --> Security Class Initialized
DEBUG - 2025-03-19 04:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:58:01 --> Input Class Initialized
INFO - 2025-03-19 04:58:01 --> Language Class Initialized
INFO - 2025-03-19 04:58:01 --> Language Class Initialized
INFO - 2025-03-19 04:58:01 --> Config Class Initialized
INFO - 2025-03-19 04:58:01 --> Loader Class Initialized
INFO - 2025-03-19 04:58:01 --> Helper loaded: url_helper
INFO - 2025-03-19 04:58:01 --> Helper loaded: file_helper
INFO - 2025-03-19 04:58:01 --> Helper loaded: html_helper
INFO - 2025-03-19 04:58:01 --> Helper loaded: form_helper
INFO - 2025-03-19 04:58:01 --> Helper loaded: text_helper
INFO - 2025-03-19 04:58:01 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:58:01 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:58:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:58:01 --> Database Driver Class Initialized
INFO - 2025-03-19 04:58:01 --> Email Class Initialized
INFO - 2025-03-19 04:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:58:01 --> Form Validation Class Initialized
INFO - 2025-03-19 04:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:58:01 --> Pagination Class Initialized
INFO - 2025-03-19 04:58:01 --> Controller Class Initialized
DEBUG - 2025-03-19 04:58:01 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:58:01 --> Model Class Initialized
DEBUG - 2025-03-19 04:58:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:58:01 --> Model Class Initialized
INFO - 2025-03-19 04:58:01 --> Final output sent to browser
DEBUG - 2025-03-19 04:58:01 --> Total execution time: 0.0109
INFO - 2025-03-19 04:58:36 --> Config Class Initialized
INFO - 2025-03-19 04:58:36 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:58:36 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:58:36 --> Utf8 Class Initialized
INFO - 2025-03-19 04:58:36 --> URI Class Initialized
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:58:36 --> Router Class Initialized
INFO - 2025-03-19 04:58:36 --> Output Class Initialized
INFO - 2025-03-19 04:58:36 --> Security Class Initialized
DEBUG - 2025-03-19 04:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:58:36 --> Input Class Initialized
INFO - 2025-03-19 04:58:36 --> Language Class Initialized
INFO - 2025-03-19 04:58:36 --> Language Class Initialized
INFO - 2025-03-19 04:58:36 --> Config Class Initialized
INFO - 2025-03-19 04:58:36 --> Loader Class Initialized
INFO - 2025-03-19 04:58:36 --> Helper loaded: url_helper
INFO - 2025-03-19 04:58:36 --> Helper loaded: file_helper
INFO - 2025-03-19 04:58:36 --> Helper loaded: html_helper
INFO - 2025-03-19 04:58:36 --> Helper loaded: form_helper
INFO - 2025-03-19 04:58:36 --> Helper loaded: text_helper
INFO - 2025-03-19 04:58:36 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:58:36 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:58:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:58:36 --> Database Driver Class Initialized
INFO - 2025-03-19 04:58:36 --> Email Class Initialized
INFO - 2025-03-19 04:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:58:36 --> Form Validation Class Initialized
INFO - 2025-03-19 04:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:58:36 --> Pagination Class Initialized
INFO - 2025-03-19 04:58:36 --> Controller Class Initialized
DEBUG - 2025-03-19 04:58:36 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:58:36 --> Model Class Initialized
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:58:36 --> Model Class Initialized
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:58:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:58:36 --> Model Class Initialized
ERROR - 2025-03-19 04:58:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 04:58:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 04:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 10:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/profit_report.php
DEBUG - 2025-03-19 10:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 10:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 10:58:36 --> Final output sent to browser
DEBUG - 2025-03-19 10:58:36 --> Total execution time: 0.1264
INFO - 2025-03-19 04:58:42 --> Config Class Initialized
INFO - 2025-03-19 04:58:42 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:58:42 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:58:42 --> Utf8 Class Initialized
INFO - 2025-03-19 04:58:42 --> URI Class Initialized
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:58:42 --> Router Class Initialized
INFO - 2025-03-19 04:58:42 --> Output Class Initialized
INFO - 2025-03-19 04:58:42 --> Security Class Initialized
DEBUG - 2025-03-19 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:58:42 --> Input Class Initialized
INFO - 2025-03-19 04:58:42 --> Language Class Initialized
INFO - 2025-03-19 04:58:42 --> Language Class Initialized
INFO - 2025-03-19 04:58:42 --> Config Class Initialized
INFO - 2025-03-19 04:58:42 --> Loader Class Initialized
INFO - 2025-03-19 04:58:42 --> Helper loaded: url_helper
INFO - 2025-03-19 04:58:42 --> Helper loaded: file_helper
INFO - 2025-03-19 04:58:42 --> Helper loaded: html_helper
INFO - 2025-03-19 04:58:42 --> Helper loaded: form_helper
INFO - 2025-03-19 04:58:42 --> Helper loaded: text_helper
INFO - 2025-03-19 04:58:42 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:58:42 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:58:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:58:42 --> Database Driver Class Initialized
INFO - 2025-03-19 04:58:42 --> Email Class Initialized
INFO - 2025-03-19 04:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:58:42 --> Form Validation Class Initialized
INFO - 2025-03-19 04:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:58:42 --> Pagination Class Initialized
INFO - 2025-03-19 04:58:42 --> Controller Class Initialized
DEBUG - 2025-03-19 04:58:42 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:58:42 --> Model Class Initialized
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:58:42 --> Model Class Initialized
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:58:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:58:42 --> Model Class Initialized
ERROR - 2025-03-19 04:58:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 04:58:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 04:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 10:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/profit_report.php
DEBUG - 2025-03-19 10:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 10:58:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 10:58:42 --> Final output sent to browser
DEBUG - 2025-03-19 10:58:42 --> Total execution time: 0.1727
INFO - 2025-03-19 04:59:14 --> Config Class Initialized
INFO - 2025-03-19 04:59:14 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:59:14 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:59:14 --> Utf8 Class Initialized
INFO - 2025-03-19 04:59:14 --> URI Class Initialized
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:59:14 --> Router Class Initialized
INFO - 2025-03-19 04:59:14 --> Output Class Initialized
INFO - 2025-03-19 04:59:14 --> Security Class Initialized
DEBUG - 2025-03-19 04:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:59:14 --> Input Class Initialized
INFO - 2025-03-19 04:59:14 --> Language Class Initialized
INFO - 2025-03-19 04:59:14 --> Language Class Initialized
INFO - 2025-03-19 04:59:14 --> Config Class Initialized
INFO - 2025-03-19 04:59:14 --> Loader Class Initialized
INFO - 2025-03-19 04:59:14 --> Helper loaded: url_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: file_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: html_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: form_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: text_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:59:14 --> Database Driver Class Initialized
INFO - 2025-03-19 04:59:14 --> Email Class Initialized
INFO - 2025-03-19 04:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:59:14 --> Form Validation Class Initialized
INFO - 2025-03-19 04:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:59:14 --> Pagination Class Initialized
INFO - 2025-03-19 04:59:14 --> Controller Class Initialized
DEBUG - 2025-03-19 04:59:14 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:59:14 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:59:14 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:59:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:59:14 --> Model Class Initialized
ERROR - 2025-03-19 04:59:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 04:59:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 04:59:14 --> Final output sent to browser
DEBUG - 2025-03-19 04:59:14 --> Total execution time: 0.1342
INFO - 2025-03-19 04:59:14 --> Config Class Initialized
INFO - 2025-03-19 04:59:14 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:59:14 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:59:14 --> Utf8 Class Initialized
INFO - 2025-03-19 04:59:14 --> URI Class Initialized
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:59:14 --> Router Class Initialized
INFO - 2025-03-19 04:59:14 --> Output Class Initialized
INFO - 2025-03-19 04:59:14 --> Security Class Initialized
DEBUG - 2025-03-19 04:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:59:14 --> Input Class Initialized
INFO - 2025-03-19 04:59:14 --> Language Class Initialized
INFO - 2025-03-19 04:59:14 --> Language Class Initialized
INFO - 2025-03-19 04:59:14 --> Config Class Initialized
INFO - 2025-03-19 04:59:14 --> Loader Class Initialized
INFO - 2025-03-19 04:59:14 --> Helper loaded: url_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: file_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: html_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: form_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: text_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:59:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:59:14 --> Database Driver Class Initialized
INFO - 2025-03-19 04:59:14 --> Email Class Initialized
INFO - 2025-03-19 04:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:59:14 --> Form Validation Class Initialized
INFO - 2025-03-19 04:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:59:14 --> Pagination Class Initialized
INFO - 2025-03-19 04:59:14 --> Controller Class Initialized
DEBUG - 2025-03-19 04:59:14 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:59:14 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:59:14 --> Model Class Initialized
INFO - 2025-03-19 04:59:14 --> Final output sent to browser
DEBUG - 2025-03-19 04:59:14 --> Total execution time: 0.0093
INFO - 2025-03-19 04:59:23 --> Config Class Initialized
INFO - 2025-03-19 04:59:23 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:59:23 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:59:23 --> Utf8 Class Initialized
INFO - 2025-03-19 04:59:23 --> URI Class Initialized
DEBUG - 2025-03-19 04:59:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 04:59:23 --> Router Class Initialized
INFO - 2025-03-19 04:59:23 --> Output Class Initialized
INFO - 2025-03-19 04:59:23 --> Security Class Initialized
DEBUG - 2025-03-19 04:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:59:23 --> Input Class Initialized
INFO - 2025-03-19 04:59:23 --> Language Class Initialized
INFO - 2025-03-19 04:59:23 --> Language Class Initialized
INFO - 2025-03-19 04:59:23 --> Config Class Initialized
INFO - 2025-03-19 04:59:23 --> Loader Class Initialized
INFO - 2025-03-19 04:59:23 --> Helper loaded: url_helper
INFO - 2025-03-19 04:59:23 --> Helper loaded: file_helper
INFO - 2025-03-19 04:59:23 --> Helper loaded: html_helper
INFO - 2025-03-19 04:59:23 --> Helper loaded: form_helper
INFO - 2025-03-19 04:59:23 --> Helper loaded: text_helper
INFO - 2025-03-19 04:59:23 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:59:23 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:59:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:59:23 --> Database Driver Class Initialized
INFO - 2025-03-19 04:59:23 --> Email Class Initialized
INFO - 2025-03-19 04:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:59:23 --> Form Validation Class Initialized
INFO - 2025-03-19 04:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:59:23 --> Pagination Class Initialized
INFO - 2025-03-19 04:59:23 --> Controller Class Initialized
DEBUG - 2025-03-19 04:59:23 --> Report MX_Controller Initialized
INFO - 2025-03-19 04:59:23 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 04:59:23 --> Model Class Initialized
INFO - 2025-03-19 04:59:23 --> Final output sent to browser
DEBUG - 2025-03-19 04:59:23 --> Total execution time: 0.0114
INFO - 2025-03-19 04:59:45 --> Config Class Initialized
INFO - 2025-03-19 04:59:45 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:59:45 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:59:45 --> Utf8 Class Initialized
INFO - 2025-03-19 04:59:45 --> URI Class Initialized
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 04:59:45 --> Router Class Initialized
INFO - 2025-03-19 04:59:45 --> Output Class Initialized
INFO - 2025-03-19 04:59:45 --> Security Class Initialized
DEBUG - 2025-03-19 04:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:59:45 --> Input Class Initialized
INFO - 2025-03-19 04:59:45 --> Language Class Initialized
INFO - 2025-03-19 04:59:45 --> Language Class Initialized
INFO - 2025-03-19 04:59:45 --> Config Class Initialized
INFO - 2025-03-19 04:59:45 --> Loader Class Initialized
INFO - 2025-03-19 04:59:45 --> Helper loaded: url_helper
INFO - 2025-03-19 04:59:45 --> Helper loaded: file_helper
INFO - 2025-03-19 04:59:45 --> Helper loaded: html_helper
INFO - 2025-03-19 04:59:45 --> Helper loaded: form_helper
INFO - 2025-03-19 04:59:45 --> Helper loaded: text_helper
INFO - 2025-03-19 04:59:45 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:59:45 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:59:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:59:45 --> Database Driver Class Initialized
INFO - 2025-03-19 04:59:45 --> Email Class Initialized
INFO - 2025-03-19 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:59:45 --> Form Validation Class Initialized
INFO - 2025-03-19 04:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:59:45 --> Pagination Class Initialized
INFO - 2025-03-19 04:59:45 --> Controller Class Initialized
DEBUG - 2025-03-19 04:59:45 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 04:59:45 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 04:59:45 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:59:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:59:45 --> Model Class Initialized
ERROR - 2025-03-19 04:59:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 04:59:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/receipt_payment.php
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 04:59:45 --> Final output sent to browser
DEBUG - 2025-03-19 04:59:45 --> Total execution time: 0.1094
INFO - 2025-03-19 04:59:51 --> Config Class Initialized
INFO - 2025-03-19 04:59:51 --> Hooks Class Initialized
DEBUG - 2025-03-19 04:59:51 --> UTF-8 Support Enabled
INFO - 2025-03-19 04:59:51 --> Utf8 Class Initialized
INFO - 2025-03-19 04:59:51 --> URI Class Initialized
DEBUG - 2025-03-19 04:59:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 04:59:51 --> Router Class Initialized
INFO - 2025-03-19 04:59:51 --> Output Class Initialized
INFO - 2025-03-19 04:59:51 --> Security Class Initialized
DEBUG - 2025-03-19 04:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 04:59:51 --> Input Class Initialized
INFO - 2025-03-19 04:59:51 --> Language Class Initialized
INFO - 2025-03-19 04:59:51 --> Language Class Initialized
INFO - 2025-03-19 04:59:51 --> Config Class Initialized
INFO - 2025-03-19 04:59:51 --> Loader Class Initialized
INFO - 2025-03-19 04:59:51 --> Helper loaded: url_helper
INFO - 2025-03-19 04:59:51 --> Helper loaded: file_helper
INFO - 2025-03-19 04:59:51 --> Helper loaded: html_helper
INFO - 2025-03-19 04:59:51 --> Helper loaded: form_helper
INFO - 2025-03-19 04:59:51 --> Helper loaded: text_helper
INFO - 2025-03-19 04:59:51 --> Helper loaded: lang_helper
INFO - 2025-03-19 04:59:51 --> Helper loaded: directory_helper
INFO - 2025-03-19 04:59:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 04:59:51 --> Database Driver Class Initialized
INFO - 2025-03-19 04:59:51 --> Email Class Initialized
INFO - 2025-03-19 04:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 04:59:51 --> Form Validation Class Initialized
INFO - 2025-03-19 04:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 04:59:51 --> Pagination Class Initialized
INFO - 2025-03-19 04:59:51 --> Controller Class Initialized
DEBUG - 2025-03-19 04:59:51 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 04:59:51 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 04:59:51 --> Model Class Initialized
DEBUG - 2025-03-19 04:59:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 04:59:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 04:59:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 04:59:51 --> Model Class Initialized
ERROR - 2025-03-19 04:59:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 04:59:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 04:59:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 04:59:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/receipt_payment_report.php
DEBUG - 2025-03-19 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 04:59:52 --> Final output sent to browser
DEBUG - 2025-03-19 04:59:52 --> Total execution time: 0.1067
INFO - 2025-03-19 05:01:30 --> Config Class Initialized
INFO - 2025-03-19 05:01:30 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:01:30 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:01:30 --> Utf8 Class Initialized
INFO - 2025-03-19 05:01:30 --> URI Class Initialized
DEBUG - 2025-03-19 05:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 05:01:30 --> Router Class Initialized
INFO - 2025-03-19 05:01:30 --> Output Class Initialized
INFO - 2025-03-19 05:01:30 --> Security Class Initialized
DEBUG - 2025-03-19 05:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:01:30 --> Input Class Initialized
INFO - 2025-03-19 05:01:30 --> Language Class Initialized
INFO - 2025-03-19 05:01:30 --> Language Class Initialized
INFO - 2025-03-19 05:01:30 --> Config Class Initialized
INFO - 2025-03-19 05:01:30 --> Loader Class Initialized
INFO - 2025-03-19 05:01:30 --> Helper loaded: url_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: file_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: html_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: form_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: text_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:01:30 --> Database Driver Class Initialized
INFO - 2025-03-19 05:01:30 --> Email Class Initialized
INFO - 2025-03-19 05:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:01:30 --> Form Validation Class Initialized
INFO - 2025-03-19 05:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:01:30 --> Pagination Class Initialized
INFO - 2025-03-19 05:01:30 --> Controller Class Initialized
DEBUG - 2025-03-19 05:01:30 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 11:01:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
ERROR - 2025-03-19 11:01:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 11:01:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 11:01:30 --> Final output sent to browser
DEBUG - 2025-03-19 11:01:30 --> Total execution time: 0.1603
INFO - 2025-03-19 05:01:30 --> Config Class Initialized
INFO - 2025-03-19 05:01:30 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:01:30 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:01:30 --> Utf8 Class Initialized
INFO - 2025-03-19 05:01:30 --> URI Class Initialized
DEBUG - 2025-03-19 05:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 05:01:30 --> Router Class Initialized
INFO - 2025-03-19 05:01:30 --> Output Class Initialized
INFO - 2025-03-19 05:01:30 --> Security Class Initialized
DEBUG - 2025-03-19 05:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:01:30 --> Input Class Initialized
INFO - 2025-03-19 05:01:30 --> Language Class Initialized
INFO - 2025-03-19 05:01:30 --> Language Class Initialized
INFO - 2025-03-19 05:01:30 --> Config Class Initialized
INFO - 2025-03-19 05:01:30 --> Loader Class Initialized
INFO - 2025-03-19 05:01:30 --> Helper loaded: url_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: file_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: html_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: form_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: text_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:01:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:01:30 --> Database Driver Class Initialized
INFO - 2025-03-19 05:01:30 --> Email Class Initialized
INFO - 2025-03-19 05:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:01:30 --> Form Validation Class Initialized
INFO - 2025-03-19 05:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:01:30 --> Pagination Class Initialized
INFO - 2025-03-19 05:01:30 --> Controller Class Initialized
DEBUG - 2025-03-19 05:01:30 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 11:01:30 --> Model Class Initialized
INFO - 2025-03-19 11:01:30 --> Final output sent to browser
DEBUG - 2025-03-19 11:01:30 --> Total execution time: 0.0431
INFO - 2025-03-19 05:01:33 --> Config Class Initialized
INFO - 2025-03-19 05:01:33 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:01:33 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:01:33 --> Utf8 Class Initialized
INFO - 2025-03-19 05:01:33 --> URI Class Initialized
DEBUG - 2025-03-19 05:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 05:01:33 --> Router Class Initialized
INFO - 2025-03-19 05:01:33 --> Output Class Initialized
INFO - 2025-03-19 05:01:33 --> Security Class Initialized
DEBUG - 2025-03-19 05:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:01:33 --> Input Class Initialized
INFO - 2025-03-19 05:01:33 --> Language Class Initialized
INFO - 2025-03-19 05:01:33 --> Language Class Initialized
INFO - 2025-03-19 05:01:33 --> Config Class Initialized
INFO - 2025-03-19 05:01:33 --> Loader Class Initialized
INFO - 2025-03-19 05:01:33 --> Helper loaded: url_helper
INFO - 2025-03-19 05:01:33 --> Helper loaded: file_helper
INFO - 2025-03-19 05:01:33 --> Helper loaded: html_helper
INFO - 2025-03-19 05:01:33 --> Helper loaded: form_helper
INFO - 2025-03-19 05:01:33 --> Helper loaded: text_helper
INFO - 2025-03-19 05:01:33 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:01:33 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:01:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:01:33 --> Database Driver Class Initialized
INFO - 2025-03-19 05:01:33 --> Email Class Initialized
INFO - 2025-03-19 05:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:01:33 --> Form Validation Class Initialized
INFO - 2025-03-19 05:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:01:33 --> Pagination Class Initialized
INFO - 2025-03-19 05:01:33 --> Controller Class Initialized
DEBUG - 2025-03-19 05:01:33 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 11:01:33 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 11:01:33 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 11:01:33 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 11:01:33 --> Model Class Initialized
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 11:01:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 11:01:33 --> Model Class Initialized
ERROR - 2025-03-19 11:01:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 11:01:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 11:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 11:01:33 --> Final output sent to browser
DEBUG - 2025-03-19 11:01:33 --> Total execution time: 0.1475
INFO - 2025-03-19 05:02:15 --> Config Class Initialized
INFO - 2025-03-19 05:02:15 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:02:15 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:02:15 --> Utf8 Class Initialized
INFO - 2025-03-19 05:02:15 --> URI Class Initialized
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 05:02:15 --> Router Class Initialized
INFO - 2025-03-19 05:02:15 --> Output Class Initialized
INFO - 2025-03-19 05:02:15 --> Security Class Initialized
DEBUG - 2025-03-19 05:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:02:15 --> Input Class Initialized
INFO - 2025-03-19 05:02:15 --> Language Class Initialized
INFO - 2025-03-19 05:02:15 --> Language Class Initialized
INFO - 2025-03-19 05:02:15 --> Config Class Initialized
INFO - 2025-03-19 05:02:15 --> Loader Class Initialized
INFO - 2025-03-19 05:02:15 --> Helper loaded: url_helper
INFO - 2025-03-19 05:02:15 --> Helper loaded: file_helper
INFO - 2025-03-19 05:02:15 --> Helper loaded: html_helper
INFO - 2025-03-19 05:02:15 --> Helper loaded: form_helper
INFO - 2025-03-19 05:02:15 --> Helper loaded: text_helper
INFO - 2025-03-19 05:02:15 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:02:15 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:02:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:02:15 --> Database Driver Class Initialized
INFO - 2025-03-19 05:02:15 --> Email Class Initialized
INFO - 2025-03-19 05:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:02:15 --> Form Validation Class Initialized
INFO - 2025-03-19 05:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:02:15 --> Pagination Class Initialized
INFO - 2025-03-19 05:02:15 --> Controller Class Initialized
DEBUG - 2025-03-19 05:02:15 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 05:02:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 05:02:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:02:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:02:15 --> Model Class Initialized
ERROR - 2025-03-19 05:02:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:02:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/bank_book.php
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:02:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:02:15 --> Final output sent to browser
DEBUG - 2025-03-19 05:02:15 --> Total execution time: 0.1409
INFO - 2025-03-19 05:02:22 --> Config Class Initialized
INFO - 2025-03-19 05:02:22 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:02:22 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:02:22 --> Utf8 Class Initialized
INFO - 2025-03-19 05:02:22 --> URI Class Initialized
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 05:02:22 --> Router Class Initialized
INFO - 2025-03-19 05:02:22 --> Output Class Initialized
INFO - 2025-03-19 05:02:22 --> Security Class Initialized
DEBUG - 2025-03-19 05:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:02:22 --> Input Class Initialized
INFO - 2025-03-19 05:02:22 --> Language Class Initialized
INFO - 2025-03-19 05:02:22 --> Language Class Initialized
INFO - 2025-03-19 05:02:22 --> Config Class Initialized
INFO - 2025-03-19 05:02:22 --> Loader Class Initialized
INFO - 2025-03-19 05:02:22 --> Helper loaded: url_helper
INFO - 2025-03-19 05:02:22 --> Helper loaded: file_helper
INFO - 2025-03-19 05:02:22 --> Helper loaded: html_helper
INFO - 2025-03-19 05:02:22 --> Helper loaded: form_helper
INFO - 2025-03-19 05:02:22 --> Helper loaded: text_helper
INFO - 2025-03-19 05:02:22 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:02:22 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:02:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:02:22 --> Database Driver Class Initialized
INFO - 2025-03-19 05:02:22 --> Email Class Initialized
INFO - 2025-03-19 05:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:02:22 --> Form Validation Class Initialized
INFO - 2025-03-19 05:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:02:22 --> Pagination Class Initialized
INFO - 2025-03-19 05:02:22 --> Controller Class Initialized
DEBUG - 2025-03-19 05:02:22 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 05:02:22 --> Model Class Initialized
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 05:02:22 --> Model Class Initialized
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:02:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:02:22 --> Model Class Initialized
ERROR - 2025-03-19 05:02:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:02:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/bank_book_report.php
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:02:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:02:22 --> Final output sent to browser
DEBUG - 2025-03-19 05:02:22 --> Total execution time: 0.1430
INFO - 2025-03-19 05:39:38 --> Config Class Initialized
INFO - 2025-03-19 05:39:38 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:39:38 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:39:38 --> Utf8 Class Initialized
INFO - 2025-03-19 05:39:38 --> URI Class Initialized
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:39:38 --> Router Class Initialized
INFO - 2025-03-19 05:39:38 --> Output Class Initialized
INFO - 2025-03-19 05:39:38 --> Security Class Initialized
DEBUG - 2025-03-19 05:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:39:38 --> Input Class Initialized
INFO - 2025-03-19 05:39:38 --> Language Class Initialized
INFO - 2025-03-19 05:39:38 --> Language Class Initialized
INFO - 2025-03-19 05:39:38 --> Config Class Initialized
INFO - 2025-03-19 05:39:38 --> Loader Class Initialized
INFO - 2025-03-19 05:39:38 --> Helper loaded: url_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: file_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: html_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: form_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: text_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:39:38 --> Database Driver Class Initialized
INFO - 2025-03-19 05:39:38 --> Email Class Initialized
INFO - 2025-03-19 05:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:39:38 --> Form Validation Class Initialized
INFO - 2025-03-19 05:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:39:38 --> Pagination Class Initialized
INFO - 2025-03-19 05:39:38 --> Controller Class Initialized
DEBUG - 2025-03-19 05:39:38 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:39:38 --> Model Class Initialized
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:39:38 --> Model Class Initialized
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:39:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:39:38 --> Model Class Initialized
ERROR - 2025-03-19 05:39:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:39:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:39:38 --> Final output sent to browser
DEBUG - 2025-03-19 05:39:38 --> Total execution time: 0.4450
INFO - 2025-03-19 05:39:38 --> Config Class Initialized
INFO - 2025-03-19 05:39:38 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:39:38 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:39:38 --> Utf8 Class Initialized
INFO - 2025-03-19 05:39:38 --> URI Class Initialized
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:39:38 --> Router Class Initialized
INFO - 2025-03-19 05:39:38 --> Output Class Initialized
INFO - 2025-03-19 05:39:38 --> Security Class Initialized
DEBUG - 2025-03-19 05:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:39:38 --> Input Class Initialized
INFO - 2025-03-19 05:39:38 --> Language Class Initialized
INFO - 2025-03-19 05:39:38 --> Language Class Initialized
INFO - 2025-03-19 05:39:38 --> Config Class Initialized
INFO - 2025-03-19 05:39:38 --> Loader Class Initialized
INFO - 2025-03-19 05:39:38 --> Helper loaded: url_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: file_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: html_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: form_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: text_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:39:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:39:38 --> Database Driver Class Initialized
INFO - 2025-03-19 05:39:38 --> Email Class Initialized
INFO - 2025-03-19 05:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:39:38 --> Form Validation Class Initialized
INFO - 2025-03-19 05:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:39:38 --> Pagination Class Initialized
INFO - 2025-03-19 05:39:38 --> Controller Class Initialized
DEBUG - 2025-03-19 05:39:38 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:39:38 --> Model Class Initialized
DEBUG - 2025-03-19 05:39:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:39:38 --> Model Class Initialized
INFO - 2025-03-19 05:39:38 --> Final output sent to browser
DEBUG - 2025-03-19 05:39:38 --> Total execution time: 0.0071
INFO - 2025-03-19 05:39:44 --> Config Class Initialized
INFO - 2025-03-19 05:39:44 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:39:44 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:39:44 --> Utf8 Class Initialized
INFO - 2025-03-19 05:39:44 --> URI Class Initialized
DEBUG - 2025-03-19 05:39:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:39:44 --> Router Class Initialized
INFO - 2025-03-19 05:39:44 --> Output Class Initialized
INFO - 2025-03-19 05:39:44 --> Security Class Initialized
DEBUG - 2025-03-19 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:39:44 --> Input Class Initialized
INFO - 2025-03-19 05:39:44 --> Language Class Initialized
INFO - 2025-03-19 05:39:44 --> Language Class Initialized
INFO - 2025-03-19 05:39:44 --> Config Class Initialized
INFO - 2025-03-19 05:39:44 --> Loader Class Initialized
INFO - 2025-03-19 05:39:44 --> Helper loaded: url_helper
INFO - 2025-03-19 05:39:44 --> Helper loaded: file_helper
INFO - 2025-03-19 05:39:44 --> Helper loaded: html_helper
INFO - 2025-03-19 05:39:44 --> Helper loaded: form_helper
INFO - 2025-03-19 05:39:44 --> Helper loaded: text_helper
INFO - 2025-03-19 05:39:44 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:39:44 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:39:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:39:44 --> Database Driver Class Initialized
INFO - 2025-03-19 05:39:44 --> Email Class Initialized
INFO - 2025-03-19 05:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:39:44 --> Form Validation Class Initialized
INFO - 2025-03-19 05:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:39:44 --> Pagination Class Initialized
INFO - 2025-03-19 05:39:44 --> Controller Class Initialized
DEBUG - 2025-03-19 05:39:44 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:39:44 --> Model Class Initialized
DEBUG - 2025-03-19 05:39:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:39:44 --> Model Class Initialized
INFO - 2025-03-19 05:39:44 --> Final output sent to browser
DEBUG - 2025-03-19 05:39:44 --> Total execution time: 0.0119
INFO - 2025-03-19 05:43:35 --> Config Class Initialized
INFO - 2025-03-19 05:43:35 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:43:35 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:43:35 --> Utf8 Class Initialized
INFO - 2025-03-19 05:43:35 --> URI Class Initialized
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:43:35 --> Router Class Initialized
INFO - 2025-03-19 05:43:35 --> Output Class Initialized
INFO - 2025-03-19 05:43:35 --> Security Class Initialized
DEBUG - 2025-03-19 05:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:43:35 --> Input Class Initialized
INFO - 2025-03-19 05:43:35 --> Language Class Initialized
INFO - 2025-03-19 05:43:35 --> Language Class Initialized
INFO - 2025-03-19 05:43:35 --> Config Class Initialized
INFO - 2025-03-19 05:43:35 --> Loader Class Initialized
INFO - 2025-03-19 05:43:35 --> Helper loaded: url_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: file_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: html_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: form_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: text_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:43:35 --> Database Driver Class Initialized
INFO - 2025-03-19 05:43:35 --> Email Class Initialized
INFO - 2025-03-19 05:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:43:35 --> Form Validation Class Initialized
INFO - 2025-03-19 05:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:43:35 --> Pagination Class Initialized
INFO - 2025-03-19 05:43:35 --> Controller Class Initialized
DEBUG - 2025-03-19 05:43:35 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:43:35 --> Model Class Initialized
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:43:35 --> Model Class Initialized
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:43:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:43:35 --> Model Class Initialized
ERROR - 2025-03-19 05:43:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:43:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:43:35 --> Final output sent to browser
DEBUG - 2025-03-19 05:43:35 --> Total execution time: 0.0961
INFO - 2025-03-19 05:43:35 --> Config Class Initialized
INFO - 2025-03-19 05:43:35 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:43:35 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:43:35 --> Utf8 Class Initialized
INFO - 2025-03-19 05:43:35 --> URI Class Initialized
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:43:35 --> Router Class Initialized
INFO - 2025-03-19 05:43:35 --> Output Class Initialized
INFO - 2025-03-19 05:43:35 --> Security Class Initialized
DEBUG - 2025-03-19 05:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:43:35 --> Input Class Initialized
INFO - 2025-03-19 05:43:35 --> Language Class Initialized
INFO - 2025-03-19 05:43:35 --> Language Class Initialized
INFO - 2025-03-19 05:43:35 --> Config Class Initialized
INFO - 2025-03-19 05:43:35 --> Loader Class Initialized
INFO - 2025-03-19 05:43:35 --> Helper loaded: url_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: file_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: html_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: form_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: text_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:43:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:43:35 --> Database Driver Class Initialized
INFO - 2025-03-19 05:43:35 --> Email Class Initialized
INFO - 2025-03-19 05:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:43:35 --> Form Validation Class Initialized
INFO - 2025-03-19 05:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:43:35 --> Pagination Class Initialized
INFO - 2025-03-19 05:43:35 --> Controller Class Initialized
DEBUG - 2025-03-19 05:43:35 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:43:35 --> Model Class Initialized
DEBUG - 2025-03-19 05:43:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:43:35 --> Model Class Initialized
ERROR - 2025-03-19 05:43:35 --> Severity: error --> Exception: Call to undefined method Report_model::get_all_bank_list() /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 249
INFO - 2025-03-19 05:45:32 --> Config Class Initialized
INFO - 2025-03-19 05:45:32 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:45:32 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:45:32 --> Utf8 Class Initialized
INFO - 2025-03-19 05:45:32 --> URI Class Initialized
DEBUG - 2025-03-19 05:45:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:45:32 --> Router Class Initialized
INFO - 2025-03-19 05:45:32 --> Output Class Initialized
INFO - 2025-03-19 05:45:32 --> Security Class Initialized
DEBUG - 2025-03-19 05:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:45:32 --> Input Class Initialized
INFO - 2025-03-19 05:45:32 --> Language Class Initialized
INFO - 2025-03-19 05:45:32 --> Language Class Initialized
INFO - 2025-03-19 05:45:32 --> Config Class Initialized
INFO - 2025-03-19 05:45:32 --> Loader Class Initialized
INFO - 2025-03-19 05:45:32 --> Helper loaded: url_helper
INFO - 2025-03-19 05:45:32 --> Helper loaded: file_helper
INFO - 2025-03-19 05:45:32 --> Helper loaded: html_helper
INFO - 2025-03-19 05:45:32 --> Helper loaded: form_helper
INFO - 2025-03-19 05:45:32 --> Helper loaded: text_helper
INFO - 2025-03-19 05:45:32 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:45:32 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:45:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:45:32 --> Database Driver Class Initialized
INFO - 2025-03-19 05:45:32 --> Email Class Initialized
INFO - 2025-03-19 05:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:45:32 --> Form Validation Class Initialized
INFO - 2025-03-19 05:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:45:32 --> Pagination Class Initialized
INFO - 2025-03-19 05:45:32 --> Controller Class Initialized
DEBUG - 2025-03-19 05:45:32 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:45:32 --> Model Class Initialized
DEBUG - 2025-03-19 05:45:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:45:32 --> Model Class Initialized
DEBUG - 2025-03-19 05:45:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:45:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:45:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:45:32 --> Model Class Initialized
ERROR - 2025-03-19 05:45:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:45:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:45:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:45:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:45:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:45:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:45:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:45:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:45:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:45:33 --> Final output sent to browser
DEBUG - 2025-03-19 05:45:33 --> Total execution time: 0.1011
INFO - 2025-03-19 05:45:33 --> Config Class Initialized
INFO - 2025-03-19 05:45:33 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:45:33 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:45:33 --> Utf8 Class Initialized
INFO - 2025-03-19 05:45:33 --> URI Class Initialized
DEBUG - 2025-03-19 05:45:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:45:33 --> Router Class Initialized
INFO - 2025-03-19 05:45:33 --> Output Class Initialized
INFO - 2025-03-19 05:45:33 --> Security Class Initialized
DEBUG - 2025-03-19 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:45:33 --> Input Class Initialized
INFO - 2025-03-19 05:45:33 --> Language Class Initialized
INFO - 2025-03-19 05:45:33 --> Language Class Initialized
INFO - 2025-03-19 05:45:33 --> Config Class Initialized
INFO - 2025-03-19 05:45:33 --> Loader Class Initialized
INFO - 2025-03-19 05:45:33 --> Helper loaded: url_helper
INFO - 2025-03-19 05:45:33 --> Helper loaded: file_helper
INFO - 2025-03-19 05:45:33 --> Helper loaded: html_helper
INFO - 2025-03-19 05:45:33 --> Helper loaded: form_helper
INFO - 2025-03-19 05:45:33 --> Helper loaded: text_helper
INFO - 2025-03-19 05:45:33 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:45:33 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:45:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:45:33 --> Database Driver Class Initialized
INFO - 2025-03-19 05:45:33 --> Email Class Initialized
INFO - 2025-03-19 05:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:45:33 --> Form Validation Class Initialized
INFO - 2025-03-19 05:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:45:33 --> Pagination Class Initialized
INFO - 2025-03-19 05:45:33 --> Controller Class Initialized
DEBUG - 2025-03-19 05:45:33 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:45:33 --> Model Class Initialized
DEBUG - 2025-03-19 05:45:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:45:33 --> Model Class Initialized
ERROR - 2025-03-19 05:45:33 --> Severity: error --> Exception: Call to undefined method Report_model::get_all_bank_list() /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 249
INFO - 2025-03-19 05:45:56 --> Config Class Initialized
INFO - 2025-03-19 05:45:56 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:45:56 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:45:56 --> Utf8 Class Initialized
INFO - 2025-03-19 05:45:56 --> URI Class Initialized
DEBUG - 2025-03-19 05:45:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:45:56 --> Router Class Initialized
INFO - 2025-03-19 05:45:56 --> Output Class Initialized
INFO - 2025-03-19 05:45:56 --> Security Class Initialized
DEBUG - 2025-03-19 05:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:45:56 --> Input Class Initialized
INFO - 2025-03-19 05:45:56 --> Language Class Initialized
INFO - 2025-03-19 05:45:56 --> Language Class Initialized
INFO - 2025-03-19 05:45:56 --> Config Class Initialized
INFO - 2025-03-19 05:45:56 --> Loader Class Initialized
INFO - 2025-03-19 05:45:56 --> Helper loaded: url_helper
INFO - 2025-03-19 05:45:56 --> Helper loaded: file_helper
INFO - 2025-03-19 05:45:56 --> Helper loaded: html_helper
INFO - 2025-03-19 05:45:56 --> Helper loaded: form_helper
INFO - 2025-03-19 05:45:56 --> Helper loaded: text_helper
INFO - 2025-03-19 05:45:56 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:45:56 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:45:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:45:56 --> Database Driver Class Initialized
INFO - 2025-03-19 05:45:56 --> Email Class Initialized
INFO - 2025-03-19 05:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:45:56 --> Form Validation Class Initialized
INFO - 2025-03-19 05:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:45:56 --> Pagination Class Initialized
INFO - 2025-03-19 05:45:56 --> Controller Class Initialized
DEBUG - 2025-03-19 05:45:56 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:45:56 --> Model Class Initialized
DEBUG - 2025-03-19 05:45:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:45:56 --> Model Class Initialized
DEBUG - 2025-03-19 05:45:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:45:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:45:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:45:56 --> Model Class Initialized
ERROR - 2025-03-19 05:45:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:45:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:45:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:45:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:45:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:45:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:45:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:45:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:45:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:45:57 --> Final output sent to browser
DEBUG - 2025-03-19 05:45:57 --> Total execution time: 0.1079
INFO - 2025-03-19 05:45:57 --> Config Class Initialized
INFO - 2025-03-19 05:45:57 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:45:57 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:45:57 --> Utf8 Class Initialized
INFO - 2025-03-19 05:45:57 --> URI Class Initialized
DEBUG - 2025-03-19 05:45:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:45:57 --> Router Class Initialized
INFO - 2025-03-19 05:45:57 --> Output Class Initialized
INFO - 2025-03-19 05:45:57 --> Security Class Initialized
DEBUG - 2025-03-19 05:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:45:57 --> Input Class Initialized
INFO - 2025-03-19 05:45:57 --> Language Class Initialized
INFO - 2025-03-19 05:45:57 --> Language Class Initialized
INFO - 2025-03-19 05:45:57 --> Config Class Initialized
INFO - 2025-03-19 05:45:57 --> Loader Class Initialized
INFO - 2025-03-19 05:45:57 --> Helper loaded: url_helper
INFO - 2025-03-19 05:45:57 --> Helper loaded: file_helper
INFO - 2025-03-19 05:45:57 --> Helper loaded: html_helper
INFO - 2025-03-19 05:45:57 --> Helper loaded: form_helper
INFO - 2025-03-19 05:45:57 --> Helper loaded: text_helper
INFO - 2025-03-19 05:45:57 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:45:57 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:45:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:45:57 --> Database Driver Class Initialized
INFO - 2025-03-19 05:45:57 --> Email Class Initialized
INFO - 2025-03-19 05:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:45:57 --> Form Validation Class Initialized
INFO - 2025-03-19 05:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:45:57 --> Pagination Class Initialized
INFO - 2025-03-19 05:45:57 --> Controller Class Initialized
DEBUG - 2025-03-19 05:45:57 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:45:57 --> Model Class Initialized
DEBUG - 2025-03-19 05:45:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:45:57 --> Model Class Initialized
ERROR - 2025-03-19 05:45:57 --> Severity: error --> Exception: Call to undefined method Report_model::get_all_bank_list() /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php 249
INFO - 2025-03-19 05:48:15 --> Config Class Initialized
INFO - 2025-03-19 05:48:15 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:48:15 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:48:15 --> Utf8 Class Initialized
INFO - 2025-03-19 05:48:15 --> URI Class Initialized
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:48:15 --> Router Class Initialized
INFO - 2025-03-19 05:48:15 --> Output Class Initialized
INFO - 2025-03-19 05:48:15 --> Security Class Initialized
DEBUG - 2025-03-19 05:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:48:15 --> Input Class Initialized
INFO - 2025-03-19 05:48:15 --> Language Class Initialized
INFO - 2025-03-19 05:48:15 --> Language Class Initialized
INFO - 2025-03-19 05:48:15 --> Config Class Initialized
INFO - 2025-03-19 05:48:15 --> Loader Class Initialized
INFO - 2025-03-19 05:48:15 --> Helper loaded: url_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: file_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: html_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: form_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: text_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:48:15 --> Database Driver Class Initialized
INFO - 2025-03-19 05:48:15 --> Email Class Initialized
INFO - 2025-03-19 05:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:48:15 --> Form Validation Class Initialized
INFO - 2025-03-19 05:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:48:15 --> Pagination Class Initialized
INFO - 2025-03-19 05:48:15 --> Controller Class Initialized
DEBUG - 2025-03-19 05:48:15 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:48:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:48:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:48:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:48:15 --> Model Class Initialized
ERROR - 2025-03-19 05:48:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:48:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:48:15 --> Final output sent to browser
DEBUG - 2025-03-19 05:48:15 --> Total execution time: 0.1585
INFO - 2025-03-19 05:48:15 --> Config Class Initialized
INFO - 2025-03-19 05:48:15 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:48:15 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:48:15 --> Utf8 Class Initialized
INFO - 2025-03-19 05:48:15 --> URI Class Initialized
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:48:15 --> Router Class Initialized
INFO - 2025-03-19 05:48:15 --> Output Class Initialized
INFO - 2025-03-19 05:48:15 --> Security Class Initialized
DEBUG - 2025-03-19 05:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:48:15 --> Input Class Initialized
INFO - 2025-03-19 05:48:15 --> Language Class Initialized
INFO - 2025-03-19 05:48:15 --> Language Class Initialized
INFO - 2025-03-19 05:48:15 --> Config Class Initialized
INFO - 2025-03-19 05:48:15 --> Loader Class Initialized
INFO - 2025-03-19 05:48:15 --> Helper loaded: url_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: file_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: html_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: form_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: text_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:48:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:48:15 --> Database Driver Class Initialized
INFO - 2025-03-19 05:48:15 --> Email Class Initialized
INFO - 2025-03-19 05:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:48:15 --> Form Validation Class Initialized
INFO - 2025-03-19 05:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:48:15 --> Pagination Class Initialized
INFO - 2025-03-19 05:48:15 --> Controller Class Initialized
DEBUG - 2025-03-19 05:48:15 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:48:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:48:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:48:15 --> Model Class Initialized
ERROR - 2025-03-19 05:48:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 05:48:29 --> Config Class Initialized
INFO - 2025-03-19 05:48:29 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:48:29 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:48:29 --> Utf8 Class Initialized
INFO - 2025-03-19 05:48:29 --> URI Class Initialized
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:48:29 --> Router Class Initialized
INFO - 2025-03-19 05:48:29 --> Output Class Initialized
INFO - 2025-03-19 05:48:29 --> Security Class Initialized
DEBUG - 2025-03-19 05:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:48:29 --> Input Class Initialized
INFO - 2025-03-19 05:48:29 --> Language Class Initialized
INFO - 2025-03-19 05:48:29 --> Language Class Initialized
INFO - 2025-03-19 05:48:29 --> Config Class Initialized
INFO - 2025-03-19 05:48:29 --> Loader Class Initialized
INFO - 2025-03-19 05:48:29 --> Helper loaded: url_helper
INFO - 2025-03-19 05:48:29 --> Helper loaded: file_helper
INFO - 2025-03-19 05:48:29 --> Helper loaded: html_helper
INFO - 2025-03-19 05:48:29 --> Helper loaded: form_helper
INFO - 2025-03-19 05:48:29 --> Helper loaded: text_helper
INFO - 2025-03-19 05:48:29 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:48:29 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:48:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:48:29 --> Database Driver Class Initialized
INFO - 2025-03-19 05:48:29 --> Email Class Initialized
INFO - 2025-03-19 05:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:48:29 --> Form Validation Class Initialized
INFO - 2025-03-19 05:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:48:29 --> Pagination Class Initialized
INFO - 2025-03-19 05:48:29 --> Controller Class Initialized
DEBUG - 2025-03-19 05:48:29 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:48:29 --> Model Class Initialized
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:48:29 --> Model Class Initialized
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:48:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:48:29 --> Model Class Initialized
ERROR - 2025-03-19 05:48:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:48:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:48:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:48:29 --> Final output sent to browser
DEBUG - 2025-03-19 05:48:29 --> Total execution time: 0.1512
INFO - 2025-03-19 05:48:30 --> Config Class Initialized
INFO - 2025-03-19 05:48:30 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:48:30 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:48:30 --> Utf8 Class Initialized
INFO - 2025-03-19 05:48:30 --> URI Class Initialized
DEBUG - 2025-03-19 05:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:48:30 --> Router Class Initialized
INFO - 2025-03-19 05:48:30 --> Output Class Initialized
INFO - 2025-03-19 05:48:30 --> Security Class Initialized
DEBUG - 2025-03-19 05:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:48:30 --> Input Class Initialized
INFO - 2025-03-19 05:48:30 --> Language Class Initialized
INFO - 2025-03-19 05:48:30 --> Language Class Initialized
INFO - 2025-03-19 05:48:30 --> Config Class Initialized
INFO - 2025-03-19 05:48:30 --> Loader Class Initialized
INFO - 2025-03-19 05:48:30 --> Helper loaded: url_helper
INFO - 2025-03-19 05:48:30 --> Helper loaded: file_helper
INFO - 2025-03-19 05:48:30 --> Helper loaded: html_helper
INFO - 2025-03-19 05:48:30 --> Helper loaded: form_helper
INFO - 2025-03-19 05:48:30 --> Helper loaded: text_helper
INFO - 2025-03-19 05:48:30 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:48:30 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:48:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:48:30 --> Database Driver Class Initialized
INFO - 2025-03-19 05:48:30 --> Email Class Initialized
INFO - 2025-03-19 05:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:48:30 --> Form Validation Class Initialized
INFO - 2025-03-19 05:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:48:30 --> Pagination Class Initialized
INFO - 2025-03-19 05:48:30 --> Controller Class Initialized
DEBUG - 2025-03-19 05:48:30 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:48:30 --> Model Class Initialized
DEBUG - 2025-03-19 05:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:48:30 --> Model Class Initialized
ERROR - 2025-03-19 05:48:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 05:55:05 --> Config Class Initialized
INFO - 2025-03-19 05:55:05 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:55:05 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:55:05 --> Utf8 Class Initialized
INFO - 2025-03-19 05:55:05 --> URI Class Initialized
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:55:05 --> Router Class Initialized
INFO - 2025-03-19 05:55:05 --> Output Class Initialized
INFO - 2025-03-19 05:55:05 --> Security Class Initialized
DEBUG - 2025-03-19 05:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:55:05 --> Input Class Initialized
INFO - 2025-03-19 05:55:05 --> Language Class Initialized
INFO - 2025-03-19 05:55:05 --> Language Class Initialized
INFO - 2025-03-19 05:55:05 --> Config Class Initialized
INFO - 2025-03-19 05:55:05 --> Loader Class Initialized
INFO - 2025-03-19 05:55:05 --> Helper loaded: url_helper
INFO - 2025-03-19 05:55:05 --> Helper loaded: file_helper
INFO - 2025-03-19 05:55:05 --> Helper loaded: html_helper
INFO - 2025-03-19 05:55:05 --> Helper loaded: form_helper
INFO - 2025-03-19 05:55:05 --> Helper loaded: text_helper
INFO - 2025-03-19 05:55:05 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:55:05 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:55:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:55:05 --> Database Driver Class Initialized
INFO - 2025-03-19 05:55:05 --> Email Class Initialized
INFO - 2025-03-19 05:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:55:05 --> Form Validation Class Initialized
INFO - 2025-03-19 05:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:55:05 --> Pagination Class Initialized
INFO - 2025-03-19 05:55:05 --> Controller Class Initialized
DEBUG - 2025-03-19 05:55:05 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:55:05 --> Model Class Initialized
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:55:05 --> Model Class Initialized
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:55:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:55:05 --> Model Class Initialized
ERROR - 2025-03-19 05:55:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:55:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:55:05 --> Final output sent to browser
DEBUG - 2025-03-19 05:55:05 --> Total execution time: 0.1399
INFO - 2025-03-19 05:55:06 --> Config Class Initialized
INFO - 2025-03-19 05:55:06 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:55:06 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:55:06 --> Utf8 Class Initialized
INFO - 2025-03-19 05:55:06 --> URI Class Initialized
DEBUG - 2025-03-19 05:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:55:06 --> Router Class Initialized
INFO - 2025-03-19 05:55:06 --> Output Class Initialized
INFO - 2025-03-19 05:55:06 --> Security Class Initialized
DEBUG - 2025-03-19 05:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:55:06 --> Input Class Initialized
INFO - 2025-03-19 05:55:06 --> Language Class Initialized
INFO - 2025-03-19 05:55:06 --> Language Class Initialized
INFO - 2025-03-19 05:55:06 --> Config Class Initialized
INFO - 2025-03-19 05:55:06 --> Loader Class Initialized
INFO - 2025-03-19 05:55:06 --> Helper loaded: url_helper
INFO - 2025-03-19 05:55:06 --> Helper loaded: file_helper
INFO - 2025-03-19 05:55:06 --> Helper loaded: html_helper
INFO - 2025-03-19 05:55:06 --> Helper loaded: form_helper
INFO - 2025-03-19 05:55:06 --> Helper loaded: text_helper
INFO - 2025-03-19 05:55:06 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:55:06 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:55:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:55:06 --> Database Driver Class Initialized
INFO - 2025-03-19 05:55:06 --> Email Class Initialized
INFO - 2025-03-19 05:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:55:06 --> Form Validation Class Initialized
INFO - 2025-03-19 05:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:55:06 --> Pagination Class Initialized
INFO - 2025-03-19 05:55:06 --> Controller Class Initialized
DEBUG - 2025-03-19 05:55:06 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:55:06 --> Model Class Initialized
DEBUG - 2025-03-19 05:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:55:06 --> Model Class Initialized
ERROR - 2025-03-19 05:55:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 05:56:48 --> Config Class Initialized
INFO - 2025-03-19 05:56:48 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:56:48 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:56:48 --> Utf8 Class Initialized
INFO - 2025-03-19 05:56:48 --> URI Class Initialized
DEBUG - 2025-03-19 05:56:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:56:48 --> Router Class Initialized
INFO - 2025-03-19 05:56:48 --> Output Class Initialized
INFO - 2025-03-19 05:56:48 --> Security Class Initialized
DEBUG - 2025-03-19 05:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:56:48 --> Input Class Initialized
INFO - 2025-03-19 05:56:48 --> Language Class Initialized
INFO - 2025-03-19 05:56:48 --> Language Class Initialized
INFO - 2025-03-19 05:56:48 --> Config Class Initialized
INFO - 2025-03-19 05:56:48 --> Loader Class Initialized
INFO - 2025-03-19 05:56:48 --> Helper loaded: url_helper
INFO - 2025-03-19 05:56:48 --> Helper loaded: file_helper
INFO - 2025-03-19 05:56:48 --> Helper loaded: html_helper
INFO - 2025-03-19 05:56:48 --> Helper loaded: form_helper
INFO - 2025-03-19 05:56:48 --> Helper loaded: text_helper
INFO - 2025-03-19 05:56:48 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:56:48 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:56:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:56:48 --> Database Driver Class Initialized
INFO - 2025-03-19 05:56:48 --> Email Class Initialized
INFO - 2025-03-19 05:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:56:48 --> Form Validation Class Initialized
INFO - 2025-03-19 05:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:56:48 --> Pagination Class Initialized
INFO - 2025-03-19 05:56:48 --> Controller Class Initialized
DEBUG - 2025-03-19 05:56:48 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:56:48 --> Model Class Initialized
DEBUG - 2025-03-19 05:56:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:56:48 --> Model Class Initialized
DEBUG - 2025-03-19 05:56:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:56:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:56:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:56:48 --> Model Class Initialized
ERROR - 2025-03-19 05:56:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:56:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:56:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:56:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:56:49 --> Final output sent to browser
DEBUG - 2025-03-19 05:56:49 --> Total execution time: 0.1258
INFO - 2025-03-19 05:56:49 --> Config Class Initialized
INFO - 2025-03-19 05:56:49 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:56:49 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:56:49 --> Utf8 Class Initialized
INFO - 2025-03-19 05:56:49 --> URI Class Initialized
DEBUG - 2025-03-19 05:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:56:49 --> Router Class Initialized
INFO - 2025-03-19 05:56:49 --> Output Class Initialized
INFO - 2025-03-19 05:56:49 --> Security Class Initialized
DEBUG - 2025-03-19 05:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:56:49 --> Input Class Initialized
INFO - 2025-03-19 05:56:49 --> Language Class Initialized
INFO - 2025-03-19 05:56:49 --> Language Class Initialized
INFO - 2025-03-19 05:56:49 --> Config Class Initialized
INFO - 2025-03-19 05:56:49 --> Loader Class Initialized
INFO - 2025-03-19 05:56:49 --> Helper loaded: url_helper
INFO - 2025-03-19 05:56:49 --> Helper loaded: file_helper
INFO - 2025-03-19 05:56:49 --> Helper loaded: html_helper
INFO - 2025-03-19 05:56:49 --> Helper loaded: form_helper
INFO - 2025-03-19 05:56:49 --> Helper loaded: text_helper
INFO - 2025-03-19 05:56:49 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:56:49 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:56:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:56:49 --> Database Driver Class Initialized
INFO - 2025-03-19 05:56:49 --> Email Class Initialized
INFO - 2025-03-19 05:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:56:49 --> Form Validation Class Initialized
INFO - 2025-03-19 05:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:56:49 --> Pagination Class Initialized
INFO - 2025-03-19 05:56:49 --> Controller Class Initialized
DEBUG - 2025-03-19 05:56:49 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:56:49 --> Model Class Initialized
DEBUG - 2025-03-19 05:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:56:49 --> Model Class Initialized
ERROR - 2025-03-19 05:56:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 05:57:15 --> Config Class Initialized
INFO - 2025-03-19 05:57:15 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:57:15 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:57:15 --> Utf8 Class Initialized
INFO - 2025-03-19 05:57:15 --> URI Class Initialized
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:57:15 --> Router Class Initialized
INFO - 2025-03-19 05:57:15 --> Output Class Initialized
INFO - 2025-03-19 05:57:15 --> Security Class Initialized
DEBUG - 2025-03-19 05:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:57:15 --> Input Class Initialized
INFO - 2025-03-19 05:57:15 --> Language Class Initialized
INFO - 2025-03-19 05:57:15 --> Language Class Initialized
INFO - 2025-03-19 05:57:15 --> Config Class Initialized
INFO - 2025-03-19 05:57:15 --> Loader Class Initialized
INFO - 2025-03-19 05:57:15 --> Helper loaded: url_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: file_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: html_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: form_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: text_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:57:15 --> Database Driver Class Initialized
INFO - 2025-03-19 05:57:15 --> Email Class Initialized
INFO - 2025-03-19 05:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:57:15 --> Form Validation Class Initialized
INFO - 2025-03-19 05:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:57:15 --> Pagination Class Initialized
INFO - 2025-03-19 05:57:15 --> Controller Class Initialized
DEBUG - 2025-03-19 05:57:15 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:57:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:57:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:57:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:57:15 --> Model Class Initialized
ERROR - 2025-03-19 05:57:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:57:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:57:15 --> Final output sent to browser
DEBUG - 2025-03-19 05:57:15 --> Total execution time: 0.1670
INFO - 2025-03-19 05:57:15 --> Config Class Initialized
INFO - 2025-03-19 05:57:15 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:57:15 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:57:15 --> Utf8 Class Initialized
INFO - 2025-03-19 05:57:15 --> URI Class Initialized
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:57:15 --> Router Class Initialized
INFO - 2025-03-19 05:57:15 --> Output Class Initialized
INFO - 2025-03-19 05:57:15 --> Security Class Initialized
DEBUG - 2025-03-19 05:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:57:15 --> Input Class Initialized
INFO - 2025-03-19 05:57:15 --> Language Class Initialized
INFO - 2025-03-19 05:57:15 --> Language Class Initialized
INFO - 2025-03-19 05:57:15 --> Config Class Initialized
INFO - 2025-03-19 05:57:15 --> Loader Class Initialized
INFO - 2025-03-19 05:57:15 --> Helper loaded: url_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: file_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: html_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: form_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: text_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:57:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:57:15 --> Database Driver Class Initialized
INFO - 2025-03-19 05:57:15 --> Email Class Initialized
INFO - 2025-03-19 05:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:57:15 --> Form Validation Class Initialized
INFO - 2025-03-19 05:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:57:15 --> Pagination Class Initialized
INFO - 2025-03-19 05:57:15 --> Controller Class Initialized
DEBUG - 2025-03-19 05:57:15 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:57:15 --> Model Class Initialized
DEBUG - 2025-03-19 05:57:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:57:15 --> Model Class Initialized
ERROR - 2025-03-19 05:57:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 05:59:33 --> Config Class Initialized
INFO - 2025-03-19 05:59:33 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:33 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:33 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:33 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:33 --> Router Class Initialized
INFO - 2025-03-19 05:59:33 --> Output Class Initialized
INFO - 2025-03-19 05:59:33 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:33 --> Input Class Initialized
INFO - 2025-03-19 05:59:33 --> Language Class Initialized
INFO - 2025-03-19 05:59:33 --> Language Class Initialized
INFO - 2025-03-19 05:59:33 --> Config Class Initialized
INFO - 2025-03-19 05:59:33 --> Loader Class Initialized
INFO - 2025-03-19 05:59:33 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:33 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:33 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:33 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:33 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:33 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:33 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:33 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:33 --> Email Class Initialized
INFO - 2025-03-19 05:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:33 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:33 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:33 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:33 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:33 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:33 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:59:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:59:33 --> Model Class Initialized
ERROR - 2025-03-19 05:59:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:59:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:59:33 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:33 --> Total execution time: 0.1380
INFO - 2025-03-19 05:59:34 --> Config Class Initialized
INFO - 2025-03-19 05:59:34 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:34 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:34 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:34 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:34 --> Router Class Initialized
INFO - 2025-03-19 05:59:34 --> Output Class Initialized
INFO - 2025-03-19 05:59:34 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:34 --> Input Class Initialized
INFO - 2025-03-19 05:59:34 --> Language Class Initialized
INFO - 2025-03-19 05:59:34 --> Language Class Initialized
INFO - 2025-03-19 05:59:34 --> Config Class Initialized
INFO - 2025-03-19 05:59:34 --> Loader Class Initialized
INFO - 2025-03-19 05:59:34 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:34 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:34 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:34 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:34 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:34 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:34 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:34 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:34 --> Email Class Initialized
INFO - 2025-03-19 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:34 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:34 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:34 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:34 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:34 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:34 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 05:59:34 --> Model Class Initialized
INFO - 2025-03-19 05:59:34 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:34 --> Total execution time: 0.0088
INFO - 2025-03-19 05:59:36 --> Config Class Initialized
INFO - 2025-03-19 05:59:36 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:36 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:36 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:36 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:36 --> Router Class Initialized
INFO - 2025-03-19 05:59:36 --> Output Class Initialized
INFO - 2025-03-19 05:59:36 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:36 --> Input Class Initialized
INFO - 2025-03-19 05:59:36 --> Language Class Initialized
INFO - 2025-03-19 05:59:36 --> Language Class Initialized
INFO - 2025-03-19 05:59:36 --> Config Class Initialized
INFO - 2025-03-19 05:59:36 --> Loader Class Initialized
INFO - 2025-03-19 05:59:36 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:36 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:36 --> Email Class Initialized
INFO - 2025-03-19 05:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:36 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:36 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:36 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:36 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:36 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:36 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:59:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:59:36 --> Model Class Initialized
ERROR - 2025-03-19 05:59:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:59:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:59:36 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:36 --> Total execution time: 0.1808
INFO - 2025-03-19 05:59:36 --> Config Class Initialized
INFO - 2025-03-19 05:59:36 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:36 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:36 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:36 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:36 --> Router Class Initialized
INFO - 2025-03-19 05:59:36 --> Output Class Initialized
INFO - 2025-03-19 05:59:36 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:36 --> Input Class Initialized
INFO - 2025-03-19 05:59:36 --> Language Class Initialized
INFO - 2025-03-19 05:59:36 --> Language Class Initialized
INFO - 2025-03-19 05:59:36 --> Config Class Initialized
INFO - 2025-03-19 05:59:36 --> Loader Class Initialized
INFO - 2025-03-19 05:59:36 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:36 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:36 --> Email Class Initialized
INFO - 2025-03-19 05:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:36 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:36 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:36 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:36 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:36 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:36 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 05:59:36 --> Model Class Initialized
INFO - 2025-03-19 05:59:36 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:36 --> Total execution time: 0.0116
INFO - 2025-03-19 05:59:42 --> Config Class Initialized
INFO - 2025-03-19 05:59:42 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:42 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:42 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:42 --> Router Class Initialized
INFO - 2025-03-19 05:59:42 --> Output Class Initialized
INFO - 2025-03-19 05:59:42 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:42 --> Input Class Initialized
INFO - 2025-03-19 05:59:42 --> Language Class Initialized
INFO - 2025-03-19 05:59:42 --> Language Class Initialized
INFO - 2025-03-19 05:59:42 --> Config Class Initialized
INFO - 2025-03-19 05:59:42 --> Loader Class Initialized
INFO - 2025-03-19 05:59:42 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:42 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:42 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:42 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:42 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:42 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:42 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:42 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:42 --> Email Class Initialized
INFO - 2025-03-19 05:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:42 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:42 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:42 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:42 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:42 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:42 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:59:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:59:42 --> Model Class Initialized
ERROR - 2025-03-19 05:59:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:59:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:59:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:59:42 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:42 --> Total execution time: 0.1501
INFO - 2025-03-19 05:59:43 --> Config Class Initialized
INFO - 2025-03-19 05:59:43 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:43 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:43 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:43 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:43 --> Router Class Initialized
INFO - 2025-03-19 05:59:43 --> Output Class Initialized
INFO - 2025-03-19 05:59:43 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:43 --> Input Class Initialized
INFO - 2025-03-19 05:59:43 --> Language Class Initialized
INFO - 2025-03-19 05:59:43 --> Language Class Initialized
INFO - 2025-03-19 05:59:43 --> Config Class Initialized
INFO - 2025-03-19 05:59:43 --> Loader Class Initialized
INFO - 2025-03-19 05:59:43 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:43 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:43 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:43 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:43 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:43 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:43 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:43 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:43 --> Email Class Initialized
INFO - 2025-03-19 05:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:43 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:43 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:43 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:43 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:43 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:43 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 05:59:43 --> Model Class Initialized
INFO - 2025-03-19 05:59:43 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:43 --> Total execution time: 0.0085
INFO - 2025-03-19 05:59:55 --> Config Class Initialized
INFO - 2025-03-19 05:59:55 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:55 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:55 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:55 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:55 --> Router Class Initialized
INFO - 2025-03-19 05:59:55 --> Output Class Initialized
INFO - 2025-03-19 05:59:55 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:55 --> Input Class Initialized
INFO - 2025-03-19 05:59:55 --> Language Class Initialized
INFO - 2025-03-19 05:59:55 --> Language Class Initialized
INFO - 2025-03-19 05:59:55 --> Config Class Initialized
INFO - 2025-03-19 05:59:55 --> Loader Class Initialized
INFO - 2025-03-19 05:59:55 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:55 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:55 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:55 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:55 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:55 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:55 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:55 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:55 --> Email Class Initialized
INFO - 2025-03-19 05:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:55 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:55 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:55 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:55 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:55 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:55 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 05:59:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 05:59:55 --> Model Class Initialized
ERROR - 2025-03-19 05:59:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 05:59:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 05:59:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 05:59:55 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:55 --> Total execution time: 0.1518
INFO - 2025-03-19 05:59:56 --> Config Class Initialized
INFO - 2025-03-19 05:59:56 --> Hooks Class Initialized
DEBUG - 2025-03-19 05:59:56 --> UTF-8 Support Enabled
INFO - 2025-03-19 05:59:56 --> Utf8 Class Initialized
INFO - 2025-03-19 05:59:56 --> URI Class Initialized
DEBUG - 2025-03-19 05:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 05:59:56 --> Router Class Initialized
INFO - 2025-03-19 05:59:56 --> Output Class Initialized
INFO - 2025-03-19 05:59:56 --> Security Class Initialized
DEBUG - 2025-03-19 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 05:59:56 --> Input Class Initialized
INFO - 2025-03-19 05:59:56 --> Language Class Initialized
INFO - 2025-03-19 05:59:56 --> Language Class Initialized
INFO - 2025-03-19 05:59:56 --> Config Class Initialized
INFO - 2025-03-19 05:59:56 --> Loader Class Initialized
INFO - 2025-03-19 05:59:56 --> Helper loaded: url_helper
INFO - 2025-03-19 05:59:56 --> Helper loaded: file_helper
INFO - 2025-03-19 05:59:56 --> Helper loaded: html_helper
INFO - 2025-03-19 05:59:56 --> Helper loaded: form_helper
INFO - 2025-03-19 05:59:56 --> Helper loaded: text_helper
INFO - 2025-03-19 05:59:56 --> Helper loaded: lang_helper
INFO - 2025-03-19 05:59:56 --> Helper loaded: directory_helper
INFO - 2025-03-19 05:59:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 05:59:56 --> Database Driver Class Initialized
INFO - 2025-03-19 05:59:56 --> Email Class Initialized
INFO - 2025-03-19 05:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 05:59:56 --> Form Validation Class Initialized
INFO - 2025-03-19 05:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 05:59:56 --> Pagination Class Initialized
INFO - 2025-03-19 05:59:56 --> Controller Class Initialized
DEBUG - 2025-03-19 05:59:56 --> Report MX_Controller Initialized
INFO - 2025-03-19 05:59:56 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 05:59:56 --> Model Class Initialized
DEBUG - 2025-03-19 05:59:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 05:59:56 --> Model Class Initialized
INFO - 2025-03-19 05:59:56 --> Final output sent to browser
DEBUG - 2025-03-19 05:59:56 --> Total execution time: 0.0093
INFO - 2025-03-19 06:05:24 --> Config Class Initialized
INFO - 2025-03-19 06:05:24 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:24 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:24 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:24 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:24 --> Router Class Initialized
INFO - 2025-03-19 06:05:24 --> Output Class Initialized
INFO - 2025-03-19 06:05:24 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:24 --> Input Class Initialized
INFO - 2025-03-19 06:05:24 --> Language Class Initialized
INFO - 2025-03-19 06:05:24 --> Language Class Initialized
INFO - 2025-03-19 06:05:24 --> Config Class Initialized
INFO - 2025-03-19 06:05:24 --> Loader Class Initialized
INFO - 2025-03-19 06:05:24 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:24 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:24 --> Email Class Initialized
INFO - 2025-03-19 06:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:24 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:24 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:24 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:24 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:24 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:24 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 06:05:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 06:05:24 --> Model Class Initialized
ERROR - 2025-03-19 06:05:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 06:05:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 06:05:24 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:24 --> Total execution time: 0.3942
INFO - 2025-03-19 06:05:24 --> Config Class Initialized
INFO - 2025-03-19 06:05:24 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:24 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:24 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:24 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:24 --> Router Class Initialized
INFO - 2025-03-19 06:05:24 --> Output Class Initialized
INFO - 2025-03-19 06:05:24 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:24 --> Input Class Initialized
INFO - 2025-03-19 06:05:24 --> Language Class Initialized
INFO - 2025-03-19 06:05:24 --> Language Class Initialized
INFO - 2025-03-19 06:05:24 --> Config Class Initialized
INFO - 2025-03-19 06:05:24 --> Loader Class Initialized
INFO - 2025-03-19 06:05:24 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:24 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:24 --> Email Class Initialized
INFO - 2025-03-19 06:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:24 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:24 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:24 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:24 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:24 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:24 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 06:05:24 --> Model Class Initialized
INFO - 2025-03-19 06:05:24 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:24 --> Total execution time: 0.0093
INFO - 2025-03-19 06:05:41 --> Config Class Initialized
INFO - 2025-03-19 06:05:41 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:41 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:41 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:41 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:41 --> Router Class Initialized
INFO - 2025-03-19 06:05:41 --> Output Class Initialized
INFO - 2025-03-19 06:05:41 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:41 --> Input Class Initialized
INFO - 2025-03-19 06:05:41 --> Language Class Initialized
INFO - 2025-03-19 06:05:41 --> Language Class Initialized
INFO - 2025-03-19 06:05:41 --> Config Class Initialized
INFO - 2025-03-19 06:05:41 --> Loader Class Initialized
INFO - 2025-03-19 06:05:41 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:41 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:41 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:41 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:41 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:41 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:41 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:41 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:41 --> Email Class Initialized
INFO - 2025-03-19 06:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:41 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:41 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:41 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:41 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:41 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:41 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 06:05:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 06:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 06:05:41 --> Model Class Initialized
ERROR - 2025-03-19 06:05:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 06:05:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 06:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 06:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 06:05:42 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:42 --> Total execution time: 0.1694
INFO - 2025-03-19 06:05:42 --> Config Class Initialized
INFO - 2025-03-19 06:05:42 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:42 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:42 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:42 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:42 --> Router Class Initialized
INFO - 2025-03-19 06:05:42 --> Output Class Initialized
INFO - 2025-03-19 06:05:42 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:42 --> Input Class Initialized
INFO - 2025-03-19 06:05:42 --> Language Class Initialized
INFO - 2025-03-19 06:05:42 --> Language Class Initialized
INFO - 2025-03-19 06:05:42 --> Config Class Initialized
INFO - 2025-03-19 06:05:42 --> Loader Class Initialized
INFO - 2025-03-19 06:05:42 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:42 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:42 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:42 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:42 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:42 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:42 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:42 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:42 --> Email Class Initialized
INFO - 2025-03-19 06:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:42 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:42 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:42 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:42 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:42 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:42 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 06:05:42 --> Model Class Initialized
INFO - 2025-03-19 06:05:42 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:42 --> Total execution time: 0.0086
INFO - 2025-03-19 06:05:51 --> Config Class Initialized
INFO - 2025-03-19 06:05:51 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:51 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:51 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:51 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:51 --> Router Class Initialized
INFO - 2025-03-19 06:05:51 --> Output Class Initialized
INFO - 2025-03-19 06:05:51 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:51 --> Input Class Initialized
INFO - 2025-03-19 06:05:51 --> Language Class Initialized
INFO - 2025-03-19 06:05:51 --> Language Class Initialized
INFO - 2025-03-19 06:05:51 --> Config Class Initialized
INFO - 2025-03-19 06:05:51 --> Loader Class Initialized
INFO - 2025-03-19 06:05:51 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:51 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:51 --> Email Class Initialized
INFO - 2025-03-19 06:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:51 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:51 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:51 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:51 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:51 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:51 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 06:05:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 06:05:51 --> Model Class Initialized
ERROR - 2025-03-19 06:05:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 06:05:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 06:05:51 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:51 --> Total execution time: 0.1237
INFO - 2025-03-19 06:05:51 --> Config Class Initialized
INFO - 2025-03-19 06:05:51 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:51 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:51 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:51 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:51 --> Router Class Initialized
INFO - 2025-03-19 06:05:51 --> Output Class Initialized
INFO - 2025-03-19 06:05:51 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:51 --> Input Class Initialized
INFO - 2025-03-19 06:05:51 --> Language Class Initialized
INFO - 2025-03-19 06:05:51 --> Language Class Initialized
INFO - 2025-03-19 06:05:51 --> Config Class Initialized
INFO - 2025-03-19 06:05:51 --> Loader Class Initialized
INFO - 2025-03-19 06:05:51 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:51 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:51 --> Email Class Initialized
INFO - 2025-03-19 06:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:51 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:51 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:51 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:51 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:51 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:51 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 06:05:51 --> Model Class Initialized
INFO - 2025-03-19 06:05:51 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:51 --> Total execution time: 0.0070
INFO - 2025-03-19 06:05:59 --> Config Class Initialized
INFO - 2025-03-19 06:05:59 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:59 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:59 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:59 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:59 --> Router Class Initialized
INFO - 2025-03-19 06:05:59 --> Output Class Initialized
INFO - 2025-03-19 06:05:59 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:59 --> Input Class Initialized
INFO - 2025-03-19 06:05:59 --> Language Class Initialized
INFO - 2025-03-19 06:05:59 --> Language Class Initialized
INFO - 2025-03-19 06:05:59 --> Config Class Initialized
INFO - 2025-03-19 06:05:59 --> Loader Class Initialized
INFO - 2025-03-19 06:05:59 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:59 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:59 --> Email Class Initialized
INFO - 2025-03-19 06:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:59 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:59 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:59 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:59 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:59 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:59 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 06:05:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 06:05:59 --> Model Class Initialized
ERROR - 2025-03-19 06:05:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 06:05:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 06:05:59 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:59 --> Total execution time: 0.1479
INFO - 2025-03-19 06:05:59 --> Config Class Initialized
INFO - 2025-03-19 06:05:59 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:05:59 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:05:59 --> Utf8 Class Initialized
INFO - 2025-03-19 06:05:59 --> URI Class Initialized
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:05:59 --> Router Class Initialized
INFO - 2025-03-19 06:05:59 --> Output Class Initialized
INFO - 2025-03-19 06:05:59 --> Security Class Initialized
DEBUG - 2025-03-19 06:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:05:59 --> Input Class Initialized
INFO - 2025-03-19 06:05:59 --> Language Class Initialized
INFO - 2025-03-19 06:05:59 --> Language Class Initialized
INFO - 2025-03-19 06:05:59 --> Config Class Initialized
INFO - 2025-03-19 06:05:59 --> Loader Class Initialized
INFO - 2025-03-19 06:05:59 --> Helper loaded: url_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: file_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: html_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: form_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: text_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:05:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:05:59 --> Database Driver Class Initialized
INFO - 2025-03-19 06:05:59 --> Email Class Initialized
INFO - 2025-03-19 06:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:05:59 --> Form Validation Class Initialized
INFO - 2025-03-19 06:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:05:59 --> Pagination Class Initialized
INFO - 2025-03-19 06:05:59 --> Controller Class Initialized
DEBUG - 2025-03-19 06:05:59 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:05:59 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:05:59 --> Model Class Initialized
DEBUG - 2025-03-19 06:05:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 06:05:59 --> Model Class Initialized
INFO - 2025-03-19 06:05:59 --> Final output sent to browser
DEBUG - 2025-03-19 06:05:59 --> Total execution time: 0.0091
INFO - 2025-03-19 06:11:56 --> Config Class Initialized
INFO - 2025-03-19 06:11:56 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:11:56 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:11:56 --> Utf8 Class Initialized
INFO - 2025-03-19 06:11:56 --> URI Class Initialized
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:11:56 --> Router Class Initialized
INFO - 2025-03-19 06:11:56 --> Output Class Initialized
INFO - 2025-03-19 06:11:56 --> Security Class Initialized
DEBUG - 2025-03-19 06:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:11:56 --> Input Class Initialized
INFO - 2025-03-19 06:11:56 --> Language Class Initialized
INFO - 2025-03-19 06:11:56 --> Language Class Initialized
INFO - 2025-03-19 06:11:56 --> Config Class Initialized
INFO - 2025-03-19 06:11:56 --> Loader Class Initialized
INFO - 2025-03-19 06:11:56 --> Helper loaded: url_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: file_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: html_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: form_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: text_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:11:56 --> Database Driver Class Initialized
INFO - 2025-03-19 06:11:56 --> Email Class Initialized
INFO - 2025-03-19 06:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:11:56 --> Form Validation Class Initialized
INFO - 2025-03-19 06:11:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:11:56 --> Pagination Class Initialized
INFO - 2025-03-19 06:11:56 --> Controller Class Initialized
DEBUG - 2025-03-19 06:11:56 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:11:56 --> Model Class Initialized
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:11:56 --> Model Class Initialized
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 06:11:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 06:11:56 --> Model Class Initialized
ERROR - 2025-03-19 06:11:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 06:11:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 06:11:56 --> Final output sent to browser
DEBUG - 2025-03-19 06:11:56 --> Total execution time: 0.1108
INFO - 2025-03-19 06:11:56 --> Config Class Initialized
INFO - 2025-03-19 06:11:56 --> Hooks Class Initialized
DEBUG - 2025-03-19 06:11:56 --> UTF-8 Support Enabled
INFO - 2025-03-19 06:11:56 --> Utf8 Class Initialized
INFO - 2025-03-19 06:11:56 --> URI Class Initialized
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 06:11:56 --> Router Class Initialized
INFO - 2025-03-19 06:11:56 --> Output Class Initialized
INFO - 2025-03-19 06:11:56 --> Security Class Initialized
DEBUG - 2025-03-19 06:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 06:11:56 --> Input Class Initialized
INFO - 2025-03-19 06:11:56 --> Language Class Initialized
INFO - 2025-03-19 06:11:56 --> Language Class Initialized
INFO - 2025-03-19 06:11:56 --> Config Class Initialized
INFO - 2025-03-19 06:11:56 --> Loader Class Initialized
INFO - 2025-03-19 06:11:56 --> Helper loaded: url_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: file_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: html_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: form_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: text_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: lang_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: directory_helper
INFO - 2025-03-19 06:11:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 06:11:56 --> Database Driver Class Initialized
INFO - 2025-03-19 06:11:56 --> Email Class Initialized
INFO - 2025-03-19 06:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 06:11:56 --> Form Validation Class Initialized
INFO - 2025-03-19 06:11:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 06:11:56 --> Pagination Class Initialized
INFO - 2025-03-19 06:11:56 --> Controller Class Initialized
DEBUG - 2025-03-19 06:11:56 --> Report MX_Controller Initialized
INFO - 2025-03-19 06:11:56 --> Model Class Initialized
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 06:11:56 --> Model Class Initialized
DEBUG - 2025-03-19 06:11:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 06:11:56 --> Model Class Initialized
INFO - 2025-03-19 06:11:56 --> Final output sent to browser
DEBUG - 2025-03-19 06:11:56 --> Total execution time: 0.0094
INFO - 2025-03-19 07:01:46 --> Config Class Initialized
INFO - 2025-03-19 07:01:46 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:01:46 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:01:46 --> Utf8 Class Initialized
INFO - 2025-03-19 07:01:46 --> URI Class Initialized
DEBUG - 2025-03-19 07:01:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:01:46 --> Router Class Initialized
INFO - 2025-03-19 07:01:46 --> Output Class Initialized
INFO - 2025-03-19 07:01:46 --> Security Class Initialized
DEBUG - 2025-03-19 07:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:01:46 --> Input Class Initialized
INFO - 2025-03-19 07:01:46 --> Language Class Initialized
INFO - 2025-03-19 07:01:46 --> Language Class Initialized
INFO - 2025-03-19 07:01:46 --> Config Class Initialized
INFO - 2025-03-19 07:01:46 --> Loader Class Initialized
INFO - 2025-03-19 07:01:46 --> Helper loaded: url_helper
INFO - 2025-03-19 07:01:46 --> Helper loaded: file_helper
INFO - 2025-03-19 07:01:46 --> Helper loaded: html_helper
INFO - 2025-03-19 07:01:46 --> Helper loaded: form_helper
INFO - 2025-03-19 07:01:46 --> Helper loaded: text_helper
INFO - 2025-03-19 07:01:46 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:01:46 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:01:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:01:46 --> Database Driver Class Initialized
INFO - 2025-03-19 07:01:46 --> Email Class Initialized
INFO - 2025-03-19 07:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:01:46 --> Form Validation Class Initialized
INFO - 2025-03-19 07:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:01:46 --> Pagination Class Initialized
INFO - 2025-03-19 07:01:46 --> Controller Class Initialized
DEBUG - 2025-03-19 07:01:46 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:01:46 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:01:46 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:01:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:01:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:01:46 --> Model Class Initialized
ERROR - 2025-03-19 07:01:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:01:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:01:47 --> Final output sent to browser
DEBUG - 2025-03-19 07:01:47 --> Total execution time: 0.7602
INFO - 2025-03-19 07:01:47 --> Config Class Initialized
INFO - 2025-03-19 07:01:47 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:01:47 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:01:47 --> Utf8 Class Initialized
INFO - 2025-03-19 07:01:47 --> URI Class Initialized
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:01:47 --> Router Class Initialized
INFO - 2025-03-19 07:01:47 --> Output Class Initialized
INFO - 2025-03-19 07:01:47 --> Security Class Initialized
DEBUG - 2025-03-19 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:01:47 --> Input Class Initialized
INFO - 2025-03-19 07:01:47 --> Language Class Initialized
INFO - 2025-03-19 07:01:47 --> Language Class Initialized
INFO - 2025-03-19 07:01:47 --> Config Class Initialized
INFO - 2025-03-19 07:01:47 --> Loader Class Initialized
INFO - 2025-03-19 07:01:47 --> Helper loaded: url_helper
INFO - 2025-03-19 07:01:47 --> Helper loaded: file_helper
INFO - 2025-03-19 07:01:47 --> Helper loaded: html_helper
INFO - 2025-03-19 07:01:47 --> Helper loaded: form_helper
INFO - 2025-03-19 07:01:47 --> Helper loaded: text_helper
INFO - 2025-03-19 07:01:47 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:01:47 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:01:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:01:47 --> Database Driver Class Initialized
INFO - 2025-03-19 07:01:47 --> Email Class Initialized
INFO - 2025-03-19 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:01:47 --> Form Validation Class Initialized
INFO - 2025-03-19 07:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:01:47 --> Pagination Class Initialized
INFO - 2025-03-19 07:01:47 --> Controller Class Initialized
DEBUG - 2025-03-19 07:01:47 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:01:47 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:01:47 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:01:47 --> Model Class Initialized
INFO - 2025-03-19 07:01:47 --> Final output sent to browser
DEBUG - 2025-03-19 07:01:47 --> Total execution time: 0.0083
INFO - 2025-03-19 07:01:57 --> Config Class Initialized
INFO - 2025-03-19 07:01:57 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:01:57 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:01:57 --> Utf8 Class Initialized
INFO - 2025-03-19 07:01:57 --> URI Class Initialized
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:01:57 --> Router Class Initialized
INFO - 2025-03-19 07:01:57 --> Output Class Initialized
INFO - 2025-03-19 07:01:57 --> Security Class Initialized
DEBUG - 2025-03-19 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:01:57 --> Input Class Initialized
INFO - 2025-03-19 07:01:57 --> Language Class Initialized
INFO - 2025-03-19 07:01:57 --> Language Class Initialized
INFO - 2025-03-19 07:01:57 --> Config Class Initialized
INFO - 2025-03-19 07:01:57 --> Loader Class Initialized
INFO - 2025-03-19 07:01:57 --> Helper loaded: url_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: file_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: html_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: form_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: text_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:01:57 --> Database Driver Class Initialized
INFO - 2025-03-19 07:01:57 --> Email Class Initialized
INFO - 2025-03-19 07:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:01:57 --> Form Validation Class Initialized
INFO - 2025-03-19 07:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:01:57 --> Pagination Class Initialized
INFO - 2025-03-19 07:01:57 --> Controller Class Initialized
DEBUG - 2025-03-19 07:01:57 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:01:57 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:01:57 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:01:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:01:57 --> Model Class Initialized
ERROR - 2025-03-19 07:01:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:01:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:01:57 --> Final output sent to browser
DEBUG - 2025-03-19 07:01:57 --> Total execution time: 0.1697
INFO - 2025-03-19 07:01:57 --> Config Class Initialized
INFO - 2025-03-19 07:01:57 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:01:57 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:01:57 --> Utf8 Class Initialized
INFO - 2025-03-19 07:01:57 --> URI Class Initialized
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:01:57 --> Router Class Initialized
INFO - 2025-03-19 07:01:57 --> Output Class Initialized
INFO - 2025-03-19 07:01:57 --> Security Class Initialized
DEBUG - 2025-03-19 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:01:57 --> Input Class Initialized
INFO - 2025-03-19 07:01:57 --> Language Class Initialized
INFO - 2025-03-19 07:01:57 --> Language Class Initialized
INFO - 2025-03-19 07:01:57 --> Config Class Initialized
INFO - 2025-03-19 07:01:57 --> Loader Class Initialized
INFO - 2025-03-19 07:01:57 --> Helper loaded: url_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: file_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: html_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: form_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: text_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:01:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:01:57 --> Database Driver Class Initialized
INFO - 2025-03-19 07:01:57 --> Email Class Initialized
INFO - 2025-03-19 07:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:01:57 --> Form Validation Class Initialized
INFO - 2025-03-19 07:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:01:57 --> Pagination Class Initialized
INFO - 2025-03-19 07:01:57 --> Controller Class Initialized
DEBUG - 2025-03-19 07:01:57 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:01:57 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:01:57 --> Model Class Initialized
DEBUG - 2025-03-19 07:01:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:01:57 --> Model Class Initialized
INFO - 2025-03-19 07:01:57 --> Final output sent to browser
DEBUG - 2025-03-19 07:01:57 --> Total execution time: 0.0103
INFO - 2025-03-19 07:03:38 --> Config Class Initialized
INFO - 2025-03-19 07:03:38 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:03:38 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:03:38 --> Utf8 Class Initialized
INFO - 2025-03-19 07:03:38 --> URI Class Initialized
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:03:38 --> Router Class Initialized
INFO - 2025-03-19 07:03:38 --> Output Class Initialized
INFO - 2025-03-19 07:03:38 --> Security Class Initialized
DEBUG - 2025-03-19 07:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:03:38 --> Input Class Initialized
INFO - 2025-03-19 07:03:38 --> Language Class Initialized
INFO - 2025-03-19 07:03:38 --> Language Class Initialized
INFO - 2025-03-19 07:03:38 --> Config Class Initialized
INFO - 2025-03-19 07:03:38 --> Loader Class Initialized
INFO - 2025-03-19 07:03:38 --> Helper loaded: url_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: file_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: html_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: form_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: text_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:03:38 --> Database Driver Class Initialized
INFO - 2025-03-19 07:03:38 --> Email Class Initialized
INFO - 2025-03-19 07:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:03:38 --> Form Validation Class Initialized
INFO - 2025-03-19 07:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:03:38 --> Pagination Class Initialized
INFO - 2025-03-19 07:03:38 --> Controller Class Initialized
DEBUG - 2025-03-19 07:03:38 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:03:38 --> Model Class Initialized
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:03:38 --> Model Class Initialized
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:03:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:03:38 --> Model Class Initialized
ERROR - 2025-03-19 07:03:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:03:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:03:38 --> Final output sent to browser
DEBUG - 2025-03-19 07:03:38 --> Total execution time: 0.1514
INFO - 2025-03-19 07:03:38 --> Config Class Initialized
INFO - 2025-03-19 07:03:38 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:03:38 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:03:38 --> Utf8 Class Initialized
INFO - 2025-03-19 07:03:38 --> URI Class Initialized
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:03:38 --> Router Class Initialized
INFO - 2025-03-19 07:03:38 --> Output Class Initialized
INFO - 2025-03-19 07:03:38 --> Security Class Initialized
DEBUG - 2025-03-19 07:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:03:38 --> Input Class Initialized
INFO - 2025-03-19 07:03:38 --> Language Class Initialized
INFO - 2025-03-19 07:03:38 --> Language Class Initialized
INFO - 2025-03-19 07:03:38 --> Config Class Initialized
INFO - 2025-03-19 07:03:38 --> Loader Class Initialized
INFO - 2025-03-19 07:03:38 --> Helper loaded: url_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: file_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: html_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: form_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: text_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:03:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:03:38 --> Database Driver Class Initialized
INFO - 2025-03-19 07:03:38 --> Email Class Initialized
INFO - 2025-03-19 07:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:03:38 --> Form Validation Class Initialized
INFO - 2025-03-19 07:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:03:38 --> Pagination Class Initialized
INFO - 2025-03-19 07:03:38 --> Controller Class Initialized
DEBUG - 2025-03-19 07:03:38 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:03:38 --> Model Class Initialized
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:03:38 --> Model Class Initialized
DEBUG - 2025-03-19 07:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:03:38 --> Model Class Initialized
INFO - 2025-03-19 07:03:38 --> Final output sent to browser
DEBUG - 2025-03-19 07:03:38 --> Total execution time: 0.0097
INFO - 2025-03-19 07:30:05 --> Config Class Initialized
INFO - 2025-03-19 07:30:05 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:30:05 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:30:05 --> Utf8 Class Initialized
INFO - 2025-03-19 07:30:05 --> URI Class Initialized
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:30:05 --> Router Class Initialized
INFO - 2025-03-19 07:30:05 --> Output Class Initialized
INFO - 2025-03-19 07:30:05 --> Security Class Initialized
DEBUG - 2025-03-19 07:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:30:05 --> Input Class Initialized
INFO - 2025-03-19 07:30:05 --> Language Class Initialized
INFO - 2025-03-19 07:30:05 --> Language Class Initialized
INFO - 2025-03-19 07:30:05 --> Config Class Initialized
INFO - 2025-03-19 07:30:05 --> Loader Class Initialized
INFO - 2025-03-19 07:30:05 --> Helper loaded: url_helper
INFO - 2025-03-19 07:30:05 --> Helper loaded: file_helper
INFO - 2025-03-19 07:30:05 --> Helper loaded: html_helper
INFO - 2025-03-19 07:30:05 --> Helper loaded: form_helper
INFO - 2025-03-19 07:30:05 --> Helper loaded: text_helper
INFO - 2025-03-19 07:30:05 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:30:05 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:30:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:30:05 --> Database Driver Class Initialized
INFO - 2025-03-19 07:30:05 --> Email Class Initialized
INFO - 2025-03-19 07:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:30:05 --> Form Validation Class Initialized
INFO - 2025-03-19 07:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:30:05 --> Pagination Class Initialized
INFO - 2025-03-19 07:30:05 --> Controller Class Initialized
DEBUG - 2025-03-19 07:30:05 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:30:05 --> Model Class Initialized
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:30:05 --> Model Class Initialized
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:30:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:30:05 --> Model Class Initialized
ERROR - 2025-03-19 07:30:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:30:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:30:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:30:05 --> Final output sent to browser
DEBUG - 2025-03-19 07:30:05 --> Total execution time: 0.2691
INFO - 2025-03-19 07:30:06 --> Config Class Initialized
INFO - 2025-03-19 07:30:06 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:30:06 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:30:06 --> Utf8 Class Initialized
INFO - 2025-03-19 07:30:06 --> URI Class Initialized
DEBUG - 2025-03-19 07:30:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:30:06 --> Router Class Initialized
INFO - 2025-03-19 07:30:06 --> Output Class Initialized
INFO - 2025-03-19 07:30:06 --> Security Class Initialized
DEBUG - 2025-03-19 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:30:06 --> Input Class Initialized
INFO - 2025-03-19 07:30:06 --> Language Class Initialized
INFO - 2025-03-19 07:30:06 --> Language Class Initialized
INFO - 2025-03-19 07:30:06 --> Config Class Initialized
INFO - 2025-03-19 07:30:06 --> Loader Class Initialized
INFO - 2025-03-19 07:30:06 --> Helper loaded: url_helper
INFO - 2025-03-19 07:30:06 --> Helper loaded: file_helper
INFO - 2025-03-19 07:30:06 --> Helper loaded: html_helper
INFO - 2025-03-19 07:30:06 --> Helper loaded: form_helper
INFO - 2025-03-19 07:30:06 --> Helper loaded: text_helper
INFO - 2025-03-19 07:30:06 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:30:06 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:30:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:30:06 --> Database Driver Class Initialized
INFO - 2025-03-19 07:30:06 --> Email Class Initialized
INFO - 2025-03-19 07:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:30:06 --> Form Validation Class Initialized
INFO - 2025-03-19 07:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:30:06 --> Pagination Class Initialized
INFO - 2025-03-19 07:30:06 --> Controller Class Initialized
DEBUG - 2025-03-19 07:30:06 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:30:06 --> Model Class Initialized
DEBUG - 2025-03-19 07:30:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:30:06 --> Model Class Initialized
DEBUG - 2025-03-19 07:30:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:30:06 --> Model Class Initialized
INFO - 2025-03-19 07:30:06 --> Final output sent to browser
DEBUG - 2025-03-19 07:30:06 --> Total execution time: 0.0092
INFO - 2025-03-19 07:31:23 --> Config Class Initialized
INFO - 2025-03-19 07:31:23 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:31:23 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:31:23 --> Utf8 Class Initialized
INFO - 2025-03-19 07:31:23 --> URI Class Initialized
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:31:23 --> Router Class Initialized
INFO - 2025-03-19 07:31:23 --> Output Class Initialized
INFO - 2025-03-19 07:31:23 --> Security Class Initialized
DEBUG - 2025-03-19 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:31:23 --> Input Class Initialized
INFO - 2025-03-19 07:31:23 --> Language Class Initialized
INFO - 2025-03-19 07:31:23 --> Language Class Initialized
INFO - 2025-03-19 07:31:23 --> Config Class Initialized
INFO - 2025-03-19 07:31:23 --> Loader Class Initialized
INFO - 2025-03-19 07:31:23 --> Helper loaded: url_helper
INFO - 2025-03-19 07:31:23 --> Helper loaded: file_helper
INFO - 2025-03-19 07:31:23 --> Helper loaded: html_helper
INFO - 2025-03-19 07:31:23 --> Helper loaded: form_helper
INFO - 2025-03-19 07:31:23 --> Helper loaded: text_helper
INFO - 2025-03-19 07:31:23 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:31:23 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:31:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:31:23 --> Database Driver Class Initialized
INFO - 2025-03-19 07:31:23 --> Email Class Initialized
INFO - 2025-03-19 07:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:31:23 --> Form Validation Class Initialized
INFO - 2025-03-19 07:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:31:23 --> Pagination Class Initialized
INFO - 2025-03-19 07:31:23 --> Controller Class Initialized
DEBUG - 2025-03-19 07:31:23 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:31:23 --> Model Class Initialized
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:31:23 --> Model Class Initialized
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:31:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:31:23 --> Model Class Initialized
ERROR - 2025-03-19 07:31:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:31:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:31:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:31:23 --> Final output sent to browser
DEBUG - 2025-03-19 07:31:23 --> Total execution time: 0.1309
INFO - 2025-03-19 07:31:24 --> Config Class Initialized
INFO - 2025-03-19 07:31:24 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:31:24 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:31:24 --> Utf8 Class Initialized
INFO - 2025-03-19 07:31:24 --> URI Class Initialized
DEBUG - 2025-03-19 07:31:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:31:24 --> Router Class Initialized
INFO - 2025-03-19 07:31:24 --> Output Class Initialized
INFO - 2025-03-19 07:31:24 --> Security Class Initialized
DEBUG - 2025-03-19 07:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:31:24 --> Input Class Initialized
INFO - 2025-03-19 07:31:24 --> Language Class Initialized
INFO - 2025-03-19 07:31:24 --> Language Class Initialized
INFO - 2025-03-19 07:31:24 --> Config Class Initialized
INFO - 2025-03-19 07:31:24 --> Loader Class Initialized
INFO - 2025-03-19 07:31:24 --> Helper loaded: url_helper
INFO - 2025-03-19 07:31:24 --> Helper loaded: file_helper
INFO - 2025-03-19 07:31:24 --> Helper loaded: html_helper
INFO - 2025-03-19 07:31:24 --> Helper loaded: form_helper
INFO - 2025-03-19 07:31:24 --> Helper loaded: text_helper
INFO - 2025-03-19 07:31:24 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:31:24 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:31:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:31:24 --> Database Driver Class Initialized
INFO - 2025-03-19 07:31:24 --> Email Class Initialized
INFO - 2025-03-19 07:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:31:24 --> Form Validation Class Initialized
INFO - 2025-03-19 07:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:31:24 --> Pagination Class Initialized
INFO - 2025-03-19 07:31:24 --> Controller Class Initialized
DEBUG - 2025-03-19 07:31:24 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:31:24 --> Model Class Initialized
DEBUG - 2025-03-19 07:31:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:31:24 --> Model Class Initialized
DEBUG - 2025-03-19 07:31:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:31:24 --> Model Class Initialized
INFO - 2025-03-19 07:31:24 --> Final output sent to browser
DEBUG - 2025-03-19 07:31:24 --> Total execution time: 0.0065
INFO - 2025-03-19 07:32:04 --> Config Class Initialized
INFO - 2025-03-19 07:32:04 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:32:04 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:32:04 --> Utf8 Class Initialized
INFO - 2025-03-19 07:32:04 --> URI Class Initialized
DEBUG - 2025-03-19 07:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:32:04 --> Router Class Initialized
INFO - 2025-03-19 07:32:04 --> Output Class Initialized
INFO - 2025-03-19 07:32:04 --> Security Class Initialized
DEBUG - 2025-03-19 07:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:32:04 --> Input Class Initialized
INFO - 2025-03-19 07:32:04 --> Language Class Initialized
INFO - 2025-03-19 07:32:04 --> Language Class Initialized
INFO - 2025-03-19 07:32:04 --> Config Class Initialized
INFO - 2025-03-19 07:32:04 --> Loader Class Initialized
INFO - 2025-03-19 07:32:04 --> Helper loaded: url_helper
INFO - 2025-03-19 07:32:04 --> Helper loaded: file_helper
INFO - 2025-03-19 07:32:04 --> Helper loaded: html_helper
INFO - 2025-03-19 07:32:04 --> Helper loaded: form_helper
INFO - 2025-03-19 07:32:04 --> Helper loaded: text_helper
INFO - 2025-03-19 07:32:04 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:32:04 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:32:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:32:04 --> Database Driver Class Initialized
INFO - 2025-03-19 07:32:04 --> Email Class Initialized
INFO - 2025-03-19 07:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:32:04 --> Form Validation Class Initialized
INFO - 2025-03-19 07:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:32:04 --> Pagination Class Initialized
INFO - 2025-03-19 07:32:04 --> Controller Class Initialized
DEBUG - 2025-03-19 07:32:04 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:32:04 --> Model Class Initialized
DEBUG - 2025-03-19 07:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:32:04 --> Model Class Initialized
DEBUG - 2025-03-19 07:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:32:05 --> Model Class Initialized
INFO - 2025-03-19 07:32:05 --> Final output sent to browser
DEBUG - 2025-03-19 07:32:05 --> Total execution time: 0.0211
INFO - 2025-03-19 07:38:55 --> Config Class Initialized
INFO - 2025-03-19 07:38:55 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:38:55 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:38:55 --> Utf8 Class Initialized
INFO - 2025-03-19 07:38:55 --> URI Class Initialized
DEBUG - 2025-03-19 07:38:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:38:55 --> Router Class Initialized
INFO - 2025-03-19 07:38:55 --> Output Class Initialized
INFO - 2025-03-19 07:38:55 --> Security Class Initialized
DEBUG - 2025-03-19 07:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:38:55 --> Input Class Initialized
INFO - 2025-03-19 07:38:55 --> Language Class Initialized
INFO - 2025-03-19 07:38:55 --> Language Class Initialized
INFO - 2025-03-19 07:38:55 --> Config Class Initialized
INFO - 2025-03-19 07:38:55 --> Loader Class Initialized
INFO - 2025-03-19 07:38:55 --> Helper loaded: url_helper
INFO - 2025-03-19 07:38:55 --> Helper loaded: file_helper
INFO - 2025-03-19 07:38:55 --> Helper loaded: html_helper
INFO - 2025-03-19 07:38:55 --> Helper loaded: form_helper
INFO - 2025-03-19 07:38:55 --> Helper loaded: text_helper
INFO - 2025-03-19 07:38:55 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:38:55 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:38:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:38:55 --> Database Driver Class Initialized
INFO - 2025-03-19 07:38:55 --> Email Class Initialized
INFO - 2025-03-19 07:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:38:55 --> Form Validation Class Initialized
INFO - 2025-03-19 07:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:38:55 --> Pagination Class Initialized
INFO - 2025-03-19 07:38:55 --> Controller Class Initialized
DEBUG - 2025-03-19 07:38:55 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:38:55 --> Model Class Initialized
DEBUG - 2025-03-19 07:38:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:38:55 --> Model Class Initialized
ERROR - 2025-03-19 07:38:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 07:39:07 --> Config Class Initialized
INFO - 2025-03-19 07:39:07 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:39:07 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:39:07 --> Utf8 Class Initialized
INFO - 2025-03-19 07:39:07 --> URI Class Initialized
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:39:07 --> Router Class Initialized
INFO - 2025-03-19 07:39:07 --> Output Class Initialized
INFO - 2025-03-19 07:39:07 --> Security Class Initialized
DEBUG - 2025-03-19 07:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:39:07 --> Input Class Initialized
INFO - 2025-03-19 07:39:07 --> Language Class Initialized
INFO - 2025-03-19 07:39:07 --> Language Class Initialized
INFO - 2025-03-19 07:39:07 --> Config Class Initialized
INFO - 2025-03-19 07:39:07 --> Loader Class Initialized
INFO - 2025-03-19 07:39:07 --> Helper loaded: url_helper
INFO - 2025-03-19 07:39:07 --> Helper loaded: file_helper
INFO - 2025-03-19 07:39:07 --> Helper loaded: html_helper
INFO - 2025-03-19 07:39:07 --> Helper loaded: form_helper
INFO - 2025-03-19 07:39:07 --> Helper loaded: text_helper
INFO - 2025-03-19 07:39:07 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:39:07 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:39:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:39:07 --> Database Driver Class Initialized
INFO - 2025-03-19 07:39:07 --> Email Class Initialized
INFO - 2025-03-19 07:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:39:07 --> Form Validation Class Initialized
INFO - 2025-03-19 07:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:39:07 --> Pagination Class Initialized
INFO - 2025-03-19 07:39:07 --> Controller Class Initialized
DEBUG - 2025-03-19 07:39:07 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:39:07 --> Model Class Initialized
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:39:07 --> Model Class Initialized
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:39:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:39:07 --> Model Class Initialized
ERROR - 2025-03-19 07:39:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:39:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:39:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:39:07 --> Final output sent to browser
DEBUG - 2025-03-19 07:39:07 --> Total execution time: 0.0957
INFO - 2025-03-19 07:39:08 --> Config Class Initialized
INFO - 2025-03-19 07:39:08 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:39:08 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:39:08 --> Utf8 Class Initialized
INFO - 2025-03-19 07:39:08 --> URI Class Initialized
DEBUG - 2025-03-19 07:39:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:39:08 --> Router Class Initialized
INFO - 2025-03-19 07:39:08 --> Output Class Initialized
INFO - 2025-03-19 07:39:08 --> Security Class Initialized
DEBUG - 2025-03-19 07:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:39:08 --> Input Class Initialized
INFO - 2025-03-19 07:39:08 --> Language Class Initialized
INFO - 2025-03-19 07:39:08 --> Language Class Initialized
INFO - 2025-03-19 07:39:08 --> Config Class Initialized
INFO - 2025-03-19 07:39:08 --> Loader Class Initialized
INFO - 2025-03-19 07:39:08 --> Helper loaded: url_helper
INFO - 2025-03-19 07:39:08 --> Helper loaded: file_helper
INFO - 2025-03-19 07:39:08 --> Helper loaded: html_helper
INFO - 2025-03-19 07:39:08 --> Helper loaded: form_helper
INFO - 2025-03-19 07:39:08 --> Helper loaded: text_helper
INFO - 2025-03-19 07:39:08 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:39:08 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:39:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:39:08 --> Database Driver Class Initialized
INFO - 2025-03-19 07:39:08 --> Email Class Initialized
INFO - 2025-03-19 07:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:39:08 --> Form Validation Class Initialized
INFO - 2025-03-19 07:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:39:08 --> Pagination Class Initialized
INFO - 2025-03-19 07:39:08 --> Controller Class Initialized
DEBUG - 2025-03-19 07:39:08 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:39:08 --> Model Class Initialized
DEBUG - 2025-03-19 07:39:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:39:08 --> Model Class Initialized
ERROR - 2025-03-19 07:39:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 07:42:42 --> Config Class Initialized
INFO - 2025-03-19 07:42:42 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:42:42 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:42:42 --> Utf8 Class Initialized
INFO - 2025-03-19 07:42:42 --> URI Class Initialized
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:42:42 --> Router Class Initialized
INFO - 2025-03-19 07:42:42 --> Output Class Initialized
INFO - 2025-03-19 07:42:42 --> Security Class Initialized
DEBUG - 2025-03-19 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:42:42 --> Input Class Initialized
INFO - 2025-03-19 07:42:42 --> Language Class Initialized
INFO - 2025-03-19 07:42:42 --> Language Class Initialized
INFO - 2025-03-19 07:42:42 --> Config Class Initialized
INFO - 2025-03-19 07:42:42 --> Loader Class Initialized
INFO - 2025-03-19 07:42:42 --> Helper loaded: url_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: file_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: html_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: form_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: text_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:42:42 --> Database Driver Class Initialized
INFO - 2025-03-19 07:42:42 --> Email Class Initialized
INFO - 2025-03-19 07:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:42:42 --> Form Validation Class Initialized
INFO - 2025-03-19 07:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:42:42 --> Pagination Class Initialized
INFO - 2025-03-19 07:42:42 --> Controller Class Initialized
DEBUG - 2025-03-19 07:42:42 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:42:42 --> Model Class Initialized
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:42:42 --> Model Class Initialized
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:42:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:42:42 --> Model Class Initialized
ERROR - 2025-03-19 07:42:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:42:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:42:42 --> Final output sent to browser
DEBUG - 2025-03-19 07:42:42 --> Total execution time: 0.1024
INFO - 2025-03-19 07:42:42 --> Config Class Initialized
INFO - 2025-03-19 07:42:42 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:42:42 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:42:42 --> Utf8 Class Initialized
INFO - 2025-03-19 07:42:42 --> URI Class Initialized
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:42:42 --> Router Class Initialized
INFO - 2025-03-19 07:42:42 --> Output Class Initialized
INFO - 2025-03-19 07:42:42 --> Security Class Initialized
DEBUG - 2025-03-19 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:42:42 --> Input Class Initialized
INFO - 2025-03-19 07:42:42 --> Language Class Initialized
INFO - 2025-03-19 07:42:42 --> Language Class Initialized
INFO - 2025-03-19 07:42:42 --> Config Class Initialized
INFO - 2025-03-19 07:42:42 --> Loader Class Initialized
INFO - 2025-03-19 07:42:42 --> Helper loaded: url_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: file_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: html_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: form_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: text_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:42:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:42:42 --> Database Driver Class Initialized
INFO - 2025-03-19 07:42:42 --> Email Class Initialized
INFO - 2025-03-19 07:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:42:42 --> Form Validation Class Initialized
INFO - 2025-03-19 07:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:42:42 --> Pagination Class Initialized
INFO - 2025-03-19 07:42:42 --> Controller Class Initialized
DEBUG - 2025-03-19 07:42:42 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:42:42 --> Model Class Initialized
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:42:42 --> Model Class Initialized
DEBUG - 2025-03-19 07:42:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:42:42 --> Model Class Initialized
INFO - 2025-03-19 07:42:42 --> Final output sent to browser
DEBUG - 2025-03-19 07:42:42 --> Total execution time: 0.0143
INFO - 2025-03-19 07:42:50 --> Config Class Initialized
INFO - 2025-03-19 07:42:50 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:42:50 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:42:50 --> Utf8 Class Initialized
INFO - 2025-03-19 07:42:50 --> URI Class Initialized
DEBUG - 2025-03-19 07:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:42:50 --> Router Class Initialized
INFO - 2025-03-19 07:42:50 --> Output Class Initialized
INFO - 2025-03-19 07:42:50 --> Security Class Initialized
DEBUG - 2025-03-19 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:42:50 --> Input Class Initialized
INFO - 2025-03-19 07:42:50 --> Language Class Initialized
INFO - 2025-03-19 07:42:50 --> Language Class Initialized
INFO - 2025-03-19 07:42:50 --> Config Class Initialized
INFO - 2025-03-19 07:42:50 --> Loader Class Initialized
INFO - 2025-03-19 07:42:50 --> Helper loaded: url_helper
INFO - 2025-03-19 07:42:50 --> Helper loaded: file_helper
INFO - 2025-03-19 07:42:50 --> Helper loaded: html_helper
INFO - 2025-03-19 07:42:50 --> Helper loaded: form_helper
INFO - 2025-03-19 07:42:50 --> Helper loaded: text_helper
INFO - 2025-03-19 07:42:50 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:42:50 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:42:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:42:50 --> Database Driver Class Initialized
INFO - 2025-03-19 07:42:50 --> Email Class Initialized
INFO - 2025-03-19 07:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:42:50 --> Form Validation Class Initialized
INFO - 2025-03-19 07:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:42:50 --> Pagination Class Initialized
INFO - 2025-03-19 07:42:50 --> Controller Class Initialized
DEBUG - 2025-03-19 07:42:50 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:42:50 --> Model Class Initialized
DEBUG - 2025-03-19 07:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:42:50 --> Model Class Initialized
DEBUG - 2025-03-19 07:42:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:42:50 --> Model Class Initialized
INFO - 2025-03-19 07:42:50 --> Final output sent to browser
DEBUG - 2025-03-19 07:42:50 --> Total execution time: 0.0075
INFO - 2025-03-19 07:49:26 --> Config Class Initialized
INFO - 2025-03-19 07:49:26 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:49:26 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:49:26 --> Utf8 Class Initialized
INFO - 2025-03-19 07:49:26 --> URI Class Initialized
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:49:26 --> Router Class Initialized
INFO - 2025-03-19 07:49:26 --> Output Class Initialized
INFO - 2025-03-19 07:49:26 --> Security Class Initialized
DEBUG - 2025-03-19 07:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:49:26 --> Input Class Initialized
INFO - 2025-03-19 07:49:26 --> Language Class Initialized
INFO - 2025-03-19 07:49:26 --> Language Class Initialized
INFO - 2025-03-19 07:49:26 --> Config Class Initialized
INFO - 2025-03-19 07:49:26 --> Loader Class Initialized
INFO - 2025-03-19 07:49:26 --> Helper loaded: url_helper
INFO - 2025-03-19 07:49:26 --> Helper loaded: file_helper
INFO - 2025-03-19 07:49:26 --> Helper loaded: html_helper
INFO - 2025-03-19 07:49:26 --> Helper loaded: form_helper
INFO - 2025-03-19 07:49:26 --> Helper loaded: text_helper
INFO - 2025-03-19 07:49:26 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:49:26 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:49:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:49:26 --> Database Driver Class Initialized
INFO - 2025-03-19 07:49:26 --> Email Class Initialized
INFO - 2025-03-19 07:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:49:26 --> Form Validation Class Initialized
INFO - 2025-03-19 07:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:49:26 --> Pagination Class Initialized
INFO - 2025-03-19 07:49:26 --> Controller Class Initialized
DEBUG - 2025-03-19 07:49:26 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:49:26 --> Model Class Initialized
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:49:26 --> Model Class Initialized
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 07:49:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 07:49:26 --> Model Class Initialized
ERROR - 2025-03-19 07:49:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 07:49:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 07:49:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 07:49:26 --> Final output sent to browser
DEBUG - 2025-03-19 07:49:26 --> Total execution time: 0.1267
INFO - 2025-03-19 07:49:27 --> Config Class Initialized
INFO - 2025-03-19 07:49:27 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:49:27 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:49:27 --> Utf8 Class Initialized
INFO - 2025-03-19 07:49:27 --> URI Class Initialized
DEBUG - 2025-03-19 07:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:49:27 --> Router Class Initialized
INFO - 2025-03-19 07:49:27 --> Output Class Initialized
INFO - 2025-03-19 07:49:27 --> Security Class Initialized
DEBUG - 2025-03-19 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:49:27 --> Input Class Initialized
INFO - 2025-03-19 07:49:27 --> Language Class Initialized
INFO - 2025-03-19 07:49:27 --> Language Class Initialized
INFO - 2025-03-19 07:49:27 --> Config Class Initialized
INFO - 2025-03-19 07:49:27 --> Loader Class Initialized
INFO - 2025-03-19 07:49:27 --> Helper loaded: url_helper
INFO - 2025-03-19 07:49:27 --> Helper loaded: file_helper
INFO - 2025-03-19 07:49:27 --> Helper loaded: html_helper
INFO - 2025-03-19 07:49:27 --> Helper loaded: form_helper
INFO - 2025-03-19 07:49:27 --> Helper loaded: text_helper
INFO - 2025-03-19 07:49:27 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:49:27 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:49:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:49:27 --> Database Driver Class Initialized
INFO - 2025-03-19 07:49:27 --> Email Class Initialized
INFO - 2025-03-19 07:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:49:27 --> Form Validation Class Initialized
INFO - 2025-03-19 07:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:49:27 --> Pagination Class Initialized
INFO - 2025-03-19 07:49:27 --> Controller Class Initialized
DEBUG - 2025-03-19 07:49:27 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:49:27 --> Model Class Initialized
DEBUG - 2025-03-19 07:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:49:27 --> Model Class Initialized
DEBUG - 2025-03-19 07:49:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:49:27 --> Model Class Initialized
INFO - 2025-03-19 07:49:27 --> Final output sent to browser
DEBUG - 2025-03-19 07:49:27 --> Total execution time: 0.0092
INFO - 2025-03-19 07:49:34 --> Config Class Initialized
INFO - 2025-03-19 07:49:34 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:49:34 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:49:34 --> Utf8 Class Initialized
INFO - 2025-03-19 07:49:34 --> URI Class Initialized
DEBUG - 2025-03-19 07:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:49:34 --> Router Class Initialized
INFO - 2025-03-19 07:49:34 --> Output Class Initialized
INFO - 2025-03-19 07:49:34 --> Security Class Initialized
DEBUG - 2025-03-19 07:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:49:34 --> Input Class Initialized
INFO - 2025-03-19 07:49:34 --> Language Class Initialized
INFO - 2025-03-19 07:49:34 --> Language Class Initialized
INFO - 2025-03-19 07:49:34 --> Config Class Initialized
INFO - 2025-03-19 07:49:34 --> Loader Class Initialized
INFO - 2025-03-19 07:49:34 --> Helper loaded: url_helper
INFO - 2025-03-19 07:49:34 --> Helper loaded: file_helper
INFO - 2025-03-19 07:49:34 --> Helper loaded: html_helper
INFO - 2025-03-19 07:49:34 --> Helper loaded: form_helper
INFO - 2025-03-19 07:49:34 --> Helper loaded: text_helper
INFO - 2025-03-19 07:49:34 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:49:34 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:49:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:49:34 --> Database Driver Class Initialized
INFO - 2025-03-19 07:49:34 --> Email Class Initialized
INFO - 2025-03-19 07:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:49:34 --> Form Validation Class Initialized
INFO - 2025-03-19 07:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:49:34 --> Pagination Class Initialized
INFO - 2025-03-19 07:49:34 --> Controller Class Initialized
DEBUG - 2025-03-19 07:49:34 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:49:34 --> Model Class Initialized
DEBUG - 2025-03-19 07:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:49:34 --> Model Class Initialized
DEBUG - 2025-03-19 07:49:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:49:34 --> Model Class Initialized
INFO - 2025-03-19 07:49:34 --> Final output sent to browser
DEBUG - 2025-03-19 07:49:34 --> Total execution time: 0.0105
INFO - 2025-03-19 07:51:36 --> Config Class Initialized
INFO - 2025-03-19 07:51:36 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:51:36 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:51:36 --> Utf8 Class Initialized
INFO - 2025-03-19 07:51:36 --> URI Class Initialized
DEBUG - 2025-03-19 07:51:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:51:36 --> Router Class Initialized
INFO - 2025-03-19 07:51:36 --> Output Class Initialized
INFO - 2025-03-19 07:51:36 --> Security Class Initialized
DEBUG - 2025-03-19 07:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:51:36 --> Input Class Initialized
INFO - 2025-03-19 07:51:36 --> Language Class Initialized
INFO - 2025-03-19 07:51:36 --> Language Class Initialized
INFO - 2025-03-19 07:51:36 --> Config Class Initialized
INFO - 2025-03-19 07:51:36 --> Loader Class Initialized
INFO - 2025-03-19 07:51:36 --> Helper loaded: url_helper
INFO - 2025-03-19 07:51:36 --> Helper loaded: file_helper
INFO - 2025-03-19 07:51:36 --> Helper loaded: html_helper
INFO - 2025-03-19 07:51:36 --> Helper loaded: form_helper
INFO - 2025-03-19 07:51:36 --> Helper loaded: text_helper
INFO - 2025-03-19 07:51:36 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:51:36 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:51:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:51:36 --> Database Driver Class Initialized
INFO - 2025-03-19 07:51:36 --> Email Class Initialized
INFO - 2025-03-19 07:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:51:36 --> Form Validation Class Initialized
INFO - 2025-03-19 07:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:51:36 --> Pagination Class Initialized
INFO - 2025-03-19 07:51:36 --> Controller Class Initialized
DEBUG - 2025-03-19 07:51:36 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:51:36 --> Model Class Initialized
DEBUG - 2025-03-19 07:51:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:51:36 --> Model Class Initialized
INFO - 2025-03-19 07:52:09 --> Config Class Initialized
INFO - 2025-03-19 07:52:09 --> Hooks Class Initialized
DEBUG - 2025-03-19 07:52:09 --> UTF-8 Support Enabled
INFO - 2025-03-19 07:52:09 --> Utf8 Class Initialized
INFO - 2025-03-19 07:52:09 --> URI Class Initialized
DEBUG - 2025-03-19 07:52:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 07:52:09 --> Router Class Initialized
INFO - 2025-03-19 07:52:09 --> Output Class Initialized
INFO - 2025-03-19 07:52:09 --> Security Class Initialized
DEBUG - 2025-03-19 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 07:52:09 --> Input Class Initialized
INFO - 2025-03-19 07:52:09 --> Language Class Initialized
INFO - 2025-03-19 07:52:09 --> Language Class Initialized
INFO - 2025-03-19 07:52:09 --> Config Class Initialized
INFO - 2025-03-19 07:52:09 --> Loader Class Initialized
INFO - 2025-03-19 07:52:09 --> Helper loaded: url_helper
INFO - 2025-03-19 07:52:09 --> Helper loaded: file_helper
INFO - 2025-03-19 07:52:09 --> Helper loaded: html_helper
INFO - 2025-03-19 07:52:09 --> Helper loaded: form_helper
INFO - 2025-03-19 07:52:09 --> Helper loaded: text_helper
INFO - 2025-03-19 07:52:09 --> Helper loaded: lang_helper
INFO - 2025-03-19 07:52:09 --> Helper loaded: directory_helper
INFO - 2025-03-19 07:52:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 07:52:09 --> Database Driver Class Initialized
INFO - 2025-03-19 07:52:09 --> Email Class Initialized
INFO - 2025-03-19 07:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 07:52:09 --> Form Validation Class Initialized
INFO - 2025-03-19 07:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 07:52:09 --> Pagination Class Initialized
INFO - 2025-03-19 07:52:09 --> Controller Class Initialized
DEBUG - 2025-03-19 07:52:09 --> Report MX_Controller Initialized
INFO - 2025-03-19 07:52:09 --> Model Class Initialized
DEBUG - 2025-03-19 07:52:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 07:52:09 --> Model Class Initialized
DEBUG - 2025-03-19 07:52:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 07:52:09 --> Model Class Initialized
INFO - 2025-03-19 07:52:09 --> Final output sent to browser
DEBUG - 2025-03-19 07:52:09 --> Total execution time: 0.0178
INFO - 2025-03-19 08:00:22 --> Config Class Initialized
INFO - 2025-03-19 08:00:22 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:22 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:22 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:22 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:22 --> Router Class Initialized
INFO - 2025-03-19 08:00:22 --> Output Class Initialized
INFO - 2025-03-19 08:00:22 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:22 --> Input Class Initialized
INFO - 2025-03-19 08:00:22 --> Language Class Initialized
INFO - 2025-03-19 08:00:22 --> Language Class Initialized
INFO - 2025-03-19 08:00:22 --> Config Class Initialized
INFO - 2025-03-19 08:00:22 --> Loader Class Initialized
INFO - 2025-03-19 08:00:22 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:22 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:22 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:22 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:22 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:22 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:22 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:22 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:22 --> Email Class Initialized
INFO - 2025-03-19 08:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:22 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:22 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:22 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:22 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:22 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:22 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:22 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:22 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 14:00:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 14:00:22 --> Model Class Initialized
ERROR - 2025-03-19 14:00:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 14:00:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 14:00:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 14:00:22 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:22 --> Total execution time: 0.3366
INFO - 2025-03-19 08:00:23 --> Config Class Initialized
INFO - 2025-03-19 08:00:23 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:23 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:23 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:23 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:23 --> Router Class Initialized
INFO - 2025-03-19 08:00:23 --> Output Class Initialized
INFO - 2025-03-19 08:00:23 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:23 --> Input Class Initialized
INFO - 2025-03-19 08:00:23 --> Language Class Initialized
INFO - 2025-03-19 08:00:23 --> Language Class Initialized
INFO - 2025-03-19 08:00:23 --> Config Class Initialized
INFO - 2025-03-19 08:00:23 --> Loader Class Initialized
INFO - 2025-03-19 08:00:23 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:23 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:23 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:23 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:23 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:23 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:23 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:23 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:23 --> Email Class Initialized
INFO - 2025-03-19 08:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:23 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:23 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:23 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:23 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:23 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:23 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:23 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:23 --> Model Class Initialized
INFO - 2025-03-19 14:00:23 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:23 --> Total execution time: 0.0374
INFO - 2025-03-19 08:00:31 --> Config Class Initialized
INFO - 2025-03-19 08:00:31 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:31 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:31 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:31 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:31 --> Router Class Initialized
INFO - 2025-03-19 08:00:31 --> Output Class Initialized
INFO - 2025-03-19 08:00:31 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:31 --> Input Class Initialized
INFO - 2025-03-19 08:00:31 --> Language Class Initialized
INFO - 2025-03-19 08:00:31 --> Language Class Initialized
INFO - 2025-03-19 08:00:31 --> Config Class Initialized
INFO - 2025-03-19 08:00:31 --> Loader Class Initialized
INFO - 2025-03-19 08:00:31 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:31 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:31 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:31 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:31 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:31 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:31 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:31 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:31 --> Email Class Initialized
INFO - 2025-03-19 08:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:31 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:31 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:31 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:31 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:31 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:31 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:31 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:31 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 14:00:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 14:00:31 --> Model Class Initialized
ERROR - 2025-03-19 14:00:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 14:00:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 14:00:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 14:00:31 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:31 --> Total execution time: 0.1846
INFO - 2025-03-19 08:00:36 --> Config Class Initialized
INFO - 2025-03-19 08:00:36 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:36 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:36 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:36 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:36 --> Router Class Initialized
INFO - 2025-03-19 08:00:36 --> Output Class Initialized
INFO - 2025-03-19 08:00:36 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:36 --> Input Class Initialized
INFO - 2025-03-19 08:00:36 --> Language Class Initialized
INFO - 2025-03-19 08:00:36 --> Language Class Initialized
INFO - 2025-03-19 08:00:36 --> Config Class Initialized
INFO - 2025-03-19 08:00:36 --> Loader Class Initialized
INFO - 2025-03-19 08:00:36 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:36 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:36 --> Email Class Initialized
INFO - 2025-03-19 08:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:36 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:36 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:36 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:36 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 14:00:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
ERROR - 2025-03-19 14:00:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 14:00:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 14:00:36 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:36 --> Total execution time: 0.1301
INFO - 2025-03-19 08:00:36 --> Config Class Initialized
INFO - 2025-03-19 08:00:36 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:36 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:36 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:36 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:36 --> Router Class Initialized
INFO - 2025-03-19 08:00:36 --> Output Class Initialized
INFO - 2025-03-19 08:00:36 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:36 --> Input Class Initialized
INFO - 2025-03-19 08:00:36 --> Language Class Initialized
INFO - 2025-03-19 08:00:36 --> Language Class Initialized
INFO - 2025-03-19 08:00:36 --> Config Class Initialized
INFO - 2025-03-19 08:00:36 --> Loader Class Initialized
INFO - 2025-03-19 08:00:36 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:36 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:36 --> Email Class Initialized
INFO - 2025-03-19 08:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:36 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:36 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:36 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:36 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:36 --> Model Class Initialized
INFO - 2025-03-19 14:00:37 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:37 --> Total execution time: 0.0607
INFO - 2025-03-19 08:00:41 --> Config Class Initialized
INFO - 2025-03-19 08:00:41 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:41 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:41 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:41 --> Router Class Initialized
INFO - 2025-03-19 08:00:41 --> Output Class Initialized
INFO - 2025-03-19 08:00:41 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:41 --> Input Class Initialized
INFO - 2025-03-19 08:00:41 --> Language Class Initialized
INFO - 2025-03-19 08:00:41 --> Language Class Initialized
INFO - 2025-03-19 08:00:41 --> Config Class Initialized
INFO - 2025-03-19 08:00:41 --> Loader Class Initialized
INFO - 2025-03-19 08:00:41 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:41 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:41 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:41 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:41 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:41 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:41 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:41 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:41 --> Email Class Initialized
INFO - 2025-03-19 08:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:41 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:41 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:41 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:41 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:41 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:41 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:41 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:41 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 14:00:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 14:00:41 --> Model Class Initialized
ERROR - 2025-03-19 14:00:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 14:00:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 14:00:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 14:00:41 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:41 --> Total execution time: 0.1899
INFO - 2025-03-19 08:00:53 --> Config Class Initialized
INFO - 2025-03-19 08:00:53 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:53 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:53 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:53 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:53 --> Router Class Initialized
INFO - 2025-03-19 08:00:53 --> Output Class Initialized
INFO - 2025-03-19 08:00:53 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:53 --> Input Class Initialized
INFO - 2025-03-19 08:00:53 --> Language Class Initialized
INFO - 2025-03-19 08:00:53 --> Language Class Initialized
INFO - 2025-03-19 08:00:53 --> Config Class Initialized
INFO - 2025-03-19 08:00:53 --> Loader Class Initialized
INFO - 2025-03-19 08:00:53 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:53 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:53 --> Email Class Initialized
INFO - 2025-03-19 08:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:53 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:53 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:53 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:53 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 14:00:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
ERROR - 2025-03-19 14:00:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 14:00:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 14:00:53 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:53 --> Total execution time: 0.1311
INFO - 2025-03-19 08:00:53 --> Config Class Initialized
INFO - 2025-03-19 08:00:53 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:00:53 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:00:53 --> Utf8 Class Initialized
INFO - 2025-03-19 08:00:53 --> URI Class Initialized
DEBUG - 2025-03-19 08:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-19 08:00:53 --> Router Class Initialized
INFO - 2025-03-19 08:00:53 --> Output Class Initialized
INFO - 2025-03-19 08:00:53 --> Security Class Initialized
DEBUG - 2025-03-19 08:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:00:53 --> Input Class Initialized
INFO - 2025-03-19 08:00:53 --> Language Class Initialized
INFO - 2025-03-19 08:00:53 --> Language Class Initialized
INFO - 2025-03-19 08:00:53 --> Config Class Initialized
INFO - 2025-03-19 08:00:53 --> Loader Class Initialized
INFO - 2025-03-19 08:00:53 --> Helper loaded: url_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: file_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: html_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: form_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: text_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:00:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:00:53 --> Database Driver Class Initialized
INFO - 2025-03-19 08:00:53 --> Email Class Initialized
INFO - 2025-03-19 08:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:00:53 --> Form Validation Class Initialized
INFO - 2025-03-19 08:00:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:00:53 --> Pagination Class Initialized
INFO - 2025-03-19 08:00:53 --> Controller Class Initialized
DEBUG - 2025-03-19 08:00:53 --> Invoice MX_Controller Initialized
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
DEBUG - 2025-03-19 14:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 14:00:53 --> Model Class Initialized
INFO - 2025-03-19 14:00:53 --> Final output sent to browser
DEBUG - 2025-03-19 14:00:53 --> Total execution time: 0.0539
INFO - 2025-03-19 08:01:14 --> Config Class Initialized
INFO - 2025-03-19 08:01:14 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:01:14 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:01:14 --> Utf8 Class Initialized
INFO - 2025-03-19 08:01:14 --> URI Class Initialized
DEBUG - 2025-03-19 08:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:01:14 --> Router Class Initialized
INFO - 2025-03-19 08:01:14 --> Output Class Initialized
INFO - 2025-03-19 08:01:14 --> Security Class Initialized
DEBUG - 2025-03-19 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:01:14 --> Input Class Initialized
INFO - 2025-03-19 08:01:14 --> Language Class Initialized
INFO - 2025-03-19 08:01:14 --> Language Class Initialized
INFO - 2025-03-19 08:01:14 --> Config Class Initialized
INFO - 2025-03-19 08:01:14 --> Loader Class Initialized
INFO - 2025-03-19 08:01:14 --> Helper loaded: url_helper
INFO - 2025-03-19 08:01:14 --> Helper loaded: file_helper
INFO - 2025-03-19 08:01:14 --> Helper loaded: html_helper
INFO - 2025-03-19 08:01:14 --> Helper loaded: form_helper
INFO - 2025-03-19 08:01:14 --> Helper loaded: text_helper
INFO - 2025-03-19 08:01:14 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:01:14 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:01:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:01:14 --> Database Driver Class Initialized
INFO - 2025-03-19 08:01:14 --> Email Class Initialized
INFO - 2025-03-19 08:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:01:14 --> Form Validation Class Initialized
INFO - 2025-03-19 08:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:01:14 --> Pagination Class Initialized
INFO - 2025-03-19 08:01:14 --> Controller Class Initialized
DEBUG - 2025-03-19 08:01:14 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:01:14 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:01:14 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:01:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:01:14 --> Model Class Initialized
ERROR - 2025-03-19 08:01:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:01:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:01:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/todays_customer_receipt.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:01:19 --> Final output sent to browser
DEBUG - 2025-03-19 08:01:19 --> Total execution time: 4.4736
INFO - 2025-03-19 08:01:19 --> Config Class Initialized
INFO - 2025-03-19 08:01:19 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:01:19 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:01:19 --> Utf8 Class Initialized
INFO - 2025-03-19 08:01:19 --> URI Class Initialized
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:01:19 --> Router Class Initialized
INFO - 2025-03-19 08:01:19 --> Output Class Initialized
INFO - 2025-03-19 08:01:19 --> Security Class Initialized
DEBUG - 2025-03-19 08:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:01:19 --> Input Class Initialized
INFO - 2025-03-19 08:01:19 --> Language Class Initialized
INFO - 2025-03-19 08:01:19 --> Language Class Initialized
INFO - 2025-03-19 08:01:19 --> Config Class Initialized
INFO - 2025-03-19 08:01:19 --> Loader Class Initialized
INFO - 2025-03-19 08:01:19 --> Helper loaded: url_helper
INFO - 2025-03-19 08:01:19 --> Helper loaded: file_helper
INFO - 2025-03-19 08:01:19 --> Helper loaded: html_helper
INFO - 2025-03-19 08:01:19 --> Helper loaded: form_helper
INFO - 2025-03-19 08:01:19 --> Helper loaded: text_helper
INFO - 2025-03-19 08:01:19 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:01:19 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:01:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:01:19 --> Database Driver Class Initialized
INFO - 2025-03-19 08:01:19 --> Email Class Initialized
INFO - 2025-03-19 08:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:01:19 --> Form Validation Class Initialized
INFO - 2025-03-19 08:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:01:19 --> Pagination Class Initialized
INFO - 2025-03-19 08:01:19 --> Controller Class Initialized
DEBUG - 2025-03-19 08:01:19 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:01:19 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:01:19 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:01:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:01:19 --> Model Class Initialized
ERROR - 2025-03-19 08:01:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:01:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/todays_customer_receipt.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:01:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:01:19 --> Final output sent to browser
DEBUG - 2025-03-19 08:01:19 --> Total execution time: 0.5322
INFO - 2025-03-19 08:01:31 --> Config Class Initialized
INFO - 2025-03-19 08:01:31 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:01:31 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:01:31 --> Utf8 Class Initialized
INFO - 2025-03-19 08:01:31 --> URI Class Initialized
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:01:31 --> Router Class Initialized
INFO - 2025-03-19 08:01:31 --> Output Class Initialized
INFO - 2025-03-19 08:01:31 --> Security Class Initialized
DEBUG - 2025-03-19 08:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:01:31 --> Input Class Initialized
INFO - 2025-03-19 08:01:31 --> Language Class Initialized
INFO - 2025-03-19 08:01:31 --> Language Class Initialized
INFO - 2025-03-19 08:01:31 --> Config Class Initialized
INFO - 2025-03-19 08:01:31 --> Loader Class Initialized
INFO - 2025-03-19 08:01:31 --> Helper loaded: url_helper
INFO - 2025-03-19 08:01:31 --> Helper loaded: file_helper
INFO - 2025-03-19 08:01:31 --> Helper loaded: html_helper
INFO - 2025-03-19 08:01:31 --> Helper loaded: form_helper
INFO - 2025-03-19 08:01:31 --> Helper loaded: text_helper
INFO - 2025-03-19 08:01:31 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:01:31 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:01:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:01:31 --> Database Driver Class Initialized
INFO - 2025-03-19 08:01:31 --> Email Class Initialized
INFO - 2025-03-19 08:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:01:31 --> Form Validation Class Initialized
INFO - 2025-03-19 08:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:01:31 --> Pagination Class Initialized
INFO - 2025-03-19 08:01:31 --> Controller Class Initialized
DEBUG - 2025-03-19 08:01:31 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:01:31 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:01:31 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:01:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:01:31 --> Model Class Initialized
ERROR - 2025-03-19 08:01:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:01:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/todays_customer_receipt.php
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:01:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:01:31 --> Final output sent to browser
DEBUG - 2025-03-19 08:01:31 --> Total execution time: 0.1293
INFO - 2025-03-19 08:01:35 --> Config Class Initialized
INFO - 2025-03-19 08:01:35 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:01:35 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:01:35 --> Utf8 Class Initialized
INFO - 2025-03-19 08:01:35 --> URI Class Initialized
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:01:35 --> Router Class Initialized
INFO - 2025-03-19 08:01:35 --> Output Class Initialized
INFO - 2025-03-19 08:01:35 --> Security Class Initialized
DEBUG - 2025-03-19 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:01:35 --> Input Class Initialized
INFO - 2025-03-19 08:01:35 --> Language Class Initialized
INFO - 2025-03-19 08:01:35 --> Language Class Initialized
INFO - 2025-03-19 08:01:35 --> Config Class Initialized
INFO - 2025-03-19 08:01:35 --> Loader Class Initialized
INFO - 2025-03-19 08:01:35 --> Helper loaded: url_helper
INFO - 2025-03-19 08:01:35 --> Helper loaded: file_helper
INFO - 2025-03-19 08:01:35 --> Helper loaded: html_helper
INFO - 2025-03-19 08:01:35 --> Helper loaded: form_helper
INFO - 2025-03-19 08:01:35 --> Helper loaded: text_helper
INFO - 2025-03-19 08:01:35 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:01:35 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:01:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:01:35 --> Database Driver Class Initialized
INFO - 2025-03-19 08:01:35 --> Email Class Initialized
INFO - 2025-03-19 08:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:01:35 --> Form Validation Class Initialized
INFO - 2025-03-19 08:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:01:35 --> Pagination Class Initialized
INFO - 2025-03-19 08:01:35 --> Controller Class Initialized
DEBUG - 2025-03-19 08:01:35 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:01:35 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:01:35 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:01:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:01:35 --> Model Class Initialized
ERROR - 2025-03-19 08:01:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:01:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/todays_customer_receipt.php
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:01:35 --> Final output sent to browser
DEBUG - 2025-03-19 08:01:35 --> Total execution time: 0.1097
INFO - 2025-03-19 08:01:40 --> Config Class Initialized
INFO - 2025-03-19 08:01:40 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:01:40 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:01:40 --> Utf8 Class Initialized
INFO - 2025-03-19 08:01:40 --> URI Class Initialized
DEBUG - 2025-03-19 08:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:01:40 --> Router Class Initialized
INFO - 2025-03-19 08:01:40 --> Output Class Initialized
INFO - 2025-03-19 08:01:40 --> Security Class Initialized
DEBUG - 2025-03-19 08:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:01:40 --> Input Class Initialized
INFO - 2025-03-19 08:01:40 --> Language Class Initialized
INFO - 2025-03-19 08:01:40 --> Language Class Initialized
INFO - 2025-03-19 08:01:40 --> Config Class Initialized
INFO - 2025-03-19 08:01:40 --> Loader Class Initialized
INFO - 2025-03-19 08:01:40 --> Helper loaded: url_helper
INFO - 2025-03-19 08:01:40 --> Helper loaded: file_helper
INFO - 2025-03-19 08:01:40 --> Helper loaded: html_helper
INFO - 2025-03-19 08:01:40 --> Helper loaded: form_helper
INFO - 2025-03-19 08:01:40 --> Helper loaded: text_helper
INFO - 2025-03-19 08:01:40 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:01:40 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:01:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:01:40 --> Database Driver Class Initialized
INFO - 2025-03-19 08:01:40 --> Email Class Initialized
INFO - 2025-03-19 08:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:01:40 --> Form Validation Class Initialized
INFO - 2025-03-19 08:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:01:40 --> Pagination Class Initialized
INFO - 2025-03-19 08:01:40 --> Controller Class Initialized
DEBUG - 2025-03-19 08:01:40 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:01:40 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:01:40 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:01:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:01:41 --> Model Class Initialized
ERROR - 2025-03-19 08:01:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:01:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:01:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/todays_customer_receipt.php
DEBUG - 2025-03-19 08:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:01:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:01:42 --> Final output sent to browser
DEBUG - 2025-03-19 08:01:42 --> Total execution time: 1.6169
INFO - 2025-03-19 08:01:56 --> Config Class Initialized
INFO - 2025-03-19 08:01:56 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:01:56 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:01:56 --> Utf8 Class Initialized
INFO - 2025-03-19 08:01:56 --> URI Class Initialized
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:01:56 --> Router Class Initialized
INFO - 2025-03-19 08:01:56 --> Output Class Initialized
INFO - 2025-03-19 08:01:56 --> Security Class Initialized
DEBUG - 2025-03-19 08:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:01:56 --> Input Class Initialized
INFO - 2025-03-19 08:01:56 --> Language Class Initialized
INFO - 2025-03-19 08:01:56 --> Language Class Initialized
INFO - 2025-03-19 08:01:56 --> Config Class Initialized
INFO - 2025-03-19 08:01:56 --> Loader Class Initialized
INFO - 2025-03-19 08:01:56 --> Helper loaded: url_helper
INFO - 2025-03-19 08:01:56 --> Helper loaded: file_helper
INFO - 2025-03-19 08:01:56 --> Helper loaded: html_helper
INFO - 2025-03-19 08:01:56 --> Helper loaded: form_helper
INFO - 2025-03-19 08:01:56 --> Helper loaded: text_helper
INFO - 2025-03-19 08:01:56 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:01:56 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:01:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:01:56 --> Database Driver Class Initialized
INFO - 2025-03-19 08:01:56 --> Email Class Initialized
INFO - 2025-03-19 08:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:01:56 --> Form Validation Class Initialized
INFO - 2025-03-19 08:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:01:56 --> Pagination Class Initialized
INFO - 2025-03-19 08:01:56 --> Controller Class Initialized
DEBUG - 2025-03-19 08:01:56 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:01:56 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:01:56 --> Model Class Initialized
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:01:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:01:56 --> Model Class Initialized
ERROR - 2025-03-19 08:01:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:01:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/purchase_report_category_wise.php
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:01:56 --> Final output sent to browser
DEBUG - 2025-03-19 08:01:56 --> Total execution time: 0.1287
INFO - 2025-03-19 08:02:17 --> Config Class Initialized
INFO - 2025-03-19 08:02:17 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:02:17 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:02:17 --> Utf8 Class Initialized
INFO - 2025-03-19 08:02:17 --> URI Class Initialized
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:02:17 --> Router Class Initialized
INFO - 2025-03-19 08:02:17 --> Output Class Initialized
INFO - 2025-03-19 08:02:17 --> Security Class Initialized
DEBUG - 2025-03-19 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:02:17 --> Input Class Initialized
INFO - 2025-03-19 08:02:17 --> Language Class Initialized
INFO - 2025-03-19 08:02:17 --> Language Class Initialized
INFO - 2025-03-19 08:02:17 --> Config Class Initialized
INFO - 2025-03-19 08:02:17 --> Loader Class Initialized
INFO - 2025-03-19 08:02:17 --> Helper loaded: url_helper
INFO - 2025-03-19 08:02:17 --> Helper loaded: file_helper
INFO - 2025-03-19 08:02:17 --> Helper loaded: html_helper
INFO - 2025-03-19 08:02:17 --> Helper loaded: form_helper
INFO - 2025-03-19 08:02:17 --> Helper loaded: text_helper
INFO - 2025-03-19 08:02:17 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:02:17 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:02:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:02:17 --> Database Driver Class Initialized
INFO - 2025-03-19 08:02:17 --> Email Class Initialized
INFO - 2025-03-19 08:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:02:17 --> Form Validation Class Initialized
INFO - 2025-03-19 08:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:02:17 --> Pagination Class Initialized
INFO - 2025-03-19 08:02:17 --> Controller Class Initialized
DEBUG - 2025-03-19 08:02:17 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:02:17 --> Model Class Initialized
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:02:17 --> Model Class Initialized
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:02:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:02:17 --> Model Class Initialized
ERROR - 2025-03-19 08:02:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:02:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:02:17 --> Final output sent to browser
DEBUG - 2025-03-19 08:02:17 --> Total execution time: 0.0924
INFO - 2025-03-19 08:02:28 --> Config Class Initialized
INFO - 2025-03-19 08:02:28 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:02:28 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:02:28 --> Utf8 Class Initialized
INFO - 2025-03-19 08:02:28 --> URI Class Initialized
DEBUG - 2025-03-19 08:02:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:02:28 --> Router Class Initialized
INFO - 2025-03-19 08:02:28 --> Output Class Initialized
INFO - 2025-03-19 08:02:28 --> Security Class Initialized
DEBUG - 2025-03-19 08:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:02:28 --> Input Class Initialized
INFO - 2025-03-19 08:02:28 --> Language Class Initialized
INFO - 2025-03-19 08:02:28 --> Language Class Initialized
INFO - 2025-03-19 08:02:28 --> Config Class Initialized
INFO - 2025-03-19 08:02:28 --> Loader Class Initialized
INFO - 2025-03-19 08:02:28 --> Helper loaded: url_helper
INFO - 2025-03-19 08:02:28 --> Helper loaded: file_helper
INFO - 2025-03-19 08:02:28 --> Helper loaded: html_helper
INFO - 2025-03-19 08:02:28 --> Helper loaded: form_helper
INFO - 2025-03-19 08:02:28 --> Helper loaded: text_helper
INFO - 2025-03-19 08:02:28 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:02:28 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:02:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:02:28 --> Database Driver Class Initialized
INFO - 2025-03-19 08:02:28 --> Email Class Initialized
INFO - 2025-03-19 08:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:02:28 --> Form Validation Class Initialized
INFO - 2025-03-19 08:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:02:28 --> Pagination Class Initialized
INFO - 2025-03-19 08:02:28 --> Controller Class Initialized
DEBUG - 2025-03-19 08:02:28 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:02:28 --> Model Class Initialized
DEBUG - 2025-03-19 08:02:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:02:28 --> Model Class Initialized
INFO - 2025-03-19 08:02:28 --> Final output sent to browser
DEBUG - 2025-03-19 08:02:28 --> Total execution time: 0.0084
INFO - 2025-03-19 08:02:31 --> Config Class Initialized
INFO - 2025-03-19 08:02:31 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:02:31 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:02:31 --> Utf8 Class Initialized
INFO - 2025-03-19 08:02:31 --> URI Class Initialized
DEBUG - 2025-03-19 08:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:02:31 --> Router Class Initialized
INFO - 2025-03-19 08:02:31 --> Output Class Initialized
INFO - 2025-03-19 08:02:31 --> Security Class Initialized
DEBUG - 2025-03-19 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:02:31 --> Input Class Initialized
INFO - 2025-03-19 08:02:31 --> Language Class Initialized
INFO - 2025-03-19 08:02:31 --> Language Class Initialized
INFO - 2025-03-19 08:02:31 --> Config Class Initialized
INFO - 2025-03-19 08:02:31 --> Loader Class Initialized
INFO - 2025-03-19 08:02:31 --> Helper loaded: url_helper
INFO - 2025-03-19 08:02:31 --> Helper loaded: file_helper
INFO - 2025-03-19 08:02:31 --> Helper loaded: html_helper
INFO - 2025-03-19 08:02:31 --> Helper loaded: form_helper
INFO - 2025-03-19 08:02:31 --> Helper loaded: text_helper
INFO - 2025-03-19 08:02:31 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:02:31 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:02:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:02:31 --> Database Driver Class Initialized
INFO - 2025-03-19 08:02:31 --> Email Class Initialized
INFO - 2025-03-19 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:02:31 --> Form Validation Class Initialized
INFO - 2025-03-19 08:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:02:31 --> Pagination Class Initialized
INFO - 2025-03-19 08:02:31 --> Controller Class Initialized
DEBUG - 2025-03-19 08:02:31 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:02:31 --> Model Class Initialized
DEBUG - 2025-03-19 08:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:02:31 --> Model Class Initialized
INFO - 2025-03-19 08:02:31 --> Final output sent to browser
DEBUG - 2025-03-19 08:02:31 --> Total execution time: 0.0076
INFO - 2025-03-19 08:03:52 --> Config Class Initialized
INFO - 2025-03-19 08:03:52 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:03:52 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:03:52 --> Utf8 Class Initialized
INFO - 2025-03-19 08:03:52 --> URI Class Initialized
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:03:52 --> Router Class Initialized
INFO - 2025-03-19 08:03:52 --> Output Class Initialized
INFO - 2025-03-19 08:03:52 --> Security Class Initialized
DEBUG - 2025-03-19 08:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:03:52 --> Input Class Initialized
INFO - 2025-03-19 08:03:52 --> Language Class Initialized
INFO - 2025-03-19 08:03:52 --> Language Class Initialized
INFO - 2025-03-19 08:03:52 --> Config Class Initialized
INFO - 2025-03-19 08:03:52 --> Loader Class Initialized
INFO - 2025-03-19 08:03:52 --> Helper loaded: url_helper
INFO - 2025-03-19 08:03:52 --> Helper loaded: file_helper
INFO - 2025-03-19 08:03:52 --> Helper loaded: html_helper
INFO - 2025-03-19 08:03:52 --> Helper loaded: form_helper
INFO - 2025-03-19 08:03:52 --> Helper loaded: text_helper
INFO - 2025-03-19 08:03:52 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:03:52 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:03:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:03:52 --> Database Driver Class Initialized
INFO - 2025-03-19 08:03:52 --> Email Class Initialized
INFO - 2025-03-19 08:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:03:52 --> Form Validation Class Initialized
INFO - 2025-03-19 08:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:03:52 --> Pagination Class Initialized
INFO - 2025-03-19 08:03:52 --> Controller Class Initialized
DEBUG - 2025-03-19 08:03:52 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:03:52 --> Model Class Initialized
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:03:52 --> Model Class Initialized
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:03:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:03:52 --> Model Class Initialized
ERROR - 2025-03-19 08:03:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:03:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:03:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:03:52 --> Final output sent to browser
DEBUG - 2025-03-19 08:03:52 --> Total execution time: 0.1444
INFO - 2025-03-19 08:04:11 --> Config Class Initialized
INFO - 2025-03-19 08:04:11 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:04:11 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:04:11 --> Utf8 Class Initialized
INFO - 2025-03-19 08:04:11 --> URI Class Initialized
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:04:11 --> Router Class Initialized
INFO - 2025-03-19 08:04:11 --> Output Class Initialized
INFO - 2025-03-19 08:04:11 --> Security Class Initialized
DEBUG - 2025-03-19 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:04:11 --> Input Class Initialized
INFO - 2025-03-19 08:04:11 --> Language Class Initialized
INFO - 2025-03-19 08:04:11 --> Language Class Initialized
INFO - 2025-03-19 08:04:11 --> Config Class Initialized
INFO - 2025-03-19 08:04:11 --> Loader Class Initialized
INFO - 2025-03-19 08:04:11 --> Helper loaded: url_helper
INFO - 2025-03-19 08:04:11 --> Helper loaded: file_helper
INFO - 2025-03-19 08:04:11 --> Helper loaded: html_helper
INFO - 2025-03-19 08:04:11 --> Helper loaded: form_helper
INFO - 2025-03-19 08:04:11 --> Helper loaded: text_helper
INFO - 2025-03-19 08:04:11 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:04:11 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:04:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:04:11 --> Database Driver Class Initialized
INFO - 2025-03-19 08:04:11 --> Email Class Initialized
INFO - 2025-03-19 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:04:11 --> Form Validation Class Initialized
INFO - 2025-03-19 08:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:04:11 --> Pagination Class Initialized
INFO - 2025-03-19 08:04:11 --> Controller Class Initialized
DEBUG - 2025-03-19 08:04:11 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:04:11 --> Model Class Initialized
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:04:11 --> Model Class Initialized
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:04:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:04:11 --> Model Class Initialized
ERROR - 2025-03-19 08:04:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:04:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:04:11 --> Final output sent to browser
DEBUG - 2025-03-19 08:04:11 --> Total execution time: 0.0942
INFO - 2025-03-19 08:04:14 --> Config Class Initialized
INFO - 2025-03-19 08:04:14 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:04:14 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:04:14 --> Utf8 Class Initialized
INFO - 2025-03-19 08:04:14 --> URI Class Initialized
DEBUG - 2025-03-19 08:04:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:04:14 --> Router Class Initialized
INFO - 2025-03-19 08:04:14 --> Output Class Initialized
INFO - 2025-03-19 08:04:14 --> Security Class Initialized
DEBUG - 2025-03-19 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:04:14 --> Input Class Initialized
INFO - 2025-03-19 08:04:14 --> Language Class Initialized
INFO - 2025-03-19 08:04:14 --> Language Class Initialized
INFO - 2025-03-19 08:04:14 --> Config Class Initialized
INFO - 2025-03-19 08:04:14 --> Loader Class Initialized
INFO - 2025-03-19 08:04:14 --> Helper loaded: url_helper
INFO - 2025-03-19 08:04:14 --> Helper loaded: file_helper
INFO - 2025-03-19 08:04:14 --> Helper loaded: html_helper
INFO - 2025-03-19 08:04:14 --> Helper loaded: form_helper
INFO - 2025-03-19 08:04:14 --> Helper loaded: text_helper
INFO - 2025-03-19 08:04:14 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:04:14 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:04:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:04:14 --> Database Driver Class Initialized
INFO - 2025-03-19 08:04:14 --> Email Class Initialized
INFO - 2025-03-19 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:04:14 --> Form Validation Class Initialized
INFO - 2025-03-19 08:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:04:14 --> Pagination Class Initialized
INFO - 2025-03-19 08:04:14 --> Controller Class Initialized
DEBUG - 2025-03-19 08:04:14 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:04:14 --> Model Class Initialized
DEBUG - 2025-03-19 08:04:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:04:14 --> Model Class Initialized
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:04:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:04:15 --> Model Class Initialized
ERROR - 2025-03-19 08:04:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:04:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/customer_receive_form.php
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:04:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:04:15 --> Final output sent to browser
DEBUG - 2025-03-19 08:04:15 --> Total execution time: 0.1450
INFO - 2025-03-19 08:05:17 --> Config Class Initialized
INFO - 2025-03-19 08:05:17 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:05:17 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:05:17 --> Utf8 Class Initialized
INFO - 2025-03-19 08:05:17 --> URI Class Initialized
DEBUG - 2025-03-19 08:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:05:17 --> Router Class Initialized
INFO - 2025-03-19 08:05:17 --> Output Class Initialized
INFO - 2025-03-19 08:05:17 --> Security Class Initialized
DEBUG - 2025-03-19 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:05:17 --> Input Class Initialized
INFO - 2025-03-19 08:05:17 --> Language Class Initialized
INFO - 2025-03-19 08:05:17 --> Language Class Initialized
INFO - 2025-03-19 08:05:17 --> Config Class Initialized
INFO - 2025-03-19 08:05:17 --> Loader Class Initialized
INFO - 2025-03-19 08:05:17 --> Helper loaded: url_helper
INFO - 2025-03-19 08:05:17 --> Helper loaded: file_helper
INFO - 2025-03-19 08:05:17 --> Helper loaded: html_helper
INFO - 2025-03-19 08:05:17 --> Helper loaded: form_helper
INFO - 2025-03-19 08:05:17 --> Helper loaded: text_helper
INFO - 2025-03-19 08:05:17 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:05:17 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:05:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:05:17 --> Database Driver Class Initialized
INFO - 2025-03-19 08:05:17 --> Email Class Initialized
INFO - 2025-03-19 08:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:05:17 --> Form Validation Class Initialized
INFO - 2025-03-19 08:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:05:17 --> Pagination Class Initialized
INFO - 2025-03-19 08:05:17 --> Controller Class Initialized
DEBUG - 2025-03-19 08:05:17 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:05:17 --> Model Class Initialized
DEBUG - 2025-03-19 08:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:05:17 --> Model Class Initialized
DEBUG - 2025-03-19 08:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/newpaymentveiw.php
INFO - 2025-03-19 08:05:17 --> Final output sent to browser
DEBUG - 2025-03-19 08:05:17 --> Total execution time: 0.0170
INFO - 2025-03-19 08:15:48 --> Config Class Initialized
INFO - 2025-03-19 08:15:48 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:15:48 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:15:48 --> Utf8 Class Initialized
INFO - 2025-03-19 08:15:48 --> URI Class Initialized
DEBUG - 2025-03-19 08:15:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-19 08:15:48 --> Router Class Initialized
INFO - 2025-03-19 08:15:48 --> Output Class Initialized
INFO - 2025-03-19 08:15:48 --> Security Class Initialized
DEBUG - 2025-03-19 08:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:15:48 --> Input Class Initialized
INFO - 2025-03-19 08:15:48 --> Language Class Initialized
INFO - 2025-03-19 08:15:48 --> Language Class Initialized
INFO - 2025-03-19 08:15:48 --> Config Class Initialized
INFO - 2025-03-19 08:15:48 --> Loader Class Initialized
INFO - 2025-03-19 08:15:48 --> Helper loaded: url_helper
INFO - 2025-03-19 08:15:48 --> Helper loaded: file_helper
INFO - 2025-03-19 08:15:48 --> Helper loaded: html_helper
INFO - 2025-03-19 08:15:48 --> Helper loaded: form_helper
INFO - 2025-03-19 08:15:48 --> Helper loaded: text_helper
INFO - 2025-03-19 08:15:48 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:15:48 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:15:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:15:48 --> Database Driver Class Initialized
INFO - 2025-03-19 08:15:48 --> Email Class Initialized
INFO - 2025-03-19 08:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:15:48 --> Form Validation Class Initialized
INFO - 2025-03-19 08:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:15:48 --> Pagination Class Initialized
INFO - 2025-03-19 08:15:48 --> Controller Class Initialized
DEBUG - 2025-03-19 08:15:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-19 08:15:48 --> Model Class Initialized
DEBUG - 2025-03-19 08:15:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:15:48 --> Model Class Initialized
DEBUG - 2025-03-19 08:15:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/newpaymentveiw.php
INFO - 2025-03-19 08:15:48 --> Final output sent to browser
DEBUG - 2025-03-19 08:15:48 --> Total execution time: 0.0227
INFO - 2025-03-19 08:23:42 --> Config Class Initialized
INFO - 2025-03-19 08:23:42 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:23:42 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:23:42 --> Utf8 Class Initialized
INFO - 2025-03-19 08:23:42 --> URI Class Initialized
DEBUG - 2025-03-19 08:23:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:23:42 --> Router Class Initialized
INFO - 2025-03-19 08:23:42 --> Output Class Initialized
INFO - 2025-03-19 08:23:42 --> Security Class Initialized
DEBUG - 2025-03-19 08:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:23:42 --> Input Class Initialized
INFO - 2025-03-19 08:23:42 --> Language Class Initialized
INFO - 2025-03-19 08:23:42 --> Language Class Initialized
INFO - 2025-03-19 08:23:42 --> Config Class Initialized
INFO - 2025-03-19 08:23:42 --> Loader Class Initialized
INFO - 2025-03-19 08:23:42 --> Helper loaded: url_helper
INFO - 2025-03-19 08:23:42 --> Helper loaded: file_helper
INFO - 2025-03-19 08:23:42 --> Helper loaded: html_helper
INFO - 2025-03-19 08:23:42 --> Helper loaded: form_helper
INFO - 2025-03-19 08:23:42 --> Helper loaded: text_helper
INFO - 2025-03-19 08:23:42 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:23:42 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:23:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:23:42 --> Database Driver Class Initialized
INFO - 2025-03-19 08:23:42 --> Email Class Initialized
INFO - 2025-03-19 08:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:23:42 --> Form Validation Class Initialized
INFO - 2025-03-19 08:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:23:42 --> Pagination Class Initialized
INFO - 2025-03-19 08:23:42 --> Controller Class Initialized
DEBUG - 2025-03-19 08:23:42 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:23:42 --> Model Class Initialized
DEBUG - 2025-03-19 08:23:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:23:42 --> Model Class Initialized
ERROR - 2025-03-19 08:23:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 08:24:08 --> Config Class Initialized
INFO - 2025-03-19 08:24:08 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:24:08 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:24:08 --> Utf8 Class Initialized
INFO - 2025-03-19 08:24:08 --> URI Class Initialized
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:24:08 --> Router Class Initialized
INFO - 2025-03-19 08:24:08 --> Output Class Initialized
INFO - 2025-03-19 08:24:08 --> Security Class Initialized
DEBUG - 2025-03-19 08:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:24:08 --> Input Class Initialized
INFO - 2025-03-19 08:24:08 --> Language Class Initialized
INFO - 2025-03-19 08:24:08 --> Language Class Initialized
INFO - 2025-03-19 08:24:08 --> Config Class Initialized
INFO - 2025-03-19 08:24:08 --> Loader Class Initialized
INFO - 2025-03-19 08:24:08 --> Helper loaded: url_helper
INFO - 2025-03-19 08:24:08 --> Helper loaded: file_helper
INFO - 2025-03-19 08:24:08 --> Helper loaded: html_helper
INFO - 2025-03-19 08:24:08 --> Helper loaded: form_helper
INFO - 2025-03-19 08:24:08 --> Helper loaded: text_helper
INFO - 2025-03-19 08:24:08 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:24:08 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:24:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:24:08 --> Database Driver Class Initialized
INFO - 2025-03-19 08:24:08 --> Email Class Initialized
INFO - 2025-03-19 08:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:24:08 --> Form Validation Class Initialized
INFO - 2025-03-19 08:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:24:08 --> Pagination Class Initialized
INFO - 2025-03-19 08:24:08 --> Controller Class Initialized
DEBUG - 2025-03-19 08:24:08 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:24:08 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:24:08 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:24:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:24:08 --> Model Class Initialized
ERROR - 2025-03-19 08:24:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:24:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:24:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:24:08 --> Final output sent to browser
DEBUG - 2025-03-19 08:24:08 --> Total execution time: 0.6529
INFO - 2025-03-19 08:24:09 --> Config Class Initialized
INFO - 2025-03-19 08:24:09 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:24:09 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:24:09 --> Utf8 Class Initialized
INFO - 2025-03-19 08:24:09 --> URI Class Initialized
DEBUG - 2025-03-19 08:24:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:24:09 --> Router Class Initialized
INFO - 2025-03-19 08:24:09 --> Output Class Initialized
INFO - 2025-03-19 08:24:09 --> Security Class Initialized
DEBUG - 2025-03-19 08:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:24:09 --> Input Class Initialized
INFO - 2025-03-19 08:24:09 --> Language Class Initialized
INFO - 2025-03-19 08:24:09 --> Language Class Initialized
INFO - 2025-03-19 08:24:09 --> Config Class Initialized
INFO - 2025-03-19 08:24:09 --> Loader Class Initialized
INFO - 2025-03-19 08:24:09 --> Helper loaded: url_helper
INFO - 2025-03-19 08:24:09 --> Helper loaded: file_helper
INFO - 2025-03-19 08:24:09 --> Helper loaded: html_helper
INFO - 2025-03-19 08:24:09 --> Helper loaded: form_helper
INFO - 2025-03-19 08:24:09 --> Helper loaded: text_helper
INFO - 2025-03-19 08:24:09 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:24:09 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:24:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:24:09 --> Database Driver Class Initialized
INFO - 2025-03-19 08:24:09 --> Email Class Initialized
INFO - 2025-03-19 08:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:24:09 --> Form Validation Class Initialized
INFO - 2025-03-19 08:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:24:09 --> Pagination Class Initialized
INFO - 2025-03-19 08:24:09 --> Controller Class Initialized
DEBUG - 2025-03-19 08:24:09 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:24:09 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:24:09 --> Model Class Initialized
ERROR - 2025-03-19 08:24:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-19 08:24:33 --> Config Class Initialized
INFO - 2025-03-19 08:24:33 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:24:33 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:24:33 --> Utf8 Class Initialized
INFO - 2025-03-19 08:24:33 --> URI Class Initialized
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:24:33 --> Router Class Initialized
INFO - 2025-03-19 08:24:33 --> Output Class Initialized
INFO - 2025-03-19 08:24:33 --> Security Class Initialized
DEBUG - 2025-03-19 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:24:33 --> Input Class Initialized
INFO - 2025-03-19 08:24:33 --> Language Class Initialized
INFO - 2025-03-19 08:24:33 --> Language Class Initialized
INFO - 2025-03-19 08:24:33 --> Config Class Initialized
INFO - 2025-03-19 08:24:33 --> Loader Class Initialized
INFO - 2025-03-19 08:24:33 --> Helper loaded: url_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: file_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: html_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: form_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: text_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:24:33 --> Database Driver Class Initialized
INFO - 2025-03-19 08:24:33 --> Email Class Initialized
INFO - 2025-03-19 08:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:24:33 --> Form Validation Class Initialized
INFO - 2025-03-19 08:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:24:33 --> Pagination Class Initialized
INFO - 2025-03-19 08:24:33 --> Controller Class Initialized
DEBUG - 2025-03-19 08:24:33 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:24:33 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:24:33 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:24:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:24:33 --> Model Class Initialized
ERROR - 2025-03-19 08:24:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:24:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:24:33 --> Final output sent to browser
DEBUG - 2025-03-19 08:24:33 --> Total execution time: 0.1104
INFO - 2025-03-19 08:24:33 --> Config Class Initialized
INFO - 2025-03-19 08:24:33 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:24:33 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:24:33 --> Utf8 Class Initialized
INFO - 2025-03-19 08:24:33 --> URI Class Initialized
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:24:33 --> Router Class Initialized
INFO - 2025-03-19 08:24:33 --> Output Class Initialized
INFO - 2025-03-19 08:24:33 --> Security Class Initialized
DEBUG - 2025-03-19 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:24:33 --> Input Class Initialized
INFO - 2025-03-19 08:24:33 --> Language Class Initialized
INFO - 2025-03-19 08:24:33 --> Language Class Initialized
INFO - 2025-03-19 08:24:33 --> Config Class Initialized
INFO - 2025-03-19 08:24:33 --> Loader Class Initialized
INFO - 2025-03-19 08:24:33 --> Helper loaded: url_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: file_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: html_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: form_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: text_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:24:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:24:33 --> Database Driver Class Initialized
INFO - 2025-03-19 08:24:33 --> Email Class Initialized
INFO - 2025-03-19 08:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:24:33 --> Form Validation Class Initialized
INFO - 2025-03-19 08:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:24:33 --> Pagination Class Initialized
INFO - 2025-03-19 08:24:33 --> Controller Class Initialized
DEBUG - 2025-03-19 08:24:33 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:24:33 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:24:33 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:24:33 --> Model Class Initialized
INFO - 2025-03-19 08:24:33 --> Final output sent to browser
DEBUG - 2025-03-19 08:24:33 --> Total execution time: 0.0118
INFO - 2025-03-19 08:24:47 --> Config Class Initialized
INFO - 2025-03-19 08:24:47 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:24:47 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:24:47 --> Utf8 Class Initialized
INFO - 2025-03-19 08:24:47 --> URI Class Initialized
DEBUG - 2025-03-19 08:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:24:47 --> Router Class Initialized
INFO - 2025-03-19 08:24:47 --> Output Class Initialized
INFO - 2025-03-19 08:24:47 --> Security Class Initialized
DEBUG - 2025-03-19 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:24:47 --> Input Class Initialized
INFO - 2025-03-19 08:24:47 --> Language Class Initialized
INFO - 2025-03-19 08:24:47 --> Language Class Initialized
INFO - 2025-03-19 08:24:47 --> Config Class Initialized
INFO - 2025-03-19 08:24:47 --> Loader Class Initialized
INFO - 2025-03-19 08:24:47 --> Helper loaded: url_helper
INFO - 2025-03-19 08:24:47 --> Helper loaded: file_helper
INFO - 2025-03-19 08:24:47 --> Helper loaded: html_helper
INFO - 2025-03-19 08:24:47 --> Helper loaded: form_helper
INFO - 2025-03-19 08:24:47 --> Helper loaded: text_helper
INFO - 2025-03-19 08:24:47 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:24:47 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:24:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:24:47 --> Database Driver Class Initialized
INFO - 2025-03-19 08:24:47 --> Email Class Initialized
INFO - 2025-03-19 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:24:47 --> Form Validation Class Initialized
INFO - 2025-03-19 08:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:24:47 --> Pagination Class Initialized
INFO - 2025-03-19 08:24:47 --> Controller Class Initialized
DEBUG - 2025-03-19 08:24:47 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:24:47 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:24:47 --> Model Class Initialized
DEBUG - 2025-03-19 08:24:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:24:47 --> Model Class Initialized
INFO - 2025-03-19 08:24:47 --> Final output sent to browser
DEBUG - 2025-03-19 08:24:47 --> Total execution time: 0.0088
INFO - 2025-03-19 08:26:59 --> Config Class Initialized
INFO - 2025-03-19 08:26:59 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:26:59 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:26:59 --> Utf8 Class Initialized
INFO - 2025-03-19 08:26:59 --> URI Class Initialized
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:26:59 --> Router Class Initialized
INFO - 2025-03-19 08:26:59 --> Output Class Initialized
INFO - 2025-03-19 08:26:59 --> Security Class Initialized
DEBUG - 2025-03-19 08:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:26:59 --> Input Class Initialized
INFO - 2025-03-19 08:26:59 --> Language Class Initialized
INFO - 2025-03-19 08:26:59 --> Language Class Initialized
INFO - 2025-03-19 08:26:59 --> Config Class Initialized
INFO - 2025-03-19 08:26:59 --> Loader Class Initialized
INFO - 2025-03-19 08:26:59 --> Helper loaded: url_helper
INFO - 2025-03-19 08:26:59 --> Helper loaded: file_helper
INFO - 2025-03-19 08:26:59 --> Helper loaded: html_helper
INFO - 2025-03-19 08:26:59 --> Helper loaded: form_helper
INFO - 2025-03-19 08:26:59 --> Helper loaded: text_helper
INFO - 2025-03-19 08:26:59 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:26:59 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:26:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:26:59 --> Database Driver Class Initialized
INFO - 2025-03-19 08:26:59 --> Email Class Initialized
INFO - 2025-03-19 08:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:26:59 --> Form Validation Class Initialized
INFO - 2025-03-19 08:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:26:59 --> Pagination Class Initialized
INFO - 2025-03-19 08:26:59 --> Controller Class Initialized
DEBUG - 2025-03-19 08:26:59 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:26:59 --> Model Class Initialized
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:26:59 --> Model Class Initialized
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:26:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:26:59 --> Model Class Initialized
ERROR - 2025-03-19 08:26:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:26:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:26:59 --> Final output sent to browser
DEBUG - 2025-03-19 08:26:59 --> Total execution time: 0.1007
INFO - 2025-03-19 08:27:00 --> Config Class Initialized
INFO - 2025-03-19 08:27:00 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:27:00 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:27:00 --> Utf8 Class Initialized
INFO - 2025-03-19 08:27:00 --> URI Class Initialized
DEBUG - 2025-03-19 08:27:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:27:00 --> Router Class Initialized
INFO - 2025-03-19 08:27:00 --> Output Class Initialized
INFO - 2025-03-19 08:27:00 --> Security Class Initialized
DEBUG - 2025-03-19 08:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:27:00 --> Input Class Initialized
INFO - 2025-03-19 08:27:00 --> Language Class Initialized
INFO - 2025-03-19 08:27:00 --> Language Class Initialized
INFO - 2025-03-19 08:27:00 --> Config Class Initialized
INFO - 2025-03-19 08:27:00 --> Loader Class Initialized
INFO - 2025-03-19 08:27:00 --> Helper loaded: url_helper
INFO - 2025-03-19 08:27:00 --> Helper loaded: file_helper
INFO - 2025-03-19 08:27:00 --> Helper loaded: html_helper
INFO - 2025-03-19 08:27:00 --> Helper loaded: form_helper
INFO - 2025-03-19 08:27:00 --> Helper loaded: text_helper
INFO - 2025-03-19 08:27:00 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:27:00 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:27:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:27:00 --> Database Driver Class Initialized
INFO - 2025-03-19 08:27:00 --> Email Class Initialized
INFO - 2025-03-19 08:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:27:00 --> Form Validation Class Initialized
INFO - 2025-03-19 08:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:27:00 --> Pagination Class Initialized
INFO - 2025-03-19 08:27:00 --> Controller Class Initialized
DEBUG - 2025-03-19 08:27:00 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:27:00 --> Model Class Initialized
DEBUG - 2025-03-19 08:27:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:27:00 --> Model Class Initialized
DEBUG - 2025-03-19 08:27:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:27:00 --> Model Class Initialized
INFO - 2025-03-19 08:27:00 --> Final output sent to browser
DEBUG - 2025-03-19 08:27:00 --> Total execution time: 0.0167
INFO - 2025-03-19 08:32:12 --> Config Class Initialized
INFO - 2025-03-19 08:32:12 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:32:12 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:32:12 --> Utf8 Class Initialized
INFO - 2025-03-19 08:32:12 --> URI Class Initialized
DEBUG - 2025-03-19 08:32:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:32:12 --> Router Class Initialized
INFO - 2025-03-19 08:32:12 --> Output Class Initialized
INFO - 2025-03-19 08:32:12 --> Security Class Initialized
DEBUG - 2025-03-19 08:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:32:12 --> Input Class Initialized
INFO - 2025-03-19 08:32:12 --> Language Class Initialized
INFO - 2025-03-19 08:32:12 --> Language Class Initialized
INFO - 2025-03-19 08:32:12 --> Config Class Initialized
INFO - 2025-03-19 08:32:12 --> Loader Class Initialized
INFO - 2025-03-19 08:32:12 --> Helper loaded: url_helper
INFO - 2025-03-19 08:32:12 --> Helper loaded: file_helper
INFO - 2025-03-19 08:32:12 --> Helper loaded: html_helper
INFO - 2025-03-19 08:32:12 --> Helper loaded: form_helper
INFO - 2025-03-19 08:32:12 --> Helper loaded: text_helper
INFO - 2025-03-19 08:32:12 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:32:12 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:32:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:32:12 --> Database Driver Class Initialized
INFO - 2025-03-19 08:32:12 --> Email Class Initialized
INFO - 2025-03-19 08:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:32:12 --> Form Validation Class Initialized
INFO - 2025-03-19 08:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:32:12 --> Pagination Class Initialized
INFO - 2025-03-19 08:32:12 --> Controller Class Initialized
DEBUG - 2025-03-19 08:32:12 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:32:12 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:32:12 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:32:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:32:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:32:12 --> Model Class Initialized
ERROR - 2025-03-19 08:32:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:32:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:32:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:32:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:32:13 --> Final output sent to browser
DEBUG - 2025-03-19 08:32:13 --> Total execution time: 0.1288
INFO - 2025-03-19 08:32:13 --> Config Class Initialized
INFO - 2025-03-19 08:32:13 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:32:13 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:32:13 --> Utf8 Class Initialized
INFO - 2025-03-19 08:32:13 --> URI Class Initialized
DEBUG - 2025-03-19 08:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:32:13 --> Router Class Initialized
INFO - 2025-03-19 08:32:13 --> Output Class Initialized
INFO - 2025-03-19 08:32:13 --> Security Class Initialized
DEBUG - 2025-03-19 08:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:32:13 --> Input Class Initialized
INFO - 2025-03-19 08:32:13 --> Language Class Initialized
INFO - 2025-03-19 08:32:13 --> Language Class Initialized
INFO - 2025-03-19 08:32:13 --> Config Class Initialized
INFO - 2025-03-19 08:32:13 --> Loader Class Initialized
INFO - 2025-03-19 08:32:13 --> Helper loaded: url_helper
INFO - 2025-03-19 08:32:13 --> Helper loaded: file_helper
INFO - 2025-03-19 08:32:13 --> Helper loaded: html_helper
INFO - 2025-03-19 08:32:13 --> Helper loaded: form_helper
INFO - 2025-03-19 08:32:13 --> Helper loaded: text_helper
INFO - 2025-03-19 08:32:13 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:32:13 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:32:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:32:13 --> Database Driver Class Initialized
INFO - 2025-03-19 08:32:13 --> Email Class Initialized
INFO - 2025-03-19 08:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:32:13 --> Form Validation Class Initialized
INFO - 2025-03-19 08:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:32:13 --> Pagination Class Initialized
INFO - 2025-03-19 08:32:13 --> Controller Class Initialized
DEBUG - 2025-03-19 08:32:13 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:32:13 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:32:13 --> Model Class Initialized
INFO - 2025-03-19 08:32:13 --> Final output sent to browser
DEBUG - 2025-03-19 08:32:13 --> Total execution time: 0.0081
INFO - 2025-03-19 08:32:49 --> Config Class Initialized
INFO - 2025-03-19 08:32:49 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:32:49 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:32:49 --> Utf8 Class Initialized
INFO - 2025-03-19 08:32:49 --> URI Class Initialized
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:32:49 --> Router Class Initialized
INFO - 2025-03-19 08:32:49 --> Output Class Initialized
INFO - 2025-03-19 08:32:49 --> Security Class Initialized
DEBUG - 2025-03-19 08:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:32:49 --> Input Class Initialized
INFO - 2025-03-19 08:32:49 --> Language Class Initialized
INFO - 2025-03-19 08:32:49 --> Language Class Initialized
INFO - 2025-03-19 08:32:49 --> Config Class Initialized
INFO - 2025-03-19 08:32:49 --> Loader Class Initialized
INFO - 2025-03-19 08:32:49 --> Helper loaded: url_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: file_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: html_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: form_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: text_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:32:49 --> Database Driver Class Initialized
INFO - 2025-03-19 08:32:49 --> Email Class Initialized
INFO - 2025-03-19 08:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:32:49 --> Form Validation Class Initialized
INFO - 2025-03-19 08:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:32:49 --> Pagination Class Initialized
INFO - 2025-03-19 08:32:49 --> Controller Class Initialized
DEBUG - 2025-03-19 08:32:49 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:32:49 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:32:49 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:32:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:32:49 --> Model Class Initialized
ERROR - 2025-03-19 08:32:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:32:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:32:49 --> Final output sent to browser
DEBUG - 2025-03-19 08:32:49 --> Total execution time: 0.1430
INFO - 2025-03-19 08:32:49 --> Config Class Initialized
INFO - 2025-03-19 08:32:49 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:32:49 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:32:49 --> Utf8 Class Initialized
INFO - 2025-03-19 08:32:49 --> URI Class Initialized
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:32:49 --> Router Class Initialized
INFO - 2025-03-19 08:32:49 --> Output Class Initialized
INFO - 2025-03-19 08:32:49 --> Security Class Initialized
DEBUG - 2025-03-19 08:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:32:49 --> Input Class Initialized
INFO - 2025-03-19 08:32:49 --> Language Class Initialized
INFO - 2025-03-19 08:32:49 --> Language Class Initialized
INFO - 2025-03-19 08:32:49 --> Config Class Initialized
INFO - 2025-03-19 08:32:49 --> Loader Class Initialized
INFO - 2025-03-19 08:32:49 --> Helper loaded: url_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: file_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: html_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: form_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: text_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:32:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:32:49 --> Database Driver Class Initialized
INFO - 2025-03-19 08:32:49 --> Email Class Initialized
INFO - 2025-03-19 08:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:32:49 --> Form Validation Class Initialized
INFO - 2025-03-19 08:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:32:49 --> Pagination Class Initialized
INFO - 2025-03-19 08:32:49 --> Controller Class Initialized
DEBUG - 2025-03-19 08:32:49 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:32:49 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:32:49 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:32:49 --> Model Class Initialized
INFO - 2025-03-19 08:32:49 --> Final output sent to browser
DEBUG - 2025-03-19 08:32:49 --> Total execution time: 0.0222
INFO - 2025-03-19 08:32:56 --> Config Class Initialized
INFO - 2025-03-19 08:32:56 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:32:56 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:32:56 --> Utf8 Class Initialized
INFO - 2025-03-19 08:32:56 --> URI Class Initialized
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:32:56 --> Router Class Initialized
INFO - 2025-03-19 08:32:56 --> Output Class Initialized
INFO - 2025-03-19 08:32:56 --> Security Class Initialized
DEBUG - 2025-03-19 08:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:32:56 --> Input Class Initialized
INFO - 2025-03-19 08:32:56 --> Language Class Initialized
INFO - 2025-03-19 08:32:56 --> Language Class Initialized
INFO - 2025-03-19 08:32:56 --> Config Class Initialized
INFO - 2025-03-19 08:32:56 --> Loader Class Initialized
INFO - 2025-03-19 08:32:56 --> Helper loaded: url_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: file_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: html_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: form_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: text_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:32:56 --> Database Driver Class Initialized
INFO - 2025-03-19 08:32:56 --> Email Class Initialized
INFO - 2025-03-19 08:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:32:56 --> Form Validation Class Initialized
INFO - 2025-03-19 08:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:32:56 --> Pagination Class Initialized
INFO - 2025-03-19 08:32:56 --> Controller Class Initialized
DEBUG - 2025-03-19 08:32:56 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:32:56 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:32:56 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:32:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:32:56 --> Model Class Initialized
ERROR - 2025-03-19 08:32:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:32:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:32:56 --> Final output sent to browser
DEBUG - 2025-03-19 08:32:56 --> Total execution time: 0.1376
INFO - 2025-03-19 08:32:56 --> Config Class Initialized
INFO - 2025-03-19 08:32:56 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:32:56 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:32:56 --> Utf8 Class Initialized
INFO - 2025-03-19 08:32:56 --> URI Class Initialized
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:32:56 --> Router Class Initialized
INFO - 2025-03-19 08:32:56 --> Output Class Initialized
INFO - 2025-03-19 08:32:56 --> Security Class Initialized
DEBUG - 2025-03-19 08:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:32:56 --> Input Class Initialized
INFO - 2025-03-19 08:32:56 --> Language Class Initialized
INFO - 2025-03-19 08:32:56 --> Language Class Initialized
INFO - 2025-03-19 08:32:56 --> Config Class Initialized
INFO - 2025-03-19 08:32:56 --> Loader Class Initialized
INFO - 2025-03-19 08:32:56 --> Helper loaded: url_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: file_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: html_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: form_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: text_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:32:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:32:56 --> Database Driver Class Initialized
INFO - 2025-03-19 08:32:56 --> Email Class Initialized
INFO - 2025-03-19 08:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:32:56 --> Form Validation Class Initialized
INFO - 2025-03-19 08:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:32:56 --> Pagination Class Initialized
INFO - 2025-03-19 08:32:56 --> Controller Class Initialized
DEBUG - 2025-03-19 08:32:56 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:32:56 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:32:56 --> Model Class Initialized
DEBUG - 2025-03-19 08:32:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:32:56 --> Model Class Initialized
INFO - 2025-03-19 08:32:56 --> Final output sent to browser
DEBUG - 2025-03-19 08:32:56 --> Total execution time: 0.0099
INFO - 2025-03-19 08:33:10 --> Config Class Initialized
INFO - 2025-03-19 08:33:10 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:33:10 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:33:10 --> Utf8 Class Initialized
INFO - 2025-03-19 08:33:10 --> URI Class Initialized
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:33:10 --> Router Class Initialized
INFO - 2025-03-19 08:33:10 --> Output Class Initialized
INFO - 2025-03-19 08:33:10 --> Security Class Initialized
DEBUG - 2025-03-19 08:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:33:10 --> Input Class Initialized
INFO - 2025-03-19 08:33:10 --> Language Class Initialized
INFO - 2025-03-19 08:33:10 --> Language Class Initialized
INFO - 2025-03-19 08:33:10 --> Config Class Initialized
INFO - 2025-03-19 08:33:10 --> Loader Class Initialized
INFO - 2025-03-19 08:33:10 --> Helper loaded: url_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: file_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: html_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: form_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: text_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:33:10 --> Database Driver Class Initialized
INFO - 2025-03-19 08:33:10 --> Email Class Initialized
INFO - 2025-03-19 08:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:33:10 --> Form Validation Class Initialized
INFO - 2025-03-19 08:33:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:33:10 --> Pagination Class Initialized
INFO - 2025-03-19 08:33:10 --> Controller Class Initialized
DEBUG - 2025-03-19 08:33:10 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:33:10 --> Model Class Initialized
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:33:10 --> Model Class Initialized
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:33:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:33:10 --> Model Class Initialized
ERROR - 2025-03-19 08:33:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:33:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:33:10 --> Final output sent to browser
DEBUG - 2025-03-19 08:33:10 --> Total execution time: 0.1229
INFO - 2025-03-19 08:33:10 --> Config Class Initialized
INFO - 2025-03-19 08:33:10 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:33:10 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:33:10 --> Utf8 Class Initialized
INFO - 2025-03-19 08:33:10 --> URI Class Initialized
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:33:10 --> Router Class Initialized
INFO - 2025-03-19 08:33:10 --> Output Class Initialized
INFO - 2025-03-19 08:33:10 --> Security Class Initialized
DEBUG - 2025-03-19 08:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:33:10 --> Input Class Initialized
INFO - 2025-03-19 08:33:10 --> Language Class Initialized
INFO - 2025-03-19 08:33:10 --> Language Class Initialized
INFO - 2025-03-19 08:33:10 --> Config Class Initialized
INFO - 2025-03-19 08:33:10 --> Loader Class Initialized
INFO - 2025-03-19 08:33:10 --> Helper loaded: url_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: file_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: html_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: form_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: text_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:33:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:33:10 --> Database Driver Class Initialized
INFO - 2025-03-19 08:33:10 --> Email Class Initialized
INFO - 2025-03-19 08:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:33:10 --> Form Validation Class Initialized
INFO - 2025-03-19 08:33:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:33:10 --> Pagination Class Initialized
INFO - 2025-03-19 08:33:10 --> Controller Class Initialized
DEBUG - 2025-03-19 08:33:10 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:33:10 --> Model Class Initialized
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:33:10 --> Model Class Initialized
DEBUG - 2025-03-19 08:33:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:33:10 --> Model Class Initialized
INFO - 2025-03-19 08:33:10 --> Final output sent to browser
DEBUG - 2025-03-19 08:33:10 --> Total execution time: 0.0102
INFO - 2025-03-19 08:35:38 --> Config Class Initialized
INFO - 2025-03-19 08:35:38 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:35:38 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:35:38 --> Utf8 Class Initialized
INFO - 2025-03-19 08:35:38 --> URI Class Initialized
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:35:38 --> Router Class Initialized
INFO - 2025-03-19 08:35:38 --> Output Class Initialized
INFO - 2025-03-19 08:35:38 --> Security Class Initialized
DEBUG - 2025-03-19 08:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:35:38 --> Input Class Initialized
INFO - 2025-03-19 08:35:38 --> Language Class Initialized
INFO - 2025-03-19 08:35:38 --> Language Class Initialized
INFO - 2025-03-19 08:35:38 --> Config Class Initialized
INFO - 2025-03-19 08:35:38 --> Loader Class Initialized
INFO - 2025-03-19 08:35:38 --> Helper loaded: url_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: file_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: html_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: form_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: text_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:35:38 --> Database Driver Class Initialized
INFO - 2025-03-19 08:35:38 --> Email Class Initialized
INFO - 2025-03-19 08:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:35:38 --> Form Validation Class Initialized
INFO - 2025-03-19 08:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:35:38 --> Pagination Class Initialized
INFO - 2025-03-19 08:35:38 --> Controller Class Initialized
DEBUG - 2025-03-19 08:35:38 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:35:38 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:35:38 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:35:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:35:38 --> Model Class Initialized
ERROR - 2025-03-19 08:35:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:35:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:35:38 --> Final output sent to browser
DEBUG - 2025-03-19 08:35:38 --> Total execution time: 0.1286
INFO - 2025-03-19 08:35:38 --> Config Class Initialized
INFO - 2025-03-19 08:35:38 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:35:38 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:35:38 --> Utf8 Class Initialized
INFO - 2025-03-19 08:35:38 --> URI Class Initialized
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:35:38 --> Router Class Initialized
INFO - 2025-03-19 08:35:38 --> Output Class Initialized
INFO - 2025-03-19 08:35:38 --> Security Class Initialized
DEBUG - 2025-03-19 08:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:35:38 --> Input Class Initialized
INFO - 2025-03-19 08:35:38 --> Language Class Initialized
INFO - 2025-03-19 08:35:38 --> Language Class Initialized
INFO - 2025-03-19 08:35:38 --> Config Class Initialized
INFO - 2025-03-19 08:35:38 --> Loader Class Initialized
INFO - 2025-03-19 08:35:38 --> Helper loaded: url_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: file_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: html_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: form_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: text_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:35:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:35:38 --> Database Driver Class Initialized
INFO - 2025-03-19 08:35:38 --> Email Class Initialized
INFO - 2025-03-19 08:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:35:38 --> Form Validation Class Initialized
INFO - 2025-03-19 08:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:35:38 --> Pagination Class Initialized
INFO - 2025-03-19 08:35:38 --> Controller Class Initialized
DEBUG - 2025-03-19 08:35:38 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:35:38 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:35:38 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:35:38 --> Model Class Initialized
INFO - 2025-03-19 08:35:38 --> Final output sent to browser
DEBUG - 2025-03-19 08:35:38 --> Total execution time: 0.0072
INFO - 2025-03-19 08:35:52 --> Config Class Initialized
INFO - 2025-03-19 08:35:52 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:35:52 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:35:52 --> Utf8 Class Initialized
INFO - 2025-03-19 08:35:52 --> URI Class Initialized
DEBUG - 2025-03-19 08:35:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:35:52 --> Router Class Initialized
INFO - 2025-03-19 08:35:52 --> Output Class Initialized
INFO - 2025-03-19 08:35:52 --> Security Class Initialized
DEBUG - 2025-03-19 08:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:35:52 --> Input Class Initialized
INFO - 2025-03-19 08:35:52 --> Language Class Initialized
INFO - 2025-03-19 08:35:52 --> Language Class Initialized
INFO - 2025-03-19 08:35:52 --> Config Class Initialized
INFO - 2025-03-19 08:35:52 --> Loader Class Initialized
INFO - 2025-03-19 08:35:52 --> Helper loaded: url_helper
INFO - 2025-03-19 08:35:52 --> Helper loaded: file_helper
INFO - 2025-03-19 08:35:52 --> Helper loaded: html_helper
INFO - 2025-03-19 08:35:52 --> Helper loaded: form_helper
INFO - 2025-03-19 08:35:52 --> Helper loaded: text_helper
INFO - 2025-03-19 08:35:52 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:35:52 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:35:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:35:52 --> Database Driver Class Initialized
INFO - 2025-03-19 08:35:52 --> Email Class Initialized
INFO - 2025-03-19 08:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:35:52 --> Form Validation Class Initialized
INFO - 2025-03-19 08:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:35:52 --> Pagination Class Initialized
INFO - 2025-03-19 08:35:52 --> Controller Class Initialized
DEBUG - 2025-03-19 08:35:52 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:35:52 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:35:52 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:35:52 --> Model Class Initialized
INFO - 2025-03-19 08:35:52 --> Final output sent to browser
DEBUG - 2025-03-19 08:35:52 --> Total execution time: 0.0079
INFO - 2025-03-19 08:35:53 --> Config Class Initialized
INFO - 2025-03-19 08:35:53 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:35:53 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:35:53 --> Utf8 Class Initialized
INFO - 2025-03-19 08:35:53 --> URI Class Initialized
DEBUG - 2025-03-19 08:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:35:53 --> Router Class Initialized
INFO - 2025-03-19 08:35:53 --> Output Class Initialized
INFO - 2025-03-19 08:35:53 --> Security Class Initialized
DEBUG - 2025-03-19 08:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:35:53 --> Input Class Initialized
INFO - 2025-03-19 08:35:53 --> Language Class Initialized
INFO - 2025-03-19 08:35:53 --> Language Class Initialized
INFO - 2025-03-19 08:35:53 --> Config Class Initialized
INFO - 2025-03-19 08:35:53 --> Loader Class Initialized
INFO - 2025-03-19 08:35:53 --> Helper loaded: url_helper
INFO - 2025-03-19 08:35:53 --> Helper loaded: file_helper
INFO - 2025-03-19 08:35:53 --> Helper loaded: html_helper
INFO - 2025-03-19 08:35:53 --> Helper loaded: form_helper
INFO - 2025-03-19 08:35:53 --> Helper loaded: text_helper
INFO - 2025-03-19 08:35:53 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:35:53 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:35:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:35:53 --> Database Driver Class Initialized
INFO - 2025-03-19 08:35:53 --> Email Class Initialized
INFO - 2025-03-19 08:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:35:53 --> Form Validation Class Initialized
INFO - 2025-03-19 08:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:35:53 --> Pagination Class Initialized
INFO - 2025-03-19 08:35:53 --> Controller Class Initialized
DEBUG - 2025-03-19 08:35:53 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:35:53 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:35:53 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:35:53 --> Model Class Initialized
INFO - 2025-03-19 08:35:53 --> Final output sent to browser
DEBUG - 2025-03-19 08:35:53 --> Total execution time: 0.0069
INFO - 2025-03-19 08:35:54 --> Config Class Initialized
INFO - 2025-03-19 08:35:54 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:35:54 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:35:54 --> Utf8 Class Initialized
INFO - 2025-03-19 08:35:54 --> URI Class Initialized
DEBUG - 2025-03-19 08:35:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:35:54 --> Router Class Initialized
INFO - 2025-03-19 08:35:54 --> Output Class Initialized
INFO - 2025-03-19 08:35:54 --> Security Class Initialized
DEBUG - 2025-03-19 08:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:35:54 --> Input Class Initialized
INFO - 2025-03-19 08:35:54 --> Language Class Initialized
INFO - 2025-03-19 08:35:54 --> Language Class Initialized
INFO - 2025-03-19 08:35:54 --> Config Class Initialized
INFO - 2025-03-19 08:35:54 --> Loader Class Initialized
INFO - 2025-03-19 08:35:54 --> Helper loaded: url_helper
INFO - 2025-03-19 08:35:54 --> Helper loaded: file_helper
INFO - 2025-03-19 08:35:54 --> Helper loaded: html_helper
INFO - 2025-03-19 08:35:54 --> Helper loaded: form_helper
INFO - 2025-03-19 08:35:54 --> Helper loaded: text_helper
INFO - 2025-03-19 08:35:54 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:35:54 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:35:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:35:54 --> Database Driver Class Initialized
INFO - 2025-03-19 08:35:54 --> Email Class Initialized
INFO - 2025-03-19 08:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:35:54 --> Form Validation Class Initialized
INFO - 2025-03-19 08:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:35:54 --> Pagination Class Initialized
INFO - 2025-03-19 08:35:54 --> Controller Class Initialized
DEBUG - 2025-03-19 08:35:54 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:35:54 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:35:54 --> Model Class Initialized
DEBUG - 2025-03-19 08:35:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:35:54 --> Model Class Initialized
INFO - 2025-03-19 08:35:54 --> Final output sent to browser
DEBUG - 2025-03-19 08:35:54 --> Total execution time: 0.0053
INFO - 2025-03-19 08:36:36 --> Config Class Initialized
INFO - 2025-03-19 08:36:36 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:36:36 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:36:36 --> Utf8 Class Initialized
INFO - 2025-03-19 08:36:36 --> URI Class Initialized
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:36:36 --> Router Class Initialized
INFO - 2025-03-19 08:36:36 --> Output Class Initialized
INFO - 2025-03-19 08:36:36 --> Security Class Initialized
DEBUG - 2025-03-19 08:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:36:36 --> Input Class Initialized
INFO - 2025-03-19 08:36:36 --> Language Class Initialized
INFO - 2025-03-19 08:36:36 --> Language Class Initialized
INFO - 2025-03-19 08:36:36 --> Config Class Initialized
INFO - 2025-03-19 08:36:36 --> Loader Class Initialized
INFO - 2025-03-19 08:36:36 --> Helper loaded: url_helper
INFO - 2025-03-19 08:36:36 --> Helper loaded: file_helper
INFO - 2025-03-19 08:36:36 --> Helper loaded: html_helper
INFO - 2025-03-19 08:36:36 --> Helper loaded: form_helper
INFO - 2025-03-19 08:36:36 --> Helper loaded: text_helper
INFO - 2025-03-19 08:36:36 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:36:36 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:36:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:36:36 --> Database Driver Class Initialized
INFO - 2025-03-19 08:36:36 --> Email Class Initialized
INFO - 2025-03-19 08:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:36:36 --> Form Validation Class Initialized
INFO - 2025-03-19 08:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:36:36 --> Pagination Class Initialized
INFO - 2025-03-19 08:36:36 --> Controller Class Initialized
DEBUG - 2025-03-19 08:36:36 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:36:36 --> Model Class Initialized
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:36:36 --> Model Class Initialized
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:36:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:36:36 --> Model Class Initialized
ERROR - 2025-03-19 08:36:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:36:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:36:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:36:36 --> Final output sent to browser
DEBUG - 2025-03-19 08:36:36 --> Total execution time: 0.1230
INFO - 2025-03-19 08:36:37 --> Config Class Initialized
INFO - 2025-03-19 08:36:37 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:36:37 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:36:37 --> Utf8 Class Initialized
INFO - 2025-03-19 08:36:37 --> URI Class Initialized
DEBUG - 2025-03-19 08:36:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:36:37 --> Router Class Initialized
INFO - 2025-03-19 08:36:37 --> Output Class Initialized
INFO - 2025-03-19 08:36:37 --> Security Class Initialized
DEBUG - 2025-03-19 08:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:36:37 --> Input Class Initialized
INFO - 2025-03-19 08:36:37 --> Language Class Initialized
INFO - 2025-03-19 08:36:37 --> Language Class Initialized
INFO - 2025-03-19 08:36:37 --> Config Class Initialized
INFO - 2025-03-19 08:36:37 --> Loader Class Initialized
INFO - 2025-03-19 08:36:37 --> Helper loaded: url_helper
INFO - 2025-03-19 08:36:37 --> Helper loaded: file_helper
INFO - 2025-03-19 08:36:37 --> Helper loaded: html_helper
INFO - 2025-03-19 08:36:37 --> Helper loaded: form_helper
INFO - 2025-03-19 08:36:37 --> Helper loaded: text_helper
INFO - 2025-03-19 08:36:37 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:36:37 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:36:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:36:37 --> Database Driver Class Initialized
INFO - 2025-03-19 08:36:37 --> Email Class Initialized
INFO - 2025-03-19 08:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:36:37 --> Form Validation Class Initialized
INFO - 2025-03-19 08:36:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:36:37 --> Pagination Class Initialized
INFO - 2025-03-19 08:36:37 --> Controller Class Initialized
DEBUG - 2025-03-19 08:36:37 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:36:37 --> Model Class Initialized
DEBUG - 2025-03-19 08:36:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:36:37 --> Model Class Initialized
DEBUG - 2025-03-19 08:36:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:36:37 --> Model Class Initialized
INFO - 2025-03-19 08:36:37 --> Final output sent to browser
DEBUG - 2025-03-19 08:36:37 --> Total execution time: 0.0071
INFO - 2025-03-19 08:37:23 --> Config Class Initialized
INFO - 2025-03-19 08:37:23 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:37:23 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:37:23 --> Utf8 Class Initialized
INFO - 2025-03-19 08:37:23 --> URI Class Initialized
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:37:23 --> Router Class Initialized
INFO - 2025-03-19 08:37:23 --> Output Class Initialized
INFO - 2025-03-19 08:37:23 --> Security Class Initialized
DEBUG - 2025-03-19 08:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:37:23 --> Input Class Initialized
INFO - 2025-03-19 08:37:23 --> Language Class Initialized
INFO - 2025-03-19 08:37:23 --> Language Class Initialized
INFO - 2025-03-19 08:37:23 --> Config Class Initialized
INFO - 2025-03-19 08:37:23 --> Loader Class Initialized
INFO - 2025-03-19 08:37:23 --> Helper loaded: url_helper
INFO - 2025-03-19 08:37:23 --> Helper loaded: file_helper
INFO - 2025-03-19 08:37:23 --> Helper loaded: html_helper
INFO - 2025-03-19 08:37:23 --> Helper loaded: form_helper
INFO - 2025-03-19 08:37:23 --> Helper loaded: text_helper
INFO - 2025-03-19 08:37:23 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:37:23 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:37:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:37:23 --> Database Driver Class Initialized
INFO - 2025-03-19 08:37:23 --> Email Class Initialized
INFO - 2025-03-19 08:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:37:23 --> Form Validation Class Initialized
INFO - 2025-03-19 08:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:37:23 --> Pagination Class Initialized
INFO - 2025-03-19 08:37:23 --> Controller Class Initialized
DEBUG - 2025-03-19 08:37:23 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:37:23 --> Model Class Initialized
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:37:23 --> Model Class Initialized
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:37:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:37:23 --> Model Class Initialized
ERROR - 2025-03-19 08:37:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:37:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:37:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:37:23 --> Final output sent to browser
DEBUG - 2025-03-19 08:37:23 --> Total execution time: 0.1357
INFO - 2025-03-19 08:37:24 --> Config Class Initialized
INFO - 2025-03-19 08:37:24 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:37:24 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:37:24 --> Utf8 Class Initialized
INFO - 2025-03-19 08:37:24 --> URI Class Initialized
DEBUG - 2025-03-19 08:37:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:37:24 --> Router Class Initialized
INFO - 2025-03-19 08:37:24 --> Output Class Initialized
INFO - 2025-03-19 08:37:24 --> Security Class Initialized
DEBUG - 2025-03-19 08:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:37:24 --> Input Class Initialized
INFO - 2025-03-19 08:37:24 --> Language Class Initialized
INFO - 2025-03-19 08:37:24 --> Language Class Initialized
INFO - 2025-03-19 08:37:24 --> Config Class Initialized
INFO - 2025-03-19 08:37:24 --> Loader Class Initialized
INFO - 2025-03-19 08:37:24 --> Helper loaded: url_helper
INFO - 2025-03-19 08:37:24 --> Helper loaded: file_helper
INFO - 2025-03-19 08:37:24 --> Helper loaded: html_helper
INFO - 2025-03-19 08:37:24 --> Helper loaded: form_helper
INFO - 2025-03-19 08:37:24 --> Helper loaded: text_helper
INFO - 2025-03-19 08:37:24 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:37:24 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:37:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:37:24 --> Database Driver Class Initialized
INFO - 2025-03-19 08:37:24 --> Email Class Initialized
INFO - 2025-03-19 08:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:37:24 --> Form Validation Class Initialized
INFO - 2025-03-19 08:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:37:24 --> Pagination Class Initialized
INFO - 2025-03-19 08:37:24 --> Controller Class Initialized
DEBUG - 2025-03-19 08:37:24 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:37:24 --> Model Class Initialized
DEBUG - 2025-03-19 08:37:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:37:24 --> Model Class Initialized
DEBUG - 2025-03-19 08:37:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:37:24 --> Model Class Initialized
INFO - 2025-03-19 08:37:24 --> Final output sent to browser
DEBUG - 2025-03-19 08:37:24 --> Total execution time: 0.0108
INFO - 2025-03-19 08:39:50 --> Config Class Initialized
INFO - 2025-03-19 08:39:50 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:39:50 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:39:50 --> Utf8 Class Initialized
INFO - 2025-03-19 08:39:50 --> URI Class Initialized
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:39:50 --> Router Class Initialized
INFO - 2025-03-19 08:39:50 --> Output Class Initialized
INFO - 2025-03-19 08:39:50 --> Security Class Initialized
DEBUG - 2025-03-19 08:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:39:50 --> Input Class Initialized
INFO - 2025-03-19 08:39:50 --> Language Class Initialized
INFO - 2025-03-19 08:39:50 --> Language Class Initialized
INFO - 2025-03-19 08:39:50 --> Config Class Initialized
INFO - 2025-03-19 08:39:50 --> Loader Class Initialized
INFO - 2025-03-19 08:39:50 --> Helper loaded: url_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: file_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: html_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: form_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: text_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:39:50 --> Database Driver Class Initialized
INFO - 2025-03-19 08:39:50 --> Email Class Initialized
INFO - 2025-03-19 08:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:39:50 --> Form Validation Class Initialized
INFO - 2025-03-19 08:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:39:50 --> Pagination Class Initialized
INFO - 2025-03-19 08:39:50 --> Controller Class Initialized
DEBUG - 2025-03-19 08:39:50 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:39:50 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:39:50 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:39:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:39:50 --> Model Class Initialized
ERROR - 2025-03-19 08:39:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:39:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:39:50 --> Final output sent to browser
DEBUG - 2025-03-19 08:39:50 --> Total execution time: 0.1338
INFO - 2025-03-19 08:39:50 --> Config Class Initialized
INFO - 2025-03-19 08:39:50 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:39:50 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:39:50 --> Utf8 Class Initialized
INFO - 2025-03-19 08:39:50 --> URI Class Initialized
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:39:50 --> Router Class Initialized
INFO - 2025-03-19 08:39:50 --> Output Class Initialized
INFO - 2025-03-19 08:39:50 --> Security Class Initialized
DEBUG - 2025-03-19 08:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:39:50 --> Input Class Initialized
INFO - 2025-03-19 08:39:50 --> Language Class Initialized
INFO - 2025-03-19 08:39:50 --> Language Class Initialized
INFO - 2025-03-19 08:39:50 --> Config Class Initialized
INFO - 2025-03-19 08:39:50 --> Loader Class Initialized
INFO - 2025-03-19 08:39:50 --> Helper loaded: url_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: file_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: html_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: form_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: text_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:39:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:39:50 --> Database Driver Class Initialized
INFO - 2025-03-19 08:39:50 --> Email Class Initialized
INFO - 2025-03-19 08:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:39:50 --> Form Validation Class Initialized
INFO - 2025-03-19 08:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:39:50 --> Pagination Class Initialized
INFO - 2025-03-19 08:39:50 --> Controller Class Initialized
DEBUG - 2025-03-19 08:39:50 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:39:50 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:39:50 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:39:50 --> Model Class Initialized
INFO - 2025-03-19 08:39:50 --> Final output sent to browser
DEBUG - 2025-03-19 08:39:50 --> Total execution time: 0.0099
INFO - 2025-03-19 08:39:51 --> Config Class Initialized
INFO - 2025-03-19 08:39:51 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:39:51 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:39:51 --> Utf8 Class Initialized
INFO - 2025-03-19 08:39:51 --> URI Class Initialized
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:39:51 --> Router Class Initialized
INFO - 2025-03-19 08:39:51 --> Output Class Initialized
INFO - 2025-03-19 08:39:51 --> Security Class Initialized
DEBUG - 2025-03-19 08:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:39:51 --> Input Class Initialized
INFO - 2025-03-19 08:39:51 --> Language Class Initialized
INFO - 2025-03-19 08:39:51 --> Language Class Initialized
INFO - 2025-03-19 08:39:51 --> Config Class Initialized
INFO - 2025-03-19 08:39:51 --> Loader Class Initialized
INFO - 2025-03-19 08:39:51 --> Helper loaded: url_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: file_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: html_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: form_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: text_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:39:51 --> Database Driver Class Initialized
INFO - 2025-03-19 08:39:51 --> Email Class Initialized
INFO - 2025-03-19 08:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:39:51 --> Form Validation Class Initialized
INFO - 2025-03-19 08:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:39:51 --> Pagination Class Initialized
INFO - 2025-03-19 08:39:51 --> Controller Class Initialized
DEBUG - 2025-03-19 08:39:51 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:39:51 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:39:51 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:39:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:39:51 --> Model Class Initialized
ERROR - 2025-03-19 08:39:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:39:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:39:51 --> Final output sent to browser
DEBUG - 2025-03-19 08:39:51 --> Total execution time: 0.1255
INFO - 2025-03-19 08:39:51 --> Config Class Initialized
INFO - 2025-03-19 08:39:51 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:39:51 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:39:51 --> Utf8 Class Initialized
INFO - 2025-03-19 08:39:51 --> URI Class Initialized
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:39:51 --> Router Class Initialized
INFO - 2025-03-19 08:39:51 --> Output Class Initialized
INFO - 2025-03-19 08:39:51 --> Security Class Initialized
DEBUG - 2025-03-19 08:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:39:51 --> Input Class Initialized
INFO - 2025-03-19 08:39:51 --> Language Class Initialized
INFO - 2025-03-19 08:39:51 --> Language Class Initialized
INFO - 2025-03-19 08:39:51 --> Config Class Initialized
INFO - 2025-03-19 08:39:51 --> Loader Class Initialized
INFO - 2025-03-19 08:39:51 --> Helper loaded: url_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: file_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: html_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: form_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: text_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:39:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:39:51 --> Database Driver Class Initialized
INFO - 2025-03-19 08:39:51 --> Email Class Initialized
INFO - 2025-03-19 08:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:39:51 --> Form Validation Class Initialized
INFO - 2025-03-19 08:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:39:51 --> Pagination Class Initialized
INFO - 2025-03-19 08:39:51 --> Controller Class Initialized
DEBUG - 2025-03-19 08:39:51 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:39:51 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:39:51 --> Model Class Initialized
DEBUG - 2025-03-19 08:39:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:39:51 --> Model Class Initialized
INFO - 2025-03-19 08:39:51 --> Final output sent to browser
DEBUG - 2025-03-19 08:39:51 --> Total execution time: 0.0098
INFO - 2025-03-19 08:40:00 --> Config Class Initialized
INFO - 2025-03-19 08:40:00 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:40:00 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:40:00 --> Utf8 Class Initialized
INFO - 2025-03-19 08:40:00 --> URI Class Initialized
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:40:00 --> Router Class Initialized
INFO - 2025-03-19 08:40:00 --> Output Class Initialized
INFO - 2025-03-19 08:40:00 --> Security Class Initialized
DEBUG - 2025-03-19 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:40:00 --> Input Class Initialized
INFO - 2025-03-19 08:40:00 --> Language Class Initialized
INFO - 2025-03-19 08:40:00 --> Language Class Initialized
INFO - 2025-03-19 08:40:00 --> Config Class Initialized
INFO - 2025-03-19 08:40:00 --> Loader Class Initialized
INFO - 2025-03-19 08:40:00 --> Helper loaded: url_helper
INFO - 2025-03-19 08:40:00 --> Helper loaded: file_helper
INFO - 2025-03-19 08:40:00 --> Helper loaded: html_helper
INFO - 2025-03-19 08:40:00 --> Helper loaded: form_helper
INFO - 2025-03-19 08:40:00 --> Helper loaded: text_helper
INFO - 2025-03-19 08:40:00 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:40:00 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:40:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:40:00 --> Database Driver Class Initialized
INFO - 2025-03-19 08:40:00 --> Email Class Initialized
INFO - 2025-03-19 08:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:40:00 --> Form Validation Class Initialized
INFO - 2025-03-19 08:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:40:00 --> Pagination Class Initialized
INFO - 2025-03-19 08:40:00 --> Controller Class Initialized
DEBUG - 2025-03-19 08:40:00 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:40:00 --> Model Class Initialized
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:40:00 --> Model Class Initialized
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:40:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:40:00 --> Model Class Initialized
ERROR - 2025-03-19 08:40:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:40:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:40:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:40:00 --> Final output sent to browser
DEBUG - 2025-03-19 08:40:00 --> Total execution time: 0.1079
INFO - 2025-03-19 08:40:01 --> Config Class Initialized
INFO - 2025-03-19 08:40:01 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:40:01 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:40:01 --> Utf8 Class Initialized
INFO - 2025-03-19 08:40:01 --> URI Class Initialized
DEBUG - 2025-03-19 08:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:40:01 --> Router Class Initialized
INFO - 2025-03-19 08:40:01 --> Output Class Initialized
INFO - 2025-03-19 08:40:01 --> Security Class Initialized
DEBUG - 2025-03-19 08:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:40:01 --> Input Class Initialized
INFO - 2025-03-19 08:40:01 --> Language Class Initialized
INFO - 2025-03-19 08:40:01 --> Language Class Initialized
INFO - 2025-03-19 08:40:01 --> Config Class Initialized
INFO - 2025-03-19 08:40:01 --> Loader Class Initialized
INFO - 2025-03-19 08:40:01 --> Helper loaded: url_helper
INFO - 2025-03-19 08:40:01 --> Helper loaded: file_helper
INFO - 2025-03-19 08:40:01 --> Helper loaded: html_helper
INFO - 2025-03-19 08:40:01 --> Helper loaded: form_helper
INFO - 2025-03-19 08:40:01 --> Helper loaded: text_helper
INFO - 2025-03-19 08:40:01 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:40:01 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:40:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:40:01 --> Database Driver Class Initialized
INFO - 2025-03-19 08:40:01 --> Email Class Initialized
INFO - 2025-03-19 08:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:40:01 --> Form Validation Class Initialized
INFO - 2025-03-19 08:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:40:01 --> Pagination Class Initialized
INFO - 2025-03-19 08:40:01 --> Controller Class Initialized
DEBUG - 2025-03-19 08:40:01 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:40:01 --> Model Class Initialized
DEBUG - 2025-03-19 08:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:40:01 --> Model Class Initialized
DEBUG - 2025-03-19 08:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:40:01 --> Model Class Initialized
INFO - 2025-03-19 08:40:01 --> Final output sent to browser
DEBUG - 2025-03-19 08:40:01 --> Total execution time: 0.0121
INFO - 2025-03-19 08:42:04 --> Config Class Initialized
INFO - 2025-03-19 08:42:04 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:42:04 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:42:04 --> Utf8 Class Initialized
INFO - 2025-03-19 08:42:04 --> URI Class Initialized
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:42:04 --> Router Class Initialized
INFO - 2025-03-19 08:42:04 --> Output Class Initialized
INFO - 2025-03-19 08:42:04 --> Security Class Initialized
DEBUG - 2025-03-19 08:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:42:04 --> Input Class Initialized
INFO - 2025-03-19 08:42:04 --> Language Class Initialized
INFO - 2025-03-19 08:42:04 --> Language Class Initialized
INFO - 2025-03-19 08:42:04 --> Config Class Initialized
INFO - 2025-03-19 08:42:04 --> Loader Class Initialized
INFO - 2025-03-19 08:42:04 --> Helper loaded: url_helper
INFO - 2025-03-19 08:42:04 --> Helper loaded: file_helper
INFO - 2025-03-19 08:42:04 --> Helper loaded: html_helper
INFO - 2025-03-19 08:42:04 --> Helper loaded: form_helper
INFO - 2025-03-19 08:42:04 --> Helper loaded: text_helper
INFO - 2025-03-19 08:42:04 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:42:04 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:42:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:42:04 --> Database Driver Class Initialized
INFO - 2025-03-19 08:42:04 --> Email Class Initialized
INFO - 2025-03-19 08:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:42:04 --> Form Validation Class Initialized
INFO - 2025-03-19 08:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:42:04 --> Pagination Class Initialized
INFO - 2025-03-19 08:42:04 --> Controller Class Initialized
DEBUG - 2025-03-19 08:42:04 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:42:04 --> Model Class Initialized
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:42:04 --> Model Class Initialized
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:42:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:42:04 --> Model Class Initialized
ERROR - 2025-03-19 08:42:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:42:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:42:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:42:04 --> Final output sent to browser
DEBUG - 2025-03-19 08:42:04 --> Total execution time: 0.1319
INFO - 2025-03-19 08:42:05 --> Config Class Initialized
INFO - 2025-03-19 08:42:05 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:42:05 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:42:05 --> Utf8 Class Initialized
INFO - 2025-03-19 08:42:05 --> URI Class Initialized
DEBUG - 2025-03-19 08:42:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:42:05 --> Router Class Initialized
INFO - 2025-03-19 08:42:05 --> Output Class Initialized
INFO - 2025-03-19 08:42:05 --> Security Class Initialized
DEBUG - 2025-03-19 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:42:05 --> Input Class Initialized
INFO - 2025-03-19 08:42:05 --> Language Class Initialized
INFO - 2025-03-19 08:42:05 --> Language Class Initialized
INFO - 2025-03-19 08:42:05 --> Config Class Initialized
INFO - 2025-03-19 08:42:05 --> Loader Class Initialized
INFO - 2025-03-19 08:42:05 --> Helper loaded: url_helper
INFO - 2025-03-19 08:42:05 --> Helper loaded: file_helper
INFO - 2025-03-19 08:42:05 --> Helper loaded: html_helper
INFO - 2025-03-19 08:42:05 --> Helper loaded: form_helper
INFO - 2025-03-19 08:42:05 --> Helper loaded: text_helper
INFO - 2025-03-19 08:42:05 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:42:05 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:42:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:42:05 --> Database Driver Class Initialized
INFO - 2025-03-19 08:42:05 --> Email Class Initialized
INFO - 2025-03-19 08:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:42:05 --> Form Validation Class Initialized
INFO - 2025-03-19 08:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:42:05 --> Pagination Class Initialized
INFO - 2025-03-19 08:42:05 --> Controller Class Initialized
DEBUG - 2025-03-19 08:42:05 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:42:05 --> Model Class Initialized
DEBUG - 2025-03-19 08:42:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:42:05 --> Model Class Initialized
DEBUG - 2025-03-19 08:42:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:42:05 --> Model Class Initialized
INFO - 2025-03-19 08:42:05 --> Final output sent to browser
DEBUG - 2025-03-19 08:42:05 --> Total execution time: 0.0077
INFO - 2025-03-19 08:48:30 --> Config Class Initialized
INFO - 2025-03-19 08:48:30 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:48:30 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:48:30 --> Utf8 Class Initialized
INFO - 2025-03-19 08:48:30 --> URI Class Initialized
DEBUG - 2025-03-19 08:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:48:30 --> Router Class Initialized
INFO - 2025-03-19 08:48:30 --> Output Class Initialized
INFO - 2025-03-19 08:48:30 --> Security Class Initialized
DEBUG - 2025-03-19 08:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:48:30 --> Input Class Initialized
INFO - 2025-03-19 08:48:30 --> Language Class Initialized
INFO - 2025-03-19 08:48:30 --> Language Class Initialized
INFO - 2025-03-19 08:48:30 --> Config Class Initialized
INFO - 2025-03-19 08:48:30 --> Loader Class Initialized
INFO - 2025-03-19 08:48:30 --> Helper loaded: url_helper
INFO - 2025-03-19 08:48:30 --> Helper loaded: file_helper
INFO - 2025-03-19 08:48:30 --> Helper loaded: html_helper
INFO - 2025-03-19 08:48:30 --> Helper loaded: form_helper
INFO - 2025-03-19 08:48:30 --> Helper loaded: text_helper
INFO - 2025-03-19 08:48:30 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:48:30 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:48:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:48:30 --> Database Driver Class Initialized
INFO - 2025-03-19 08:48:30 --> Email Class Initialized
INFO - 2025-03-19 08:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:48:30 --> Form Validation Class Initialized
INFO - 2025-03-19 08:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:48:30 --> Pagination Class Initialized
INFO - 2025-03-19 08:48:30 --> Controller Class Initialized
DEBUG - 2025-03-19 08:48:30 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:48:30 --> Model Class Initialized
DEBUG - 2025-03-19 08:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:48:30 --> Model Class Initialized
DEBUG - 2025-03-19 08:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:48:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:48:30 --> Model Class Initialized
ERROR - 2025-03-19 08:48:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:48:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:48:31 --> Final output sent to browser
DEBUG - 2025-03-19 08:48:31 --> Total execution time: 0.3337
INFO - 2025-03-19 08:48:31 --> Config Class Initialized
INFO - 2025-03-19 08:48:31 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:48:31 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:48:31 --> Utf8 Class Initialized
INFO - 2025-03-19 08:48:31 --> URI Class Initialized
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:48:31 --> Router Class Initialized
INFO - 2025-03-19 08:48:31 --> Output Class Initialized
INFO - 2025-03-19 08:48:31 --> Security Class Initialized
DEBUG - 2025-03-19 08:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:48:31 --> Input Class Initialized
INFO - 2025-03-19 08:48:31 --> Language Class Initialized
INFO - 2025-03-19 08:48:31 --> Language Class Initialized
INFO - 2025-03-19 08:48:31 --> Config Class Initialized
INFO - 2025-03-19 08:48:31 --> Loader Class Initialized
INFO - 2025-03-19 08:48:31 --> Helper loaded: url_helper
INFO - 2025-03-19 08:48:31 --> Helper loaded: file_helper
INFO - 2025-03-19 08:48:31 --> Helper loaded: html_helper
INFO - 2025-03-19 08:48:31 --> Helper loaded: form_helper
INFO - 2025-03-19 08:48:31 --> Helper loaded: text_helper
INFO - 2025-03-19 08:48:31 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:48:31 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:48:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:48:31 --> Database Driver Class Initialized
INFO - 2025-03-19 08:48:31 --> Email Class Initialized
INFO - 2025-03-19 08:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:48:31 --> Form Validation Class Initialized
INFO - 2025-03-19 08:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:48:31 --> Pagination Class Initialized
INFO - 2025-03-19 08:48:31 --> Controller Class Initialized
DEBUG - 2025-03-19 08:48:31 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:48:31 --> Model Class Initialized
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:48:31 --> Model Class Initialized
DEBUG - 2025-03-19 08:48:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:48:31 --> Model Class Initialized
INFO - 2025-03-19 08:48:31 --> Final output sent to browser
DEBUG - 2025-03-19 08:48:31 --> Total execution time: 0.0074
INFO - 2025-03-19 08:48:43 --> Config Class Initialized
INFO - 2025-03-19 08:48:43 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:48:43 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:48:43 --> Utf8 Class Initialized
INFO - 2025-03-19 08:48:43 --> URI Class Initialized
DEBUG - 2025-03-19 08:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:48:43 --> Router Class Initialized
INFO - 2025-03-19 08:48:43 --> Output Class Initialized
INFO - 2025-03-19 08:48:43 --> Security Class Initialized
DEBUG - 2025-03-19 08:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:48:43 --> Input Class Initialized
INFO - 2025-03-19 08:48:43 --> Language Class Initialized
INFO - 2025-03-19 08:48:43 --> Language Class Initialized
INFO - 2025-03-19 08:48:43 --> Config Class Initialized
INFO - 2025-03-19 08:48:43 --> Loader Class Initialized
INFO - 2025-03-19 08:48:43 --> Helper loaded: url_helper
INFO - 2025-03-19 08:48:43 --> Helper loaded: file_helper
INFO - 2025-03-19 08:48:43 --> Helper loaded: html_helper
INFO - 2025-03-19 08:48:43 --> Helper loaded: form_helper
INFO - 2025-03-19 08:48:43 --> Helper loaded: text_helper
INFO - 2025-03-19 08:48:43 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:48:43 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:48:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:48:43 --> Database Driver Class Initialized
INFO - 2025-03-19 08:48:43 --> Email Class Initialized
INFO - 2025-03-19 08:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:48:43 --> Form Validation Class Initialized
INFO - 2025-03-19 08:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:48:43 --> Pagination Class Initialized
INFO - 2025-03-19 08:48:43 --> Controller Class Initialized
DEBUG - 2025-03-19 08:48:43 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:48:43 --> Model Class Initialized
DEBUG - 2025-03-19 08:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:48:43 --> Model Class Initialized
DEBUG - 2025-03-19 08:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:48:43 --> Model Class Initialized
INFO - 2025-03-19 08:48:43 --> Final output sent to browser
DEBUG - 2025-03-19 08:48:43 --> Total execution time: 0.0096
INFO - 2025-03-19 08:49:15 --> Config Class Initialized
INFO - 2025-03-19 08:49:15 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:49:15 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:49:15 --> Utf8 Class Initialized
INFO - 2025-03-19 08:49:15 --> URI Class Initialized
DEBUG - 2025-03-19 08:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:49:15 --> Router Class Initialized
INFO - 2025-03-19 08:49:15 --> Output Class Initialized
INFO - 2025-03-19 08:49:15 --> Security Class Initialized
DEBUG - 2025-03-19 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:49:15 --> Input Class Initialized
INFO - 2025-03-19 08:49:15 --> Language Class Initialized
INFO - 2025-03-19 08:49:15 --> Language Class Initialized
INFO - 2025-03-19 08:49:15 --> Config Class Initialized
INFO - 2025-03-19 08:49:15 --> Loader Class Initialized
INFO - 2025-03-19 08:49:15 --> Helper loaded: url_helper
INFO - 2025-03-19 08:49:15 --> Helper loaded: file_helper
INFO - 2025-03-19 08:49:15 --> Helper loaded: html_helper
INFO - 2025-03-19 08:49:15 --> Helper loaded: form_helper
INFO - 2025-03-19 08:49:15 --> Helper loaded: text_helper
INFO - 2025-03-19 08:49:15 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:49:15 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:49:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:49:15 --> Database Driver Class Initialized
INFO - 2025-03-19 08:49:15 --> Email Class Initialized
INFO - 2025-03-19 08:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:49:15 --> Form Validation Class Initialized
INFO - 2025-03-19 08:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:49:15 --> Pagination Class Initialized
INFO - 2025-03-19 08:49:15 --> Controller Class Initialized
DEBUG - 2025-03-19 08:49:15 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:49:15 --> Model Class Initialized
DEBUG - 2025-03-19 08:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:49:15 --> Model Class Initialized
DEBUG - 2025-03-19 08:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:49:15 --> Model Class Initialized
INFO - 2025-03-19 08:49:15 --> Final output sent to browser
DEBUG - 2025-03-19 08:49:15 --> Total execution time: 0.0082
INFO - 2025-03-19 08:54:00 --> Config Class Initialized
INFO - 2025-03-19 08:54:00 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:54:00 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:54:00 --> Utf8 Class Initialized
INFO - 2025-03-19 08:54:00 --> URI Class Initialized
DEBUG - 2025-03-19 08:54:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:54:00 --> Router Class Initialized
INFO - 2025-03-19 08:54:00 --> Output Class Initialized
INFO - 2025-03-19 08:54:00 --> Security Class Initialized
DEBUG - 2025-03-19 08:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:54:00 --> Input Class Initialized
INFO - 2025-03-19 08:54:00 --> Language Class Initialized
INFO - 2025-03-19 08:54:00 --> Language Class Initialized
INFO - 2025-03-19 08:54:00 --> Config Class Initialized
INFO - 2025-03-19 08:54:00 --> Loader Class Initialized
INFO - 2025-03-19 08:54:00 --> Helper loaded: url_helper
INFO - 2025-03-19 08:54:00 --> Helper loaded: file_helper
INFO - 2025-03-19 08:54:00 --> Helper loaded: html_helper
INFO - 2025-03-19 08:54:00 --> Helper loaded: form_helper
INFO - 2025-03-19 08:54:00 --> Helper loaded: text_helper
INFO - 2025-03-19 08:54:00 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:54:00 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:54:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:54:00 --> Database Driver Class Initialized
INFO - 2025-03-19 08:54:00 --> Email Class Initialized
INFO - 2025-03-19 08:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:54:00 --> Form Validation Class Initialized
INFO - 2025-03-19 08:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:54:00 --> Pagination Class Initialized
INFO - 2025-03-19 08:54:00 --> Controller Class Initialized
DEBUG - 2025-03-19 08:54:00 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:54:00 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:54:00 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:54:00 --> Model Class Initialized
INFO - 2025-03-19 08:54:00 --> Final output sent to browser
DEBUG - 2025-03-19 08:54:00 --> Total execution time: 0.0120
INFO - 2025-03-19 08:54:07 --> Config Class Initialized
INFO - 2025-03-19 08:54:07 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:54:07 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:54:07 --> Utf8 Class Initialized
INFO - 2025-03-19 08:54:07 --> URI Class Initialized
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:54:07 --> Router Class Initialized
INFO - 2025-03-19 08:54:07 --> Output Class Initialized
INFO - 2025-03-19 08:54:07 --> Security Class Initialized
DEBUG - 2025-03-19 08:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:54:07 --> Input Class Initialized
INFO - 2025-03-19 08:54:07 --> Language Class Initialized
INFO - 2025-03-19 08:54:07 --> Language Class Initialized
INFO - 2025-03-19 08:54:07 --> Config Class Initialized
INFO - 2025-03-19 08:54:07 --> Loader Class Initialized
INFO - 2025-03-19 08:54:07 --> Helper loaded: url_helper
INFO - 2025-03-19 08:54:07 --> Helper loaded: file_helper
INFO - 2025-03-19 08:54:07 --> Helper loaded: html_helper
INFO - 2025-03-19 08:54:07 --> Helper loaded: form_helper
INFO - 2025-03-19 08:54:07 --> Helper loaded: text_helper
INFO - 2025-03-19 08:54:07 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:54:07 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:54:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:54:07 --> Database Driver Class Initialized
INFO - 2025-03-19 08:54:07 --> Email Class Initialized
INFO - 2025-03-19 08:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:54:07 --> Form Validation Class Initialized
INFO - 2025-03-19 08:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:54:07 --> Pagination Class Initialized
INFO - 2025-03-19 08:54:07 --> Controller Class Initialized
DEBUG - 2025-03-19 08:54:07 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:54:07 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:54:07 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-19 08:54:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-19 08:54:07 --> Model Class Initialized
ERROR - 2025-03-19 08:54:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-19 08:54:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/sales_report.php
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-19 08:54:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-19 08:54:07 --> Final output sent to browser
DEBUG - 2025-03-19 08:54:07 --> Total execution time: 0.2070
INFO - 2025-03-19 08:54:08 --> Config Class Initialized
INFO - 2025-03-19 08:54:08 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:54:08 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:54:08 --> Utf8 Class Initialized
INFO - 2025-03-19 08:54:08 --> URI Class Initialized
DEBUG - 2025-03-19 08:54:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:54:08 --> Router Class Initialized
INFO - 2025-03-19 08:54:08 --> Output Class Initialized
INFO - 2025-03-19 08:54:08 --> Security Class Initialized
DEBUG - 2025-03-19 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:54:08 --> Input Class Initialized
INFO - 2025-03-19 08:54:08 --> Language Class Initialized
INFO - 2025-03-19 08:54:08 --> Language Class Initialized
INFO - 2025-03-19 08:54:08 --> Config Class Initialized
INFO - 2025-03-19 08:54:08 --> Loader Class Initialized
INFO - 2025-03-19 08:54:08 --> Helper loaded: url_helper
INFO - 2025-03-19 08:54:08 --> Helper loaded: file_helper
INFO - 2025-03-19 08:54:08 --> Helper loaded: html_helper
INFO - 2025-03-19 08:54:08 --> Helper loaded: form_helper
INFO - 2025-03-19 08:54:08 --> Helper loaded: text_helper
INFO - 2025-03-19 08:54:08 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:54:08 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:54:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:54:08 --> Database Driver Class Initialized
INFO - 2025-03-19 08:54:08 --> Email Class Initialized
INFO - 2025-03-19 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:54:08 --> Form Validation Class Initialized
INFO - 2025-03-19 08:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:54:08 --> Pagination Class Initialized
INFO - 2025-03-19 08:54:08 --> Controller Class Initialized
DEBUG - 2025-03-19 08:54:08 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:54:08 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:54:08 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:54:08 --> Model Class Initialized
INFO - 2025-03-19 08:54:08 --> Final output sent to browser
DEBUG - 2025-03-19 08:54:08 --> Total execution time: 0.0081
INFO - 2025-03-19 08:54:13 --> Config Class Initialized
INFO - 2025-03-19 08:54:13 --> Hooks Class Initialized
DEBUG - 2025-03-19 08:54:13 --> UTF-8 Support Enabled
INFO - 2025-03-19 08:54:13 --> Utf8 Class Initialized
INFO - 2025-03-19 08:54:13 --> URI Class Initialized
DEBUG - 2025-03-19 08:54:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-19 08:54:13 --> Router Class Initialized
INFO - 2025-03-19 08:54:13 --> Output Class Initialized
INFO - 2025-03-19 08:54:13 --> Security Class Initialized
DEBUG - 2025-03-19 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-19 08:54:13 --> Input Class Initialized
INFO - 2025-03-19 08:54:13 --> Language Class Initialized
INFO - 2025-03-19 08:54:13 --> Language Class Initialized
INFO - 2025-03-19 08:54:13 --> Config Class Initialized
INFO - 2025-03-19 08:54:13 --> Loader Class Initialized
INFO - 2025-03-19 08:54:13 --> Helper loaded: url_helper
INFO - 2025-03-19 08:54:13 --> Helper loaded: file_helper
INFO - 2025-03-19 08:54:13 --> Helper loaded: html_helper
INFO - 2025-03-19 08:54:13 --> Helper loaded: form_helper
INFO - 2025-03-19 08:54:13 --> Helper loaded: text_helper
INFO - 2025-03-19 08:54:13 --> Helper loaded: lang_helper
INFO - 2025-03-19 08:54:13 --> Helper loaded: directory_helper
INFO - 2025-03-19 08:54:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-19 08:54:13 --> Database Driver Class Initialized
INFO - 2025-03-19 08:54:13 --> Email Class Initialized
INFO - 2025-03-19 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-19 08:54:13 --> Form Validation Class Initialized
INFO - 2025-03-19 08:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-19 08:54:13 --> Pagination Class Initialized
INFO - 2025-03-19 08:54:13 --> Controller Class Initialized
DEBUG - 2025-03-19 08:54:13 --> Report MX_Controller Initialized
INFO - 2025-03-19 08:54:13 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-19 08:54:13 --> Model Class Initialized
DEBUG - 2025-03-19 08:54:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-19 08:54:13 --> Model Class Initialized
INFO - 2025-03-19 08:54:13 --> Final output sent to browser
DEBUG - 2025-03-19 08:54:13 --> Total execution time: 0.0138
