<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-21 00:17:16 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 00:17:16 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 00:17:16 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 00:17:16 --> Model Class Initialized
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 00:17:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
ERROR - 2025-03-21 00:17:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 00:17:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 00:17:30 --> Final output sent to browser
DEBUG - 2025-03-21 00:17:30 --> Total execution time: 0.1368
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-21 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 00:17:30 --> Model Class Initialized
INFO - 2025-03-21 00:17:30 --> Final output sent to browser
DEBUG - 2025-03-21 00:17:30 --> Total execution time: 0.0540
INFO - 2025-03-21 02:01:30 --> Model Class Initialized
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:01:30 --> Model Class Initialized
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:01:30 --> Model Class Initialized
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:01:30 --> Model Class Initialized
ERROR - 2025-03-21 02:01:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-21 02:01:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-21 02:01:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-21 02:01:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 02:01:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 02:01:30 --> Model Class Initialized
ERROR - 2025-03-21 02:01:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 02:01:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-21 02:01:30 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 02:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 02:01:30 --> Final output sent to browser
DEBUG - 2025-03-21 02:01:30 --> Total execution time: 0.1491
INFO - 2025-03-21 02:02:08 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:08 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:08 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:08 --> Model Class Initialized
ERROR - 2025-03-21 02:02:08 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-21 02:02:08 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-21 02:02:08 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-21 02:02:08 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 02:02:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 02:02:08 --> Model Class Initialized
ERROR - 2025-03-21 02:02:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 02:02:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-21 02:02:08 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 02:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 02:02:08 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:08 --> Total execution time: 0.0973
INFO - 2025-03-21 02:02:17 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:17 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:17 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:17 --> Model Class Initialized
INFO - 2025-03-21 02:02:17 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:17 --> Total execution time: 0.0064
INFO - 2025-03-21 02:02:18 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:18 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:18 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:18 --> Model Class Initialized
INFO - 2025-03-21 02:02:18 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:18 --> Total execution time: 0.0069
INFO - 2025-03-21 02:02:26 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:26 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:26 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:26 --> Model Class Initialized
INFO - 2025-03-21 02:02:26 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:26 --> Total execution time: 0.0077
INFO - 2025-03-21 02:02:28 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:28 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:28 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:28 --> Model Class Initialized
INFO - 2025-03-21 02:02:28 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:28 --> Total execution time: 0.0068
INFO - 2025-03-21 02:02:33 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:33 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:33 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:33 --> Model Class Initialized
INFO - 2025-03-21 02:02:33 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:33 --> Total execution time: 0.0050
INFO - 2025-03-21 02:02:34 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:34 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:34 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:34 --> Model Class Initialized
INFO - 2025-03-21 02:02:34 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:34 --> Total execution time: 0.0102
INFO - 2025-03-21 02:02:35 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:35 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:35 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:35 --> Model Class Initialized
INFO - 2025-03-21 02:02:35 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:35 --> Total execution time: 0.0149
INFO - 2025-03-21 02:02:37 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:37 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:37 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:37 --> Model Class Initialized
INFO - 2025-03-21 02:02:37 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:37 --> Total execution time: 0.0063
INFO - 2025-03-21 02:02:59 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:02:59 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:02:59 --> Model Class Initialized
DEBUG - 2025-03-21 02:02:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:02:59 --> Model Class Initialized
INFO - 2025-03-21 02:02:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-03-21 02:02:59 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 478
ERROR - 2025-03-21 02:02:59 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 479
DEBUG - 2025-03-21 02:02:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html_manual.php
INFO - 2025-03-21 02:02:59 --> Final output sent to browser
DEBUG - 2025-03-21 02:02:59 --> Total execution time: 0.1045
INFO - 2025-03-21 02:03:00 --> Model Class Initialized
DEBUG - 2025-03-21 02:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-21 02:03:00 --> Model Class Initialized
DEBUG - 2025-03-21 02:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 02:03:00 --> Model Class Initialized
DEBUG - 2025-03-21 02:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-21 02:03:00 --> Model Class Initialized
ERROR - 2025-03-21 02:03:00 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-21 02:03:00 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-21 02:03:00 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-21 02:03:00 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-21 02:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 02:03:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 02:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 02:03:00 --> Model Class Initialized
ERROR - 2025-03-21 02:03:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 02:03:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 02:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 02:03:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 02:03:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 02:03:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-21 02:03:01 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-21 02:03:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-21 02:03:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 02:03:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 02:03:01 --> Final output sent to browser
DEBUG - 2025-03-21 02:03:01 --> Total execution time: 0.1457
INFO - 2025-03-21 12:37:10 --> Config Class Initialized
INFO - 2025-03-21 12:37:10 --> Hooks Class Initialized
DEBUG - 2025-03-21 12:37:10 --> UTF-8 Support Enabled
INFO - 2025-03-21 12:37:10 --> Utf8 Class Initialized
INFO - 2025-03-21 12:37:10 --> URI Class Initialized
DEBUG - 2025-03-21 12:37:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-21 12:37:10 --> Router Class Initialized
INFO - 2025-03-21 12:37:10 --> Output Class Initialized
INFO - 2025-03-21 12:37:10 --> Security Class Initialized
DEBUG - 2025-03-21 12:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 12:37:10 --> Input Class Initialized
INFO - 2025-03-21 12:37:10 --> Language Class Initialized
INFO - 2025-03-21 12:37:10 --> Language Class Initialized
INFO - 2025-03-21 12:37:10 --> Config Class Initialized
INFO - 2025-03-21 12:37:10 --> Loader Class Initialized
INFO - 2025-03-21 12:37:10 --> Helper loaded: url_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: file_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: html_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: form_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: text_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: lang_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: directory_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 12:37:10 --> Database Driver Class Initialized
INFO - 2025-03-21 12:37:10 --> Email Class Initialized
INFO - 2025-03-21 12:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 12:37:10 --> Form Validation Class Initialized
INFO - 2025-03-21 12:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 12:37:10 --> Pagination Class Initialized
INFO - 2025-03-21 12:37:10 --> Controller Class Initialized
DEBUG - 2025-03-21 12:37:10 --> Report MX_Controller Initialized
INFO - 2025-03-21 12:37:10 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-21 12:37:10 --> Model Class Initialized
INFO - 2025-03-21 12:37:10 --> Config Class Initialized
INFO - 2025-03-21 12:37:10 --> Hooks Class Initialized
DEBUG - 2025-03-21 12:37:10 --> UTF-8 Support Enabled
INFO - 2025-03-21 12:37:10 --> Utf8 Class Initialized
INFO - 2025-03-21 12:37:10 --> URI Class Initialized
DEBUG - 2025-03-21 12:37:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-21 12:37:10 --> Router Class Initialized
INFO - 2025-03-21 12:37:10 --> Output Class Initialized
INFO - 2025-03-21 12:37:10 --> Security Class Initialized
DEBUG - 2025-03-21 12:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 12:37:10 --> Input Class Initialized
INFO - 2025-03-21 12:37:10 --> Language Class Initialized
INFO - 2025-03-21 12:37:10 --> Language Class Initialized
INFO - 2025-03-21 12:37:10 --> Config Class Initialized
INFO - 2025-03-21 12:37:10 --> Loader Class Initialized
INFO - 2025-03-21 12:37:10 --> Helper loaded: url_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: file_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: html_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: form_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: text_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: lang_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: directory_helper
INFO - 2025-03-21 12:37:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 12:37:10 --> Database Driver Class Initialized
INFO - 2025-03-21 12:37:10 --> Email Class Initialized
INFO - 2025-03-21 12:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 12:37:10 --> Form Validation Class Initialized
INFO - 2025-03-21 12:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 12:37:10 --> Pagination Class Initialized
INFO - 2025-03-21 12:37:10 --> Controller Class Initialized
DEBUG - 2025-03-21 12:37:10 --> Auth MX_Controller Initialized
INFO - 2025-03-21 12:37:10 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-21 12:37:10 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 12:37:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 12:37:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 12:37:10 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-21 12:37:10 --> Final output sent to browser
DEBUG - 2025-03-21 12:37:10 --> Total execution time: 0.0341
INFO - 2025-03-21 12:37:21 --> Config Class Initialized
INFO - 2025-03-21 12:37:21 --> Hooks Class Initialized
DEBUG - 2025-03-21 12:37:21 --> UTF-8 Support Enabled
INFO - 2025-03-21 12:37:21 --> Utf8 Class Initialized
INFO - 2025-03-21 12:37:21 --> URI Class Initialized
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-21 12:37:21 --> Router Class Initialized
INFO - 2025-03-21 12:37:21 --> Output Class Initialized
INFO - 2025-03-21 12:37:21 --> Security Class Initialized
DEBUG - 2025-03-21 12:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 12:37:21 --> Input Class Initialized
INFO - 2025-03-21 12:37:21 --> Language Class Initialized
INFO - 2025-03-21 12:37:21 --> Language Class Initialized
INFO - 2025-03-21 12:37:21 --> Config Class Initialized
INFO - 2025-03-21 12:37:21 --> Loader Class Initialized
INFO - 2025-03-21 12:37:21 --> Helper loaded: url_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: file_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: html_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: form_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: text_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: lang_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: directory_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 12:37:21 --> Database Driver Class Initialized
INFO - 2025-03-21 12:37:21 --> Email Class Initialized
INFO - 2025-03-21 12:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 12:37:21 --> Form Validation Class Initialized
INFO - 2025-03-21 12:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 12:37:21 --> Pagination Class Initialized
INFO - 2025-03-21 12:37:21 --> Controller Class Initialized
DEBUG - 2025-03-21 12:37:21 --> Auth MX_Controller Initialized
INFO - 2025-03-21 12:37:21 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-21 12:37:21 --> Model Class Initialized
INFO - 2025-03-21 12:37:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-21 12:37:21 --> Config Class Initialized
INFO - 2025-03-21 12:37:21 --> Hooks Class Initialized
DEBUG - 2025-03-21 12:37:21 --> UTF-8 Support Enabled
INFO - 2025-03-21 12:37:21 --> Utf8 Class Initialized
INFO - 2025-03-21 12:37:21 --> URI Class Initialized
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-21 12:37:21 --> Router Class Initialized
INFO - 2025-03-21 12:37:21 --> Output Class Initialized
INFO - 2025-03-21 12:37:21 --> Security Class Initialized
DEBUG - 2025-03-21 12:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 12:37:21 --> Input Class Initialized
INFO - 2025-03-21 12:37:21 --> Language Class Initialized
INFO - 2025-03-21 12:37:21 --> Language Class Initialized
INFO - 2025-03-21 12:37:21 --> Config Class Initialized
INFO - 2025-03-21 12:37:21 --> Loader Class Initialized
INFO - 2025-03-21 12:37:21 --> Helper loaded: url_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: file_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: html_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: form_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: text_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: lang_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: directory_helper
INFO - 2025-03-21 12:37:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 12:37:21 --> Database Driver Class Initialized
INFO - 2025-03-21 12:37:21 --> Email Class Initialized
INFO - 2025-03-21 12:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 12:37:21 --> Form Validation Class Initialized
INFO - 2025-03-21 12:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 12:37:21 --> Pagination Class Initialized
INFO - 2025-03-21 12:37:21 --> Controller Class Initialized
DEBUG - 2025-03-21 12:37:21 --> Home MX_Controller Initialized
INFO - 2025-03-21 12:37:21 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-21 12:37:21 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 12:37:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 12:37:21 --> Model Class Initialized
ERROR - 2025-03-21 12:37:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 12:37:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 12:37:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 12:37:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 12:37:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 12:37:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-21 12:37:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 12:37:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 12:37:22 --> Final output sent to browser
DEBUG - 2025-03-21 12:37:22 --> Total execution time: 0.6130
INFO - 2025-03-21 12:37:27 --> Config Class Initialized
INFO - 2025-03-21 12:37:27 --> Hooks Class Initialized
DEBUG - 2025-03-21 12:37:27 --> UTF-8 Support Enabled
INFO - 2025-03-21 12:37:27 --> Utf8 Class Initialized
INFO - 2025-03-21 12:37:27 --> URI Class Initialized
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-21 12:37:27 --> Router Class Initialized
INFO - 2025-03-21 12:37:27 --> Output Class Initialized
INFO - 2025-03-21 12:37:27 --> Security Class Initialized
DEBUG - 2025-03-21 12:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 12:37:27 --> Input Class Initialized
INFO - 2025-03-21 12:37:27 --> Language Class Initialized
INFO - 2025-03-21 12:37:27 --> Language Class Initialized
INFO - 2025-03-21 12:37:27 --> Config Class Initialized
INFO - 2025-03-21 12:37:27 --> Loader Class Initialized
INFO - 2025-03-21 12:37:27 --> Helper loaded: url_helper
INFO - 2025-03-21 12:37:27 --> Helper loaded: file_helper
INFO - 2025-03-21 12:37:27 --> Helper loaded: html_helper
INFO - 2025-03-21 12:37:27 --> Helper loaded: form_helper
INFO - 2025-03-21 12:37:27 --> Helper loaded: text_helper
INFO - 2025-03-21 12:37:27 --> Helper loaded: lang_helper
INFO - 2025-03-21 12:37:27 --> Helper loaded: directory_helper
INFO - 2025-03-21 12:37:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 12:37:27 --> Database Driver Class Initialized
INFO - 2025-03-21 12:37:27 --> Email Class Initialized
INFO - 2025-03-21 12:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 12:37:27 --> Form Validation Class Initialized
INFO - 2025-03-21 12:37:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 12:37:27 --> Pagination Class Initialized
INFO - 2025-03-21 12:37:27 --> Controller Class Initialized
DEBUG - 2025-03-21 12:37:27 --> Product MX_Controller Initialized
INFO - 2025-03-21 12:37:27 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-21 12:37:27 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-21 12:37:27 --> Model Class Initialized
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 12:37:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 12:37:27 --> Model Class Initialized
ERROR - 2025-03-21 12:37:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 12:37:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/unit_list.php
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 12:37:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 12:37:27 --> Final output sent to browser
DEBUG - 2025-03-21 12:37:27 --> Total execution time: 0.1008
INFO - 2025-03-21 12:37:39 --> Config Class Initialized
INFO - 2025-03-21 12:37:39 --> Hooks Class Initialized
DEBUG - 2025-03-21 12:37:39 --> UTF-8 Support Enabled
INFO - 2025-03-21 12:37:39 --> Utf8 Class Initialized
INFO - 2025-03-21 12:37:39 --> URI Class Initialized
INFO - 2025-03-21 12:37:39 --> Router Class Initialized
INFO - 2025-03-21 12:37:39 --> Output Class Initialized
INFO - 2025-03-21 12:37:39 --> Security Class Initialized
DEBUG - 2025-03-21 12:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 12:37:39 --> Input Class Initialized
INFO - 2025-03-21 12:37:39 --> Language Class Initialized
INFO - 2025-03-21 12:37:39 --> Language Class Initialized
INFO - 2025-03-21 12:37:39 --> Config Class Initialized
INFO - 2025-03-21 12:37:39 --> Loader Class Initialized
INFO - 2025-03-21 12:37:39 --> Helper loaded: url_helper
INFO - 2025-03-21 12:37:39 --> Helper loaded: file_helper
INFO - 2025-03-21 12:37:39 --> Helper loaded: html_helper
INFO - 2025-03-21 12:37:39 --> Helper loaded: form_helper
INFO - 2025-03-21 12:37:39 --> Helper loaded: text_helper
INFO - 2025-03-21 12:37:39 --> Helper loaded: lang_helper
INFO - 2025-03-21 12:37:39 --> Helper loaded: directory_helper
INFO - 2025-03-21 12:37:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 12:37:39 --> Database Driver Class Initialized
INFO - 2025-03-21 12:37:39 --> Email Class Initialized
INFO - 2025-03-21 12:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 12:37:39 --> Form Validation Class Initialized
INFO - 2025-03-21 12:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 12:37:39 --> Pagination Class Initialized
INFO - 2025-03-21 12:37:39 --> Controller Class Initialized
INFO - 2025-03-21 12:37:39 --> Model Class Initialized
INFO - 2025-03-21 12:37:39 --> Final output sent to browser
DEBUG - 2025-03-21 12:37:39 --> Total execution time: 0.0171
INFO - 2025-03-21 21:15:39 --> Config Class Initialized
INFO - 2025-03-21 21:15:39 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:15:39 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:15:39 --> Utf8 Class Initialized
INFO - 2025-03-21 21:15:39 --> URI Class Initialized
DEBUG - 2025-03-21 21:15:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-21 21:15:39 --> No URI present. Default controller set.
INFO - 2025-03-21 21:15:39 --> Router Class Initialized
INFO - 2025-03-21 21:15:39 --> Output Class Initialized
INFO - 2025-03-21 21:15:39 --> Security Class Initialized
DEBUG - 2025-03-21 21:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:15:39 --> Input Class Initialized
INFO - 2025-03-21 21:15:39 --> Language Class Initialized
INFO - 2025-03-21 21:15:39 --> Language Class Initialized
INFO - 2025-03-21 21:15:39 --> Config Class Initialized
INFO - 2025-03-21 21:15:39 --> Loader Class Initialized
INFO - 2025-03-21 21:15:39 --> Helper loaded: url_helper
INFO - 2025-03-21 21:15:39 --> Helper loaded: file_helper
INFO - 2025-03-21 21:15:39 --> Helper loaded: html_helper
INFO - 2025-03-21 21:15:39 --> Helper loaded: form_helper
INFO - 2025-03-21 21:15:39 --> Helper loaded: text_helper
INFO - 2025-03-21 21:15:39 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:15:39 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:15:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:15:39 --> Database Driver Class Initialized
INFO - 2025-03-21 21:15:39 --> Email Class Initialized
INFO - 2025-03-21 21:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:15:39 --> Form Validation Class Initialized
INFO - 2025-03-21 21:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:15:39 --> Pagination Class Initialized
INFO - 2025-03-21 21:15:39 --> Controller Class Initialized
DEBUG - 2025-03-21 21:15:39 --> Auth MX_Controller Initialized
INFO - 2025-03-21 21:15:39 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-21 21:15:39 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:15:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:15:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:15:39 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-21 21:15:39 --> Final output sent to browser
DEBUG - 2025-03-21 21:15:39 --> Total execution time: 0.0421
INFO - 2025-03-21 21:15:49 --> Config Class Initialized
INFO - 2025-03-21 21:15:49 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:15:49 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:15:49 --> Utf8 Class Initialized
INFO - 2025-03-21 21:15:49 --> URI Class Initialized
DEBUG - 2025-03-21 21:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-21 21:15:49 --> Router Class Initialized
INFO - 2025-03-21 21:15:49 --> Output Class Initialized
INFO - 2025-03-21 21:15:49 --> Security Class Initialized
DEBUG - 2025-03-21 21:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:15:49 --> Input Class Initialized
INFO - 2025-03-21 21:15:49 --> Language Class Initialized
INFO - 2025-03-21 21:15:49 --> Language Class Initialized
INFO - 2025-03-21 21:15:49 --> Config Class Initialized
INFO - 2025-03-21 21:15:49 --> Loader Class Initialized
INFO - 2025-03-21 21:15:49 --> Helper loaded: url_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: file_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: html_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: form_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: text_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:15:49 --> Database Driver Class Initialized
INFO - 2025-03-21 21:15:49 --> Email Class Initialized
INFO - 2025-03-21 21:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:15:49 --> Form Validation Class Initialized
INFO - 2025-03-21 21:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:15:49 --> Pagination Class Initialized
INFO - 2025-03-21 21:15:49 --> Controller Class Initialized
DEBUG - 2025-03-21 21:15:49 --> Auth MX_Controller Initialized
INFO - 2025-03-21 21:15:49 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-21 21:15:49 --> Model Class Initialized
INFO - 2025-03-21 21:15:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-21 21:15:49 --> Config Class Initialized
INFO - 2025-03-21 21:15:49 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:15:49 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:15:49 --> Utf8 Class Initialized
INFO - 2025-03-21 21:15:49 --> URI Class Initialized
DEBUG - 2025-03-21 21:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-21 21:15:49 --> Router Class Initialized
INFO - 2025-03-21 21:15:49 --> Output Class Initialized
INFO - 2025-03-21 21:15:49 --> Security Class Initialized
DEBUG - 2025-03-21 21:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:15:49 --> Input Class Initialized
INFO - 2025-03-21 21:15:49 --> Language Class Initialized
INFO - 2025-03-21 21:15:49 --> Language Class Initialized
INFO - 2025-03-21 21:15:49 --> Config Class Initialized
INFO - 2025-03-21 21:15:49 --> Loader Class Initialized
INFO - 2025-03-21 21:15:49 --> Helper loaded: url_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: file_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: html_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: form_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: text_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:15:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:15:49 --> Database Driver Class Initialized
INFO - 2025-03-21 21:15:49 --> Email Class Initialized
INFO - 2025-03-21 21:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:15:49 --> Form Validation Class Initialized
INFO - 2025-03-21 21:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:15:49 --> Pagination Class Initialized
INFO - 2025-03-21 21:15:49 --> Controller Class Initialized
DEBUG - 2025-03-21 21:15:49 --> Home MX_Controller Initialized
INFO - 2025-03-21 21:15:49 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-21 21:15:49 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:15:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:15:49 --> Model Class Initialized
ERROR - 2025-03-21 21:15:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:15:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-21 21:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:15:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:15:50 --> Final output sent to browser
DEBUG - 2025-03-21 21:15:50 --> Total execution time: 0.7954
INFO - 2025-03-21 21:15:53 --> Config Class Initialized
INFO - 2025-03-21 21:15:53 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:15:53 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:15:53 --> Utf8 Class Initialized
INFO - 2025-03-21 21:15:53 --> URI Class Initialized
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:15:53 --> Router Class Initialized
INFO - 2025-03-21 21:15:53 --> Output Class Initialized
INFO - 2025-03-21 21:15:53 --> Security Class Initialized
DEBUG - 2025-03-21 21:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:15:53 --> Input Class Initialized
INFO - 2025-03-21 21:15:53 --> Language Class Initialized
INFO - 2025-03-21 21:15:53 --> Language Class Initialized
INFO - 2025-03-21 21:15:53 --> Config Class Initialized
INFO - 2025-03-21 21:15:53 --> Loader Class Initialized
INFO - 2025-03-21 21:15:53 --> Helper loaded: url_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: file_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: html_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: form_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: text_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:15:53 --> Database Driver Class Initialized
INFO - 2025-03-21 21:15:53 --> Email Class Initialized
INFO - 2025-03-21 21:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:15:53 --> Form Validation Class Initialized
INFO - 2025-03-21 21:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:15:53 --> Pagination Class Initialized
INFO - 2025-03-21 21:15:53 --> Controller Class Initialized
DEBUG - 2025-03-21 21:15:53 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:15:53 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:15:53 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:15:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:15:53 --> Model Class Initialized
ERROR - 2025-03-21 21:15:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:15:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:15:53 --> Final output sent to browser
DEBUG - 2025-03-21 21:15:53 --> Total execution time: 0.1468
INFO - 2025-03-21 21:15:53 --> Config Class Initialized
INFO - 2025-03-21 21:15:53 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:15:53 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:15:53 --> Utf8 Class Initialized
INFO - 2025-03-21 21:15:53 --> URI Class Initialized
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:15:53 --> Router Class Initialized
INFO - 2025-03-21 21:15:53 --> Output Class Initialized
INFO - 2025-03-21 21:15:53 --> Security Class Initialized
DEBUG - 2025-03-21 21:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:15:53 --> Input Class Initialized
INFO - 2025-03-21 21:15:53 --> Language Class Initialized
INFO - 2025-03-21 21:15:53 --> Language Class Initialized
INFO - 2025-03-21 21:15:53 --> Config Class Initialized
INFO - 2025-03-21 21:15:53 --> Loader Class Initialized
INFO - 2025-03-21 21:15:53 --> Helper loaded: url_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: file_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: html_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: form_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: text_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:15:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:15:53 --> Database Driver Class Initialized
INFO - 2025-03-21 21:15:53 --> Email Class Initialized
INFO - 2025-03-21 21:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:15:53 --> Form Validation Class Initialized
INFO - 2025-03-21 21:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:15:53 --> Pagination Class Initialized
INFO - 2025-03-21 21:15:53 --> Controller Class Initialized
DEBUG - 2025-03-21 21:15:53 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:15:53 --> Model Class Initialized
DEBUG - 2025-03-21 21:15:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:15:53 --> Model Class Initialized
ERROR - 2025-03-21 21:15:53 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:15:53 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:15:53 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:15:53 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:15:53 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:15:53 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:15:53 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:15:53 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"0","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:15:53 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:16:15 --> Config Class Initialized
INFO - 2025-03-21 21:16:15 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:16:15 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:16:15 --> Utf8 Class Initialized
INFO - 2025-03-21 21:16:15 --> URI Class Initialized
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:16:15 --> Router Class Initialized
INFO - 2025-03-21 21:16:15 --> Output Class Initialized
INFO - 2025-03-21 21:16:15 --> Security Class Initialized
DEBUG - 2025-03-21 21:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:16:15 --> Input Class Initialized
INFO - 2025-03-21 21:16:15 --> Language Class Initialized
INFO - 2025-03-21 21:16:15 --> Language Class Initialized
INFO - 2025-03-21 21:16:15 --> Config Class Initialized
INFO - 2025-03-21 21:16:15 --> Loader Class Initialized
INFO - 2025-03-21 21:16:15 --> Helper loaded: url_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: file_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: html_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: form_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: text_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:16:15 --> Database Driver Class Initialized
INFO - 2025-03-21 21:16:15 --> Email Class Initialized
INFO - 2025-03-21 21:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:16:15 --> Form Validation Class Initialized
INFO - 2025-03-21 21:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:16:15 --> Pagination Class Initialized
INFO - 2025-03-21 21:16:15 --> Controller Class Initialized
DEBUG - 2025-03-21 21:16:15 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:16:15 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:16:15 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:16:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:16:15 --> Model Class Initialized
ERROR - 2025-03-21 21:16:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:16:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:16:15 --> Final output sent to browser
DEBUG - 2025-03-21 21:16:15 --> Total execution time: 0.0998
INFO - 2025-03-21 21:16:15 --> Config Class Initialized
INFO - 2025-03-21 21:16:15 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:16:15 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:16:15 --> Utf8 Class Initialized
INFO - 2025-03-21 21:16:15 --> URI Class Initialized
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:16:15 --> Router Class Initialized
INFO - 2025-03-21 21:16:15 --> Output Class Initialized
INFO - 2025-03-21 21:16:15 --> Security Class Initialized
DEBUG - 2025-03-21 21:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:16:15 --> Input Class Initialized
INFO - 2025-03-21 21:16:15 --> Language Class Initialized
INFO - 2025-03-21 21:16:15 --> Language Class Initialized
INFO - 2025-03-21 21:16:15 --> Config Class Initialized
INFO - 2025-03-21 21:16:15 --> Loader Class Initialized
INFO - 2025-03-21 21:16:15 --> Helper loaded: url_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: file_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: html_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: form_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: text_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:16:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:16:15 --> Database Driver Class Initialized
INFO - 2025-03-21 21:16:15 --> Email Class Initialized
INFO - 2025-03-21 21:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:16:15 --> Form Validation Class Initialized
INFO - 2025-03-21 21:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:16:15 --> Pagination Class Initialized
INFO - 2025-03-21 21:16:15 --> Controller Class Initialized
DEBUG - 2025-03-21 21:16:15 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:16:15 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:16:15 --> Model Class Initialized
ERROR - 2025-03-21 21:16:15 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:16:15 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:16:15 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:16:15 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:16:15 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:16:15 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:16:15 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:16:15 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:16:15 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:16:16 --> Config Class Initialized
INFO - 2025-03-21 21:16:16 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:16:16 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:16:16 --> Utf8 Class Initialized
INFO - 2025-03-21 21:16:16 --> URI Class Initialized
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:16:16 --> Router Class Initialized
INFO - 2025-03-21 21:16:16 --> Output Class Initialized
INFO - 2025-03-21 21:16:16 --> Security Class Initialized
DEBUG - 2025-03-21 21:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:16:16 --> Input Class Initialized
INFO - 2025-03-21 21:16:16 --> Language Class Initialized
INFO - 2025-03-21 21:16:16 --> Language Class Initialized
INFO - 2025-03-21 21:16:16 --> Config Class Initialized
INFO - 2025-03-21 21:16:16 --> Loader Class Initialized
INFO - 2025-03-21 21:16:16 --> Helper loaded: url_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: file_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: html_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: form_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: text_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:16:16 --> Database Driver Class Initialized
INFO - 2025-03-21 21:16:16 --> Email Class Initialized
INFO - 2025-03-21 21:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:16:16 --> Form Validation Class Initialized
INFO - 2025-03-21 21:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:16:16 --> Pagination Class Initialized
INFO - 2025-03-21 21:16:16 --> Controller Class Initialized
DEBUG - 2025-03-21 21:16:16 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:16:16 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:16:16 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:16:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:16:16 --> Model Class Initialized
ERROR - 2025-03-21 21:16:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:16:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:16:16 --> Final output sent to browser
DEBUG - 2025-03-21 21:16:16 --> Total execution time: 0.0917
INFO - 2025-03-21 21:16:16 --> Config Class Initialized
INFO - 2025-03-21 21:16:16 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:16:16 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:16:16 --> Utf8 Class Initialized
INFO - 2025-03-21 21:16:16 --> URI Class Initialized
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:16:16 --> Router Class Initialized
INFO - 2025-03-21 21:16:16 --> Output Class Initialized
INFO - 2025-03-21 21:16:16 --> Security Class Initialized
DEBUG - 2025-03-21 21:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:16:16 --> Input Class Initialized
INFO - 2025-03-21 21:16:16 --> Language Class Initialized
INFO - 2025-03-21 21:16:16 --> Language Class Initialized
INFO - 2025-03-21 21:16:16 --> Config Class Initialized
INFO - 2025-03-21 21:16:16 --> Loader Class Initialized
INFO - 2025-03-21 21:16:16 --> Helper loaded: url_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: file_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: html_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: form_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: text_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:16:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:16:16 --> Database Driver Class Initialized
INFO - 2025-03-21 21:16:16 --> Email Class Initialized
INFO - 2025-03-21 21:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:16:16 --> Form Validation Class Initialized
INFO - 2025-03-21 21:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:16:16 --> Pagination Class Initialized
INFO - 2025-03-21 21:16:16 --> Controller Class Initialized
DEBUG - 2025-03-21 21:16:16 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:16:16 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:16:16 --> Model Class Initialized
ERROR - 2025-03-21 21:16:16 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:16:16 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:16:16 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:16:16 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:16:16 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:16:16 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:16:16 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:16:16 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:16:16 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:16:22 --> Config Class Initialized
INFO - 2025-03-21 21:16:22 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:16:22 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:16:22 --> Utf8 Class Initialized
INFO - 2025-03-21 21:16:22 --> URI Class Initialized
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:16:22 --> Router Class Initialized
INFO - 2025-03-21 21:16:22 --> Output Class Initialized
INFO - 2025-03-21 21:16:22 --> Security Class Initialized
DEBUG - 2025-03-21 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:16:22 --> Input Class Initialized
INFO - 2025-03-21 21:16:22 --> Language Class Initialized
INFO - 2025-03-21 21:16:22 --> Language Class Initialized
INFO - 2025-03-21 21:16:22 --> Config Class Initialized
INFO - 2025-03-21 21:16:22 --> Loader Class Initialized
INFO - 2025-03-21 21:16:22 --> Helper loaded: url_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: file_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: html_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: form_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: text_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:16:22 --> Database Driver Class Initialized
INFO - 2025-03-21 21:16:22 --> Email Class Initialized
INFO - 2025-03-21 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:16:22 --> Form Validation Class Initialized
INFO - 2025-03-21 21:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:16:22 --> Pagination Class Initialized
INFO - 2025-03-21 21:16:22 --> Controller Class Initialized
DEBUG - 2025-03-21 21:16:22 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:16:22 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:16:22 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:16:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:16:22 --> Model Class Initialized
ERROR - 2025-03-21 21:16:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:16:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:16:22 --> Final output sent to browser
DEBUG - 2025-03-21 21:16:22 --> Total execution time: 0.1557
INFO - 2025-03-21 21:16:22 --> Config Class Initialized
INFO - 2025-03-21 21:16:22 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:16:22 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:16:22 --> Utf8 Class Initialized
INFO - 2025-03-21 21:16:22 --> URI Class Initialized
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:16:22 --> Router Class Initialized
INFO - 2025-03-21 21:16:22 --> Output Class Initialized
INFO - 2025-03-21 21:16:22 --> Security Class Initialized
DEBUG - 2025-03-21 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:16:22 --> Input Class Initialized
INFO - 2025-03-21 21:16:22 --> Language Class Initialized
INFO - 2025-03-21 21:16:22 --> Language Class Initialized
INFO - 2025-03-21 21:16:22 --> Config Class Initialized
INFO - 2025-03-21 21:16:22 --> Loader Class Initialized
INFO - 2025-03-21 21:16:22 --> Helper loaded: url_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: file_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: html_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: form_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: text_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:16:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:16:22 --> Database Driver Class Initialized
INFO - 2025-03-21 21:16:22 --> Email Class Initialized
INFO - 2025-03-21 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:16:22 --> Form Validation Class Initialized
INFO - 2025-03-21 21:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:16:22 --> Pagination Class Initialized
INFO - 2025-03-21 21:16:22 --> Controller Class Initialized
DEBUG - 2025-03-21 21:16:22 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:16:22 --> Model Class Initialized
DEBUG - 2025-03-21 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:16:22 --> Model Class Initialized
ERROR - 2025-03-21 21:16:22 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:16:22 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:16:22 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:16:22 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:16:22 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:16:22 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:16:22 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:16:22 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:16:22 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:17:47 --> Config Class Initialized
INFO - 2025-03-21 21:17:47 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:17:47 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:17:47 --> Utf8 Class Initialized
INFO - 2025-03-21 21:17:47 --> URI Class Initialized
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:17:47 --> Router Class Initialized
INFO - 2025-03-21 21:17:47 --> Output Class Initialized
INFO - 2025-03-21 21:17:47 --> Security Class Initialized
DEBUG - 2025-03-21 21:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:17:47 --> Input Class Initialized
INFO - 2025-03-21 21:17:47 --> Language Class Initialized
INFO - 2025-03-21 21:17:47 --> Language Class Initialized
INFO - 2025-03-21 21:17:47 --> Config Class Initialized
INFO - 2025-03-21 21:17:47 --> Loader Class Initialized
INFO - 2025-03-21 21:17:47 --> Helper loaded: url_helper
INFO - 2025-03-21 21:17:47 --> Helper loaded: file_helper
INFO - 2025-03-21 21:17:47 --> Helper loaded: html_helper
INFO - 2025-03-21 21:17:47 --> Helper loaded: form_helper
INFO - 2025-03-21 21:17:47 --> Helper loaded: text_helper
INFO - 2025-03-21 21:17:47 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:17:47 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:17:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:17:47 --> Database Driver Class Initialized
INFO - 2025-03-21 21:17:47 --> Email Class Initialized
INFO - 2025-03-21 21:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:17:47 --> Form Validation Class Initialized
INFO - 2025-03-21 21:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:17:47 --> Pagination Class Initialized
INFO - 2025-03-21 21:17:47 --> Controller Class Initialized
DEBUG - 2025-03-21 21:17:47 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:17:47 --> Model Class Initialized
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:17:47 --> Model Class Initialized
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:17:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:17:47 --> Model Class Initialized
ERROR - 2025-03-21 21:17:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:17:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:17:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:17:47 --> Final output sent to browser
DEBUG - 2025-03-21 21:17:47 --> Total execution time: 0.1332
INFO - 2025-03-21 21:17:48 --> Config Class Initialized
INFO - 2025-03-21 21:17:48 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:17:48 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:17:48 --> Utf8 Class Initialized
INFO - 2025-03-21 21:17:48 --> URI Class Initialized
DEBUG - 2025-03-21 21:17:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:17:48 --> Router Class Initialized
INFO - 2025-03-21 21:17:48 --> Output Class Initialized
INFO - 2025-03-21 21:17:48 --> Security Class Initialized
DEBUG - 2025-03-21 21:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:17:48 --> Input Class Initialized
INFO - 2025-03-21 21:17:48 --> Language Class Initialized
INFO - 2025-03-21 21:17:48 --> Language Class Initialized
INFO - 2025-03-21 21:17:48 --> Config Class Initialized
INFO - 2025-03-21 21:17:48 --> Loader Class Initialized
INFO - 2025-03-21 21:17:48 --> Helper loaded: url_helper
INFO - 2025-03-21 21:17:48 --> Helper loaded: file_helper
INFO - 2025-03-21 21:17:48 --> Helper loaded: html_helper
INFO - 2025-03-21 21:17:48 --> Helper loaded: form_helper
INFO - 2025-03-21 21:17:48 --> Helper loaded: text_helper
INFO - 2025-03-21 21:17:48 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:17:48 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:17:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:17:48 --> Database Driver Class Initialized
INFO - 2025-03-21 21:17:48 --> Email Class Initialized
INFO - 2025-03-21 21:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:17:48 --> Form Validation Class Initialized
INFO - 2025-03-21 21:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:17:48 --> Pagination Class Initialized
INFO - 2025-03-21 21:17:48 --> Controller Class Initialized
DEBUG - 2025-03-21 21:17:48 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:17:48 --> Model Class Initialized
DEBUG - 2025-03-21 21:17:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:17:48 --> Model Class Initialized
ERROR - 2025-03-21 21:17:48 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:17:48 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:17:48 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:17:48 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:17:48 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:17:48 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:17:48 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:17:48 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:17:48 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:19:31 --> Config Class Initialized
INFO - 2025-03-21 21:19:31 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:19:31 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:19:31 --> Utf8 Class Initialized
INFO - 2025-03-21 21:19:31 --> URI Class Initialized
DEBUG - 2025-03-21 21:19:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:19:31 --> Router Class Initialized
INFO - 2025-03-21 21:19:31 --> Output Class Initialized
INFO - 2025-03-21 21:19:31 --> Security Class Initialized
DEBUG - 2025-03-21 21:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:19:31 --> Input Class Initialized
INFO - 2025-03-21 21:19:31 --> Language Class Initialized
INFO - 2025-03-21 21:19:31 --> Language Class Initialized
INFO - 2025-03-21 21:19:31 --> Config Class Initialized
INFO - 2025-03-21 21:19:31 --> Loader Class Initialized
INFO - 2025-03-21 21:19:31 --> Helper loaded: url_helper
INFO - 2025-03-21 21:19:31 --> Helper loaded: file_helper
INFO - 2025-03-21 21:19:31 --> Helper loaded: html_helper
INFO - 2025-03-21 21:19:31 --> Helper loaded: form_helper
INFO - 2025-03-21 21:19:31 --> Helper loaded: text_helper
INFO - 2025-03-21 21:19:31 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:19:31 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:19:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:19:31 --> Database Driver Class Initialized
INFO - 2025-03-21 21:19:31 --> Email Class Initialized
INFO - 2025-03-21 21:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:19:31 --> Form Validation Class Initialized
INFO - 2025-03-21 21:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:19:31 --> Pagination Class Initialized
INFO - 2025-03-21 21:19:31 --> Controller Class Initialized
DEBUG - 2025-03-21 21:19:31 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:19:31 --> Model Class Initialized
DEBUG - 2025-03-21 21:19:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:19:31 --> Model Class Initialized
ERROR - 2025-03-21 21:19:31 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:19:31 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:19:31 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:19:31 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:19:31 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:19:31 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:19:31 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:19:31 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:19:31 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:21:24 --> Config Class Initialized
INFO - 2025-03-21 21:21:24 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:21:24 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:21:24 --> Utf8 Class Initialized
INFO - 2025-03-21 21:21:24 --> URI Class Initialized
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:21:24 --> Router Class Initialized
INFO - 2025-03-21 21:21:24 --> Output Class Initialized
INFO - 2025-03-21 21:21:24 --> Security Class Initialized
DEBUG - 2025-03-21 21:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:21:24 --> Input Class Initialized
INFO - 2025-03-21 21:21:24 --> Language Class Initialized
INFO - 2025-03-21 21:21:24 --> Language Class Initialized
INFO - 2025-03-21 21:21:24 --> Config Class Initialized
INFO - 2025-03-21 21:21:24 --> Loader Class Initialized
INFO - 2025-03-21 21:21:24 --> Helper loaded: url_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: file_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: html_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: form_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: text_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:21:24 --> Database Driver Class Initialized
INFO - 2025-03-21 21:21:24 --> Email Class Initialized
INFO - 2025-03-21 21:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:21:24 --> Form Validation Class Initialized
INFO - 2025-03-21 21:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:21:24 --> Pagination Class Initialized
INFO - 2025-03-21 21:21:24 --> Controller Class Initialized
DEBUG - 2025-03-21 21:21:24 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:21:24 --> Model Class Initialized
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:21:24 --> Model Class Initialized
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:21:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:21:24 --> Model Class Initialized
ERROR - 2025-03-21 21:21:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:21:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:21:24 --> Final output sent to browser
DEBUG - 2025-03-21 21:21:24 --> Total execution time: 0.1254
INFO - 2025-03-21 21:21:24 --> Config Class Initialized
INFO - 2025-03-21 21:21:24 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:21:24 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:21:24 --> Utf8 Class Initialized
INFO - 2025-03-21 21:21:24 --> URI Class Initialized
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:21:24 --> Router Class Initialized
INFO - 2025-03-21 21:21:24 --> Output Class Initialized
INFO - 2025-03-21 21:21:24 --> Security Class Initialized
DEBUG - 2025-03-21 21:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:21:24 --> Input Class Initialized
INFO - 2025-03-21 21:21:24 --> Language Class Initialized
INFO - 2025-03-21 21:21:24 --> Language Class Initialized
INFO - 2025-03-21 21:21:24 --> Config Class Initialized
INFO - 2025-03-21 21:21:24 --> Loader Class Initialized
INFO - 2025-03-21 21:21:24 --> Helper loaded: url_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: file_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: html_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: form_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: text_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:21:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:21:24 --> Database Driver Class Initialized
INFO - 2025-03-21 21:21:24 --> Email Class Initialized
INFO - 2025-03-21 21:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:21:24 --> Form Validation Class Initialized
INFO - 2025-03-21 21:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:21:24 --> Pagination Class Initialized
INFO - 2025-03-21 21:21:24 --> Controller Class Initialized
DEBUG - 2025-03-21 21:21:24 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:21:24 --> Model Class Initialized
DEBUG - 2025-03-21 21:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:21:24 --> Model Class Initialized
ERROR - 2025-03-21 21:21:24 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:21:24 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:21:24 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:21:24 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:21:24 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:21:24 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:21:24 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:21:24 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:21:24 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:21:32 --> Config Class Initialized
INFO - 2025-03-21 21:21:32 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:21:32 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:21:32 --> Utf8 Class Initialized
INFO - 2025-03-21 21:21:32 --> URI Class Initialized
DEBUG - 2025-03-21 21:21:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:21:32 --> Router Class Initialized
INFO - 2025-03-21 21:21:32 --> Output Class Initialized
INFO - 2025-03-21 21:21:32 --> Security Class Initialized
DEBUG - 2025-03-21 21:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:21:32 --> Input Class Initialized
INFO - 2025-03-21 21:21:32 --> Language Class Initialized
INFO - 2025-03-21 21:21:32 --> Language Class Initialized
INFO - 2025-03-21 21:21:32 --> Config Class Initialized
INFO - 2025-03-21 21:21:32 --> Loader Class Initialized
INFO - 2025-03-21 21:21:32 --> Helper loaded: url_helper
INFO - 2025-03-21 21:21:32 --> Helper loaded: file_helper
INFO - 2025-03-21 21:21:32 --> Helper loaded: html_helper
INFO - 2025-03-21 21:21:32 --> Helper loaded: form_helper
INFO - 2025-03-21 21:21:32 --> Helper loaded: text_helper
INFO - 2025-03-21 21:21:32 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:21:32 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:21:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:21:32 --> Database Driver Class Initialized
INFO - 2025-03-21 21:21:32 --> Email Class Initialized
INFO - 2025-03-21 21:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:21:32 --> Form Validation Class Initialized
INFO - 2025-03-21 21:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:21:32 --> Pagination Class Initialized
INFO - 2025-03-21 21:21:32 --> Controller Class Initialized
DEBUG - 2025-03-21 21:21:32 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:21:32 --> Model Class Initialized
DEBUG - 2025-03-21 21:21:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:21:32 --> Model Class Initialized
ERROR - 2025-03-21 21:21:32 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:21:32 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:21:32 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:21:32 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:21:32 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:21:32 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:21:32 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:21:32 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:21:32 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:31:22 --> Config Class Initialized
INFO - 2025-03-21 21:31:22 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:31:22 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:31:22 --> Utf8 Class Initialized
INFO - 2025-03-21 21:31:22 --> URI Class Initialized
DEBUG - 2025-03-21 21:31:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:31:22 --> Router Class Initialized
INFO - 2025-03-21 21:31:22 --> Output Class Initialized
INFO - 2025-03-21 21:31:22 --> Security Class Initialized
DEBUG - 2025-03-21 21:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:31:22 --> Input Class Initialized
INFO - 2025-03-21 21:31:22 --> Language Class Initialized
INFO - 2025-03-21 21:31:22 --> Language Class Initialized
INFO - 2025-03-21 21:31:22 --> Config Class Initialized
INFO - 2025-03-21 21:31:22 --> Loader Class Initialized
INFO - 2025-03-21 21:31:22 --> Helper loaded: url_helper
INFO - 2025-03-21 21:31:22 --> Helper loaded: file_helper
INFO - 2025-03-21 21:31:22 --> Helper loaded: html_helper
INFO - 2025-03-21 21:31:22 --> Helper loaded: form_helper
INFO - 2025-03-21 21:31:22 --> Helper loaded: text_helper
INFO - 2025-03-21 21:31:22 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:31:22 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:31:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:31:22 --> Database Driver Class Initialized
INFO - 2025-03-21 21:31:22 --> Email Class Initialized
INFO - 2025-03-21 21:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:31:22 --> Form Validation Class Initialized
INFO - 2025-03-21 21:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:31:22 --> Pagination Class Initialized
INFO - 2025-03-21 21:31:22 --> Controller Class Initialized
DEBUG - 2025-03-21 21:31:22 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:31:22 --> Model Class Initialized
DEBUG - 2025-03-21 21:31:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:31:22 --> Model Class Initialized
ERROR - 2025-03-21 21:31:22 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:31:22 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:31:22 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:31:22 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:31:22 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:31:22 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:31:22 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:31:23 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:31:23 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:31:26 --> Config Class Initialized
INFO - 2025-03-21 21:31:26 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:31:26 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:31:26 --> Utf8 Class Initialized
INFO - 2025-03-21 21:31:26 --> URI Class Initialized
DEBUG - 2025-03-21 21:31:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:31:26 --> Router Class Initialized
INFO - 2025-03-21 21:31:26 --> Output Class Initialized
INFO - 2025-03-21 21:31:26 --> Security Class Initialized
DEBUG - 2025-03-21 21:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:31:26 --> Input Class Initialized
INFO - 2025-03-21 21:31:26 --> Language Class Initialized
INFO - 2025-03-21 21:31:26 --> Language Class Initialized
INFO - 2025-03-21 21:31:26 --> Config Class Initialized
INFO - 2025-03-21 21:31:26 --> Loader Class Initialized
INFO - 2025-03-21 21:31:26 --> Helper loaded: url_helper
INFO - 2025-03-21 21:31:26 --> Helper loaded: file_helper
INFO - 2025-03-21 21:31:26 --> Helper loaded: html_helper
INFO - 2025-03-21 21:31:26 --> Helper loaded: form_helper
INFO - 2025-03-21 21:31:26 --> Helper loaded: text_helper
INFO - 2025-03-21 21:31:26 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:31:26 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:31:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:31:26 --> Database Driver Class Initialized
INFO - 2025-03-21 21:31:26 --> Email Class Initialized
INFO - 2025-03-21 21:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:31:26 --> Form Validation Class Initialized
INFO - 2025-03-21 21:31:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:31:26 --> Pagination Class Initialized
INFO - 2025-03-21 21:31:26 --> Controller Class Initialized
DEBUG - 2025-03-21 21:31:26 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:31:26 --> Model Class Initialized
DEBUG - 2025-03-21 21:31:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:31:26 --> Model Class Initialized
ERROR - 2025-03-21 21:31:26 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:31:26 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:31:26 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:31:26 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:31:26 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:31:26 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:31:26 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:31:26 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:31:26 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:31:37 --> Config Class Initialized
INFO - 2025-03-21 21:31:37 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:31:37 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:31:37 --> Utf8 Class Initialized
INFO - 2025-03-21 21:31:37 --> URI Class Initialized
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:31:37 --> Router Class Initialized
INFO - 2025-03-21 21:31:37 --> Output Class Initialized
INFO - 2025-03-21 21:31:37 --> Security Class Initialized
DEBUG - 2025-03-21 21:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:31:37 --> Input Class Initialized
INFO - 2025-03-21 21:31:37 --> Language Class Initialized
INFO - 2025-03-21 21:31:37 --> Language Class Initialized
INFO - 2025-03-21 21:31:37 --> Config Class Initialized
INFO - 2025-03-21 21:31:37 --> Loader Class Initialized
INFO - 2025-03-21 21:31:37 --> Helper loaded: url_helper
INFO - 2025-03-21 21:31:37 --> Helper loaded: file_helper
INFO - 2025-03-21 21:31:37 --> Helper loaded: html_helper
INFO - 2025-03-21 21:31:37 --> Helper loaded: form_helper
INFO - 2025-03-21 21:31:37 --> Helper loaded: text_helper
INFO - 2025-03-21 21:31:37 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:31:37 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:31:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:31:37 --> Database Driver Class Initialized
INFO - 2025-03-21 21:31:37 --> Email Class Initialized
INFO - 2025-03-21 21:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:31:37 --> Form Validation Class Initialized
INFO - 2025-03-21 21:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:31:37 --> Pagination Class Initialized
INFO - 2025-03-21 21:31:37 --> Controller Class Initialized
DEBUG - 2025-03-21 21:31:37 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:31:37 --> Model Class Initialized
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:31:37 --> Model Class Initialized
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:31:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:31:37 --> Model Class Initialized
ERROR - 2025-03-21 21:31:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:31:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:31:37 --> Final output sent to browser
DEBUG - 2025-03-21 21:31:37 --> Total execution time: 0.1642
INFO - 2025-03-21 21:31:38 --> Config Class Initialized
INFO - 2025-03-21 21:31:38 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:31:38 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:31:38 --> Utf8 Class Initialized
INFO - 2025-03-21 21:31:38 --> URI Class Initialized
DEBUG - 2025-03-21 21:31:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:31:38 --> Router Class Initialized
INFO - 2025-03-21 21:31:38 --> Output Class Initialized
INFO - 2025-03-21 21:31:38 --> Security Class Initialized
DEBUG - 2025-03-21 21:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:31:38 --> Input Class Initialized
INFO - 2025-03-21 21:31:38 --> Language Class Initialized
INFO - 2025-03-21 21:31:38 --> Language Class Initialized
INFO - 2025-03-21 21:31:38 --> Config Class Initialized
INFO - 2025-03-21 21:31:38 --> Loader Class Initialized
INFO - 2025-03-21 21:31:38 --> Helper loaded: url_helper
INFO - 2025-03-21 21:31:38 --> Helper loaded: file_helper
INFO - 2025-03-21 21:31:38 --> Helper loaded: html_helper
INFO - 2025-03-21 21:31:38 --> Helper loaded: form_helper
INFO - 2025-03-21 21:31:38 --> Helper loaded: text_helper
INFO - 2025-03-21 21:31:38 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:31:38 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:31:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:31:38 --> Database Driver Class Initialized
INFO - 2025-03-21 21:31:38 --> Email Class Initialized
INFO - 2025-03-21 21:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:31:38 --> Form Validation Class Initialized
INFO - 2025-03-21 21:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:31:38 --> Pagination Class Initialized
INFO - 2025-03-21 21:31:38 --> Controller Class Initialized
DEBUG - 2025-03-21 21:31:38 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:31:38 --> Model Class Initialized
DEBUG - 2025-03-21 21:31:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:31:38 --> Model Class Initialized
ERROR - 2025-03-21 21:31:38 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:31:38 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:31:38 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:31:38 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:31:38 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:31:38 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:31:38 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:31:38 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:31:38 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:32:38 --> Config Class Initialized
INFO - 2025-03-21 21:32:38 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:32:38 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:32:38 --> Utf8 Class Initialized
INFO - 2025-03-21 21:32:38 --> URI Class Initialized
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:32:38 --> Router Class Initialized
INFO - 2025-03-21 21:32:38 --> Output Class Initialized
INFO - 2025-03-21 21:32:38 --> Security Class Initialized
DEBUG - 2025-03-21 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:32:38 --> Input Class Initialized
INFO - 2025-03-21 21:32:38 --> Language Class Initialized
INFO - 2025-03-21 21:32:38 --> Language Class Initialized
INFO - 2025-03-21 21:32:38 --> Config Class Initialized
INFO - 2025-03-21 21:32:38 --> Loader Class Initialized
INFO - 2025-03-21 21:32:38 --> Helper loaded: url_helper
INFO - 2025-03-21 21:32:38 --> Helper loaded: file_helper
INFO - 2025-03-21 21:32:38 --> Helper loaded: html_helper
INFO - 2025-03-21 21:32:38 --> Helper loaded: form_helper
INFO - 2025-03-21 21:32:38 --> Helper loaded: text_helper
INFO - 2025-03-21 21:32:38 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:32:38 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:32:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:32:38 --> Database Driver Class Initialized
INFO - 2025-03-21 21:32:38 --> Email Class Initialized
INFO - 2025-03-21 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:32:38 --> Form Validation Class Initialized
INFO - 2025-03-21 21:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:32:38 --> Pagination Class Initialized
INFO - 2025-03-21 21:32:38 --> Controller Class Initialized
DEBUG - 2025-03-21 21:32:38 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:32:38 --> Model Class Initialized
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:32:38 --> Model Class Initialized
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:32:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:32:38 --> Model Class Initialized
ERROR - 2025-03-21 21:32:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:32:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:32:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:32:38 --> Final output sent to browser
DEBUG - 2025-03-21 21:32:38 --> Total execution time: 0.1324
INFO - 2025-03-21 21:32:39 --> Config Class Initialized
INFO - 2025-03-21 21:32:39 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:32:39 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:32:39 --> Utf8 Class Initialized
INFO - 2025-03-21 21:32:39 --> URI Class Initialized
DEBUG - 2025-03-21 21:32:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:32:39 --> Router Class Initialized
INFO - 2025-03-21 21:32:39 --> Output Class Initialized
INFO - 2025-03-21 21:32:39 --> Security Class Initialized
DEBUG - 2025-03-21 21:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:32:39 --> Input Class Initialized
INFO - 2025-03-21 21:32:39 --> Language Class Initialized
INFO - 2025-03-21 21:32:39 --> Language Class Initialized
INFO - 2025-03-21 21:32:39 --> Config Class Initialized
INFO - 2025-03-21 21:32:39 --> Loader Class Initialized
INFO - 2025-03-21 21:32:39 --> Helper loaded: url_helper
INFO - 2025-03-21 21:32:39 --> Helper loaded: file_helper
INFO - 2025-03-21 21:32:39 --> Helper loaded: html_helper
INFO - 2025-03-21 21:32:39 --> Helper loaded: form_helper
INFO - 2025-03-21 21:32:39 --> Helper loaded: text_helper
INFO - 2025-03-21 21:32:39 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:32:39 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:32:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:32:39 --> Database Driver Class Initialized
INFO - 2025-03-21 21:32:39 --> Email Class Initialized
INFO - 2025-03-21 21:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:32:39 --> Form Validation Class Initialized
INFO - 2025-03-21 21:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:32:39 --> Pagination Class Initialized
INFO - 2025-03-21 21:32:39 --> Controller Class Initialized
DEBUG - 2025-03-21 21:32:39 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:32:39 --> Model Class Initialized
DEBUG - 2025-03-21 21:32:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:32:39 --> Model Class Initialized
ERROR - 2025-03-21 21:32:39 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:32:39 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:32:39 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:32:39 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:32:39 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:32:39 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:32:39 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:32:39 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:32:39 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:34:28 --> Config Class Initialized
INFO - 2025-03-21 21:34:28 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:34:28 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:34:28 --> Utf8 Class Initialized
INFO - 2025-03-21 21:34:28 --> URI Class Initialized
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:34:28 --> Router Class Initialized
INFO - 2025-03-21 21:34:28 --> Output Class Initialized
INFO - 2025-03-21 21:34:28 --> Security Class Initialized
DEBUG - 2025-03-21 21:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:34:28 --> Input Class Initialized
INFO - 2025-03-21 21:34:28 --> Language Class Initialized
INFO - 2025-03-21 21:34:28 --> Language Class Initialized
INFO - 2025-03-21 21:34:28 --> Config Class Initialized
INFO - 2025-03-21 21:34:28 --> Loader Class Initialized
INFO - 2025-03-21 21:34:28 --> Helper loaded: url_helper
INFO - 2025-03-21 21:34:28 --> Helper loaded: file_helper
INFO - 2025-03-21 21:34:28 --> Helper loaded: html_helper
INFO - 2025-03-21 21:34:28 --> Helper loaded: form_helper
INFO - 2025-03-21 21:34:28 --> Helper loaded: text_helper
INFO - 2025-03-21 21:34:28 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:34:28 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:34:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:34:28 --> Database Driver Class Initialized
INFO - 2025-03-21 21:34:28 --> Email Class Initialized
INFO - 2025-03-21 21:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:34:28 --> Form Validation Class Initialized
INFO - 2025-03-21 21:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:34:28 --> Pagination Class Initialized
INFO - 2025-03-21 21:34:28 --> Controller Class Initialized
DEBUG - 2025-03-21 21:34:28 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:34:28 --> Model Class Initialized
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:34:28 --> Model Class Initialized
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:34:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:34:28 --> Model Class Initialized
ERROR - 2025-03-21 21:34:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:34:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:34:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:34:28 --> Final output sent to browser
DEBUG - 2025-03-21 21:34:28 --> Total execution time: 0.1285
INFO - 2025-03-21 21:34:29 --> Config Class Initialized
INFO - 2025-03-21 21:34:29 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:34:29 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:34:29 --> Utf8 Class Initialized
INFO - 2025-03-21 21:34:29 --> URI Class Initialized
DEBUG - 2025-03-21 21:34:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:34:29 --> Router Class Initialized
INFO - 2025-03-21 21:34:29 --> Output Class Initialized
INFO - 2025-03-21 21:34:29 --> Security Class Initialized
DEBUG - 2025-03-21 21:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:34:29 --> Input Class Initialized
INFO - 2025-03-21 21:34:29 --> Language Class Initialized
INFO - 2025-03-21 21:34:29 --> Language Class Initialized
INFO - 2025-03-21 21:34:29 --> Config Class Initialized
INFO - 2025-03-21 21:34:29 --> Loader Class Initialized
INFO - 2025-03-21 21:34:29 --> Helper loaded: url_helper
INFO - 2025-03-21 21:34:29 --> Helper loaded: file_helper
INFO - 2025-03-21 21:34:29 --> Helper loaded: html_helper
INFO - 2025-03-21 21:34:29 --> Helper loaded: form_helper
INFO - 2025-03-21 21:34:29 --> Helper loaded: text_helper
INFO - 2025-03-21 21:34:29 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:34:29 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:34:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:34:29 --> Database Driver Class Initialized
INFO - 2025-03-21 21:34:29 --> Email Class Initialized
INFO - 2025-03-21 21:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:34:29 --> Form Validation Class Initialized
INFO - 2025-03-21 21:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:34:29 --> Pagination Class Initialized
INFO - 2025-03-21 21:34:29 --> Controller Class Initialized
DEBUG - 2025-03-21 21:34:29 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:34:29 --> Model Class Initialized
DEBUG - 2025-03-21 21:34:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:34:29 --> Model Class Initialized
ERROR - 2025-03-21 21:34:29 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:34:29 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:34:29 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:34:29 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:34:29 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:34:29 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:34:29 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:34:29 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:34:29 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:34:41 --> Config Class Initialized
INFO - 2025-03-21 21:34:41 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:34:41 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:34:41 --> Utf8 Class Initialized
INFO - 2025-03-21 21:34:41 --> URI Class Initialized
DEBUG - 2025-03-21 21:34:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:34:41 --> Router Class Initialized
INFO - 2025-03-21 21:34:41 --> Output Class Initialized
INFO - 2025-03-21 21:34:41 --> Security Class Initialized
DEBUG - 2025-03-21 21:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:34:41 --> Input Class Initialized
INFO - 2025-03-21 21:34:41 --> Language Class Initialized
INFO - 2025-03-21 21:34:41 --> Language Class Initialized
INFO - 2025-03-21 21:34:41 --> Config Class Initialized
INFO - 2025-03-21 21:34:41 --> Loader Class Initialized
INFO - 2025-03-21 21:34:41 --> Helper loaded: url_helper
INFO - 2025-03-21 21:34:41 --> Helper loaded: file_helper
INFO - 2025-03-21 21:34:41 --> Helper loaded: html_helper
INFO - 2025-03-21 21:34:41 --> Helper loaded: form_helper
INFO - 2025-03-21 21:34:41 --> Helper loaded: text_helper
INFO - 2025-03-21 21:34:41 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:34:41 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:34:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:34:41 --> Database Driver Class Initialized
INFO - 2025-03-21 21:34:41 --> Email Class Initialized
INFO - 2025-03-21 21:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:34:41 --> Form Validation Class Initialized
INFO - 2025-03-21 21:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:34:41 --> Pagination Class Initialized
INFO - 2025-03-21 21:34:41 --> Controller Class Initialized
DEBUG - 2025-03-21 21:34:41 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:34:41 --> Model Class Initialized
DEBUG - 2025-03-21 21:34:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:34:41 --> Model Class Initialized
ERROR - 2025-03-21 21:34:41 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:34:41 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:34:41 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:34:41 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:34:41 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:34:41 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:34:41 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:34:41 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:34:41 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:42:31 --> Config Class Initialized
INFO - 2025-03-21 21:42:31 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:42:31 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:42:31 --> Utf8 Class Initialized
INFO - 2025-03-21 21:42:31 --> URI Class Initialized
DEBUG - 2025-03-21 21:42:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:42:31 --> Router Class Initialized
INFO - 2025-03-21 21:42:31 --> Output Class Initialized
INFO - 2025-03-21 21:42:31 --> Security Class Initialized
DEBUG - 2025-03-21 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:42:31 --> Input Class Initialized
INFO - 2025-03-21 21:42:31 --> Language Class Initialized
INFO - 2025-03-21 21:42:31 --> Language Class Initialized
INFO - 2025-03-21 21:42:31 --> Config Class Initialized
INFO - 2025-03-21 21:42:31 --> Loader Class Initialized
INFO - 2025-03-21 21:42:31 --> Helper loaded: url_helper
INFO - 2025-03-21 21:42:31 --> Helper loaded: file_helper
INFO - 2025-03-21 21:42:31 --> Helper loaded: html_helper
INFO - 2025-03-21 21:42:31 --> Helper loaded: form_helper
INFO - 2025-03-21 21:42:31 --> Helper loaded: text_helper
INFO - 2025-03-21 21:42:31 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:42:31 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:42:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:42:31 --> Database Driver Class Initialized
INFO - 2025-03-21 21:42:31 --> Email Class Initialized
INFO - 2025-03-21 21:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:42:31 --> Form Validation Class Initialized
INFO - 2025-03-21 21:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:42:31 --> Pagination Class Initialized
INFO - 2025-03-21 21:42:31 --> Controller Class Initialized
DEBUG - 2025-03-21 21:42:31 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:42:31 --> Model Class Initialized
DEBUG - 2025-03-21 21:42:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:42:31 --> Model Class Initialized
ERROR - 2025-03-21 21:42:31 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:42:31 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:42:31 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:42:31 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:42:31 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:42:31 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:42:31 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:42:31 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:42:31 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:42:34 --> Config Class Initialized
INFO - 2025-03-21 21:42:34 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:42:34 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:42:34 --> Utf8 Class Initialized
INFO - 2025-03-21 21:42:34 --> URI Class Initialized
DEBUG - 2025-03-21 21:42:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:42:34 --> Router Class Initialized
INFO - 2025-03-21 21:42:34 --> Output Class Initialized
INFO - 2025-03-21 21:42:34 --> Security Class Initialized
DEBUG - 2025-03-21 21:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:42:34 --> Input Class Initialized
INFO - 2025-03-21 21:42:34 --> Language Class Initialized
INFO - 2025-03-21 21:42:34 --> Language Class Initialized
INFO - 2025-03-21 21:42:34 --> Config Class Initialized
INFO - 2025-03-21 21:42:34 --> Loader Class Initialized
INFO - 2025-03-21 21:42:34 --> Helper loaded: url_helper
INFO - 2025-03-21 21:42:34 --> Helper loaded: file_helper
INFO - 2025-03-21 21:42:34 --> Helper loaded: html_helper
INFO - 2025-03-21 21:42:34 --> Helper loaded: form_helper
INFO - 2025-03-21 21:42:34 --> Helper loaded: text_helper
INFO - 2025-03-21 21:42:34 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:42:34 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:42:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:42:34 --> Database Driver Class Initialized
INFO - 2025-03-21 21:42:34 --> Email Class Initialized
INFO - 2025-03-21 21:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:42:34 --> Form Validation Class Initialized
INFO - 2025-03-21 21:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:42:34 --> Pagination Class Initialized
INFO - 2025-03-21 21:42:34 --> Controller Class Initialized
DEBUG - 2025-03-21 21:42:34 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:42:34 --> Model Class Initialized
DEBUG - 2025-03-21 21:42:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:42:34 --> Model Class Initialized
ERROR - 2025-03-21 21:42:34 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:42:34 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:42:34 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:42:34 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:42:34 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:42:34 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:42:34 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:42:34 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:42:34 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:43:34 --> Config Class Initialized
INFO - 2025-03-21 21:43:34 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:43:34 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:43:34 --> Utf8 Class Initialized
INFO - 2025-03-21 21:43:34 --> URI Class Initialized
DEBUG - 2025-03-21 21:43:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:43:34 --> Router Class Initialized
INFO - 2025-03-21 21:43:34 --> Output Class Initialized
INFO - 2025-03-21 21:43:34 --> Security Class Initialized
DEBUG - 2025-03-21 21:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:43:34 --> Input Class Initialized
INFO - 2025-03-21 21:43:34 --> Language Class Initialized
INFO - 2025-03-21 21:43:34 --> Language Class Initialized
INFO - 2025-03-21 21:43:34 --> Config Class Initialized
INFO - 2025-03-21 21:43:34 --> Loader Class Initialized
INFO - 2025-03-21 21:43:34 --> Helper loaded: url_helper
INFO - 2025-03-21 21:43:34 --> Helper loaded: file_helper
INFO - 2025-03-21 21:43:34 --> Helper loaded: html_helper
INFO - 2025-03-21 21:43:34 --> Helper loaded: form_helper
INFO - 2025-03-21 21:43:34 --> Helper loaded: text_helper
INFO - 2025-03-21 21:43:34 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:43:34 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:43:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:43:34 --> Database Driver Class Initialized
INFO - 2025-03-21 21:43:34 --> Email Class Initialized
INFO - 2025-03-21 21:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:43:34 --> Form Validation Class Initialized
INFO - 2025-03-21 21:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:43:34 --> Pagination Class Initialized
INFO - 2025-03-21 21:43:34 --> Controller Class Initialized
DEBUG - 2025-03-21 21:43:34 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:43:34 --> Model Class Initialized
DEBUG - 2025-03-21 21:43:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:43:34 --> Model Class Initialized
ERROR - 2025-03-21 21:43:34 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:43:34 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:43:34 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:43:34 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:43:34 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:43:34 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:43:34 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:43:34 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:43:34 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:44:29 --> Config Class Initialized
INFO - 2025-03-21 21:44:29 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:44:29 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:44:29 --> Utf8 Class Initialized
INFO - 2025-03-21 21:44:29 --> URI Class Initialized
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:44:29 --> Router Class Initialized
INFO - 2025-03-21 21:44:29 --> Output Class Initialized
INFO - 2025-03-21 21:44:29 --> Security Class Initialized
DEBUG - 2025-03-21 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:44:29 --> Input Class Initialized
INFO - 2025-03-21 21:44:29 --> Language Class Initialized
INFO - 2025-03-21 21:44:29 --> Language Class Initialized
INFO - 2025-03-21 21:44:29 --> Config Class Initialized
INFO - 2025-03-21 21:44:29 --> Loader Class Initialized
INFO - 2025-03-21 21:44:29 --> Helper loaded: url_helper
INFO - 2025-03-21 21:44:29 --> Helper loaded: file_helper
INFO - 2025-03-21 21:44:29 --> Helper loaded: html_helper
INFO - 2025-03-21 21:44:29 --> Helper loaded: form_helper
INFO - 2025-03-21 21:44:29 --> Helper loaded: text_helper
INFO - 2025-03-21 21:44:29 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:44:29 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:44:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:44:29 --> Database Driver Class Initialized
INFO - 2025-03-21 21:44:29 --> Email Class Initialized
INFO - 2025-03-21 21:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:44:29 --> Form Validation Class Initialized
INFO - 2025-03-21 21:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:44:29 --> Pagination Class Initialized
INFO - 2025-03-21 21:44:29 --> Controller Class Initialized
DEBUG - 2025-03-21 21:44:29 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:44:29 --> Model Class Initialized
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:44:29 --> Model Class Initialized
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:44:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:44:29 --> Model Class Initialized
ERROR - 2025-03-21 21:44:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:44:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:44:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:44:29 --> Final output sent to browser
DEBUG - 2025-03-21 21:44:29 --> Total execution time: 0.1048
INFO - 2025-03-21 21:44:30 --> Config Class Initialized
INFO - 2025-03-21 21:44:30 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:44:30 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:44:30 --> Utf8 Class Initialized
INFO - 2025-03-21 21:44:30 --> URI Class Initialized
DEBUG - 2025-03-21 21:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:44:30 --> Router Class Initialized
INFO - 2025-03-21 21:44:30 --> Output Class Initialized
INFO - 2025-03-21 21:44:30 --> Security Class Initialized
DEBUG - 2025-03-21 21:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:44:30 --> Input Class Initialized
INFO - 2025-03-21 21:44:30 --> Language Class Initialized
INFO - 2025-03-21 21:44:30 --> Language Class Initialized
INFO - 2025-03-21 21:44:30 --> Config Class Initialized
INFO - 2025-03-21 21:44:30 --> Loader Class Initialized
INFO - 2025-03-21 21:44:30 --> Helper loaded: url_helper
INFO - 2025-03-21 21:44:30 --> Helper loaded: file_helper
INFO - 2025-03-21 21:44:30 --> Helper loaded: html_helper
INFO - 2025-03-21 21:44:30 --> Helper loaded: form_helper
INFO - 2025-03-21 21:44:30 --> Helper loaded: text_helper
INFO - 2025-03-21 21:44:30 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:44:30 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:44:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:44:30 --> Database Driver Class Initialized
INFO - 2025-03-21 21:44:30 --> Email Class Initialized
INFO - 2025-03-21 21:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:44:30 --> Form Validation Class Initialized
INFO - 2025-03-21 21:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:44:30 --> Pagination Class Initialized
INFO - 2025-03-21 21:44:30 --> Controller Class Initialized
DEBUG - 2025-03-21 21:44:30 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:44:30 --> Model Class Initialized
DEBUG - 2025-03-21 21:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:44:30 --> Model Class Initialized
ERROR - 2025-03-21 21:44:30 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:44:30 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:44:30 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:44:30 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:44:30 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:44:30 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:44:30 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:44:30 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:44:30 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:44:34 --> Config Class Initialized
INFO - 2025-03-21 21:44:34 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:44:34 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:44:34 --> Utf8 Class Initialized
INFO - 2025-03-21 21:44:34 --> URI Class Initialized
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:44:34 --> Router Class Initialized
INFO - 2025-03-21 21:44:34 --> Output Class Initialized
INFO - 2025-03-21 21:44:34 --> Security Class Initialized
DEBUG - 2025-03-21 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:44:34 --> Input Class Initialized
INFO - 2025-03-21 21:44:34 --> Language Class Initialized
INFO - 2025-03-21 21:44:34 --> Language Class Initialized
INFO - 2025-03-21 21:44:34 --> Config Class Initialized
INFO - 2025-03-21 21:44:34 --> Loader Class Initialized
INFO - 2025-03-21 21:44:34 --> Helper loaded: url_helper
INFO - 2025-03-21 21:44:34 --> Helper loaded: file_helper
INFO - 2025-03-21 21:44:34 --> Helper loaded: html_helper
INFO - 2025-03-21 21:44:34 --> Helper loaded: form_helper
INFO - 2025-03-21 21:44:34 --> Helper loaded: text_helper
INFO - 2025-03-21 21:44:34 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:44:34 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:44:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:44:34 --> Database Driver Class Initialized
INFO - 2025-03-21 21:44:34 --> Email Class Initialized
INFO - 2025-03-21 21:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:44:34 --> Form Validation Class Initialized
INFO - 2025-03-21 21:44:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:44:34 --> Pagination Class Initialized
INFO - 2025-03-21 21:44:34 --> Controller Class Initialized
DEBUG - 2025-03-21 21:44:34 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:44:34 --> Model Class Initialized
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:44:34 --> Model Class Initialized
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:44:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:44:34 --> Model Class Initialized
ERROR - 2025-03-21 21:44:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:44:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:44:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:44:34 --> Final output sent to browser
DEBUG - 2025-03-21 21:44:34 --> Total execution time: 0.1320
INFO - 2025-03-21 21:44:35 --> Config Class Initialized
INFO - 2025-03-21 21:44:35 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:44:35 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:44:35 --> Utf8 Class Initialized
INFO - 2025-03-21 21:44:35 --> URI Class Initialized
DEBUG - 2025-03-21 21:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:44:35 --> Router Class Initialized
INFO - 2025-03-21 21:44:35 --> Output Class Initialized
INFO - 2025-03-21 21:44:35 --> Security Class Initialized
DEBUG - 2025-03-21 21:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:44:35 --> Input Class Initialized
INFO - 2025-03-21 21:44:35 --> Language Class Initialized
INFO - 2025-03-21 21:44:35 --> Language Class Initialized
INFO - 2025-03-21 21:44:35 --> Config Class Initialized
INFO - 2025-03-21 21:44:35 --> Loader Class Initialized
INFO - 2025-03-21 21:44:35 --> Helper loaded: url_helper
INFO - 2025-03-21 21:44:35 --> Helper loaded: file_helper
INFO - 2025-03-21 21:44:35 --> Helper loaded: html_helper
INFO - 2025-03-21 21:44:35 --> Helper loaded: form_helper
INFO - 2025-03-21 21:44:35 --> Helper loaded: text_helper
INFO - 2025-03-21 21:44:35 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:44:35 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:44:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:44:35 --> Database Driver Class Initialized
INFO - 2025-03-21 21:44:35 --> Email Class Initialized
INFO - 2025-03-21 21:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:44:35 --> Form Validation Class Initialized
INFO - 2025-03-21 21:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:44:35 --> Pagination Class Initialized
INFO - 2025-03-21 21:44:35 --> Controller Class Initialized
DEBUG - 2025-03-21 21:44:35 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:44:35 --> Model Class Initialized
DEBUG - 2025-03-21 21:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:44:35 --> Model Class Initialized
ERROR - 2025-03-21 21:44:35 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:44:35 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:44:35 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:44:35 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:44:35 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:44:35 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:44:35 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:44:35 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:44:35 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:45:29 --> Config Class Initialized
INFO - 2025-03-21 21:45:29 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:45:29 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:45:29 --> Utf8 Class Initialized
INFO - 2025-03-21 21:45:29 --> URI Class Initialized
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:45:29 --> Router Class Initialized
INFO - 2025-03-21 21:45:29 --> Output Class Initialized
INFO - 2025-03-21 21:45:29 --> Security Class Initialized
DEBUG - 2025-03-21 21:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:45:29 --> Input Class Initialized
INFO - 2025-03-21 21:45:29 --> Language Class Initialized
INFO - 2025-03-21 21:45:29 --> Language Class Initialized
INFO - 2025-03-21 21:45:29 --> Config Class Initialized
INFO - 2025-03-21 21:45:29 --> Loader Class Initialized
INFO - 2025-03-21 21:45:29 --> Helper loaded: url_helper
INFO - 2025-03-21 21:45:29 --> Helper loaded: file_helper
INFO - 2025-03-21 21:45:29 --> Helper loaded: html_helper
INFO - 2025-03-21 21:45:29 --> Helper loaded: form_helper
INFO - 2025-03-21 21:45:29 --> Helper loaded: text_helper
INFO - 2025-03-21 21:45:29 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:45:29 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:45:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:45:29 --> Database Driver Class Initialized
INFO - 2025-03-21 21:45:29 --> Email Class Initialized
INFO - 2025-03-21 21:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:45:29 --> Form Validation Class Initialized
INFO - 2025-03-21 21:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:45:29 --> Pagination Class Initialized
INFO - 2025-03-21 21:45:29 --> Controller Class Initialized
DEBUG - 2025-03-21 21:45:29 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:45:29 --> Model Class Initialized
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:45:29 --> Model Class Initialized
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:45:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:45:29 --> Model Class Initialized
ERROR - 2025-03-21 21:45:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:45:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:45:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:45:29 --> Final output sent to browser
DEBUG - 2025-03-21 21:45:29 --> Total execution time: 0.1416
INFO - 2025-03-21 21:45:30 --> Config Class Initialized
INFO - 2025-03-21 21:45:30 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:45:30 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:45:30 --> Utf8 Class Initialized
INFO - 2025-03-21 21:45:30 --> URI Class Initialized
DEBUG - 2025-03-21 21:45:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:45:30 --> Router Class Initialized
INFO - 2025-03-21 21:45:30 --> Output Class Initialized
INFO - 2025-03-21 21:45:30 --> Security Class Initialized
DEBUG - 2025-03-21 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:45:30 --> Input Class Initialized
INFO - 2025-03-21 21:45:30 --> Language Class Initialized
INFO - 2025-03-21 21:45:30 --> Language Class Initialized
INFO - 2025-03-21 21:45:30 --> Config Class Initialized
INFO - 2025-03-21 21:45:30 --> Loader Class Initialized
INFO - 2025-03-21 21:45:30 --> Helper loaded: url_helper
INFO - 2025-03-21 21:45:30 --> Helper loaded: file_helper
INFO - 2025-03-21 21:45:30 --> Helper loaded: html_helper
INFO - 2025-03-21 21:45:30 --> Helper loaded: form_helper
INFO - 2025-03-21 21:45:30 --> Helper loaded: text_helper
INFO - 2025-03-21 21:45:30 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:45:30 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:45:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:45:30 --> Database Driver Class Initialized
INFO - 2025-03-21 21:45:30 --> Email Class Initialized
INFO - 2025-03-21 21:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:45:30 --> Form Validation Class Initialized
INFO - 2025-03-21 21:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:45:30 --> Pagination Class Initialized
INFO - 2025-03-21 21:45:30 --> Controller Class Initialized
DEBUG - 2025-03-21 21:45:30 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:45:30 --> Model Class Initialized
DEBUG - 2025-03-21 21:45:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:45:30 --> Model Class Initialized
ERROR - 2025-03-21 21:45:30 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:45:30 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:45:30 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:45:30 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:45:30 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:45:30 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:45:30 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:45:30 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:45:30 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:47:38 --> Config Class Initialized
INFO - 2025-03-21 21:47:38 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:47:38 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:47:38 --> Utf8 Class Initialized
INFO - 2025-03-21 21:47:38 --> URI Class Initialized
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:47:38 --> Router Class Initialized
INFO - 2025-03-21 21:47:38 --> Output Class Initialized
INFO - 2025-03-21 21:47:38 --> Security Class Initialized
DEBUG - 2025-03-21 21:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:47:38 --> Input Class Initialized
INFO - 2025-03-21 21:47:38 --> Language Class Initialized
INFO - 2025-03-21 21:47:38 --> Language Class Initialized
INFO - 2025-03-21 21:47:38 --> Config Class Initialized
INFO - 2025-03-21 21:47:38 --> Loader Class Initialized
INFO - 2025-03-21 21:47:38 --> Helper loaded: url_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: file_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: html_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: form_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: text_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:47:38 --> Database Driver Class Initialized
INFO - 2025-03-21 21:47:38 --> Email Class Initialized
INFO - 2025-03-21 21:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:47:38 --> Form Validation Class Initialized
INFO - 2025-03-21 21:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:47:38 --> Pagination Class Initialized
INFO - 2025-03-21 21:47:38 --> Controller Class Initialized
DEBUG - 2025-03-21 21:47:38 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:47:38 --> Model Class Initialized
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:47:38 --> Model Class Initialized
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:47:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:47:38 --> Model Class Initialized
ERROR - 2025-03-21 21:47:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:47:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:47:38 --> Final output sent to browser
DEBUG - 2025-03-21 21:47:38 --> Total execution time: 0.1288
INFO - 2025-03-21 21:47:38 --> Config Class Initialized
INFO - 2025-03-21 21:47:38 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:47:38 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:47:38 --> Utf8 Class Initialized
INFO - 2025-03-21 21:47:38 --> URI Class Initialized
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:47:38 --> Router Class Initialized
INFO - 2025-03-21 21:47:38 --> Output Class Initialized
INFO - 2025-03-21 21:47:38 --> Security Class Initialized
DEBUG - 2025-03-21 21:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:47:38 --> Input Class Initialized
INFO - 2025-03-21 21:47:38 --> Language Class Initialized
INFO - 2025-03-21 21:47:38 --> Language Class Initialized
INFO - 2025-03-21 21:47:38 --> Config Class Initialized
INFO - 2025-03-21 21:47:38 --> Loader Class Initialized
INFO - 2025-03-21 21:47:38 --> Helper loaded: url_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: file_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: html_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: form_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: text_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:47:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:47:38 --> Database Driver Class Initialized
INFO - 2025-03-21 21:47:38 --> Email Class Initialized
INFO - 2025-03-21 21:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:47:38 --> Form Validation Class Initialized
INFO - 2025-03-21 21:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:47:38 --> Pagination Class Initialized
INFO - 2025-03-21 21:47:38 --> Controller Class Initialized
DEBUG - 2025-03-21 21:47:38 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:47:38 --> Model Class Initialized
DEBUG - 2025-03-21 21:47:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:47:38 --> Model Class Initialized
ERROR - 2025-03-21 21:47:38 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:47:38 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:47:38 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:47:38 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:47:38 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:47:38 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:47:38 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:47:38 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:47:38 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:48:28 --> Config Class Initialized
INFO - 2025-03-21 21:48:28 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:48:28 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:48:28 --> Utf8 Class Initialized
INFO - 2025-03-21 21:48:28 --> URI Class Initialized
DEBUG - 2025-03-21 21:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:48:28 --> Router Class Initialized
INFO - 2025-03-21 21:48:28 --> Output Class Initialized
INFO - 2025-03-21 21:48:28 --> Security Class Initialized
DEBUG - 2025-03-21 21:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:48:28 --> Input Class Initialized
INFO - 2025-03-21 21:48:28 --> Language Class Initialized
INFO - 2025-03-21 21:48:28 --> Language Class Initialized
INFO - 2025-03-21 21:48:28 --> Config Class Initialized
INFO - 2025-03-21 21:48:28 --> Loader Class Initialized
INFO - 2025-03-21 21:48:28 --> Helper loaded: url_helper
INFO - 2025-03-21 21:48:28 --> Helper loaded: file_helper
INFO - 2025-03-21 21:48:28 --> Helper loaded: html_helper
INFO - 2025-03-21 21:48:28 --> Helper loaded: form_helper
INFO - 2025-03-21 21:48:28 --> Helper loaded: text_helper
INFO - 2025-03-21 21:48:28 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:48:28 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:48:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:48:28 --> Database Driver Class Initialized
INFO - 2025-03-21 21:48:28 --> Email Class Initialized
INFO - 2025-03-21 21:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:48:28 --> Form Validation Class Initialized
INFO - 2025-03-21 21:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:48:28 --> Pagination Class Initialized
INFO - 2025-03-21 21:48:28 --> Controller Class Initialized
DEBUG - 2025-03-21 21:48:28 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:48:28 --> Model Class Initialized
DEBUG - 2025-03-21 21:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:48:28 --> Model Class Initialized
ERROR - 2025-03-21 21:48:28 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:48:28 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:48:28 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:48:28 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:48:28 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:48:28 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:48:28 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:48:28 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:48:28 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:48:39 --> Config Class Initialized
INFO - 2025-03-21 21:48:39 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:48:39 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:48:39 --> Utf8 Class Initialized
INFO - 2025-03-21 21:48:39 --> URI Class Initialized
DEBUG - 2025-03-21 21:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:48:39 --> Router Class Initialized
INFO - 2025-03-21 21:48:39 --> Output Class Initialized
INFO - 2025-03-21 21:48:39 --> Security Class Initialized
DEBUG - 2025-03-21 21:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:48:39 --> Input Class Initialized
INFO - 2025-03-21 21:48:39 --> Language Class Initialized
INFO - 2025-03-21 21:48:39 --> Language Class Initialized
INFO - 2025-03-21 21:48:39 --> Config Class Initialized
INFO - 2025-03-21 21:48:39 --> Loader Class Initialized
INFO - 2025-03-21 21:48:39 --> Helper loaded: url_helper
INFO - 2025-03-21 21:48:39 --> Helper loaded: file_helper
INFO - 2025-03-21 21:48:39 --> Helper loaded: html_helper
INFO - 2025-03-21 21:48:39 --> Helper loaded: form_helper
INFO - 2025-03-21 21:48:39 --> Helper loaded: text_helper
INFO - 2025-03-21 21:48:39 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:48:39 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:48:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:48:39 --> Database Driver Class Initialized
INFO - 2025-03-21 21:48:39 --> Email Class Initialized
INFO - 2025-03-21 21:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:48:39 --> Form Validation Class Initialized
INFO - 2025-03-21 21:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:48:39 --> Pagination Class Initialized
INFO - 2025-03-21 21:48:39 --> Controller Class Initialized
DEBUG - 2025-03-21 21:48:39 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:48:39 --> Model Class Initialized
DEBUG - 2025-03-21 21:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:48:39 --> Model Class Initialized
ERROR - 2025-03-21 21:48:39 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:48:39 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:48:39 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:48:39 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:48:39 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:48:39 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:48:39 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:48:39 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:48:39 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:55:57 --> Config Class Initialized
INFO - 2025-03-21 21:55:57 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:55:57 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:55:57 --> Utf8 Class Initialized
INFO - 2025-03-21 21:55:57 --> URI Class Initialized
DEBUG - 2025-03-21 21:55:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:55:57 --> Router Class Initialized
INFO - 2025-03-21 21:55:57 --> Output Class Initialized
INFO - 2025-03-21 21:55:57 --> Security Class Initialized
DEBUG - 2025-03-21 21:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:55:57 --> Input Class Initialized
INFO - 2025-03-21 21:55:57 --> Language Class Initialized
INFO - 2025-03-21 21:55:57 --> Language Class Initialized
INFO - 2025-03-21 21:55:57 --> Config Class Initialized
INFO - 2025-03-21 21:55:57 --> Loader Class Initialized
INFO - 2025-03-21 21:55:57 --> Helper loaded: url_helper
INFO - 2025-03-21 21:55:57 --> Helper loaded: file_helper
INFO - 2025-03-21 21:55:57 --> Helper loaded: html_helper
INFO - 2025-03-21 21:55:57 --> Helper loaded: form_helper
INFO - 2025-03-21 21:55:57 --> Helper loaded: text_helper
INFO - 2025-03-21 21:55:57 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:55:57 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:55:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:55:57 --> Database Driver Class Initialized
INFO - 2025-03-21 21:55:57 --> Email Class Initialized
INFO - 2025-03-21 21:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:55:57 --> Form Validation Class Initialized
INFO - 2025-03-21 21:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:55:57 --> Pagination Class Initialized
INFO - 2025-03-21 21:55:57 --> Controller Class Initialized
DEBUG - 2025-03-21 21:55:57 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:55:57 --> Model Class Initialized
DEBUG - 2025-03-21 21:55:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:55:57 --> Model Class Initialized
ERROR - 2025-03-21 21:55:57 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:55:57 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:55:57 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:55:57 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:55:57 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:55:57 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:55:57 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:55:57 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:55:57 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:56:05 --> Config Class Initialized
INFO - 2025-03-21 21:56:05 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:56:05 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:56:05 --> Utf8 Class Initialized
INFO - 2025-03-21 21:56:05 --> URI Class Initialized
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:56:05 --> Router Class Initialized
INFO - 2025-03-21 21:56:05 --> Output Class Initialized
INFO - 2025-03-21 21:56:05 --> Security Class Initialized
DEBUG - 2025-03-21 21:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:56:05 --> Input Class Initialized
INFO - 2025-03-21 21:56:05 --> Language Class Initialized
INFO - 2025-03-21 21:56:05 --> Language Class Initialized
INFO - 2025-03-21 21:56:05 --> Config Class Initialized
INFO - 2025-03-21 21:56:05 --> Loader Class Initialized
INFO - 2025-03-21 21:56:05 --> Helper loaded: url_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: file_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: html_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: form_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: text_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:56:05 --> Database Driver Class Initialized
INFO - 2025-03-21 21:56:05 --> Email Class Initialized
INFO - 2025-03-21 21:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:56:05 --> Form Validation Class Initialized
INFO - 2025-03-21 21:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:56:05 --> Pagination Class Initialized
INFO - 2025-03-21 21:56:05 --> Controller Class Initialized
DEBUG - 2025-03-21 21:56:05 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:56:05 --> Model Class Initialized
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:56:05 --> Model Class Initialized
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:56:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:56:05 --> Model Class Initialized
ERROR - 2025-03-21 21:56:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:56:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:56:05 --> Final output sent to browser
DEBUG - 2025-03-21 21:56:05 --> Total execution time: 0.2389
INFO - 2025-03-21 21:56:05 --> Config Class Initialized
INFO - 2025-03-21 21:56:05 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:56:05 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:56:05 --> Utf8 Class Initialized
INFO - 2025-03-21 21:56:05 --> URI Class Initialized
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:56:05 --> Router Class Initialized
INFO - 2025-03-21 21:56:05 --> Output Class Initialized
INFO - 2025-03-21 21:56:05 --> Security Class Initialized
DEBUG - 2025-03-21 21:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:56:05 --> Input Class Initialized
INFO - 2025-03-21 21:56:05 --> Language Class Initialized
INFO - 2025-03-21 21:56:05 --> Language Class Initialized
INFO - 2025-03-21 21:56:05 --> Config Class Initialized
INFO - 2025-03-21 21:56:05 --> Loader Class Initialized
INFO - 2025-03-21 21:56:05 --> Helper loaded: url_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: file_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: html_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: form_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: text_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:56:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:56:05 --> Database Driver Class Initialized
INFO - 2025-03-21 21:56:05 --> Email Class Initialized
INFO - 2025-03-21 21:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:56:05 --> Form Validation Class Initialized
INFO - 2025-03-21 21:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:56:05 --> Pagination Class Initialized
INFO - 2025-03-21 21:56:05 --> Controller Class Initialized
DEBUG - 2025-03-21 21:56:05 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:56:05 --> Model Class Initialized
DEBUG - 2025-03-21 21:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:56:05 --> Model Class Initialized
ERROR - 2025-03-21 21:56:05 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:56:05 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:56:05 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:56:05 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:56:05 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:56:05 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:56:05 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:56:05 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:56:05 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:56:10 --> Config Class Initialized
INFO - 2025-03-21 21:56:10 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:56:10 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:56:10 --> Utf8 Class Initialized
INFO - 2025-03-21 21:56:10 --> URI Class Initialized
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:56:10 --> Router Class Initialized
INFO - 2025-03-21 21:56:10 --> Output Class Initialized
INFO - 2025-03-21 21:56:10 --> Security Class Initialized
DEBUG - 2025-03-21 21:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:56:10 --> Input Class Initialized
INFO - 2025-03-21 21:56:10 --> Language Class Initialized
INFO - 2025-03-21 21:56:10 --> Language Class Initialized
INFO - 2025-03-21 21:56:10 --> Config Class Initialized
INFO - 2025-03-21 21:56:10 --> Loader Class Initialized
INFO - 2025-03-21 21:56:10 --> Helper loaded: url_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: file_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: html_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: form_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: text_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:56:10 --> Database Driver Class Initialized
INFO - 2025-03-21 21:56:10 --> Email Class Initialized
INFO - 2025-03-21 21:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:56:10 --> Form Validation Class Initialized
INFO - 2025-03-21 21:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:56:10 --> Pagination Class Initialized
INFO - 2025-03-21 21:56:10 --> Controller Class Initialized
DEBUG - 2025-03-21 21:56:10 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:56:10 --> Model Class Initialized
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:56:10 --> Model Class Initialized
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 21:56:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 21:56:10 --> Model Class Initialized
ERROR - 2025-03-21 21:56:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 21:56:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 21:56:10 --> Final output sent to browser
DEBUG - 2025-03-21 21:56:10 --> Total execution time: 0.0971
INFO - 2025-03-21 21:56:10 --> Config Class Initialized
INFO - 2025-03-21 21:56:10 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:56:10 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:56:10 --> Utf8 Class Initialized
INFO - 2025-03-21 21:56:10 --> URI Class Initialized
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:56:10 --> Router Class Initialized
INFO - 2025-03-21 21:56:10 --> Output Class Initialized
INFO - 2025-03-21 21:56:10 --> Security Class Initialized
DEBUG - 2025-03-21 21:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:56:10 --> Input Class Initialized
INFO - 2025-03-21 21:56:10 --> Language Class Initialized
INFO - 2025-03-21 21:56:10 --> Language Class Initialized
INFO - 2025-03-21 21:56:10 --> Config Class Initialized
INFO - 2025-03-21 21:56:10 --> Loader Class Initialized
INFO - 2025-03-21 21:56:10 --> Helper loaded: url_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: file_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: html_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: form_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: text_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:56:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:56:10 --> Database Driver Class Initialized
INFO - 2025-03-21 21:56:10 --> Email Class Initialized
INFO - 2025-03-21 21:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:56:10 --> Form Validation Class Initialized
INFO - 2025-03-21 21:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:56:10 --> Pagination Class Initialized
INFO - 2025-03-21 21:56:10 --> Controller Class Initialized
DEBUG - 2025-03-21 21:56:10 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:56:10 --> Model Class Initialized
DEBUG - 2025-03-21 21:56:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:56:10 --> Model Class Initialized
ERROR - 2025-03-21 21:56:10 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:56:10 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:56:10 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:56:10 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:56:10 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:56:10 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:56:10 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:56:10 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:56:10 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:56:57 --> Config Class Initialized
INFO - 2025-03-21 21:56:57 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:56:57 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:56:57 --> Utf8 Class Initialized
INFO - 2025-03-21 21:56:57 --> URI Class Initialized
DEBUG - 2025-03-21 21:56:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:56:57 --> Router Class Initialized
INFO - 2025-03-21 21:56:57 --> Output Class Initialized
INFO - 2025-03-21 21:56:57 --> Security Class Initialized
DEBUG - 2025-03-21 21:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:56:57 --> Input Class Initialized
INFO - 2025-03-21 21:56:57 --> Language Class Initialized
INFO - 2025-03-21 21:56:57 --> Language Class Initialized
INFO - 2025-03-21 21:56:57 --> Config Class Initialized
INFO - 2025-03-21 21:56:57 --> Loader Class Initialized
INFO - 2025-03-21 21:56:57 --> Helper loaded: url_helper
INFO - 2025-03-21 21:56:57 --> Helper loaded: file_helper
INFO - 2025-03-21 21:56:57 --> Helper loaded: html_helper
INFO - 2025-03-21 21:56:57 --> Helper loaded: form_helper
INFO - 2025-03-21 21:56:57 --> Helper loaded: text_helper
INFO - 2025-03-21 21:56:57 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:56:57 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:56:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:56:57 --> Database Driver Class Initialized
INFO - 2025-03-21 21:56:57 --> Email Class Initialized
INFO - 2025-03-21 21:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:56:57 --> Form Validation Class Initialized
INFO - 2025-03-21 21:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:56:57 --> Pagination Class Initialized
INFO - 2025-03-21 21:56:57 --> Controller Class Initialized
DEBUG - 2025-03-21 21:56:57 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:56:57 --> Model Class Initialized
DEBUG - 2025-03-21 21:56:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:56:57 --> Model Class Initialized
ERROR - 2025-03-21 21:56:57 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:56:57 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:56:57 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:56:57 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:56:57 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:56:57 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:56:57 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:56:57 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:56:57 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 21:59:05 --> Config Class Initialized
INFO - 2025-03-21 21:59:05 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:59:05 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:59:05 --> Utf8 Class Initialized
INFO - 2025-03-21 21:59:05 --> URI Class Initialized
DEBUG - 2025-03-21 21:59:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:59:05 --> Router Class Initialized
INFO - 2025-03-21 21:59:05 --> Output Class Initialized
INFO - 2025-03-21 21:59:05 --> Security Class Initialized
DEBUG - 2025-03-21 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:59:05 --> Input Class Initialized
INFO - 2025-03-21 21:59:05 --> Language Class Initialized
INFO - 2025-03-21 21:59:05 --> Language Class Initialized
INFO - 2025-03-21 21:59:05 --> Config Class Initialized
INFO - 2025-03-21 21:59:05 --> Loader Class Initialized
INFO - 2025-03-21 21:59:05 --> Helper loaded: url_helper
INFO - 2025-03-21 21:59:05 --> Helper loaded: file_helper
INFO - 2025-03-21 21:59:05 --> Helper loaded: html_helper
INFO - 2025-03-21 21:59:05 --> Helper loaded: form_helper
INFO - 2025-03-21 21:59:05 --> Helper loaded: text_helper
INFO - 2025-03-21 21:59:05 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:59:05 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:59:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:59:05 --> Database Driver Class Initialized
INFO - 2025-03-21 21:59:05 --> Email Class Initialized
INFO - 2025-03-21 21:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:59:05 --> Form Validation Class Initialized
INFO - 2025-03-21 21:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:59:05 --> Pagination Class Initialized
INFO - 2025-03-21 21:59:05 --> Controller Class Initialized
DEBUG - 2025-03-21 21:59:05 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:59:05 --> Model Class Initialized
DEBUG - 2025-03-21 21:59:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:59:05 --> Model Class Initialized
ERROR - 2025-03-21 21:59:05 --> ====== getCustomerList() START ======
ERROR - 2025-03-21 21:59:05 --> Input: customer_id = null
ERROR - 2025-03-21 21:59:05 --> Input: customfiled = null
ERROR - 2025-03-21 21:59:05 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 21:59:05 --> Pagination: start=0, length=-1
ERROR - 2025-03-21 21:59:05 --> Sorting: column=customer_name, order=asc
ERROR - 2025-03-21 21:59:05 --> Search Value: 
ERROR - 2025-03-21 21:59:05 --> Total Records in DB (no filter): 9
ERROR - 2025-03-21 21:59:05 --> LIMIT skipped — fetching all records.
ERROR - 2025-03-21 21:59:05 --> Records fetched: 6
ERROR - 2025-03-21 21:59:05 --> Prepared response row count: 6
ERROR - 2025-03-21 21:59:05 --> Final JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 21:59:05 --> ====== getCustomerList() END ======
INFO - 2025-03-21 21:59:33 --> Config Class Initialized
INFO - 2025-03-21 21:59:33 --> Hooks Class Initialized
DEBUG - 2025-03-21 21:59:33 --> UTF-8 Support Enabled
INFO - 2025-03-21 21:59:33 --> Utf8 Class Initialized
INFO - 2025-03-21 21:59:33 --> URI Class Initialized
DEBUG - 2025-03-21 21:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 21:59:33 --> Router Class Initialized
INFO - 2025-03-21 21:59:33 --> Output Class Initialized
INFO - 2025-03-21 21:59:33 --> Security Class Initialized
DEBUG - 2025-03-21 21:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 21:59:33 --> Input Class Initialized
INFO - 2025-03-21 21:59:33 --> Language Class Initialized
INFO - 2025-03-21 21:59:33 --> Language Class Initialized
INFO - 2025-03-21 21:59:33 --> Config Class Initialized
INFO - 2025-03-21 21:59:33 --> Loader Class Initialized
INFO - 2025-03-21 21:59:33 --> Helper loaded: url_helper
INFO - 2025-03-21 21:59:33 --> Helper loaded: file_helper
INFO - 2025-03-21 21:59:33 --> Helper loaded: html_helper
INFO - 2025-03-21 21:59:33 --> Helper loaded: form_helper
INFO - 2025-03-21 21:59:33 --> Helper loaded: text_helper
INFO - 2025-03-21 21:59:33 --> Helper loaded: lang_helper
INFO - 2025-03-21 21:59:33 --> Helper loaded: directory_helper
INFO - 2025-03-21 21:59:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 21:59:33 --> Database Driver Class Initialized
INFO - 2025-03-21 21:59:33 --> Email Class Initialized
INFO - 2025-03-21 21:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 21:59:33 --> Form Validation Class Initialized
INFO - 2025-03-21 21:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 21:59:33 --> Pagination Class Initialized
INFO - 2025-03-21 21:59:33 --> Controller Class Initialized
DEBUG - 2025-03-21 21:59:33 --> Customer MX_Controller Initialized
INFO - 2025-03-21 21:59:33 --> Model Class Initialized
DEBUG - 2025-03-21 21:59:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 21:59:33 --> Model Class Initialized
ERROR - 2025-03-21 21:59:33 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-21 21:59:33 --> DEBUG: Received customer_id = null
ERROR - 2025-03-21 21:59:33 --> DEBUG: Received customfiled = null
ERROR - 2025-03-21 21:59:33 --> DEBUG: Search Value = 
ERROR - 2025-03-21 21:59:33 --> DEBUG: Counting total records...
ERROR - 2025-03-21 21:59:33 --> DEBUG: Total Records = 9
ERROR - 2025-03-21 21:59:33 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-21 21:59:33 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"1742284328_deshi_shaad_fav1.png","zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-21 21:59:33 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-21 22:01:08 --> Config Class Initialized
INFO - 2025-03-21 22:01:08 --> Hooks Class Initialized
DEBUG - 2025-03-21 22:01:08 --> UTF-8 Support Enabled
INFO - 2025-03-21 22:01:08 --> Utf8 Class Initialized
INFO - 2025-03-21 22:01:08 --> URI Class Initialized
DEBUG - 2025-03-21 22:01:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 22:01:08 --> Router Class Initialized
INFO - 2025-03-21 22:01:08 --> Output Class Initialized
INFO - 2025-03-21 22:01:08 --> Security Class Initialized
DEBUG - 2025-03-21 22:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 22:01:08 --> Input Class Initialized
INFO - 2025-03-21 22:01:08 --> Language Class Initialized
INFO - 2025-03-21 22:01:08 --> Language Class Initialized
INFO - 2025-03-21 22:01:08 --> Config Class Initialized
INFO - 2025-03-21 22:01:08 --> Loader Class Initialized
INFO - 2025-03-21 22:01:08 --> Helper loaded: url_helper
INFO - 2025-03-21 22:01:08 --> Helper loaded: file_helper
INFO - 2025-03-21 22:01:08 --> Helper loaded: html_helper
INFO - 2025-03-21 22:01:08 --> Helper loaded: form_helper
INFO - 2025-03-21 22:01:08 --> Helper loaded: text_helper
INFO - 2025-03-21 22:01:08 --> Helper loaded: lang_helper
INFO - 2025-03-21 22:01:08 --> Helper loaded: directory_helper
INFO - 2025-03-21 22:01:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 22:01:08 --> Database Driver Class Initialized
INFO - 2025-03-21 22:01:08 --> Email Class Initialized
INFO - 2025-03-21 22:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 22:01:08 --> Form Validation Class Initialized
INFO - 2025-03-21 22:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 22:01:08 --> Pagination Class Initialized
INFO - 2025-03-21 22:01:08 --> Controller Class Initialized
DEBUG - 2025-03-21 22:01:08 --> Customer MX_Controller Initialized
INFO - 2025-03-21 22:01:08 --> Model Class Initialized
DEBUG - 2025-03-21 22:01:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 22:01:08 --> Model Class Initialized
ERROR - 2025-03-21 22:01:08 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 22:01:08 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 22:01:08 --> Received customer_id: null
ERROR - 2025-03-21 22:01:08 --> Received customfiled: null
ERROR - 2025-03-21 22:01:08 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 22:01:08 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 22:01:08 --> Search value: 
ERROR - 2025-03-21 22:01:08 --> Total unfiltered records: 9
ERROR - 2025-03-21 22:01:08 --> Fetching records from DB...
ERROR - 2025-03-21 22:01:08 --> No LIMIT applied — loading all records
ERROR - 2025-03-21 22:01:08 --> Records fetched from DB: 6
ERROR - 2025-03-21 22:01:08 --> Final data row count: 6
ERROR - 2025-03-21 22:01:08 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 22:01:08 --> ========= getCustomerList() END =========
INFO - 2025-03-21 22:01:12 --> Config Class Initialized
INFO - 2025-03-21 22:01:12 --> Hooks Class Initialized
DEBUG - 2025-03-21 22:01:12 --> UTF-8 Support Enabled
INFO - 2025-03-21 22:01:12 --> Utf8 Class Initialized
INFO - 2025-03-21 22:01:12 --> URI Class Initialized
DEBUG - 2025-03-21 22:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 22:01:12 --> Router Class Initialized
INFO - 2025-03-21 22:01:12 --> Output Class Initialized
INFO - 2025-03-21 22:01:12 --> Security Class Initialized
DEBUG - 2025-03-21 22:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 22:01:12 --> Input Class Initialized
INFO - 2025-03-21 22:01:12 --> Language Class Initialized
INFO - 2025-03-21 22:01:12 --> Language Class Initialized
INFO - 2025-03-21 22:01:12 --> Config Class Initialized
INFO - 2025-03-21 22:01:12 --> Loader Class Initialized
INFO - 2025-03-21 22:01:12 --> Helper loaded: url_helper
INFO - 2025-03-21 22:01:12 --> Helper loaded: file_helper
INFO - 2025-03-21 22:01:12 --> Helper loaded: html_helper
INFO - 2025-03-21 22:01:12 --> Helper loaded: form_helper
INFO - 2025-03-21 22:01:12 --> Helper loaded: text_helper
INFO - 2025-03-21 22:01:12 --> Helper loaded: lang_helper
INFO - 2025-03-21 22:01:12 --> Helper loaded: directory_helper
INFO - 2025-03-21 22:01:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 22:01:12 --> Database Driver Class Initialized
INFO - 2025-03-21 22:01:12 --> Email Class Initialized
INFO - 2025-03-21 22:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 22:01:12 --> Form Validation Class Initialized
INFO - 2025-03-21 22:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 22:01:12 --> Pagination Class Initialized
INFO - 2025-03-21 22:01:12 --> Controller Class Initialized
DEBUG - 2025-03-21 22:01:12 --> Customer MX_Controller Initialized
INFO - 2025-03-21 22:01:12 --> Model Class Initialized
DEBUG - 2025-03-21 22:01:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 22:01:12 --> Model Class Initialized
ERROR - 2025-03-21 22:01:12 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 22:01:12 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 22:01:12 --> Received customer_id: null
ERROR - 2025-03-21 22:01:12 --> Received customfiled: null
ERROR - 2025-03-21 22:01:12 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 22:01:12 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 22:01:12 --> Search value: 
ERROR - 2025-03-21 22:01:12 --> Total unfiltered records: 9
ERROR - 2025-03-21 22:01:12 --> Fetching records from DB...
ERROR - 2025-03-21 22:01:12 --> No LIMIT applied — loading all records
ERROR - 2025-03-21 22:01:12 --> Records fetched from DB: 6
ERROR - 2025-03-21 22:01:12 --> Final data row count: 6
ERROR - 2025-03-21 22:01:12 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 22:01:12 --> ========= getCustomerList() END =========
INFO - 2025-03-21 22:11:11 --> Config Class Initialized
INFO - 2025-03-21 22:11:11 --> Hooks Class Initialized
DEBUG - 2025-03-21 22:11:11 --> UTF-8 Support Enabled
INFO - 2025-03-21 22:11:11 --> Utf8 Class Initialized
INFO - 2025-03-21 22:11:11 --> URI Class Initialized
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 22:11:11 --> Router Class Initialized
INFO - 2025-03-21 22:11:11 --> Output Class Initialized
INFO - 2025-03-21 22:11:11 --> Security Class Initialized
DEBUG - 2025-03-21 22:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 22:11:11 --> Input Class Initialized
INFO - 2025-03-21 22:11:11 --> Language Class Initialized
INFO - 2025-03-21 22:11:11 --> Language Class Initialized
INFO - 2025-03-21 22:11:11 --> Config Class Initialized
INFO - 2025-03-21 22:11:11 --> Loader Class Initialized
INFO - 2025-03-21 22:11:11 --> Helper loaded: url_helper
INFO - 2025-03-21 22:11:11 --> Helper loaded: file_helper
INFO - 2025-03-21 22:11:11 --> Helper loaded: html_helper
INFO - 2025-03-21 22:11:11 --> Helper loaded: form_helper
INFO - 2025-03-21 22:11:11 --> Helper loaded: text_helper
INFO - 2025-03-21 22:11:11 --> Helper loaded: lang_helper
INFO - 2025-03-21 22:11:11 --> Helper loaded: directory_helper
INFO - 2025-03-21 22:11:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 22:11:11 --> Database Driver Class Initialized
INFO - 2025-03-21 22:11:11 --> Email Class Initialized
INFO - 2025-03-21 22:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 22:11:11 --> Form Validation Class Initialized
INFO - 2025-03-21 22:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 22:11:11 --> Pagination Class Initialized
INFO - 2025-03-21 22:11:11 --> Controller Class Initialized
DEBUG - 2025-03-21 22:11:11 --> Customer MX_Controller Initialized
INFO - 2025-03-21 22:11:11 --> Model Class Initialized
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 22:11:11 --> Model Class Initialized
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 22:11:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 22:11:11 --> Model Class Initialized
ERROR - 2025-03-21 22:11:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 22:11:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 22:11:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 22:11:11 --> Final output sent to browser
DEBUG - 2025-03-21 22:11:11 --> Total execution time: 0.1219
INFO - 2025-03-21 22:11:12 --> Config Class Initialized
INFO - 2025-03-21 22:11:12 --> Hooks Class Initialized
DEBUG - 2025-03-21 22:11:12 --> UTF-8 Support Enabled
INFO - 2025-03-21 22:11:12 --> Utf8 Class Initialized
INFO - 2025-03-21 22:11:12 --> URI Class Initialized
DEBUG - 2025-03-21 22:11:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 22:11:12 --> Router Class Initialized
INFO - 2025-03-21 22:11:12 --> Output Class Initialized
INFO - 2025-03-21 22:11:12 --> Security Class Initialized
DEBUG - 2025-03-21 22:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 22:11:12 --> Input Class Initialized
INFO - 2025-03-21 22:11:12 --> Language Class Initialized
INFO - 2025-03-21 22:11:12 --> Language Class Initialized
INFO - 2025-03-21 22:11:12 --> Config Class Initialized
INFO - 2025-03-21 22:11:12 --> Loader Class Initialized
INFO - 2025-03-21 22:11:12 --> Helper loaded: url_helper
INFO - 2025-03-21 22:11:12 --> Helper loaded: file_helper
INFO - 2025-03-21 22:11:12 --> Helper loaded: html_helper
INFO - 2025-03-21 22:11:12 --> Helper loaded: form_helper
INFO - 2025-03-21 22:11:12 --> Helper loaded: text_helper
INFO - 2025-03-21 22:11:12 --> Helper loaded: lang_helper
INFO - 2025-03-21 22:11:12 --> Helper loaded: directory_helper
INFO - 2025-03-21 22:11:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 22:11:12 --> Database Driver Class Initialized
INFO - 2025-03-21 22:11:12 --> Email Class Initialized
INFO - 2025-03-21 22:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 22:11:12 --> Form Validation Class Initialized
INFO - 2025-03-21 22:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 22:11:12 --> Pagination Class Initialized
INFO - 2025-03-21 22:11:12 --> Controller Class Initialized
DEBUG - 2025-03-21 22:11:12 --> Customer MX_Controller Initialized
INFO - 2025-03-21 22:11:12 --> Model Class Initialized
DEBUG - 2025-03-21 22:11:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 22:11:12 --> Model Class Initialized
ERROR - 2025-03-21 22:11:12 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 22:11:12 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 22:11:12 --> Received customer_id: null
ERROR - 2025-03-21 22:11:12 --> Received customfiled: null
ERROR - 2025-03-21 22:11:12 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 22:11:12 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 22:11:12 --> Search value: 
ERROR - 2025-03-21 22:11:12 --> Total unfiltered records: 9
ERROR - 2025-03-21 22:11:12 --> Fetching records from DB...
ERROR - 2025-03-21 22:11:12 --> No LIMIT applied — loading all records
ERROR - 2025-03-21 22:11:12 --> Records fetched from DB: 6
ERROR - 2025-03-21 22:11:12 --> Final data row count: 6
ERROR - 2025-03-21 22:11:12 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 22:11:12 --> ========= getCustomerList() END =========
INFO - 2025-03-21 22:11:20 --> Config Class Initialized
INFO - 2025-03-21 22:11:20 --> Hooks Class Initialized
DEBUG - 2025-03-21 22:11:20 --> UTF-8 Support Enabled
INFO - 2025-03-21 22:11:20 --> Utf8 Class Initialized
INFO - 2025-03-21 22:11:20 --> URI Class Initialized
DEBUG - 2025-03-21 22:11:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 22:11:20 --> Router Class Initialized
INFO - 2025-03-21 22:11:20 --> Output Class Initialized
INFO - 2025-03-21 22:11:20 --> Security Class Initialized
DEBUG - 2025-03-21 22:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 22:11:20 --> Input Class Initialized
INFO - 2025-03-21 22:11:20 --> Language Class Initialized
INFO - 2025-03-21 22:11:20 --> Language Class Initialized
INFO - 2025-03-21 22:11:20 --> Config Class Initialized
INFO - 2025-03-21 22:11:20 --> Loader Class Initialized
INFO - 2025-03-21 22:11:20 --> Helper loaded: url_helper
INFO - 2025-03-21 22:11:20 --> Helper loaded: file_helper
INFO - 2025-03-21 22:11:20 --> Helper loaded: html_helper
INFO - 2025-03-21 22:11:20 --> Helper loaded: form_helper
INFO - 2025-03-21 22:11:20 --> Helper loaded: text_helper
INFO - 2025-03-21 22:11:20 --> Helper loaded: lang_helper
INFO - 2025-03-21 22:11:20 --> Helper loaded: directory_helper
INFO - 2025-03-21 22:11:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 22:11:20 --> Database Driver Class Initialized
INFO - 2025-03-21 22:11:20 --> Email Class Initialized
INFO - 2025-03-21 22:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 22:11:20 --> Form Validation Class Initialized
INFO - 2025-03-21 22:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 22:11:20 --> Pagination Class Initialized
INFO - 2025-03-21 22:11:20 --> Controller Class Initialized
DEBUG - 2025-03-21 22:11:20 --> Customer MX_Controller Initialized
INFO - 2025-03-21 22:11:20 --> Model Class Initialized
DEBUG - 2025-03-21 22:11:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 22:11:20 --> Model Class Initialized
ERROR - 2025-03-21 22:11:20 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 22:11:20 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 22:11:20 --> Received customer_id: null
ERROR - 2025-03-21 22:11:20 --> Received customfiled: null
ERROR - 2025-03-21 22:11:20 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 22:11:20 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 22:11:20 --> Search value: 
ERROR - 2025-03-21 22:11:20 --> Total unfiltered records: 9
ERROR - 2025-03-21 22:11:20 --> Fetching records from DB...
ERROR - 2025-03-21 22:11:20 --> No LIMIT applied — loading all records
ERROR - 2025-03-21 22:11:20 --> Records fetched from DB: 6
ERROR - 2025-03-21 22:11:20 --> Final data row count: 6
ERROR - 2025-03-21 22:11:20 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 22:11:20 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:02:43 --> Config Class Initialized
INFO - 2025-03-21 23:02:43 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:02:43 --> Utf8 Class Initialized
INFO - 2025-03-21 23:02:43 --> URI Class Initialized
DEBUG - 2025-03-21 23:02:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:02:43 --> Router Class Initialized
INFO - 2025-03-21 23:02:43 --> Output Class Initialized
INFO - 2025-03-21 23:02:43 --> Security Class Initialized
DEBUG - 2025-03-21 23:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:02:43 --> Input Class Initialized
INFO - 2025-03-21 23:02:43 --> Language Class Initialized
INFO - 2025-03-21 23:02:43 --> Language Class Initialized
INFO - 2025-03-21 23:02:43 --> Config Class Initialized
INFO - 2025-03-21 23:02:43 --> Loader Class Initialized
INFO - 2025-03-21 23:02:43 --> Helper loaded: url_helper
INFO - 2025-03-21 23:02:43 --> Helper loaded: file_helper
INFO - 2025-03-21 23:02:43 --> Helper loaded: html_helper
INFO - 2025-03-21 23:02:43 --> Helper loaded: form_helper
INFO - 2025-03-21 23:02:43 --> Helper loaded: text_helper
INFO - 2025-03-21 23:02:43 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:02:43 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:02:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:02:43 --> Database Driver Class Initialized
INFO - 2025-03-21 23:02:43 --> Email Class Initialized
INFO - 2025-03-21 23:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:02:43 --> Form Validation Class Initialized
INFO - 2025-03-21 23:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:02:43 --> Pagination Class Initialized
INFO - 2025-03-21 23:02:43 --> Controller Class Initialized
DEBUG - 2025-03-21 23:02:43 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:02:43 --> Model Class Initialized
DEBUG - 2025-03-21 23:02:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:02:43 --> Model Class Initialized
DEBUG - 2025-03-21 23:02:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:02:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:02:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:02:43 --> Model Class Initialized
ERROR - 2025-03-21 23:02:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:02:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:02:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:02:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:02:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:02:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:02:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:02:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:02:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:02:44 --> Final output sent to browser
DEBUG - 2025-03-21 23:02:44 --> Total execution time: 0.6458
INFO - 2025-03-21 23:02:45 --> Config Class Initialized
INFO - 2025-03-21 23:02:45 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:02:45 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:02:45 --> Utf8 Class Initialized
INFO - 2025-03-21 23:02:45 --> URI Class Initialized
DEBUG - 2025-03-21 23:02:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:02:45 --> Router Class Initialized
INFO - 2025-03-21 23:02:45 --> Output Class Initialized
INFO - 2025-03-21 23:02:45 --> Security Class Initialized
DEBUG - 2025-03-21 23:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:02:45 --> Input Class Initialized
INFO - 2025-03-21 23:02:45 --> Language Class Initialized
INFO - 2025-03-21 23:02:45 --> Language Class Initialized
INFO - 2025-03-21 23:02:45 --> Config Class Initialized
INFO - 2025-03-21 23:02:45 --> Loader Class Initialized
INFO - 2025-03-21 23:02:45 --> Helper loaded: url_helper
INFO - 2025-03-21 23:02:45 --> Helper loaded: file_helper
INFO - 2025-03-21 23:02:45 --> Helper loaded: html_helper
INFO - 2025-03-21 23:02:45 --> Helper loaded: form_helper
INFO - 2025-03-21 23:02:45 --> Helper loaded: text_helper
INFO - 2025-03-21 23:02:45 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:02:45 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:02:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:02:45 --> Database Driver Class Initialized
INFO - 2025-03-21 23:02:45 --> Email Class Initialized
INFO - 2025-03-21 23:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:02:45 --> Form Validation Class Initialized
INFO - 2025-03-21 23:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:02:45 --> Pagination Class Initialized
INFO - 2025-03-21 23:02:45 --> Controller Class Initialized
DEBUG - 2025-03-21 23:02:45 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:02:45 --> Model Class Initialized
DEBUG - 2025-03-21 23:02:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:02:45 --> Model Class Initialized
ERROR - 2025-03-21 23:02:45 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:02:45 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:02:45 --> Received customer_id: null
ERROR - 2025-03-21 23:02:45 --> Received customfiled: null
ERROR - 2025-03-21 23:02:45 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:02:45 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:02:45 --> Search value: 
ERROR - 2025-03-21 23:02:45 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:02:45 --> Fetching records from DB...
ERROR - 2025-03-21 23:02:45 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:02:45 --> Records fetched from DB: 6
ERROR - 2025-03-21 23:02:45 --> Final data row count: 6
ERROR - 2025-03-21 23:02:45 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:02:45 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:02:53 --> Config Class Initialized
INFO - 2025-03-21 23:02:53 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:02:53 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:02:53 --> Utf8 Class Initialized
INFO - 2025-03-21 23:02:53 --> URI Class Initialized
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:02:53 --> Router Class Initialized
INFO - 2025-03-21 23:02:53 --> Output Class Initialized
INFO - 2025-03-21 23:02:53 --> Security Class Initialized
DEBUG - 2025-03-21 23:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:02:53 --> Input Class Initialized
INFO - 2025-03-21 23:02:53 --> Language Class Initialized
INFO - 2025-03-21 23:02:53 --> Language Class Initialized
INFO - 2025-03-21 23:02:53 --> Config Class Initialized
INFO - 2025-03-21 23:02:53 --> Loader Class Initialized
INFO - 2025-03-21 23:02:53 --> Helper loaded: url_helper
INFO - 2025-03-21 23:02:53 --> Helper loaded: file_helper
INFO - 2025-03-21 23:02:53 --> Helper loaded: html_helper
INFO - 2025-03-21 23:02:53 --> Helper loaded: form_helper
INFO - 2025-03-21 23:02:53 --> Helper loaded: text_helper
INFO - 2025-03-21 23:02:53 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:02:53 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:02:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:02:53 --> Database Driver Class Initialized
INFO - 2025-03-21 23:02:53 --> Email Class Initialized
INFO - 2025-03-21 23:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:02:53 --> Form Validation Class Initialized
INFO - 2025-03-21 23:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:02:53 --> Pagination Class Initialized
INFO - 2025-03-21 23:02:53 --> Controller Class Initialized
DEBUG - 2025-03-21 23:02:53 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:02:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:02:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:02:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:02:53 --> Model Class Initialized
ERROR - 2025-03-21 23:02:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:02:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:02:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:02:53 --> Final output sent to browser
DEBUG - 2025-03-21 23:02:53 --> Total execution time: 0.0991
INFO - 2025-03-21 23:02:54 --> Config Class Initialized
INFO - 2025-03-21 23:02:54 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:02:54 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:02:54 --> Utf8 Class Initialized
INFO - 2025-03-21 23:02:54 --> URI Class Initialized
DEBUG - 2025-03-21 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:02:54 --> Router Class Initialized
INFO - 2025-03-21 23:02:54 --> Output Class Initialized
INFO - 2025-03-21 23:02:54 --> Security Class Initialized
DEBUG - 2025-03-21 23:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:02:54 --> Input Class Initialized
INFO - 2025-03-21 23:02:54 --> Language Class Initialized
INFO - 2025-03-21 23:02:54 --> Language Class Initialized
INFO - 2025-03-21 23:02:54 --> Config Class Initialized
INFO - 2025-03-21 23:02:54 --> Loader Class Initialized
INFO - 2025-03-21 23:02:54 --> Helper loaded: url_helper
INFO - 2025-03-21 23:02:54 --> Helper loaded: file_helper
INFO - 2025-03-21 23:02:54 --> Helper loaded: html_helper
INFO - 2025-03-21 23:02:54 --> Helper loaded: form_helper
INFO - 2025-03-21 23:02:54 --> Helper loaded: text_helper
INFO - 2025-03-21 23:02:54 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:02:54 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:02:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:02:54 --> Database Driver Class Initialized
INFO - 2025-03-21 23:02:54 --> Email Class Initialized
INFO - 2025-03-21 23:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:02:54 --> Form Validation Class Initialized
INFO - 2025-03-21 23:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:02:54 --> Pagination Class Initialized
INFO - 2025-03-21 23:02:54 --> Controller Class Initialized
DEBUG - 2025-03-21 23:02:54 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:02:54 --> Model Class Initialized
DEBUG - 2025-03-21 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:02:54 --> Model Class Initialized
ERROR - 2025-03-21 23:02:54 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:02:54 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:02:54 --> Received customer_id: null
ERROR - 2025-03-21 23:02:54 --> Received customfiled: null
ERROR - 2025-03-21 23:02:54 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:02:54 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:02:54 --> Search value: 
ERROR - 2025-03-21 23:02:54 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:02:54 --> Fetching records from DB...
ERROR - 2025-03-21 23:02:54 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:02:54 --> Records fetched from DB: 6
ERROR - 2025-03-21 23:02:54 --> Final data row count: 6
ERROR - 2025-03-21 23:02:54 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:02:54 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:02:59 --> Config Class Initialized
INFO - 2025-03-21 23:02:59 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:02:59 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:02:59 --> Utf8 Class Initialized
INFO - 2025-03-21 23:02:59 --> URI Class Initialized
DEBUG - 2025-03-21 23:02:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:02:59 --> Router Class Initialized
INFO - 2025-03-21 23:02:59 --> Output Class Initialized
INFO - 2025-03-21 23:02:59 --> Security Class Initialized
DEBUG - 2025-03-21 23:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:02:59 --> Input Class Initialized
INFO - 2025-03-21 23:02:59 --> Language Class Initialized
INFO - 2025-03-21 23:02:59 --> Language Class Initialized
INFO - 2025-03-21 23:02:59 --> Config Class Initialized
INFO - 2025-03-21 23:02:59 --> Loader Class Initialized
INFO - 2025-03-21 23:02:59 --> Helper loaded: url_helper
INFO - 2025-03-21 23:02:59 --> Helper loaded: file_helper
INFO - 2025-03-21 23:02:59 --> Helper loaded: html_helper
INFO - 2025-03-21 23:02:59 --> Helper loaded: form_helper
INFO - 2025-03-21 23:02:59 --> Helper loaded: text_helper
INFO - 2025-03-21 23:02:59 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:02:59 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:02:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:02:59 --> Database Driver Class Initialized
INFO - 2025-03-21 23:02:59 --> Email Class Initialized
INFO - 2025-03-21 23:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:02:59 --> Form Validation Class Initialized
INFO - 2025-03-21 23:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:02:59 --> Pagination Class Initialized
INFO - 2025-03-21 23:02:59 --> Controller Class Initialized
DEBUG - 2025-03-21 23:02:59 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:02:59 --> Model Class Initialized
DEBUG - 2025-03-21 23:02:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:02:59 --> Model Class Initialized
ERROR - 2025-03-21 23:02:59 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:02:59 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:02:59 --> Received customer_id: null
ERROR - 2025-03-21 23:02:59 --> Received customfiled: null
ERROR - 2025-03-21 23:02:59 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:02:59 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:02:59 --> Search value: 
ERROR - 2025-03-21 23:02:59 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:02:59 --> Fetching records from DB...
ERROR - 2025-03-21 23:02:59 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:02:59 --> Records fetched from DB: 6
ERROR - 2025-03-21 23:02:59 --> Final data row count: 6
ERROR - 2025-03-21 23:02:59 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:02:59 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:03:57 --> Config Class Initialized
INFO - 2025-03-21 23:03:57 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:03:57 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:03:57 --> Utf8 Class Initialized
INFO - 2025-03-21 23:03:57 --> URI Class Initialized
DEBUG - 2025-03-21 23:03:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:03:57 --> Router Class Initialized
INFO - 2025-03-21 23:03:57 --> Output Class Initialized
INFO - 2025-03-21 23:03:57 --> Security Class Initialized
DEBUG - 2025-03-21 23:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:03:57 --> Input Class Initialized
INFO - 2025-03-21 23:03:57 --> Language Class Initialized
INFO - 2025-03-21 23:03:57 --> Language Class Initialized
INFO - 2025-03-21 23:03:57 --> Config Class Initialized
INFO - 2025-03-21 23:03:57 --> Loader Class Initialized
INFO - 2025-03-21 23:03:57 --> Helper loaded: url_helper
INFO - 2025-03-21 23:03:57 --> Helper loaded: file_helper
INFO - 2025-03-21 23:03:57 --> Helper loaded: html_helper
INFO - 2025-03-21 23:03:57 --> Helper loaded: form_helper
INFO - 2025-03-21 23:03:57 --> Helper loaded: text_helper
INFO - 2025-03-21 23:03:57 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:03:57 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:03:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:03:57 --> Database Driver Class Initialized
INFO - 2025-03-21 23:03:57 --> Email Class Initialized
INFO - 2025-03-21 23:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:03:57 --> Form Validation Class Initialized
INFO - 2025-03-21 23:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:03:57 --> Pagination Class Initialized
INFO - 2025-03-21 23:03:57 --> Controller Class Initialized
DEBUG - 2025-03-21 23:03:57 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:03:57 --> Model Class Initialized
DEBUG - 2025-03-21 23:03:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:03:57 --> Model Class Initialized
ERROR - 2025-03-21 23:03:57 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:03:57 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:03:57 --> Received customer_id: null
ERROR - 2025-03-21 23:03:57 --> Received customfiled: null
ERROR - 2025-03-21 23:03:57 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:03:57 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:03:57 --> Search value: 
ERROR - 2025-03-21 23:03:57 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:03:57 --> Fetching records from DB...
ERROR - 2025-03-21 23:03:57 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:03:57 --> Records fetched from DB: 6
ERROR - 2025-03-21 23:03:57 --> Final data row count: 6
ERROR - 2025-03-21 23:03:57 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:03:57 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:05:29 --> Config Class Initialized
INFO - 2025-03-21 23:05:29 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:05:29 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:05:29 --> Utf8 Class Initialized
INFO - 2025-03-21 23:05:29 --> URI Class Initialized
DEBUG - 2025-03-21 23:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:05:29 --> Router Class Initialized
INFO - 2025-03-21 23:05:29 --> Output Class Initialized
INFO - 2025-03-21 23:05:29 --> Security Class Initialized
DEBUG - 2025-03-21 23:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:05:29 --> Input Class Initialized
INFO - 2025-03-21 23:05:29 --> Language Class Initialized
INFO - 2025-03-21 23:05:29 --> Language Class Initialized
INFO - 2025-03-21 23:05:29 --> Config Class Initialized
INFO - 2025-03-21 23:05:29 --> Loader Class Initialized
INFO - 2025-03-21 23:05:29 --> Helper loaded: url_helper
INFO - 2025-03-21 23:05:29 --> Helper loaded: file_helper
INFO - 2025-03-21 23:05:29 --> Helper loaded: html_helper
INFO - 2025-03-21 23:05:29 --> Helper loaded: form_helper
INFO - 2025-03-21 23:05:29 --> Helper loaded: text_helper
INFO - 2025-03-21 23:05:29 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:05:29 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:05:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:05:29 --> Database Driver Class Initialized
INFO - 2025-03-21 23:05:29 --> Email Class Initialized
INFO - 2025-03-21 23:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:05:29 --> Form Validation Class Initialized
INFO - 2025-03-21 23:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:05:29 --> Pagination Class Initialized
INFO - 2025-03-21 23:05:29 --> Controller Class Initialized
DEBUG - 2025-03-21 23:05:29 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:05:29 --> Model Class Initialized
DEBUG - 2025-03-21 23:05:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:05:29 --> Model Class Initialized
ERROR - 2025-03-21 23:05:29 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:05:29 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:05:29 --> Received customer_id: null
ERROR - 2025-03-21 23:05:29 --> Received customfiled: null
ERROR - 2025-03-21 23:05:29 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:05:29 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:05:29 --> Search value: 
ERROR - 2025-03-21 23:05:29 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:05:29 --> Fetching records from DB...
ERROR - 2025-03-21 23:05:29 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:05:29 --> Records fetched from DB: 6
ERROR - 2025-03-21 23:05:29 --> Final data row count: 6
ERROR - 2025-03-21 23:05:29 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:05:29 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:05:53 --> Config Class Initialized
INFO - 2025-03-21 23:05:53 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:05:53 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:05:53 --> Utf8 Class Initialized
INFO - 2025-03-21 23:05:53 --> URI Class Initialized
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:05:53 --> Router Class Initialized
INFO - 2025-03-21 23:05:53 --> Output Class Initialized
INFO - 2025-03-21 23:05:53 --> Security Class Initialized
DEBUG - 2025-03-21 23:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:05:53 --> Input Class Initialized
INFO - 2025-03-21 23:05:53 --> Language Class Initialized
INFO - 2025-03-21 23:05:53 --> Language Class Initialized
INFO - 2025-03-21 23:05:53 --> Config Class Initialized
INFO - 2025-03-21 23:05:53 --> Loader Class Initialized
INFO - 2025-03-21 23:05:53 --> Helper loaded: url_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: file_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: html_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: form_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: text_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:05:53 --> Database Driver Class Initialized
INFO - 2025-03-21 23:05:53 --> Email Class Initialized
INFO - 2025-03-21 23:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:05:53 --> Form Validation Class Initialized
INFO - 2025-03-21 23:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:05:53 --> Pagination Class Initialized
INFO - 2025-03-21 23:05:53 --> Controller Class Initialized
DEBUG - 2025-03-21 23:05:53 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:05:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:05:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:05:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:05:53 --> Model Class Initialized
ERROR - 2025-03-21 23:05:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:05:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:05:53 --> Final output sent to browser
DEBUG - 2025-03-21 23:05:53 --> Total execution time: 0.1332
INFO - 2025-03-21 23:05:53 --> Config Class Initialized
INFO - 2025-03-21 23:05:53 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:05:53 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:05:53 --> Utf8 Class Initialized
INFO - 2025-03-21 23:05:53 --> URI Class Initialized
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:05:53 --> Router Class Initialized
INFO - 2025-03-21 23:05:53 --> Output Class Initialized
INFO - 2025-03-21 23:05:53 --> Security Class Initialized
DEBUG - 2025-03-21 23:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:05:53 --> Input Class Initialized
INFO - 2025-03-21 23:05:53 --> Language Class Initialized
INFO - 2025-03-21 23:05:53 --> Language Class Initialized
INFO - 2025-03-21 23:05:53 --> Config Class Initialized
INFO - 2025-03-21 23:05:53 --> Loader Class Initialized
INFO - 2025-03-21 23:05:53 --> Helper loaded: url_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: file_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: html_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: form_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: text_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:05:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:05:53 --> Database Driver Class Initialized
INFO - 2025-03-21 23:05:53 --> Email Class Initialized
INFO - 2025-03-21 23:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:05:53 --> Form Validation Class Initialized
INFO - 2025-03-21 23:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:05:53 --> Pagination Class Initialized
INFO - 2025-03-21 23:05:53 --> Controller Class Initialized
DEBUG - 2025-03-21 23:05:53 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:05:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:05:53 --> Model Class Initialized
ERROR - 2025-03-21 23:05:53 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:05:53 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:05:53 --> Received customer_id: null
ERROR - 2025-03-21 23:05:53 --> Received customfiled: null
ERROR - 2025-03-21 23:05:53 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:05:53 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:05:53 --> Search value: 
ERROR - 2025-03-21 23:05:53 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:05:53 --> Fetching records from DB...
ERROR - 2025-03-21 23:05:53 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:05:53 --> Records fetched from DB: 6
ERROR - 2025-03-21 23:05:53 --> Final data row count: 6
ERROR - 2025-03-21 23:05:53 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:05:53 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:06:09 --> Config Class Initialized
INFO - 2025-03-21 23:06:09 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:06:09 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:06:09 --> Utf8 Class Initialized
INFO - 2025-03-21 23:06:09 --> URI Class Initialized
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:06:09 --> Router Class Initialized
INFO - 2025-03-21 23:06:09 --> Output Class Initialized
INFO - 2025-03-21 23:06:09 --> Security Class Initialized
DEBUG - 2025-03-21 23:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:06:09 --> Input Class Initialized
INFO - 2025-03-21 23:06:09 --> Language Class Initialized
INFO - 2025-03-21 23:06:09 --> Language Class Initialized
INFO - 2025-03-21 23:06:09 --> Config Class Initialized
INFO - 2025-03-21 23:06:09 --> Loader Class Initialized
INFO - 2025-03-21 23:06:09 --> Helper loaded: url_helper
INFO - 2025-03-21 23:06:09 --> Helper loaded: file_helper
INFO - 2025-03-21 23:06:09 --> Helper loaded: html_helper
INFO - 2025-03-21 23:06:09 --> Helper loaded: form_helper
INFO - 2025-03-21 23:06:09 --> Helper loaded: text_helper
INFO - 2025-03-21 23:06:09 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:06:09 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:06:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:06:09 --> Database Driver Class Initialized
INFO - 2025-03-21 23:06:09 --> Email Class Initialized
INFO - 2025-03-21 23:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:06:09 --> Form Validation Class Initialized
INFO - 2025-03-21 23:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:06:09 --> Pagination Class Initialized
INFO - 2025-03-21 23:06:09 --> Controller Class Initialized
DEBUG - 2025-03-21 23:06:09 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:06:09 --> Model Class Initialized
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:06:09 --> Model Class Initialized
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:06:09 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:06:09 --> Model Class Initialized
ERROR - 2025-03-21 23:06:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:06:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:06:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:06:09 --> Final output sent to browser
DEBUG - 2025-03-21 23:06:09 --> Total execution time: 0.1122
INFO - 2025-03-21 23:06:10 --> Config Class Initialized
INFO - 2025-03-21 23:06:10 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:06:10 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:06:10 --> Utf8 Class Initialized
INFO - 2025-03-21 23:06:10 --> URI Class Initialized
DEBUG - 2025-03-21 23:06:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:06:10 --> Router Class Initialized
INFO - 2025-03-21 23:06:10 --> Output Class Initialized
INFO - 2025-03-21 23:06:10 --> Security Class Initialized
DEBUG - 2025-03-21 23:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:06:10 --> Input Class Initialized
INFO - 2025-03-21 23:06:10 --> Language Class Initialized
INFO - 2025-03-21 23:06:10 --> Language Class Initialized
INFO - 2025-03-21 23:06:10 --> Config Class Initialized
INFO - 2025-03-21 23:06:10 --> Loader Class Initialized
INFO - 2025-03-21 23:06:10 --> Helper loaded: url_helper
INFO - 2025-03-21 23:06:10 --> Helper loaded: file_helper
INFO - 2025-03-21 23:06:10 --> Helper loaded: html_helper
INFO - 2025-03-21 23:06:10 --> Helper loaded: form_helper
INFO - 2025-03-21 23:06:10 --> Helper loaded: text_helper
INFO - 2025-03-21 23:06:10 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:06:10 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:06:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:06:10 --> Database Driver Class Initialized
INFO - 2025-03-21 23:06:10 --> Email Class Initialized
INFO - 2025-03-21 23:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:06:10 --> Form Validation Class Initialized
INFO - 2025-03-21 23:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:06:10 --> Pagination Class Initialized
INFO - 2025-03-21 23:06:10 --> Controller Class Initialized
DEBUG - 2025-03-21 23:06:10 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:06:10 --> Model Class Initialized
DEBUG - 2025-03-21 23:06:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:06:10 --> Model Class Initialized
ERROR - 2025-03-21 23:06:10 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:06:10 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:06:10 --> Received customer_id: null
ERROR - 2025-03-21 23:06:10 --> Received customfiled: null
ERROR - 2025-03-21 23:06:10 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:06:10 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:06:10 --> Search value: 
ERROR - 2025-03-21 23:06:10 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:06:10 --> Fetching records from DB...
ERROR - 2025-03-21 23:06:10 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:06:10 --> Records fetched from DB: 6
ERROR - 2025-03-21 23:06:10 --> Final data row count: 6
ERROR - 2025-03-21 23:06:10 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":6,"aaData":[{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:06:10 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:11:25 --> Config Class Initialized
INFO - 2025-03-21 23:11:25 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:11:25 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:11:25 --> Utf8 Class Initialized
INFO - 2025-03-21 23:11:25 --> URI Class Initialized
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:11:25 --> Router Class Initialized
INFO - 2025-03-21 23:11:25 --> Output Class Initialized
INFO - 2025-03-21 23:11:25 --> Security Class Initialized
DEBUG - 2025-03-21 23:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:11:25 --> Input Class Initialized
INFO - 2025-03-21 23:11:25 --> Language Class Initialized
INFO - 2025-03-21 23:11:25 --> Language Class Initialized
INFO - 2025-03-21 23:11:25 --> Config Class Initialized
INFO - 2025-03-21 23:11:25 --> Loader Class Initialized
INFO - 2025-03-21 23:11:25 --> Helper loaded: url_helper
INFO - 2025-03-21 23:11:25 --> Helper loaded: file_helper
INFO - 2025-03-21 23:11:25 --> Helper loaded: html_helper
INFO - 2025-03-21 23:11:25 --> Helper loaded: form_helper
INFO - 2025-03-21 23:11:25 --> Helper loaded: text_helper
INFO - 2025-03-21 23:11:25 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:11:25 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:11:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:11:25 --> Database Driver Class Initialized
INFO - 2025-03-21 23:11:25 --> Email Class Initialized
INFO - 2025-03-21 23:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:11:25 --> Form Validation Class Initialized
INFO - 2025-03-21 23:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:11:25 --> Pagination Class Initialized
INFO - 2025-03-21 23:11:25 --> Controller Class Initialized
DEBUG - 2025-03-21 23:11:25 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:11:25 --> Model Class Initialized
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:11:25 --> Model Class Initialized
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:11:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:11:25 --> Model Class Initialized
ERROR - 2025-03-21 23:11:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:11:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:11:25 --> Final output sent to browser
DEBUG - 2025-03-21 23:11:25 --> Total execution time: 0.1105
INFO - 2025-03-21 23:11:26 --> Config Class Initialized
INFO - 2025-03-21 23:11:26 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:11:26 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:11:26 --> Utf8 Class Initialized
INFO - 2025-03-21 23:11:26 --> URI Class Initialized
DEBUG - 2025-03-21 23:11:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:11:26 --> Router Class Initialized
INFO - 2025-03-21 23:11:26 --> Output Class Initialized
INFO - 2025-03-21 23:11:26 --> Security Class Initialized
DEBUG - 2025-03-21 23:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:11:26 --> Input Class Initialized
INFO - 2025-03-21 23:11:26 --> Language Class Initialized
INFO - 2025-03-21 23:11:26 --> Language Class Initialized
INFO - 2025-03-21 23:11:26 --> Config Class Initialized
INFO - 2025-03-21 23:11:26 --> Loader Class Initialized
INFO - 2025-03-21 23:11:26 --> Helper loaded: url_helper
INFO - 2025-03-21 23:11:26 --> Helper loaded: file_helper
INFO - 2025-03-21 23:11:26 --> Helper loaded: html_helper
INFO - 2025-03-21 23:11:26 --> Helper loaded: form_helper
INFO - 2025-03-21 23:11:26 --> Helper loaded: text_helper
INFO - 2025-03-21 23:11:26 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:11:26 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:11:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:11:26 --> Database Driver Class Initialized
INFO - 2025-03-21 23:11:26 --> Email Class Initialized
INFO - 2025-03-21 23:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:11:26 --> Form Validation Class Initialized
INFO - 2025-03-21 23:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:11:26 --> Pagination Class Initialized
INFO - 2025-03-21 23:11:26 --> Controller Class Initialized
DEBUG - 2025-03-21 23:11:26 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:11:26 --> Model Class Initialized
DEBUG - 2025-03-21 23:11:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:11:26 --> Model Class Initialized
ERROR - 2025-03-21 23:11:26 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:11:26 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:11:26 --> Received customer_id: null
ERROR - 2025-03-21 23:11:26 --> Received customfiled: null
ERROR - 2025-03-21 23:11:26 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:11:26 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:11:26 --> Search value: 
ERROR - 2025-03-21 23:11:26 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:11:26 --> Fetching records from DB...
ERROR - 2025-03-21 23:11:26 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:11:26 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:11:26 --> Final data row count: 9
ERROR - 2025-03-21 23:11:26 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:11:26 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:12:13 --> Config Class Initialized
INFO - 2025-03-21 23:12:13 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:12:13 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:12:13 --> Utf8 Class Initialized
INFO - 2025-03-21 23:12:13 --> URI Class Initialized
DEBUG - 2025-03-21 23:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:12:13 --> Router Class Initialized
INFO - 2025-03-21 23:12:13 --> Output Class Initialized
INFO - 2025-03-21 23:12:13 --> Security Class Initialized
DEBUG - 2025-03-21 23:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:12:13 --> Input Class Initialized
INFO - 2025-03-21 23:12:13 --> Language Class Initialized
INFO - 2025-03-21 23:12:13 --> Language Class Initialized
INFO - 2025-03-21 23:12:13 --> Config Class Initialized
INFO - 2025-03-21 23:12:13 --> Loader Class Initialized
INFO - 2025-03-21 23:12:13 --> Helper loaded: url_helper
INFO - 2025-03-21 23:12:13 --> Helper loaded: file_helper
INFO - 2025-03-21 23:12:13 --> Helper loaded: html_helper
INFO - 2025-03-21 23:12:13 --> Helper loaded: form_helper
INFO - 2025-03-21 23:12:13 --> Helper loaded: text_helper
INFO - 2025-03-21 23:12:13 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:12:13 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:12:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:12:13 --> Database Driver Class Initialized
INFO - 2025-03-21 23:12:13 --> Email Class Initialized
INFO - 2025-03-21 23:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:12:13 --> Form Validation Class Initialized
INFO - 2025-03-21 23:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:12:13 --> Pagination Class Initialized
INFO - 2025-03-21 23:12:13 --> Controller Class Initialized
DEBUG - 2025-03-21 23:12:13 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:12:13 --> Model Class Initialized
DEBUG - 2025-03-21 23:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:12:13 --> Model Class Initialized
DEBUG - 2025-03-21 23:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:12:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:12:13 --> Model Class Initialized
ERROR - 2025-03-21 23:12:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:12:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:12:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:12:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:12:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:12:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:12:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:12:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:12:14 --> Final output sent to browser
DEBUG - 2025-03-21 23:12:14 --> Total execution time: 0.1365
INFO - 2025-03-21 23:12:14 --> Config Class Initialized
INFO - 2025-03-21 23:12:14 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:12:14 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:12:14 --> Utf8 Class Initialized
INFO - 2025-03-21 23:12:14 --> URI Class Initialized
DEBUG - 2025-03-21 23:12:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:12:14 --> Router Class Initialized
INFO - 2025-03-21 23:12:14 --> Output Class Initialized
INFO - 2025-03-21 23:12:14 --> Security Class Initialized
DEBUG - 2025-03-21 23:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:12:14 --> Input Class Initialized
INFO - 2025-03-21 23:12:14 --> Language Class Initialized
INFO - 2025-03-21 23:12:14 --> Language Class Initialized
INFO - 2025-03-21 23:12:14 --> Config Class Initialized
INFO - 2025-03-21 23:12:14 --> Loader Class Initialized
INFO - 2025-03-21 23:12:14 --> Helper loaded: url_helper
INFO - 2025-03-21 23:12:14 --> Helper loaded: file_helper
INFO - 2025-03-21 23:12:14 --> Helper loaded: html_helper
INFO - 2025-03-21 23:12:14 --> Helper loaded: form_helper
INFO - 2025-03-21 23:12:14 --> Helper loaded: text_helper
INFO - 2025-03-21 23:12:14 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:12:14 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:12:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:12:14 --> Database Driver Class Initialized
INFO - 2025-03-21 23:12:14 --> Email Class Initialized
INFO - 2025-03-21 23:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:12:14 --> Form Validation Class Initialized
INFO - 2025-03-21 23:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:12:14 --> Pagination Class Initialized
INFO - 2025-03-21 23:12:14 --> Controller Class Initialized
DEBUG - 2025-03-21 23:12:14 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:12:14 --> Model Class Initialized
DEBUG - 2025-03-21 23:12:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:12:14 --> Model Class Initialized
ERROR - 2025-03-21 23:12:14 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:12:14 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:12:14 --> Received customer_id: null
ERROR - 2025-03-21 23:12:14 --> Received customfiled: null
ERROR - 2025-03-21 23:12:14 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:12:14 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:12:14 --> Search value: 
ERROR - 2025-03-21 23:12:14 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:12:14 --> Fetching records from DB...
ERROR - 2025-03-21 23:12:14 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:12:14 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:12:14 --> Final data row count: 9
ERROR - 2025-03-21 23:12:14 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:12:14 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:12:20 --> Config Class Initialized
INFO - 2025-03-21 23:12:20 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:12:20 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:12:20 --> Utf8 Class Initialized
INFO - 2025-03-21 23:12:20 --> URI Class Initialized
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:12:20 --> Router Class Initialized
INFO - 2025-03-21 23:12:20 --> Output Class Initialized
INFO - 2025-03-21 23:12:20 --> Security Class Initialized
DEBUG - 2025-03-21 23:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:12:20 --> Input Class Initialized
INFO - 2025-03-21 23:12:20 --> Language Class Initialized
INFO - 2025-03-21 23:12:20 --> Language Class Initialized
INFO - 2025-03-21 23:12:20 --> Config Class Initialized
INFO - 2025-03-21 23:12:20 --> Loader Class Initialized
INFO - 2025-03-21 23:12:20 --> Helper loaded: url_helper
INFO - 2025-03-21 23:12:20 --> Helper loaded: file_helper
INFO - 2025-03-21 23:12:20 --> Helper loaded: html_helper
INFO - 2025-03-21 23:12:20 --> Helper loaded: form_helper
INFO - 2025-03-21 23:12:20 --> Helper loaded: text_helper
INFO - 2025-03-21 23:12:20 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:12:20 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:12:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:12:20 --> Database Driver Class Initialized
INFO - 2025-03-21 23:12:20 --> Email Class Initialized
INFO - 2025-03-21 23:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:12:20 --> Form Validation Class Initialized
INFO - 2025-03-21 23:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:12:20 --> Pagination Class Initialized
INFO - 2025-03-21 23:12:20 --> Controller Class Initialized
DEBUG - 2025-03-21 23:12:20 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:12:20 --> Model Class Initialized
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:12:20 --> Model Class Initialized
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:12:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:12:20 --> Model Class Initialized
ERROR - 2025-03-21 23:12:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:12:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:12:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:12:20 --> Final output sent to browser
DEBUG - 2025-03-21 23:12:20 --> Total execution time: 0.1247
INFO - 2025-03-21 23:12:21 --> Config Class Initialized
INFO - 2025-03-21 23:12:21 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:12:21 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:12:21 --> Utf8 Class Initialized
INFO - 2025-03-21 23:12:21 --> URI Class Initialized
DEBUG - 2025-03-21 23:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:12:21 --> Router Class Initialized
INFO - 2025-03-21 23:12:21 --> Output Class Initialized
INFO - 2025-03-21 23:12:21 --> Security Class Initialized
DEBUG - 2025-03-21 23:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:12:21 --> Input Class Initialized
INFO - 2025-03-21 23:12:21 --> Language Class Initialized
INFO - 2025-03-21 23:12:21 --> Language Class Initialized
INFO - 2025-03-21 23:12:21 --> Config Class Initialized
INFO - 2025-03-21 23:12:21 --> Loader Class Initialized
INFO - 2025-03-21 23:12:21 --> Helper loaded: url_helper
INFO - 2025-03-21 23:12:21 --> Helper loaded: file_helper
INFO - 2025-03-21 23:12:21 --> Helper loaded: html_helper
INFO - 2025-03-21 23:12:21 --> Helper loaded: form_helper
INFO - 2025-03-21 23:12:21 --> Helper loaded: text_helper
INFO - 2025-03-21 23:12:21 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:12:21 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:12:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:12:21 --> Database Driver Class Initialized
INFO - 2025-03-21 23:12:21 --> Email Class Initialized
INFO - 2025-03-21 23:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:12:21 --> Form Validation Class Initialized
INFO - 2025-03-21 23:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:12:21 --> Pagination Class Initialized
INFO - 2025-03-21 23:12:21 --> Controller Class Initialized
DEBUG - 2025-03-21 23:12:21 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:12:21 --> Model Class Initialized
DEBUG - 2025-03-21 23:12:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:12:21 --> Model Class Initialized
ERROR - 2025-03-21 23:12:21 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:12:21 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:12:21 --> Received customer_id: null
ERROR - 2025-03-21 23:12:21 --> Received customfiled: null
ERROR - 2025-03-21 23:12:21 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:12:21 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:12:21 --> Search value: 
ERROR - 2025-03-21 23:12:21 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:12:21 --> Fetching records from DB...
ERROR - 2025-03-21 23:12:21 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:12:21 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:12:21 --> Final data row count: 9
ERROR - 2025-03-21 23:12:21 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:12:21 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:13:18 --> Config Class Initialized
INFO - 2025-03-21 23:13:18 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:13:18 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:13:18 --> Utf8 Class Initialized
INFO - 2025-03-21 23:13:18 --> URI Class Initialized
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:13:18 --> Router Class Initialized
INFO - 2025-03-21 23:13:18 --> Output Class Initialized
INFO - 2025-03-21 23:13:18 --> Security Class Initialized
DEBUG - 2025-03-21 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:13:18 --> Input Class Initialized
INFO - 2025-03-21 23:13:18 --> Language Class Initialized
INFO - 2025-03-21 23:13:18 --> Language Class Initialized
INFO - 2025-03-21 23:13:18 --> Config Class Initialized
INFO - 2025-03-21 23:13:18 --> Loader Class Initialized
INFO - 2025-03-21 23:13:18 --> Helper loaded: url_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: file_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: html_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: form_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: text_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:13:18 --> Database Driver Class Initialized
INFO - 2025-03-21 23:13:18 --> Email Class Initialized
INFO - 2025-03-21 23:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:13:18 --> Form Validation Class Initialized
INFO - 2025-03-21 23:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:13:18 --> Pagination Class Initialized
INFO - 2025-03-21 23:13:18 --> Controller Class Initialized
DEBUG - 2025-03-21 23:13:18 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:13:18 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:13:18 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:13:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:13:18 --> Model Class Initialized
ERROR - 2025-03-21 23:13:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:13:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:13:18 --> Final output sent to browser
DEBUG - 2025-03-21 23:13:18 --> Total execution time: 0.1271
INFO - 2025-03-21 23:13:18 --> Config Class Initialized
INFO - 2025-03-21 23:13:18 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:13:18 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:13:18 --> Utf8 Class Initialized
INFO - 2025-03-21 23:13:18 --> URI Class Initialized
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:13:18 --> Router Class Initialized
INFO - 2025-03-21 23:13:18 --> Output Class Initialized
INFO - 2025-03-21 23:13:18 --> Security Class Initialized
DEBUG - 2025-03-21 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:13:18 --> Input Class Initialized
INFO - 2025-03-21 23:13:18 --> Language Class Initialized
INFO - 2025-03-21 23:13:18 --> Language Class Initialized
INFO - 2025-03-21 23:13:18 --> Config Class Initialized
INFO - 2025-03-21 23:13:18 --> Loader Class Initialized
INFO - 2025-03-21 23:13:18 --> Helper loaded: url_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: file_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: html_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: form_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: text_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:13:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:13:18 --> Database Driver Class Initialized
INFO - 2025-03-21 23:13:18 --> Email Class Initialized
INFO - 2025-03-21 23:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:13:18 --> Form Validation Class Initialized
INFO - 2025-03-21 23:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:13:18 --> Pagination Class Initialized
INFO - 2025-03-21 23:13:18 --> Controller Class Initialized
DEBUG - 2025-03-21 23:13:18 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:13:18 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:13:18 --> Model Class Initialized
ERROR - 2025-03-21 23:13:18 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:13:18 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:13:18 --> Received customer_id: null
ERROR - 2025-03-21 23:13:18 --> Received customfiled: null
ERROR - 2025-03-21 23:13:18 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:13:18 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:13:18 --> Search value: 
ERROR - 2025-03-21 23:13:18 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:13:18 --> Fetching records from DB...
ERROR - 2025-03-21 23:13:18 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:13:18 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:13:18 --> Final data row count: 9
ERROR - 2025-03-21 23:13:18 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:13:18 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:13:24 --> Config Class Initialized
INFO - 2025-03-21 23:13:24 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:13:24 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:13:24 --> Utf8 Class Initialized
INFO - 2025-03-21 23:13:24 --> URI Class Initialized
DEBUG - 2025-03-21 23:13:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:13:24 --> Router Class Initialized
INFO - 2025-03-21 23:13:24 --> Output Class Initialized
INFO - 2025-03-21 23:13:24 --> Security Class Initialized
DEBUG - 2025-03-21 23:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:13:24 --> Input Class Initialized
INFO - 2025-03-21 23:13:24 --> Language Class Initialized
INFO - 2025-03-21 23:13:24 --> Language Class Initialized
INFO - 2025-03-21 23:13:24 --> Config Class Initialized
INFO - 2025-03-21 23:13:24 --> Loader Class Initialized
INFO - 2025-03-21 23:13:24 --> Helper loaded: url_helper
INFO - 2025-03-21 23:13:24 --> Helper loaded: file_helper
INFO - 2025-03-21 23:13:24 --> Helper loaded: html_helper
INFO - 2025-03-21 23:13:24 --> Helper loaded: form_helper
INFO - 2025-03-21 23:13:24 --> Helper loaded: text_helper
INFO - 2025-03-21 23:13:24 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:13:24 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:13:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:13:24 --> Database Driver Class Initialized
INFO - 2025-03-21 23:13:24 --> Email Class Initialized
INFO - 2025-03-21 23:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:13:24 --> Form Validation Class Initialized
INFO - 2025-03-21 23:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:13:24 --> Pagination Class Initialized
INFO - 2025-03-21 23:13:24 --> Controller Class Initialized
DEBUG - 2025-03-21 23:13:24 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:13:24 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:13:24 --> Model Class Initialized
ERROR - 2025-03-21 23:13:24 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:13:24 --> POST Data: {"draw":"2","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"-1","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:13:24 --> Received customer_id: null
ERROR - 2025-03-21 23:13:24 --> Received customfiled: null
ERROR - 2025-03-21 23:13:24 --> Pagination info: start=0, length=-1
ERROR - 2025-03-21 23:13:24 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:13:24 --> Search value: 
ERROR - 2025-03-21 23:13:24 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:13:24 --> Fetching records from DB...
ERROR - 2025-03-21 23:13:24 --> LIMIT skipped — loading all records
ERROR - 2025-03-21 23:13:24 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:13:24 --> Final data row count: 9
ERROR - 2025-03-21 23:13:24 --> JSON Response: {"draw":2,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:13:24 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:13:27 --> Config Class Initialized
INFO - 2025-03-21 23:13:27 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:13:27 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:13:27 --> Utf8 Class Initialized
INFO - 2025-03-21 23:13:27 --> URI Class Initialized
DEBUG - 2025-03-21 23:13:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:13:27 --> Router Class Initialized
INFO - 2025-03-21 23:13:27 --> Output Class Initialized
INFO - 2025-03-21 23:13:27 --> Security Class Initialized
DEBUG - 2025-03-21 23:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:13:27 --> Input Class Initialized
INFO - 2025-03-21 23:13:27 --> Language Class Initialized
INFO - 2025-03-21 23:13:27 --> Language Class Initialized
INFO - 2025-03-21 23:13:27 --> Config Class Initialized
INFO - 2025-03-21 23:13:27 --> Loader Class Initialized
INFO - 2025-03-21 23:13:27 --> Helper loaded: url_helper
INFO - 2025-03-21 23:13:27 --> Helper loaded: file_helper
INFO - 2025-03-21 23:13:27 --> Helper loaded: html_helper
INFO - 2025-03-21 23:13:27 --> Helper loaded: form_helper
INFO - 2025-03-21 23:13:27 --> Helper loaded: text_helper
INFO - 2025-03-21 23:13:27 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:13:27 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:13:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:13:27 --> Database Driver Class Initialized
INFO - 2025-03-21 23:13:27 --> Email Class Initialized
INFO - 2025-03-21 23:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:13:27 --> Form Validation Class Initialized
INFO - 2025-03-21 23:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:13:27 --> Pagination Class Initialized
INFO - 2025-03-21 23:13:27 --> Controller Class Initialized
DEBUG - 2025-03-21 23:13:27 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:13:27 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:13:27 --> Model Class Initialized
ERROR - 2025-03-21 23:13:27 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:13:27 --> POST Data: {"draw":"3","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:13:27 --> Received customer_id: null
ERROR - 2025-03-21 23:13:27 --> Received customfiled: null
ERROR - 2025-03-21 23:13:27 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:13:27 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:13:27 --> Search value: 
ERROR - 2025-03-21 23:13:27 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:13:27 --> Fetching records from DB...
ERROR - 2025-03-21 23:13:27 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:13:27 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:13:27 --> Final data row count: 9
ERROR - 2025-03-21 23:13:27 --> JSON Response: {"draw":3,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:13:27 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:13:33 --> Config Class Initialized
INFO - 2025-03-21 23:13:33 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:13:33 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:13:33 --> Utf8 Class Initialized
INFO - 2025-03-21 23:13:33 --> URI Class Initialized
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:13:33 --> Router Class Initialized
INFO - 2025-03-21 23:13:33 --> Output Class Initialized
INFO - 2025-03-21 23:13:33 --> Security Class Initialized
DEBUG - 2025-03-21 23:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:13:33 --> Input Class Initialized
INFO - 2025-03-21 23:13:33 --> Language Class Initialized
INFO - 2025-03-21 23:13:33 --> Language Class Initialized
INFO - 2025-03-21 23:13:33 --> Config Class Initialized
INFO - 2025-03-21 23:13:33 --> Loader Class Initialized
INFO - 2025-03-21 23:13:33 --> Helper loaded: url_helper
INFO - 2025-03-21 23:13:33 --> Helper loaded: file_helper
INFO - 2025-03-21 23:13:33 --> Helper loaded: html_helper
INFO - 2025-03-21 23:13:33 --> Helper loaded: form_helper
INFO - 2025-03-21 23:13:33 --> Helper loaded: text_helper
INFO - 2025-03-21 23:13:33 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:13:33 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:13:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:13:33 --> Database Driver Class Initialized
INFO - 2025-03-21 23:13:33 --> Email Class Initialized
INFO - 2025-03-21 23:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:13:33 --> Form Validation Class Initialized
INFO - 2025-03-21 23:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:13:33 --> Pagination Class Initialized
INFO - 2025-03-21 23:13:33 --> Controller Class Initialized
DEBUG - 2025-03-21 23:13:33 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:13:33 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:13:33 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:13:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:13:33 --> Model Class Initialized
ERROR - 2025-03-21 23:13:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:13:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:13:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:13:33 --> Final output sent to browser
DEBUG - 2025-03-21 23:13:33 --> Total execution time: 0.1303
INFO - 2025-03-21 23:13:34 --> Config Class Initialized
INFO - 2025-03-21 23:13:34 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:13:34 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:13:34 --> Utf8 Class Initialized
INFO - 2025-03-21 23:13:34 --> URI Class Initialized
DEBUG - 2025-03-21 23:13:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:13:34 --> Router Class Initialized
INFO - 2025-03-21 23:13:34 --> Output Class Initialized
INFO - 2025-03-21 23:13:34 --> Security Class Initialized
DEBUG - 2025-03-21 23:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:13:34 --> Input Class Initialized
INFO - 2025-03-21 23:13:34 --> Language Class Initialized
INFO - 2025-03-21 23:13:34 --> Language Class Initialized
INFO - 2025-03-21 23:13:34 --> Config Class Initialized
INFO - 2025-03-21 23:13:34 --> Loader Class Initialized
INFO - 2025-03-21 23:13:34 --> Helper loaded: url_helper
INFO - 2025-03-21 23:13:34 --> Helper loaded: file_helper
INFO - 2025-03-21 23:13:34 --> Helper loaded: html_helper
INFO - 2025-03-21 23:13:34 --> Helper loaded: form_helper
INFO - 2025-03-21 23:13:34 --> Helper loaded: text_helper
INFO - 2025-03-21 23:13:34 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:13:34 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:13:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:13:34 --> Database Driver Class Initialized
INFO - 2025-03-21 23:13:34 --> Email Class Initialized
INFO - 2025-03-21 23:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:13:34 --> Form Validation Class Initialized
INFO - 2025-03-21 23:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:13:34 --> Pagination Class Initialized
INFO - 2025-03-21 23:13:34 --> Controller Class Initialized
DEBUG - 2025-03-21 23:13:34 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:13:34 --> Model Class Initialized
DEBUG - 2025-03-21 23:13:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:13:34 --> Model Class Initialized
ERROR - 2025-03-21 23:13:34 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:13:34 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:13:34 --> Received customer_id: null
ERROR - 2025-03-21 23:13:34 --> Received customfiled: null
ERROR - 2025-03-21 23:13:34 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:13:34 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:13:34 --> Search value: 
ERROR - 2025-03-21 23:13:34 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:13:34 --> Fetching records from DB...
ERROR - 2025-03-21 23:13:34 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:13:34 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:13:34 --> Final data row count: 9
ERROR - 2025-03-21 23:13:34 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:13:34 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:15:56 --> Config Class Initialized
INFO - 2025-03-21 23:15:56 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:15:56 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:15:56 --> Utf8 Class Initialized
INFO - 2025-03-21 23:15:56 --> URI Class Initialized
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:15:56 --> Router Class Initialized
INFO - 2025-03-21 23:15:56 --> Output Class Initialized
INFO - 2025-03-21 23:15:56 --> Security Class Initialized
DEBUG - 2025-03-21 23:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:15:56 --> Input Class Initialized
INFO - 2025-03-21 23:15:56 --> Language Class Initialized
INFO - 2025-03-21 23:15:56 --> Language Class Initialized
INFO - 2025-03-21 23:15:56 --> Config Class Initialized
INFO - 2025-03-21 23:15:56 --> Loader Class Initialized
INFO - 2025-03-21 23:15:56 --> Helper loaded: url_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: file_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: html_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: form_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: text_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:15:56 --> Database Driver Class Initialized
INFO - 2025-03-21 23:15:56 --> Email Class Initialized
INFO - 2025-03-21 23:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:15:56 --> Form Validation Class Initialized
INFO - 2025-03-21 23:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:15:56 --> Pagination Class Initialized
INFO - 2025-03-21 23:15:56 --> Controller Class Initialized
DEBUG - 2025-03-21 23:15:56 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:15:56 --> Model Class Initialized
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:15:56 --> Model Class Initialized
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:15:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:15:56 --> Model Class Initialized
ERROR - 2025-03-21 23:15:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:15:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:15:56 --> Final output sent to browser
DEBUG - 2025-03-21 23:15:56 --> Total execution time: 0.1386
INFO - 2025-03-21 23:15:56 --> Config Class Initialized
INFO - 2025-03-21 23:15:56 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:15:56 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:15:56 --> Utf8 Class Initialized
INFO - 2025-03-21 23:15:56 --> URI Class Initialized
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:15:56 --> Router Class Initialized
INFO - 2025-03-21 23:15:56 --> Output Class Initialized
INFO - 2025-03-21 23:15:56 --> Security Class Initialized
DEBUG - 2025-03-21 23:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:15:56 --> Input Class Initialized
INFO - 2025-03-21 23:15:56 --> Language Class Initialized
INFO - 2025-03-21 23:15:56 --> Language Class Initialized
INFO - 2025-03-21 23:15:56 --> Config Class Initialized
INFO - 2025-03-21 23:15:56 --> Loader Class Initialized
INFO - 2025-03-21 23:15:56 --> Helper loaded: url_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: file_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: html_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: form_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: text_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:15:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:15:56 --> Database Driver Class Initialized
INFO - 2025-03-21 23:15:56 --> Email Class Initialized
INFO - 2025-03-21 23:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:15:56 --> Form Validation Class Initialized
INFO - 2025-03-21 23:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:15:56 --> Pagination Class Initialized
INFO - 2025-03-21 23:15:56 --> Controller Class Initialized
DEBUG - 2025-03-21 23:15:56 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:15:56 --> Model Class Initialized
DEBUG - 2025-03-21 23:15:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:15:56 --> Model Class Initialized
ERROR - 2025-03-21 23:15:56 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:15:56 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:15:56 --> Received customer_id: null
ERROR - 2025-03-21 23:15:56 --> Received customfiled: null
ERROR - 2025-03-21 23:15:56 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:15:56 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:15:56 --> Search value: 
ERROR - 2025-03-21 23:15:56 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:15:56 --> Fetching records from DB...
ERROR - 2025-03-21 23:15:56 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:15:56 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:15:56 --> Final data row count: 9
ERROR - 2025-03-21 23:15:56 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:15:56 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:16:06 --> Config Class Initialized
INFO - 2025-03-21 23:16:06 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:16:06 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:16:06 --> Utf8 Class Initialized
INFO - 2025-03-21 23:16:06 --> URI Class Initialized
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:16:06 --> Router Class Initialized
INFO - 2025-03-21 23:16:06 --> Output Class Initialized
INFO - 2025-03-21 23:16:06 --> Security Class Initialized
DEBUG - 2025-03-21 23:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:16:06 --> Input Class Initialized
INFO - 2025-03-21 23:16:06 --> Language Class Initialized
INFO - 2025-03-21 23:16:06 --> Language Class Initialized
INFO - 2025-03-21 23:16:06 --> Config Class Initialized
INFO - 2025-03-21 23:16:06 --> Loader Class Initialized
INFO - 2025-03-21 23:16:06 --> Helper loaded: url_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: file_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: html_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: form_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: text_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:16:06 --> Database Driver Class Initialized
INFO - 2025-03-21 23:16:06 --> Email Class Initialized
INFO - 2025-03-21 23:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:16:06 --> Form Validation Class Initialized
INFO - 2025-03-21 23:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:16:06 --> Pagination Class Initialized
INFO - 2025-03-21 23:16:06 --> Controller Class Initialized
DEBUG - 2025-03-21 23:16:06 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:16:06 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:16:06 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:16:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:16:06 --> Model Class Initialized
ERROR - 2025-03-21 23:16:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:16:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:16:06 --> Final output sent to browser
DEBUG - 2025-03-21 23:16:06 --> Total execution time: 0.1459
INFO - 2025-03-21 23:16:06 --> Config Class Initialized
INFO - 2025-03-21 23:16:06 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:16:06 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:16:06 --> Utf8 Class Initialized
INFO - 2025-03-21 23:16:06 --> URI Class Initialized
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:16:06 --> Router Class Initialized
INFO - 2025-03-21 23:16:06 --> Output Class Initialized
INFO - 2025-03-21 23:16:06 --> Security Class Initialized
DEBUG - 2025-03-21 23:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:16:06 --> Input Class Initialized
INFO - 2025-03-21 23:16:06 --> Language Class Initialized
INFO - 2025-03-21 23:16:06 --> Language Class Initialized
INFO - 2025-03-21 23:16:06 --> Config Class Initialized
INFO - 2025-03-21 23:16:06 --> Loader Class Initialized
INFO - 2025-03-21 23:16:06 --> Helper loaded: url_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: file_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: html_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: form_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: text_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:16:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:16:06 --> Database Driver Class Initialized
INFO - 2025-03-21 23:16:06 --> Email Class Initialized
INFO - 2025-03-21 23:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:16:06 --> Form Validation Class Initialized
INFO - 2025-03-21 23:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:16:06 --> Pagination Class Initialized
INFO - 2025-03-21 23:16:06 --> Controller Class Initialized
DEBUG - 2025-03-21 23:16:06 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:16:06 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:16:06 --> Model Class Initialized
ERROR - 2025-03-21 23:16:06 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:16:06 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:16:06 --> Received customer_id: null
ERROR - 2025-03-21 23:16:06 --> Received customfiled: null
ERROR - 2025-03-21 23:16:06 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:16:06 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:16:06 --> Search value: 
ERROR - 2025-03-21 23:16:06 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:16:06 --> Fetching records from DB...
ERROR - 2025-03-21 23:16:06 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:16:06 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:16:06 --> Final data row count: 9
ERROR - 2025-03-21 23:16:06 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:16:06 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:16:53 --> Config Class Initialized
INFO - 2025-03-21 23:16:53 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:16:53 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:16:53 --> Utf8 Class Initialized
INFO - 2025-03-21 23:16:53 --> URI Class Initialized
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:16:53 --> Router Class Initialized
INFO - 2025-03-21 23:16:53 --> Output Class Initialized
INFO - 2025-03-21 23:16:53 --> Security Class Initialized
DEBUG - 2025-03-21 23:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:16:53 --> Input Class Initialized
INFO - 2025-03-21 23:16:53 --> Language Class Initialized
INFO - 2025-03-21 23:16:53 --> Language Class Initialized
INFO - 2025-03-21 23:16:53 --> Config Class Initialized
INFO - 2025-03-21 23:16:53 --> Loader Class Initialized
INFO - 2025-03-21 23:16:53 --> Helper loaded: url_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: file_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: html_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: form_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: text_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:16:53 --> Database Driver Class Initialized
INFO - 2025-03-21 23:16:53 --> Email Class Initialized
INFO - 2025-03-21 23:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:16:53 --> Form Validation Class Initialized
INFO - 2025-03-21 23:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:16:53 --> Pagination Class Initialized
INFO - 2025-03-21 23:16:53 --> Controller Class Initialized
DEBUG - 2025-03-21 23:16:53 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:16:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:16:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:16:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:16:53 --> Model Class Initialized
ERROR - 2025-03-21 23:16:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:16:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:16:53 --> Final output sent to browser
DEBUG - 2025-03-21 23:16:53 --> Total execution time: 0.1064
INFO - 2025-03-21 23:16:53 --> Config Class Initialized
INFO - 2025-03-21 23:16:53 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:16:53 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:16:53 --> Utf8 Class Initialized
INFO - 2025-03-21 23:16:53 --> URI Class Initialized
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:16:53 --> Router Class Initialized
INFO - 2025-03-21 23:16:53 --> Output Class Initialized
INFO - 2025-03-21 23:16:53 --> Security Class Initialized
DEBUG - 2025-03-21 23:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:16:53 --> Input Class Initialized
INFO - 2025-03-21 23:16:53 --> Language Class Initialized
INFO - 2025-03-21 23:16:53 --> Language Class Initialized
INFO - 2025-03-21 23:16:53 --> Config Class Initialized
INFO - 2025-03-21 23:16:53 --> Loader Class Initialized
INFO - 2025-03-21 23:16:53 --> Helper loaded: url_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: file_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: html_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: form_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: text_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:16:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:16:53 --> Database Driver Class Initialized
INFO - 2025-03-21 23:16:53 --> Email Class Initialized
INFO - 2025-03-21 23:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:16:53 --> Form Validation Class Initialized
INFO - 2025-03-21 23:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:16:53 --> Pagination Class Initialized
INFO - 2025-03-21 23:16:53 --> Controller Class Initialized
DEBUG - 2025-03-21 23:16:53 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:16:53 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:16:53 --> Model Class Initialized
ERROR - 2025-03-21 23:16:53 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:16:53 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:16:53 --> Received customer_id: null
ERROR - 2025-03-21 23:16:53 --> Received customfiled: null
ERROR - 2025-03-21 23:16:53 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:16:53 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:16:53 --> Search value: 
ERROR - 2025-03-21 23:16:53 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:16:53 --> Fetching records from DB...
ERROR - 2025-03-21 23:16:53 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:16:53 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:16:53 --> Final data row count: 9
ERROR - 2025-03-21 23:16:53 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:16:53 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:16:56 --> Config Class Initialized
INFO - 2025-03-21 23:16:56 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:16:56 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:16:56 --> Utf8 Class Initialized
INFO - 2025-03-21 23:16:56 --> URI Class Initialized
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:16:56 --> Router Class Initialized
INFO - 2025-03-21 23:16:56 --> Output Class Initialized
INFO - 2025-03-21 23:16:56 --> Security Class Initialized
DEBUG - 2025-03-21 23:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:16:56 --> Input Class Initialized
INFO - 2025-03-21 23:16:56 --> Language Class Initialized
INFO - 2025-03-21 23:16:56 --> Language Class Initialized
INFO - 2025-03-21 23:16:56 --> Config Class Initialized
INFO - 2025-03-21 23:16:56 --> Loader Class Initialized
INFO - 2025-03-21 23:16:56 --> Helper loaded: url_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: file_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: html_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: form_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: text_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:16:56 --> Database Driver Class Initialized
INFO - 2025-03-21 23:16:56 --> Email Class Initialized
INFO - 2025-03-21 23:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:16:56 --> Form Validation Class Initialized
INFO - 2025-03-21 23:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:16:56 --> Pagination Class Initialized
INFO - 2025-03-21 23:16:56 --> Controller Class Initialized
DEBUG - 2025-03-21 23:16:56 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:16:56 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:16:56 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:16:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:16:56 --> Model Class Initialized
ERROR - 2025-03-21 23:16:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:16:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:16:56 --> Final output sent to browser
DEBUG - 2025-03-21 23:16:56 --> Total execution time: 0.1467
INFO - 2025-03-21 23:16:56 --> Config Class Initialized
INFO - 2025-03-21 23:16:56 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:16:56 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:16:56 --> Utf8 Class Initialized
INFO - 2025-03-21 23:16:56 --> URI Class Initialized
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:16:56 --> Router Class Initialized
INFO - 2025-03-21 23:16:56 --> Output Class Initialized
INFO - 2025-03-21 23:16:56 --> Security Class Initialized
DEBUG - 2025-03-21 23:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:16:56 --> Input Class Initialized
INFO - 2025-03-21 23:16:56 --> Language Class Initialized
INFO - 2025-03-21 23:16:56 --> Language Class Initialized
INFO - 2025-03-21 23:16:56 --> Config Class Initialized
INFO - 2025-03-21 23:16:56 --> Loader Class Initialized
INFO - 2025-03-21 23:16:56 --> Helper loaded: url_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: file_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: html_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: form_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: text_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:16:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:16:56 --> Database Driver Class Initialized
INFO - 2025-03-21 23:16:56 --> Email Class Initialized
INFO - 2025-03-21 23:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:16:56 --> Form Validation Class Initialized
INFO - 2025-03-21 23:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:16:56 --> Pagination Class Initialized
INFO - 2025-03-21 23:16:56 --> Controller Class Initialized
DEBUG - 2025-03-21 23:16:56 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:16:56 --> Model Class Initialized
DEBUG - 2025-03-21 23:16:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:16:56 --> Model Class Initialized
ERROR - 2025-03-21 23:16:56 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:16:56 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:16:56 --> Received customer_id: null
ERROR - 2025-03-21 23:16:56 --> Received customfiled: null
ERROR - 2025-03-21 23:16:56 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:16:56 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:16:56 --> Search value: 
ERROR - 2025-03-21 23:16:56 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:16:56 --> Fetching records from DB...
ERROR - 2025-03-21 23:16:56 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:16:56 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:16:56 --> Final data row count: 9
ERROR - 2025-03-21 23:16:56 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:16:56 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:20:31 --> Config Class Initialized
INFO - 2025-03-21 23:20:31 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:20:31 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:20:31 --> Utf8 Class Initialized
INFO - 2025-03-21 23:20:31 --> URI Class Initialized
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:20:31 --> Router Class Initialized
INFO - 2025-03-21 23:20:31 --> Output Class Initialized
INFO - 2025-03-21 23:20:31 --> Security Class Initialized
DEBUG - 2025-03-21 23:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:20:31 --> Input Class Initialized
INFO - 2025-03-21 23:20:31 --> Language Class Initialized
INFO - 2025-03-21 23:20:31 --> Language Class Initialized
INFO - 2025-03-21 23:20:31 --> Config Class Initialized
INFO - 2025-03-21 23:20:31 --> Loader Class Initialized
INFO - 2025-03-21 23:20:31 --> Helper loaded: url_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: file_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: html_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: form_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: text_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:20:31 --> Database Driver Class Initialized
INFO - 2025-03-21 23:20:31 --> Email Class Initialized
INFO - 2025-03-21 23:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:20:31 --> Form Validation Class Initialized
INFO - 2025-03-21 23:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:20:31 --> Pagination Class Initialized
INFO - 2025-03-21 23:20:31 --> Controller Class Initialized
DEBUG - 2025-03-21 23:20:31 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:20:31 --> Model Class Initialized
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:20:31 --> Model Class Initialized
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:20:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:20:31 --> Model Class Initialized
ERROR - 2025-03-21 23:20:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:20:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:20:31 --> Final output sent to browser
DEBUG - 2025-03-21 23:20:31 --> Total execution time: 0.1302
INFO - 2025-03-21 23:20:31 --> Config Class Initialized
INFO - 2025-03-21 23:20:31 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:20:31 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:20:31 --> Utf8 Class Initialized
INFO - 2025-03-21 23:20:31 --> URI Class Initialized
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:20:31 --> Router Class Initialized
INFO - 2025-03-21 23:20:31 --> Output Class Initialized
INFO - 2025-03-21 23:20:31 --> Security Class Initialized
DEBUG - 2025-03-21 23:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:20:31 --> Input Class Initialized
INFO - 2025-03-21 23:20:31 --> Language Class Initialized
INFO - 2025-03-21 23:20:31 --> Language Class Initialized
INFO - 2025-03-21 23:20:31 --> Config Class Initialized
INFO - 2025-03-21 23:20:31 --> Loader Class Initialized
INFO - 2025-03-21 23:20:31 --> Helper loaded: url_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: file_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: html_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: form_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: text_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:20:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:20:31 --> Database Driver Class Initialized
INFO - 2025-03-21 23:20:31 --> Email Class Initialized
INFO - 2025-03-21 23:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:20:31 --> Form Validation Class Initialized
INFO - 2025-03-21 23:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:20:31 --> Pagination Class Initialized
INFO - 2025-03-21 23:20:31 --> Controller Class Initialized
DEBUG - 2025-03-21 23:20:31 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:20:31 --> Model Class Initialized
DEBUG - 2025-03-21 23:20:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:20:31 --> Model Class Initialized
ERROR - 2025-03-21 23:20:31 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:20:31 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:20:31 --> Received customer_id: null
ERROR - 2025-03-21 23:20:31 --> Received customfiled: null
ERROR - 2025-03-21 23:20:31 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:20:31 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:20:31 --> Search value: 
ERROR - 2025-03-21 23:20:31 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:20:31 --> Fetching records from DB...
ERROR - 2025-03-21 23:20:31 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:20:31 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:20:31 --> Final data row count: 9
ERROR - 2025-03-21 23:20:31 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:20:31 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:21:18 --> Config Class Initialized
INFO - 2025-03-21 23:21:18 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:21:18 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:21:18 --> Utf8 Class Initialized
INFO - 2025-03-21 23:21:18 --> URI Class Initialized
DEBUG - 2025-03-21 23:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:21:18 --> Router Class Initialized
INFO - 2025-03-21 23:21:18 --> Output Class Initialized
INFO - 2025-03-21 23:21:18 --> Security Class Initialized
DEBUG - 2025-03-21 23:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:21:18 --> Input Class Initialized
INFO - 2025-03-21 23:21:18 --> Language Class Initialized
INFO - 2025-03-21 23:21:18 --> Language Class Initialized
INFO - 2025-03-21 23:21:18 --> Config Class Initialized
INFO - 2025-03-21 23:21:18 --> Loader Class Initialized
INFO - 2025-03-21 23:21:18 --> Helper loaded: url_helper
INFO - 2025-03-21 23:21:18 --> Helper loaded: file_helper
INFO - 2025-03-21 23:21:18 --> Helper loaded: html_helper
INFO - 2025-03-21 23:21:18 --> Helper loaded: form_helper
INFO - 2025-03-21 23:21:18 --> Helper loaded: text_helper
INFO - 2025-03-21 23:21:18 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:21:18 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:21:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:21:18 --> Database Driver Class Initialized
INFO - 2025-03-21 23:21:18 --> Email Class Initialized
INFO - 2025-03-21 23:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:21:18 --> Form Validation Class Initialized
INFO - 2025-03-21 23:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:21:18 --> Pagination Class Initialized
INFO - 2025-03-21 23:21:18 --> Controller Class Initialized
DEBUG - 2025-03-21 23:21:18 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:21:18 --> Model Class Initialized
DEBUG - 2025-03-21 23:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:21:18 --> Model Class Initialized
DEBUG - 2025-03-21 23:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:21:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:21:18 --> Model Class Initialized
ERROR - 2025-03-21 23:21:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:21:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:21:19 --> Final output sent to browser
DEBUG - 2025-03-21 23:21:19 --> Total execution time: 0.1354
INFO - 2025-03-21 23:21:19 --> Config Class Initialized
INFO - 2025-03-21 23:21:19 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:21:19 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:21:19 --> Utf8 Class Initialized
INFO - 2025-03-21 23:21:19 --> URI Class Initialized
DEBUG - 2025-03-21 23:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:21:19 --> Router Class Initialized
INFO - 2025-03-21 23:21:19 --> Output Class Initialized
INFO - 2025-03-21 23:21:19 --> Security Class Initialized
DEBUG - 2025-03-21 23:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:21:19 --> Input Class Initialized
INFO - 2025-03-21 23:21:19 --> Language Class Initialized
INFO - 2025-03-21 23:21:19 --> Language Class Initialized
INFO - 2025-03-21 23:21:19 --> Config Class Initialized
INFO - 2025-03-21 23:21:19 --> Loader Class Initialized
INFO - 2025-03-21 23:21:19 --> Helper loaded: url_helper
INFO - 2025-03-21 23:21:19 --> Helper loaded: file_helper
INFO - 2025-03-21 23:21:19 --> Helper loaded: html_helper
INFO - 2025-03-21 23:21:19 --> Helper loaded: form_helper
INFO - 2025-03-21 23:21:19 --> Helper loaded: text_helper
INFO - 2025-03-21 23:21:19 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:21:19 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:21:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:21:19 --> Database Driver Class Initialized
INFO - 2025-03-21 23:21:19 --> Email Class Initialized
INFO - 2025-03-21 23:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:21:19 --> Form Validation Class Initialized
INFO - 2025-03-21 23:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:21:19 --> Pagination Class Initialized
INFO - 2025-03-21 23:21:19 --> Controller Class Initialized
DEBUG - 2025-03-21 23:21:19 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:21:19 --> Model Class Initialized
DEBUG - 2025-03-21 23:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:21:19 --> Model Class Initialized
ERROR - 2025-03-21 23:21:19 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:21:19 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:21:19 --> Received customer_id: null
ERROR - 2025-03-21 23:21:19 --> Received customfiled: null
ERROR - 2025-03-21 23:21:19 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:21:19 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:21:19 --> Search value: 
ERROR - 2025-03-21 23:21:19 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:21:19 --> Fetching records from DB...
ERROR - 2025-03-21 23:21:19 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:21:19 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:21:19 --> Final data row count: 9
ERROR - 2025-03-21 23:21:19 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:21:19 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:23:47 --> Config Class Initialized
INFO - 2025-03-21 23:23:47 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:23:47 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:23:47 --> Utf8 Class Initialized
INFO - 2025-03-21 23:23:47 --> URI Class Initialized
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:23:47 --> Router Class Initialized
INFO - 2025-03-21 23:23:47 --> Output Class Initialized
INFO - 2025-03-21 23:23:47 --> Security Class Initialized
DEBUG - 2025-03-21 23:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:23:47 --> Input Class Initialized
INFO - 2025-03-21 23:23:47 --> Language Class Initialized
INFO - 2025-03-21 23:23:47 --> Language Class Initialized
INFO - 2025-03-21 23:23:47 --> Config Class Initialized
INFO - 2025-03-21 23:23:47 --> Loader Class Initialized
INFO - 2025-03-21 23:23:47 --> Helper loaded: url_helper
INFO - 2025-03-21 23:23:47 --> Helper loaded: file_helper
INFO - 2025-03-21 23:23:47 --> Helper loaded: html_helper
INFO - 2025-03-21 23:23:47 --> Helper loaded: form_helper
INFO - 2025-03-21 23:23:47 --> Helper loaded: text_helper
INFO - 2025-03-21 23:23:47 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:23:47 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:23:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:23:47 --> Database Driver Class Initialized
INFO - 2025-03-21 23:23:47 --> Email Class Initialized
INFO - 2025-03-21 23:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:23:47 --> Form Validation Class Initialized
INFO - 2025-03-21 23:23:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:23:47 --> Pagination Class Initialized
INFO - 2025-03-21 23:23:47 --> Controller Class Initialized
DEBUG - 2025-03-21 23:23:47 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:23:47 --> Model Class Initialized
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:23:47 --> Model Class Initialized
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:23:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:23:47 --> Model Class Initialized
ERROR - 2025-03-21 23:23:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:23:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:23:47 --> Final output sent to browser
DEBUG - 2025-03-21 23:23:47 --> Total execution time: 0.1301
INFO - 2025-03-21 23:23:48 --> Config Class Initialized
INFO - 2025-03-21 23:23:48 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:23:48 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:23:48 --> Utf8 Class Initialized
INFO - 2025-03-21 23:23:48 --> URI Class Initialized
DEBUG - 2025-03-21 23:23:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:23:48 --> Router Class Initialized
INFO - 2025-03-21 23:23:48 --> Output Class Initialized
INFO - 2025-03-21 23:23:48 --> Security Class Initialized
DEBUG - 2025-03-21 23:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:23:48 --> Input Class Initialized
INFO - 2025-03-21 23:23:48 --> Language Class Initialized
INFO - 2025-03-21 23:23:48 --> Language Class Initialized
INFO - 2025-03-21 23:23:48 --> Config Class Initialized
INFO - 2025-03-21 23:23:48 --> Loader Class Initialized
INFO - 2025-03-21 23:23:48 --> Helper loaded: url_helper
INFO - 2025-03-21 23:23:48 --> Helper loaded: file_helper
INFO - 2025-03-21 23:23:48 --> Helper loaded: html_helper
INFO - 2025-03-21 23:23:48 --> Helper loaded: form_helper
INFO - 2025-03-21 23:23:48 --> Helper loaded: text_helper
INFO - 2025-03-21 23:23:48 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:23:48 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:23:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:23:48 --> Database Driver Class Initialized
INFO - 2025-03-21 23:23:48 --> Email Class Initialized
INFO - 2025-03-21 23:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:23:48 --> Form Validation Class Initialized
INFO - 2025-03-21 23:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:23:48 --> Pagination Class Initialized
INFO - 2025-03-21 23:23:48 --> Controller Class Initialized
DEBUG - 2025-03-21 23:23:48 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:23:48 --> Model Class Initialized
DEBUG - 2025-03-21 23:23:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:23:48 --> Model Class Initialized
ERROR - 2025-03-21 23:23:48 --> ========= getCustomerList() START =========
ERROR - 2025-03-21 23:23:48 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-21 23:23:48 --> Received customer_id: null
ERROR - 2025-03-21 23:23:48 --> Received customfiled: null
ERROR - 2025-03-21 23:23:48 --> Pagination info: start=0, length=50
ERROR - 2025-03-21 23:23:48 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-21 23:23:48 --> Search value: 
ERROR - 2025-03-21 23:23:48 --> Total unfiltered records: 9
ERROR - 2025-03-21 23:23:48 --> Fetching records from DB...
ERROR - 2025-03-21 23:23:48 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-21 23:23:48 --> Records fetched from DB: 9
ERROR - 2025-03-21 23:23:48 --> Final data row count: 9
ERROR - 2025-03-21 23:23:48 --> JSON Response: {"draw":1,"iTotalRecords":9,"iTotalDisplayRecords":9,"aaData":[{"sl":1,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/18\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/11\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/14\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":7,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"0","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":8,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":9,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]}
ERROR - 2025-03-21 23:23:48 --> ========= getCustomerList() END =========
INFO - 2025-03-21 23:24:06 --> Config Class Initialized
INFO - 2025-03-21 23:24:06 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:24:06 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:24:06 --> Utf8 Class Initialized
INFO - 2025-03-21 23:24:06 --> URI Class Initialized
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:24:06 --> Router Class Initialized
INFO - 2025-03-21 23:24:06 --> Output Class Initialized
INFO - 2025-03-21 23:24:06 --> Security Class Initialized
DEBUG - 2025-03-21 23:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:24:06 --> Input Class Initialized
INFO - 2025-03-21 23:24:06 --> Language Class Initialized
INFO - 2025-03-21 23:24:06 --> Language Class Initialized
INFO - 2025-03-21 23:24:06 --> Config Class Initialized
INFO - 2025-03-21 23:24:06 --> Loader Class Initialized
INFO - 2025-03-21 23:24:06 --> Helper loaded: url_helper
INFO - 2025-03-21 23:24:06 --> Helper loaded: file_helper
INFO - 2025-03-21 23:24:06 --> Helper loaded: html_helper
INFO - 2025-03-21 23:24:06 --> Helper loaded: form_helper
INFO - 2025-03-21 23:24:06 --> Helper loaded: text_helper
INFO - 2025-03-21 23:24:06 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:24:06 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:24:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:24:06 --> Database Driver Class Initialized
INFO - 2025-03-21 23:24:06 --> Email Class Initialized
INFO - 2025-03-21 23:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:24:06 --> Form Validation Class Initialized
INFO - 2025-03-21 23:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:24:06 --> Pagination Class Initialized
INFO - 2025-03-21 23:24:06 --> Controller Class Initialized
DEBUG - 2025-03-21 23:24:06 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:24:06 --> Model Class Initialized
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:24:06 --> Model Class Initialized
ERROR - 2025-03-21 23:24:06 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:24:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:24:06 --> Model Class Initialized
ERROR - 2025-03-21 23:24:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:24:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:24:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:24:06 --> Final output sent to browser
DEBUG - 2025-03-21 23:24:06 --> Total execution time: 0.1657
INFO - 2025-03-21 23:24:35 --> Config Class Initialized
INFO - 2025-03-21 23:24:35 --> Hooks Class Initialized
DEBUG - 2025-03-21 23:24:35 --> UTF-8 Support Enabled
INFO - 2025-03-21 23:24:35 --> Utf8 Class Initialized
INFO - 2025-03-21 23:24:35 --> URI Class Initialized
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-21 23:24:35 --> Router Class Initialized
INFO - 2025-03-21 23:24:35 --> Output Class Initialized
INFO - 2025-03-21 23:24:35 --> Security Class Initialized
DEBUG - 2025-03-21 23:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-21 23:24:35 --> Input Class Initialized
INFO - 2025-03-21 23:24:35 --> Language Class Initialized
INFO - 2025-03-21 23:24:35 --> Language Class Initialized
INFO - 2025-03-21 23:24:35 --> Config Class Initialized
INFO - 2025-03-21 23:24:35 --> Loader Class Initialized
INFO - 2025-03-21 23:24:35 --> Helper loaded: url_helper
INFO - 2025-03-21 23:24:35 --> Helper loaded: file_helper
INFO - 2025-03-21 23:24:35 --> Helper loaded: html_helper
INFO - 2025-03-21 23:24:35 --> Helper loaded: form_helper
INFO - 2025-03-21 23:24:35 --> Helper loaded: text_helper
INFO - 2025-03-21 23:24:35 --> Helper loaded: lang_helper
INFO - 2025-03-21 23:24:35 --> Helper loaded: directory_helper
INFO - 2025-03-21 23:24:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-21 23:24:35 --> Database Driver Class Initialized
INFO - 2025-03-21 23:24:35 --> Email Class Initialized
INFO - 2025-03-21 23:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-21 23:24:35 --> Form Validation Class Initialized
INFO - 2025-03-21 23:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-21 23:24:35 --> Pagination Class Initialized
INFO - 2025-03-21 23:24:35 --> Controller Class Initialized
DEBUG - 2025-03-21 23:24:35 --> Customer MX_Controller Initialized
INFO - 2025-03-21 23:24:35 --> Model Class Initialized
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-21 23:24:35 --> Model Class Initialized
ERROR - 2025-03-21 23:24:35 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-21 23:24:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-21 23:24:35 --> Model Class Initialized
ERROR - 2025-03-21 23:24:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-21 23:24:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-21 23:24:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-21 23:24:35 --> Final output sent to browser
DEBUG - 2025-03-21 23:24:35 --> Total execution time: 0.1583
