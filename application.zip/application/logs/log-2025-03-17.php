<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-17 19:48:27 --> Config Class Initialized
INFO - 2025-03-17 19:48:27 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:48:27 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:48:27 --> Utf8 Class Initialized
INFO - 2025-03-17 19:48:27 --> URI Class Initialized
DEBUG - 2025-03-17 19:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-17 19:48:27 --> No URI present. Default controller set.
INFO - 2025-03-17 19:48:27 --> Router Class Initialized
INFO - 2025-03-17 19:48:27 --> Output Class Initialized
INFO - 2025-03-17 19:48:27 --> Security Class Initialized
DEBUG - 2025-03-17 19:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:48:27 --> Input Class Initialized
INFO - 2025-03-17 19:48:27 --> Language Class Initialized
INFO - 2025-03-17 19:48:27 --> Language Class Initialized
INFO - 2025-03-17 19:48:27 --> Config Class Initialized
INFO - 2025-03-17 19:48:27 --> Loader Class Initialized
INFO - 2025-03-17 19:48:27 --> Helper loaded: url_helper
INFO - 2025-03-17 19:48:27 --> Helper loaded: file_helper
INFO - 2025-03-17 19:48:27 --> Helper loaded: html_helper
INFO - 2025-03-17 19:48:27 --> Helper loaded: form_helper
INFO - 2025-03-17 19:48:27 --> Helper loaded: text_helper
INFO - 2025-03-17 19:48:27 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:48:27 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:48:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:48:27 --> Database Driver Class Initialized
INFO - 2025-03-17 19:48:27 --> Email Class Initialized
INFO - 2025-03-17 19:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:48:27 --> Form Validation Class Initialized
INFO - 2025-03-17 19:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:48:27 --> Pagination Class Initialized
INFO - 2025-03-17 19:48:27 --> Controller Class Initialized
DEBUG - 2025-03-17 19:48:27 --> Auth MX_Controller Initialized
INFO - 2025-03-17 19:48:27 --> Model Class Initialized
DEBUG - 2025-03-17 19:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-17 19:48:27 --> Model Class Initialized
DEBUG - 2025-03-17 19:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 19:48:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 19:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 19:48:27 --> Model Class Initialized
DEBUG - 2025-03-17 19:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-17 19:48:27 --> Final output sent to browser
DEBUG - 2025-03-17 19:48:27 --> Total execution time: 0.0642
INFO - 2025-03-17 19:48:39 --> Config Class Initialized
INFO - 2025-03-17 19:48:39 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:48:39 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:48:39 --> Utf8 Class Initialized
INFO - 2025-03-17 19:48:39 --> URI Class Initialized
DEBUG - 2025-03-17 19:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-17 19:48:39 --> Router Class Initialized
INFO - 2025-03-17 19:48:39 --> Output Class Initialized
INFO - 2025-03-17 19:48:39 --> Security Class Initialized
DEBUG - 2025-03-17 19:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:48:39 --> Input Class Initialized
INFO - 2025-03-17 19:48:39 --> Language Class Initialized
INFO - 2025-03-17 19:48:39 --> Language Class Initialized
INFO - 2025-03-17 19:48:39 --> Config Class Initialized
INFO - 2025-03-17 19:48:39 --> Loader Class Initialized
INFO - 2025-03-17 19:48:39 --> Helper loaded: url_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: file_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: html_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: form_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: text_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:48:39 --> Database Driver Class Initialized
INFO - 2025-03-17 19:48:39 --> Email Class Initialized
INFO - 2025-03-17 19:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:48:39 --> Form Validation Class Initialized
INFO - 2025-03-17 19:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:48:39 --> Pagination Class Initialized
INFO - 2025-03-17 19:48:39 --> Controller Class Initialized
DEBUG - 2025-03-17 19:48:39 --> Auth MX_Controller Initialized
INFO - 2025-03-17 19:48:39 --> Model Class Initialized
DEBUG - 2025-03-17 19:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-17 19:48:39 --> Model Class Initialized
INFO - 2025-03-17 19:48:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-17 19:48:39 --> Config Class Initialized
INFO - 2025-03-17 19:48:39 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:48:39 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:48:39 --> Utf8 Class Initialized
INFO - 2025-03-17 19:48:39 --> URI Class Initialized
DEBUG - 2025-03-17 19:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-17 19:48:39 --> Router Class Initialized
INFO - 2025-03-17 19:48:39 --> Output Class Initialized
INFO - 2025-03-17 19:48:39 --> Security Class Initialized
DEBUG - 2025-03-17 19:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:48:39 --> Input Class Initialized
INFO - 2025-03-17 19:48:39 --> Language Class Initialized
INFO - 2025-03-17 19:48:39 --> Language Class Initialized
INFO - 2025-03-17 19:48:39 --> Config Class Initialized
INFO - 2025-03-17 19:48:39 --> Loader Class Initialized
INFO - 2025-03-17 19:48:39 --> Helper loaded: url_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: file_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: html_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: form_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: text_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:48:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:48:39 --> Database Driver Class Initialized
INFO - 2025-03-17 19:48:39 --> Email Class Initialized
INFO - 2025-03-17 19:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:48:39 --> Form Validation Class Initialized
INFO - 2025-03-17 19:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:48:39 --> Pagination Class Initialized
INFO - 2025-03-17 19:48:39 --> Controller Class Initialized
DEBUG - 2025-03-17 19:48:39 --> Home MX_Controller Initialized
INFO - 2025-03-17 19:48:39 --> Model Class Initialized
DEBUG - 2025-03-17 19:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-17 19:48:39 --> Model Class Initialized
DEBUG - 2025-03-17 19:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 19:48:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 19:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 19:48:39 --> Model Class Initialized
ERROR - 2025-03-17 19:48:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 19:48:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 19:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 19:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 19:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 19:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 19:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-17 19:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 19:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 19:48:40 --> Final output sent to browser
DEBUG - 2025-03-17 19:48:40 --> Total execution time: 0.5298
INFO - 2025-03-17 19:49:03 --> Config Class Initialized
INFO - 2025-03-17 19:49:03 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:49:03 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:49:03 --> Utf8 Class Initialized
INFO - 2025-03-17 19:49:03 --> URI Class Initialized
DEBUG - 2025-03-17 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 19:49:03 --> Router Class Initialized
INFO - 2025-03-17 19:49:03 --> Output Class Initialized
INFO - 2025-03-17 19:49:03 --> Security Class Initialized
DEBUG - 2025-03-17 19:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:49:03 --> Input Class Initialized
INFO - 2025-03-17 19:49:03 --> Language Class Initialized
INFO - 2025-03-17 19:49:03 --> Language Class Initialized
INFO - 2025-03-17 19:49:03 --> Config Class Initialized
INFO - 2025-03-17 19:49:03 --> Loader Class Initialized
INFO - 2025-03-17 19:49:03 --> Helper loaded: url_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: file_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: html_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: form_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: text_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:49:03 --> Database Driver Class Initialized
INFO - 2025-03-17 19:49:03 --> Email Class Initialized
INFO - 2025-03-17 19:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:49:03 --> Form Validation Class Initialized
INFO - 2025-03-17 19:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:49:03 --> Pagination Class Initialized
INFO - 2025-03-17 19:49:03 --> Controller Class Initialized
DEBUG - 2025-03-17 19:49:03 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 19:49:03 --> Config Class Initialized
INFO - 2025-03-17 19:49:03 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:49:03 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:49:03 --> Utf8 Class Initialized
INFO - 2025-03-17 19:49:03 --> URI Class Initialized
DEBUG - 2025-03-17 19:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 19:49:03 --> Router Class Initialized
INFO - 2025-03-17 19:49:03 --> Output Class Initialized
INFO - 2025-03-17 19:49:03 --> Security Class Initialized
DEBUG - 2025-03-17 19:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:49:03 --> Input Class Initialized
INFO - 2025-03-17 19:49:03 --> Language Class Initialized
INFO - 2025-03-17 19:49:03 --> Language Class Initialized
INFO - 2025-03-17 19:49:03 --> Config Class Initialized
INFO - 2025-03-17 19:49:03 --> Loader Class Initialized
INFO - 2025-03-17 19:49:03 --> Helper loaded: url_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: file_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: html_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: form_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: text_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:49:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:49:03 --> Database Driver Class Initialized
INFO - 2025-03-17 19:49:03 --> Email Class Initialized
INFO - 2025-03-17 19:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:49:03 --> Form Validation Class Initialized
INFO - 2025-03-17 19:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:49:03 --> Pagination Class Initialized
INFO - 2025-03-17 19:49:03 --> Controller Class Initialized
DEBUG - 2025-03-17 19:49:03 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 19:49:16 --> Config Class Initialized
INFO - 2025-03-17 19:49:16 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:49:16 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:49:16 --> Utf8 Class Initialized
INFO - 2025-03-17 19:49:16 --> URI Class Initialized
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 19:49:16 --> Router Class Initialized
INFO - 2025-03-17 19:49:16 --> Output Class Initialized
INFO - 2025-03-17 19:49:16 --> Security Class Initialized
DEBUG - 2025-03-17 19:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:49:16 --> Input Class Initialized
INFO - 2025-03-17 19:49:16 --> Language Class Initialized
INFO - 2025-03-17 19:49:16 --> Language Class Initialized
INFO - 2025-03-17 19:49:16 --> Config Class Initialized
INFO - 2025-03-17 19:49:16 --> Loader Class Initialized
INFO - 2025-03-17 19:49:16 --> Helper loaded: url_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: file_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: html_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: form_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: text_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:49:16 --> Database Driver Class Initialized
INFO - 2025-03-17 19:49:16 --> Email Class Initialized
INFO - 2025-03-17 19:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:49:16 --> Form Validation Class Initialized
INFO - 2025-03-17 19:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:49:16 --> Pagination Class Initialized
INFO - 2025-03-17 19:49:16 --> Controller Class Initialized
DEBUG - 2025-03-17 19:49:16 --> Customer MX_Controller Initialized
INFO - 2025-03-17 19:49:16 --> Model Class Initialized
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 19:49:16 --> Model Class Initialized
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 19:49:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 19:49:16 --> Model Class Initialized
ERROR - 2025-03-17 19:49:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 19:49:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 19:49:16 --> Final output sent to browser
DEBUG - 2025-03-17 19:49:16 --> Total execution time: 0.0981
INFO - 2025-03-17 19:49:16 --> Config Class Initialized
INFO - 2025-03-17 19:49:16 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:49:16 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:49:16 --> Utf8 Class Initialized
INFO - 2025-03-17 19:49:16 --> URI Class Initialized
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 19:49:16 --> Router Class Initialized
INFO - 2025-03-17 19:49:16 --> Output Class Initialized
INFO - 2025-03-17 19:49:16 --> Security Class Initialized
DEBUG - 2025-03-17 19:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:49:16 --> Input Class Initialized
INFO - 2025-03-17 19:49:16 --> Language Class Initialized
INFO - 2025-03-17 19:49:16 --> Language Class Initialized
INFO - 2025-03-17 19:49:16 --> Config Class Initialized
INFO - 2025-03-17 19:49:16 --> Loader Class Initialized
INFO - 2025-03-17 19:49:16 --> Helper loaded: url_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: file_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: html_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: form_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: text_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:49:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:49:16 --> Database Driver Class Initialized
INFO - 2025-03-17 19:49:16 --> Email Class Initialized
INFO - 2025-03-17 19:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:49:16 --> Form Validation Class Initialized
INFO - 2025-03-17 19:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:49:16 --> Pagination Class Initialized
INFO - 2025-03-17 19:49:16 --> Controller Class Initialized
DEBUG - 2025-03-17 19:49:16 --> Customer MX_Controller Initialized
INFO - 2025-03-17 19:49:16 --> Model Class Initialized
DEBUG - 2025-03-17 19:49:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 19:49:16 --> Model Class Initialized
ERROR - 2025-03-17 19:49:16 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 19:49:16 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 19:49:16 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 19:49:16 --> DEBUG: Search Value = 
ERROR - 2025-03-17 19:49:16 --> DEBUG: Counting total records...
ERROR - 2025-03-17 19:49:16 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 19:49:16 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 19:49:16 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 19:49:16 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 19:50:15 --> Config Class Initialized
INFO - 2025-03-17 19:50:15 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:50:15 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:50:15 --> Utf8 Class Initialized
INFO - 2025-03-17 19:50:15 --> URI Class Initialized
INFO - 2025-03-17 19:50:15 --> Router Class Initialized
INFO - 2025-03-17 19:50:15 --> Output Class Initialized
INFO - 2025-03-17 19:50:15 --> Security Class Initialized
DEBUG - 2025-03-17 19:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:50:15 --> Input Class Initialized
INFO - 2025-03-17 19:50:15 --> Language Class Initialized
INFO - 2025-03-17 19:50:15 --> Language Class Initialized
INFO - 2025-03-17 19:50:15 --> Config Class Initialized
INFO - 2025-03-17 19:50:15 --> Loader Class Initialized
INFO - 2025-03-17 19:50:15 --> Helper loaded: url_helper
INFO - 2025-03-17 19:50:15 --> Helper loaded: file_helper
INFO - 2025-03-17 19:50:15 --> Helper loaded: html_helper
INFO - 2025-03-17 19:50:15 --> Helper loaded: form_helper
INFO - 2025-03-17 19:50:15 --> Helper loaded: text_helper
INFO - 2025-03-17 19:50:15 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:50:15 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:50:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:50:15 --> Database Driver Class Initialized
INFO - 2025-03-17 19:50:15 --> Email Class Initialized
INFO - 2025-03-17 19:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:50:15 --> Form Validation Class Initialized
INFO - 2025-03-17 19:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:50:15 --> Pagination Class Initialized
INFO - 2025-03-17 19:50:15 --> Controller Class Initialized
INFO - 2025-03-17 19:50:15 --> Model Class Initialized
INFO - 2025-03-17 19:50:15 --> Final output sent to browser
DEBUG - 2025-03-17 19:50:15 --> Total execution time: 0.0233
INFO - 2025-03-17 19:56:03 --> Config Class Initialized
INFO - 2025-03-17 19:56:03 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:56:03 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:56:03 --> Utf8 Class Initialized
INFO - 2025-03-17 19:56:03 --> URI Class Initialized
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 19:56:03 --> Router Class Initialized
INFO - 2025-03-17 19:56:03 --> Output Class Initialized
INFO - 2025-03-17 19:56:03 --> Security Class Initialized
DEBUG - 2025-03-17 19:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:56:03 --> Input Class Initialized
INFO - 2025-03-17 19:56:03 --> Language Class Initialized
INFO - 2025-03-17 19:56:03 --> Language Class Initialized
INFO - 2025-03-17 19:56:03 --> Config Class Initialized
INFO - 2025-03-17 19:56:03 --> Loader Class Initialized
INFO - 2025-03-17 19:56:03 --> Helper loaded: url_helper
INFO - 2025-03-17 19:56:03 --> Helper loaded: file_helper
INFO - 2025-03-17 19:56:03 --> Helper loaded: html_helper
INFO - 2025-03-17 19:56:03 --> Helper loaded: form_helper
INFO - 2025-03-17 19:56:03 --> Helper loaded: text_helper
INFO - 2025-03-17 19:56:03 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:56:03 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:56:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:56:03 --> Database Driver Class Initialized
INFO - 2025-03-17 19:56:03 --> Email Class Initialized
INFO - 2025-03-17 19:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:56:03 --> Form Validation Class Initialized
INFO - 2025-03-17 19:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:56:03 --> Pagination Class Initialized
INFO - 2025-03-17 19:56:03 --> Controller Class Initialized
DEBUG - 2025-03-17 19:56:03 --> Customer MX_Controller Initialized
INFO - 2025-03-17 19:56:03 --> Model Class Initialized
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 19:56:03 --> Model Class Initialized
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 19:56:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 19:56:03 --> Model Class Initialized
ERROR - 2025-03-17 19:56:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 19:56:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 19:56:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 19:56:03 --> Final output sent to browser
DEBUG - 2025-03-17 19:56:03 --> Total execution time: 0.1557
INFO - 2025-03-17 19:56:04 --> Config Class Initialized
INFO - 2025-03-17 19:56:04 --> Hooks Class Initialized
DEBUG - 2025-03-17 19:56:04 --> UTF-8 Support Enabled
INFO - 2025-03-17 19:56:04 --> Utf8 Class Initialized
INFO - 2025-03-17 19:56:04 --> URI Class Initialized
DEBUG - 2025-03-17 19:56:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 19:56:04 --> Router Class Initialized
INFO - 2025-03-17 19:56:04 --> Output Class Initialized
INFO - 2025-03-17 19:56:04 --> Security Class Initialized
DEBUG - 2025-03-17 19:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 19:56:04 --> Input Class Initialized
INFO - 2025-03-17 19:56:04 --> Language Class Initialized
INFO - 2025-03-17 19:56:04 --> Language Class Initialized
INFO - 2025-03-17 19:56:04 --> Config Class Initialized
INFO - 2025-03-17 19:56:04 --> Loader Class Initialized
INFO - 2025-03-17 19:56:04 --> Helper loaded: url_helper
INFO - 2025-03-17 19:56:04 --> Helper loaded: file_helper
INFO - 2025-03-17 19:56:04 --> Helper loaded: html_helper
INFO - 2025-03-17 19:56:04 --> Helper loaded: form_helper
INFO - 2025-03-17 19:56:04 --> Helper loaded: text_helper
INFO - 2025-03-17 19:56:04 --> Helper loaded: lang_helper
INFO - 2025-03-17 19:56:04 --> Helper loaded: directory_helper
INFO - 2025-03-17 19:56:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 19:56:04 --> Database Driver Class Initialized
INFO - 2025-03-17 19:56:04 --> Email Class Initialized
INFO - 2025-03-17 19:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 19:56:04 --> Form Validation Class Initialized
INFO - 2025-03-17 19:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 19:56:04 --> Pagination Class Initialized
INFO - 2025-03-17 19:56:04 --> Controller Class Initialized
DEBUG - 2025-03-17 19:56:04 --> Customer MX_Controller Initialized
INFO - 2025-03-17 19:56:04 --> Model Class Initialized
DEBUG - 2025-03-17 19:56:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 19:56:04 --> Model Class Initialized
ERROR - 2025-03-17 19:56:04 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 19:56:04 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 19:56:04 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 19:56:04 --> DEBUG: Search Value = 
ERROR - 2025-03-17 19:56:04 --> DEBUG: Counting total records...
ERROR - 2025-03-17 19:56:04 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 19:56:04 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 19:56:04 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 19:56:04 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:07:09 --> Config Class Initialized
INFO - 2025-03-17 20:07:09 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:07:09 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:07:09 --> Utf8 Class Initialized
INFO - 2025-03-17 20:07:09 --> URI Class Initialized
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:07:09 --> Router Class Initialized
INFO - 2025-03-17 20:07:09 --> Output Class Initialized
INFO - 2025-03-17 20:07:09 --> Security Class Initialized
DEBUG - 2025-03-17 20:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:07:09 --> Input Class Initialized
INFO - 2025-03-17 20:07:09 --> Language Class Initialized
INFO - 2025-03-17 20:07:09 --> Language Class Initialized
INFO - 2025-03-17 20:07:09 --> Config Class Initialized
INFO - 2025-03-17 20:07:09 --> Loader Class Initialized
INFO - 2025-03-17 20:07:09 --> Helper loaded: url_helper
INFO - 2025-03-17 20:07:09 --> Helper loaded: file_helper
INFO - 2025-03-17 20:07:09 --> Helper loaded: html_helper
INFO - 2025-03-17 20:07:09 --> Helper loaded: form_helper
INFO - 2025-03-17 20:07:09 --> Helper loaded: text_helper
INFO - 2025-03-17 20:07:09 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:07:09 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:07:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:07:09 --> Database Driver Class Initialized
INFO - 2025-03-17 20:07:09 --> Email Class Initialized
INFO - 2025-03-17 20:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:07:09 --> Form Validation Class Initialized
INFO - 2025-03-17 20:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:07:09 --> Pagination Class Initialized
INFO - 2025-03-17 20:07:09 --> Controller Class Initialized
DEBUG - 2025-03-17 20:07:09 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:07:09 --> Model Class Initialized
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:07:09 --> Model Class Initialized
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:07:09 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:07:09 --> Model Class Initialized
ERROR - 2025-03-17 20:07:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:07:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:07:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:07:09 --> Final output sent to browser
DEBUG - 2025-03-17 20:07:09 --> Total execution time: 0.1045
INFO - 2025-03-17 20:07:10 --> Config Class Initialized
INFO - 2025-03-17 20:07:10 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:07:10 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:07:10 --> Utf8 Class Initialized
INFO - 2025-03-17 20:07:10 --> URI Class Initialized
DEBUG - 2025-03-17 20:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:07:10 --> Router Class Initialized
INFO - 2025-03-17 20:07:10 --> Output Class Initialized
INFO - 2025-03-17 20:07:10 --> Security Class Initialized
DEBUG - 2025-03-17 20:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:07:10 --> Input Class Initialized
INFO - 2025-03-17 20:07:10 --> Language Class Initialized
INFO - 2025-03-17 20:07:10 --> Language Class Initialized
INFO - 2025-03-17 20:07:10 --> Config Class Initialized
INFO - 2025-03-17 20:07:10 --> Loader Class Initialized
INFO - 2025-03-17 20:07:10 --> Helper loaded: url_helper
INFO - 2025-03-17 20:07:10 --> Helper loaded: file_helper
INFO - 2025-03-17 20:07:10 --> Helper loaded: html_helper
INFO - 2025-03-17 20:07:10 --> Helper loaded: form_helper
INFO - 2025-03-17 20:07:10 --> Helper loaded: text_helper
INFO - 2025-03-17 20:07:10 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:07:10 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:07:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:07:10 --> Database Driver Class Initialized
INFO - 2025-03-17 20:07:10 --> Email Class Initialized
INFO - 2025-03-17 20:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:07:10 --> Form Validation Class Initialized
INFO - 2025-03-17 20:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:07:10 --> Pagination Class Initialized
INFO - 2025-03-17 20:07:10 --> Controller Class Initialized
DEBUG - 2025-03-17 20:07:10 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:07:10 --> Model Class Initialized
DEBUG - 2025-03-17 20:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:07:10 --> Model Class Initialized
ERROR - 2025-03-17 20:07:10 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:07:10 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:07:10 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:07:10 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:07:10 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:07:10 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:07:10 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:07:10 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:07:10 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:11:19 --> Config Class Initialized
INFO - 2025-03-17 20:11:19 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:19 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:19 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:19 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:19 --> Router Class Initialized
INFO - 2025-03-17 20:11:19 --> Output Class Initialized
INFO - 2025-03-17 20:11:19 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:19 --> Input Class Initialized
INFO - 2025-03-17 20:11:19 --> Language Class Initialized
INFO - 2025-03-17 20:11:19 --> Language Class Initialized
INFO - 2025-03-17 20:11:19 --> Config Class Initialized
INFO - 2025-03-17 20:11:19 --> Loader Class Initialized
INFO - 2025-03-17 20:11:19 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:19 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:19 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:19 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:19 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:19 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:19 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:19 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:19 --> Email Class Initialized
INFO - 2025-03-17 20:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:19 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:19 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:19 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:19 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:19 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:19 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:19 --> Model Class Initialized
ERROR - 2025-03-17 20:11:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:19 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:19 --> Total execution time: 0.1212
INFO - 2025-03-17 20:11:20 --> Config Class Initialized
INFO - 2025-03-17 20:11:20 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:20 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:20 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:20 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:20 --> Router Class Initialized
INFO - 2025-03-17 20:11:20 --> Output Class Initialized
INFO - 2025-03-17 20:11:20 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:20 --> Input Class Initialized
INFO - 2025-03-17 20:11:20 --> Language Class Initialized
INFO - 2025-03-17 20:11:20 --> Language Class Initialized
INFO - 2025-03-17 20:11:20 --> Config Class Initialized
INFO - 2025-03-17 20:11:20 --> Loader Class Initialized
INFO - 2025-03-17 20:11:20 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:20 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:20 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:20 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:20 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:20 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:20 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:20 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:20 --> Email Class Initialized
INFO - 2025-03-17 20:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:20 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:20 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:20 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:20 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:20 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:20 --> Model Class Initialized
INFO - 2025-03-17 20:11:20 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:20 --> Total execution time: 0.0351
INFO - 2025-03-17 20:11:33 --> Config Class Initialized
INFO - 2025-03-17 20:11:33 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:33 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:33 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:33 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:33 --> Router Class Initialized
INFO - 2025-03-17 20:11:33 --> Output Class Initialized
INFO - 2025-03-17 20:11:33 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:33 --> Input Class Initialized
INFO - 2025-03-17 20:11:33 --> Language Class Initialized
INFO - 2025-03-17 20:11:33 --> Language Class Initialized
INFO - 2025-03-17 20:11:33 --> Config Class Initialized
INFO - 2025-03-17 20:11:33 --> Loader Class Initialized
INFO - 2025-03-17 20:11:33 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:33 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:33 --> Email Class Initialized
INFO - 2025-03-17 20:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:33 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:33 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:33 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:33 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:33 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:33 --> Model Class Initialized
INFO - 2025-03-17 20:11:33 --> Config Class Initialized
INFO - 2025-03-17 20:11:33 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:33 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:33 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:33 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:33 --> Router Class Initialized
INFO - 2025-03-17 20:11:33 --> Output Class Initialized
INFO - 2025-03-17 20:11:33 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:33 --> Input Class Initialized
INFO - 2025-03-17 20:11:33 --> Language Class Initialized
INFO - 2025-03-17 20:11:33 --> Language Class Initialized
INFO - 2025-03-17 20:11:33 --> Config Class Initialized
INFO - 2025-03-17 20:11:33 --> Loader Class Initialized
INFO - 2025-03-17 20:11:33 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:33 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:33 --> Email Class Initialized
INFO - 2025-03-17 20:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:33 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:33 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:33 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:33 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:33 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:33 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:33 --> Model Class Initialized
ERROR - 2025-03-17 20:11:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:33 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:33 --> Total execution time: 0.1291
INFO - 2025-03-17 20:11:33 --> Config Class Initialized
INFO - 2025-03-17 20:11:33 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:33 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:33 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:33 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:33 --> Router Class Initialized
INFO - 2025-03-17 20:11:33 --> Output Class Initialized
INFO - 2025-03-17 20:11:33 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:33 --> Input Class Initialized
INFO - 2025-03-17 20:11:33 --> Language Class Initialized
INFO - 2025-03-17 20:11:33 --> Language Class Initialized
INFO - 2025-03-17 20:11:33 --> Config Class Initialized
INFO - 2025-03-17 20:11:33 --> Loader Class Initialized
INFO - 2025-03-17 20:11:33 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:33 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:33 --> Email Class Initialized
INFO - 2025-03-17 20:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:33 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:33 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:33 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:33 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:33 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:33 --> Model Class Initialized
INFO - 2025-03-17 20:11:33 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:33 --> Total execution time: 0.0552
INFO - 2025-03-17 20:11:38 --> Config Class Initialized
INFO - 2025-03-17 20:11:38 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:38 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:38 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:38 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:38 --> Router Class Initialized
INFO - 2025-03-17 20:11:38 --> Output Class Initialized
INFO - 2025-03-17 20:11:38 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:38 --> Input Class Initialized
INFO - 2025-03-17 20:11:38 --> Language Class Initialized
INFO - 2025-03-17 20:11:38 --> Language Class Initialized
INFO - 2025-03-17 20:11:38 --> Config Class Initialized
INFO - 2025-03-17 20:11:38 --> Loader Class Initialized
INFO - 2025-03-17 20:11:38 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:38 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:38 --> Email Class Initialized
INFO - 2025-03-17 20:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:38 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:38 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:38 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:38 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:38 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:38 --> Model Class Initialized
INFO - 2025-03-17 20:11:38 --> Config Class Initialized
INFO - 2025-03-17 20:11:38 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:38 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:38 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:38 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:38 --> Router Class Initialized
INFO - 2025-03-17 20:11:38 --> Output Class Initialized
INFO - 2025-03-17 20:11:38 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:38 --> Input Class Initialized
INFO - 2025-03-17 20:11:38 --> Language Class Initialized
INFO - 2025-03-17 20:11:38 --> Language Class Initialized
INFO - 2025-03-17 20:11:38 --> Config Class Initialized
INFO - 2025-03-17 20:11:38 --> Loader Class Initialized
INFO - 2025-03-17 20:11:38 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:38 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:38 --> Email Class Initialized
INFO - 2025-03-17 20:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:38 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:38 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:38 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:38 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:38 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:38 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:38 --> Model Class Initialized
ERROR - 2025-03-17 20:11:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:38 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:38 --> Total execution time: 0.1330
INFO - 2025-03-17 20:11:38 --> Config Class Initialized
INFO - 2025-03-17 20:11:38 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:38 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:38 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:38 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:38 --> Router Class Initialized
INFO - 2025-03-17 20:11:38 --> Output Class Initialized
INFO - 2025-03-17 20:11:38 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:38 --> Input Class Initialized
INFO - 2025-03-17 20:11:38 --> Language Class Initialized
INFO - 2025-03-17 20:11:38 --> Language Class Initialized
INFO - 2025-03-17 20:11:38 --> Config Class Initialized
INFO - 2025-03-17 20:11:38 --> Loader Class Initialized
INFO - 2025-03-17 20:11:38 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:38 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:38 --> Email Class Initialized
INFO - 2025-03-17 20:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:38 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:38 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:38 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:38 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:38 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:38 --> Model Class Initialized
INFO - 2025-03-17 20:11:38 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:38 --> Total execution time: 0.0275
INFO - 2025-03-17 20:11:43 --> Config Class Initialized
INFO - 2025-03-17 20:11:43 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:43 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:43 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:43 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:43 --> Router Class Initialized
INFO - 2025-03-17 20:11:43 --> Output Class Initialized
INFO - 2025-03-17 20:11:43 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:43 --> Input Class Initialized
INFO - 2025-03-17 20:11:43 --> Language Class Initialized
INFO - 2025-03-17 20:11:43 --> Language Class Initialized
INFO - 2025-03-17 20:11:43 --> Config Class Initialized
INFO - 2025-03-17 20:11:43 --> Loader Class Initialized
INFO - 2025-03-17 20:11:43 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:43 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:43 --> Email Class Initialized
INFO - 2025-03-17 20:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:43 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:43 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:43 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:43 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:43 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:43 --> Model Class Initialized
INFO - 2025-03-17 20:11:43 --> Config Class Initialized
INFO - 2025-03-17 20:11:43 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:43 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:43 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:43 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:43 --> Router Class Initialized
INFO - 2025-03-17 20:11:43 --> Output Class Initialized
INFO - 2025-03-17 20:11:43 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:43 --> Input Class Initialized
INFO - 2025-03-17 20:11:43 --> Language Class Initialized
INFO - 2025-03-17 20:11:43 --> Language Class Initialized
INFO - 2025-03-17 20:11:43 --> Config Class Initialized
INFO - 2025-03-17 20:11:43 --> Loader Class Initialized
INFO - 2025-03-17 20:11:43 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:43 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:43 --> Email Class Initialized
INFO - 2025-03-17 20:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:43 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:43 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:43 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:43 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:43 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:43 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:43 --> Model Class Initialized
ERROR - 2025-03-17 20:11:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:43 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:43 --> Total execution time: 0.1566
INFO - 2025-03-17 20:11:43 --> Config Class Initialized
INFO - 2025-03-17 20:11:43 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:43 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:43 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:43 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:43 --> Router Class Initialized
INFO - 2025-03-17 20:11:43 --> Output Class Initialized
INFO - 2025-03-17 20:11:43 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:43 --> Input Class Initialized
INFO - 2025-03-17 20:11:43 --> Language Class Initialized
INFO - 2025-03-17 20:11:43 --> Language Class Initialized
INFO - 2025-03-17 20:11:43 --> Config Class Initialized
INFO - 2025-03-17 20:11:43 --> Loader Class Initialized
INFO - 2025-03-17 20:11:43 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:43 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:43 --> Email Class Initialized
INFO - 2025-03-17 20:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:43 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:43 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:43 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:43 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:43 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:43 --> Model Class Initialized
INFO - 2025-03-17 20:11:43 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:43 --> Total execution time: 0.0539
INFO - 2025-03-17 20:11:45 --> Config Class Initialized
INFO - 2025-03-17 20:11:45 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:45 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:45 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:45 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:45 --> Router Class Initialized
INFO - 2025-03-17 20:11:45 --> Output Class Initialized
INFO - 2025-03-17 20:11:45 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:45 --> Input Class Initialized
INFO - 2025-03-17 20:11:45 --> Language Class Initialized
INFO - 2025-03-17 20:11:45 --> Language Class Initialized
INFO - 2025-03-17 20:11:45 --> Config Class Initialized
INFO - 2025-03-17 20:11:45 --> Loader Class Initialized
INFO - 2025-03-17 20:11:45 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:45 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:45 --> Email Class Initialized
INFO - 2025-03-17 20:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:45 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:45 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:45 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:45 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:45 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:45 --> Model Class Initialized
INFO - 2025-03-17 20:11:45 --> Config Class Initialized
INFO - 2025-03-17 20:11:45 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:45 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:45 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:45 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:45 --> Router Class Initialized
INFO - 2025-03-17 20:11:45 --> Output Class Initialized
INFO - 2025-03-17 20:11:45 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:45 --> Input Class Initialized
INFO - 2025-03-17 20:11:45 --> Language Class Initialized
INFO - 2025-03-17 20:11:45 --> Language Class Initialized
INFO - 2025-03-17 20:11:45 --> Config Class Initialized
INFO - 2025-03-17 20:11:45 --> Loader Class Initialized
INFO - 2025-03-17 20:11:45 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:45 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:45 --> Email Class Initialized
INFO - 2025-03-17 20:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:45 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:45 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:45 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:45 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:45 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:45 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:45 --> Model Class Initialized
ERROR - 2025-03-17 20:11:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:45 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:45 --> Total execution time: 0.1318
INFO - 2025-03-17 20:11:46 --> Config Class Initialized
INFO - 2025-03-17 20:11:46 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:46 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:46 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:46 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:46 --> Router Class Initialized
INFO - 2025-03-17 20:11:46 --> Output Class Initialized
INFO - 2025-03-17 20:11:46 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:46 --> Input Class Initialized
INFO - 2025-03-17 20:11:46 --> Language Class Initialized
INFO - 2025-03-17 20:11:46 --> Language Class Initialized
INFO - 2025-03-17 20:11:46 --> Config Class Initialized
INFO - 2025-03-17 20:11:46 --> Loader Class Initialized
INFO - 2025-03-17 20:11:46 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:46 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:46 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:46 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:46 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:46 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:46 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:46 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:46 --> Email Class Initialized
INFO - 2025-03-17 20:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:46 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:46 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:46 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:46 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:46 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:46 --> Model Class Initialized
INFO - 2025-03-17 20:11:46 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:46 --> Total execution time: 0.0337
INFO - 2025-03-17 20:11:48 --> Config Class Initialized
INFO - 2025-03-17 20:11:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:48 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:48 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:48 --> Router Class Initialized
INFO - 2025-03-17 20:11:48 --> Output Class Initialized
INFO - 2025-03-17 20:11:48 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:48 --> Input Class Initialized
INFO - 2025-03-17 20:11:48 --> Language Class Initialized
INFO - 2025-03-17 20:11:48 --> Language Class Initialized
INFO - 2025-03-17 20:11:48 --> Config Class Initialized
INFO - 2025-03-17 20:11:48 --> Loader Class Initialized
INFO - 2025-03-17 20:11:48 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:48 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:48 --> Email Class Initialized
INFO - 2025-03-17 20:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:48 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:48 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:48 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:48 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:48 --> Model Class Initialized
INFO - 2025-03-17 20:11:48 --> Config Class Initialized
INFO - 2025-03-17 20:11:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:48 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:48 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:48 --> Router Class Initialized
INFO - 2025-03-17 20:11:48 --> Output Class Initialized
INFO - 2025-03-17 20:11:48 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:48 --> Input Class Initialized
INFO - 2025-03-17 20:11:48 --> Language Class Initialized
INFO - 2025-03-17 20:11:48 --> Language Class Initialized
INFO - 2025-03-17 20:11:48 --> Config Class Initialized
INFO - 2025-03-17 20:11:48 --> Loader Class Initialized
INFO - 2025-03-17 20:11:48 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:48 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:48 --> Email Class Initialized
INFO - 2025-03-17 20:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:48 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:48 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:48 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:48 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:48 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:48 --> Model Class Initialized
ERROR - 2025-03-17 20:11:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:48 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:48 --> Total execution time: 0.1579
INFO - 2025-03-17 20:11:48 --> Config Class Initialized
INFO - 2025-03-17 20:11:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:48 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:48 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:48 --> Router Class Initialized
INFO - 2025-03-17 20:11:48 --> Output Class Initialized
INFO - 2025-03-17 20:11:48 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:48 --> Input Class Initialized
INFO - 2025-03-17 20:11:48 --> Language Class Initialized
INFO - 2025-03-17 20:11:48 --> Language Class Initialized
INFO - 2025-03-17 20:11:48 --> Config Class Initialized
INFO - 2025-03-17 20:11:48 --> Loader Class Initialized
INFO - 2025-03-17 20:11:48 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:48 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:48 --> Email Class Initialized
INFO - 2025-03-17 20:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:48 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:48 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:48 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:48 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:48 --> Model Class Initialized
INFO - 2025-03-17 20:11:48 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:48 --> Total execution time: 0.0347
INFO - 2025-03-17 20:11:52 --> Config Class Initialized
INFO - 2025-03-17 20:11:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:52 --> Router Class Initialized
INFO - 2025-03-17 20:11:52 --> Output Class Initialized
INFO - 2025-03-17 20:11:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:52 --> Input Class Initialized
INFO - 2025-03-17 20:11:52 --> Language Class Initialized
INFO - 2025-03-17 20:11:52 --> Language Class Initialized
INFO - 2025-03-17 20:11:52 --> Config Class Initialized
INFO - 2025-03-17 20:11:52 --> Loader Class Initialized
INFO - 2025-03-17 20:11:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:52 --> Email Class Initialized
INFO - 2025-03-17 20:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:52 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:52 --> Model Class Initialized
INFO - 2025-03-17 20:11:52 --> Config Class Initialized
INFO - 2025-03-17 20:11:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:52 --> Router Class Initialized
INFO - 2025-03-17 20:11:52 --> Output Class Initialized
INFO - 2025-03-17 20:11:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:52 --> Input Class Initialized
INFO - 2025-03-17 20:11:52 --> Language Class Initialized
INFO - 2025-03-17 20:11:52 --> Language Class Initialized
INFO - 2025-03-17 20:11:52 --> Config Class Initialized
INFO - 2025-03-17 20:11:52 --> Loader Class Initialized
INFO - 2025-03-17 20:11:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:52 --> Email Class Initialized
INFO - 2025-03-17 20:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:52 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:52 --> Model Class Initialized
ERROR - 2025-03-17 20:11:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:52 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:52 --> Total execution time: 0.1010
INFO - 2025-03-17 20:11:52 --> Config Class Initialized
INFO - 2025-03-17 20:11:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:52 --> Router Class Initialized
INFO - 2025-03-17 20:11:52 --> Output Class Initialized
INFO - 2025-03-17 20:11:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:52 --> Input Class Initialized
INFO - 2025-03-17 20:11:52 --> Language Class Initialized
INFO - 2025-03-17 20:11:52 --> Language Class Initialized
INFO - 2025-03-17 20:11:52 --> Config Class Initialized
INFO - 2025-03-17 20:11:52 --> Loader Class Initialized
INFO - 2025-03-17 20:11:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:52 --> Email Class Initialized
INFO - 2025-03-17 20:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:52 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:52 --> Model Class Initialized
INFO - 2025-03-17 20:11:52 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:52 --> Total execution time: 0.0209
INFO - 2025-03-17 20:11:54 --> Config Class Initialized
INFO - 2025-03-17 20:11:54 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:54 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:54 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:54 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:54 --> Router Class Initialized
INFO - 2025-03-17 20:11:54 --> Output Class Initialized
INFO - 2025-03-17 20:11:54 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:54 --> Input Class Initialized
INFO - 2025-03-17 20:11:54 --> Language Class Initialized
INFO - 2025-03-17 20:11:54 --> Language Class Initialized
INFO - 2025-03-17 20:11:54 --> Config Class Initialized
INFO - 2025-03-17 20:11:54 --> Loader Class Initialized
INFO - 2025-03-17 20:11:54 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:54 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:54 --> Email Class Initialized
INFO - 2025-03-17 20:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:54 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:54 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:54 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:54 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:54 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:54 --> Model Class Initialized
INFO - 2025-03-17 20:11:54 --> Config Class Initialized
INFO - 2025-03-17 20:11:54 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:54 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:54 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:54 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:54 --> Router Class Initialized
INFO - 2025-03-17 20:11:54 --> Output Class Initialized
INFO - 2025-03-17 20:11:54 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:54 --> Input Class Initialized
INFO - 2025-03-17 20:11:54 --> Language Class Initialized
INFO - 2025-03-17 20:11:54 --> Language Class Initialized
INFO - 2025-03-17 20:11:54 --> Config Class Initialized
INFO - 2025-03-17 20:11:54 --> Loader Class Initialized
INFO - 2025-03-17 20:11:54 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:54 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:54 --> Email Class Initialized
INFO - 2025-03-17 20:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:54 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:54 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:54 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:54 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:54 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:54 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:54 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:54 --> Model Class Initialized
ERROR - 2025-03-17 20:11:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:54 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:54 --> Total execution time: 0.1385
INFO - 2025-03-17 20:11:54 --> Config Class Initialized
INFO - 2025-03-17 20:11:54 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:54 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:54 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:54 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:54 --> Router Class Initialized
INFO - 2025-03-17 20:11:54 --> Output Class Initialized
INFO - 2025-03-17 20:11:54 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:54 --> Input Class Initialized
INFO - 2025-03-17 20:11:54 --> Language Class Initialized
INFO - 2025-03-17 20:11:54 --> Language Class Initialized
INFO - 2025-03-17 20:11:54 --> Config Class Initialized
INFO - 2025-03-17 20:11:54 --> Loader Class Initialized
INFO - 2025-03-17 20:11:54 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:54 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:54 --> Email Class Initialized
INFO - 2025-03-17 20:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:54 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:54 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:54 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:54 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:54 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:54 --> Model Class Initialized
INFO - 2025-03-17 20:11:54 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:54 --> Total execution time: 0.0172
INFO - 2025-03-17 20:11:57 --> Config Class Initialized
INFO - 2025-03-17 20:11:57 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:57 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:57 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:57 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:57 --> Router Class Initialized
INFO - 2025-03-17 20:11:57 --> Output Class Initialized
INFO - 2025-03-17 20:11:57 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:57 --> Input Class Initialized
INFO - 2025-03-17 20:11:57 --> Language Class Initialized
INFO - 2025-03-17 20:11:57 --> Language Class Initialized
INFO - 2025-03-17 20:11:57 --> Config Class Initialized
INFO - 2025-03-17 20:11:57 --> Loader Class Initialized
INFO - 2025-03-17 20:11:57 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:57 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:57 --> Email Class Initialized
INFO - 2025-03-17 20:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:57 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:57 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:57 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:57 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:57 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:57 --> Model Class Initialized
INFO - 2025-03-17 20:11:57 --> Config Class Initialized
INFO - 2025-03-17 20:11:57 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:57 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:57 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:57 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:57 --> Router Class Initialized
INFO - 2025-03-17 20:11:57 --> Output Class Initialized
INFO - 2025-03-17 20:11:57 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:57 --> Input Class Initialized
INFO - 2025-03-17 20:11:57 --> Language Class Initialized
INFO - 2025-03-17 20:11:57 --> Language Class Initialized
INFO - 2025-03-17 20:11:57 --> Config Class Initialized
INFO - 2025-03-17 20:11:57 --> Loader Class Initialized
INFO - 2025-03-17 20:11:57 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:57 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:57 --> Email Class Initialized
INFO - 2025-03-17 20:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:57 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:57 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:57 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:57 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:57 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:57 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:11:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:11:57 --> Model Class Initialized
ERROR - 2025-03-17 20:11:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:11:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:11:57 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:57 --> Total execution time: 0.0898
INFO - 2025-03-17 20:11:57 --> Config Class Initialized
INFO - 2025-03-17 20:11:57 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:11:57 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:11:57 --> Utf8 Class Initialized
INFO - 2025-03-17 20:11:57 --> URI Class Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 20:11:57 --> Router Class Initialized
INFO - 2025-03-17 20:11:57 --> Output Class Initialized
INFO - 2025-03-17 20:11:57 --> Security Class Initialized
DEBUG - 2025-03-17 20:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:11:57 --> Input Class Initialized
INFO - 2025-03-17 20:11:57 --> Language Class Initialized
INFO - 2025-03-17 20:11:57 --> Language Class Initialized
INFO - 2025-03-17 20:11:57 --> Config Class Initialized
INFO - 2025-03-17 20:11:57 --> Loader Class Initialized
INFO - 2025-03-17 20:11:57 --> Helper loaded: url_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: file_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: html_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: form_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: text_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:11:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:11:57 --> Database Driver Class Initialized
INFO - 2025-03-17 20:11:57 --> Email Class Initialized
INFO - 2025-03-17 20:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:11:57 --> Form Validation Class Initialized
INFO - 2025-03-17 20:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:11:57 --> Pagination Class Initialized
INFO - 2025-03-17 20:11:57 --> Controller Class Initialized
DEBUG - 2025-03-17 20:11:57 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 20:11:57 --> Model Class Initialized
DEBUG - 2025-03-17 20:11:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 20:11:57 --> Model Class Initialized
INFO - 2025-03-17 20:11:57 --> Final output sent to browser
DEBUG - 2025-03-17 20:11:57 --> Total execution time: 0.0098
INFO - 2025-03-17 20:12:02 --> Config Class Initialized
INFO - 2025-03-17 20:12:02 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:12:02 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:12:02 --> Utf8 Class Initialized
INFO - 2025-03-17 20:12:02 --> URI Class Initialized
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:12:02 --> Router Class Initialized
INFO - 2025-03-17 20:12:02 --> Output Class Initialized
INFO - 2025-03-17 20:12:02 --> Security Class Initialized
DEBUG - 2025-03-17 20:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:12:02 --> Input Class Initialized
INFO - 2025-03-17 20:12:02 --> Language Class Initialized
INFO - 2025-03-17 20:12:02 --> Language Class Initialized
INFO - 2025-03-17 20:12:02 --> Config Class Initialized
INFO - 2025-03-17 20:12:02 --> Loader Class Initialized
INFO - 2025-03-17 20:12:02 --> Helper loaded: url_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: file_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: html_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: form_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: text_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:12:02 --> Database Driver Class Initialized
INFO - 2025-03-17 20:12:02 --> Email Class Initialized
INFO - 2025-03-17 20:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:12:02 --> Form Validation Class Initialized
INFO - 2025-03-17 20:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:12:02 --> Pagination Class Initialized
INFO - 2025-03-17 20:12:02 --> Controller Class Initialized
DEBUG - 2025-03-17 20:12:02 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:12:02 --> Model Class Initialized
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:12:02 --> Model Class Initialized
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:12:02 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:12:02 --> Model Class Initialized
ERROR - 2025-03-17 20:12:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:12:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:12:02 --> Final output sent to browser
DEBUG - 2025-03-17 20:12:02 --> Total execution time: 0.0842
INFO - 2025-03-17 20:12:02 --> Config Class Initialized
INFO - 2025-03-17 20:12:02 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:12:02 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:12:02 --> Utf8 Class Initialized
INFO - 2025-03-17 20:12:02 --> URI Class Initialized
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:12:02 --> Router Class Initialized
INFO - 2025-03-17 20:12:02 --> Output Class Initialized
INFO - 2025-03-17 20:12:02 --> Security Class Initialized
DEBUG - 2025-03-17 20:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:12:02 --> Input Class Initialized
INFO - 2025-03-17 20:12:02 --> Language Class Initialized
INFO - 2025-03-17 20:12:02 --> Language Class Initialized
INFO - 2025-03-17 20:12:02 --> Config Class Initialized
INFO - 2025-03-17 20:12:02 --> Loader Class Initialized
INFO - 2025-03-17 20:12:02 --> Helper loaded: url_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: file_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: html_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: form_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: text_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:12:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:12:02 --> Database Driver Class Initialized
INFO - 2025-03-17 20:12:02 --> Email Class Initialized
INFO - 2025-03-17 20:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:12:02 --> Form Validation Class Initialized
INFO - 2025-03-17 20:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:12:02 --> Pagination Class Initialized
INFO - 2025-03-17 20:12:02 --> Controller Class Initialized
DEBUG - 2025-03-17 20:12:02 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:12:02 --> Model Class Initialized
DEBUG - 2025-03-17 20:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:12:02 --> Model Class Initialized
ERROR - 2025-03-17 20:12:02 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:12:02 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:12:02 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:12:02 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:12:02 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:12:02 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:12:02 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:12:02 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:12:02 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:12:06 --> Config Class Initialized
INFO - 2025-03-17 20:12:06 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:12:06 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:12:06 --> Utf8 Class Initialized
INFO - 2025-03-17 20:12:06 --> URI Class Initialized
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 20:12:06 --> Router Class Initialized
INFO - 2025-03-17 20:12:06 --> Output Class Initialized
INFO - 2025-03-17 20:12:06 --> Security Class Initialized
DEBUG - 2025-03-17 20:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:12:06 --> Input Class Initialized
INFO - 2025-03-17 20:12:06 --> Language Class Initialized
INFO - 2025-03-17 20:12:06 --> Language Class Initialized
INFO - 2025-03-17 20:12:06 --> Config Class Initialized
INFO - 2025-03-17 20:12:06 --> Loader Class Initialized
INFO - 2025-03-17 20:12:06 --> Helper loaded: url_helper
INFO - 2025-03-17 20:12:06 --> Helper loaded: file_helper
INFO - 2025-03-17 20:12:06 --> Helper loaded: html_helper
INFO - 2025-03-17 20:12:06 --> Helper loaded: form_helper
INFO - 2025-03-17 20:12:06 --> Helper loaded: text_helper
INFO - 2025-03-17 20:12:06 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:12:06 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:12:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:12:06 --> Database Driver Class Initialized
INFO - 2025-03-17 20:12:06 --> Email Class Initialized
INFO - 2025-03-17 20:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:12:06 --> Form Validation Class Initialized
INFO - 2025-03-17 20:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:12:06 --> Pagination Class Initialized
INFO - 2025-03-17 20:12:06 --> Controller Class Initialized
DEBUG - 2025-03-17 20:12:06 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 20:12:06 --> Model Class Initialized
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 20:12:06 --> Model Class Initialized
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:12:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:12:06 --> Model Class Initialized
ERROR - 2025-03-17 20:12:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:12:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:12:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:12:06 --> Final output sent to browser
DEBUG - 2025-03-17 20:12:06 --> Total execution time: 0.1834
INFO - 2025-03-17 20:12:07 --> Config Class Initialized
INFO - 2025-03-17 20:12:07 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:12:07 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:12:07 --> Utf8 Class Initialized
INFO - 2025-03-17 20:12:07 --> URI Class Initialized
DEBUG - 2025-03-17 20:12:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 20:12:07 --> Router Class Initialized
INFO - 2025-03-17 20:12:07 --> Output Class Initialized
INFO - 2025-03-17 20:12:07 --> Security Class Initialized
DEBUG - 2025-03-17 20:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:12:07 --> Input Class Initialized
INFO - 2025-03-17 20:12:07 --> Language Class Initialized
INFO - 2025-03-17 20:12:07 --> Language Class Initialized
INFO - 2025-03-17 20:12:07 --> Config Class Initialized
INFO - 2025-03-17 20:12:07 --> Loader Class Initialized
INFO - 2025-03-17 20:12:07 --> Helper loaded: url_helper
INFO - 2025-03-17 20:12:07 --> Helper loaded: file_helper
INFO - 2025-03-17 20:12:07 --> Helper loaded: html_helper
INFO - 2025-03-17 20:12:07 --> Helper loaded: form_helper
INFO - 2025-03-17 20:12:07 --> Helper loaded: text_helper
INFO - 2025-03-17 20:12:07 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:12:07 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:12:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:12:07 --> Database Driver Class Initialized
INFO - 2025-03-17 20:12:07 --> Email Class Initialized
INFO - 2025-03-17 20:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:12:07 --> Form Validation Class Initialized
INFO - 2025-03-17 20:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:12:07 --> Pagination Class Initialized
INFO - 2025-03-17 20:12:07 --> Controller Class Initialized
DEBUG - 2025-03-17 20:12:07 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 20:12:07 --> Model Class Initialized
DEBUG - 2025-03-17 20:12:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 20:12:07 --> Model Class Initialized
INFO - 2025-03-17 20:12:07 --> Final output sent to browser
DEBUG - 2025-03-17 20:12:07 --> Total execution time: 0.0131
INFO - 2025-03-17 20:23:57 --> Config Class Initialized
INFO - 2025-03-17 20:23:57 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:23:57 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:23:57 --> Utf8 Class Initialized
INFO - 2025-03-17 20:23:57 --> URI Class Initialized
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:23:57 --> Router Class Initialized
INFO - 2025-03-17 20:23:57 --> Output Class Initialized
INFO - 2025-03-17 20:23:57 --> Security Class Initialized
DEBUG - 2025-03-17 20:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:23:57 --> Input Class Initialized
INFO - 2025-03-17 20:23:57 --> Language Class Initialized
INFO - 2025-03-17 20:23:57 --> Language Class Initialized
INFO - 2025-03-17 20:23:57 --> Config Class Initialized
INFO - 2025-03-17 20:23:57 --> Loader Class Initialized
INFO - 2025-03-17 20:23:57 --> Helper loaded: url_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: file_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: html_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: form_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: text_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:23:57 --> Database Driver Class Initialized
INFO - 2025-03-17 20:23:57 --> Email Class Initialized
INFO - 2025-03-17 20:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:23:57 --> Form Validation Class Initialized
INFO - 2025-03-17 20:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:23:57 --> Pagination Class Initialized
INFO - 2025-03-17 20:23:57 --> Controller Class Initialized
DEBUG - 2025-03-17 20:23:57 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:23:57 --> Model Class Initialized
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:23:57 --> Model Class Initialized
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:23:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:23:57 --> Model Class Initialized
ERROR - 2025-03-17 20:23:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:23:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:23:57 --> Final output sent to browser
DEBUG - 2025-03-17 20:23:57 --> Total execution time: 0.1571
INFO - 2025-03-17 20:23:57 --> Config Class Initialized
INFO - 2025-03-17 20:23:57 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:23:57 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:23:57 --> Utf8 Class Initialized
INFO - 2025-03-17 20:23:57 --> URI Class Initialized
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:23:57 --> Router Class Initialized
INFO - 2025-03-17 20:23:57 --> Output Class Initialized
INFO - 2025-03-17 20:23:57 --> Security Class Initialized
DEBUG - 2025-03-17 20:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:23:57 --> Input Class Initialized
INFO - 2025-03-17 20:23:57 --> Language Class Initialized
INFO - 2025-03-17 20:23:57 --> Language Class Initialized
INFO - 2025-03-17 20:23:57 --> Config Class Initialized
INFO - 2025-03-17 20:23:57 --> Loader Class Initialized
INFO - 2025-03-17 20:23:57 --> Helper loaded: url_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: file_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: html_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: form_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: text_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:23:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:23:57 --> Database Driver Class Initialized
INFO - 2025-03-17 20:23:57 --> Email Class Initialized
INFO - 2025-03-17 20:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:23:57 --> Form Validation Class Initialized
INFO - 2025-03-17 20:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:23:57 --> Pagination Class Initialized
INFO - 2025-03-17 20:23:57 --> Controller Class Initialized
DEBUG - 2025-03-17 20:23:57 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:23:57 --> Model Class Initialized
DEBUG - 2025-03-17 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:23:57 --> Model Class Initialized
ERROR - 2025-03-17 20:23:57 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:23:57 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:23:57 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:23:57 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:23:57 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:23:57 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:23:57 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:23:57 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:23:57 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:27:21 --> Config Class Initialized
INFO - 2025-03-17 20:27:21 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:27:21 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:27:21 --> Utf8 Class Initialized
INFO - 2025-03-17 20:27:21 --> URI Class Initialized
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:27:21 --> Router Class Initialized
INFO - 2025-03-17 20:27:21 --> Output Class Initialized
INFO - 2025-03-17 20:27:21 --> Security Class Initialized
DEBUG - 2025-03-17 20:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:27:21 --> Input Class Initialized
INFO - 2025-03-17 20:27:21 --> Language Class Initialized
INFO - 2025-03-17 20:27:21 --> Language Class Initialized
INFO - 2025-03-17 20:27:21 --> Config Class Initialized
INFO - 2025-03-17 20:27:21 --> Loader Class Initialized
INFO - 2025-03-17 20:27:21 --> Helper loaded: url_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: file_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: html_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: form_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: text_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:27:21 --> Database Driver Class Initialized
INFO - 2025-03-17 20:27:21 --> Email Class Initialized
INFO - 2025-03-17 20:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:27:21 --> Form Validation Class Initialized
INFO - 2025-03-17 20:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:27:21 --> Pagination Class Initialized
INFO - 2025-03-17 20:27:21 --> Controller Class Initialized
DEBUG - 2025-03-17 20:27:21 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:27:21 --> Model Class Initialized
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:27:21 --> Model Class Initialized
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:27:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:27:21 --> Model Class Initialized
ERROR - 2025-03-17 20:27:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:27:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/credit_customer.php
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:27:21 --> Final output sent to browser
DEBUG - 2025-03-17 20:27:21 --> Total execution time: 0.3487
INFO - 2025-03-17 20:27:21 --> Config Class Initialized
INFO - 2025-03-17 20:27:21 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:27:21 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:27:21 --> Utf8 Class Initialized
INFO - 2025-03-17 20:27:21 --> URI Class Initialized
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:27:21 --> Router Class Initialized
INFO - 2025-03-17 20:27:21 --> Output Class Initialized
INFO - 2025-03-17 20:27:21 --> Security Class Initialized
DEBUG - 2025-03-17 20:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:27:21 --> Input Class Initialized
INFO - 2025-03-17 20:27:21 --> Language Class Initialized
INFO - 2025-03-17 20:27:21 --> Language Class Initialized
INFO - 2025-03-17 20:27:21 --> Config Class Initialized
INFO - 2025-03-17 20:27:21 --> Loader Class Initialized
INFO - 2025-03-17 20:27:21 --> Helper loaded: url_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: file_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: html_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: form_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: text_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:27:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:27:21 --> Database Driver Class Initialized
INFO - 2025-03-17 20:27:21 --> Email Class Initialized
INFO - 2025-03-17 20:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:27:21 --> Form Validation Class Initialized
INFO - 2025-03-17 20:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:27:21 --> Pagination Class Initialized
INFO - 2025-03-17 20:27:21 --> Controller Class Initialized
DEBUG - 2025-03-17 20:27:21 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:27:21 --> Model Class Initialized
DEBUG - 2025-03-17 20:27:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:27:21 --> Model Class Initialized
ERROR - 2025-03-17 20:27:21 --> Severity: error --> Exception: Unknown column 'i.previous_due' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-17 20:27:52 --> Config Class Initialized
INFO - 2025-03-17 20:27:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:27:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:27:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:27:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:27:52 --> Router Class Initialized
INFO - 2025-03-17 20:27:52 --> Output Class Initialized
INFO - 2025-03-17 20:27:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:27:52 --> Input Class Initialized
INFO - 2025-03-17 20:27:52 --> Language Class Initialized
INFO - 2025-03-17 20:27:52 --> Language Class Initialized
INFO - 2025-03-17 20:27:52 --> Config Class Initialized
INFO - 2025-03-17 20:27:52 --> Loader Class Initialized
INFO - 2025-03-17 20:27:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:27:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:27:52 --> Email Class Initialized
INFO - 2025-03-17 20:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:27:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:27:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:27:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:27:52 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:27:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:27:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:27:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:27:52 --> Model Class Initialized
ERROR - 2025-03-17 20:27:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:27:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/paid_customer.php
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:27:52 --> Final output sent to browser
DEBUG - 2025-03-17 20:27:52 --> Total execution time: 0.1889
INFO - 2025-03-17 20:27:52 --> Config Class Initialized
INFO - 2025-03-17 20:27:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:27:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:27:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:27:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:27:52 --> Router Class Initialized
INFO - 2025-03-17 20:27:52 --> Output Class Initialized
INFO - 2025-03-17 20:27:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:27:52 --> Input Class Initialized
INFO - 2025-03-17 20:27:52 --> Language Class Initialized
INFO - 2025-03-17 20:27:52 --> Language Class Initialized
INFO - 2025-03-17 20:27:52 --> Config Class Initialized
INFO - 2025-03-17 20:27:52 --> Loader Class Initialized
INFO - 2025-03-17 20:27:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:27:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:27:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:27:52 --> Email Class Initialized
INFO - 2025-03-17 20:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:27:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:27:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:27:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:27:52 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:27:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:27:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:27:52 --> Model Class Initialized
INFO - 2025-03-17 20:27:52 --> Final output sent to browser
DEBUG - 2025-03-17 20:27:52 --> Total execution time: 0.0155
INFO - 2025-03-17 20:28:04 --> Config Class Initialized
INFO - 2025-03-17 20:28:04 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:28:04 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:28:04 --> Utf8 Class Initialized
INFO - 2025-03-17 20:28:04 --> URI Class Initialized
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:28:04 --> Router Class Initialized
INFO - 2025-03-17 20:28:04 --> Output Class Initialized
INFO - 2025-03-17 20:28:04 --> Security Class Initialized
DEBUG - 2025-03-17 20:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:28:04 --> Input Class Initialized
INFO - 2025-03-17 20:28:04 --> Language Class Initialized
INFO - 2025-03-17 20:28:04 --> Language Class Initialized
INFO - 2025-03-17 20:28:04 --> Config Class Initialized
INFO - 2025-03-17 20:28:04 --> Loader Class Initialized
INFO - 2025-03-17 20:28:04 --> Helper loaded: url_helper
INFO - 2025-03-17 20:28:04 --> Helper loaded: file_helper
INFO - 2025-03-17 20:28:04 --> Helper loaded: html_helper
INFO - 2025-03-17 20:28:04 --> Helper loaded: form_helper
INFO - 2025-03-17 20:28:04 --> Helper loaded: text_helper
INFO - 2025-03-17 20:28:04 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:28:04 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:28:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:28:04 --> Database Driver Class Initialized
INFO - 2025-03-17 20:28:04 --> Email Class Initialized
INFO - 2025-03-17 20:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:28:04 --> Form Validation Class Initialized
INFO - 2025-03-17 20:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:28:04 --> Pagination Class Initialized
INFO - 2025-03-17 20:28:04 --> Controller Class Initialized
DEBUG - 2025-03-17 20:28:04 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:28:04 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:28:04 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:28:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:28:04 --> Model Class Initialized
ERROR - 2025-03-17 20:28:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:28:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/credit_customer.php
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:28:04 --> Final output sent to browser
DEBUG - 2025-03-17 20:28:04 --> Total execution time: 0.2390
INFO - 2025-03-17 20:28:05 --> Config Class Initialized
INFO - 2025-03-17 20:28:05 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:28:05 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:28:05 --> Utf8 Class Initialized
INFO - 2025-03-17 20:28:05 --> URI Class Initialized
DEBUG - 2025-03-17 20:28:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:28:05 --> Router Class Initialized
INFO - 2025-03-17 20:28:05 --> Output Class Initialized
INFO - 2025-03-17 20:28:05 --> Security Class Initialized
DEBUG - 2025-03-17 20:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:28:05 --> Input Class Initialized
INFO - 2025-03-17 20:28:05 --> Language Class Initialized
INFO - 2025-03-17 20:28:05 --> Language Class Initialized
INFO - 2025-03-17 20:28:05 --> Config Class Initialized
INFO - 2025-03-17 20:28:05 --> Loader Class Initialized
INFO - 2025-03-17 20:28:05 --> Helper loaded: url_helper
INFO - 2025-03-17 20:28:05 --> Helper loaded: file_helper
INFO - 2025-03-17 20:28:05 --> Helper loaded: html_helper
INFO - 2025-03-17 20:28:05 --> Helper loaded: form_helper
INFO - 2025-03-17 20:28:05 --> Helper loaded: text_helper
INFO - 2025-03-17 20:28:05 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:28:05 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:28:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:28:05 --> Database Driver Class Initialized
INFO - 2025-03-17 20:28:05 --> Email Class Initialized
INFO - 2025-03-17 20:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:28:05 --> Form Validation Class Initialized
INFO - 2025-03-17 20:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:28:05 --> Pagination Class Initialized
INFO - 2025-03-17 20:28:05 --> Controller Class Initialized
DEBUG - 2025-03-17 20:28:05 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:28:05 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:28:05 --> Model Class Initialized
ERROR - 2025-03-17 20:28:05 --> Severity: error --> Exception: Unknown column 'i.previous_due' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-17 20:28:18 --> Config Class Initialized
INFO - 2025-03-17 20:28:18 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:28:18 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:28:18 --> Utf8 Class Initialized
INFO - 2025-03-17 20:28:18 --> URI Class Initialized
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:28:18 --> Router Class Initialized
INFO - 2025-03-17 20:28:18 --> Output Class Initialized
INFO - 2025-03-17 20:28:18 --> Security Class Initialized
DEBUG - 2025-03-17 20:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:28:18 --> Input Class Initialized
INFO - 2025-03-17 20:28:18 --> Language Class Initialized
INFO - 2025-03-17 20:28:18 --> Language Class Initialized
INFO - 2025-03-17 20:28:18 --> Config Class Initialized
INFO - 2025-03-17 20:28:18 --> Loader Class Initialized
INFO - 2025-03-17 20:28:18 --> Helper loaded: url_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: file_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: html_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: form_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: text_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:28:18 --> Database Driver Class Initialized
INFO - 2025-03-17 20:28:18 --> Email Class Initialized
INFO - 2025-03-17 20:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:28:18 --> Form Validation Class Initialized
INFO - 2025-03-17 20:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:28:18 --> Pagination Class Initialized
INFO - 2025-03-17 20:28:18 --> Controller Class Initialized
DEBUG - 2025-03-17 20:28:18 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:28:18 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:28:18 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:28:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:28:18 --> Model Class Initialized
ERROR - 2025-03-17 20:28:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:28:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:28:18 --> Final output sent to browser
DEBUG - 2025-03-17 20:28:18 --> Total execution time: 0.1966
INFO - 2025-03-17 20:28:18 --> Config Class Initialized
INFO - 2025-03-17 20:28:18 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:28:18 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:28:18 --> Utf8 Class Initialized
INFO - 2025-03-17 20:28:18 --> URI Class Initialized
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:28:18 --> Router Class Initialized
INFO - 2025-03-17 20:28:18 --> Output Class Initialized
INFO - 2025-03-17 20:28:18 --> Security Class Initialized
DEBUG - 2025-03-17 20:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:28:18 --> Input Class Initialized
INFO - 2025-03-17 20:28:18 --> Language Class Initialized
INFO - 2025-03-17 20:28:18 --> Language Class Initialized
INFO - 2025-03-17 20:28:18 --> Config Class Initialized
INFO - 2025-03-17 20:28:18 --> Loader Class Initialized
INFO - 2025-03-17 20:28:18 --> Helper loaded: url_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: file_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: html_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: form_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: text_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:28:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:28:18 --> Database Driver Class Initialized
INFO - 2025-03-17 20:28:18 --> Email Class Initialized
INFO - 2025-03-17 20:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:28:18 --> Form Validation Class Initialized
INFO - 2025-03-17 20:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:28:18 --> Pagination Class Initialized
INFO - 2025-03-17 20:28:18 --> Controller Class Initialized
DEBUG - 2025-03-17 20:28:18 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:28:18 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:28:18 --> Model Class Initialized
ERROR - 2025-03-17 20:28:18 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:28:18 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:28:18 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:28:18 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:28:18 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:28:18 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:28:18 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:28:18 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:28:18 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:28:33 --> Config Class Initialized
INFO - 2025-03-17 20:28:33 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:28:33 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:28:33 --> Utf8 Class Initialized
INFO - 2025-03-17 20:28:33 --> URI Class Initialized
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:28:33 --> Router Class Initialized
INFO - 2025-03-17 20:28:33 --> Output Class Initialized
INFO - 2025-03-17 20:28:33 --> Security Class Initialized
DEBUG - 2025-03-17 20:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:28:33 --> Input Class Initialized
INFO - 2025-03-17 20:28:33 --> Language Class Initialized
INFO - 2025-03-17 20:28:33 --> Language Class Initialized
INFO - 2025-03-17 20:28:33 --> Config Class Initialized
INFO - 2025-03-17 20:28:33 --> Loader Class Initialized
INFO - 2025-03-17 20:28:33 --> Helper loaded: url_helper
INFO - 2025-03-17 20:28:33 --> Helper loaded: file_helper
INFO - 2025-03-17 20:28:33 --> Helper loaded: html_helper
INFO - 2025-03-17 20:28:33 --> Helper loaded: form_helper
INFO - 2025-03-17 20:28:33 --> Helper loaded: text_helper
INFO - 2025-03-17 20:28:33 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:28:33 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:28:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:28:33 --> Database Driver Class Initialized
INFO - 2025-03-17 20:28:33 --> Email Class Initialized
INFO - 2025-03-17 20:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:28:33 --> Form Validation Class Initialized
INFO - 2025-03-17 20:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:28:33 --> Pagination Class Initialized
INFO - 2025-03-17 20:28:33 --> Controller Class Initialized
DEBUG - 2025-03-17 20:28:33 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:28:33 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:28:33 --> Model Class Initialized
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:28:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:28:33 --> Model Class Initialized
ERROR - 2025-03-17 20:28:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:28:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_advance.php
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:28:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:28:33 --> Final output sent to browser
DEBUG - 2025-03-17 20:28:33 --> Total execution time: 0.1698
INFO - 2025-03-17 20:29:13 --> Config Class Initialized
INFO - 2025-03-17 20:29:13 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:29:13 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:29:13 --> Utf8 Class Initialized
INFO - 2025-03-17 20:29:13 --> URI Class Initialized
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/hrm/config/routes.php
INFO - 2025-03-17 20:29:13 --> Router Class Initialized
INFO - 2025-03-17 20:29:13 --> Output Class Initialized
INFO - 2025-03-17 20:29:13 --> Security Class Initialized
DEBUG - 2025-03-17 20:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:29:13 --> Input Class Initialized
INFO - 2025-03-17 20:29:13 --> Language Class Initialized
INFO - 2025-03-17 20:29:13 --> Language Class Initialized
INFO - 2025-03-17 20:29:13 --> Config Class Initialized
INFO - 2025-03-17 20:29:13 --> Loader Class Initialized
INFO - 2025-03-17 20:29:13 --> Helper loaded: url_helper
INFO - 2025-03-17 20:29:13 --> Helper loaded: file_helper
INFO - 2025-03-17 20:29:13 --> Helper loaded: html_helper
INFO - 2025-03-17 20:29:13 --> Helper loaded: form_helper
INFO - 2025-03-17 20:29:13 --> Helper loaded: text_helper
INFO - 2025-03-17 20:29:13 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:29:13 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:29:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:29:13 --> Database Driver Class Initialized
INFO - 2025-03-17 20:29:13 --> Email Class Initialized
INFO - 2025-03-17 20:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:29:13 --> Form Validation Class Initialized
INFO - 2025-03-17 20:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:29:13 --> Pagination Class Initialized
INFO - 2025-03-17 20:29:13 --> Controller Class Initialized
DEBUG - 2025-03-17 20:29:13 --> Attendance MX_Controller Initialized
INFO - 2025-03-17 20:29:13 --> Model Class Initialized
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/hrm/models/Attendance_model.php
INFO - 2025-03-17 20:29:13 --> Model Class Initialized
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:29:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:29:13 --> Model Class Initialized
ERROR - 2025-03-17 20:29:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:29:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/hrm/views/attendance/attendance_form.php
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:29:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:29:13 --> Final output sent to browser
DEBUG - 2025-03-17 20:29:13 --> Total execution time: 0.1086
INFO - 2025-03-17 20:29:18 --> Config Class Initialized
INFO - 2025-03-17 20:29:18 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:29:18 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:29:18 --> Utf8 Class Initialized
INFO - 2025-03-17 20:29:18 --> URI Class Initialized
DEBUG - 2025-03-17 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:29:18 --> Router Class Initialized
INFO - 2025-03-17 20:29:18 --> Output Class Initialized
INFO - 2025-03-17 20:29:18 --> Security Class Initialized
DEBUG - 2025-03-17 20:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:29:18 --> Input Class Initialized
INFO - 2025-03-17 20:29:18 --> Language Class Initialized
INFO - 2025-03-17 20:29:18 --> Language Class Initialized
INFO - 2025-03-17 20:29:18 --> Config Class Initialized
INFO - 2025-03-17 20:29:18 --> Loader Class Initialized
INFO - 2025-03-17 20:29:18 --> Helper loaded: url_helper
INFO - 2025-03-17 20:29:18 --> Helper loaded: file_helper
INFO - 2025-03-17 20:29:18 --> Helper loaded: html_helper
INFO - 2025-03-17 20:29:18 --> Helper loaded: form_helper
INFO - 2025-03-17 20:29:18 --> Helper loaded: text_helper
INFO - 2025-03-17 20:29:18 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:29:18 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:29:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:29:18 --> Database Driver Class Initialized
INFO - 2025-03-17 20:29:18 --> Email Class Initialized
INFO - 2025-03-17 20:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:29:18 --> Form Validation Class Initialized
INFO - 2025-03-17 20:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:29:18 --> Pagination Class Initialized
INFO - 2025-03-17 20:29:18 --> Controller Class Initialized
DEBUG - 2025-03-17 20:29:18 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:29:18 --> Model Class Initialized
DEBUG - 2025-03-17 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:29:18 --> Model Class Initialized
ERROR - 2025-03-17 20:29:18 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-17 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:29:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:29:18 --> Model Class Initialized
ERROR - 2025-03-17 20:29:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:29:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:29:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:29:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:29:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:29:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-17 20:29:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:29:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:29:19 --> Final output sent to browser
DEBUG - 2025-03-17 20:29:19 --> Total execution time: 0.2400
INFO - 2025-03-17 20:29:20 --> Config Class Initialized
INFO - 2025-03-17 20:29:20 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:29:20 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:29:20 --> Utf8 Class Initialized
INFO - 2025-03-17 20:29:20 --> URI Class Initialized
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:29:20 --> Router Class Initialized
INFO - 2025-03-17 20:29:20 --> Output Class Initialized
INFO - 2025-03-17 20:29:20 --> Security Class Initialized
DEBUG - 2025-03-17 20:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:29:20 --> Input Class Initialized
INFO - 2025-03-17 20:29:20 --> Language Class Initialized
INFO - 2025-03-17 20:29:20 --> Language Class Initialized
INFO - 2025-03-17 20:29:20 --> Config Class Initialized
INFO - 2025-03-17 20:29:20 --> Loader Class Initialized
INFO - 2025-03-17 20:29:20 --> Helper loaded: url_helper
INFO - 2025-03-17 20:29:20 --> Helper loaded: file_helper
INFO - 2025-03-17 20:29:20 --> Helper loaded: html_helper
INFO - 2025-03-17 20:29:20 --> Helper loaded: form_helper
INFO - 2025-03-17 20:29:20 --> Helper loaded: text_helper
INFO - 2025-03-17 20:29:20 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:29:20 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:29:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:29:20 --> Database Driver Class Initialized
INFO - 2025-03-17 20:29:20 --> Email Class Initialized
INFO - 2025-03-17 20:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:29:20 --> Form Validation Class Initialized
INFO - 2025-03-17 20:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:29:20 --> Pagination Class Initialized
INFO - 2025-03-17 20:29:20 --> Controller Class Initialized
DEBUG - 2025-03-17 20:29:20 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:29:20 --> Model Class Initialized
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:29:20 --> Model Class Initialized
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:29:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:29:20 --> Model Class Initialized
ERROR - 2025-03-17 20:29:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:29:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:29:20 --> Final output sent to browser
DEBUG - 2025-03-17 20:29:20 --> Total execution time: 0.1828
INFO - 2025-03-17 20:29:21 --> Config Class Initialized
INFO - 2025-03-17 20:29:21 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:29:21 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:29:21 --> Utf8 Class Initialized
INFO - 2025-03-17 20:29:21 --> URI Class Initialized
DEBUG - 2025-03-17 20:29:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:29:21 --> Router Class Initialized
INFO - 2025-03-17 20:29:21 --> Output Class Initialized
INFO - 2025-03-17 20:29:21 --> Security Class Initialized
DEBUG - 2025-03-17 20:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:29:21 --> Input Class Initialized
INFO - 2025-03-17 20:29:21 --> Language Class Initialized
INFO - 2025-03-17 20:29:21 --> Language Class Initialized
INFO - 2025-03-17 20:29:21 --> Config Class Initialized
INFO - 2025-03-17 20:29:21 --> Loader Class Initialized
INFO - 2025-03-17 20:29:21 --> Helper loaded: url_helper
INFO - 2025-03-17 20:29:21 --> Helper loaded: file_helper
INFO - 2025-03-17 20:29:21 --> Helper loaded: html_helper
INFO - 2025-03-17 20:29:21 --> Helper loaded: form_helper
INFO - 2025-03-17 20:29:21 --> Helper loaded: text_helper
INFO - 2025-03-17 20:29:21 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:29:21 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:29:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:29:21 --> Database Driver Class Initialized
INFO - 2025-03-17 20:29:21 --> Email Class Initialized
INFO - 2025-03-17 20:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:29:21 --> Form Validation Class Initialized
INFO - 2025-03-17 20:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:29:21 --> Pagination Class Initialized
INFO - 2025-03-17 20:29:21 --> Controller Class Initialized
DEBUG - 2025-03-17 20:29:21 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:29:21 --> Model Class Initialized
DEBUG - 2025-03-17 20:29:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:29:21 --> Model Class Initialized
ERROR - 2025-03-17 20:29:21 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:29:21 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:29:21 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:29:21 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:29:21 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:29:21 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:29:21 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:29:21 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:29:21 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:30:41 --> Config Class Initialized
INFO - 2025-03-17 20:30:41 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:30:41 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:30:41 --> Utf8 Class Initialized
INFO - 2025-03-17 20:30:41 --> URI Class Initialized
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:30:41 --> Router Class Initialized
INFO - 2025-03-17 20:30:41 --> Output Class Initialized
INFO - 2025-03-17 20:30:41 --> Security Class Initialized
DEBUG - 2025-03-17 20:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:30:41 --> Input Class Initialized
INFO - 2025-03-17 20:30:41 --> Language Class Initialized
INFO - 2025-03-17 20:30:41 --> Language Class Initialized
INFO - 2025-03-17 20:30:41 --> Config Class Initialized
INFO - 2025-03-17 20:30:41 --> Loader Class Initialized
INFO - 2025-03-17 20:30:41 --> Helper loaded: url_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: file_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: html_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: form_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: text_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:30:41 --> Database Driver Class Initialized
INFO - 2025-03-17 20:30:41 --> Email Class Initialized
INFO - 2025-03-17 20:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:30:41 --> Form Validation Class Initialized
INFO - 2025-03-17 20:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:30:41 --> Pagination Class Initialized
INFO - 2025-03-17 20:30:41 --> Controller Class Initialized
DEBUG - 2025-03-17 20:30:41 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:30:41 --> Model Class Initialized
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:30:41 --> Model Class Initialized
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:30:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:30:41 --> Model Class Initialized
ERROR - 2025-03-17 20:30:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:30:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:30:41 --> Final output sent to browser
DEBUG - 2025-03-17 20:30:41 --> Total execution time: 0.1226
INFO - 2025-03-17 20:30:41 --> Config Class Initialized
INFO - 2025-03-17 20:30:41 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:30:41 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:30:41 --> Utf8 Class Initialized
INFO - 2025-03-17 20:30:41 --> URI Class Initialized
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:30:41 --> Router Class Initialized
INFO - 2025-03-17 20:30:41 --> Output Class Initialized
INFO - 2025-03-17 20:30:41 --> Security Class Initialized
DEBUG - 2025-03-17 20:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:30:41 --> Input Class Initialized
INFO - 2025-03-17 20:30:41 --> Language Class Initialized
INFO - 2025-03-17 20:30:41 --> Language Class Initialized
INFO - 2025-03-17 20:30:41 --> Config Class Initialized
INFO - 2025-03-17 20:30:41 --> Loader Class Initialized
INFO - 2025-03-17 20:30:41 --> Helper loaded: url_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: file_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: html_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: form_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: text_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:30:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:30:41 --> Database Driver Class Initialized
INFO - 2025-03-17 20:30:41 --> Email Class Initialized
INFO - 2025-03-17 20:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:30:41 --> Form Validation Class Initialized
INFO - 2025-03-17 20:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:30:41 --> Pagination Class Initialized
INFO - 2025-03-17 20:30:41 --> Controller Class Initialized
DEBUG - 2025-03-17 20:30:41 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:30:41 --> Model Class Initialized
DEBUG - 2025-03-17 20:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:30:41 --> Model Class Initialized
ERROR - 2025-03-17 20:30:41 --> Severity: error --> Exception: Unknown column 'i.previous_due' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-17 20:30:52 --> Config Class Initialized
INFO - 2025-03-17 20:30:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:30:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:30:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:30:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:30:52 --> Router Class Initialized
INFO - 2025-03-17 20:30:52 --> Output Class Initialized
INFO - 2025-03-17 20:30:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:30:52 --> Input Class Initialized
INFO - 2025-03-17 20:30:52 --> Language Class Initialized
INFO - 2025-03-17 20:30:52 --> Language Class Initialized
INFO - 2025-03-17 20:30:52 --> Config Class Initialized
INFO - 2025-03-17 20:30:52 --> Loader Class Initialized
INFO - 2025-03-17 20:30:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:30:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:30:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:30:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:30:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:30:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:30:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:30:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:30:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:30:52 --> Email Class Initialized
INFO - 2025-03-17 20:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:30:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:30:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:30:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:30:52 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:30:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:30:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:30:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:30:52 --> Model Class Initialized
ERROR - 2025-03-17 20:30:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:30:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:30:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:30:52 --> Final output sent to browser
DEBUG - 2025-03-17 20:30:52 --> Total execution time: 0.2090
INFO - 2025-03-17 20:30:53 --> Config Class Initialized
INFO - 2025-03-17 20:30:53 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:30:53 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:30:53 --> Utf8 Class Initialized
INFO - 2025-03-17 20:30:53 --> URI Class Initialized
DEBUG - 2025-03-17 20:30:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:30:53 --> Router Class Initialized
INFO - 2025-03-17 20:30:53 --> Output Class Initialized
INFO - 2025-03-17 20:30:53 --> Security Class Initialized
DEBUG - 2025-03-17 20:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:30:53 --> Input Class Initialized
INFO - 2025-03-17 20:30:53 --> Language Class Initialized
INFO - 2025-03-17 20:30:53 --> Language Class Initialized
INFO - 2025-03-17 20:30:53 --> Config Class Initialized
INFO - 2025-03-17 20:30:53 --> Loader Class Initialized
INFO - 2025-03-17 20:30:53 --> Helper loaded: url_helper
INFO - 2025-03-17 20:30:53 --> Helper loaded: file_helper
INFO - 2025-03-17 20:30:53 --> Helper loaded: html_helper
INFO - 2025-03-17 20:30:53 --> Helper loaded: form_helper
INFO - 2025-03-17 20:30:53 --> Helper loaded: text_helper
INFO - 2025-03-17 20:30:53 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:30:53 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:30:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:30:53 --> Database Driver Class Initialized
INFO - 2025-03-17 20:30:53 --> Email Class Initialized
INFO - 2025-03-17 20:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:30:53 --> Form Validation Class Initialized
INFO - 2025-03-17 20:30:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:30:53 --> Pagination Class Initialized
INFO - 2025-03-17 20:30:53 --> Controller Class Initialized
DEBUG - 2025-03-17 20:30:53 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:30:53 --> Model Class Initialized
DEBUG - 2025-03-17 20:30:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:30:53 --> Model Class Initialized
ERROR - 2025-03-17 20:30:53 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:30:53 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:30:53 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:30:53 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:30:53 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:30:53 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:30:53 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:30:53 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:30:53 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:32:22 --> Config Class Initialized
INFO - 2025-03-17 20:32:22 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:32:22 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:32:22 --> Utf8 Class Initialized
INFO - 2025-03-17 20:32:22 --> URI Class Initialized
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:32:22 --> Router Class Initialized
INFO - 2025-03-17 20:32:22 --> Output Class Initialized
INFO - 2025-03-17 20:32:22 --> Security Class Initialized
DEBUG - 2025-03-17 20:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:32:22 --> Input Class Initialized
INFO - 2025-03-17 20:32:22 --> Language Class Initialized
INFO - 2025-03-17 20:32:22 --> Language Class Initialized
INFO - 2025-03-17 20:32:22 --> Config Class Initialized
INFO - 2025-03-17 20:32:22 --> Loader Class Initialized
INFO - 2025-03-17 20:32:22 --> Helper loaded: url_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: file_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: html_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: form_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: text_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:32:22 --> Database Driver Class Initialized
INFO - 2025-03-17 20:32:22 --> Email Class Initialized
INFO - 2025-03-17 20:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:32:22 --> Form Validation Class Initialized
INFO - 2025-03-17 20:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:32:22 --> Pagination Class Initialized
INFO - 2025-03-17 20:32:22 --> Controller Class Initialized
DEBUG - 2025-03-17 20:32:22 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:32:22 --> Model Class Initialized
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:32:22 --> Model Class Initialized
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:32:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:32:22 --> Model Class Initialized
ERROR - 2025-03-17 20:32:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:32:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:32:22 --> Final output sent to browser
DEBUG - 2025-03-17 20:32:22 --> Total execution time: 0.1320
INFO - 2025-03-17 20:32:22 --> Config Class Initialized
INFO - 2025-03-17 20:32:22 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:32:22 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:32:22 --> Utf8 Class Initialized
INFO - 2025-03-17 20:32:22 --> URI Class Initialized
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:32:22 --> Router Class Initialized
INFO - 2025-03-17 20:32:22 --> Output Class Initialized
INFO - 2025-03-17 20:32:22 --> Security Class Initialized
DEBUG - 2025-03-17 20:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:32:22 --> Input Class Initialized
INFO - 2025-03-17 20:32:22 --> Language Class Initialized
INFO - 2025-03-17 20:32:22 --> Language Class Initialized
INFO - 2025-03-17 20:32:22 --> Config Class Initialized
INFO - 2025-03-17 20:32:22 --> Loader Class Initialized
INFO - 2025-03-17 20:32:22 --> Helper loaded: url_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: file_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: html_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: form_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: text_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:32:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:32:22 --> Database Driver Class Initialized
INFO - 2025-03-17 20:32:22 --> Email Class Initialized
INFO - 2025-03-17 20:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:32:22 --> Form Validation Class Initialized
INFO - 2025-03-17 20:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:32:22 --> Pagination Class Initialized
INFO - 2025-03-17 20:32:22 --> Controller Class Initialized
DEBUG - 2025-03-17 20:32:22 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:32:22 --> Model Class Initialized
DEBUG - 2025-03-17 20:32:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:32:22 --> Model Class Initialized
ERROR - 2025-03-17 20:32:22 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:32:22 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:32:22 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:32:22 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:32:22 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:32:22 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:32:22 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:32:22 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:32:22 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:32:31 --> Config Class Initialized
INFO - 2025-03-17 20:32:31 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:32:31 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:32:31 --> Utf8 Class Initialized
INFO - 2025-03-17 20:32:31 --> URI Class Initialized
DEBUG - 2025-03-17 20:32:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:32:31 --> Router Class Initialized
INFO - 2025-03-17 20:32:31 --> Output Class Initialized
INFO - 2025-03-17 20:32:31 --> Security Class Initialized
DEBUG - 2025-03-17 20:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:32:31 --> Input Class Initialized
INFO - 2025-03-17 20:32:31 --> Language Class Initialized
INFO - 2025-03-17 20:32:31 --> Language Class Initialized
INFO - 2025-03-17 20:32:31 --> Config Class Initialized
INFO - 2025-03-17 20:32:31 --> Loader Class Initialized
INFO - 2025-03-17 20:32:31 --> Helper loaded: url_helper
INFO - 2025-03-17 20:32:31 --> Helper loaded: file_helper
INFO - 2025-03-17 20:32:31 --> Helper loaded: html_helper
INFO - 2025-03-17 20:32:31 --> Helper loaded: form_helper
INFO - 2025-03-17 20:32:31 --> Helper loaded: text_helper
INFO - 2025-03-17 20:32:31 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:32:31 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:32:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:32:31 --> Database Driver Class Initialized
INFO - 2025-03-17 20:32:31 --> Email Class Initialized
INFO - 2025-03-17 20:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:32:31 --> Form Validation Class Initialized
INFO - 2025-03-17 20:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:32:31 --> Pagination Class Initialized
INFO - 2025-03-17 20:32:31 --> Controller Class Initialized
DEBUG - 2025-03-17 20:32:31 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:32:31 --> Model Class Initialized
DEBUG - 2025-03-17 20:32:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:32:31 --> Model Class Initialized
ERROR - 2025-03-17 20:32:31 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:32:31 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:32:31 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:32:31 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:32:31 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:32:31 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:32:31 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:32:31 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:32:31 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-17 20:52:20 --> Config Class Initialized
INFO - 2025-03-17 20:52:20 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:52:20 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:52:20 --> Utf8 Class Initialized
INFO - 2025-03-17 20:52:20 --> URI Class Initialized
DEBUG - 2025-03-17 20:52:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:52:20 --> Router Class Initialized
INFO - 2025-03-17 20:52:20 --> Output Class Initialized
INFO - 2025-03-17 20:52:20 --> Security Class Initialized
DEBUG - 2025-03-17 20:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:52:20 --> Input Class Initialized
INFO - 2025-03-17 20:52:20 --> Language Class Initialized
INFO - 2025-03-17 20:52:20 --> Language Class Initialized
INFO - 2025-03-17 20:52:20 --> Config Class Initialized
INFO - 2025-03-17 20:52:20 --> Loader Class Initialized
INFO - 2025-03-17 20:52:20 --> Helper loaded: url_helper
INFO - 2025-03-17 20:52:20 --> Helper loaded: file_helper
INFO - 2025-03-17 20:52:20 --> Helper loaded: html_helper
INFO - 2025-03-17 20:52:20 --> Helper loaded: form_helper
INFO - 2025-03-17 20:52:20 --> Helper loaded: text_helper
INFO - 2025-03-17 20:52:20 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:52:20 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:52:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:52:20 --> Database Driver Class Initialized
INFO - 2025-03-17 20:52:20 --> Email Class Initialized
INFO - 2025-03-17 20:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:52:20 --> Form Validation Class Initialized
INFO - 2025-03-17 20:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:52:20 --> Pagination Class Initialized
INFO - 2025-03-17 20:52:20 --> Controller Class Initialized
DEBUG - 2025-03-17 20:52:20 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:52:20 --> Model Class Initialized
DEBUG - 2025-03-17 20:52:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:52:20 --> Model Class Initialized
ERROR - 2025-03-17 20:52:20 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:52:20 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:52:20 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:52:20 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:52:20 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:52:20 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:52:20 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:52:20 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"275.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:52:20 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"275.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-17 20:52:35 --> Config Class Initialized
INFO - 2025-03-17 20:52:35 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:52:35 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:52:35 --> Utf8 Class Initialized
INFO - 2025-03-17 20:52:35 --> URI Class Initialized
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:52:35 --> Router Class Initialized
INFO - 2025-03-17 20:52:35 --> Output Class Initialized
INFO - 2025-03-17 20:52:35 --> Security Class Initialized
DEBUG - 2025-03-17 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:52:35 --> Input Class Initialized
INFO - 2025-03-17 20:52:35 --> Language Class Initialized
INFO - 2025-03-17 20:52:35 --> Language Class Initialized
INFO - 2025-03-17 20:52:35 --> Config Class Initialized
INFO - 2025-03-17 20:52:35 --> Loader Class Initialized
INFO - 2025-03-17 20:52:35 --> Helper loaded: url_helper
INFO - 2025-03-17 20:52:35 --> Helper loaded: file_helper
INFO - 2025-03-17 20:52:35 --> Helper loaded: html_helper
INFO - 2025-03-17 20:52:35 --> Helper loaded: form_helper
INFO - 2025-03-17 20:52:35 --> Helper loaded: text_helper
INFO - 2025-03-17 20:52:35 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:52:35 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:52:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:52:35 --> Database Driver Class Initialized
INFO - 2025-03-17 20:52:35 --> Email Class Initialized
INFO - 2025-03-17 20:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:52:35 --> Form Validation Class Initialized
INFO - 2025-03-17 20:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:52:35 --> Pagination Class Initialized
INFO - 2025-03-17 20:52:35 --> Controller Class Initialized
DEBUG - 2025-03-17 20:52:35 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:52:35 --> Model Class Initialized
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:52:35 --> Model Class Initialized
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:52:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:52:35 --> Model Class Initialized
ERROR - 2025-03-17 20:52:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:52:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:52:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:52:35 --> Final output sent to browser
DEBUG - 2025-03-17 20:52:35 --> Total execution time: 0.1527
INFO - 2025-03-17 20:52:36 --> Config Class Initialized
INFO - 2025-03-17 20:52:36 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:52:36 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:52:36 --> Utf8 Class Initialized
INFO - 2025-03-17 20:52:36 --> URI Class Initialized
DEBUG - 2025-03-17 20:52:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:52:36 --> Router Class Initialized
INFO - 2025-03-17 20:52:36 --> Output Class Initialized
INFO - 2025-03-17 20:52:36 --> Security Class Initialized
DEBUG - 2025-03-17 20:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:52:36 --> Input Class Initialized
INFO - 2025-03-17 20:52:36 --> Language Class Initialized
INFO - 2025-03-17 20:52:36 --> Language Class Initialized
INFO - 2025-03-17 20:52:36 --> Config Class Initialized
INFO - 2025-03-17 20:52:36 --> Loader Class Initialized
INFO - 2025-03-17 20:52:36 --> Helper loaded: url_helper
INFO - 2025-03-17 20:52:36 --> Helper loaded: file_helper
INFO - 2025-03-17 20:52:36 --> Helper loaded: html_helper
INFO - 2025-03-17 20:52:36 --> Helper loaded: form_helper
INFO - 2025-03-17 20:52:36 --> Helper loaded: text_helper
INFO - 2025-03-17 20:52:36 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:52:36 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:52:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:52:36 --> Database Driver Class Initialized
INFO - 2025-03-17 20:52:36 --> Email Class Initialized
INFO - 2025-03-17 20:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:52:36 --> Form Validation Class Initialized
INFO - 2025-03-17 20:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:52:36 --> Pagination Class Initialized
INFO - 2025-03-17 20:52:36 --> Controller Class Initialized
DEBUG - 2025-03-17 20:52:36 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:52:36 --> Model Class Initialized
DEBUG - 2025-03-17 20:52:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:52:36 --> Model Class Initialized
ERROR - 2025-03-17 20:52:36 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:52:36 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:52:36 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:52:36 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:52:36 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:52:36 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:52:36 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:52:36 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"275.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:52:36 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"275.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-17 20:52:54 --> Config Class Initialized
INFO - 2025-03-17 20:52:54 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:52:54 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:52:54 --> Utf8 Class Initialized
INFO - 2025-03-17 20:52:54 --> URI Class Initialized
DEBUG - 2025-03-17 20:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:52:54 --> Router Class Initialized
INFO - 2025-03-17 20:52:54 --> Output Class Initialized
INFO - 2025-03-17 20:52:54 --> Security Class Initialized
DEBUG - 2025-03-17 20:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:52:54 --> Input Class Initialized
INFO - 2025-03-17 20:52:54 --> Language Class Initialized
INFO - 2025-03-17 20:52:54 --> Language Class Initialized
INFO - 2025-03-17 20:52:54 --> Config Class Initialized
INFO - 2025-03-17 20:52:54 --> Loader Class Initialized
INFO - 2025-03-17 20:52:54 --> Helper loaded: url_helper
INFO - 2025-03-17 20:52:54 --> Helper loaded: file_helper
INFO - 2025-03-17 20:52:54 --> Helper loaded: html_helper
INFO - 2025-03-17 20:52:54 --> Helper loaded: form_helper
INFO - 2025-03-17 20:52:54 --> Helper loaded: text_helper
INFO - 2025-03-17 20:52:54 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:52:54 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:52:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:52:54 --> Database Driver Class Initialized
INFO - 2025-03-17 20:52:54 --> Email Class Initialized
INFO - 2025-03-17 20:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:52:54 --> Form Validation Class Initialized
INFO - 2025-03-17 20:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:52:54 --> Pagination Class Initialized
INFO - 2025-03-17 20:52:54 --> Controller Class Initialized
DEBUG - 2025-03-17 20:52:54 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:52:55 --> Config Class Initialized
INFO - 2025-03-17 20:52:55 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:52:55 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:52:55 --> Utf8 Class Initialized
INFO - 2025-03-17 20:52:55 --> URI Class Initialized
DEBUG - 2025-03-17 20:52:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:52:55 --> Router Class Initialized
INFO - 2025-03-17 20:52:55 --> Output Class Initialized
INFO - 2025-03-17 20:52:55 --> Security Class Initialized
DEBUG - 2025-03-17 20:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:52:55 --> Input Class Initialized
INFO - 2025-03-17 20:52:55 --> Language Class Initialized
INFO - 2025-03-17 20:52:55 --> Language Class Initialized
INFO - 2025-03-17 20:52:55 --> Config Class Initialized
INFO - 2025-03-17 20:52:55 --> Loader Class Initialized
INFO - 2025-03-17 20:52:55 --> Helper loaded: url_helper
INFO - 2025-03-17 20:52:55 --> Helper loaded: file_helper
INFO - 2025-03-17 20:52:55 --> Helper loaded: html_helper
INFO - 2025-03-17 20:52:55 --> Helper loaded: form_helper
INFO - 2025-03-17 20:52:55 --> Helper loaded: text_helper
INFO - 2025-03-17 20:52:55 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:52:55 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:52:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:52:55 --> Database Driver Class Initialized
INFO - 2025-03-17 20:52:55 --> Email Class Initialized
INFO - 2025-03-17 20:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:52:55 --> Form Validation Class Initialized
INFO - 2025-03-17 20:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:52:55 --> Pagination Class Initialized
INFO - 2025-03-17 20:52:55 --> Controller Class Initialized
DEBUG - 2025-03-17 20:52:55 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:53:07 --> Config Class Initialized
INFO - 2025-03-17 20:53:07 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:53:07 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:53:07 --> Utf8 Class Initialized
INFO - 2025-03-17 20:53:07 --> URI Class Initialized
DEBUG - 2025-03-17 20:53:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:53:07 --> Router Class Initialized
INFO - 2025-03-17 20:53:07 --> Output Class Initialized
INFO - 2025-03-17 20:53:07 --> Security Class Initialized
DEBUG - 2025-03-17 20:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:53:07 --> Input Class Initialized
INFO - 2025-03-17 20:53:07 --> Language Class Initialized
INFO - 2025-03-17 20:53:07 --> Language Class Initialized
INFO - 2025-03-17 20:53:07 --> Config Class Initialized
INFO - 2025-03-17 20:53:07 --> Loader Class Initialized
INFO - 2025-03-17 20:53:07 --> Helper loaded: url_helper
INFO - 2025-03-17 20:53:07 --> Helper loaded: file_helper
INFO - 2025-03-17 20:53:07 --> Helper loaded: html_helper
INFO - 2025-03-17 20:53:07 --> Helper loaded: form_helper
INFO - 2025-03-17 20:53:07 --> Helper loaded: text_helper
INFO - 2025-03-17 20:53:07 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:53:07 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:53:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:53:07 --> Database Driver Class Initialized
INFO - 2025-03-17 20:53:07 --> Email Class Initialized
INFO - 2025-03-17 20:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:53:07 --> Form Validation Class Initialized
INFO - 2025-03-17 20:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:53:07 --> Pagination Class Initialized
INFO - 2025-03-17 20:53:07 --> Controller Class Initialized
DEBUG - 2025-03-17 20:53:07 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:53:24 --> Config Class Initialized
INFO - 2025-03-17 20:53:24 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:53:24 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:53:24 --> Utf8 Class Initialized
INFO - 2025-03-17 20:53:24 --> URI Class Initialized
DEBUG - 2025-03-17 20:53:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:53:24 --> Router Class Initialized
INFO - 2025-03-17 20:53:24 --> Output Class Initialized
INFO - 2025-03-17 20:53:24 --> Security Class Initialized
DEBUG - 2025-03-17 20:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:53:24 --> Input Class Initialized
INFO - 2025-03-17 20:53:24 --> Language Class Initialized
INFO - 2025-03-17 20:53:24 --> Language Class Initialized
INFO - 2025-03-17 20:53:24 --> Config Class Initialized
INFO - 2025-03-17 20:53:24 --> Loader Class Initialized
INFO - 2025-03-17 20:53:24 --> Helper loaded: url_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: file_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: html_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: form_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: text_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:53:24 --> Database Driver Class Initialized
INFO - 2025-03-17 20:53:24 --> Email Class Initialized
INFO - 2025-03-17 20:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:53:24 --> Form Validation Class Initialized
INFO - 2025-03-17 20:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:53:24 --> Pagination Class Initialized
INFO - 2025-03-17 20:53:24 --> Controller Class Initialized
DEBUG - 2025-03-17 20:53:24 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:53:24 --> Config Class Initialized
INFO - 2025-03-17 20:53:24 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:53:24 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:53:24 --> Utf8 Class Initialized
INFO - 2025-03-17 20:53:24 --> URI Class Initialized
DEBUG - 2025-03-17 20:53:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:53:24 --> Router Class Initialized
INFO - 2025-03-17 20:53:24 --> Output Class Initialized
INFO - 2025-03-17 20:53:24 --> Security Class Initialized
DEBUG - 2025-03-17 20:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:53:24 --> Input Class Initialized
INFO - 2025-03-17 20:53:24 --> Language Class Initialized
INFO - 2025-03-17 20:53:24 --> Language Class Initialized
INFO - 2025-03-17 20:53:24 --> Config Class Initialized
INFO - 2025-03-17 20:53:24 --> Loader Class Initialized
INFO - 2025-03-17 20:53:24 --> Helper loaded: url_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: file_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: html_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: form_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: text_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:53:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:53:24 --> Database Driver Class Initialized
INFO - 2025-03-17 20:53:24 --> Email Class Initialized
INFO - 2025-03-17 20:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:53:24 --> Form Validation Class Initialized
INFO - 2025-03-17 20:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:53:24 --> Pagination Class Initialized
INFO - 2025-03-17 20:53:24 --> Controller Class Initialized
DEBUG - 2025-03-17 20:53:24 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:03 --> Config Class Initialized
INFO - 2025-03-17 20:54:03 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:03 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:03 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:03 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:54:03 --> Router Class Initialized
INFO - 2025-03-17 20:54:03 --> Output Class Initialized
INFO - 2025-03-17 20:54:03 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:03 --> Input Class Initialized
INFO - 2025-03-17 20:54:03 --> Language Class Initialized
INFO - 2025-03-17 20:54:03 --> Language Class Initialized
INFO - 2025-03-17 20:54:03 --> Config Class Initialized
INFO - 2025-03-17 20:54:03 --> Loader Class Initialized
INFO - 2025-03-17 20:54:03 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:03 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:03 --> Email Class Initialized
INFO - 2025-03-17 20:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:03 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:03 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:03 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:03 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:54:03 --> Model Class Initialized
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:54:03 --> Model Class Initialized
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:54:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:54:03 --> Model Class Initialized
ERROR - 2025-03-17 20:54:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:54:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:54:03 --> Final output sent to browser
DEBUG - 2025-03-17 20:54:03 --> Total execution time: 0.1750
INFO - 2025-03-17 20:54:03 --> Config Class Initialized
INFO - 2025-03-17 20:54:03 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:03 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:03 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:03 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:54:03 --> Router Class Initialized
INFO - 2025-03-17 20:54:03 --> Output Class Initialized
INFO - 2025-03-17 20:54:03 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:03 --> Input Class Initialized
INFO - 2025-03-17 20:54:03 --> Language Class Initialized
INFO - 2025-03-17 20:54:03 --> Language Class Initialized
INFO - 2025-03-17 20:54:03 --> Config Class Initialized
INFO - 2025-03-17 20:54:03 --> Loader Class Initialized
INFO - 2025-03-17 20:54:03 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:03 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:03 --> Email Class Initialized
INFO - 2025-03-17 20:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:03 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:03 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:03 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:03 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:54:03 --> Model Class Initialized
DEBUG - 2025-03-17 20:54:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:54:03 --> Model Class Initialized
ERROR - 2025-03-17 20:54:03 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:54:03 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:54:03 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:54:03 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:54:03 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:54:03 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:54:03 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:54:03 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"275.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:54:03 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"275.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-17 20:54:13 --> Config Class Initialized
INFO - 2025-03-17 20:54:13 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:13 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:13 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:13 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:13 --> Router Class Initialized
INFO - 2025-03-17 20:54:13 --> Output Class Initialized
INFO - 2025-03-17 20:54:13 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:13 --> Input Class Initialized
INFO - 2025-03-17 20:54:13 --> Language Class Initialized
INFO - 2025-03-17 20:54:13 --> Language Class Initialized
INFO - 2025-03-17 20:54:13 --> Config Class Initialized
INFO - 2025-03-17 20:54:13 --> Loader Class Initialized
INFO - 2025-03-17 20:54:13 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:13 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:13 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:13 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:13 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:13 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:13 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:13 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:13 --> Email Class Initialized
INFO - 2025-03-17 20:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:13 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:13 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:13 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:13 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:21 --> Config Class Initialized
INFO - 2025-03-17 20:54:21 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:21 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:21 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:21 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:21 --> Router Class Initialized
INFO - 2025-03-17 20:54:21 --> Output Class Initialized
INFO - 2025-03-17 20:54:21 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:21 --> Input Class Initialized
INFO - 2025-03-17 20:54:21 --> Language Class Initialized
INFO - 2025-03-17 20:54:21 --> Language Class Initialized
INFO - 2025-03-17 20:54:21 --> Config Class Initialized
INFO - 2025-03-17 20:54:21 --> Loader Class Initialized
INFO - 2025-03-17 20:54:21 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:21 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:21 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:21 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:21 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:21 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:21 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:21 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:21 --> Email Class Initialized
INFO - 2025-03-17 20:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:21 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:21 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:21 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:21 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:23 --> Config Class Initialized
INFO - 2025-03-17 20:54:23 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:23 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:23 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:23 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:23 --> Router Class Initialized
INFO - 2025-03-17 20:54:23 --> Output Class Initialized
INFO - 2025-03-17 20:54:23 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:23 --> Input Class Initialized
INFO - 2025-03-17 20:54:23 --> Language Class Initialized
INFO - 2025-03-17 20:54:23 --> Language Class Initialized
INFO - 2025-03-17 20:54:23 --> Config Class Initialized
INFO - 2025-03-17 20:54:23 --> Loader Class Initialized
INFO - 2025-03-17 20:54:23 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:23 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:23 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:23 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:23 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:23 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:23 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:23 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:23 --> Email Class Initialized
INFO - 2025-03-17 20:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:23 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:23 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:23 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:23 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:26 --> Config Class Initialized
INFO - 2025-03-17 20:54:26 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:26 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:26 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:26 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:26 --> Router Class Initialized
INFO - 2025-03-17 20:54:26 --> Output Class Initialized
INFO - 2025-03-17 20:54:26 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:26 --> Input Class Initialized
INFO - 2025-03-17 20:54:26 --> Language Class Initialized
INFO - 2025-03-17 20:54:26 --> Language Class Initialized
INFO - 2025-03-17 20:54:26 --> Config Class Initialized
INFO - 2025-03-17 20:54:26 --> Loader Class Initialized
INFO - 2025-03-17 20:54:26 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:26 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:26 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:26 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:26 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:26 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:26 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:26 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:26 --> Email Class Initialized
INFO - 2025-03-17 20:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:26 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:26 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:26 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:26 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:28 --> Config Class Initialized
INFO - 2025-03-17 20:54:28 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:28 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:28 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:28 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:28 --> Router Class Initialized
INFO - 2025-03-17 20:54:28 --> Output Class Initialized
INFO - 2025-03-17 20:54:28 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:28 --> Input Class Initialized
INFO - 2025-03-17 20:54:28 --> Language Class Initialized
INFO - 2025-03-17 20:54:28 --> Language Class Initialized
INFO - 2025-03-17 20:54:28 --> Config Class Initialized
INFO - 2025-03-17 20:54:28 --> Loader Class Initialized
INFO - 2025-03-17 20:54:28 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:28 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:28 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:28 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:28 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:28 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:28 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:28 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:28 --> Email Class Initialized
INFO - 2025-03-17 20:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:28 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:28 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:28 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:28 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:30 --> Config Class Initialized
INFO - 2025-03-17 20:54:30 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:30 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:30 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:30 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:30 --> Router Class Initialized
INFO - 2025-03-17 20:54:30 --> Output Class Initialized
INFO - 2025-03-17 20:54:30 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:30 --> Input Class Initialized
INFO - 2025-03-17 20:54:30 --> Language Class Initialized
INFO - 2025-03-17 20:54:30 --> Language Class Initialized
INFO - 2025-03-17 20:54:30 --> Config Class Initialized
INFO - 2025-03-17 20:54:30 --> Loader Class Initialized
INFO - 2025-03-17 20:54:30 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:30 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:30 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:30 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:30 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:30 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:30 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:30 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:30 --> Email Class Initialized
INFO - 2025-03-17 20:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:30 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:30 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:30 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:30 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:43 --> Config Class Initialized
INFO - 2025-03-17 20:54:43 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:43 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:43 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:43 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:43 --> Router Class Initialized
INFO - 2025-03-17 20:54:43 --> Output Class Initialized
INFO - 2025-03-17 20:54:43 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:43 --> Input Class Initialized
INFO - 2025-03-17 20:54:43 --> Language Class Initialized
INFO - 2025-03-17 20:54:43 --> Language Class Initialized
INFO - 2025-03-17 20:54:43 --> Config Class Initialized
INFO - 2025-03-17 20:54:43 --> Loader Class Initialized
INFO - 2025-03-17 20:54:43 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:43 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:43 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:43 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:43 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:43 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:43 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:43 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:43 --> Email Class Initialized
INFO - 2025-03-17 20:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:43 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:43 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:43 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:43 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:45 --> Config Class Initialized
INFO - 2025-03-17 20:54:45 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:45 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:45 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:45 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-17 20:54:45 --> Router Class Initialized
INFO - 2025-03-17 20:54:45 --> Output Class Initialized
INFO - 2025-03-17 20:54:45 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:45 --> Input Class Initialized
INFO - 2025-03-17 20:54:45 --> Language Class Initialized
INFO - 2025-03-17 20:54:45 --> Language Class Initialized
INFO - 2025-03-17 20:54:45 --> Config Class Initialized
INFO - 2025-03-17 20:54:45 --> Loader Class Initialized
INFO - 2025-03-17 20:54:45 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:45 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:45 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:45 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:45 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:45 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:45 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:45 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:45 --> Email Class Initialized
INFO - 2025-03-17 20:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:45 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:45 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:45 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:45 --> Invoice MX_Controller Initialized
INFO - 2025-03-17 20:54:52 --> Config Class Initialized
INFO - 2025-03-17 20:54:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:54:52 --> Router Class Initialized
INFO - 2025-03-17 20:54:52 --> Output Class Initialized
INFO - 2025-03-17 20:54:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:52 --> Input Class Initialized
INFO - 2025-03-17 20:54:52 --> Language Class Initialized
INFO - 2025-03-17 20:54:52 --> Language Class Initialized
INFO - 2025-03-17 20:54:52 --> Config Class Initialized
INFO - 2025-03-17 20:54:52 --> Loader Class Initialized
INFO - 2025-03-17 20:54:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:52 --> Email Class Initialized
INFO - 2025-03-17 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:52 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:54:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:54:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 20:54:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 20:54:52 --> Model Class Initialized
ERROR - 2025-03-17 20:54:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 20:54:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 20:54:52 --> Final output sent to browser
DEBUG - 2025-03-17 20:54:52 --> Total execution time: 0.1077
INFO - 2025-03-17 20:54:52 --> Config Class Initialized
INFO - 2025-03-17 20:54:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 20:54:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 20:54:52 --> Utf8 Class Initialized
INFO - 2025-03-17 20:54:52 --> URI Class Initialized
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-17 20:54:52 --> Router Class Initialized
INFO - 2025-03-17 20:54:52 --> Output Class Initialized
INFO - 2025-03-17 20:54:52 --> Security Class Initialized
DEBUG - 2025-03-17 20:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 20:54:52 --> Input Class Initialized
INFO - 2025-03-17 20:54:52 --> Language Class Initialized
INFO - 2025-03-17 20:54:52 --> Language Class Initialized
INFO - 2025-03-17 20:54:52 --> Config Class Initialized
INFO - 2025-03-17 20:54:52 --> Loader Class Initialized
INFO - 2025-03-17 20:54:52 --> Helper loaded: url_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: file_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: html_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: form_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: text_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 20:54:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 20:54:52 --> Database Driver Class Initialized
INFO - 2025-03-17 20:54:52 --> Email Class Initialized
INFO - 2025-03-17 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 20:54:52 --> Form Validation Class Initialized
INFO - 2025-03-17 20:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 20:54:52 --> Pagination Class Initialized
INFO - 2025-03-17 20:54:52 --> Controller Class Initialized
DEBUG - 2025-03-17 20:54:52 --> Customer MX_Controller Initialized
INFO - 2025-03-17 20:54:52 --> Model Class Initialized
DEBUG - 2025-03-17 20:54:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-17 20:54:52 --> Model Class Initialized
ERROR - 2025-03-17 20:54:52 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-17 20:54:52 --> DEBUG: Received customer_id = null
ERROR - 2025-03-17 20:54:52 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 20:54:52 --> DEBUG: Search Value = 
ERROR - 2025-03-17 20:54:52 --> DEBUG: Counting total records...
ERROR - 2025-03-17 20:54:52 --> DEBUG: Total Records = 9
ERROR - 2025-03-17 20:54:52 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-17 20:54:52 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"275.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"125.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-17 20:54:52 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"275.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"125.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n                class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n                <i class=\"pe-7s-note\"><\/i>\r\n            <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n                class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n                <i class=\"pe-7s-trash\"><\/i>\r\n            <\/a>"}]
INFO - 2025-03-17 22:32:19 --> Config Class Initialized
INFO - 2025-03-17 22:32:19 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:32:19 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:32:19 --> Utf8 Class Initialized
INFO - 2025-03-17 22:32:19 --> URI Class Initialized
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 22:32:19 --> Router Class Initialized
INFO - 2025-03-17 22:32:19 --> Output Class Initialized
INFO - 2025-03-17 22:32:19 --> Security Class Initialized
DEBUG - 2025-03-17 22:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:32:19 --> Input Class Initialized
INFO - 2025-03-17 22:32:19 --> Language Class Initialized
INFO - 2025-03-17 22:32:19 --> Language Class Initialized
INFO - 2025-03-17 22:32:19 --> Config Class Initialized
INFO - 2025-03-17 22:32:19 --> Loader Class Initialized
INFO - 2025-03-17 22:32:19 --> Helper loaded: url_helper
INFO - 2025-03-17 22:32:19 --> Helper loaded: file_helper
INFO - 2025-03-17 22:32:19 --> Helper loaded: html_helper
INFO - 2025-03-17 22:32:19 --> Helper loaded: form_helper
INFO - 2025-03-17 22:32:19 --> Helper loaded: text_helper
INFO - 2025-03-17 22:32:19 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:32:19 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:32:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:32:19 --> Database Driver Class Initialized
INFO - 2025-03-17 22:32:19 --> Email Class Initialized
INFO - 2025-03-17 22:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:32:19 --> Form Validation Class Initialized
INFO - 2025-03-17 22:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:32:19 --> Pagination Class Initialized
INFO - 2025-03-17 22:32:19 --> Controller Class Initialized
DEBUG - 2025-03-17 22:32:19 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 22:32:19 --> Model Class Initialized
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 22:32:19 --> Model Class Initialized
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 22:32:19 --> Model Class Initialized
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 22:32:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 22:32:19 --> Model Class Initialized
ERROR - 2025-03-17 22:32:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 22:32:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 22:32:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 22:32:19 --> Final output sent to browser
DEBUG - 2025-03-17 22:32:19 --> Total execution time: 0.5720
INFO - 2025-03-17 22:32:41 --> Config Class Initialized
INFO - 2025-03-17 22:32:41 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:32:41 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:32:41 --> Utf8 Class Initialized
INFO - 2025-03-17 22:32:41 --> URI Class Initialized
DEBUG - 2025-03-17 22:32:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 22:32:41 --> Router Class Initialized
INFO - 2025-03-17 22:32:41 --> Output Class Initialized
INFO - 2025-03-17 22:32:41 --> Security Class Initialized
DEBUG - 2025-03-17 22:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:32:41 --> Input Class Initialized
INFO - 2025-03-17 22:32:41 --> Language Class Initialized
INFO - 2025-03-17 22:32:41 --> Language Class Initialized
INFO - 2025-03-17 22:32:41 --> Config Class Initialized
INFO - 2025-03-17 22:32:41 --> Loader Class Initialized
INFO - 2025-03-17 22:32:41 --> Helper loaded: url_helper
INFO - 2025-03-17 22:32:41 --> Helper loaded: file_helper
INFO - 2025-03-17 22:32:41 --> Helper loaded: html_helper
INFO - 2025-03-17 22:32:41 --> Helper loaded: form_helper
INFO - 2025-03-17 22:32:41 --> Helper loaded: text_helper
INFO - 2025-03-17 22:32:41 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:32:41 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:32:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:32:41 --> Database Driver Class Initialized
INFO - 2025-03-17 22:32:41 --> Email Class Initialized
INFO - 2025-03-17 22:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:32:41 --> Form Validation Class Initialized
INFO - 2025-03-17 22:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:32:41 --> Pagination Class Initialized
INFO - 2025-03-17 22:32:41 --> Controller Class Initialized
DEBUG - 2025-03-17 22:32:41 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 22:32:41 --> Model Class Initialized
DEBUG - 2025-03-17 22:32:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 22:32:41 --> Model Class Initialized
DEBUG - 2025-03-17 22:32:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 22:32:41 --> Model Class Initialized
INFO - 2025-03-17 22:32:41 --> Final output sent to browser
DEBUG - 2025-03-17 22:32:41 --> Total execution time: 0.0080
INFO - 2025-03-17 22:32:42 --> Config Class Initialized
INFO - 2025-03-17 22:32:42 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:32:42 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:32:42 --> Utf8 Class Initialized
INFO - 2025-03-17 22:32:42 --> URI Class Initialized
DEBUG - 2025-03-17 22:32:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 22:32:42 --> Router Class Initialized
INFO - 2025-03-17 22:32:42 --> Output Class Initialized
INFO - 2025-03-17 22:32:42 --> Security Class Initialized
DEBUG - 2025-03-17 22:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:32:42 --> Input Class Initialized
INFO - 2025-03-17 22:32:42 --> Language Class Initialized
INFO - 2025-03-17 22:32:42 --> Language Class Initialized
INFO - 2025-03-17 22:32:42 --> Config Class Initialized
INFO - 2025-03-17 22:32:42 --> Loader Class Initialized
INFO - 2025-03-17 22:32:42 --> Helper loaded: url_helper
INFO - 2025-03-17 22:32:42 --> Helper loaded: file_helper
INFO - 2025-03-17 22:32:42 --> Helper loaded: html_helper
INFO - 2025-03-17 22:32:42 --> Helper loaded: form_helper
INFO - 2025-03-17 22:32:42 --> Helper loaded: text_helper
INFO - 2025-03-17 22:32:42 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:32:42 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:32:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:32:42 --> Database Driver Class Initialized
INFO - 2025-03-17 22:32:42 --> Email Class Initialized
INFO - 2025-03-17 22:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:32:42 --> Form Validation Class Initialized
INFO - 2025-03-17 22:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:32:42 --> Pagination Class Initialized
INFO - 2025-03-17 22:32:42 --> Controller Class Initialized
DEBUG - 2025-03-17 22:32:42 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 22:32:42 --> Model Class Initialized
DEBUG - 2025-03-17 22:32:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 22:32:42 --> Model Class Initialized
DEBUG - 2025-03-17 22:32:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 22:32:42 --> Model Class Initialized
INFO - 2025-03-17 22:32:42 --> Final output sent to browser
DEBUG - 2025-03-17 22:32:42 --> Total execution time: 0.0072
INFO - 2025-03-17 22:33:16 --> Config Class Initialized
INFO - 2025-03-17 22:33:16 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:33:16 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:33:16 --> Utf8 Class Initialized
INFO - 2025-03-17 22:33:16 --> URI Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 22:33:16 --> Router Class Initialized
INFO - 2025-03-17 22:33:16 --> Output Class Initialized
INFO - 2025-03-17 22:33:16 --> Security Class Initialized
DEBUG - 2025-03-17 22:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:33:16 --> Input Class Initialized
INFO - 2025-03-17 22:33:16 --> Language Class Initialized
INFO - 2025-03-17 22:33:16 --> Language Class Initialized
INFO - 2025-03-17 22:33:16 --> Config Class Initialized
INFO - 2025-03-17 22:33:16 --> Loader Class Initialized
INFO - 2025-03-17 22:33:16 --> Helper loaded: url_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: file_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: html_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: form_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: text_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:33:16 --> Database Driver Class Initialized
INFO - 2025-03-17 22:33:16 --> Email Class Initialized
INFO - 2025-03-17 22:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:33:16 --> Form Validation Class Initialized
INFO - 2025-03-17 22:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:33:16 --> Pagination Class Initialized
INFO - 2025-03-17 22:33:16 --> Controller Class Initialized
DEBUG - 2025-03-17 22:33:16 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
INFO - 2025-03-17 22:33:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-17 22:33:16 --> Config Class Initialized
INFO - 2025-03-17 22:33:16 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:33:16 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:33:16 --> Utf8 Class Initialized
INFO - 2025-03-17 22:33:16 --> URI Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 22:33:16 --> Router Class Initialized
INFO - 2025-03-17 22:33:16 --> Output Class Initialized
INFO - 2025-03-17 22:33:16 --> Security Class Initialized
DEBUG - 2025-03-17 22:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:33:16 --> Input Class Initialized
INFO - 2025-03-17 22:33:16 --> Language Class Initialized
INFO - 2025-03-17 22:33:16 --> Language Class Initialized
INFO - 2025-03-17 22:33:16 --> Config Class Initialized
INFO - 2025-03-17 22:33:16 --> Loader Class Initialized
INFO - 2025-03-17 22:33:16 --> Helper loaded: url_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: file_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: html_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: form_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: text_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:33:16 --> Database Driver Class Initialized
INFO - 2025-03-17 22:33:16 --> Email Class Initialized
INFO - 2025-03-17 22:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:33:16 --> Form Validation Class Initialized
INFO - 2025-03-17 22:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:33:16 --> Pagination Class Initialized
INFO - 2025-03-17 22:33:16 --> Controller Class Initialized
DEBUG - 2025-03-17 22:33:16 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 22:33:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
ERROR - 2025-03-17 22:33:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 22:33:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 22:33:16 --> Final output sent to browser
DEBUG - 2025-03-17 22:33:16 --> Total execution time: 0.1012
INFO - 2025-03-17 22:33:16 --> Config Class Initialized
INFO - 2025-03-17 22:33:16 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:33:16 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:33:16 --> Utf8 Class Initialized
INFO - 2025-03-17 22:33:16 --> URI Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 22:33:16 --> Router Class Initialized
INFO - 2025-03-17 22:33:16 --> Output Class Initialized
INFO - 2025-03-17 22:33:16 --> Security Class Initialized
DEBUG - 2025-03-17 22:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:33:16 --> Input Class Initialized
INFO - 2025-03-17 22:33:16 --> Language Class Initialized
INFO - 2025-03-17 22:33:16 --> Language Class Initialized
INFO - 2025-03-17 22:33:16 --> Config Class Initialized
INFO - 2025-03-17 22:33:16 --> Loader Class Initialized
INFO - 2025-03-17 22:33:16 --> Helper loaded: url_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: file_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: html_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: form_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: text_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:33:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:33:16 --> Database Driver Class Initialized
INFO - 2025-03-17 22:33:16 --> Email Class Initialized
INFO - 2025-03-17 22:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:33:16 --> Form Validation Class Initialized
INFO - 2025-03-17 22:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:33:16 --> Pagination Class Initialized
INFO - 2025-03-17 22:33:16 --> Controller Class Initialized
DEBUG - 2025-03-17 22:33:16 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 22:33:16 --> Model Class Initialized
INFO - 2025-03-17 22:33:16 --> Final output sent to browser
DEBUG - 2025-03-17 22:33:16 --> Total execution time: 0.0377
INFO - 2025-03-17 22:33:30 --> Config Class Initialized
INFO - 2025-03-17 22:33:30 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:33:30 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:33:30 --> Utf8 Class Initialized
INFO - 2025-03-17 22:33:30 --> URI Class Initialized
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:33:30 --> Router Class Initialized
INFO - 2025-03-17 22:33:30 --> Output Class Initialized
INFO - 2025-03-17 22:33:30 --> Security Class Initialized
DEBUG - 2025-03-17 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:33:30 --> Input Class Initialized
INFO - 2025-03-17 22:33:30 --> Language Class Initialized
INFO - 2025-03-17 22:33:30 --> Language Class Initialized
INFO - 2025-03-17 22:33:30 --> Config Class Initialized
INFO - 2025-03-17 22:33:30 --> Loader Class Initialized
INFO - 2025-03-17 22:33:30 --> Helper loaded: url_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: file_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: html_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: form_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: text_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:33:30 --> Database Driver Class Initialized
INFO - 2025-03-17 22:33:30 --> Email Class Initialized
INFO - 2025-03-17 22:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:33:30 --> Form Validation Class Initialized
INFO - 2025-03-17 22:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:33:30 --> Pagination Class Initialized
INFO - 2025-03-17 22:33:30 --> Controller Class Initialized
DEBUG - 2025-03-17 22:33:30 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:33:30 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:33:30 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 22:33:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 22:33:30 --> Model Class Initialized
ERROR - 2025-03-17 22:33:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 22:33:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 22:33:30 --> Final output sent to browser
DEBUG - 2025-03-17 22:33:30 --> Total execution time: 0.1874
INFO - 2025-03-17 22:33:30 --> Config Class Initialized
INFO - 2025-03-17 22:33:30 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:33:30 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:33:30 --> Utf8 Class Initialized
INFO - 2025-03-17 22:33:30 --> URI Class Initialized
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:33:30 --> Router Class Initialized
INFO - 2025-03-17 22:33:30 --> Output Class Initialized
INFO - 2025-03-17 22:33:30 --> Security Class Initialized
DEBUG - 2025-03-17 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:33:30 --> Input Class Initialized
INFO - 2025-03-17 22:33:30 --> Language Class Initialized
INFO - 2025-03-17 22:33:30 --> Language Class Initialized
INFO - 2025-03-17 22:33:30 --> Config Class Initialized
INFO - 2025-03-17 22:33:30 --> Loader Class Initialized
INFO - 2025-03-17 22:33:30 --> Helper loaded: url_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: file_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: html_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: form_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: text_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:33:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:33:30 --> Database Driver Class Initialized
INFO - 2025-03-17 22:33:30 --> Email Class Initialized
INFO - 2025-03-17 22:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:33:30 --> Form Validation Class Initialized
INFO - 2025-03-17 22:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:33:30 --> Pagination Class Initialized
INFO - 2025-03-17 22:33:30 --> Controller Class Initialized
DEBUG - 2025-03-17 22:33:30 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:33:30 --> Model Class Initialized
DEBUG - 2025-03-17 22:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:33:30 --> Model Class Initialized
INFO - 2025-03-17 22:33:30 --> Final output sent to browser
DEBUG - 2025-03-17 22:33:30 --> Total execution time: 0.0096
INFO - 2025-03-17 22:43:29 --> Config Class Initialized
INFO - 2025-03-17 22:43:29 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:43:29 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:43:29 --> Utf8 Class Initialized
INFO - 2025-03-17 22:43:29 --> URI Class Initialized
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:43:29 --> Router Class Initialized
INFO - 2025-03-17 22:43:29 --> Output Class Initialized
INFO - 2025-03-17 22:43:29 --> Security Class Initialized
DEBUG - 2025-03-17 22:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:43:29 --> Input Class Initialized
INFO - 2025-03-17 22:43:29 --> Language Class Initialized
INFO - 2025-03-17 22:43:29 --> Language Class Initialized
INFO - 2025-03-17 22:43:29 --> Config Class Initialized
INFO - 2025-03-17 22:43:29 --> Loader Class Initialized
INFO - 2025-03-17 22:43:29 --> Helper loaded: url_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: file_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: html_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: form_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: text_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:43:29 --> Database Driver Class Initialized
INFO - 2025-03-17 22:43:29 --> Email Class Initialized
INFO - 2025-03-17 22:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:43:29 --> Form Validation Class Initialized
INFO - 2025-03-17 22:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:43:29 --> Pagination Class Initialized
INFO - 2025-03-17 22:43:29 --> Controller Class Initialized
DEBUG - 2025-03-17 22:43:29 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:43:29 --> Model Class Initialized
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:43:29 --> Model Class Initialized
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 22:43:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 22:43:29 --> Model Class Initialized
ERROR - 2025-03-17 22:43:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 22:43:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 22:43:29 --> Final output sent to browser
DEBUG - 2025-03-17 22:43:29 --> Total execution time: 0.1786
INFO - 2025-03-17 22:43:29 --> Config Class Initialized
INFO - 2025-03-17 22:43:29 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:43:29 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:43:29 --> Utf8 Class Initialized
INFO - 2025-03-17 22:43:29 --> URI Class Initialized
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:43:29 --> Router Class Initialized
INFO - 2025-03-17 22:43:29 --> Output Class Initialized
INFO - 2025-03-17 22:43:29 --> Security Class Initialized
DEBUG - 2025-03-17 22:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:43:29 --> Input Class Initialized
INFO - 2025-03-17 22:43:29 --> Language Class Initialized
INFO - 2025-03-17 22:43:29 --> Language Class Initialized
INFO - 2025-03-17 22:43:29 --> Config Class Initialized
INFO - 2025-03-17 22:43:29 --> Loader Class Initialized
INFO - 2025-03-17 22:43:29 --> Helper loaded: url_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: file_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: html_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: form_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: text_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:43:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:43:29 --> Database Driver Class Initialized
INFO - 2025-03-17 22:43:29 --> Email Class Initialized
INFO - 2025-03-17 22:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:43:29 --> Form Validation Class Initialized
INFO - 2025-03-17 22:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:43:29 --> Pagination Class Initialized
INFO - 2025-03-17 22:43:29 --> Controller Class Initialized
DEBUG - 2025-03-17 22:43:29 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:43:29 --> Model Class Initialized
DEBUG - 2025-03-17 22:43:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:43:29 --> Model Class Initialized
ERROR - 2025-03-17 22:43:29 --> DEBUG: getSupplierList() called.
ERROR - 2025-03-17 22:43:29 --> DEBUG: Received supplier_id = null
ERROR - 2025-03-17 22:43:29 --> DEBUG: Received customfiled = null
ERROR - 2025-03-17 22:43:29 --> DEBUG: Search Value = 
ERROR - 2025-03-17 22:43:29 --> DEBUG: Counting total supplier records...
ERROR - 2025-03-17 22:43:29 --> DEBUG: Total Supplier Records = 3
ERROR - 2025-03-17 22:43:29 --> DEBUG: Fetching filtered supplier records...
ERROR - 2025-03-17 22:43:29 --> Severity: error --> Exception: Unknown column 's.supplier_address' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-17 22:46:36 --> Config Class Initialized
INFO - 2025-03-17 22:46:36 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:46:36 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:46:36 --> Utf8 Class Initialized
INFO - 2025-03-17 22:46:36 --> URI Class Initialized
DEBUG - 2025-03-17 22:46:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:46:36 --> Router Class Initialized
INFO - 2025-03-17 22:46:36 --> Output Class Initialized
INFO - 2025-03-17 22:46:36 --> Security Class Initialized
DEBUG - 2025-03-17 22:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:46:36 --> Input Class Initialized
INFO - 2025-03-17 22:46:36 --> Language Class Initialized
INFO - 2025-03-17 22:46:36 --> Language Class Initialized
INFO - 2025-03-17 22:46:36 --> Config Class Initialized
INFO - 2025-03-17 22:46:36 --> Loader Class Initialized
INFO - 2025-03-17 22:46:36 --> Helper loaded: url_helper
INFO - 2025-03-17 22:46:36 --> Helper loaded: file_helper
INFO - 2025-03-17 22:46:36 --> Helper loaded: html_helper
INFO - 2025-03-17 22:46:36 --> Helper loaded: form_helper
INFO - 2025-03-17 22:46:36 --> Helper loaded: text_helper
INFO - 2025-03-17 22:46:36 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:46:36 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:46:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:46:36 --> Database Driver Class Initialized
INFO - 2025-03-17 22:46:36 --> Email Class Initialized
INFO - 2025-03-17 22:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:46:36 --> Form Validation Class Initialized
INFO - 2025-03-17 22:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:46:36 --> Pagination Class Initialized
INFO - 2025-03-17 22:46:36 --> Controller Class Initialized
DEBUG - 2025-03-17 22:46:36 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:46:36 --> Model Class Initialized
DEBUG - 2025-03-17 22:46:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:46:36 --> Model Class Initialized
DEBUG - 2025-03-17 22:46:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 22:46:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 22:46:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 22:46:36 --> Model Class Initialized
ERROR - 2025-03-17 22:46:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 22:46:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 22:46:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 22:46:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 22:46:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 22:46:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 22:46:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-17 22:46:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 22:46:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 22:46:37 --> Final output sent to browser
DEBUG - 2025-03-17 22:46:37 --> Total execution time: 0.1618
INFO - 2025-03-17 22:46:37 --> Config Class Initialized
INFO - 2025-03-17 22:46:37 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:46:37 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:46:37 --> Utf8 Class Initialized
INFO - 2025-03-17 22:46:37 --> URI Class Initialized
DEBUG - 2025-03-17 22:46:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:46:37 --> Router Class Initialized
INFO - 2025-03-17 22:46:37 --> Output Class Initialized
INFO - 2025-03-17 22:46:37 --> Security Class Initialized
DEBUG - 2025-03-17 22:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:46:37 --> Input Class Initialized
INFO - 2025-03-17 22:46:37 --> Language Class Initialized
INFO - 2025-03-17 22:46:37 --> Language Class Initialized
INFO - 2025-03-17 22:46:37 --> Config Class Initialized
INFO - 2025-03-17 22:46:37 --> Loader Class Initialized
INFO - 2025-03-17 22:46:37 --> Helper loaded: url_helper
INFO - 2025-03-17 22:46:37 --> Helper loaded: file_helper
INFO - 2025-03-17 22:46:37 --> Helper loaded: html_helper
INFO - 2025-03-17 22:46:37 --> Helper loaded: form_helper
INFO - 2025-03-17 22:46:37 --> Helper loaded: text_helper
INFO - 2025-03-17 22:46:37 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:46:37 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:46:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:46:37 --> Database Driver Class Initialized
INFO - 2025-03-17 22:46:37 --> Email Class Initialized
INFO - 2025-03-17 22:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:46:37 --> Form Validation Class Initialized
INFO - 2025-03-17 22:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:46:37 --> Pagination Class Initialized
INFO - 2025-03-17 22:46:37 --> Controller Class Initialized
DEBUG - 2025-03-17 22:46:37 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:46:37 --> Model Class Initialized
DEBUG - 2025-03-17 22:46:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:46:37 --> Model Class Initialized
INFO - 2025-03-17 22:46:37 --> Final output sent to browser
DEBUG - 2025-03-17 22:46:37 --> Total execution time: 0.0173
INFO - 2025-03-17 22:46:39 --> Config Class Initialized
INFO - 2025-03-17 22:46:39 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:46:39 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:46:39 --> Utf8 Class Initialized
INFO - 2025-03-17 22:46:39 --> URI Class Initialized
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:46:39 --> Router Class Initialized
INFO - 2025-03-17 22:46:39 --> Output Class Initialized
INFO - 2025-03-17 22:46:39 --> Security Class Initialized
DEBUG - 2025-03-17 22:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:46:39 --> Input Class Initialized
INFO - 2025-03-17 22:46:39 --> Language Class Initialized
INFO - 2025-03-17 22:46:39 --> Language Class Initialized
INFO - 2025-03-17 22:46:39 --> Config Class Initialized
INFO - 2025-03-17 22:46:39 --> Loader Class Initialized
INFO - 2025-03-17 22:46:39 --> Helper loaded: url_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: file_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: html_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: form_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: text_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:46:39 --> Database Driver Class Initialized
INFO - 2025-03-17 22:46:39 --> Email Class Initialized
INFO - 2025-03-17 22:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:46:39 --> Form Validation Class Initialized
INFO - 2025-03-17 22:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:46:39 --> Pagination Class Initialized
INFO - 2025-03-17 22:46:39 --> Controller Class Initialized
DEBUG - 2025-03-17 22:46:39 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:46:39 --> Model Class Initialized
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:46:39 --> Model Class Initialized
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 22:46:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 22:46:39 --> Model Class Initialized
ERROR - 2025-03-17 22:46:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 22:46:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 22:46:39 --> Final output sent to browser
DEBUG - 2025-03-17 22:46:39 --> Total execution time: 0.2132
INFO - 2025-03-17 22:46:39 --> Config Class Initialized
INFO - 2025-03-17 22:46:39 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:46:39 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:46:39 --> Utf8 Class Initialized
INFO - 2025-03-17 22:46:39 --> URI Class Initialized
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:46:39 --> Router Class Initialized
INFO - 2025-03-17 22:46:39 --> Output Class Initialized
INFO - 2025-03-17 22:46:39 --> Security Class Initialized
DEBUG - 2025-03-17 22:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:46:39 --> Input Class Initialized
INFO - 2025-03-17 22:46:39 --> Language Class Initialized
INFO - 2025-03-17 22:46:39 --> Language Class Initialized
INFO - 2025-03-17 22:46:39 --> Config Class Initialized
INFO - 2025-03-17 22:46:39 --> Loader Class Initialized
INFO - 2025-03-17 22:46:39 --> Helper loaded: url_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: file_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: html_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: form_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: text_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:46:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:46:39 --> Database Driver Class Initialized
INFO - 2025-03-17 22:46:39 --> Email Class Initialized
INFO - 2025-03-17 22:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:46:39 --> Form Validation Class Initialized
INFO - 2025-03-17 22:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:46:39 --> Pagination Class Initialized
INFO - 2025-03-17 22:46:39 --> Controller Class Initialized
DEBUG - 2025-03-17 22:46:39 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:46:39 --> Model Class Initialized
DEBUG - 2025-03-17 22:46:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:46:39 --> Model Class Initialized
INFO - 2025-03-17 22:46:39 --> Final output sent to browser
DEBUG - 2025-03-17 22:46:39 --> Total execution time: 0.0105
INFO - 2025-03-17 22:47:04 --> Config Class Initialized
INFO - 2025-03-17 22:47:04 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:47:04 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:47:04 --> Utf8 Class Initialized
INFO - 2025-03-17 22:47:04 --> URI Class Initialized
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:47:04 --> Router Class Initialized
INFO - 2025-03-17 22:47:04 --> Output Class Initialized
INFO - 2025-03-17 22:47:04 --> Security Class Initialized
DEBUG - 2025-03-17 22:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:47:04 --> Input Class Initialized
INFO - 2025-03-17 22:47:04 --> Language Class Initialized
INFO - 2025-03-17 22:47:04 --> Language Class Initialized
INFO - 2025-03-17 22:47:04 --> Config Class Initialized
INFO - 2025-03-17 22:47:04 --> Loader Class Initialized
INFO - 2025-03-17 22:47:04 --> Helper loaded: url_helper
INFO - 2025-03-17 22:47:04 --> Helper loaded: file_helper
INFO - 2025-03-17 22:47:04 --> Helper loaded: html_helper
INFO - 2025-03-17 22:47:04 --> Helper loaded: form_helper
INFO - 2025-03-17 22:47:04 --> Helper loaded: text_helper
INFO - 2025-03-17 22:47:04 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:47:04 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:47:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:47:04 --> Database Driver Class Initialized
INFO - 2025-03-17 22:47:04 --> Email Class Initialized
INFO - 2025-03-17 22:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:47:04 --> Form Validation Class Initialized
INFO - 2025-03-17 22:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:47:04 --> Pagination Class Initialized
INFO - 2025-03-17 22:47:04 --> Controller Class Initialized
DEBUG - 2025-03-17 22:47:04 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:47:04 --> Model Class Initialized
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:47:04 --> Model Class Initialized
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 22:47:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 22:47:04 --> Model Class Initialized
ERROR - 2025-03-17 22:47:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 22:47:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 22:47:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 22:47:04 --> Final output sent to browser
DEBUG - 2025-03-17 22:47:04 --> Total execution time: 0.0956
INFO - 2025-03-17 22:47:05 --> Config Class Initialized
INFO - 2025-03-17 22:47:05 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:47:05 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:47:05 --> Utf8 Class Initialized
INFO - 2025-03-17 22:47:05 --> URI Class Initialized
DEBUG - 2025-03-17 22:47:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:47:05 --> Router Class Initialized
INFO - 2025-03-17 22:47:05 --> Output Class Initialized
INFO - 2025-03-17 22:47:05 --> Security Class Initialized
DEBUG - 2025-03-17 22:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:47:05 --> Input Class Initialized
INFO - 2025-03-17 22:47:05 --> Language Class Initialized
INFO - 2025-03-17 22:47:05 --> Language Class Initialized
INFO - 2025-03-17 22:47:05 --> Config Class Initialized
INFO - 2025-03-17 22:47:05 --> Loader Class Initialized
INFO - 2025-03-17 22:47:05 --> Helper loaded: url_helper
INFO - 2025-03-17 22:47:05 --> Helper loaded: file_helper
INFO - 2025-03-17 22:47:05 --> Helper loaded: html_helper
INFO - 2025-03-17 22:47:05 --> Helper loaded: form_helper
INFO - 2025-03-17 22:47:05 --> Helper loaded: text_helper
INFO - 2025-03-17 22:47:05 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:47:05 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:47:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:47:05 --> Database Driver Class Initialized
INFO - 2025-03-17 22:47:05 --> Email Class Initialized
INFO - 2025-03-17 22:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:47:05 --> Form Validation Class Initialized
INFO - 2025-03-17 22:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:47:05 --> Pagination Class Initialized
INFO - 2025-03-17 22:47:05 --> Controller Class Initialized
DEBUG - 2025-03-17 22:47:05 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:47:05 --> Model Class Initialized
DEBUG - 2025-03-17 22:47:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:47:05 --> Model Class Initialized
INFO - 2025-03-17 22:47:05 --> Final output sent to browser
DEBUG - 2025-03-17 22:47:05 --> Total execution time: 0.0109
INFO - 2025-03-17 22:47:09 --> Config Class Initialized
INFO - 2025-03-17 22:47:09 --> Hooks Class Initialized
DEBUG - 2025-03-17 22:47:09 --> UTF-8 Support Enabled
INFO - 2025-03-17 22:47:09 --> Utf8 Class Initialized
INFO - 2025-03-17 22:47:09 --> URI Class Initialized
DEBUG - 2025-03-17 22:47:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-17 22:47:09 --> Router Class Initialized
INFO - 2025-03-17 22:47:09 --> Output Class Initialized
INFO - 2025-03-17 22:47:09 --> Security Class Initialized
DEBUG - 2025-03-17 22:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 22:47:09 --> Input Class Initialized
INFO - 2025-03-17 22:47:09 --> Language Class Initialized
INFO - 2025-03-17 22:47:09 --> Language Class Initialized
INFO - 2025-03-17 22:47:09 --> Config Class Initialized
INFO - 2025-03-17 22:47:09 --> Loader Class Initialized
INFO - 2025-03-17 22:47:09 --> Helper loaded: url_helper
INFO - 2025-03-17 22:47:09 --> Helper loaded: file_helper
INFO - 2025-03-17 22:47:09 --> Helper loaded: html_helper
INFO - 2025-03-17 22:47:09 --> Helper loaded: form_helper
INFO - 2025-03-17 22:47:09 --> Helper loaded: text_helper
INFO - 2025-03-17 22:47:09 --> Helper loaded: lang_helper
INFO - 2025-03-17 22:47:09 --> Helper loaded: directory_helper
INFO - 2025-03-17 22:47:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 22:47:09 --> Database Driver Class Initialized
INFO - 2025-03-17 22:47:09 --> Email Class Initialized
INFO - 2025-03-17 22:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 22:47:09 --> Form Validation Class Initialized
INFO - 2025-03-17 22:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 22:47:09 --> Pagination Class Initialized
INFO - 2025-03-17 22:47:09 --> Controller Class Initialized
DEBUG - 2025-03-17 22:47:09 --> Supplier MX_Controller Initialized
INFO - 2025-03-17 22:47:09 --> Model Class Initialized
DEBUG - 2025-03-17 22:47:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 22:47:09 --> Model Class Initialized
INFO - 2025-03-17 22:47:09 --> Final output sent to browser
DEBUG - 2025-03-17 22:47:09 --> Total execution time: 0.0125
INFO - 2025-03-17 23:00:36 --> Config Class Initialized
INFO - 2025-03-17 23:00:36 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:00:36 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:00:36 --> Utf8 Class Initialized
INFO - 2025-03-17 23:00:36 --> URI Class Initialized
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:00:36 --> Router Class Initialized
INFO - 2025-03-17 23:00:36 --> Output Class Initialized
INFO - 2025-03-17 23:00:36 --> Security Class Initialized
DEBUG - 2025-03-17 23:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:00:36 --> Input Class Initialized
INFO - 2025-03-17 23:00:36 --> Language Class Initialized
INFO - 2025-03-17 23:00:36 --> Language Class Initialized
INFO - 2025-03-17 23:00:36 --> Config Class Initialized
INFO - 2025-03-17 23:00:36 --> Loader Class Initialized
INFO - 2025-03-17 23:00:36 --> Helper loaded: url_helper
INFO - 2025-03-17 23:00:36 --> Helper loaded: file_helper
INFO - 2025-03-17 23:00:36 --> Helper loaded: html_helper
INFO - 2025-03-17 23:00:36 --> Helper loaded: form_helper
INFO - 2025-03-17 23:00:36 --> Helper loaded: text_helper
INFO - 2025-03-17 23:00:36 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:00:36 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:00:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:00:36 --> Database Driver Class Initialized
INFO - 2025-03-17 23:00:36 --> Email Class Initialized
INFO - 2025-03-17 23:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:00:36 --> Form Validation Class Initialized
INFO - 2025-03-17 23:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:00:36 --> Pagination Class Initialized
INFO - 2025-03-17 23:00:36 --> Controller Class Initialized
DEBUG - 2025-03-17 23:00:36 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:00:36 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:00:36 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:00:36 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:00:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:00:36 --> Model Class Initialized
ERROR - 2025-03-17 23:00:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:00:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:00:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:00:36 --> Final output sent to browser
DEBUG - 2025-03-17 23:00:36 --> Total execution time: 0.7138
INFO - 2025-03-17 23:00:50 --> Config Class Initialized
INFO - 2025-03-17 23:00:50 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:00:50 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:00:50 --> Utf8 Class Initialized
INFO - 2025-03-17 23:00:50 --> URI Class Initialized
DEBUG - 2025-03-17 23:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:00:50 --> Router Class Initialized
INFO - 2025-03-17 23:00:50 --> Output Class Initialized
INFO - 2025-03-17 23:00:50 --> Security Class Initialized
DEBUG - 2025-03-17 23:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:00:50 --> Input Class Initialized
INFO - 2025-03-17 23:00:50 --> Language Class Initialized
INFO - 2025-03-17 23:00:50 --> Language Class Initialized
INFO - 2025-03-17 23:00:50 --> Config Class Initialized
INFO - 2025-03-17 23:00:50 --> Loader Class Initialized
INFO - 2025-03-17 23:00:50 --> Helper loaded: url_helper
INFO - 2025-03-17 23:00:50 --> Helper loaded: file_helper
INFO - 2025-03-17 23:00:50 --> Helper loaded: html_helper
INFO - 2025-03-17 23:00:50 --> Helper loaded: form_helper
INFO - 2025-03-17 23:00:50 --> Helper loaded: text_helper
INFO - 2025-03-17 23:00:50 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:00:50 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:00:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:00:50 --> Database Driver Class Initialized
INFO - 2025-03-17 23:00:50 --> Email Class Initialized
INFO - 2025-03-17 23:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:00:50 --> Form Validation Class Initialized
INFO - 2025-03-17 23:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:00:50 --> Pagination Class Initialized
INFO - 2025-03-17 23:00:50 --> Controller Class Initialized
DEBUG - 2025-03-17 23:00:50 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:00:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:00:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:00:50 --> Model Class Initialized
INFO - 2025-03-17 23:00:50 --> Final output sent to browser
DEBUG - 2025-03-17 23:00:50 --> Total execution time: 0.0151
INFO - 2025-03-17 23:00:51 --> Config Class Initialized
INFO - 2025-03-17 23:00:51 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:00:51 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:00:51 --> Utf8 Class Initialized
INFO - 2025-03-17 23:00:51 --> URI Class Initialized
DEBUG - 2025-03-17 23:00:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:00:51 --> Router Class Initialized
INFO - 2025-03-17 23:00:51 --> Output Class Initialized
INFO - 2025-03-17 23:00:51 --> Security Class Initialized
DEBUG - 2025-03-17 23:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:00:51 --> Input Class Initialized
INFO - 2025-03-17 23:00:51 --> Language Class Initialized
INFO - 2025-03-17 23:00:51 --> Language Class Initialized
INFO - 2025-03-17 23:00:51 --> Config Class Initialized
INFO - 2025-03-17 23:00:51 --> Loader Class Initialized
INFO - 2025-03-17 23:00:51 --> Helper loaded: url_helper
INFO - 2025-03-17 23:00:51 --> Helper loaded: file_helper
INFO - 2025-03-17 23:00:51 --> Helper loaded: html_helper
INFO - 2025-03-17 23:00:51 --> Helper loaded: form_helper
INFO - 2025-03-17 23:00:51 --> Helper loaded: text_helper
INFO - 2025-03-17 23:00:51 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:00:51 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:00:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:00:51 --> Database Driver Class Initialized
INFO - 2025-03-17 23:00:51 --> Email Class Initialized
INFO - 2025-03-17 23:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:00:51 --> Form Validation Class Initialized
INFO - 2025-03-17 23:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:00:51 --> Pagination Class Initialized
INFO - 2025-03-17 23:00:51 --> Controller Class Initialized
DEBUG - 2025-03-17 23:00:51 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:00:51 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:00:51 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:00:51 --> Model Class Initialized
INFO - 2025-03-17 23:00:51 --> Final output sent to browser
DEBUG - 2025-03-17 23:00:51 --> Total execution time: 0.0085
INFO - 2025-03-17 23:00:54 --> Config Class Initialized
INFO - 2025-03-17 23:00:54 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:00:54 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:00:54 --> Utf8 Class Initialized
INFO - 2025-03-17 23:00:54 --> URI Class Initialized
DEBUG - 2025-03-17 23:00:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:00:54 --> Router Class Initialized
INFO - 2025-03-17 23:00:54 --> Output Class Initialized
INFO - 2025-03-17 23:00:54 --> Security Class Initialized
DEBUG - 2025-03-17 23:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:00:54 --> Input Class Initialized
INFO - 2025-03-17 23:00:54 --> Language Class Initialized
INFO - 2025-03-17 23:00:54 --> Language Class Initialized
INFO - 2025-03-17 23:00:54 --> Config Class Initialized
INFO - 2025-03-17 23:00:54 --> Loader Class Initialized
INFO - 2025-03-17 23:00:54 --> Helper loaded: url_helper
INFO - 2025-03-17 23:00:54 --> Helper loaded: file_helper
INFO - 2025-03-17 23:00:54 --> Helper loaded: html_helper
INFO - 2025-03-17 23:00:54 --> Helper loaded: form_helper
INFO - 2025-03-17 23:00:54 --> Helper loaded: text_helper
INFO - 2025-03-17 23:00:54 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:00:54 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:00:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:00:54 --> Database Driver Class Initialized
INFO - 2025-03-17 23:00:54 --> Email Class Initialized
INFO - 2025-03-17 23:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:00:54 --> Form Validation Class Initialized
INFO - 2025-03-17 23:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:00:54 --> Pagination Class Initialized
INFO - 2025-03-17 23:00:54 --> Controller Class Initialized
DEBUG - 2025-03-17 23:00:54 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:00:54 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:00:54 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:00:54 --> Model Class Initialized
INFO - 2025-03-17 23:00:54 --> Final output sent to browser
DEBUG - 2025-03-17 23:00:54 --> Total execution time: 0.0119
INFO - 2025-03-17 23:00:57 --> Config Class Initialized
INFO - 2025-03-17 23:00:57 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:00:57 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:00:57 --> Utf8 Class Initialized
INFO - 2025-03-17 23:00:57 --> URI Class Initialized
DEBUG - 2025-03-17 23:00:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:00:57 --> Router Class Initialized
INFO - 2025-03-17 23:00:57 --> Output Class Initialized
INFO - 2025-03-17 23:00:57 --> Security Class Initialized
DEBUG - 2025-03-17 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:00:57 --> Input Class Initialized
INFO - 2025-03-17 23:00:57 --> Language Class Initialized
INFO - 2025-03-17 23:00:57 --> Language Class Initialized
INFO - 2025-03-17 23:00:57 --> Config Class Initialized
INFO - 2025-03-17 23:00:57 --> Loader Class Initialized
INFO - 2025-03-17 23:00:57 --> Helper loaded: url_helper
INFO - 2025-03-17 23:00:57 --> Helper loaded: file_helper
INFO - 2025-03-17 23:00:57 --> Helper loaded: html_helper
INFO - 2025-03-17 23:00:57 --> Helper loaded: form_helper
INFO - 2025-03-17 23:00:57 --> Helper loaded: text_helper
INFO - 2025-03-17 23:00:57 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:00:57 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:00:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:00:57 --> Database Driver Class Initialized
INFO - 2025-03-17 23:00:57 --> Email Class Initialized
INFO - 2025-03-17 23:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:00:57 --> Form Validation Class Initialized
INFO - 2025-03-17 23:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:00:57 --> Pagination Class Initialized
INFO - 2025-03-17 23:00:57 --> Controller Class Initialized
DEBUG - 2025-03-17 23:00:57 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:00:57 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:00:57 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:00:57 --> Model Class Initialized
INFO - 2025-03-17 23:00:57 --> Final output sent to browser
DEBUG - 2025-03-17 23:00:57 --> Total execution time: 0.0116
INFO - 2025-03-17 23:00:58 --> Config Class Initialized
INFO - 2025-03-17 23:00:58 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:00:58 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:00:58 --> Utf8 Class Initialized
INFO - 2025-03-17 23:00:58 --> URI Class Initialized
DEBUG - 2025-03-17 23:00:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:00:58 --> Router Class Initialized
INFO - 2025-03-17 23:00:58 --> Output Class Initialized
INFO - 2025-03-17 23:00:58 --> Security Class Initialized
DEBUG - 2025-03-17 23:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:00:58 --> Input Class Initialized
INFO - 2025-03-17 23:00:58 --> Language Class Initialized
INFO - 2025-03-17 23:00:58 --> Language Class Initialized
INFO - 2025-03-17 23:00:58 --> Config Class Initialized
INFO - 2025-03-17 23:00:58 --> Loader Class Initialized
INFO - 2025-03-17 23:00:58 --> Helper loaded: url_helper
INFO - 2025-03-17 23:00:58 --> Helper loaded: file_helper
INFO - 2025-03-17 23:00:58 --> Helper loaded: html_helper
INFO - 2025-03-17 23:00:58 --> Helper loaded: form_helper
INFO - 2025-03-17 23:00:58 --> Helper loaded: text_helper
INFO - 2025-03-17 23:00:58 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:00:58 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:00:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:00:58 --> Database Driver Class Initialized
INFO - 2025-03-17 23:00:58 --> Email Class Initialized
INFO - 2025-03-17 23:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:00:58 --> Form Validation Class Initialized
INFO - 2025-03-17 23:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:00:58 --> Pagination Class Initialized
INFO - 2025-03-17 23:00:58 --> Controller Class Initialized
DEBUG - 2025-03-17 23:00:58 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:00:58 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:00:58 --> Model Class Initialized
DEBUG - 2025-03-17 23:00:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:00:58 --> Model Class Initialized
INFO - 2025-03-17 23:00:58 --> Final output sent to browser
DEBUG - 2025-03-17 23:00:58 --> Total execution time: 0.0129
INFO - 2025-03-17 23:01:01 --> Config Class Initialized
INFO - 2025-03-17 23:01:01 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:01 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:01 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:01 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:01 --> Router Class Initialized
INFO - 2025-03-17 23:01:01 --> Output Class Initialized
INFO - 2025-03-17 23:01:01 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:01 --> Input Class Initialized
INFO - 2025-03-17 23:01:01 --> Language Class Initialized
INFO - 2025-03-17 23:01:01 --> Language Class Initialized
INFO - 2025-03-17 23:01:01 --> Config Class Initialized
INFO - 2025-03-17 23:01:01 --> Loader Class Initialized
INFO - 2025-03-17 23:01:01 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:01 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:01 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:01 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:01 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:01 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:01 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:01 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:01 --> Email Class Initialized
INFO - 2025-03-17 23:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:01 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:01 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:01 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:01 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:01 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:01 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:01 --> Model Class Initialized
INFO - 2025-03-17 23:01:01 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:01 --> Total execution time: 0.0104
INFO - 2025-03-17 23:01:02 --> Config Class Initialized
INFO - 2025-03-17 23:01:02 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:02 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:02 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:02 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:02 --> Router Class Initialized
INFO - 2025-03-17 23:01:02 --> Output Class Initialized
INFO - 2025-03-17 23:01:02 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:02 --> Input Class Initialized
INFO - 2025-03-17 23:01:02 --> Language Class Initialized
INFO - 2025-03-17 23:01:02 --> Language Class Initialized
INFO - 2025-03-17 23:01:02 --> Config Class Initialized
INFO - 2025-03-17 23:01:02 --> Loader Class Initialized
INFO - 2025-03-17 23:01:02 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:02 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:02 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:02 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:02 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:02 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:02 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:02 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:02 --> Email Class Initialized
INFO - 2025-03-17 23:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:02 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:02 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:02 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:02 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:02 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:02 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:02 --> Model Class Initialized
INFO - 2025-03-17 23:01:02 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:02 --> Total execution time: 0.0141
INFO - 2025-03-17 23:01:04 --> Config Class Initialized
INFO - 2025-03-17 23:01:04 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:04 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:04 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:04 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:04 --> Router Class Initialized
INFO - 2025-03-17 23:01:04 --> Output Class Initialized
INFO - 2025-03-17 23:01:04 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:04 --> Input Class Initialized
INFO - 2025-03-17 23:01:04 --> Language Class Initialized
INFO - 2025-03-17 23:01:04 --> Language Class Initialized
INFO - 2025-03-17 23:01:04 --> Config Class Initialized
INFO - 2025-03-17 23:01:04 --> Loader Class Initialized
INFO - 2025-03-17 23:01:04 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:04 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:04 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:04 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:04 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:04 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:04 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:04 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:04 --> Email Class Initialized
INFO - 2025-03-17 23:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:04 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:04 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:04 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:04 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:04 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:04 --> Model Class Initialized
INFO - 2025-03-17 23:01:04 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:04 --> Total execution time: 0.0132
INFO - 2025-03-17 23:01:05 --> Config Class Initialized
INFO - 2025-03-17 23:01:05 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:05 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:05 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:05 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:05 --> Router Class Initialized
INFO - 2025-03-17 23:01:05 --> Output Class Initialized
INFO - 2025-03-17 23:01:05 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:05 --> Input Class Initialized
INFO - 2025-03-17 23:01:05 --> Language Class Initialized
INFO - 2025-03-17 23:01:05 --> Language Class Initialized
INFO - 2025-03-17 23:01:05 --> Config Class Initialized
INFO - 2025-03-17 23:01:05 --> Loader Class Initialized
INFO - 2025-03-17 23:01:05 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:05 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:05 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:05 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:05 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:05 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:05 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:05 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:05 --> Email Class Initialized
INFO - 2025-03-17 23:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:05 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:05 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:05 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:05 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:05 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:05 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:05 --> Model Class Initialized
INFO - 2025-03-17 23:01:05 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:05 --> Total execution time: 0.0110
INFO - 2025-03-17 23:01:06 --> Config Class Initialized
INFO - 2025-03-17 23:01:06 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:06 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:06 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:06 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:06 --> Router Class Initialized
INFO - 2025-03-17 23:01:06 --> Output Class Initialized
INFO - 2025-03-17 23:01:06 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:06 --> Input Class Initialized
INFO - 2025-03-17 23:01:06 --> Language Class Initialized
INFO - 2025-03-17 23:01:06 --> Language Class Initialized
INFO - 2025-03-17 23:01:06 --> Config Class Initialized
INFO - 2025-03-17 23:01:06 --> Loader Class Initialized
INFO - 2025-03-17 23:01:06 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:06 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:06 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:06 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:06 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:06 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:06 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:06 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:06 --> Email Class Initialized
INFO - 2025-03-17 23:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:06 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:06 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:06 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:06 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:06 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:06 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:06 --> Model Class Initialized
INFO - 2025-03-17 23:01:06 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:06 --> Total execution time: 0.0114
INFO - 2025-03-17 23:01:08 --> Config Class Initialized
INFO - 2025-03-17 23:01:08 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:08 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:08 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:08 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:08 --> Router Class Initialized
INFO - 2025-03-17 23:01:08 --> Output Class Initialized
INFO - 2025-03-17 23:01:08 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:08 --> Input Class Initialized
INFO - 2025-03-17 23:01:08 --> Language Class Initialized
INFO - 2025-03-17 23:01:08 --> Language Class Initialized
INFO - 2025-03-17 23:01:08 --> Config Class Initialized
INFO - 2025-03-17 23:01:08 --> Loader Class Initialized
INFO - 2025-03-17 23:01:08 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:08 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:08 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:08 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:08 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:08 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:08 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:08 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:08 --> Email Class Initialized
INFO - 2025-03-17 23:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:08 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:08 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:08 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:08 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:08 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:08 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:08 --> Model Class Initialized
INFO - 2025-03-17 23:01:08 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:08 --> Total execution time: 0.0142
INFO - 2025-03-17 23:01:11 --> Config Class Initialized
INFO - 2025-03-17 23:01:11 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:11 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:11 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:11 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:11 --> Router Class Initialized
INFO - 2025-03-17 23:01:11 --> Output Class Initialized
INFO - 2025-03-17 23:01:11 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:11 --> Input Class Initialized
INFO - 2025-03-17 23:01:11 --> Language Class Initialized
INFO - 2025-03-17 23:01:11 --> Language Class Initialized
INFO - 2025-03-17 23:01:11 --> Config Class Initialized
INFO - 2025-03-17 23:01:11 --> Loader Class Initialized
INFO - 2025-03-17 23:01:11 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:11 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:11 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:11 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:11 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:11 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:11 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:11 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:11 --> Email Class Initialized
INFO - 2025-03-17 23:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:11 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:11 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:11 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:11 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:11 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:11 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:11 --> Model Class Initialized
INFO - 2025-03-17 23:01:11 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:11 --> Total execution time: 0.0176
INFO - 2025-03-17 23:01:16 --> Config Class Initialized
INFO - 2025-03-17 23:01:16 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:16 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:16 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:16 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:16 --> Router Class Initialized
INFO - 2025-03-17 23:01:16 --> Output Class Initialized
INFO - 2025-03-17 23:01:16 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:16 --> Input Class Initialized
INFO - 2025-03-17 23:01:16 --> Language Class Initialized
INFO - 2025-03-17 23:01:16 --> Language Class Initialized
INFO - 2025-03-17 23:01:16 --> Config Class Initialized
INFO - 2025-03-17 23:01:16 --> Loader Class Initialized
INFO - 2025-03-17 23:01:16 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:16 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:16 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:16 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:16 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:16 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:16 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:16 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:16 --> Email Class Initialized
INFO - 2025-03-17 23:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:16 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:16 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:16 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:16 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:16 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:16 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:16 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:01:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:01:16 --> Model Class Initialized
ERROR - 2025-03-17 23:01:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:01:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:01:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:01:16 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:16 --> Total execution time: 0.2033
INFO - 2025-03-17 23:01:18 --> Config Class Initialized
INFO - 2025-03-17 23:01:18 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:18 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:18 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:18 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:18 --> Router Class Initialized
INFO - 2025-03-17 23:01:18 --> Output Class Initialized
INFO - 2025-03-17 23:01:18 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:18 --> Input Class Initialized
INFO - 2025-03-17 23:01:18 --> Language Class Initialized
INFO - 2025-03-17 23:01:18 --> Language Class Initialized
INFO - 2025-03-17 23:01:18 --> Config Class Initialized
INFO - 2025-03-17 23:01:18 --> Loader Class Initialized
INFO - 2025-03-17 23:01:18 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:18 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:18 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:18 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:18 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:18 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:18 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:18 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:18 --> Email Class Initialized
INFO - 2025-03-17 23:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:18 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:18 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:18 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:18 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:18 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:18 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:18 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:01:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:01:18 --> Model Class Initialized
ERROR - 2025-03-17 23:01:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:01:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:01:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:01:18 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:18 --> Total execution time: 0.2132
INFO - 2025-03-17 23:01:30 --> Config Class Initialized
INFO - 2025-03-17 23:01:30 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:30 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:30 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:30 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:30 --> Router Class Initialized
INFO - 2025-03-17 23:01:30 --> Output Class Initialized
INFO - 2025-03-17 23:01:30 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:30 --> Input Class Initialized
INFO - 2025-03-17 23:01:30 --> Language Class Initialized
INFO - 2025-03-17 23:01:30 --> Language Class Initialized
INFO - 2025-03-17 23:01:30 --> Config Class Initialized
INFO - 2025-03-17 23:01:30 --> Loader Class Initialized
INFO - 2025-03-17 23:01:30 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:30 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:30 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:30 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:30 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:30 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:30 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:30 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:30 --> Email Class Initialized
INFO - 2025-03-17 23:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:30 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:30 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:30 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:30 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:30 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:30 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:30 --> Model Class Initialized
INFO - 2025-03-17 23:01:30 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:30 --> Total execution time: 0.0144
INFO - 2025-03-17 23:01:32 --> Config Class Initialized
INFO - 2025-03-17 23:01:32 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:32 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:32 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:32 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:32 --> Router Class Initialized
INFO - 2025-03-17 23:01:32 --> Output Class Initialized
INFO - 2025-03-17 23:01:32 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:32 --> Input Class Initialized
INFO - 2025-03-17 23:01:32 --> Language Class Initialized
INFO - 2025-03-17 23:01:32 --> Language Class Initialized
INFO - 2025-03-17 23:01:32 --> Config Class Initialized
INFO - 2025-03-17 23:01:32 --> Loader Class Initialized
INFO - 2025-03-17 23:01:32 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:32 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:32 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:32 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:32 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:32 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:32 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:32 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:32 --> Email Class Initialized
INFO - 2025-03-17 23:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:32 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:32 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:32 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:32 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:32 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:32 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:32 --> Model Class Initialized
INFO - 2025-03-17 23:01:32 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:32 --> Total execution time: 0.0156
INFO - 2025-03-17 23:01:33 --> Config Class Initialized
INFO - 2025-03-17 23:01:33 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:33 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:33 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:33 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:33 --> Router Class Initialized
INFO - 2025-03-17 23:01:33 --> Output Class Initialized
INFO - 2025-03-17 23:01:33 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:33 --> Input Class Initialized
INFO - 2025-03-17 23:01:33 --> Language Class Initialized
INFO - 2025-03-17 23:01:33 --> Language Class Initialized
INFO - 2025-03-17 23:01:33 --> Config Class Initialized
INFO - 2025-03-17 23:01:33 --> Loader Class Initialized
INFO - 2025-03-17 23:01:33 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:33 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:33 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:33 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:33 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:33 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:33 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:33 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:33 --> Email Class Initialized
INFO - 2025-03-17 23:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:33 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:33 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:33 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:33 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:33 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:33 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:33 --> Model Class Initialized
INFO - 2025-03-17 23:01:33 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:33 --> Total execution time: 0.0136
INFO - 2025-03-17 23:01:35 --> Config Class Initialized
INFO - 2025-03-17 23:01:35 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:35 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:35 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:35 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:35 --> Router Class Initialized
INFO - 2025-03-17 23:01:35 --> Output Class Initialized
INFO - 2025-03-17 23:01:35 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:35 --> Input Class Initialized
INFO - 2025-03-17 23:01:35 --> Language Class Initialized
INFO - 2025-03-17 23:01:35 --> Language Class Initialized
INFO - 2025-03-17 23:01:35 --> Config Class Initialized
INFO - 2025-03-17 23:01:35 --> Loader Class Initialized
INFO - 2025-03-17 23:01:35 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:35 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:35 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:35 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:35 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:35 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:35 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:35 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:35 --> Email Class Initialized
INFO - 2025-03-17 23:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:35 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:35 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:35 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:35 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:35 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:35 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:35 --> Model Class Initialized
INFO - 2025-03-17 23:01:35 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:35 --> Total execution time: 0.0139
INFO - 2025-03-17 23:01:50 --> Config Class Initialized
INFO - 2025-03-17 23:01:50 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:50 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:50 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:50 --> Router Class Initialized
INFO - 2025-03-17 23:01:50 --> Output Class Initialized
INFO - 2025-03-17 23:01:50 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:50 --> Input Class Initialized
INFO - 2025-03-17 23:01:50 --> Language Class Initialized
INFO - 2025-03-17 23:01:50 --> Language Class Initialized
INFO - 2025-03-17 23:01:50 --> Config Class Initialized
INFO - 2025-03-17 23:01:50 --> Loader Class Initialized
INFO - 2025-03-17 23:01:50 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:50 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:50 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:50 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:50 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:50 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:50 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:50 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:50 --> Email Class Initialized
INFO - 2025-03-17 23:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:50 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:50 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:50 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:50 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:01:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:01:50 --> Model Class Initialized
ERROR - 2025-03-17 23:01:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:01:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:01:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:01:50 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:50 --> Total execution time: 0.1699
INFO - 2025-03-17 23:01:52 --> Config Class Initialized
INFO - 2025-03-17 23:01:52 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:52 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:52 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:52 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:52 --> Router Class Initialized
INFO - 2025-03-17 23:01:52 --> Output Class Initialized
INFO - 2025-03-17 23:01:52 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:52 --> Input Class Initialized
INFO - 2025-03-17 23:01:52 --> Language Class Initialized
INFO - 2025-03-17 23:01:52 --> Language Class Initialized
INFO - 2025-03-17 23:01:52 --> Config Class Initialized
INFO - 2025-03-17 23:01:52 --> Loader Class Initialized
INFO - 2025-03-17 23:01:52 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:52 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:52 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:52 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:52 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:52 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:52 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:52 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:52 --> Email Class Initialized
INFO - 2025-03-17 23:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:52 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:52 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:52 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:52 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:52 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:52 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:52 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:01:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:01:52 --> Model Class Initialized
ERROR - 2025-03-17 23:01:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:01:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:01:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:01:52 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:52 --> Total execution time: 0.1385
INFO - 2025-03-17 23:01:55 --> Config Class Initialized
INFO - 2025-03-17 23:01:55 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:01:55 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:01:55 --> Utf8 Class Initialized
INFO - 2025-03-17 23:01:55 --> URI Class Initialized
DEBUG - 2025-03-17 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:01:55 --> Router Class Initialized
INFO - 2025-03-17 23:01:55 --> Output Class Initialized
INFO - 2025-03-17 23:01:55 --> Security Class Initialized
DEBUG - 2025-03-17 23:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:01:55 --> Input Class Initialized
INFO - 2025-03-17 23:01:55 --> Language Class Initialized
INFO - 2025-03-17 23:01:55 --> Language Class Initialized
INFO - 2025-03-17 23:01:55 --> Config Class Initialized
INFO - 2025-03-17 23:01:55 --> Loader Class Initialized
INFO - 2025-03-17 23:01:55 --> Helper loaded: url_helper
INFO - 2025-03-17 23:01:55 --> Helper loaded: file_helper
INFO - 2025-03-17 23:01:55 --> Helper loaded: html_helper
INFO - 2025-03-17 23:01:55 --> Helper loaded: form_helper
INFO - 2025-03-17 23:01:55 --> Helper loaded: text_helper
INFO - 2025-03-17 23:01:55 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:01:55 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:01:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:01:55 --> Database Driver Class Initialized
INFO - 2025-03-17 23:01:55 --> Email Class Initialized
INFO - 2025-03-17 23:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:01:55 --> Form Validation Class Initialized
INFO - 2025-03-17 23:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:01:55 --> Pagination Class Initialized
INFO - 2025-03-17 23:01:55 --> Controller Class Initialized
DEBUG - 2025-03-17 23:01:55 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:01:55 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:01:55 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:01:55 --> Model Class Initialized
DEBUG - 2025-03-17 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:01:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:01:55 --> Model Class Initialized
ERROR - 2025-03-17 23:01:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:01:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:01:56 --> Final output sent to browser
DEBUG - 2025-03-17 23:01:56 --> Total execution time: 0.2200
INFO - 2025-03-17 23:02:11 --> Config Class Initialized
INFO - 2025-03-17 23:02:11 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:11 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:11 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:11 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:02:11 --> Router Class Initialized
INFO - 2025-03-17 23:02:11 --> Output Class Initialized
INFO - 2025-03-17 23:02:11 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:11 --> Input Class Initialized
INFO - 2025-03-17 23:02:11 --> Language Class Initialized
INFO - 2025-03-17 23:02:11 --> Language Class Initialized
INFO - 2025-03-17 23:02:11 --> Config Class Initialized
INFO - 2025-03-17 23:02:11 --> Loader Class Initialized
INFO - 2025-03-17 23:02:11 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:11 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:11 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:11 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:11 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:11 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:11 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:11 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:11 --> Email Class Initialized
INFO - 2025-03-17 23:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:11 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:11 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:11 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:11 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:02:11 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:02:11 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:02:11 --> Model Class Initialized
INFO - 2025-03-17 23:02:11 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:11 --> Total execution time: 0.0137
INFO - 2025-03-17 23:02:12 --> Config Class Initialized
INFO - 2025-03-17 23:02:12 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:12 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:12 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:12 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:02:12 --> Router Class Initialized
INFO - 2025-03-17 23:02:12 --> Output Class Initialized
INFO - 2025-03-17 23:02:12 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:12 --> Input Class Initialized
INFO - 2025-03-17 23:02:12 --> Language Class Initialized
INFO - 2025-03-17 23:02:12 --> Language Class Initialized
INFO - 2025-03-17 23:02:12 --> Config Class Initialized
INFO - 2025-03-17 23:02:12 --> Loader Class Initialized
INFO - 2025-03-17 23:02:12 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:12 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:12 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:12 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:12 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:12 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:12 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:12 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:12 --> Email Class Initialized
INFO - 2025-03-17 23:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:12 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:12 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:12 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:12 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:02:12 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:02:12 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:02:12 --> Model Class Initialized
INFO - 2025-03-17 23:02:12 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:12 --> Total execution time: 0.0135
INFO - 2025-03-17 23:02:16 --> Config Class Initialized
INFO - 2025-03-17 23:02:16 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:16 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:16 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:16 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:02:16 --> Router Class Initialized
INFO - 2025-03-17 23:02:16 --> Output Class Initialized
INFO - 2025-03-17 23:02:16 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:16 --> Input Class Initialized
INFO - 2025-03-17 23:02:16 --> Language Class Initialized
INFO - 2025-03-17 23:02:16 --> Language Class Initialized
INFO - 2025-03-17 23:02:16 --> Config Class Initialized
INFO - 2025-03-17 23:02:16 --> Loader Class Initialized
INFO - 2025-03-17 23:02:16 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:16 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:16 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:16 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:16 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:16 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:16 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:16 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:16 --> Email Class Initialized
INFO - 2025-03-17 23:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:16 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:16 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:16 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:16 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:02:16 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:02:16 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:02:16 --> Model Class Initialized
INFO - 2025-03-17 23:02:16 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:16 --> Total execution time: 0.0088
INFO - 2025-03-17 23:02:18 --> Config Class Initialized
INFO - 2025-03-17 23:02:18 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:18 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:18 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:18 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:02:18 --> Router Class Initialized
INFO - 2025-03-17 23:02:18 --> Output Class Initialized
INFO - 2025-03-17 23:02:18 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:18 --> Input Class Initialized
INFO - 2025-03-17 23:02:18 --> Language Class Initialized
INFO - 2025-03-17 23:02:18 --> Language Class Initialized
INFO - 2025-03-17 23:02:18 --> Config Class Initialized
INFO - 2025-03-17 23:02:18 --> Loader Class Initialized
INFO - 2025-03-17 23:02:18 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:18 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:18 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:18 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:18 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:18 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:18 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:18 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:18 --> Email Class Initialized
INFO - 2025-03-17 23:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:18 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:18 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:18 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:18 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:02:18 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:02:18 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:02:18 --> Model Class Initialized
INFO - 2025-03-17 23:02:18 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:18 --> Total execution time: 0.0063
INFO - 2025-03-17 23:02:24 --> Config Class Initialized
INFO - 2025-03-17 23:02:24 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:24 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:24 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:24 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:24 --> Router Class Initialized
INFO - 2025-03-17 23:02:24 --> Output Class Initialized
INFO - 2025-03-17 23:02:24 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:24 --> Input Class Initialized
INFO - 2025-03-17 23:02:24 --> Language Class Initialized
INFO - 2025-03-17 23:02:24 --> Language Class Initialized
INFO - 2025-03-17 23:02:24 --> Config Class Initialized
INFO - 2025-03-17 23:02:24 --> Loader Class Initialized
INFO - 2025-03-17 23:02:24 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:24 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:24 --> Email Class Initialized
INFO - 2025-03-17 23:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:24 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:24 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:24 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:24 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:24 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:24 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:24 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:02:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:02:24 --> Model Class Initialized
ERROR - 2025-03-17 23:02:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:02:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:02:24 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:24 --> Total execution time: 0.1475
INFO - 2025-03-17 23:02:24 --> Config Class Initialized
INFO - 2025-03-17 23:02:24 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:24 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:24 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:24 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:24 --> Router Class Initialized
INFO - 2025-03-17 23:02:24 --> Output Class Initialized
INFO - 2025-03-17 23:02:24 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:24 --> Input Class Initialized
INFO - 2025-03-17 23:02:24 --> Language Class Initialized
INFO - 2025-03-17 23:02:24 --> Language Class Initialized
INFO - 2025-03-17 23:02:24 --> Config Class Initialized
INFO - 2025-03-17 23:02:24 --> Loader Class Initialized
INFO - 2025-03-17 23:02:24 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:24 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:24 --> Email Class Initialized
INFO - 2025-03-17 23:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:24 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:24 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:24 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:24 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:24 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:24 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:24 --> Model Class Initialized
ERROR - 2025-03-17 23:02:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:24 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-17 23:02:24 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:24 --> Total execution time: 0.0464
INFO - 2025-03-17 23:02:31 --> Config Class Initialized
INFO - 2025-03-17 23:02:31 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:31 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:31 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:31 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:31 --> Router Class Initialized
INFO - 2025-03-17 23:02:31 --> Output Class Initialized
INFO - 2025-03-17 23:02:31 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:31 --> Input Class Initialized
INFO - 2025-03-17 23:02:31 --> Language Class Initialized
INFO - 2025-03-17 23:02:31 --> Language Class Initialized
INFO - 2025-03-17 23:02:31 --> Config Class Initialized
INFO - 2025-03-17 23:02:31 --> Loader Class Initialized
INFO - 2025-03-17 23:02:31 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:31 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:31 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:31 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:31 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:31 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:31 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:31 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:31 --> Email Class Initialized
INFO - 2025-03-17 23:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:31 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:31 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:31 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:31 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:31 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:31 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:31 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:02:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:02:31 --> Model Class Initialized
ERROR - 2025-03-17 23:02:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:02:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:02:31 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:31 --> Total execution time: 0.1785
INFO - 2025-03-17 23:02:38 --> Config Class Initialized
INFO - 2025-03-17 23:02:38 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:38 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:38 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:38 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:38 --> Router Class Initialized
INFO - 2025-03-17 23:02:38 --> Output Class Initialized
INFO - 2025-03-17 23:02:38 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:38 --> Input Class Initialized
INFO - 2025-03-17 23:02:38 --> Language Class Initialized
INFO - 2025-03-17 23:02:38 --> Language Class Initialized
INFO - 2025-03-17 23:02:38 --> Config Class Initialized
INFO - 2025-03-17 23:02:38 --> Loader Class Initialized
INFO - 2025-03-17 23:02:38 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:38 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:38 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:38 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:38 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:38 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:38 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:38 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:38 --> Email Class Initialized
INFO - 2025-03-17 23:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:38 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:38 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:38 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:38 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:38 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:38 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:38 --> Model Class Initialized
INFO - 2025-03-17 23:02:38 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:38 --> Total execution time: 0.0086
INFO - 2025-03-17 23:02:43 --> Config Class Initialized
INFO - 2025-03-17 23:02:43 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:43 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:43 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:43 --> Router Class Initialized
INFO - 2025-03-17 23:02:43 --> Output Class Initialized
INFO - 2025-03-17 23:02:43 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:43 --> Input Class Initialized
INFO - 2025-03-17 23:02:43 --> Language Class Initialized
INFO - 2025-03-17 23:02:43 --> Language Class Initialized
INFO - 2025-03-17 23:02:43 --> Config Class Initialized
INFO - 2025-03-17 23:02:43 --> Loader Class Initialized
INFO - 2025-03-17 23:02:43 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:43 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:43 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:43 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:43 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:43 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:43 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:43 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:43 --> Email Class Initialized
INFO - 2025-03-17 23:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:43 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:43 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:43 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:43 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:43 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:43 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:43 --> Model Class Initialized
INFO - 2025-03-17 23:02:43 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:43 --> Total execution time: 0.0076
INFO - 2025-03-17 23:02:50 --> Config Class Initialized
INFO - 2025-03-17 23:02:50 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:50 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:50 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:50 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:50 --> Router Class Initialized
INFO - 2025-03-17 23:02:50 --> Output Class Initialized
INFO - 2025-03-17 23:02:50 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:50 --> Input Class Initialized
INFO - 2025-03-17 23:02:50 --> Language Class Initialized
INFO - 2025-03-17 23:02:50 --> Language Class Initialized
INFO - 2025-03-17 23:02:50 --> Config Class Initialized
INFO - 2025-03-17 23:02:50 --> Loader Class Initialized
INFO - 2025-03-17 23:02:50 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:50 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:50 --> Email Class Initialized
INFO - 2025-03-17 23:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:50 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:50 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:50 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:50 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
INFO - 2025-03-17 23:02:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-17 23:02:50 --> Config Class Initialized
INFO - 2025-03-17 23:02:50 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:50 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:50 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:50 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:50 --> Router Class Initialized
INFO - 2025-03-17 23:02:50 --> Output Class Initialized
INFO - 2025-03-17 23:02:50 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:50 --> Input Class Initialized
INFO - 2025-03-17 23:02:50 --> Language Class Initialized
INFO - 2025-03-17 23:02:50 --> Language Class Initialized
INFO - 2025-03-17 23:02:50 --> Config Class Initialized
INFO - 2025-03-17 23:02:50 --> Loader Class Initialized
INFO - 2025-03-17 23:02:50 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:50 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:50 --> Email Class Initialized
INFO - 2025-03-17 23:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:50 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:50 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:50 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:50 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:02:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
ERROR - 2025-03-17 23:02:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:02:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:02:50 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:50 --> Total execution time: 0.1372
INFO - 2025-03-17 23:02:50 --> Config Class Initialized
INFO - 2025-03-17 23:02:50 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:50 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:50 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:50 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-17 23:02:50 --> Router Class Initialized
INFO - 2025-03-17 23:02:50 --> Output Class Initialized
INFO - 2025-03-17 23:02:50 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:50 --> Input Class Initialized
INFO - 2025-03-17 23:02:50 --> Language Class Initialized
INFO - 2025-03-17 23:02:50 --> Language Class Initialized
INFO - 2025-03-17 23:02:50 --> Config Class Initialized
INFO - 2025-03-17 23:02:50 --> Loader Class Initialized
INFO - 2025-03-17 23:02:50 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:50 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:50 --> Email Class Initialized
INFO - 2025-03-17 23:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:50 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:50 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:50 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:50 --> Product MX_Controller Initialized
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-17 23:02:50 --> Model Class Initialized
ERROR - 2025-03-17 23:02:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-17 23:02:50 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-17 23:02:50 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:50 --> Total execution time: 0.0300
INFO - 2025-03-17 23:02:54 --> Config Class Initialized
INFO - 2025-03-17 23:02:54 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:54 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:54 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:54 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:02:54 --> Router Class Initialized
INFO - 2025-03-17 23:02:54 --> Output Class Initialized
INFO - 2025-03-17 23:02:54 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:54 --> Input Class Initialized
INFO - 2025-03-17 23:02:54 --> Language Class Initialized
INFO - 2025-03-17 23:02:54 --> Language Class Initialized
INFO - 2025-03-17 23:02:54 --> Config Class Initialized
INFO - 2025-03-17 23:02:54 --> Loader Class Initialized
INFO - 2025-03-17 23:02:54 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:54 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:54 --> Email Class Initialized
INFO - 2025-03-17 23:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:54 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:54 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:54 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:54 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:02:54 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:02:54 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:02:54 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:02:54 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:02:54 --> Model Class Initialized
ERROR - 2025-03-17 23:02:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:02:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:02:54 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:54 --> Total execution time: 0.1838
INFO - 2025-03-17 23:02:54 --> Config Class Initialized
INFO - 2025-03-17 23:02:54 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:54 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:54 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:54 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:02:54 --> Router Class Initialized
INFO - 2025-03-17 23:02:54 --> Output Class Initialized
INFO - 2025-03-17 23:02:54 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:54 --> Input Class Initialized
INFO - 2025-03-17 23:02:54 --> Language Class Initialized
INFO - 2025-03-17 23:02:54 --> Language Class Initialized
INFO - 2025-03-17 23:02:54 --> Config Class Initialized
INFO - 2025-03-17 23:02:54 --> Loader Class Initialized
INFO - 2025-03-17 23:02:54 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:54 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:54 --> Email Class Initialized
INFO - 2025-03-17 23:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:54 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:54 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:54 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:54 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:02:54 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:02:54 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:02:54 --> Model Class Initialized
INFO - 2025-03-17 23:02:54 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:54 --> Total execution time: 0.0329
INFO - 2025-03-17 23:02:56 --> Config Class Initialized
INFO - 2025-03-17 23:02:56 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:02:56 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:02:56 --> Utf8 Class Initialized
INFO - 2025-03-17 23:02:56 --> URI Class Initialized
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:02:56 --> Router Class Initialized
INFO - 2025-03-17 23:02:56 --> Output Class Initialized
INFO - 2025-03-17 23:02:56 --> Security Class Initialized
DEBUG - 2025-03-17 23:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:02:56 --> Input Class Initialized
INFO - 2025-03-17 23:02:56 --> Language Class Initialized
INFO - 2025-03-17 23:02:56 --> Language Class Initialized
INFO - 2025-03-17 23:02:56 --> Config Class Initialized
INFO - 2025-03-17 23:02:56 --> Loader Class Initialized
INFO - 2025-03-17 23:02:56 --> Helper loaded: url_helper
INFO - 2025-03-17 23:02:56 --> Helper loaded: file_helper
INFO - 2025-03-17 23:02:56 --> Helper loaded: html_helper
INFO - 2025-03-17 23:02:56 --> Helper loaded: form_helper
INFO - 2025-03-17 23:02:56 --> Helper loaded: text_helper
INFO - 2025-03-17 23:02:56 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:02:56 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:02:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:02:56 --> Database Driver Class Initialized
INFO - 2025-03-17 23:02:56 --> Email Class Initialized
INFO - 2025-03-17 23:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:02:56 --> Form Validation Class Initialized
INFO - 2025-03-17 23:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:02:56 --> Pagination Class Initialized
INFO - 2025-03-17 23:02:56 --> Controller Class Initialized
DEBUG - 2025-03-17 23:02:56 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:02:56 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:02:56 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:02:56 --> Model Class Initialized
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:02:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:02:56 --> Model Class Initialized
ERROR - 2025-03-17 23:02:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:02:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:02:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:02:56 --> Final output sent to browser
DEBUG - 2025-03-17 23:02:56 --> Total execution time: 0.1999
INFO - 2025-03-17 23:03:06 --> Config Class Initialized
INFO - 2025-03-17 23:03:06 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:03:06 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:03:06 --> Utf8 Class Initialized
INFO - 2025-03-17 23:03:06 --> URI Class Initialized
DEBUG - 2025-03-17 23:03:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:03:06 --> Router Class Initialized
INFO - 2025-03-17 23:03:06 --> Output Class Initialized
INFO - 2025-03-17 23:03:06 --> Security Class Initialized
DEBUG - 2025-03-17 23:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:03:06 --> Input Class Initialized
INFO - 2025-03-17 23:03:06 --> Language Class Initialized
INFO - 2025-03-17 23:03:06 --> Language Class Initialized
INFO - 2025-03-17 23:03:06 --> Config Class Initialized
INFO - 2025-03-17 23:03:06 --> Loader Class Initialized
INFO - 2025-03-17 23:03:06 --> Helper loaded: url_helper
INFO - 2025-03-17 23:03:06 --> Helper loaded: file_helper
INFO - 2025-03-17 23:03:06 --> Helper loaded: html_helper
INFO - 2025-03-17 23:03:06 --> Helper loaded: form_helper
INFO - 2025-03-17 23:03:06 --> Helper loaded: text_helper
INFO - 2025-03-17 23:03:06 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:03:06 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:03:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:03:06 --> Database Driver Class Initialized
INFO - 2025-03-17 23:03:06 --> Email Class Initialized
INFO - 2025-03-17 23:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:03:06 --> Form Validation Class Initialized
INFO - 2025-03-17 23:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:03:06 --> Pagination Class Initialized
INFO - 2025-03-17 23:03:06 --> Controller Class Initialized
DEBUG - 2025-03-17 23:03:06 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:03:06 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:03:06 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:03:06 --> Model Class Initialized
INFO - 2025-03-17 23:03:06 --> Final output sent to browser
DEBUG - 2025-03-17 23:03:06 --> Total execution time: 0.0162
INFO - 2025-03-17 23:03:07 --> Config Class Initialized
INFO - 2025-03-17 23:03:07 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:03:07 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:03:07 --> Utf8 Class Initialized
INFO - 2025-03-17 23:03:07 --> URI Class Initialized
DEBUG - 2025-03-17 23:03:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:03:07 --> Router Class Initialized
INFO - 2025-03-17 23:03:07 --> Output Class Initialized
INFO - 2025-03-17 23:03:07 --> Security Class Initialized
DEBUG - 2025-03-17 23:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:03:07 --> Input Class Initialized
INFO - 2025-03-17 23:03:07 --> Language Class Initialized
INFO - 2025-03-17 23:03:07 --> Language Class Initialized
INFO - 2025-03-17 23:03:07 --> Config Class Initialized
INFO - 2025-03-17 23:03:07 --> Loader Class Initialized
INFO - 2025-03-17 23:03:07 --> Helper loaded: url_helper
INFO - 2025-03-17 23:03:07 --> Helper loaded: file_helper
INFO - 2025-03-17 23:03:07 --> Helper loaded: html_helper
INFO - 2025-03-17 23:03:07 --> Helper loaded: form_helper
INFO - 2025-03-17 23:03:07 --> Helper loaded: text_helper
INFO - 2025-03-17 23:03:07 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:03:07 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:03:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:03:07 --> Database Driver Class Initialized
INFO - 2025-03-17 23:03:07 --> Email Class Initialized
INFO - 2025-03-17 23:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:03:07 --> Form Validation Class Initialized
INFO - 2025-03-17 23:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:03:07 --> Pagination Class Initialized
INFO - 2025-03-17 23:03:07 --> Controller Class Initialized
DEBUG - 2025-03-17 23:03:07 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:03:07 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:03:07 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:03:07 --> Model Class Initialized
INFO - 2025-03-17 23:03:07 --> Final output sent to browser
DEBUG - 2025-03-17 23:03:07 --> Total execution time: 0.0105
INFO - 2025-03-17 23:03:27 --> Config Class Initialized
INFO - 2025-03-17 23:03:27 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:03:27 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:03:27 --> Utf8 Class Initialized
INFO - 2025-03-17 23:03:27 --> URI Class Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:03:27 --> Router Class Initialized
INFO - 2025-03-17 23:03:27 --> Output Class Initialized
INFO - 2025-03-17 23:03:27 --> Security Class Initialized
DEBUG - 2025-03-17 23:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:03:27 --> Input Class Initialized
INFO - 2025-03-17 23:03:27 --> Language Class Initialized
INFO - 2025-03-17 23:03:27 --> Language Class Initialized
INFO - 2025-03-17 23:03:27 --> Config Class Initialized
INFO - 2025-03-17 23:03:27 --> Loader Class Initialized
INFO - 2025-03-17 23:03:27 --> Helper loaded: url_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: file_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: html_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: form_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: text_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:03:27 --> Database Driver Class Initialized
INFO - 2025-03-17 23:03:27 --> Email Class Initialized
INFO - 2025-03-17 23:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:03:27 --> Form Validation Class Initialized
INFO - 2025-03-17 23:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:03:27 --> Pagination Class Initialized
INFO - 2025-03-17 23:03:27 --> Controller Class Initialized
DEBUG - 2025-03-17 23:03:27 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:03:27 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:03:27 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:03:27 --> Model Class Initialized
INFO - 2025-03-17 23:03:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-17 23:03:27 --> Config Class Initialized
INFO - 2025-03-17 23:03:27 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:03:27 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:03:27 --> Utf8 Class Initialized
INFO - 2025-03-17 23:03:27 --> URI Class Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:03:27 --> Router Class Initialized
INFO - 2025-03-17 23:03:27 --> Output Class Initialized
INFO - 2025-03-17 23:03:27 --> Security Class Initialized
DEBUG - 2025-03-17 23:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:03:27 --> Input Class Initialized
INFO - 2025-03-17 23:03:27 --> Language Class Initialized
INFO - 2025-03-17 23:03:27 --> Language Class Initialized
INFO - 2025-03-17 23:03:27 --> Config Class Initialized
INFO - 2025-03-17 23:03:27 --> Loader Class Initialized
INFO - 2025-03-17 23:03:27 --> Helper loaded: url_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: file_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: html_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: form_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: text_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:03:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:03:27 --> Database Driver Class Initialized
INFO - 2025-03-17 23:03:27 --> Email Class Initialized
INFO - 2025-03-17 23:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:03:27 --> Form Validation Class Initialized
INFO - 2025-03-17 23:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:03:27 --> Pagination Class Initialized
INFO - 2025-03-17 23:03:27 --> Controller Class Initialized
DEBUG - 2025-03-17 23:03:27 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:03:27 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:03:27 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:03:27 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:03:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:03:27 --> Model Class Initialized
ERROR - 2025-03-17 23:03:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:03:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:03:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:03:27 --> Final output sent to browser
DEBUG - 2025-03-17 23:03:27 --> Total execution time: 0.1580
INFO - 2025-03-17 23:03:28 --> Config Class Initialized
INFO - 2025-03-17 23:03:28 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:03:28 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:03:28 --> Utf8 Class Initialized
INFO - 2025-03-17 23:03:28 --> URI Class Initialized
DEBUG - 2025-03-17 23:03:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:03:28 --> Router Class Initialized
INFO - 2025-03-17 23:03:28 --> Output Class Initialized
INFO - 2025-03-17 23:03:28 --> Security Class Initialized
DEBUG - 2025-03-17 23:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:03:28 --> Input Class Initialized
INFO - 2025-03-17 23:03:28 --> Language Class Initialized
INFO - 2025-03-17 23:03:28 --> Language Class Initialized
INFO - 2025-03-17 23:03:28 --> Config Class Initialized
INFO - 2025-03-17 23:03:28 --> Loader Class Initialized
INFO - 2025-03-17 23:03:28 --> Helper loaded: url_helper
INFO - 2025-03-17 23:03:28 --> Helper loaded: file_helper
INFO - 2025-03-17 23:03:28 --> Helper loaded: html_helper
INFO - 2025-03-17 23:03:28 --> Helper loaded: form_helper
INFO - 2025-03-17 23:03:28 --> Helper loaded: text_helper
INFO - 2025-03-17 23:03:28 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:03:28 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:03:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:03:28 --> Database Driver Class Initialized
INFO - 2025-03-17 23:03:28 --> Email Class Initialized
INFO - 2025-03-17 23:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:03:28 --> Form Validation Class Initialized
INFO - 2025-03-17 23:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:03:28 --> Pagination Class Initialized
INFO - 2025-03-17 23:03:28 --> Controller Class Initialized
DEBUG - 2025-03-17 23:03:28 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:03:28 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:03:28 --> Model Class Initialized
DEBUG - 2025-03-17 23:03:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:03:28 --> Model Class Initialized
INFO - 2025-03-17 23:03:28 --> Final output sent to browser
DEBUG - 2025-03-17 23:03:28 --> Total execution time: 0.0438
INFO - 2025-03-17 23:05:41 --> Config Class Initialized
INFO - 2025-03-17 23:05:41 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:05:41 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:05:41 --> Utf8 Class Initialized
INFO - 2025-03-17 23:05:41 --> URI Class Initialized
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:05:41 --> Router Class Initialized
INFO - 2025-03-17 23:05:41 --> Output Class Initialized
INFO - 2025-03-17 23:05:41 --> Security Class Initialized
DEBUG - 2025-03-17 23:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:05:41 --> Input Class Initialized
INFO - 2025-03-17 23:05:41 --> Language Class Initialized
INFO - 2025-03-17 23:05:41 --> Language Class Initialized
INFO - 2025-03-17 23:05:41 --> Config Class Initialized
INFO - 2025-03-17 23:05:41 --> Loader Class Initialized
INFO - 2025-03-17 23:05:41 --> Helper loaded: url_helper
INFO - 2025-03-17 23:05:41 --> Helper loaded: file_helper
INFO - 2025-03-17 23:05:41 --> Helper loaded: html_helper
INFO - 2025-03-17 23:05:41 --> Helper loaded: form_helper
INFO - 2025-03-17 23:05:41 --> Helper loaded: text_helper
INFO - 2025-03-17 23:05:41 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:05:41 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:05:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:05:41 --> Database Driver Class Initialized
INFO - 2025-03-17 23:05:41 --> Email Class Initialized
INFO - 2025-03-17 23:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:05:41 --> Form Validation Class Initialized
INFO - 2025-03-17 23:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:05:41 --> Pagination Class Initialized
INFO - 2025-03-17 23:05:41 --> Controller Class Initialized
DEBUG - 2025-03-17 23:05:41 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:05:41 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:05:41 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:05:41 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:05:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:05:41 --> Model Class Initialized
ERROR - 2025-03-17 23:05:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:05:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase_detail.php
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:05:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:05:41 --> Final output sent to browser
DEBUG - 2025-03-17 23:05:41 --> Total execution time: 0.2000
INFO - 2025-03-17 23:05:47 --> Config Class Initialized
INFO - 2025-03-17 23:05:47 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:05:47 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:05:47 --> Utf8 Class Initialized
INFO - 2025-03-17 23:05:47 --> URI Class Initialized
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:05:47 --> Router Class Initialized
INFO - 2025-03-17 23:05:47 --> Output Class Initialized
INFO - 2025-03-17 23:05:47 --> Security Class Initialized
DEBUG - 2025-03-17 23:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:05:47 --> Input Class Initialized
INFO - 2025-03-17 23:05:47 --> Language Class Initialized
INFO - 2025-03-17 23:05:47 --> Language Class Initialized
INFO - 2025-03-17 23:05:47 --> Config Class Initialized
INFO - 2025-03-17 23:05:47 --> Loader Class Initialized
INFO - 2025-03-17 23:05:47 --> Helper loaded: url_helper
INFO - 2025-03-17 23:05:47 --> Helper loaded: file_helper
INFO - 2025-03-17 23:05:47 --> Helper loaded: html_helper
INFO - 2025-03-17 23:05:47 --> Helper loaded: form_helper
INFO - 2025-03-17 23:05:47 --> Helper loaded: text_helper
INFO - 2025-03-17 23:05:47 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:05:47 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:05:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:05:47 --> Database Driver Class Initialized
INFO - 2025-03-17 23:05:47 --> Email Class Initialized
INFO - 2025-03-17 23:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:05:47 --> Form Validation Class Initialized
INFO - 2025-03-17 23:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:05:47 --> Pagination Class Initialized
INFO - 2025-03-17 23:05:47 --> Controller Class Initialized
DEBUG - 2025-03-17 23:05:47 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:05:47 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:05:47 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:05:47 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:05:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:05:47 --> Model Class Initialized
ERROR - 2025-03-17 23:05:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:05:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:05:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:05:47 --> Final output sent to browser
DEBUG - 2025-03-17 23:05:47 --> Total execution time: 0.1156
INFO - 2025-03-17 23:05:48 --> Config Class Initialized
INFO - 2025-03-17 23:05:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:05:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:05:48 --> Utf8 Class Initialized
INFO - 2025-03-17 23:05:48 --> URI Class Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:05:48 --> Router Class Initialized
INFO - 2025-03-17 23:05:48 --> Output Class Initialized
INFO - 2025-03-17 23:05:48 --> Security Class Initialized
DEBUG - 2025-03-17 23:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:05:48 --> Input Class Initialized
INFO - 2025-03-17 23:05:48 --> Language Class Initialized
INFO - 2025-03-17 23:05:48 --> Language Class Initialized
INFO - 2025-03-17 23:05:48 --> Config Class Initialized
INFO - 2025-03-17 23:05:48 --> Loader Class Initialized
INFO - 2025-03-17 23:05:48 --> Helper loaded: url_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: file_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: html_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: form_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: text_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:05:48 --> Database Driver Class Initialized
INFO - 2025-03-17 23:05:48 --> Email Class Initialized
INFO - 2025-03-17 23:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:05:48 --> Form Validation Class Initialized
INFO - 2025-03-17 23:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:05:48 --> Pagination Class Initialized
INFO - 2025-03-17 23:05:48 --> Controller Class Initialized
DEBUG - 2025-03-17 23:05:48 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:05:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:05:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:05:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:05:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:05:48 --> Model Class Initialized
ERROR - 2025-03-17 23:05:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:05:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:05:48 --> Final output sent to browser
DEBUG - 2025-03-17 23:05:48 --> Total execution time: 0.1600
INFO - 2025-03-17 23:05:48 --> Config Class Initialized
INFO - 2025-03-17 23:05:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:05:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:05:48 --> Utf8 Class Initialized
INFO - 2025-03-17 23:05:48 --> URI Class Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-17 23:05:48 --> Router Class Initialized
INFO - 2025-03-17 23:05:48 --> Output Class Initialized
INFO - 2025-03-17 23:05:48 --> Security Class Initialized
DEBUG - 2025-03-17 23:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:05:48 --> Input Class Initialized
INFO - 2025-03-17 23:05:48 --> Language Class Initialized
INFO - 2025-03-17 23:05:48 --> Language Class Initialized
INFO - 2025-03-17 23:05:48 --> Config Class Initialized
INFO - 2025-03-17 23:05:48 --> Loader Class Initialized
INFO - 2025-03-17 23:05:48 --> Helper loaded: url_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: file_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: html_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: form_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: text_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:05:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:05:48 --> Database Driver Class Initialized
INFO - 2025-03-17 23:05:48 --> Email Class Initialized
INFO - 2025-03-17 23:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:05:48 --> Form Validation Class Initialized
INFO - 2025-03-17 23:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:05:48 --> Pagination Class Initialized
INFO - 2025-03-17 23:05:48 --> Controller Class Initialized
DEBUG - 2025-03-17 23:05:48 --> Purchase MX_Controller Initialized
INFO - 2025-03-17 23:05:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-17 23:05:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:05:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:05:48 --> Model Class Initialized
INFO - 2025-03-17 23:05:48 --> Final output sent to browser
DEBUG - 2025-03-17 23:05:48 --> Total execution time: 0.0731
INFO - 2025-03-17 23:06:06 --> Config Class Initialized
INFO - 2025-03-17 23:06:06 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:06 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:06 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:06 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:06 --> Router Class Initialized
INFO - 2025-03-17 23:06:06 --> Output Class Initialized
INFO - 2025-03-17 23:06:06 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:06 --> Input Class Initialized
INFO - 2025-03-17 23:06:06 --> Language Class Initialized
INFO - 2025-03-17 23:06:06 --> Language Class Initialized
INFO - 2025-03-17 23:06:06 --> Config Class Initialized
INFO - 2025-03-17 23:06:06 --> Loader Class Initialized
INFO - 2025-03-17 23:06:06 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:06 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:06 --> Email Class Initialized
INFO - 2025-03-17 23:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:06 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:06 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:06 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:06 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:06 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:06 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:06:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:06:06 --> Model Class Initialized
ERROR - 2025-03-17 23:06:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:06:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:06:06 --> Final output sent to browser
DEBUG - 2025-03-17 23:06:06 --> Total execution time: 0.1591
INFO - 2025-03-17 23:06:06 --> Config Class Initialized
INFO - 2025-03-17 23:06:06 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:06 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:06 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:06 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:06 --> Router Class Initialized
INFO - 2025-03-17 23:06:06 --> Output Class Initialized
INFO - 2025-03-17 23:06:06 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:06 --> Input Class Initialized
INFO - 2025-03-17 23:06:06 --> Language Class Initialized
INFO - 2025-03-17 23:06:06 --> Language Class Initialized
INFO - 2025-03-17 23:06:06 --> Config Class Initialized
INFO - 2025-03-17 23:06:06 --> Loader Class Initialized
INFO - 2025-03-17 23:06:06 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:06 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:06 --> Email Class Initialized
INFO - 2025-03-17 23:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:06 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:06 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:06 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:06 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:06 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:06 --> Model Class Initialized
INFO - 2025-03-17 23:06:06 --> Final output sent to browser
DEBUG - 2025-03-17 23:06:06 --> Total execution time: 0.0233
INFO - 2025-03-17 23:06:13 --> Config Class Initialized
INFO - 2025-03-17 23:06:13 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:13 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:13 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:13 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:13 --> Router Class Initialized
INFO - 2025-03-17 23:06:13 --> Output Class Initialized
INFO - 2025-03-17 23:06:13 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:13 --> Input Class Initialized
INFO - 2025-03-17 23:06:13 --> Language Class Initialized
INFO - 2025-03-17 23:06:13 --> Language Class Initialized
INFO - 2025-03-17 23:06:13 --> Config Class Initialized
INFO - 2025-03-17 23:06:13 --> Loader Class Initialized
INFO - 2025-03-17 23:06:13 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:13 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:13 --> Email Class Initialized
INFO - 2025-03-17 23:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:13 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:13 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:13 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:13 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:13 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:13 --> Model Class Initialized
INFO - 2025-03-17 23:06:13 --> Config Class Initialized
INFO - 2025-03-17 23:06:13 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:13 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:13 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:13 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:13 --> Router Class Initialized
INFO - 2025-03-17 23:06:13 --> Output Class Initialized
INFO - 2025-03-17 23:06:13 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:13 --> Input Class Initialized
INFO - 2025-03-17 23:06:13 --> Language Class Initialized
INFO - 2025-03-17 23:06:13 --> Language Class Initialized
INFO - 2025-03-17 23:06:13 --> Config Class Initialized
INFO - 2025-03-17 23:06:13 --> Loader Class Initialized
INFO - 2025-03-17 23:06:13 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:13 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:13 --> Email Class Initialized
INFO - 2025-03-17 23:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:13 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:13 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:13 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:13 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:13 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:13 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:06:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:06:13 --> Model Class Initialized
ERROR - 2025-03-17 23:06:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:06:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:06:13 --> Final output sent to browser
DEBUG - 2025-03-17 23:06:13 --> Total execution time: 0.1377
INFO - 2025-03-17 23:06:14 --> Config Class Initialized
INFO - 2025-03-17 23:06:14 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:14 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:14 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:14 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:14 --> Router Class Initialized
INFO - 2025-03-17 23:06:14 --> Output Class Initialized
INFO - 2025-03-17 23:06:14 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:14 --> Input Class Initialized
INFO - 2025-03-17 23:06:14 --> Language Class Initialized
INFO - 2025-03-17 23:06:14 --> Language Class Initialized
INFO - 2025-03-17 23:06:14 --> Config Class Initialized
INFO - 2025-03-17 23:06:14 --> Loader Class Initialized
INFO - 2025-03-17 23:06:14 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:14 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:14 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:14 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:14 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:14 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:14 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:14 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:14 --> Email Class Initialized
INFO - 2025-03-17 23:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:14 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:14 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:14 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:14 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:14 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:14 --> Model Class Initialized
INFO - 2025-03-17 23:06:14 --> Final output sent to browser
DEBUG - 2025-03-17 23:06:14 --> Total execution time: 0.0153
INFO - 2025-03-17 23:06:48 --> Config Class Initialized
INFO - 2025-03-17 23:06:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:48 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:48 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:48 --> Router Class Initialized
INFO - 2025-03-17 23:06:48 --> Output Class Initialized
INFO - 2025-03-17 23:06:48 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:48 --> Input Class Initialized
INFO - 2025-03-17 23:06:48 --> Language Class Initialized
INFO - 2025-03-17 23:06:48 --> Language Class Initialized
INFO - 2025-03-17 23:06:48 --> Config Class Initialized
INFO - 2025-03-17 23:06:48 --> Loader Class Initialized
INFO - 2025-03-17 23:06:48 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:48 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:48 --> Email Class Initialized
INFO - 2025-03-17 23:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:48 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:48 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:48 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:48 --> Model Class Initialized
INFO - 2025-03-17 23:06:48 --> Config Class Initialized
INFO - 2025-03-17 23:06:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:48 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:48 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:48 --> Router Class Initialized
INFO - 2025-03-17 23:06:48 --> Output Class Initialized
INFO - 2025-03-17 23:06:48 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:48 --> Input Class Initialized
INFO - 2025-03-17 23:06:48 --> Language Class Initialized
INFO - 2025-03-17 23:06:48 --> Language Class Initialized
INFO - 2025-03-17 23:06:48 --> Config Class Initialized
INFO - 2025-03-17 23:06:48 --> Loader Class Initialized
INFO - 2025-03-17 23:06:48 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:48 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:48 --> Email Class Initialized
INFO - 2025-03-17 23:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:48 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:48 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:48 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-17 23:06:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-17 23:06:48 --> Model Class Initialized
ERROR - 2025-03-17 23:06:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-17 23:06:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/voucher_approve.php
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-17 23:06:48 --> Final output sent to browser
DEBUG - 2025-03-17 23:06:48 --> Total execution time: 0.1769
INFO - 2025-03-17 23:06:48 --> Config Class Initialized
INFO - 2025-03-17 23:06:48 --> Hooks Class Initialized
DEBUG - 2025-03-17 23:06:48 --> UTF-8 Support Enabled
INFO - 2025-03-17 23:06:48 --> Utf8 Class Initialized
INFO - 2025-03-17 23:06:48 --> URI Class Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-17 23:06:48 --> Router Class Initialized
INFO - 2025-03-17 23:06:48 --> Output Class Initialized
INFO - 2025-03-17 23:06:48 --> Security Class Initialized
DEBUG - 2025-03-17 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-17 23:06:48 --> Input Class Initialized
INFO - 2025-03-17 23:06:48 --> Language Class Initialized
INFO - 2025-03-17 23:06:48 --> Language Class Initialized
INFO - 2025-03-17 23:06:48 --> Config Class Initialized
INFO - 2025-03-17 23:06:48 --> Loader Class Initialized
INFO - 2025-03-17 23:06:48 --> Helper loaded: url_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: file_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: html_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: form_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: text_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: lang_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: directory_helper
INFO - 2025-03-17 23:06:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-17 23:06:48 --> Database Driver Class Initialized
INFO - 2025-03-17 23:06:48 --> Email Class Initialized
INFO - 2025-03-17 23:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-17 23:06:48 --> Form Validation Class Initialized
INFO - 2025-03-17 23:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-17 23:06:48 --> Pagination Class Initialized
INFO - 2025-03-17 23:06:48 --> Controller Class Initialized
DEBUG - 2025-03-17 23:06:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-17 23:06:48 --> Model Class Initialized
DEBUG - 2025-03-17 23:06:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-17 23:06:48 --> Model Class Initialized
INFO - 2025-03-17 23:06:48 --> Final output sent to browser
DEBUG - 2025-03-17 23:06:48 --> Total execution time: 0.0163
