<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-03 19:23:29 --> Config Class Initialized
INFO - 2025-04-03 19:23:29 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:23:29 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:23:29 --> Utf8 Class Initialized
INFO - 2025-04-03 19:23:29 --> URI Class Initialized
DEBUG - 2025-04-03 19:23:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-03 19:23:29 --> No URI present. Default controller set.
INFO - 2025-04-03 19:23:29 --> Router Class Initialized
INFO - 2025-04-03 19:23:29 --> Output Class Initialized
INFO - 2025-04-03 19:23:29 --> Security Class Initialized
DEBUG - 2025-04-03 19:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:23:29 --> Input Class Initialized
INFO - 2025-04-03 19:23:29 --> Language Class Initialized
INFO - 2025-04-03 19:23:29 --> Language Class Initialized
INFO - 2025-04-03 19:23:29 --> Config Class Initialized
INFO - 2025-04-03 19:23:29 --> Loader Class Initialized
INFO - 2025-04-03 19:23:29 --> Helper loaded: url_helper
INFO - 2025-04-03 19:23:29 --> Helper loaded: file_helper
INFO - 2025-04-03 19:23:29 --> Helper loaded: html_helper
INFO - 2025-04-03 19:23:29 --> Helper loaded: form_helper
INFO - 2025-04-03 19:23:29 --> Helper loaded: text_helper
INFO - 2025-04-03 19:23:29 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:23:29 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:23:29 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:23:29 --> Database Driver Class Initialized
INFO - 2025-04-03 19:23:29 --> Email Class Initialized
INFO - 2025-04-03 19:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:23:29 --> Form Validation Class Initialized
INFO - 2025-04-03 19:23:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:23:29 --> Pagination Class Initialized
INFO - 2025-04-03 19:23:29 --> Controller Class Initialized
DEBUG - 2025-04-03 19:23:29 --> Auth MX_Controller Initialized
INFO - 2025-04-03 19:23:29 --> Model Class Initialized
DEBUG - 2025-04-03 19:23:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-03 19:23:29 --> Model Class Initialized
DEBUG - 2025-04-03 19:23:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:23:29 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:23:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:23:29 --> Model Class Initialized
DEBUG - 2025-04-03 19:23:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-03 19:23:29 --> Final output sent to browser
DEBUG - 2025-04-03 19:23:29 --> Total execution time: 0.0535
INFO - 2025-04-03 19:24:33 --> Config Class Initialized
INFO - 2025-04-03 19:24:33 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:24:33 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:24:33 --> Utf8 Class Initialized
INFO - 2025-04-03 19:24:33 --> URI Class Initialized
DEBUG - 2025-04-03 19:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-03 19:24:33 --> Router Class Initialized
INFO - 2025-04-03 19:24:33 --> Output Class Initialized
INFO - 2025-04-03 19:24:33 --> Security Class Initialized
DEBUG - 2025-04-03 19:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:24:33 --> Input Class Initialized
INFO - 2025-04-03 19:24:33 --> Language Class Initialized
INFO - 2025-04-03 19:24:33 --> Language Class Initialized
INFO - 2025-04-03 19:24:33 --> Config Class Initialized
INFO - 2025-04-03 19:24:33 --> Loader Class Initialized
INFO - 2025-04-03 19:24:33 --> Helper loaded: url_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: file_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: html_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: form_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: text_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:24:33 --> Database Driver Class Initialized
INFO - 2025-04-03 19:24:33 --> Email Class Initialized
INFO - 2025-04-03 19:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:24:33 --> Form Validation Class Initialized
INFO - 2025-04-03 19:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:24:33 --> Pagination Class Initialized
INFO - 2025-04-03 19:24:33 --> Controller Class Initialized
DEBUG - 2025-04-03 19:24:33 --> Auth MX_Controller Initialized
INFO - 2025-04-03 19:24:33 --> Model Class Initialized
DEBUG - 2025-04-03 19:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-03 19:24:33 --> Model Class Initialized
INFO - 2025-04-03 19:24:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 19:24:33 --> Config Class Initialized
INFO - 2025-04-03 19:24:33 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:24:33 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:24:33 --> Utf8 Class Initialized
INFO - 2025-04-03 19:24:33 --> URI Class Initialized
DEBUG - 2025-04-03 19:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-03 19:24:33 --> Router Class Initialized
INFO - 2025-04-03 19:24:33 --> Output Class Initialized
INFO - 2025-04-03 19:24:33 --> Security Class Initialized
DEBUG - 2025-04-03 19:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:24:33 --> Input Class Initialized
INFO - 2025-04-03 19:24:33 --> Language Class Initialized
INFO - 2025-04-03 19:24:33 --> Language Class Initialized
INFO - 2025-04-03 19:24:33 --> Config Class Initialized
INFO - 2025-04-03 19:24:33 --> Loader Class Initialized
INFO - 2025-04-03 19:24:33 --> Helper loaded: url_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: file_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: html_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: form_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: text_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:24:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:24:33 --> Database Driver Class Initialized
INFO - 2025-04-03 19:24:33 --> Email Class Initialized
INFO - 2025-04-03 19:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:24:33 --> Form Validation Class Initialized
INFO - 2025-04-03 19:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:24:33 --> Pagination Class Initialized
INFO - 2025-04-03 19:24:33 --> Controller Class Initialized
DEBUG - 2025-04-03 19:24:33 --> Home MX_Controller Initialized
INFO - 2025-04-03 19:24:33 --> Model Class Initialized
DEBUG - 2025-04-03 19:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-03 19:24:33 --> Model Class Initialized
DEBUG - 2025-04-03 19:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:24:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:24:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:24:33 --> Model Class Initialized
ERROR - 2025-04-03 19:24:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:24:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:24:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:24:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:24:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:24:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:24:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-03 19:24:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:24:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:24:34 --> Final output sent to browser
DEBUG - 2025-04-03 19:24:34 --> Total execution time: 1.1104
INFO - 2025-04-03 19:25:49 --> Config Class Initialized
INFO - 2025-04-03 19:25:49 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:25:49 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:25:49 --> Utf8 Class Initialized
INFO - 2025-04-03 19:25:49 --> URI Class Initialized
DEBUG - 2025-04-03 19:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:25:49 --> Router Class Initialized
INFO - 2025-04-03 19:25:49 --> Output Class Initialized
INFO - 2025-04-03 19:25:49 --> Security Class Initialized
DEBUG - 2025-04-03 19:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:25:49 --> Input Class Initialized
INFO - 2025-04-03 19:25:49 --> Language Class Initialized
INFO - 2025-04-03 19:25:49 --> Language Class Initialized
INFO - 2025-04-03 19:25:49 --> Config Class Initialized
INFO - 2025-04-03 19:25:49 --> Loader Class Initialized
INFO - 2025-04-03 19:25:49 --> Helper loaded: url_helper
INFO - 2025-04-03 19:25:49 --> Helper loaded: file_helper
INFO - 2025-04-03 19:25:49 --> Helper loaded: html_helper
INFO - 2025-04-03 19:25:49 --> Helper loaded: form_helper
INFO - 2025-04-03 19:25:49 --> Helper loaded: text_helper
INFO - 2025-04-03 19:25:49 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:25:49 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:25:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:25:49 --> Database Driver Class Initialized
INFO - 2025-04-03 19:25:49 --> Email Class Initialized
INFO - 2025-04-03 19:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:25:49 --> Form Validation Class Initialized
INFO - 2025-04-03 19:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:25:49 --> Pagination Class Initialized
INFO - 2025-04-03 19:25:49 --> Controller Class Initialized
DEBUG - 2025-04-03 19:25:49 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:25:54 --> Config Class Initialized
INFO - 2025-04-03 19:25:54 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:25:54 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:25:54 --> Utf8 Class Initialized
INFO - 2025-04-03 19:25:54 --> URI Class Initialized
DEBUG - 2025-04-03 19:25:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:25:54 --> Router Class Initialized
INFO - 2025-04-03 19:25:54 --> Output Class Initialized
INFO - 2025-04-03 19:25:54 --> Security Class Initialized
DEBUG - 2025-04-03 19:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:25:54 --> Input Class Initialized
INFO - 2025-04-03 19:25:54 --> Language Class Initialized
INFO - 2025-04-03 19:25:54 --> Language Class Initialized
INFO - 2025-04-03 19:25:54 --> Config Class Initialized
INFO - 2025-04-03 19:25:54 --> Loader Class Initialized
INFO - 2025-04-03 19:25:54 --> Helper loaded: url_helper
INFO - 2025-04-03 19:25:54 --> Helper loaded: file_helper
INFO - 2025-04-03 19:25:54 --> Helper loaded: html_helper
INFO - 2025-04-03 19:25:54 --> Helper loaded: form_helper
INFO - 2025-04-03 19:25:54 --> Helper loaded: text_helper
INFO - 2025-04-03 19:25:54 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:25:54 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:25:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:25:54 --> Database Driver Class Initialized
INFO - 2025-04-03 19:25:54 --> Email Class Initialized
INFO - 2025-04-03 19:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:25:54 --> Form Validation Class Initialized
INFO - 2025-04-03 19:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:25:54 --> Pagination Class Initialized
INFO - 2025-04-03 19:25:54 --> Controller Class Initialized
DEBUG - 2025-04-03 19:25:54 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:25:55 --> Config Class Initialized
INFO - 2025-04-03 19:25:55 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:25:55 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:25:55 --> Utf8 Class Initialized
INFO - 2025-04-03 19:25:55 --> URI Class Initialized
DEBUG - 2025-04-03 19:25:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:25:55 --> Router Class Initialized
INFO - 2025-04-03 19:25:55 --> Output Class Initialized
INFO - 2025-04-03 19:25:55 --> Security Class Initialized
DEBUG - 2025-04-03 19:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:25:55 --> Input Class Initialized
INFO - 2025-04-03 19:25:55 --> Language Class Initialized
INFO - 2025-04-03 19:25:55 --> Language Class Initialized
INFO - 2025-04-03 19:25:55 --> Config Class Initialized
INFO - 2025-04-03 19:25:55 --> Loader Class Initialized
INFO - 2025-04-03 19:25:55 --> Helper loaded: url_helper
INFO - 2025-04-03 19:25:55 --> Helper loaded: file_helper
INFO - 2025-04-03 19:25:55 --> Helper loaded: html_helper
INFO - 2025-04-03 19:25:55 --> Helper loaded: form_helper
INFO - 2025-04-03 19:25:55 --> Helper loaded: text_helper
INFO - 2025-04-03 19:25:55 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:25:55 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:25:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:25:55 --> Database Driver Class Initialized
INFO - 2025-04-03 19:25:55 --> Email Class Initialized
INFO - 2025-04-03 19:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:25:55 --> Form Validation Class Initialized
INFO - 2025-04-03 19:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:25:55 --> Pagination Class Initialized
INFO - 2025-04-03 19:25:55 --> Controller Class Initialized
DEBUG - 2025-04-03 19:25:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:25:57 --> Config Class Initialized
INFO - 2025-04-03 19:25:57 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:25:57 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:25:57 --> Utf8 Class Initialized
INFO - 2025-04-03 19:25:57 --> URI Class Initialized
DEBUG - 2025-04-03 19:25:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:25:57 --> Router Class Initialized
INFO - 2025-04-03 19:25:57 --> Output Class Initialized
INFO - 2025-04-03 19:25:57 --> Security Class Initialized
DEBUG - 2025-04-03 19:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:25:57 --> Input Class Initialized
INFO - 2025-04-03 19:25:57 --> Language Class Initialized
INFO - 2025-04-03 19:25:57 --> Language Class Initialized
INFO - 2025-04-03 19:25:57 --> Config Class Initialized
INFO - 2025-04-03 19:25:57 --> Loader Class Initialized
INFO - 2025-04-03 19:25:57 --> Helper loaded: url_helper
INFO - 2025-04-03 19:25:57 --> Helper loaded: file_helper
INFO - 2025-04-03 19:25:57 --> Helper loaded: html_helper
INFO - 2025-04-03 19:25:57 --> Helper loaded: form_helper
INFO - 2025-04-03 19:25:57 --> Helper loaded: text_helper
INFO - 2025-04-03 19:25:57 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:25:57 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:25:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:25:57 --> Database Driver Class Initialized
INFO - 2025-04-03 19:25:57 --> Email Class Initialized
INFO - 2025-04-03 19:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:25:57 --> Form Validation Class Initialized
INFO - 2025-04-03 19:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:25:57 --> Pagination Class Initialized
INFO - 2025-04-03 19:25:57 --> Controller Class Initialized
DEBUG - 2025-04-03 19:25:57 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:25:58 --> Config Class Initialized
INFO - 2025-04-03 19:25:58 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:25:58 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:25:58 --> Utf8 Class Initialized
INFO - 2025-04-03 19:25:58 --> URI Class Initialized
DEBUG - 2025-04-03 19:25:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:25:58 --> Router Class Initialized
INFO - 2025-04-03 19:25:58 --> Output Class Initialized
INFO - 2025-04-03 19:25:58 --> Security Class Initialized
DEBUG - 2025-04-03 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:25:58 --> Input Class Initialized
INFO - 2025-04-03 19:25:58 --> Language Class Initialized
INFO - 2025-04-03 19:25:58 --> Language Class Initialized
INFO - 2025-04-03 19:25:58 --> Config Class Initialized
INFO - 2025-04-03 19:25:58 --> Loader Class Initialized
INFO - 2025-04-03 19:25:58 --> Helper loaded: url_helper
INFO - 2025-04-03 19:25:58 --> Helper loaded: file_helper
INFO - 2025-04-03 19:25:58 --> Helper loaded: html_helper
INFO - 2025-04-03 19:25:58 --> Helper loaded: form_helper
INFO - 2025-04-03 19:25:58 --> Helper loaded: text_helper
INFO - 2025-04-03 19:25:58 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:25:58 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:25:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:25:58 --> Database Driver Class Initialized
INFO - 2025-04-03 19:25:58 --> Email Class Initialized
INFO - 2025-04-03 19:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:25:58 --> Form Validation Class Initialized
INFO - 2025-04-03 19:25:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:25:58 --> Pagination Class Initialized
INFO - 2025-04-03 19:25:58 --> Controller Class Initialized
DEBUG - 2025-04-03 19:25:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:26:38 --> Config Class Initialized
INFO - 2025-04-03 19:26:38 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:26:38 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:26:38 --> Utf8 Class Initialized
INFO - 2025-04-03 19:26:38 --> URI Class Initialized
DEBUG - 2025-04-03 19:26:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:26:38 --> Router Class Initialized
INFO - 2025-04-03 19:26:38 --> Output Class Initialized
INFO - 2025-04-03 19:26:38 --> Security Class Initialized
DEBUG - 2025-04-03 19:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:26:38 --> Input Class Initialized
INFO - 2025-04-03 19:26:38 --> Language Class Initialized
INFO - 2025-04-03 19:26:38 --> Language Class Initialized
INFO - 2025-04-03 19:26:38 --> Config Class Initialized
INFO - 2025-04-03 19:26:38 --> Loader Class Initialized
INFO - 2025-04-03 19:26:38 --> Helper loaded: url_helper
INFO - 2025-04-03 19:26:38 --> Helper loaded: file_helper
INFO - 2025-04-03 19:26:38 --> Helper loaded: html_helper
INFO - 2025-04-03 19:26:38 --> Helper loaded: form_helper
INFO - 2025-04-03 19:26:38 --> Helper loaded: text_helper
INFO - 2025-04-03 19:26:38 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:26:38 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:26:38 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:26:38 --> Database Driver Class Initialized
INFO - 2025-04-03 19:26:38 --> Email Class Initialized
INFO - 2025-04-03 19:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:26:38 --> Form Validation Class Initialized
INFO - 2025-04-03 19:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:26:38 --> Pagination Class Initialized
INFO - 2025-04-03 19:26:38 --> Controller Class Initialized
DEBUG - 2025-04-03 19:26:38 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:26:43 --> Config Class Initialized
INFO - 2025-04-03 19:26:43 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:26:43 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:26:43 --> Utf8 Class Initialized
INFO - 2025-04-03 19:26:43 --> URI Class Initialized
DEBUG - 2025-04-03 19:26:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:26:43 --> Router Class Initialized
INFO - 2025-04-03 19:26:43 --> Output Class Initialized
INFO - 2025-04-03 19:26:43 --> Security Class Initialized
DEBUG - 2025-04-03 19:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:26:43 --> Input Class Initialized
INFO - 2025-04-03 19:26:43 --> Language Class Initialized
INFO - 2025-04-03 19:26:43 --> Language Class Initialized
INFO - 2025-04-03 19:26:43 --> Config Class Initialized
INFO - 2025-04-03 19:26:43 --> Loader Class Initialized
INFO - 2025-04-03 19:26:43 --> Helper loaded: url_helper
INFO - 2025-04-03 19:26:43 --> Helper loaded: file_helper
INFO - 2025-04-03 19:26:43 --> Helper loaded: html_helper
INFO - 2025-04-03 19:26:43 --> Helper loaded: form_helper
INFO - 2025-04-03 19:26:43 --> Helper loaded: text_helper
INFO - 2025-04-03 19:26:43 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:26:43 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:26:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:26:43 --> Database Driver Class Initialized
INFO - 2025-04-03 19:26:43 --> Email Class Initialized
INFO - 2025-04-03 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:26:43 --> Form Validation Class Initialized
INFO - 2025-04-03 19:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:26:43 --> Pagination Class Initialized
INFO - 2025-04-03 19:26:43 --> Controller Class Initialized
DEBUG - 2025-04-03 19:26:43 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:26:49 --> Config Class Initialized
INFO - 2025-04-03 19:26:49 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:26:49 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:26:49 --> Utf8 Class Initialized
INFO - 2025-04-03 19:26:49 --> URI Class Initialized
DEBUG - 2025-04-03 19:26:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:26:49 --> Router Class Initialized
INFO - 2025-04-03 19:26:49 --> Output Class Initialized
INFO - 2025-04-03 19:26:49 --> Security Class Initialized
DEBUG - 2025-04-03 19:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:26:49 --> Input Class Initialized
INFO - 2025-04-03 19:26:49 --> Language Class Initialized
INFO - 2025-04-03 19:26:49 --> Language Class Initialized
INFO - 2025-04-03 19:26:49 --> Config Class Initialized
INFO - 2025-04-03 19:26:49 --> Loader Class Initialized
INFO - 2025-04-03 19:26:49 --> Helper loaded: url_helper
INFO - 2025-04-03 19:26:49 --> Helper loaded: file_helper
INFO - 2025-04-03 19:26:49 --> Helper loaded: html_helper
INFO - 2025-04-03 19:26:49 --> Helper loaded: form_helper
INFO - 2025-04-03 19:26:49 --> Helper loaded: text_helper
INFO - 2025-04-03 19:26:49 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:26:49 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:26:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:26:49 --> Database Driver Class Initialized
INFO - 2025-04-03 19:26:49 --> Email Class Initialized
INFO - 2025-04-03 19:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:26:49 --> Form Validation Class Initialized
INFO - 2025-04-03 19:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:26:49 --> Pagination Class Initialized
INFO - 2025-04-03 19:26:49 --> Controller Class Initialized
DEBUG - 2025-04-03 19:26:49 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:26:52 --> Config Class Initialized
INFO - 2025-04-03 19:26:52 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:26:52 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:26:52 --> Utf8 Class Initialized
INFO - 2025-04-03 19:26:52 --> URI Class Initialized
DEBUG - 2025-04-03 19:26:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:26:52 --> Router Class Initialized
INFO - 2025-04-03 19:26:52 --> Output Class Initialized
INFO - 2025-04-03 19:26:52 --> Security Class Initialized
DEBUG - 2025-04-03 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:26:52 --> Input Class Initialized
INFO - 2025-04-03 19:26:52 --> Language Class Initialized
INFO - 2025-04-03 19:26:52 --> Language Class Initialized
INFO - 2025-04-03 19:26:52 --> Config Class Initialized
INFO - 2025-04-03 19:26:52 --> Loader Class Initialized
INFO - 2025-04-03 19:26:52 --> Helper loaded: url_helper
INFO - 2025-04-03 19:26:52 --> Helper loaded: file_helper
INFO - 2025-04-03 19:26:52 --> Helper loaded: html_helper
INFO - 2025-04-03 19:26:52 --> Helper loaded: form_helper
INFO - 2025-04-03 19:26:52 --> Helper loaded: text_helper
INFO - 2025-04-03 19:26:52 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:26:52 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:26:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:26:52 --> Database Driver Class Initialized
INFO - 2025-04-03 19:26:52 --> Email Class Initialized
INFO - 2025-04-03 19:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:26:52 --> Form Validation Class Initialized
INFO - 2025-04-03 19:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:26:52 --> Pagination Class Initialized
INFO - 2025-04-03 19:26:52 --> Controller Class Initialized
DEBUG - 2025-04-03 19:26:52 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:27:11 --> Config Class Initialized
INFO - 2025-04-03 19:27:11 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:11 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:11 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:11 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:27:11 --> Router Class Initialized
INFO - 2025-04-03 19:27:11 --> Output Class Initialized
INFO - 2025-04-03 19:27:11 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:11 --> Input Class Initialized
INFO - 2025-04-03 19:27:11 --> Language Class Initialized
INFO - 2025-04-03 19:27:11 --> Language Class Initialized
INFO - 2025-04-03 19:27:11 --> Config Class Initialized
INFO - 2025-04-03 19:27:11 --> Loader Class Initialized
INFO - 2025-04-03 19:27:11 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:11 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:11 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:11 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:11 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:11 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:11 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:11 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:11 --> Email Class Initialized
INFO - 2025-04-03 19:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:11 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:11 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:11 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:11 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:27:14 --> Config Class Initialized
INFO - 2025-04-03 19:27:14 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:14 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:14 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:14 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:27:14 --> Router Class Initialized
INFO - 2025-04-03 19:27:14 --> Output Class Initialized
INFO - 2025-04-03 19:27:14 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:14 --> Input Class Initialized
INFO - 2025-04-03 19:27:14 --> Language Class Initialized
INFO - 2025-04-03 19:27:14 --> Language Class Initialized
INFO - 2025-04-03 19:27:14 --> Config Class Initialized
INFO - 2025-04-03 19:27:14 --> Loader Class Initialized
INFO - 2025-04-03 19:27:14 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:14 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:14 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:14 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:14 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:14 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:14 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:14 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:14 --> Email Class Initialized
INFO - 2025-04-03 19:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:14 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:14 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:14 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:14 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:27:19 --> Config Class Initialized
INFO - 2025-04-03 19:27:19 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:19 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:19 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:19 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:27:19 --> Router Class Initialized
INFO - 2025-04-03 19:27:19 --> Output Class Initialized
INFO - 2025-04-03 19:27:19 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:19 --> Input Class Initialized
INFO - 2025-04-03 19:27:19 --> Language Class Initialized
INFO - 2025-04-03 19:27:19 --> Language Class Initialized
INFO - 2025-04-03 19:27:19 --> Config Class Initialized
INFO - 2025-04-03 19:27:19 --> Loader Class Initialized
INFO - 2025-04-03 19:27:19 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:19 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:19 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:19 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:19 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:19 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:19 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:19 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:19 --> Email Class Initialized
INFO - 2025-04-03 19:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:19 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:19 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:19 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:19 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:27:20 --> Config Class Initialized
INFO - 2025-04-03 19:27:20 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:20 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:20 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:20 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:27:20 --> Router Class Initialized
INFO - 2025-04-03 19:27:20 --> Output Class Initialized
INFO - 2025-04-03 19:27:20 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:20 --> Input Class Initialized
INFO - 2025-04-03 19:27:20 --> Language Class Initialized
INFO - 2025-04-03 19:27:20 --> Language Class Initialized
INFO - 2025-04-03 19:27:20 --> Config Class Initialized
INFO - 2025-04-03 19:27:20 --> Loader Class Initialized
INFO - 2025-04-03 19:27:20 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:20 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:20 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:20 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:20 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:20 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:20 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:20 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:20 --> Email Class Initialized
INFO - 2025-04-03 19:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:20 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:20 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:20 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:27:37 --> Config Class Initialized
INFO - 2025-04-03 19:27:37 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:37 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:37 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:37 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:27:37 --> Router Class Initialized
INFO - 2025-04-03 19:27:37 --> Output Class Initialized
INFO - 2025-04-03 19:27:37 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:37 --> Input Class Initialized
INFO - 2025-04-03 19:27:37 --> Language Class Initialized
INFO - 2025-04-03 19:27:37 --> Language Class Initialized
INFO - 2025-04-03 19:27:37 --> Config Class Initialized
INFO - 2025-04-03 19:27:37 --> Loader Class Initialized
INFO - 2025-04-03 19:27:37 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:37 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:37 --> Email Class Initialized
INFO - 2025-04-03 19:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:37 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:37 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:37 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:37 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:27:37 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:27:37 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:27:37 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:27:37 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:27:37 --> Model Class Initialized
ERROR - 2025-04-03 19:27:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:27:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:27:37 --> Final output sent to browser
DEBUG - 2025-04-03 19:27:37 --> Total execution time: 0.2011
INFO - 2025-04-03 19:27:37 --> Config Class Initialized
INFO - 2025-04-03 19:27:37 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:37 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:37 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:37 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:27:37 --> Router Class Initialized
INFO - 2025-04-03 19:27:37 --> Output Class Initialized
INFO - 2025-04-03 19:27:37 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:37 --> Input Class Initialized
INFO - 2025-04-03 19:27:37 --> Language Class Initialized
INFO - 2025-04-03 19:27:37 --> Language Class Initialized
INFO - 2025-04-03 19:27:37 --> Config Class Initialized
INFO - 2025-04-03 19:27:37 --> Loader Class Initialized
INFO - 2025-04-03 19:27:37 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:37 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:37 --> Email Class Initialized
INFO - 2025-04-03 19:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:37 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:37 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:37 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:37 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:27:37 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:27:37 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:27:37 --> Model Class Initialized
INFO - 2025-04-03 19:27:37 --> Final output sent to browser
DEBUG - 2025-04-03 19:27:37 --> Total execution time: 0.0328
INFO - 2025-04-03 19:27:40 --> Config Class Initialized
INFO - 2025-04-03 19:27:40 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:40 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:40 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:40 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:27:40 --> Router Class Initialized
INFO - 2025-04-03 19:27:40 --> Output Class Initialized
INFO - 2025-04-03 19:27:40 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:40 --> Input Class Initialized
INFO - 2025-04-03 19:27:40 --> Language Class Initialized
INFO - 2025-04-03 19:27:40 --> Language Class Initialized
INFO - 2025-04-03 19:27:40 --> Config Class Initialized
INFO - 2025-04-03 19:27:40 --> Loader Class Initialized
INFO - 2025-04-03 19:27:40 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:40 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:40 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:40 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:40 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:40 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:40 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:40 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:40 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:40 --> Email Class Initialized
INFO - 2025-04-03 19:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:40 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:40 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:40 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:40 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:27:40 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:27:40 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:27:40 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:27:40 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:27:40 --> Model Class Initialized
ERROR - 2025-04-03 19:27:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:27:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:27:40 --> Final output sent to browser
DEBUG - 2025-04-03 19:27:40 --> Total execution time: 0.1982
INFO - 2025-04-03 19:27:54 --> Config Class Initialized
INFO - 2025-04-03 19:27:54 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:54 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:54 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:54 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:27:54 --> Router Class Initialized
INFO - 2025-04-03 19:27:54 --> Output Class Initialized
INFO - 2025-04-03 19:27:54 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:54 --> Input Class Initialized
INFO - 2025-04-03 19:27:54 --> Language Class Initialized
INFO - 2025-04-03 19:27:54 --> Language Class Initialized
INFO - 2025-04-03 19:27:54 --> Config Class Initialized
INFO - 2025-04-03 19:27:54 --> Loader Class Initialized
INFO - 2025-04-03 19:27:54 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:54 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:54 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:54 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:54 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:54 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:54 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:54 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:54 --> Email Class Initialized
INFO - 2025-04-03 19:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:54 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:54 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:54 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:54 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:27:54 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:27:54 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:27:54 --> Model Class Initialized
INFO - 2025-04-03 19:27:54 --> Final output sent to browser
DEBUG - 2025-04-03 19:27:54 --> Total execution time: 0.0126
INFO - 2025-04-03 19:27:56 --> Config Class Initialized
INFO - 2025-04-03 19:27:56 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:27:56 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:27:56 --> Utf8 Class Initialized
INFO - 2025-04-03 19:27:56 --> URI Class Initialized
DEBUG - 2025-04-03 19:27:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:27:56 --> Router Class Initialized
INFO - 2025-04-03 19:27:56 --> Output Class Initialized
INFO - 2025-04-03 19:27:56 --> Security Class Initialized
DEBUG - 2025-04-03 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:27:56 --> Input Class Initialized
INFO - 2025-04-03 19:27:56 --> Language Class Initialized
INFO - 2025-04-03 19:27:56 --> Language Class Initialized
INFO - 2025-04-03 19:27:56 --> Config Class Initialized
INFO - 2025-04-03 19:27:56 --> Loader Class Initialized
INFO - 2025-04-03 19:27:56 --> Helper loaded: url_helper
INFO - 2025-04-03 19:27:56 --> Helper loaded: file_helper
INFO - 2025-04-03 19:27:56 --> Helper loaded: html_helper
INFO - 2025-04-03 19:27:56 --> Helper loaded: form_helper
INFO - 2025-04-03 19:27:56 --> Helper loaded: text_helper
INFO - 2025-04-03 19:27:56 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:27:56 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:27:56 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:27:56 --> Database Driver Class Initialized
INFO - 2025-04-03 19:27:56 --> Email Class Initialized
INFO - 2025-04-03 19:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:27:56 --> Form Validation Class Initialized
INFO - 2025-04-03 19:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:27:56 --> Pagination Class Initialized
INFO - 2025-04-03 19:27:56 --> Controller Class Initialized
DEBUG - 2025-04-03 19:27:56 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:27:56 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:27:56 --> Model Class Initialized
DEBUG - 2025-04-03 19:27:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:27:56 --> Model Class Initialized
INFO - 2025-04-03 19:27:56 --> Final output sent to browser
DEBUG - 2025-04-03 19:27:56 --> Total execution time: 0.0146
INFO - 2025-04-03 19:28:01 --> Config Class Initialized
INFO - 2025-04-03 19:28:01 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:01 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:01 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:01 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:28:01 --> Router Class Initialized
INFO - 2025-04-03 19:28:01 --> Output Class Initialized
INFO - 2025-04-03 19:28:01 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:01 --> Input Class Initialized
INFO - 2025-04-03 19:28:01 --> Language Class Initialized
INFO - 2025-04-03 19:28:01 --> Language Class Initialized
INFO - 2025-04-03 19:28:01 --> Config Class Initialized
INFO - 2025-04-03 19:28:01 --> Loader Class Initialized
INFO - 2025-04-03 19:28:01 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:01 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:01 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:01 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:01 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:01 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:01 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:01 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:01 --> Email Class Initialized
INFO - 2025-04-03 19:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:01 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:01 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:01 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:01 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:28:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:28:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:28:01 --> Model Class Initialized
INFO - 2025-04-03 19:28:01 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:01 --> Total execution time: 0.0049
INFO - 2025-04-03 19:28:08 --> Config Class Initialized
INFO - 2025-04-03 19:28:08 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:08 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:08 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:08 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:28:08 --> Router Class Initialized
INFO - 2025-04-03 19:28:08 --> Output Class Initialized
INFO - 2025-04-03 19:28:08 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:08 --> Input Class Initialized
INFO - 2025-04-03 19:28:08 --> Language Class Initialized
INFO - 2025-04-03 19:28:08 --> Language Class Initialized
INFO - 2025-04-03 19:28:08 --> Config Class Initialized
INFO - 2025-04-03 19:28:08 --> Loader Class Initialized
INFO - 2025-04-03 19:28:08 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:08 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:08 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:08 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:08 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:08 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:08 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:08 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:08 --> Email Class Initialized
INFO - 2025-04-03 19:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:08 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:08 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:08 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:08 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:28:08 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:28:08 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:28:08 --> Model Class Initialized
INFO - 2025-04-03 19:28:08 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:08 --> Total execution time: 0.0051
INFO - 2025-04-03 19:28:10 --> Config Class Initialized
INFO - 2025-04-03 19:28:10 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:10 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:10 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:10 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:28:10 --> Router Class Initialized
INFO - 2025-04-03 19:28:10 --> Output Class Initialized
INFO - 2025-04-03 19:28:10 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:10 --> Input Class Initialized
INFO - 2025-04-03 19:28:10 --> Language Class Initialized
INFO - 2025-04-03 19:28:10 --> Language Class Initialized
INFO - 2025-04-03 19:28:10 --> Config Class Initialized
INFO - 2025-04-03 19:28:10 --> Loader Class Initialized
INFO - 2025-04-03 19:28:10 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:10 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:10 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:10 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:10 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:10 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:10 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:10 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:10 --> Email Class Initialized
INFO - 2025-04-03 19:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:10 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:10 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:10 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:10 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:28:10 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:28:10 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:28:10 --> Model Class Initialized
INFO - 2025-04-03 19:28:10 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:10 --> Total execution time: 0.0134
INFO - 2025-04-03 19:28:10 --> Config Class Initialized
INFO - 2025-04-03 19:28:10 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:10 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:10 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:10 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:28:10 --> Router Class Initialized
INFO - 2025-04-03 19:28:10 --> Output Class Initialized
INFO - 2025-04-03 19:28:10 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:10 --> Input Class Initialized
INFO - 2025-04-03 19:28:10 --> Language Class Initialized
INFO - 2025-04-03 19:28:11 --> Language Class Initialized
INFO - 2025-04-03 19:28:11 --> Config Class Initialized
INFO - 2025-04-03 19:28:11 --> Loader Class Initialized
INFO - 2025-04-03 19:28:11 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:11 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:11 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:11 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:11 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:11 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:11 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:11 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:11 --> Email Class Initialized
INFO - 2025-04-03 19:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:11 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:11 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:11 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:11 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:28:11 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:28:11 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:28:11 --> Model Class Initialized
INFO - 2025-04-03 19:28:11 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:11 --> Total execution time: 0.0055
INFO - 2025-04-03 19:28:12 --> Config Class Initialized
INFO - 2025-04-03 19:28:12 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:12 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:12 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:12 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:28:12 --> Router Class Initialized
INFO - 2025-04-03 19:28:12 --> Output Class Initialized
INFO - 2025-04-03 19:28:12 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:12 --> Input Class Initialized
INFO - 2025-04-03 19:28:12 --> Language Class Initialized
INFO - 2025-04-03 19:28:12 --> Language Class Initialized
INFO - 2025-04-03 19:28:12 --> Config Class Initialized
INFO - 2025-04-03 19:28:12 --> Loader Class Initialized
INFO - 2025-04-03 19:28:12 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:12 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:12 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:12 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:12 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:12 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:12 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:12 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:12 --> Email Class Initialized
INFO - 2025-04-03 19:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:12 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:12 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:12 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:12 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:28:12 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:28:12 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:28:12 --> Model Class Initialized
INFO - 2025-04-03 19:28:12 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:12 --> Total execution time: 0.0157
INFO - 2025-04-03 19:28:20 --> Config Class Initialized
INFO - 2025-04-03 19:28:20 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:20 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:20 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:20 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:28:20 --> Router Class Initialized
INFO - 2025-04-03 19:28:20 --> Output Class Initialized
INFO - 2025-04-03 19:28:20 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:20 --> Input Class Initialized
INFO - 2025-04-03 19:28:20 --> Language Class Initialized
INFO - 2025-04-03 19:28:20 --> Language Class Initialized
INFO - 2025-04-03 19:28:20 --> Config Class Initialized
INFO - 2025-04-03 19:28:20 --> Loader Class Initialized
INFO - 2025-04-03 19:28:20 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:20 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:20 --> Email Class Initialized
INFO - 2025-04-03 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:20 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:20 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:20 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:20 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:28:20 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:28:20 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:28:20 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:28:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:28:20 --> Model Class Initialized
ERROR - 2025-04-03 19:28:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:28:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:28:20 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:20 --> Total execution time: 0.1428
INFO - 2025-04-03 19:28:20 --> Config Class Initialized
INFO - 2025-04-03 19:28:20 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:20 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:20 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:20 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:28:20 --> Router Class Initialized
INFO - 2025-04-03 19:28:20 --> Output Class Initialized
INFO - 2025-04-03 19:28:20 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:20 --> Input Class Initialized
INFO - 2025-04-03 19:28:20 --> Language Class Initialized
INFO - 2025-04-03 19:28:20 --> Language Class Initialized
INFO - 2025-04-03 19:28:20 --> Config Class Initialized
INFO - 2025-04-03 19:28:20 --> Loader Class Initialized
INFO - 2025-04-03 19:28:20 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:20 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:20 --> Email Class Initialized
INFO - 2025-04-03 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:20 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:20 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:20 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:20 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:28:20 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:28:20 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:28:20 --> Model Class Initialized
ERROR - 2025-04-03 19:28:20 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 7
    [iTotalDisplayRecords] => 7
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/34769578">Test Product</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 200
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-02/c19c9bec0db94a53a3cbe5c4adce6cc7.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/34769578" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/34769578" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/34769578" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/34769578" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/cd23e47393890cd08fe0269c490e4dec.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [5] => Array
                (
                    [sl] => 6
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [6] => Array
                (
                    [sl] => 7
                    [product_name] => <a href="http://localhost:8000/product_details/81013513">Test Product 2</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/"></a>
                    [price] => 100
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-02/d984be91e4ff96faaf51b1de5b80d413.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/81013513" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/81013513" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/81013513" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/81013513" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-04-03 19:28:20 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:20 --> Total execution time: 0.0073
INFO - 2025-04-03 19:28:28 --> Config Class Initialized
INFO - 2025-04-03 19:28:28 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:28:28 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:28:28 --> Utf8 Class Initialized
INFO - 2025-04-03 19:28:28 --> URI Class Initialized
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:28:28 --> Router Class Initialized
INFO - 2025-04-03 19:28:28 --> Output Class Initialized
INFO - 2025-04-03 19:28:28 --> Security Class Initialized
DEBUG - 2025-04-03 19:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:28:28 --> Input Class Initialized
INFO - 2025-04-03 19:28:28 --> Language Class Initialized
INFO - 2025-04-03 19:28:28 --> Language Class Initialized
INFO - 2025-04-03 19:28:28 --> Config Class Initialized
INFO - 2025-04-03 19:28:28 --> Loader Class Initialized
INFO - 2025-04-03 19:28:28 --> Helper loaded: url_helper
INFO - 2025-04-03 19:28:28 --> Helper loaded: file_helper
INFO - 2025-04-03 19:28:28 --> Helper loaded: html_helper
INFO - 2025-04-03 19:28:28 --> Helper loaded: form_helper
INFO - 2025-04-03 19:28:28 --> Helper loaded: text_helper
INFO - 2025-04-03 19:28:28 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:28:28 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:28:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:28:28 --> Database Driver Class Initialized
INFO - 2025-04-03 19:28:28 --> Email Class Initialized
INFO - 2025-04-03 19:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:28:28 --> Form Validation Class Initialized
INFO - 2025-04-03 19:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:28:28 --> Pagination Class Initialized
INFO - 2025-04-03 19:28:28 --> Controller Class Initialized
DEBUG - 2025-04-03 19:28:28 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:28:28 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:28:28 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:28:28 --> Model Class Initialized
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:28:28 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:28:28 --> Model Class Initialized
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-03 19:28:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:28:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:28:28 --> Final output sent to browser
DEBUG - 2025-04-03 19:28:28 --> Total execution time: 0.2144
INFO - 2025-04-03 19:29:00 --> Config Class Initialized
INFO - 2025-04-03 19:29:00 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:00 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:00 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:00 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:29:00 --> Router Class Initialized
INFO - 2025-04-03 19:29:00 --> Output Class Initialized
INFO - 2025-04-03 19:29:00 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:00 --> Input Class Initialized
INFO - 2025-04-03 19:29:00 --> Language Class Initialized
INFO - 2025-04-03 19:29:00 --> Language Class Initialized
INFO - 2025-04-03 19:29:00 --> Config Class Initialized
INFO - 2025-04-03 19:29:00 --> Loader Class Initialized
INFO - 2025-04-03 19:29:00 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:00 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:00 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:00 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:00 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:00 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:00 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:00 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:00 --> Email Class Initialized
INFO - 2025-04-03 19:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:00 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:00 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:00 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:00 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:29:00 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:29:00 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:29:00 --> Model Class Initialized
INFO - 2025-04-03 19:29:00 --> Upload Class Initialized
INFO - 2025-04-03 19:29:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 19:29:01 --> Config Class Initialized
INFO - 2025-04-03 19:29:01 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:01 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:01 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:01 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:29:01 --> Router Class Initialized
INFO - 2025-04-03 19:29:01 --> Output Class Initialized
INFO - 2025-04-03 19:29:01 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:01 --> Input Class Initialized
INFO - 2025-04-03 19:29:01 --> Language Class Initialized
INFO - 2025-04-03 19:29:01 --> Language Class Initialized
INFO - 2025-04-03 19:29:01 --> Config Class Initialized
INFO - 2025-04-03 19:29:01 --> Loader Class Initialized
INFO - 2025-04-03 19:29:01 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:01 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:01 --> Email Class Initialized
INFO - 2025-04-03 19:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:01 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:01 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:01 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:01 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:29:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:29:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:29:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:29:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:29:01 --> Model Class Initialized
ERROR - 2025-04-03 19:29:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:29:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:29:01 --> Final output sent to browser
DEBUG - 2025-04-03 19:29:01 --> Total execution time: 0.1142
INFO - 2025-04-03 19:29:01 --> Config Class Initialized
INFO - 2025-04-03 19:29:01 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:01 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:01 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:01 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:29:01 --> Router Class Initialized
INFO - 2025-04-03 19:29:01 --> Output Class Initialized
INFO - 2025-04-03 19:29:01 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:01 --> Input Class Initialized
INFO - 2025-04-03 19:29:01 --> Language Class Initialized
INFO - 2025-04-03 19:29:01 --> Language Class Initialized
INFO - 2025-04-03 19:29:01 --> Config Class Initialized
INFO - 2025-04-03 19:29:01 --> Loader Class Initialized
INFO - 2025-04-03 19:29:01 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:01 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:01 --> Email Class Initialized
INFO - 2025-04-03 19:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:01 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:01 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:01 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:01 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:29:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:29:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:29:01 --> Model Class Initialized
ERROR - 2025-04-03 19:29:01 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 7
    [iTotalDisplayRecords] => 7
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/34769578">Test Product</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 200
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-02/c19c9bec0db94a53a3cbe5c4adce6cc7.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/34769578" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/34769578" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/34769578" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/34769578" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/cd23e47393890cd08fe0269c490e4dec.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [5] => Array
                (
                    [sl] => 6
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [6] => Array
                (
                    [sl] => 7
                    [product_name] => <a href="http://localhost:8000/product_details/81013513">Test Product 2</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 100
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-03/318e046a6b58394b74cd8832f4f5d008.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/81013513" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/81013513" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/81013513" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/81013513" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-04-03 19:29:01 --> Final output sent to browser
DEBUG - 2025-04-03 19:29:01 --> Total execution time: 0.0088
INFO - 2025-04-03 19:29:09 --> Config Class Initialized
INFO - 2025-04-03 19:29:09 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:09 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:09 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:09 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:29:09 --> Router Class Initialized
INFO - 2025-04-03 19:29:09 --> Output Class Initialized
INFO - 2025-04-03 19:29:09 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:09 --> Input Class Initialized
INFO - 2025-04-03 19:29:09 --> Language Class Initialized
INFO - 2025-04-03 19:29:09 --> Language Class Initialized
INFO - 2025-04-03 19:29:09 --> Config Class Initialized
INFO - 2025-04-03 19:29:09 --> Loader Class Initialized
INFO - 2025-04-03 19:29:09 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:09 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:09 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:09 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:09 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:09 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:09 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:09 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:09 --> Email Class Initialized
INFO - 2025-04-03 19:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:09 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:09 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:09 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:09 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:29:09 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:29:09 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:29:09 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:29:09 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:29:09 --> Model Class Initialized
ERROR - 2025-04-03 19:29:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:29:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:29:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:29:09 --> Final output sent to browser
DEBUG - 2025-04-03 19:29:09 --> Total execution time: 0.1722
INFO - 2025-04-03 19:29:10 --> Config Class Initialized
INFO - 2025-04-03 19:29:10 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:10 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:10 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:10 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:29:10 --> Router Class Initialized
INFO - 2025-04-03 19:29:10 --> Output Class Initialized
INFO - 2025-04-03 19:29:10 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:10 --> Input Class Initialized
INFO - 2025-04-03 19:29:10 --> Language Class Initialized
INFO - 2025-04-03 19:29:10 --> Language Class Initialized
INFO - 2025-04-03 19:29:10 --> Config Class Initialized
INFO - 2025-04-03 19:29:10 --> Loader Class Initialized
INFO - 2025-04-03 19:29:10 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:10 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:10 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:10 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:10 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:10 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:10 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:10 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:10 --> Email Class Initialized
INFO - 2025-04-03 19:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:10 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:10 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:10 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:10 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:29:10 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:29:10 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:29:10 --> Model Class Initialized
INFO - 2025-04-03 19:29:10 --> Final output sent to browser
DEBUG - 2025-04-03 19:29:10 --> Total execution time: 0.0345
INFO - 2025-04-03 19:29:11 --> Config Class Initialized
INFO - 2025-04-03 19:29:11 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:11 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:11 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:11 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:29:11 --> Router Class Initialized
INFO - 2025-04-03 19:29:11 --> Output Class Initialized
INFO - 2025-04-03 19:29:11 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:11 --> Input Class Initialized
INFO - 2025-04-03 19:29:11 --> Language Class Initialized
INFO - 2025-04-03 19:29:11 --> Language Class Initialized
INFO - 2025-04-03 19:29:11 --> Config Class Initialized
INFO - 2025-04-03 19:29:11 --> Loader Class Initialized
INFO - 2025-04-03 19:29:11 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:11 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:11 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:11 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:11 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:11 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:11 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:11 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:11 --> Email Class Initialized
INFO - 2025-04-03 19:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:11 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:11 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:11 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:11 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:29:11 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:29:11 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:29:11 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:29:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:29:11 --> Model Class Initialized
ERROR - 2025-04-03 19:29:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:29:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:29:11 --> Final output sent to browser
DEBUG - 2025-04-03 19:29:11 --> Total execution time: 0.1597
INFO - 2025-04-03 19:29:20 --> Config Class Initialized
INFO - 2025-04-03 19:29:20 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:20 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:20 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:20 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:29:20 --> Router Class Initialized
INFO - 2025-04-03 19:29:20 --> Output Class Initialized
INFO - 2025-04-03 19:29:20 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:20 --> Input Class Initialized
INFO - 2025-04-03 19:29:20 --> Language Class Initialized
INFO - 2025-04-03 19:29:20 --> Language Class Initialized
INFO - 2025-04-03 19:29:20 --> Config Class Initialized
INFO - 2025-04-03 19:29:20 --> Loader Class Initialized
INFO - 2025-04-03 19:29:20 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:20 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:20 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:20 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:20 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:20 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:20 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:20 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:20 --> Email Class Initialized
INFO - 2025-04-03 19:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:20 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:20 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:20 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:20 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:29:20 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:29:20 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:29:20 --> Model Class Initialized
INFO - 2025-04-03 19:29:20 --> Final output sent to browser
DEBUG - 2025-04-03 19:29:20 --> Total execution time: 0.0151
INFO - 2025-04-03 19:29:23 --> Config Class Initialized
INFO - 2025-04-03 19:29:23 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:29:23 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:29:23 --> Utf8 Class Initialized
INFO - 2025-04-03 19:29:23 --> URI Class Initialized
DEBUG - 2025-04-03 19:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:29:23 --> Router Class Initialized
INFO - 2025-04-03 19:29:23 --> Output Class Initialized
INFO - 2025-04-03 19:29:23 --> Security Class Initialized
DEBUG - 2025-04-03 19:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:29:23 --> Input Class Initialized
INFO - 2025-04-03 19:29:23 --> Language Class Initialized
INFO - 2025-04-03 19:29:23 --> Language Class Initialized
INFO - 2025-04-03 19:29:23 --> Config Class Initialized
INFO - 2025-04-03 19:29:23 --> Loader Class Initialized
INFO - 2025-04-03 19:29:23 --> Helper loaded: url_helper
INFO - 2025-04-03 19:29:23 --> Helper loaded: file_helper
INFO - 2025-04-03 19:29:23 --> Helper loaded: html_helper
INFO - 2025-04-03 19:29:23 --> Helper loaded: form_helper
INFO - 2025-04-03 19:29:23 --> Helper loaded: text_helper
INFO - 2025-04-03 19:29:23 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:29:23 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:29:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:29:23 --> Database Driver Class Initialized
INFO - 2025-04-03 19:29:23 --> Email Class Initialized
INFO - 2025-04-03 19:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:29:23 --> Form Validation Class Initialized
INFO - 2025-04-03 19:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:29:23 --> Pagination Class Initialized
INFO - 2025-04-03 19:29:23 --> Controller Class Initialized
DEBUG - 2025-04-03 19:29:23 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:29:23 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:29:23 --> Model Class Initialized
DEBUG - 2025-04-03 19:29:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:29:23 --> Model Class Initialized
INFO - 2025-04-03 19:29:23 --> Final output sent to browser
DEBUG - 2025-04-03 19:29:23 --> Total execution time: 0.0063
INFO - 2025-04-03 19:30:01 --> Config Class Initialized
INFO - 2025-04-03 19:30:01 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:01 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:01 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:01 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:30:01 --> Router Class Initialized
INFO - 2025-04-03 19:30:01 --> Output Class Initialized
INFO - 2025-04-03 19:30:01 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:01 --> Input Class Initialized
INFO - 2025-04-03 19:30:01 --> Language Class Initialized
INFO - 2025-04-03 19:30:01 --> Language Class Initialized
INFO - 2025-04-03 19:30:01 --> Config Class Initialized
INFO - 2025-04-03 19:30:01 --> Loader Class Initialized
INFO - 2025-04-03 19:30:01 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:01 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:01 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:01 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:01 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:01 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:01 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:01 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:01 --> Email Class Initialized
INFO - 2025-04-03 19:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:01 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:01 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:01 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:01 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:30:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:30:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:30:01 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:30:01 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:30:01 --> Model Class Initialized
ERROR - 2025-04-03 19:30:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:30:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:30:01 --> Final output sent to browser
DEBUG - 2025-04-03 19:30:01 --> Total execution time: 0.1221
INFO - 2025-04-03 19:30:02 --> Config Class Initialized
INFO - 2025-04-03 19:30:02 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:02 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:02 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:02 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-03 19:30:02 --> Router Class Initialized
INFO - 2025-04-03 19:30:02 --> Output Class Initialized
INFO - 2025-04-03 19:30:02 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:02 --> Input Class Initialized
INFO - 2025-04-03 19:30:02 --> Language Class Initialized
INFO - 2025-04-03 19:30:02 --> Language Class Initialized
INFO - 2025-04-03 19:30:02 --> Config Class Initialized
INFO - 2025-04-03 19:30:02 --> Loader Class Initialized
INFO - 2025-04-03 19:30:02 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:02 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:02 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:02 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:02 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:02 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:02 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:02 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:02 --> Email Class Initialized
INFO - 2025-04-03 19:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:02 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:02 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:02 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:02 --> Product MX_Controller Initialized
INFO - 2025-04-03 19:30:02 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-03 19:30:02 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-03 19:30:02 --> Model Class Initialized
ERROR - 2025-04-03 19:30:02 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 7
    [iTotalDisplayRecords] => 7
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/34769578">Test Product</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 200
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-02/c19c9bec0db94a53a3cbe5c4adce6cc7.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/34769578" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/34769578" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/34769578" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/34769578" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/cd23e47393890cd08fe0269c490e4dec.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [5] => Array
                (
                    [sl] => 6
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [6] => Array
                (
                    [sl] => 7
                    [product_name] => <a href="http://localhost:8000/product_details/81013513">Test Product 2</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 100
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-03/318e046a6b58394b74cd8832f4f5d008.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/81013513" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/81013513" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/81013513" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/81013513" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-04-03 19:30:02 --> Final output sent to browser
DEBUG - 2025-04-03 19:30:02 --> Total execution time: 0.0130
INFO - 2025-04-03 19:30:26 --> Config Class Initialized
INFO - 2025-04-03 19:30:26 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:26 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:26 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:26 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:30:26 --> Router Class Initialized
INFO - 2025-04-03 19:30:26 --> Output Class Initialized
INFO - 2025-04-03 19:30:26 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:26 --> Input Class Initialized
INFO - 2025-04-03 19:30:26 --> Language Class Initialized
INFO - 2025-04-03 19:30:26 --> Language Class Initialized
INFO - 2025-04-03 19:30:26 --> Config Class Initialized
INFO - 2025-04-03 19:30:26 --> Loader Class Initialized
INFO - 2025-04-03 19:30:26 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:26 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:26 --> Email Class Initialized
INFO - 2025-04-03 19:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:26 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:26 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:26 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:26 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:30:26 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:30:26 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:30:26 --> Model Class Initialized
INFO - 2025-04-03 19:30:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 19:30:26 --> Config Class Initialized
INFO - 2025-04-03 19:30:26 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:26 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:26 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:26 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:30:26 --> Router Class Initialized
INFO - 2025-04-03 19:30:26 --> Output Class Initialized
INFO - 2025-04-03 19:30:26 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:26 --> Input Class Initialized
INFO - 2025-04-03 19:30:26 --> Language Class Initialized
INFO - 2025-04-03 19:30:26 --> Language Class Initialized
INFO - 2025-04-03 19:30:26 --> Config Class Initialized
INFO - 2025-04-03 19:30:26 --> Loader Class Initialized
INFO - 2025-04-03 19:30:26 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:26 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:26 --> Email Class Initialized
INFO - 2025-04-03 19:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:26 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:26 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:26 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:26 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:30:26 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:30:26 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:30:26 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 19:30:26 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 19:30:26 --> Model Class Initialized
ERROR - 2025-04-03 19:30:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 19:30:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 19:30:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 19:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-04-03 19:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 19:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 19:30:27 --> Final output sent to browser
DEBUG - 2025-04-03 19:30:27 --> Total execution time: 0.1608
INFO - 2025-04-03 19:30:27 --> Config Class Initialized
INFO - 2025-04-03 19:30:27 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:27 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:27 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:27 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-03 19:30:27 --> Router Class Initialized
INFO - 2025-04-03 19:30:27 --> Output Class Initialized
INFO - 2025-04-03 19:30:27 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:27 --> Input Class Initialized
INFO - 2025-04-03 19:30:27 --> Language Class Initialized
INFO - 2025-04-03 19:30:27 --> Language Class Initialized
INFO - 2025-04-03 19:30:27 --> Config Class Initialized
INFO - 2025-04-03 19:30:27 --> Loader Class Initialized
INFO - 2025-04-03 19:30:27 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:27 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:27 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:27 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:27 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:27 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:27 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:27 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:27 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:27 --> Email Class Initialized
INFO - 2025-04-03 19:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:27 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:27 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:27 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:27 --> Purchase MX_Controller Initialized
INFO - 2025-04-03 19:30:27 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-03 19:30:27 --> Model Class Initialized
DEBUG - 2025-04-03 19:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-03 19:30:27 --> Model Class Initialized
INFO - 2025-04-03 19:30:27 --> Final output sent to browser
DEBUG - 2025-04-03 19:30:27 --> Total execution time: 0.0320
INFO - 2025-04-03 19:30:47 --> Config Class Initialized
INFO - 2025-04-03 19:30:47 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:47 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:47 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:47 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:30:47 --> Router Class Initialized
INFO - 2025-04-03 19:30:47 --> Output Class Initialized
INFO - 2025-04-03 19:30:47 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:47 --> Input Class Initialized
INFO - 2025-04-03 19:30:47 --> Language Class Initialized
INFO - 2025-04-03 19:30:47 --> Language Class Initialized
INFO - 2025-04-03 19:30:47 --> Config Class Initialized
INFO - 2025-04-03 19:30:47 --> Loader Class Initialized
INFO - 2025-04-03 19:30:47 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:47 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:47 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:47 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:47 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:47 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:47 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:47 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:47 --> Email Class Initialized
INFO - 2025-04-03 19:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:47 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:47 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:47 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:30:53 --> Config Class Initialized
INFO - 2025-04-03 19:30:53 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:53 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:53 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:53 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:30:53 --> Router Class Initialized
INFO - 2025-04-03 19:30:53 --> Output Class Initialized
INFO - 2025-04-03 19:30:53 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:53 --> Input Class Initialized
INFO - 2025-04-03 19:30:53 --> Language Class Initialized
INFO - 2025-04-03 19:30:53 --> Language Class Initialized
INFO - 2025-04-03 19:30:53 --> Config Class Initialized
INFO - 2025-04-03 19:30:53 --> Loader Class Initialized
INFO - 2025-04-03 19:30:53 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:53 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:53 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:53 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:53 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:53 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:53 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:53 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:53 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:53 --> Email Class Initialized
INFO - 2025-04-03 19:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:53 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:53 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:53 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:53 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:30:54 --> Config Class Initialized
INFO - 2025-04-03 19:30:54 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:54 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:54 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:54 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:30:54 --> Router Class Initialized
INFO - 2025-04-03 19:30:54 --> Output Class Initialized
INFO - 2025-04-03 19:30:54 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:54 --> Input Class Initialized
INFO - 2025-04-03 19:30:54 --> Language Class Initialized
INFO - 2025-04-03 19:30:54 --> Language Class Initialized
INFO - 2025-04-03 19:30:54 --> Config Class Initialized
INFO - 2025-04-03 19:30:54 --> Loader Class Initialized
INFO - 2025-04-03 19:30:54 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:54 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:54 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:54 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:54 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:54 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:54 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:54 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:54 --> Email Class Initialized
INFO - 2025-04-03 19:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:54 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:54 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:54 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:54 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:30:58 --> Config Class Initialized
INFO - 2025-04-03 19:30:58 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:58 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:58 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:58 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:30:58 --> Router Class Initialized
INFO - 2025-04-03 19:30:58 --> Output Class Initialized
INFO - 2025-04-03 19:30:58 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:58 --> Input Class Initialized
INFO - 2025-04-03 19:30:58 --> Language Class Initialized
INFO - 2025-04-03 19:30:58 --> Language Class Initialized
INFO - 2025-04-03 19:30:58 --> Config Class Initialized
INFO - 2025-04-03 19:30:58 --> Loader Class Initialized
INFO - 2025-04-03 19:30:58 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:58 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:58 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:58 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:58 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:58 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:58 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:58 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:58 --> Email Class Initialized
INFO - 2025-04-03 19:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:58 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:58 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:58 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:30:59 --> Config Class Initialized
INFO - 2025-04-03 19:30:59 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:30:59 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:30:59 --> Utf8 Class Initialized
INFO - 2025-04-03 19:30:59 --> URI Class Initialized
DEBUG - 2025-04-03 19:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:30:59 --> Router Class Initialized
INFO - 2025-04-03 19:30:59 --> Output Class Initialized
INFO - 2025-04-03 19:30:59 --> Security Class Initialized
DEBUG - 2025-04-03 19:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:30:59 --> Input Class Initialized
INFO - 2025-04-03 19:30:59 --> Language Class Initialized
INFO - 2025-04-03 19:30:59 --> Language Class Initialized
INFO - 2025-04-03 19:30:59 --> Config Class Initialized
INFO - 2025-04-03 19:30:59 --> Loader Class Initialized
INFO - 2025-04-03 19:30:59 --> Helper loaded: url_helper
INFO - 2025-04-03 19:30:59 --> Helper loaded: file_helper
INFO - 2025-04-03 19:30:59 --> Helper loaded: html_helper
INFO - 2025-04-03 19:30:59 --> Helper loaded: form_helper
INFO - 2025-04-03 19:30:59 --> Helper loaded: text_helper
INFO - 2025-04-03 19:30:59 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:30:59 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:30:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:30:59 --> Database Driver Class Initialized
INFO - 2025-04-03 19:30:59 --> Email Class Initialized
INFO - 2025-04-03 19:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:30:59 --> Form Validation Class Initialized
INFO - 2025-04-03 19:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:30:59 --> Pagination Class Initialized
INFO - 2025-04-03 19:30:59 --> Controller Class Initialized
DEBUG - 2025-04-03 19:30:59 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:31:02 --> Config Class Initialized
INFO - 2025-04-03 19:31:02 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:31:02 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:31:02 --> Utf8 Class Initialized
INFO - 2025-04-03 19:31:02 --> URI Class Initialized
DEBUG - 2025-04-03 19:31:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:31:02 --> Router Class Initialized
INFO - 2025-04-03 19:31:02 --> Output Class Initialized
INFO - 2025-04-03 19:31:02 --> Security Class Initialized
DEBUG - 2025-04-03 19:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:31:02 --> Input Class Initialized
INFO - 2025-04-03 19:31:02 --> Language Class Initialized
INFO - 2025-04-03 19:31:02 --> Language Class Initialized
INFO - 2025-04-03 19:31:02 --> Config Class Initialized
INFO - 2025-04-03 19:31:02 --> Loader Class Initialized
INFO - 2025-04-03 19:31:02 --> Helper loaded: url_helper
INFO - 2025-04-03 19:31:02 --> Helper loaded: file_helper
INFO - 2025-04-03 19:31:02 --> Helper loaded: html_helper
INFO - 2025-04-03 19:31:02 --> Helper loaded: form_helper
INFO - 2025-04-03 19:31:02 --> Helper loaded: text_helper
INFO - 2025-04-03 19:31:02 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:31:02 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:31:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:31:02 --> Database Driver Class Initialized
INFO - 2025-04-03 19:31:02 --> Email Class Initialized
INFO - 2025-04-03 19:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:31:02 --> Form Validation Class Initialized
INFO - 2025-04-03 19:31:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:31:02 --> Pagination Class Initialized
INFO - 2025-04-03 19:31:02 --> Controller Class Initialized
DEBUG - 2025-04-03 19:31:02 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:31:19 --> Config Class Initialized
INFO - 2025-04-03 19:31:19 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:31:19 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:31:19 --> Utf8 Class Initialized
INFO - 2025-04-03 19:31:19 --> URI Class Initialized
DEBUG - 2025-04-03 19:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:31:19 --> Router Class Initialized
INFO - 2025-04-03 19:31:19 --> Output Class Initialized
INFO - 2025-04-03 19:31:19 --> Security Class Initialized
DEBUG - 2025-04-03 19:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:31:19 --> Input Class Initialized
INFO - 2025-04-03 19:31:19 --> Language Class Initialized
INFO - 2025-04-03 19:31:19 --> Language Class Initialized
INFO - 2025-04-03 19:31:19 --> Config Class Initialized
INFO - 2025-04-03 19:31:19 --> Loader Class Initialized
INFO - 2025-04-03 19:31:19 --> Helper loaded: url_helper
INFO - 2025-04-03 19:31:19 --> Helper loaded: file_helper
INFO - 2025-04-03 19:31:19 --> Helper loaded: html_helper
INFO - 2025-04-03 19:31:19 --> Helper loaded: form_helper
INFO - 2025-04-03 19:31:19 --> Helper loaded: text_helper
INFO - 2025-04-03 19:31:19 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:31:19 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:31:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:31:19 --> Database Driver Class Initialized
INFO - 2025-04-03 19:31:19 --> Email Class Initialized
INFO - 2025-04-03 19:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:31:19 --> Form Validation Class Initialized
INFO - 2025-04-03 19:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:31:19 --> Pagination Class Initialized
INFO - 2025-04-03 19:31:19 --> Controller Class Initialized
DEBUG - 2025-04-03 19:31:19 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:31:37 --> Config Class Initialized
INFO - 2025-04-03 19:31:37 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:31:37 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:31:37 --> Utf8 Class Initialized
INFO - 2025-04-03 19:31:37 --> URI Class Initialized
DEBUG - 2025-04-03 19:31:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:31:37 --> Router Class Initialized
INFO - 2025-04-03 19:31:37 --> Output Class Initialized
INFO - 2025-04-03 19:31:37 --> Security Class Initialized
DEBUG - 2025-04-03 19:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:31:37 --> Input Class Initialized
INFO - 2025-04-03 19:31:37 --> Language Class Initialized
INFO - 2025-04-03 19:31:37 --> Language Class Initialized
INFO - 2025-04-03 19:31:37 --> Config Class Initialized
INFO - 2025-04-03 19:31:37 --> Loader Class Initialized
INFO - 2025-04-03 19:31:37 --> Helper loaded: url_helper
INFO - 2025-04-03 19:31:37 --> Helper loaded: file_helper
INFO - 2025-04-03 19:31:37 --> Helper loaded: html_helper
INFO - 2025-04-03 19:31:37 --> Helper loaded: form_helper
INFO - 2025-04-03 19:31:37 --> Helper loaded: text_helper
INFO - 2025-04-03 19:31:37 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:31:37 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:31:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:31:37 --> Database Driver Class Initialized
INFO - 2025-04-03 19:31:37 --> Email Class Initialized
INFO - 2025-04-03 19:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:31:37 --> Form Validation Class Initialized
INFO - 2025-04-03 19:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:31:37 --> Pagination Class Initialized
INFO - 2025-04-03 19:31:37 --> Controller Class Initialized
DEBUG - 2025-04-03 19:31:37 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:31:39 --> Config Class Initialized
INFO - 2025-04-03 19:31:39 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:31:39 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:31:39 --> Utf8 Class Initialized
INFO - 2025-04-03 19:31:39 --> URI Class Initialized
DEBUG - 2025-04-03 19:31:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:31:39 --> Router Class Initialized
INFO - 2025-04-03 19:31:39 --> Output Class Initialized
INFO - 2025-04-03 19:31:39 --> Security Class Initialized
DEBUG - 2025-04-03 19:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:31:39 --> Input Class Initialized
INFO - 2025-04-03 19:31:39 --> Language Class Initialized
INFO - 2025-04-03 19:31:39 --> Language Class Initialized
INFO - 2025-04-03 19:31:39 --> Config Class Initialized
INFO - 2025-04-03 19:31:39 --> Loader Class Initialized
INFO - 2025-04-03 19:31:39 --> Helper loaded: url_helper
INFO - 2025-04-03 19:31:39 --> Helper loaded: file_helper
INFO - 2025-04-03 19:31:39 --> Helper loaded: html_helper
INFO - 2025-04-03 19:31:39 --> Helper loaded: form_helper
INFO - 2025-04-03 19:31:39 --> Helper loaded: text_helper
INFO - 2025-04-03 19:31:39 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:31:39 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:31:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:31:39 --> Database Driver Class Initialized
INFO - 2025-04-03 19:31:39 --> Email Class Initialized
INFO - 2025-04-03 19:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:31:39 --> Form Validation Class Initialized
INFO - 2025-04-03 19:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:31:39 --> Pagination Class Initialized
INFO - 2025-04-03 19:31:39 --> Controller Class Initialized
DEBUG - 2025-04-03 19:31:39 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:32:01 --> Config Class Initialized
INFO - 2025-04-03 19:32:01 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:32:01 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:32:01 --> Utf8 Class Initialized
INFO - 2025-04-03 19:32:01 --> URI Class Initialized
DEBUG - 2025-04-03 19:32:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:32:01 --> Router Class Initialized
INFO - 2025-04-03 19:32:01 --> Output Class Initialized
INFO - 2025-04-03 19:32:01 --> Security Class Initialized
DEBUG - 2025-04-03 19:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:32:01 --> Input Class Initialized
INFO - 2025-04-03 19:32:01 --> Language Class Initialized
INFO - 2025-04-03 19:32:01 --> Language Class Initialized
INFO - 2025-04-03 19:32:01 --> Config Class Initialized
INFO - 2025-04-03 19:32:01 --> Loader Class Initialized
INFO - 2025-04-03 19:32:01 --> Helper loaded: url_helper
INFO - 2025-04-03 19:32:01 --> Helper loaded: file_helper
INFO - 2025-04-03 19:32:01 --> Helper loaded: html_helper
INFO - 2025-04-03 19:32:01 --> Helper loaded: form_helper
INFO - 2025-04-03 19:32:01 --> Helper loaded: text_helper
INFO - 2025-04-03 19:32:01 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:32:01 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:32:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:32:01 --> Database Driver Class Initialized
INFO - 2025-04-03 19:32:01 --> Email Class Initialized
INFO - 2025-04-03 19:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:32:01 --> Form Validation Class Initialized
INFO - 2025-04-03 19:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:32:01 --> Pagination Class Initialized
INFO - 2025-04-03 19:32:01 --> Controller Class Initialized
DEBUG - 2025-04-03 19:32:01 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 19:32:04 --> Config Class Initialized
INFO - 2025-04-03 19:32:04 --> Hooks Class Initialized
DEBUG - 2025-04-03 19:32:04 --> UTF-8 Support Enabled
INFO - 2025-04-03 19:32:04 --> Utf8 Class Initialized
INFO - 2025-04-03 19:32:04 --> URI Class Initialized
DEBUG - 2025-04-03 19:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 19:32:04 --> Router Class Initialized
INFO - 2025-04-03 19:32:04 --> Output Class Initialized
INFO - 2025-04-03 19:32:04 --> Security Class Initialized
DEBUG - 2025-04-03 19:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 19:32:04 --> Input Class Initialized
INFO - 2025-04-03 19:32:04 --> Language Class Initialized
INFO - 2025-04-03 19:32:04 --> Language Class Initialized
INFO - 2025-04-03 19:32:04 --> Config Class Initialized
INFO - 2025-04-03 19:32:04 --> Loader Class Initialized
INFO - 2025-04-03 19:32:04 --> Helper loaded: url_helper
INFO - 2025-04-03 19:32:04 --> Helper loaded: file_helper
INFO - 2025-04-03 19:32:04 --> Helper loaded: html_helper
INFO - 2025-04-03 19:32:04 --> Helper loaded: form_helper
INFO - 2025-04-03 19:32:04 --> Helper loaded: text_helper
INFO - 2025-04-03 19:32:04 --> Helper loaded: lang_helper
INFO - 2025-04-03 19:32:04 --> Helper loaded: directory_helper
INFO - 2025-04-03 19:32:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 19:32:04 --> Database Driver Class Initialized
INFO - 2025-04-03 19:32:04 --> Email Class Initialized
INFO - 2025-04-03 19:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 19:32:04 --> Form Validation Class Initialized
INFO - 2025-04-03 19:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 19:32:04 --> Pagination Class Initialized
INFO - 2025-04-03 19:32:04 --> Controller Class Initialized
DEBUG - 2025-04-03 19:32:04 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:12:02 --> Config Class Initialized
INFO - 2025-04-03 21:12:02 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:12:02 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:12:02 --> Utf8 Class Initialized
INFO - 2025-04-03 21:12:02 --> URI Class Initialized
DEBUG - 2025-04-03 21:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:12:02 --> Router Class Initialized
INFO - 2025-04-03 21:12:02 --> Output Class Initialized
INFO - 2025-04-03 21:12:02 --> Security Class Initialized
DEBUG - 2025-04-03 21:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:12:02 --> Input Class Initialized
INFO - 2025-04-03 21:12:02 --> Language Class Initialized
INFO - 2025-04-03 21:12:02 --> Language Class Initialized
INFO - 2025-04-03 21:12:02 --> Config Class Initialized
INFO - 2025-04-03 21:12:02 --> Loader Class Initialized
INFO - 2025-04-03 21:12:02 --> Helper loaded: url_helper
INFO - 2025-04-03 21:12:02 --> Helper loaded: file_helper
INFO - 2025-04-03 21:12:02 --> Helper loaded: html_helper
INFO - 2025-04-03 21:12:02 --> Helper loaded: form_helper
INFO - 2025-04-03 21:12:02 --> Helper loaded: text_helper
INFO - 2025-04-03 21:12:02 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:12:02 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:12:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:12:02 --> Database Driver Class Initialized
INFO - 2025-04-03 21:12:02 --> Email Class Initialized
INFO - 2025-04-03 21:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:12:02 --> Form Validation Class Initialized
INFO - 2025-04-03 21:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:12:02 --> Pagination Class Initialized
INFO - 2025-04-03 21:12:02 --> Controller Class Initialized
DEBUG - 2025-04-03 21:12:02 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:05 --> Config Class Initialized
INFO - 2025-04-03 21:13:05 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:05 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:05 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:05 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:05 --> Router Class Initialized
INFO - 2025-04-03 21:13:05 --> Output Class Initialized
INFO - 2025-04-03 21:13:05 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:05 --> Input Class Initialized
INFO - 2025-04-03 21:13:05 --> Language Class Initialized
INFO - 2025-04-03 21:13:05 --> Language Class Initialized
INFO - 2025-04-03 21:13:05 --> Config Class Initialized
INFO - 2025-04-03 21:13:05 --> Loader Class Initialized
INFO - 2025-04-03 21:13:05 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:05 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:05 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:05 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:05 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:05 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:05 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:05 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:05 --> Email Class Initialized
INFO - 2025-04-03 21:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:05 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:05 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:05 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:05 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:06 --> Config Class Initialized
INFO - 2025-04-03 21:13:06 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:06 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:06 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:06 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:06 --> Router Class Initialized
INFO - 2025-04-03 21:13:06 --> Output Class Initialized
INFO - 2025-04-03 21:13:06 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:06 --> Input Class Initialized
INFO - 2025-04-03 21:13:06 --> Language Class Initialized
INFO - 2025-04-03 21:13:06 --> Language Class Initialized
INFO - 2025-04-03 21:13:06 --> Config Class Initialized
INFO - 2025-04-03 21:13:06 --> Loader Class Initialized
INFO - 2025-04-03 21:13:06 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:06 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:06 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:06 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:06 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:06 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:06 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:06 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:06 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:06 --> Email Class Initialized
INFO - 2025-04-03 21:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:06 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:06 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:06 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:06 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:10 --> Config Class Initialized
INFO - 2025-04-03 21:13:10 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:10 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:10 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:10 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:10 --> Router Class Initialized
INFO - 2025-04-03 21:13:10 --> Output Class Initialized
INFO - 2025-04-03 21:13:10 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:10 --> Input Class Initialized
INFO - 2025-04-03 21:13:10 --> Language Class Initialized
INFO - 2025-04-03 21:13:10 --> Language Class Initialized
INFO - 2025-04-03 21:13:10 --> Config Class Initialized
INFO - 2025-04-03 21:13:10 --> Loader Class Initialized
INFO - 2025-04-03 21:13:10 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:10 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:10 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:10 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:10 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:10 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:10 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:10 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:10 --> Email Class Initialized
INFO - 2025-04-03 21:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:10 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:10 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:10 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:10 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:11 --> Config Class Initialized
INFO - 2025-04-03 21:13:11 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:11 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:11 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:11 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:11 --> Router Class Initialized
INFO - 2025-04-03 21:13:11 --> Output Class Initialized
INFO - 2025-04-03 21:13:11 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:11 --> Input Class Initialized
INFO - 2025-04-03 21:13:11 --> Language Class Initialized
INFO - 2025-04-03 21:13:11 --> Language Class Initialized
INFO - 2025-04-03 21:13:11 --> Config Class Initialized
INFO - 2025-04-03 21:13:11 --> Loader Class Initialized
INFO - 2025-04-03 21:13:11 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:11 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:11 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:11 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:11 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:11 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:11 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:11 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:11 --> Email Class Initialized
INFO - 2025-04-03 21:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:11 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:11 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:11 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:11 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:16 --> Config Class Initialized
INFO - 2025-04-03 21:13:16 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:16 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:16 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:16 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:16 --> Router Class Initialized
INFO - 2025-04-03 21:13:16 --> Output Class Initialized
INFO - 2025-04-03 21:13:16 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:16 --> Input Class Initialized
INFO - 2025-04-03 21:13:16 --> Language Class Initialized
INFO - 2025-04-03 21:13:16 --> Language Class Initialized
INFO - 2025-04-03 21:13:16 --> Config Class Initialized
INFO - 2025-04-03 21:13:16 --> Loader Class Initialized
INFO - 2025-04-03 21:13:16 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:16 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:16 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:16 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:16 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:16 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:16 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:16 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:16 --> Email Class Initialized
INFO - 2025-04-03 21:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:16 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:16 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:16 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:17 --> Config Class Initialized
INFO - 2025-04-03 21:13:17 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:17 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:17 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:17 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:17 --> Router Class Initialized
INFO - 2025-04-03 21:13:17 --> Output Class Initialized
INFO - 2025-04-03 21:13:17 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:17 --> Input Class Initialized
INFO - 2025-04-03 21:13:17 --> Language Class Initialized
INFO - 2025-04-03 21:13:17 --> Language Class Initialized
INFO - 2025-04-03 21:13:17 --> Config Class Initialized
INFO - 2025-04-03 21:13:17 --> Loader Class Initialized
INFO - 2025-04-03 21:13:17 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:17 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:17 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:17 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:17 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:17 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:17 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:17 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:17 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:17 --> Email Class Initialized
INFO - 2025-04-03 21:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:17 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:17 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:17 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:17 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:19 --> Config Class Initialized
INFO - 2025-04-03 21:13:19 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:19 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:19 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:19 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:19 --> Router Class Initialized
INFO - 2025-04-03 21:13:19 --> Output Class Initialized
INFO - 2025-04-03 21:13:19 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:19 --> Input Class Initialized
INFO - 2025-04-03 21:13:19 --> Language Class Initialized
INFO - 2025-04-03 21:13:19 --> Language Class Initialized
INFO - 2025-04-03 21:13:19 --> Config Class Initialized
INFO - 2025-04-03 21:13:19 --> Loader Class Initialized
INFO - 2025-04-03 21:13:19 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:19 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:19 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:19 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:19 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:19 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:19 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:19 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:19 --> Email Class Initialized
INFO - 2025-04-03 21:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:19 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:19 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:19 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:19 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:29 --> Config Class Initialized
INFO - 2025-04-03 21:13:29 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:29 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:29 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:29 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:29 --> Router Class Initialized
INFO - 2025-04-03 21:13:29 --> Output Class Initialized
INFO - 2025-04-03 21:13:29 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:29 --> Input Class Initialized
INFO - 2025-04-03 21:13:29 --> Language Class Initialized
INFO - 2025-04-03 21:13:29 --> Language Class Initialized
INFO - 2025-04-03 21:13:29 --> Config Class Initialized
INFO - 2025-04-03 21:13:29 --> Loader Class Initialized
INFO - 2025-04-03 21:13:29 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:29 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:29 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:29 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:29 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:29 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:29 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:29 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:29 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:29 --> Email Class Initialized
INFO - 2025-04-03 21:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:29 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:29 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:29 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:29 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:30 --> Config Class Initialized
INFO - 2025-04-03 21:13:30 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:30 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:30 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:30 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:30 --> Router Class Initialized
INFO - 2025-04-03 21:13:30 --> Output Class Initialized
INFO - 2025-04-03 21:13:30 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:30 --> Input Class Initialized
INFO - 2025-04-03 21:13:30 --> Language Class Initialized
INFO - 2025-04-03 21:13:30 --> Language Class Initialized
INFO - 2025-04-03 21:13:30 --> Config Class Initialized
INFO - 2025-04-03 21:13:30 --> Loader Class Initialized
INFO - 2025-04-03 21:13:30 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:30 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:30 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:30 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:30 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:30 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:30 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:30 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:30 --> Email Class Initialized
INFO - 2025-04-03 21:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:30 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:30 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:30 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:30 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:32 --> Config Class Initialized
INFO - 2025-04-03 21:13:32 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:32 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:32 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:32 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:32 --> Router Class Initialized
INFO - 2025-04-03 21:13:32 --> Output Class Initialized
INFO - 2025-04-03 21:13:32 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:32 --> Input Class Initialized
INFO - 2025-04-03 21:13:32 --> Language Class Initialized
INFO - 2025-04-03 21:13:32 --> Language Class Initialized
INFO - 2025-04-03 21:13:32 --> Config Class Initialized
INFO - 2025-04-03 21:13:32 --> Loader Class Initialized
INFO - 2025-04-03 21:13:32 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:32 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:32 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:32 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:32 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:32 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:32 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:32 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:32 --> Email Class Initialized
INFO - 2025-04-03 21:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:32 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:32 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:32 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:32 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:46 --> Config Class Initialized
INFO - 2025-04-03 21:13:46 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:46 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:46 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:46 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:46 --> Router Class Initialized
INFO - 2025-04-03 21:13:46 --> Output Class Initialized
INFO - 2025-04-03 21:13:46 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:46 --> Input Class Initialized
INFO - 2025-04-03 21:13:46 --> Language Class Initialized
INFO - 2025-04-03 21:13:46 --> Language Class Initialized
INFO - 2025-04-03 21:13:46 --> Config Class Initialized
INFO - 2025-04-03 21:13:46 --> Loader Class Initialized
INFO - 2025-04-03 21:13:46 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:46 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:46 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:46 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:46 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:46 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:46 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:46 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:46 --> Email Class Initialized
INFO - 2025-04-03 21:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:46 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:46 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:46 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 21:13:51 --> Config Class Initialized
INFO - 2025-04-03 21:13:51 --> Hooks Class Initialized
DEBUG - 2025-04-03 21:13:51 --> UTF-8 Support Enabled
INFO - 2025-04-03 21:13:51 --> Utf8 Class Initialized
INFO - 2025-04-03 21:13:51 --> URI Class Initialized
DEBUG - 2025-04-03 21:13:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 21:13:51 --> Router Class Initialized
INFO - 2025-04-03 21:13:51 --> Output Class Initialized
INFO - 2025-04-03 21:13:51 --> Security Class Initialized
DEBUG - 2025-04-03 21:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 21:13:51 --> Input Class Initialized
INFO - 2025-04-03 21:13:51 --> Language Class Initialized
INFO - 2025-04-03 21:13:51 --> Language Class Initialized
INFO - 2025-04-03 21:13:51 --> Config Class Initialized
INFO - 2025-04-03 21:13:51 --> Loader Class Initialized
INFO - 2025-04-03 21:13:51 --> Helper loaded: url_helper
INFO - 2025-04-03 21:13:51 --> Helper loaded: file_helper
INFO - 2025-04-03 21:13:51 --> Helper loaded: html_helper
INFO - 2025-04-03 21:13:51 --> Helper loaded: form_helper
INFO - 2025-04-03 21:13:51 --> Helper loaded: text_helper
INFO - 2025-04-03 21:13:51 --> Helper loaded: lang_helper
INFO - 2025-04-03 21:13:51 --> Helper loaded: directory_helper
INFO - 2025-04-03 21:13:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 21:13:51 --> Database Driver Class Initialized
INFO - 2025-04-03 21:13:51 --> Email Class Initialized
INFO - 2025-04-03 21:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 21:13:51 --> Form Validation Class Initialized
INFO - 2025-04-03 21:13:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 21:13:51 --> Pagination Class Initialized
INFO - 2025-04-03 21:13:51 --> Controller Class Initialized
DEBUG - 2025-04-03 21:13:51 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 22:44:04 --> Config Class Initialized
INFO - 2025-04-03 22:44:04 --> Hooks Class Initialized
DEBUG - 2025-04-03 22:44:04 --> UTF-8 Support Enabled
INFO - 2025-04-03 22:44:04 --> Utf8 Class Initialized
INFO - 2025-04-03 22:44:04 --> URI Class Initialized
DEBUG - 2025-04-03 22:44:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-03 22:44:04 --> Router Class Initialized
INFO - 2025-04-03 22:44:04 --> Output Class Initialized
INFO - 2025-04-03 22:44:04 --> Security Class Initialized
DEBUG - 2025-04-03 22:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 22:44:04 --> Input Class Initialized
INFO - 2025-04-03 22:44:04 --> Language Class Initialized
INFO - 2025-04-03 22:44:04 --> Language Class Initialized
INFO - 2025-04-03 22:44:04 --> Config Class Initialized
INFO - 2025-04-03 22:44:04 --> Loader Class Initialized
INFO - 2025-04-03 22:44:04 --> Helper loaded: url_helper
INFO - 2025-04-03 22:44:04 --> Helper loaded: file_helper
INFO - 2025-04-03 22:44:04 --> Helper loaded: html_helper
INFO - 2025-04-03 22:44:04 --> Helper loaded: form_helper
INFO - 2025-04-03 22:44:04 --> Helper loaded: text_helper
INFO - 2025-04-03 22:44:04 --> Helper loaded: lang_helper
INFO - 2025-04-03 22:44:04 --> Helper loaded: directory_helper
INFO - 2025-04-03 22:44:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 22:44:04 --> Database Driver Class Initialized
INFO - 2025-04-03 22:44:04 --> Email Class Initialized
INFO - 2025-04-03 22:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 22:44:04 --> Form Validation Class Initialized
INFO - 2025-04-03 22:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 22:44:04 --> Pagination Class Initialized
INFO - 2025-04-03 22:44:04 --> Controller Class Initialized
DEBUG - 2025-04-03 22:44:04 --> Invoice MX_Controller Initialized
INFO - 2025-04-03 22:44:12 --> Config Class Initialized
INFO - 2025-04-03 22:44:12 --> Hooks Class Initialized
DEBUG - 2025-04-03 22:44:12 --> UTF-8 Support Enabled
INFO - 2025-04-03 22:44:12 --> Utf8 Class Initialized
INFO - 2025-04-03 22:44:12 --> URI Class Initialized
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 22:44:12 --> Router Class Initialized
INFO - 2025-04-03 22:44:12 --> Output Class Initialized
INFO - 2025-04-03 22:44:12 --> Security Class Initialized
DEBUG - 2025-04-03 22:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 22:44:12 --> Input Class Initialized
INFO - 2025-04-03 22:44:12 --> Language Class Initialized
INFO - 2025-04-03 22:44:12 --> Language Class Initialized
INFO - 2025-04-03 22:44:12 --> Config Class Initialized
INFO - 2025-04-03 22:44:12 --> Loader Class Initialized
INFO - 2025-04-03 22:44:12 --> Helper loaded: url_helper
INFO - 2025-04-03 22:44:12 --> Helper loaded: file_helper
INFO - 2025-04-03 22:44:12 --> Helper loaded: html_helper
INFO - 2025-04-03 22:44:12 --> Helper loaded: form_helper
INFO - 2025-04-03 22:44:12 --> Helper loaded: text_helper
INFO - 2025-04-03 22:44:12 --> Helper loaded: lang_helper
INFO - 2025-04-03 22:44:12 --> Helper loaded: directory_helper
INFO - 2025-04-03 22:44:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 22:44:12 --> Database Driver Class Initialized
INFO - 2025-04-03 22:44:12 --> Email Class Initialized
INFO - 2025-04-03 22:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 22:44:12 --> Form Validation Class Initialized
INFO - 2025-04-03 22:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 22:44:12 --> Pagination Class Initialized
INFO - 2025-04-03 22:44:12 --> Controller Class Initialized
DEBUG - 2025-04-03 22:44:12 --> Customer MX_Controller Initialized
INFO - 2025-04-03 22:44:12 --> Model Class Initialized
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 22:44:12 --> Model Class Initialized
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 22:44:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 22:44:12 --> Model Class Initialized
ERROR - 2025-04-03 22:44:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 22:44:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 22:44:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 22:44:12 --> Final output sent to browser
DEBUG - 2025-04-03 22:44:12 --> Total execution time: 0.2253
INFO - 2025-04-03 22:44:12 --> Config Class Initialized
INFO - 2025-04-03 22:44:12 --> Hooks Class Initialized
DEBUG - 2025-04-03 22:44:12 --> UTF-8 Support Enabled
INFO - 2025-04-03 22:44:12 --> Utf8 Class Initialized
INFO - 2025-04-03 22:44:12 --> URI Class Initialized
DEBUG - 2025-04-03 22:44:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 22:44:13 --> Router Class Initialized
INFO - 2025-04-03 22:44:13 --> Output Class Initialized
INFO - 2025-04-03 22:44:13 --> Security Class Initialized
DEBUG - 2025-04-03 22:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 22:44:13 --> Input Class Initialized
INFO - 2025-04-03 22:44:13 --> Language Class Initialized
INFO - 2025-04-03 22:44:13 --> Language Class Initialized
INFO - 2025-04-03 22:44:13 --> Config Class Initialized
INFO - 2025-04-03 22:44:13 --> Loader Class Initialized
INFO - 2025-04-03 22:44:13 --> Helper loaded: url_helper
INFO - 2025-04-03 22:44:13 --> Helper loaded: file_helper
INFO - 2025-04-03 22:44:13 --> Helper loaded: html_helper
INFO - 2025-04-03 22:44:13 --> Helper loaded: form_helper
INFO - 2025-04-03 22:44:13 --> Helper loaded: text_helper
INFO - 2025-04-03 22:44:13 --> Helper loaded: lang_helper
INFO - 2025-04-03 22:44:13 --> Helper loaded: directory_helper
INFO - 2025-04-03 22:44:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 22:44:13 --> Database Driver Class Initialized
INFO - 2025-04-03 22:44:13 --> Email Class Initialized
INFO - 2025-04-03 22:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 22:44:13 --> Form Validation Class Initialized
INFO - 2025-04-03 22:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 22:44:13 --> Pagination Class Initialized
INFO - 2025-04-03 22:44:13 --> Controller Class Initialized
DEBUG - 2025-04-03 22:44:13 --> Customer MX_Controller Initialized
INFO - 2025-04-03 22:44:13 --> Model Class Initialized
DEBUG - 2025-04-03 22:44:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 22:44:13 --> Model Class Initialized
ERROR - 2025-04-03 22:44:13 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 22:44:13 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 22:44:13 --> Received customer_id: null
ERROR - 2025-04-03 22:44:13 --> Received customfiled: null
ERROR - 2025-04-03 22:44:13 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 22:44:13 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 22:44:13 --> Search value: 
ERROR - 2025-04-03 22:44:13 --> Total unfiltered records: 15
ERROR - 2025-04-03 22:44:13 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 22:44:13 --> Records fetched from DB: 15
ERROR - 2025-04-03 22:44:13 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 22:44:13 --> ========= getCustomerList() END =========
INFO - 2025-04-03 22:44:15 --> Config Class Initialized
INFO - 2025-04-03 22:44:15 --> Hooks Class Initialized
DEBUG - 2025-04-03 22:44:15 --> UTF-8 Support Enabled
INFO - 2025-04-03 22:44:15 --> Utf8 Class Initialized
INFO - 2025-04-03 22:44:15 --> URI Class Initialized
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 22:44:15 --> Router Class Initialized
INFO - 2025-04-03 22:44:15 --> Output Class Initialized
INFO - 2025-04-03 22:44:15 --> Security Class Initialized
DEBUG - 2025-04-03 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 22:44:15 --> Input Class Initialized
INFO - 2025-04-03 22:44:15 --> Language Class Initialized
INFO - 2025-04-03 22:44:15 --> Language Class Initialized
INFO - 2025-04-03 22:44:15 --> Config Class Initialized
INFO - 2025-04-03 22:44:15 --> Loader Class Initialized
INFO - 2025-04-03 22:44:15 --> Helper loaded: url_helper
INFO - 2025-04-03 22:44:15 --> Helper loaded: file_helper
INFO - 2025-04-03 22:44:15 --> Helper loaded: html_helper
INFO - 2025-04-03 22:44:15 --> Helper loaded: form_helper
INFO - 2025-04-03 22:44:15 --> Helper loaded: text_helper
INFO - 2025-04-03 22:44:15 --> Helper loaded: lang_helper
INFO - 2025-04-03 22:44:15 --> Helper loaded: directory_helper
INFO - 2025-04-03 22:44:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 22:44:15 --> Database Driver Class Initialized
INFO - 2025-04-03 22:44:15 --> Email Class Initialized
INFO - 2025-04-03 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 22:44:15 --> Form Validation Class Initialized
INFO - 2025-04-03 22:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 22:44:15 --> Pagination Class Initialized
INFO - 2025-04-03 22:44:15 --> Controller Class Initialized
DEBUG - 2025-04-03 22:44:15 --> Customer MX_Controller Initialized
INFO - 2025-04-03 22:44:15 --> Model Class Initialized
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 22:44:15 --> Model Class Initialized
ERROR - 2025-04-03 22:44:15 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 22:44:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 22:44:15 --> Model Class Initialized
ERROR - 2025-04-03 22:44:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 22:44:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 22:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 22:44:15 --> Final output sent to browser
DEBUG - 2025-04-03 22:44:15 --> Total execution time: 0.2414
INFO - 2025-04-03 22:53:39 --> Config Class Initialized
INFO - 2025-04-03 22:53:39 --> Hooks Class Initialized
DEBUG - 2025-04-03 22:53:39 --> UTF-8 Support Enabled
INFO - 2025-04-03 22:53:39 --> Utf8 Class Initialized
INFO - 2025-04-03 22:53:39 --> URI Class Initialized
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 22:53:39 --> Router Class Initialized
INFO - 2025-04-03 22:53:39 --> Output Class Initialized
INFO - 2025-04-03 22:53:39 --> Security Class Initialized
DEBUG - 2025-04-03 22:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 22:53:39 --> Input Class Initialized
INFO - 2025-04-03 22:53:39 --> Language Class Initialized
INFO - 2025-04-03 22:53:39 --> Language Class Initialized
INFO - 2025-04-03 22:53:39 --> Config Class Initialized
INFO - 2025-04-03 22:53:39 --> Loader Class Initialized
INFO - 2025-04-03 22:53:39 --> Helper loaded: url_helper
INFO - 2025-04-03 22:53:39 --> Helper loaded: file_helper
INFO - 2025-04-03 22:53:39 --> Helper loaded: html_helper
INFO - 2025-04-03 22:53:39 --> Helper loaded: form_helper
INFO - 2025-04-03 22:53:39 --> Helper loaded: text_helper
INFO - 2025-04-03 22:53:39 --> Helper loaded: lang_helper
INFO - 2025-04-03 22:53:39 --> Helper loaded: directory_helper
INFO - 2025-04-03 22:53:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 22:53:39 --> Database Driver Class Initialized
INFO - 2025-04-03 22:53:39 --> Email Class Initialized
INFO - 2025-04-03 22:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 22:53:39 --> Form Validation Class Initialized
INFO - 2025-04-03 22:53:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 22:53:39 --> Pagination Class Initialized
INFO - 2025-04-03 22:53:39 --> Controller Class Initialized
DEBUG - 2025-04-03 22:53:39 --> Customer MX_Controller Initialized
INFO - 2025-04-03 22:53:39 --> Model Class Initialized
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 22:53:39 --> Model Class Initialized
ERROR - 2025-04-03 22:53:39 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 22:53:39 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 22:53:39 --> Model Class Initialized
ERROR - 2025-04-03 22:53:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 22:53:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 22:53:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 22:53:39 --> Final output sent to browser
DEBUG - 2025-04-03 22:53:39 --> Total execution time: 0.3192
INFO - 2025-04-03 22:58:36 --> Config Class Initialized
INFO - 2025-04-03 22:58:36 --> Hooks Class Initialized
DEBUG - 2025-04-03 22:58:36 --> UTF-8 Support Enabled
INFO - 2025-04-03 22:58:36 --> Utf8 Class Initialized
INFO - 2025-04-03 22:58:36 --> URI Class Initialized
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 22:58:36 --> Router Class Initialized
INFO - 2025-04-03 22:58:36 --> Output Class Initialized
INFO - 2025-04-03 22:58:36 --> Security Class Initialized
DEBUG - 2025-04-03 22:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 22:58:36 --> Input Class Initialized
INFO - 2025-04-03 22:58:36 --> Language Class Initialized
INFO - 2025-04-03 22:58:36 --> Language Class Initialized
INFO - 2025-04-03 22:58:36 --> Config Class Initialized
INFO - 2025-04-03 22:58:36 --> Loader Class Initialized
INFO - 2025-04-03 22:58:36 --> Helper loaded: url_helper
INFO - 2025-04-03 22:58:36 --> Helper loaded: file_helper
INFO - 2025-04-03 22:58:36 --> Helper loaded: html_helper
INFO - 2025-04-03 22:58:36 --> Helper loaded: form_helper
INFO - 2025-04-03 22:58:36 --> Helper loaded: text_helper
INFO - 2025-04-03 22:58:36 --> Helper loaded: lang_helper
INFO - 2025-04-03 22:58:36 --> Helper loaded: directory_helper
INFO - 2025-04-03 22:58:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 22:58:36 --> Database Driver Class Initialized
INFO - 2025-04-03 22:58:36 --> Email Class Initialized
INFO - 2025-04-03 22:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 22:58:36 --> Form Validation Class Initialized
INFO - 2025-04-03 22:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 22:58:36 --> Pagination Class Initialized
INFO - 2025-04-03 22:58:36 --> Controller Class Initialized
DEBUG - 2025-04-03 22:58:36 --> Customer MX_Controller Initialized
INFO - 2025-04-03 22:58:36 --> Model Class Initialized
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 22:58:36 --> Model Class Initialized
ERROR - 2025-04-03 22:58:36 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 22:58:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 22:58:36 --> Model Class Initialized
ERROR - 2025-04-03 22:58:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 22:58:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 22:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 22:58:36 --> Final output sent to browser
DEBUG - 2025-04-03 22:58:36 --> Total execution time: 0.1352
INFO - 2025-04-03 22:59:27 --> Config Class Initialized
INFO - 2025-04-03 22:59:27 --> Hooks Class Initialized
DEBUG - 2025-04-03 22:59:27 --> UTF-8 Support Enabled
INFO - 2025-04-03 22:59:27 --> Utf8 Class Initialized
INFO - 2025-04-03 22:59:27 --> URI Class Initialized
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 22:59:27 --> Router Class Initialized
INFO - 2025-04-03 22:59:27 --> Output Class Initialized
INFO - 2025-04-03 22:59:27 --> Security Class Initialized
DEBUG - 2025-04-03 22:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 22:59:27 --> Input Class Initialized
INFO - 2025-04-03 22:59:27 --> Language Class Initialized
INFO - 2025-04-03 22:59:27 --> Language Class Initialized
INFO - 2025-04-03 22:59:27 --> Config Class Initialized
INFO - 2025-04-03 22:59:27 --> Loader Class Initialized
INFO - 2025-04-03 22:59:27 --> Helper loaded: url_helper
INFO - 2025-04-03 22:59:27 --> Helper loaded: file_helper
INFO - 2025-04-03 22:59:27 --> Helper loaded: html_helper
INFO - 2025-04-03 22:59:27 --> Helper loaded: form_helper
INFO - 2025-04-03 22:59:27 --> Helper loaded: text_helper
INFO - 2025-04-03 22:59:27 --> Helper loaded: lang_helper
INFO - 2025-04-03 22:59:27 --> Helper loaded: directory_helper
INFO - 2025-04-03 22:59:27 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 22:59:27 --> Database Driver Class Initialized
INFO - 2025-04-03 22:59:27 --> Email Class Initialized
INFO - 2025-04-03 22:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 22:59:27 --> Form Validation Class Initialized
INFO - 2025-04-03 22:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 22:59:27 --> Pagination Class Initialized
INFO - 2025-04-03 22:59:27 --> Controller Class Initialized
DEBUG - 2025-04-03 22:59:27 --> Customer MX_Controller Initialized
INFO - 2025-04-03 22:59:27 --> Model Class Initialized
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 22:59:27 --> Model Class Initialized
ERROR - 2025-04-03 22:59:27 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 22:59:27 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 22:59:27 --> Model Class Initialized
ERROR - 2025-04-03 22:59:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 22:59:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 22:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 22:59:27 --> Final output sent to browser
DEBUG - 2025-04-03 22:59:27 --> Total execution time: 0.1614
INFO - 2025-04-03 23:00:16 --> Config Class Initialized
INFO - 2025-04-03 23:00:16 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:00:16 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:00:16 --> Utf8 Class Initialized
INFO - 2025-04-03 23:00:16 --> URI Class Initialized
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:00:16 --> Router Class Initialized
INFO - 2025-04-03 23:00:16 --> Output Class Initialized
INFO - 2025-04-03 23:00:16 --> Security Class Initialized
DEBUG - 2025-04-03 23:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:00:16 --> Input Class Initialized
INFO - 2025-04-03 23:00:16 --> Language Class Initialized
INFO - 2025-04-03 23:00:16 --> Language Class Initialized
INFO - 2025-04-03 23:00:16 --> Config Class Initialized
INFO - 2025-04-03 23:00:16 --> Loader Class Initialized
INFO - 2025-04-03 23:00:16 --> Helper loaded: url_helper
INFO - 2025-04-03 23:00:16 --> Helper loaded: file_helper
INFO - 2025-04-03 23:00:16 --> Helper loaded: html_helper
INFO - 2025-04-03 23:00:16 --> Helper loaded: form_helper
INFO - 2025-04-03 23:00:16 --> Helper loaded: text_helper
INFO - 2025-04-03 23:00:16 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:00:16 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:00:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:00:16 --> Database Driver Class Initialized
INFO - 2025-04-03 23:00:16 --> Email Class Initialized
INFO - 2025-04-03 23:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:00:16 --> Form Validation Class Initialized
INFO - 2025-04-03 23:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:00:16 --> Pagination Class Initialized
INFO - 2025-04-03 23:00:16 --> Controller Class Initialized
DEBUG - 2025-04-03 23:00:16 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:00:16 --> Model Class Initialized
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:00:16 --> Model Class Initialized
ERROR - 2025-04-03 23:00:16 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:00:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:00:16 --> Model Class Initialized
ERROR - 2025-04-03 23:00:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:00:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:00:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:00:16 --> Final output sent to browser
DEBUG - 2025-04-03 23:00:16 --> Total execution time: 0.1707
INFO - 2025-04-03 23:00:49 --> Config Class Initialized
INFO - 2025-04-03 23:00:49 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:00:49 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:00:49 --> Utf8 Class Initialized
INFO - 2025-04-03 23:00:49 --> URI Class Initialized
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:00:49 --> Router Class Initialized
INFO - 2025-04-03 23:00:49 --> Output Class Initialized
INFO - 2025-04-03 23:00:49 --> Security Class Initialized
DEBUG - 2025-04-03 23:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:00:49 --> Input Class Initialized
INFO - 2025-04-03 23:00:49 --> Language Class Initialized
INFO - 2025-04-03 23:00:49 --> Language Class Initialized
INFO - 2025-04-03 23:00:49 --> Config Class Initialized
INFO - 2025-04-03 23:00:49 --> Loader Class Initialized
INFO - 2025-04-03 23:00:49 --> Helper loaded: url_helper
INFO - 2025-04-03 23:00:49 --> Helper loaded: file_helper
INFO - 2025-04-03 23:00:49 --> Helper loaded: html_helper
INFO - 2025-04-03 23:00:49 --> Helper loaded: form_helper
INFO - 2025-04-03 23:00:49 --> Helper loaded: text_helper
INFO - 2025-04-03 23:00:49 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:00:49 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:00:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:00:49 --> Database Driver Class Initialized
INFO - 2025-04-03 23:00:49 --> Email Class Initialized
INFO - 2025-04-03 23:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:00:49 --> Form Validation Class Initialized
INFO - 2025-04-03 23:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:00:49 --> Pagination Class Initialized
INFO - 2025-04-03 23:00:49 --> Controller Class Initialized
DEBUG - 2025-04-03 23:00:49 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:00:49 --> Model Class Initialized
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:00:49 --> Model Class Initialized
ERROR - 2025-04-03 23:00:49 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:00:49 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:00:49 --> Model Class Initialized
ERROR - 2025-04-03 23:00:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:00:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:00:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:00:49 --> Final output sent to browser
DEBUG - 2025-04-03 23:00:49 --> Total execution time: 0.1295
INFO - 2025-04-03 23:01:55 --> Config Class Initialized
INFO - 2025-04-03 23:01:55 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:01:55 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:01:55 --> Utf8 Class Initialized
INFO - 2025-04-03 23:01:55 --> URI Class Initialized
DEBUG - 2025-04-03 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:01:55 --> Router Class Initialized
INFO - 2025-04-03 23:01:55 --> Output Class Initialized
INFO - 2025-04-03 23:01:55 --> Security Class Initialized
DEBUG - 2025-04-03 23:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:01:55 --> Input Class Initialized
INFO - 2025-04-03 23:01:55 --> Language Class Initialized
INFO - 2025-04-03 23:01:55 --> Language Class Initialized
INFO - 2025-04-03 23:01:55 --> Config Class Initialized
INFO - 2025-04-03 23:01:55 --> Loader Class Initialized
INFO - 2025-04-03 23:01:55 --> Helper loaded: url_helper
INFO - 2025-04-03 23:01:55 --> Helper loaded: file_helper
INFO - 2025-04-03 23:01:55 --> Helper loaded: html_helper
INFO - 2025-04-03 23:01:55 --> Helper loaded: form_helper
INFO - 2025-04-03 23:01:55 --> Helper loaded: text_helper
INFO - 2025-04-03 23:01:55 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:01:55 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:01:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:01:55 --> Database Driver Class Initialized
INFO - 2025-04-03 23:01:55 --> Email Class Initialized
INFO - 2025-04-03 23:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:01:55 --> Form Validation Class Initialized
INFO - 2025-04-03 23:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:01:55 --> Pagination Class Initialized
INFO - 2025-04-03 23:01:55 --> Controller Class Initialized
DEBUG - 2025-04-03 23:01:55 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:01:55 --> Model Class Initialized
DEBUG - 2025-04-03 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:01:55 --> Model Class Initialized
ERROR - 2025-04-03 23:01:55 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-04-03 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:01:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:01:55 --> Model Class Initialized
ERROR - 2025-04-03 23:01:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:01:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:01:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:01:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:01:56 --> Final output sent to browser
DEBUG - 2025-04-03 23:01:56 --> Total execution time: 0.1978
INFO - 2025-04-03 23:15:03 --> Config Class Initialized
INFO - 2025-04-03 23:15:03 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:15:03 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:15:03 --> Utf8 Class Initialized
INFO - 2025-04-03 23:15:03 --> URI Class Initialized
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:15:03 --> Router Class Initialized
INFO - 2025-04-03 23:15:03 --> Output Class Initialized
INFO - 2025-04-03 23:15:03 --> Security Class Initialized
DEBUG - 2025-04-03 23:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:15:03 --> Input Class Initialized
INFO - 2025-04-03 23:15:03 --> Language Class Initialized
INFO - 2025-04-03 23:15:03 --> Language Class Initialized
INFO - 2025-04-03 23:15:03 --> Config Class Initialized
INFO - 2025-04-03 23:15:03 --> Loader Class Initialized
INFO - 2025-04-03 23:15:03 --> Helper loaded: url_helper
INFO - 2025-04-03 23:15:03 --> Helper loaded: file_helper
INFO - 2025-04-03 23:15:03 --> Helper loaded: html_helper
INFO - 2025-04-03 23:15:03 --> Helper loaded: form_helper
INFO - 2025-04-03 23:15:03 --> Helper loaded: text_helper
INFO - 2025-04-03 23:15:03 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:15:03 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:15:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:15:03 --> Database Driver Class Initialized
INFO - 2025-04-03 23:15:03 --> Email Class Initialized
INFO - 2025-04-03 23:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:15:03 --> Form Validation Class Initialized
INFO - 2025-04-03 23:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:15:03 --> Pagination Class Initialized
INFO - 2025-04-03 23:15:03 --> Controller Class Initialized
DEBUG - 2025-04-03 23:15:03 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:15:03 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:15:03 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:15:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:15:03 --> Model Class Initialized
ERROR - 2025-04-03 23:15:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:15:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:15:03 --> Final output sent to browser
DEBUG - 2025-04-03 23:15:03 --> Total execution time: 0.1655
INFO - 2025-04-03 23:15:09 --> Config Class Initialized
INFO - 2025-04-03 23:15:09 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:15:09 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:15:09 --> Utf8 Class Initialized
INFO - 2025-04-03 23:15:09 --> URI Class Initialized
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:15:09 --> Router Class Initialized
INFO - 2025-04-03 23:15:09 --> Output Class Initialized
INFO - 2025-04-03 23:15:09 --> Security Class Initialized
DEBUG - 2025-04-03 23:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:15:09 --> Input Class Initialized
INFO - 2025-04-03 23:15:09 --> Language Class Initialized
INFO - 2025-04-03 23:15:09 --> Language Class Initialized
INFO - 2025-04-03 23:15:09 --> Config Class Initialized
INFO - 2025-04-03 23:15:09 --> Loader Class Initialized
INFO - 2025-04-03 23:15:09 --> Helper loaded: url_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: file_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: html_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: form_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: text_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:15:09 --> Database Driver Class Initialized
INFO - 2025-04-03 23:15:09 --> Email Class Initialized
INFO - 2025-04-03 23:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:15:09 --> Form Validation Class Initialized
INFO - 2025-04-03 23:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:15:09 --> Pagination Class Initialized
INFO - 2025-04-03 23:15:09 --> Controller Class Initialized
DEBUG - 2025-04-03 23:15:09 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:15:09 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:15:09 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:15:09 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:15:09 --> Model Class Initialized
ERROR - 2025-04-03 23:15:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:15:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:15:09 --> Final output sent to browser
DEBUG - 2025-04-03 23:15:09 --> Total execution time: 0.1731
INFO - 2025-04-03 23:15:09 --> Config Class Initialized
INFO - 2025-04-03 23:15:09 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:15:09 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:15:09 --> Utf8 Class Initialized
INFO - 2025-04-03 23:15:09 --> URI Class Initialized
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:15:09 --> Router Class Initialized
INFO - 2025-04-03 23:15:09 --> Output Class Initialized
INFO - 2025-04-03 23:15:09 --> Security Class Initialized
DEBUG - 2025-04-03 23:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:15:09 --> Input Class Initialized
INFO - 2025-04-03 23:15:09 --> Language Class Initialized
INFO - 2025-04-03 23:15:09 --> Language Class Initialized
INFO - 2025-04-03 23:15:09 --> Config Class Initialized
INFO - 2025-04-03 23:15:09 --> Loader Class Initialized
INFO - 2025-04-03 23:15:09 --> Helper loaded: url_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: file_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: html_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: form_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: text_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:15:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:15:09 --> Database Driver Class Initialized
INFO - 2025-04-03 23:15:09 --> Email Class Initialized
INFO - 2025-04-03 23:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:15:09 --> Form Validation Class Initialized
INFO - 2025-04-03 23:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:15:09 --> Pagination Class Initialized
INFO - 2025-04-03 23:15:09 --> Controller Class Initialized
DEBUG - 2025-04-03 23:15:09 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:15:09 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:15:09 --> Model Class Initialized
ERROR - 2025-04-03 23:15:09 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:15:09 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:15:09 --> Received customer_id: null
ERROR - 2025-04-03 23:15:09 --> Received customfiled: null
ERROR - 2025-04-03 23:15:09 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:15:09 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:15:09 --> Search value: 
ERROR - 2025-04-03 23:15:09 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:15:09 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:15:09 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:15:09 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:15:09 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:15:20 --> Config Class Initialized
INFO - 2025-04-03 23:15:20 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:15:20 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:15:20 --> Utf8 Class Initialized
INFO - 2025-04-03 23:15:20 --> URI Class Initialized
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:15:20 --> Router Class Initialized
INFO - 2025-04-03 23:15:20 --> Output Class Initialized
INFO - 2025-04-03 23:15:20 --> Security Class Initialized
DEBUG - 2025-04-03 23:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:15:20 --> Input Class Initialized
INFO - 2025-04-03 23:15:20 --> Language Class Initialized
INFO - 2025-04-03 23:15:20 --> Language Class Initialized
INFO - 2025-04-03 23:15:20 --> Config Class Initialized
INFO - 2025-04-03 23:15:20 --> Loader Class Initialized
INFO - 2025-04-03 23:15:20 --> Helper loaded: url_helper
INFO - 2025-04-03 23:15:20 --> Helper loaded: file_helper
INFO - 2025-04-03 23:15:20 --> Helper loaded: html_helper
INFO - 2025-04-03 23:15:20 --> Helper loaded: form_helper
INFO - 2025-04-03 23:15:20 --> Helper loaded: text_helper
INFO - 2025-04-03 23:15:20 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:15:20 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:15:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:15:20 --> Database Driver Class Initialized
INFO - 2025-04-03 23:15:20 --> Email Class Initialized
INFO - 2025-04-03 23:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:15:20 --> Form Validation Class Initialized
INFO - 2025-04-03 23:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:15:20 --> Pagination Class Initialized
INFO - 2025-04-03 23:15:20 --> Controller Class Initialized
DEBUG - 2025-04-03 23:15:20 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:15:20 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:15:20 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:15:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:15:20 --> Model Class Initialized
ERROR - 2025-04-03 23:15:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:15:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:15:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:15:20 --> Final output sent to browser
DEBUG - 2025-04-03 23:15:20 --> Total execution time: 0.2217
INFO - 2025-04-03 23:15:58 --> Config Class Initialized
INFO - 2025-04-03 23:15:58 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:15:58 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:15:58 --> Utf8 Class Initialized
INFO - 2025-04-03 23:15:58 --> URI Class Initialized
DEBUG - 2025-04-03 23:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:15:58 --> Router Class Initialized
INFO - 2025-04-03 23:15:58 --> Output Class Initialized
INFO - 2025-04-03 23:15:58 --> Security Class Initialized
DEBUG - 2025-04-03 23:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:15:58 --> Input Class Initialized
INFO - 2025-04-03 23:15:58 --> Language Class Initialized
INFO - 2025-04-03 23:15:58 --> Language Class Initialized
INFO - 2025-04-03 23:15:58 --> Config Class Initialized
INFO - 2025-04-03 23:15:58 --> Loader Class Initialized
INFO - 2025-04-03 23:15:58 --> Helper loaded: url_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: file_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: html_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: form_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: text_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:15:58 --> Database Driver Class Initialized
INFO - 2025-04-03 23:15:58 --> Email Class Initialized
INFO - 2025-04-03 23:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:15:58 --> Form Validation Class Initialized
INFO - 2025-04-03 23:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:15:58 --> Pagination Class Initialized
INFO - 2025-04-03 23:15:58 --> Controller Class Initialized
DEBUG - 2025-04-03 23:15:58 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:15:58 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:15:58 --> Model Class Initialized
INFO - 2025-04-03 23:15:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 23:15:58 --> Config Class Initialized
INFO - 2025-04-03 23:15:58 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:15:58 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:15:58 --> Utf8 Class Initialized
INFO - 2025-04-03 23:15:58 --> URI Class Initialized
DEBUG - 2025-04-03 23:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:15:58 --> Router Class Initialized
INFO - 2025-04-03 23:15:58 --> Output Class Initialized
INFO - 2025-04-03 23:15:58 --> Security Class Initialized
DEBUG - 2025-04-03 23:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:15:58 --> Input Class Initialized
INFO - 2025-04-03 23:15:58 --> Language Class Initialized
INFO - 2025-04-03 23:15:58 --> Language Class Initialized
INFO - 2025-04-03 23:15:58 --> Config Class Initialized
INFO - 2025-04-03 23:15:58 --> Loader Class Initialized
INFO - 2025-04-03 23:15:58 --> Helper loaded: url_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: file_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: html_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: form_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: text_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:15:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:15:58 --> Database Driver Class Initialized
INFO - 2025-04-03 23:15:58 --> Email Class Initialized
INFO - 2025-04-03 23:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:15:58 --> Form Validation Class Initialized
INFO - 2025-04-03 23:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:15:58 --> Pagination Class Initialized
INFO - 2025-04-03 23:15:58 --> Controller Class Initialized
DEBUG - 2025-04-03 23:15:58 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:15:58 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:15:58 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:15:58 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:15:59 --> Model Class Initialized
ERROR - 2025-04-03 23:15:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:15:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:15:59 --> Final output sent to browser
DEBUG - 2025-04-03 23:15:59 --> Total execution time: 0.1409
INFO - 2025-04-03 23:15:59 --> Config Class Initialized
INFO - 2025-04-03 23:15:59 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:15:59 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:15:59 --> Utf8 Class Initialized
INFO - 2025-04-03 23:15:59 --> URI Class Initialized
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:15:59 --> Router Class Initialized
INFO - 2025-04-03 23:15:59 --> Output Class Initialized
INFO - 2025-04-03 23:15:59 --> Security Class Initialized
DEBUG - 2025-04-03 23:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:15:59 --> Input Class Initialized
INFO - 2025-04-03 23:15:59 --> Language Class Initialized
INFO - 2025-04-03 23:15:59 --> Language Class Initialized
INFO - 2025-04-03 23:15:59 --> Config Class Initialized
INFO - 2025-04-03 23:15:59 --> Loader Class Initialized
INFO - 2025-04-03 23:15:59 --> Helper loaded: url_helper
INFO - 2025-04-03 23:15:59 --> Helper loaded: file_helper
INFO - 2025-04-03 23:15:59 --> Helper loaded: html_helper
INFO - 2025-04-03 23:15:59 --> Helper loaded: form_helper
INFO - 2025-04-03 23:15:59 --> Helper loaded: text_helper
INFO - 2025-04-03 23:15:59 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:15:59 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:15:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:15:59 --> Database Driver Class Initialized
INFO - 2025-04-03 23:15:59 --> Email Class Initialized
INFO - 2025-04-03 23:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:15:59 --> Form Validation Class Initialized
INFO - 2025-04-03 23:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:15:59 --> Pagination Class Initialized
INFO - 2025-04-03 23:15:59 --> Controller Class Initialized
DEBUG - 2025-04-03 23:15:59 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:15:59 --> Model Class Initialized
DEBUG - 2025-04-03 23:15:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:15:59 --> Model Class Initialized
ERROR - 2025-04-03 23:15:59 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:15:59 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:15:59 --> Received customer_id: null
ERROR - 2025-04-03 23:15:59 --> Received customfiled: null
ERROR - 2025-04-03 23:15:59 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:15:59 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:15:59 --> Search value: 
ERROR - 2025-04-03 23:15:59 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:15:59 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:15:59 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:15:59 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:15:59 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:16:36 --> Config Class Initialized
INFO - 2025-04-03 23:16:36 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:16:36 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:16:36 --> Utf8 Class Initialized
INFO - 2025-04-03 23:16:36 --> URI Class Initialized
DEBUG - 2025-04-03 23:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:16:36 --> Router Class Initialized
INFO - 2025-04-03 23:16:36 --> Output Class Initialized
INFO - 2025-04-03 23:16:36 --> Security Class Initialized
DEBUG - 2025-04-03 23:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:16:36 --> Input Class Initialized
INFO - 2025-04-03 23:16:36 --> Language Class Initialized
INFO - 2025-04-03 23:16:36 --> Language Class Initialized
INFO - 2025-04-03 23:16:36 --> Config Class Initialized
INFO - 2025-04-03 23:16:36 --> Loader Class Initialized
INFO - 2025-04-03 23:16:36 --> Helper loaded: url_helper
INFO - 2025-04-03 23:16:36 --> Helper loaded: file_helper
INFO - 2025-04-03 23:16:36 --> Helper loaded: html_helper
INFO - 2025-04-03 23:16:36 --> Helper loaded: form_helper
INFO - 2025-04-03 23:16:36 --> Helper loaded: text_helper
INFO - 2025-04-03 23:16:36 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:16:36 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:16:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:16:36 --> Database Driver Class Initialized
INFO - 2025-04-03 23:16:36 --> Email Class Initialized
INFO - 2025-04-03 23:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:16:36 --> Form Validation Class Initialized
INFO - 2025-04-03 23:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:16:36 --> Pagination Class Initialized
INFO - 2025-04-03 23:16:36 --> Controller Class Initialized
DEBUG - 2025-04-03 23:16:36 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:16:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:16:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:16:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:16:36 --> Model Class Initialized
ERROR - 2025-04-03 23:16:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:16:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:16:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:16:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:16:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:16:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:16:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:16:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:16:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:16:37 --> Final output sent to browser
DEBUG - 2025-04-03 23:16:37 --> Total execution time: 0.1429
INFO - 2025-04-03 23:16:49 --> Config Class Initialized
INFO - 2025-04-03 23:16:49 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:16:49 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:16:49 --> Utf8 Class Initialized
INFO - 2025-04-03 23:16:49 --> URI Class Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:16:49 --> Router Class Initialized
INFO - 2025-04-03 23:16:49 --> Output Class Initialized
INFO - 2025-04-03 23:16:49 --> Security Class Initialized
DEBUG - 2025-04-03 23:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:16:49 --> Input Class Initialized
INFO - 2025-04-03 23:16:49 --> Language Class Initialized
INFO - 2025-04-03 23:16:49 --> Language Class Initialized
INFO - 2025-04-03 23:16:49 --> Config Class Initialized
INFO - 2025-04-03 23:16:49 --> Loader Class Initialized
INFO - 2025-04-03 23:16:49 --> Helper loaded: url_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: file_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: html_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: form_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: text_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:16:49 --> Database Driver Class Initialized
INFO - 2025-04-03 23:16:49 --> Email Class Initialized
INFO - 2025-04-03 23:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:16:49 --> Form Validation Class Initialized
INFO - 2025-04-03 23:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:16:49 --> Pagination Class Initialized
INFO - 2025-04-03 23:16:49 --> Controller Class Initialized
DEBUG - 2025-04-03 23:16:49 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:16:49 --> Model Class Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:16:49 --> Model Class Initialized
INFO - 2025-04-03 23:16:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 23:16:49 --> Config Class Initialized
INFO - 2025-04-03 23:16:49 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:16:49 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:16:49 --> Utf8 Class Initialized
INFO - 2025-04-03 23:16:49 --> URI Class Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:16:49 --> Router Class Initialized
INFO - 2025-04-03 23:16:49 --> Output Class Initialized
INFO - 2025-04-03 23:16:49 --> Security Class Initialized
DEBUG - 2025-04-03 23:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:16:49 --> Input Class Initialized
INFO - 2025-04-03 23:16:49 --> Language Class Initialized
INFO - 2025-04-03 23:16:49 --> Language Class Initialized
INFO - 2025-04-03 23:16:49 --> Config Class Initialized
INFO - 2025-04-03 23:16:49 --> Loader Class Initialized
INFO - 2025-04-03 23:16:49 --> Helper loaded: url_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: file_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: html_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: form_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: text_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:16:49 --> Database Driver Class Initialized
INFO - 2025-04-03 23:16:49 --> Email Class Initialized
INFO - 2025-04-03 23:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:16:49 --> Form Validation Class Initialized
INFO - 2025-04-03 23:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:16:49 --> Pagination Class Initialized
INFO - 2025-04-03 23:16:49 --> Controller Class Initialized
DEBUG - 2025-04-03 23:16:49 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:16:49 --> Model Class Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:16:49 --> Model Class Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:16:49 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:16:49 --> Model Class Initialized
ERROR - 2025-04-03 23:16:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:16:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:16:49 --> Final output sent to browser
DEBUG - 2025-04-03 23:16:49 --> Total execution time: 0.1230
INFO - 2025-04-03 23:16:49 --> Config Class Initialized
INFO - 2025-04-03 23:16:49 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:16:49 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:16:49 --> Utf8 Class Initialized
INFO - 2025-04-03 23:16:49 --> URI Class Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:16:49 --> Router Class Initialized
INFO - 2025-04-03 23:16:49 --> Output Class Initialized
INFO - 2025-04-03 23:16:49 --> Security Class Initialized
DEBUG - 2025-04-03 23:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:16:49 --> Input Class Initialized
INFO - 2025-04-03 23:16:49 --> Language Class Initialized
INFO - 2025-04-03 23:16:49 --> Language Class Initialized
INFO - 2025-04-03 23:16:49 --> Config Class Initialized
INFO - 2025-04-03 23:16:49 --> Loader Class Initialized
INFO - 2025-04-03 23:16:49 --> Helper loaded: url_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: file_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: html_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: form_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: text_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:16:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:16:49 --> Database Driver Class Initialized
INFO - 2025-04-03 23:16:49 --> Email Class Initialized
INFO - 2025-04-03 23:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:16:49 --> Form Validation Class Initialized
INFO - 2025-04-03 23:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:16:49 --> Pagination Class Initialized
INFO - 2025-04-03 23:16:49 --> Controller Class Initialized
DEBUG - 2025-04-03 23:16:49 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:16:49 --> Model Class Initialized
DEBUG - 2025-04-03 23:16:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:16:49 --> Model Class Initialized
ERROR - 2025-04-03 23:16:49 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:16:49 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:16:49 --> Received customer_id: null
ERROR - 2025-04-03 23:16:49 --> Received customfiled: null
ERROR - 2025-04-03 23:16:49 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:16:49 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:16:49 --> Search value: 
ERROR - 2025-04-03 23:16:49 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:16:49 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:16:49 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:16:49 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:16:49 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:20:09 --> Config Class Initialized
INFO - 2025-04-03 23:20:09 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:20:09 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:20:09 --> Utf8 Class Initialized
INFO - 2025-04-03 23:20:09 --> URI Class Initialized
DEBUG - 2025-04-03 23:20:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:20:09 --> Router Class Initialized
INFO - 2025-04-03 23:20:09 --> Output Class Initialized
INFO - 2025-04-03 23:20:09 --> Security Class Initialized
DEBUG - 2025-04-03 23:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:20:09 --> Input Class Initialized
INFO - 2025-04-03 23:20:09 --> Language Class Initialized
INFO - 2025-04-03 23:20:09 --> Language Class Initialized
INFO - 2025-04-03 23:20:09 --> Config Class Initialized
INFO - 2025-04-03 23:20:09 --> Loader Class Initialized
INFO - 2025-04-03 23:20:09 --> Helper loaded: url_helper
INFO - 2025-04-03 23:20:09 --> Helper loaded: file_helper
INFO - 2025-04-03 23:20:09 --> Helper loaded: html_helper
INFO - 2025-04-03 23:20:09 --> Helper loaded: form_helper
INFO - 2025-04-03 23:20:09 --> Helper loaded: text_helper
INFO - 2025-04-03 23:20:09 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:20:09 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:20:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:20:09 --> Database Driver Class Initialized
INFO - 2025-04-03 23:20:09 --> Email Class Initialized
INFO - 2025-04-03 23:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:20:09 --> Form Validation Class Initialized
INFO - 2025-04-03 23:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:20:09 --> Pagination Class Initialized
INFO - 2025-04-03 23:20:09 --> Controller Class Initialized
DEBUG - 2025-04-03 23:20:09 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:20:09 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:20:09 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:20:09 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:20:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:20:09 --> Model Class Initialized
ERROR - 2025-04-03 23:20:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:20:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:20:10 --> Final output sent to browser
DEBUG - 2025-04-03 23:20:10 --> Total execution time: 0.3526
INFO - 2025-04-03 23:20:10 --> Config Class Initialized
INFO - 2025-04-03 23:20:10 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:20:10 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:20:10 --> Utf8 Class Initialized
INFO - 2025-04-03 23:20:10 --> URI Class Initialized
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:20:10 --> Router Class Initialized
INFO - 2025-04-03 23:20:10 --> Output Class Initialized
INFO - 2025-04-03 23:20:10 --> Security Class Initialized
DEBUG - 2025-04-03 23:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:20:10 --> Input Class Initialized
INFO - 2025-04-03 23:20:10 --> Language Class Initialized
INFO - 2025-04-03 23:20:10 --> Language Class Initialized
INFO - 2025-04-03 23:20:10 --> Config Class Initialized
INFO - 2025-04-03 23:20:10 --> Loader Class Initialized
INFO - 2025-04-03 23:20:10 --> Helper loaded: url_helper
INFO - 2025-04-03 23:20:10 --> Helper loaded: file_helper
INFO - 2025-04-03 23:20:10 --> Helper loaded: html_helper
INFO - 2025-04-03 23:20:10 --> Helper loaded: form_helper
INFO - 2025-04-03 23:20:10 --> Helper loaded: text_helper
INFO - 2025-04-03 23:20:10 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:20:10 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:20:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:20:10 --> Database Driver Class Initialized
INFO - 2025-04-03 23:20:10 --> Email Class Initialized
INFO - 2025-04-03 23:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:20:10 --> Form Validation Class Initialized
INFO - 2025-04-03 23:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:20:10 --> Pagination Class Initialized
INFO - 2025-04-03 23:20:10 --> Controller Class Initialized
DEBUG - 2025-04-03 23:20:10 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:20:10 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:20:10 --> Model Class Initialized
ERROR - 2025-04-03 23:20:10 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:20:10 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:20:10 --> Received customer_id: null
ERROR - 2025-04-03 23:20:10 --> Received customfiled: null
ERROR - 2025-04-03 23:20:10 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:20:10 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:20:10 --> Search value: 
ERROR - 2025-04-03 23:20:10 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:20:10 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:20:10 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:20:10 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:20:10 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:20:15 --> Config Class Initialized
INFO - 2025-04-03 23:20:15 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:20:15 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:20:15 --> Utf8 Class Initialized
INFO - 2025-04-03 23:20:15 --> URI Class Initialized
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:20:15 --> Router Class Initialized
INFO - 2025-04-03 23:20:15 --> Output Class Initialized
INFO - 2025-04-03 23:20:15 --> Security Class Initialized
DEBUG - 2025-04-03 23:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:20:15 --> Input Class Initialized
INFO - 2025-04-03 23:20:15 --> Language Class Initialized
INFO - 2025-04-03 23:20:15 --> Language Class Initialized
INFO - 2025-04-03 23:20:15 --> Config Class Initialized
INFO - 2025-04-03 23:20:15 --> Loader Class Initialized
INFO - 2025-04-03 23:20:15 --> Helper loaded: url_helper
INFO - 2025-04-03 23:20:15 --> Helper loaded: file_helper
INFO - 2025-04-03 23:20:15 --> Helper loaded: html_helper
INFO - 2025-04-03 23:20:15 --> Helper loaded: form_helper
INFO - 2025-04-03 23:20:15 --> Helper loaded: text_helper
INFO - 2025-04-03 23:20:15 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:20:15 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:20:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:20:15 --> Database Driver Class Initialized
INFO - 2025-04-03 23:20:15 --> Email Class Initialized
INFO - 2025-04-03 23:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:20:15 --> Form Validation Class Initialized
INFO - 2025-04-03 23:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:20:15 --> Pagination Class Initialized
INFO - 2025-04-03 23:20:15 --> Controller Class Initialized
DEBUG - 2025-04-03 23:20:15 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:20:15 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:20:15 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:20:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:20:15 --> Model Class Initialized
ERROR - 2025-04-03 23:20:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:20:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:20:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:20:15 --> Final output sent to browser
DEBUG - 2025-04-03 23:20:15 --> Total execution time: 0.1917
INFO - 2025-04-03 23:20:26 --> Config Class Initialized
INFO - 2025-04-03 23:20:26 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:20:26 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:20:26 --> Utf8 Class Initialized
INFO - 2025-04-03 23:20:26 --> URI Class Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:20:26 --> Router Class Initialized
INFO - 2025-04-03 23:20:26 --> Output Class Initialized
INFO - 2025-04-03 23:20:26 --> Security Class Initialized
DEBUG - 2025-04-03 23:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:20:26 --> Input Class Initialized
INFO - 2025-04-03 23:20:26 --> Language Class Initialized
INFO - 2025-04-03 23:20:26 --> Language Class Initialized
INFO - 2025-04-03 23:20:26 --> Config Class Initialized
INFO - 2025-04-03 23:20:26 --> Loader Class Initialized
INFO - 2025-04-03 23:20:26 --> Helper loaded: url_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: file_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: html_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: form_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: text_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:20:26 --> Database Driver Class Initialized
INFO - 2025-04-03 23:20:26 --> Email Class Initialized
INFO - 2025-04-03 23:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:20:26 --> Form Validation Class Initialized
INFO - 2025-04-03 23:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:20:26 --> Pagination Class Initialized
INFO - 2025-04-03 23:20:26 --> Controller Class Initialized
DEBUG - 2025-04-03 23:20:26 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:20:26 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:20:26 --> Model Class Initialized
INFO - 2025-04-03 23:20:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 23:20:26 --> Config Class Initialized
INFO - 2025-04-03 23:20:26 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:20:26 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:20:26 --> Utf8 Class Initialized
INFO - 2025-04-03 23:20:26 --> URI Class Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:20:26 --> Router Class Initialized
INFO - 2025-04-03 23:20:26 --> Output Class Initialized
INFO - 2025-04-03 23:20:26 --> Security Class Initialized
DEBUG - 2025-04-03 23:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:20:26 --> Input Class Initialized
INFO - 2025-04-03 23:20:26 --> Language Class Initialized
INFO - 2025-04-03 23:20:26 --> Language Class Initialized
INFO - 2025-04-03 23:20:26 --> Config Class Initialized
INFO - 2025-04-03 23:20:26 --> Loader Class Initialized
INFO - 2025-04-03 23:20:26 --> Helper loaded: url_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: file_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: html_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: form_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: text_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:20:26 --> Database Driver Class Initialized
INFO - 2025-04-03 23:20:26 --> Email Class Initialized
INFO - 2025-04-03 23:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:20:26 --> Form Validation Class Initialized
INFO - 2025-04-03 23:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:20:26 --> Pagination Class Initialized
INFO - 2025-04-03 23:20:26 --> Controller Class Initialized
DEBUG - 2025-04-03 23:20:26 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:20:26 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:20:26 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:20:26 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:20:26 --> Model Class Initialized
ERROR - 2025-04-03 23:20:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:20:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:20:26 --> Final output sent to browser
DEBUG - 2025-04-03 23:20:26 --> Total execution time: 0.1662
INFO - 2025-04-03 23:20:26 --> Config Class Initialized
INFO - 2025-04-03 23:20:26 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:20:26 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:20:26 --> Utf8 Class Initialized
INFO - 2025-04-03 23:20:26 --> URI Class Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:20:26 --> Router Class Initialized
INFO - 2025-04-03 23:20:26 --> Output Class Initialized
INFO - 2025-04-03 23:20:26 --> Security Class Initialized
DEBUG - 2025-04-03 23:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:20:26 --> Input Class Initialized
INFO - 2025-04-03 23:20:26 --> Language Class Initialized
INFO - 2025-04-03 23:20:26 --> Language Class Initialized
INFO - 2025-04-03 23:20:26 --> Config Class Initialized
INFO - 2025-04-03 23:20:26 --> Loader Class Initialized
INFO - 2025-04-03 23:20:26 --> Helper loaded: url_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: file_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: html_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: form_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: text_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:20:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:20:26 --> Database Driver Class Initialized
INFO - 2025-04-03 23:20:26 --> Email Class Initialized
INFO - 2025-04-03 23:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:20:26 --> Form Validation Class Initialized
INFO - 2025-04-03 23:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:20:26 --> Pagination Class Initialized
INFO - 2025-04-03 23:20:26 --> Controller Class Initialized
DEBUG - 2025-04-03 23:20:26 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:20:26 --> Model Class Initialized
DEBUG - 2025-04-03 23:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:20:26 --> Model Class Initialized
ERROR - 2025-04-03 23:20:26 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:20:26 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:20:26 --> Received customer_id: null
ERROR - 2025-04-03 23:20:26 --> Received customfiled: null
ERROR - 2025-04-03 23:20:26 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:20:26 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:20:26 --> Search value: 
ERROR - 2025-04-03 23:20:26 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:20:26 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:20:26 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:20:26 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:20:26 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:22:30 --> Config Class Initialized
INFO - 2025-04-03 23:22:30 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:22:30 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:22:30 --> Utf8 Class Initialized
INFO - 2025-04-03 23:22:30 --> URI Class Initialized
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:22:30 --> Router Class Initialized
INFO - 2025-04-03 23:22:30 --> Output Class Initialized
INFO - 2025-04-03 23:22:30 --> Security Class Initialized
DEBUG - 2025-04-03 23:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:22:30 --> Input Class Initialized
INFO - 2025-04-03 23:22:30 --> Language Class Initialized
INFO - 2025-04-03 23:22:30 --> Language Class Initialized
INFO - 2025-04-03 23:22:30 --> Config Class Initialized
INFO - 2025-04-03 23:22:30 --> Loader Class Initialized
INFO - 2025-04-03 23:22:30 --> Helper loaded: url_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: file_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: html_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: form_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: text_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:22:30 --> Database Driver Class Initialized
INFO - 2025-04-03 23:22:30 --> Email Class Initialized
INFO - 2025-04-03 23:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:22:30 --> Form Validation Class Initialized
INFO - 2025-04-03 23:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:22:30 --> Pagination Class Initialized
INFO - 2025-04-03 23:22:30 --> Controller Class Initialized
DEBUG - 2025-04-03 23:22:30 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:22:30 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:22:30 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:22:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:22:30 --> Model Class Initialized
ERROR - 2025-04-03 23:22:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:22:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:22:30 --> Final output sent to browser
DEBUG - 2025-04-03 23:22:30 --> Total execution time: 0.1529
INFO - 2025-04-03 23:22:30 --> Config Class Initialized
INFO - 2025-04-03 23:22:30 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:22:30 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:22:30 --> Utf8 Class Initialized
INFO - 2025-04-03 23:22:30 --> URI Class Initialized
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:22:30 --> Router Class Initialized
INFO - 2025-04-03 23:22:30 --> Output Class Initialized
INFO - 2025-04-03 23:22:30 --> Security Class Initialized
DEBUG - 2025-04-03 23:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:22:30 --> Input Class Initialized
INFO - 2025-04-03 23:22:30 --> Language Class Initialized
INFO - 2025-04-03 23:22:30 --> Language Class Initialized
INFO - 2025-04-03 23:22:30 --> Config Class Initialized
INFO - 2025-04-03 23:22:30 --> Loader Class Initialized
INFO - 2025-04-03 23:22:30 --> Helper loaded: url_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: file_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: html_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: form_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: text_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:22:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:22:30 --> Database Driver Class Initialized
INFO - 2025-04-03 23:22:30 --> Email Class Initialized
INFO - 2025-04-03 23:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:22:30 --> Form Validation Class Initialized
INFO - 2025-04-03 23:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:22:30 --> Pagination Class Initialized
INFO - 2025-04-03 23:22:30 --> Controller Class Initialized
DEBUG - 2025-04-03 23:22:30 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:22:30 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:22:30 --> Model Class Initialized
ERROR - 2025-04-03 23:22:30 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:22:30 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:22:30 --> Received customer_id: null
ERROR - 2025-04-03 23:22:30 --> Received customfiled: null
ERROR - 2025-04-03 23:22:30 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:22:30 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:22:30 --> Search value: 
ERROR - 2025-04-03 23:22:30 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:22:30 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:22:30 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:22:30 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:22:30 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:22:33 --> Config Class Initialized
INFO - 2025-04-03 23:22:33 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:22:33 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:22:33 --> Utf8 Class Initialized
INFO - 2025-04-03 23:22:33 --> URI Class Initialized
DEBUG - 2025-04-03 23:22:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:22:33 --> Router Class Initialized
INFO - 2025-04-03 23:22:33 --> Output Class Initialized
INFO - 2025-04-03 23:22:33 --> Security Class Initialized
DEBUG - 2025-04-03 23:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:22:33 --> Input Class Initialized
INFO - 2025-04-03 23:22:33 --> Language Class Initialized
INFO - 2025-04-03 23:22:33 --> Language Class Initialized
INFO - 2025-04-03 23:22:33 --> Config Class Initialized
INFO - 2025-04-03 23:22:33 --> Loader Class Initialized
INFO - 2025-04-03 23:22:33 --> Helper loaded: url_helper
INFO - 2025-04-03 23:22:33 --> Helper loaded: file_helper
INFO - 2025-04-03 23:22:33 --> Helper loaded: html_helper
INFO - 2025-04-03 23:22:33 --> Helper loaded: form_helper
INFO - 2025-04-03 23:22:33 --> Helper loaded: text_helper
INFO - 2025-04-03 23:22:33 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:22:33 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:22:33 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:22:33 --> Database Driver Class Initialized
INFO - 2025-04-03 23:22:33 --> Email Class Initialized
INFO - 2025-04-03 23:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:22:33 --> Form Validation Class Initialized
INFO - 2025-04-03 23:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:22:33 --> Pagination Class Initialized
INFO - 2025-04-03 23:22:33 --> Controller Class Initialized
DEBUG - 2025-04-03 23:22:33 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:22:33 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:22:33 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:22:33 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:22:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:22:33 --> Model Class Initialized
ERROR - 2025-04-03 23:22:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:22:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:22:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:22:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:22:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:22:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:22:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:22:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:22:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:22:34 --> Final output sent to browser
DEBUG - 2025-04-03 23:22:34 --> Total execution time: 0.1989
INFO - 2025-04-03 23:22:41 --> Config Class Initialized
INFO - 2025-04-03 23:22:41 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:22:41 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:22:41 --> Utf8 Class Initialized
INFO - 2025-04-03 23:22:41 --> URI Class Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:22:41 --> Router Class Initialized
INFO - 2025-04-03 23:22:41 --> Output Class Initialized
INFO - 2025-04-03 23:22:41 --> Security Class Initialized
DEBUG - 2025-04-03 23:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:22:41 --> Input Class Initialized
INFO - 2025-04-03 23:22:41 --> Language Class Initialized
INFO - 2025-04-03 23:22:41 --> Language Class Initialized
INFO - 2025-04-03 23:22:41 --> Config Class Initialized
INFO - 2025-04-03 23:22:41 --> Loader Class Initialized
INFO - 2025-04-03 23:22:41 --> Helper loaded: url_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: file_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: html_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: form_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: text_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:22:41 --> Database Driver Class Initialized
INFO - 2025-04-03 23:22:41 --> Email Class Initialized
INFO - 2025-04-03 23:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:22:41 --> Form Validation Class Initialized
INFO - 2025-04-03 23:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:22:41 --> Pagination Class Initialized
INFO - 2025-04-03 23:22:41 --> Controller Class Initialized
DEBUG - 2025-04-03 23:22:41 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:22:41 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:22:41 --> Model Class Initialized
INFO - 2025-04-03 23:22:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 23:22:41 --> Inserted new commission for customer_id=26 and set all previous to status=0
INFO - 2025-04-03 23:22:41 --> Config Class Initialized
INFO - 2025-04-03 23:22:41 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:22:41 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:22:41 --> Utf8 Class Initialized
INFO - 2025-04-03 23:22:41 --> URI Class Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:22:41 --> Router Class Initialized
INFO - 2025-04-03 23:22:41 --> Output Class Initialized
INFO - 2025-04-03 23:22:41 --> Security Class Initialized
DEBUG - 2025-04-03 23:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:22:41 --> Input Class Initialized
INFO - 2025-04-03 23:22:41 --> Language Class Initialized
INFO - 2025-04-03 23:22:41 --> Language Class Initialized
INFO - 2025-04-03 23:22:41 --> Config Class Initialized
INFO - 2025-04-03 23:22:41 --> Loader Class Initialized
INFO - 2025-04-03 23:22:41 --> Helper loaded: url_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: file_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: html_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: form_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: text_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:22:41 --> Database Driver Class Initialized
INFO - 2025-04-03 23:22:41 --> Email Class Initialized
INFO - 2025-04-03 23:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:22:41 --> Form Validation Class Initialized
INFO - 2025-04-03 23:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:22:41 --> Pagination Class Initialized
INFO - 2025-04-03 23:22:41 --> Controller Class Initialized
DEBUG - 2025-04-03 23:22:41 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:22:41 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:22:41 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:22:41 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:22:41 --> Model Class Initialized
ERROR - 2025-04-03 23:22:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:22:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:22:41 --> Final output sent to browser
DEBUG - 2025-04-03 23:22:41 --> Total execution time: 0.1580
INFO - 2025-04-03 23:22:41 --> Config Class Initialized
INFO - 2025-04-03 23:22:41 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:22:41 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:22:41 --> Utf8 Class Initialized
INFO - 2025-04-03 23:22:41 --> URI Class Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:22:41 --> Router Class Initialized
INFO - 2025-04-03 23:22:41 --> Output Class Initialized
INFO - 2025-04-03 23:22:41 --> Security Class Initialized
DEBUG - 2025-04-03 23:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:22:41 --> Input Class Initialized
INFO - 2025-04-03 23:22:41 --> Language Class Initialized
INFO - 2025-04-03 23:22:41 --> Language Class Initialized
INFO - 2025-04-03 23:22:41 --> Config Class Initialized
INFO - 2025-04-03 23:22:41 --> Loader Class Initialized
INFO - 2025-04-03 23:22:41 --> Helper loaded: url_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: file_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: html_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: form_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: text_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:22:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:22:41 --> Database Driver Class Initialized
INFO - 2025-04-03 23:22:41 --> Email Class Initialized
INFO - 2025-04-03 23:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:22:41 --> Form Validation Class Initialized
INFO - 2025-04-03 23:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:22:41 --> Pagination Class Initialized
INFO - 2025-04-03 23:22:41 --> Controller Class Initialized
DEBUG - 2025-04-03 23:22:41 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:22:41 --> Model Class Initialized
DEBUG - 2025-04-03 23:22:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:22:41 --> Model Class Initialized
ERROR - 2025-04-03 23:22:41 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:22:41 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:22:41 --> Received customer_id: null
ERROR - 2025-04-03 23:22:41 --> Received customfiled: null
ERROR - 2025-04-03 23:22:41 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:22:41 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:22:41 --> Search value: 
ERROR - 2025-04-03 23:22:41 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:22:41 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:22:41 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:22:41 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:22:41 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:24:36 --> Config Class Initialized
INFO - 2025-04-03 23:24:36 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:24:36 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:24:36 --> Utf8 Class Initialized
INFO - 2025-04-03 23:24:36 --> URI Class Initialized
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:24:36 --> Router Class Initialized
INFO - 2025-04-03 23:24:36 --> Output Class Initialized
INFO - 2025-04-03 23:24:36 --> Security Class Initialized
DEBUG - 2025-04-03 23:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:24:36 --> Input Class Initialized
INFO - 2025-04-03 23:24:36 --> Language Class Initialized
INFO - 2025-04-03 23:24:36 --> Language Class Initialized
INFO - 2025-04-03 23:24:36 --> Config Class Initialized
INFO - 2025-04-03 23:24:36 --> Loader Class Initialized
INFO - 2025-04-03 23:24:36 --> Helper loaded: url_helper
INFO - 2025-04-03 23:24:36 --> Helper loaded: file_helper
INFO - 2025-04-03 23:24:36 --> Helper loaded: html_helper
INFO - 2025-04-03 23:24:36 --> Helper loaded: form_helper
INFO - 2025-04-03 23:24:36 --> Helper loaded: text_helper
INFO - 2025-04-03 23:24:36 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:24:36 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:24:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:24:36 --> Database Driver Class Initialized
INFO - 2025-04-03 23:24:36 --> Email Class Initialized
INFO - 2025-04-03 23:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:24:36 --> Form Validation Class Initialized
INFO - 2025-04-03 23:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:24:36 --> Pagination Class Initialized
INFO - 2025-04-03 23:24:36 --> Controller Class Initialized
DEBUG - 2025-04-03 23:24:36 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:24:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:24:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:24:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:24:36 --> Model Class Initialized
ERROR - 2025-04-03 23:24:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:24:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:24:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:24:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:24:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:24:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:24:37 --> Final output sent to browser
DEBUG - 2025-04-03 23:24:37 --> Total execution time: 0.2148
INFO - 2025-04-03 23:24:37 --> Config Class Initialized
INFO - 2025-04-03 23:24:37 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:24:37 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:24:37 --> Utf8 Class Initialized
INFO - 2025-04-03 23:24:37 --> URI Class Initialized
DEBUG - 2025-04-03 23:24:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:24:37 --> Router Class Initialized
INFO - 2025-04-03 23:24:37 --> Output Class Initialized
INFO - 2025-04-03 23:24:37 --> Security Class Initialized
DEBUG - 2025-04-03 23:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:24:37 --> Input Class Initialized
INFO - 2025-04-03 23:24:37 --> Language Class Initialized
INFO - 2025-04-03 23:24:37 --> Language Class Initialized
INFO - 2025-04-03 23:24:37 --> Config Class Initialized
INFO - 2025-04-03 23:24:37 --> Loader Class Initialized
INFO - 2025-04-03 23:24:37 --> Helper loaded: url_helper
INFO - 2025-04-03 23:24:37 --> Helper loaded: file_helper
INFO - 2025-04-03 23:24:37 --> Helper loaded: html_helper
INFO - 2025-04-03 23:24:37 --> Helper loaded: form_helper
INFO - 2025-04-03 23:24:37 --> Helper loaded: text_helper
INFO - 2025-04-03 23:24:37 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:24:37 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:24:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:24:37 --> Database Driver Class Initialized
INFO - 2025-04-03 23:24:37 --> Email Class Initialized
INFO - 2025-04-03 23:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:24:37 --> Form Validation Class Initialized
INFO - 2025-04-03 23:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:24:37 --> Pagination Class Initialized
INFO - 2025-04-03 23:24:37 --> Controller Class Initialized
DEBUG - 2025-04-03 23:24:37 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:24:37 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:24:37 --> Model Class Initialized
ERROR - 2025-04-03 23:24:37 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:24:37 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:24:37 --> Received customer_id: null
ERROR - 2025-04-03 23:24:37 --> Received customfiled: null
ERROR - 2025-04-03 23:24:37 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:24:37 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:24:37 --> Search value: 
ERROR - 2025-04-03 23:24:37 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:24:37 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:24:37 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:24:37 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:24:37 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:24:41 --> Config Class Initialized
INFO - 2025-04-03 23:24:41 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:24:41 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:24:41 --> Utf8 Class Initialized
INFO - 2025-04-03 23:24:41 --> URI Class Initialized
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:24:41 --> Router Class Initialized
INFO - 2025-04-03 23:24:41 --> Output Class Initialized
INFO - 2025-04-03 23:24:41 --> Security Class Initialized
DEBUG - 2025-04-03 23:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:24:41 --> Input Class Initialized
INFO - 2025-04-03 23:24:41 --> Language Class Initialized
INFO - 2025-04-03 23:24:41 --> Language Class Initialized
INFO - 2025-04-03 23:24:41 --> Config Class Initialized
INFO - 2025-04-03 23:24:41 --> Loader Class Initialized
INFO - 2025-04-03 23:24:41 --> Helper loaded: url_helper
INFO - 2025-04-03 23:24:41 --> Helper loaded: file_helper
INFO - 2025-04-03 23:24:41 --> Helper loaded: html_helper
INFO - 2025-04-03 23:24:41 --> Helper loaded: form_helper
INFO - 2025-04-03 23:24:41 --> Helper loaded: text_helper
INFO - 2025-04-03 23:24:41 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:24:41 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:24:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:24:41 --> Database Driver Class Initialized
INFO - 2025-04-03 23:24:41 --> Email Class Initialized
INFO - 2025-04-03 23:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:24:41 --> Form Validation Class Initialized
INFO - 2025-04-03 23:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:24:41 --> Pagination Class Initialized
INFO - 2025-04-03 23:24:41 --> Controller Class Initialized
DEBUG - 2025-04-03 23:24:41 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:24:41 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:24:41 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:24:41 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:24:41 --> Model Class Initialized
ERROR - 2025-04-03 23:24:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:24:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:24:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:24:41 --> Final output sent to browser
DEBUG - 2025-04-03 23:24:41 --> Total execution time: 0.1800
INFO - 2025-04-03 23:24:51 --> Config Class Initialized
INFO - 2025-04-03 23:24:51 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:24:51 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:24:51 --> Utf8 Class Initialized
INFO - 2025-04-03 23:24:51 --> URI Class Initialized
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:24:51 --> Router Class Initialized
INFO - 2025-04-03 23:24:51 --> Output Class Initialized
INFO - 2025-04-03 23:24:51 --> Security Class Initialized
DEBUG - 2025-04-03 23:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:24:51 --> Input Class Initialized
INFO - 2025-04-03 23:24:51 --> Language Class Initialized
INFO - 2025-04-03 23:24:51 --> Language Class Initialized
INFO - 2025-04-03 23:24:51 --> Config Class Initialized
INFO - 2025-04-03 23:24:51 --> Loader Class Initialized
INFO - 2025-04-03 23:24:51 --> Helper loaded: url_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: file_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: html_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: form_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: text_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:24:51 --> Database Driver Class Initialized
INFO - 2025-04-03 23:24:51 --> Email Class Initialized
INFO - 2025-04-03 23:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:24:51 --> Form Validation Class Initialized
INFO - 2025-04-03 23:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:24:51 --> Pagination Class Initialized
INFO - 2025-04-03 23:24:51 --> Controller Class Initialized
DEBUG - 2025-04-03 23:24:51 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:24:51 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:24:51 --> Model Class Initialized
INFO - 2025-04-03 23:24:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 23:24:51 --> Inserted new commission for customer_id=26 and set all previous to status=0
INFO - 2025-04-03 23:24:51 --> Config Class Initialized
INFO - 2025-04-03 23:24:51 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:24:51 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:24:51 --> Utf8 Class Initialized
INFO - 2025-04-03 23:24:51 --> URI Class Initialized
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:24:51 --> Router Class Initialized
INFO - 2025-04-03 23:24:51 --> Output Class Initialized
INFO - 2025-04-03 23:24:51 --> Security Class Initialized
DEBUG - 2025-04-03 23:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:24:51 --> Input Class Initialized
INFO - 2025-04-03 23:24:51 --> Language Class Initialized
INFO - 2025-04-03 23:24:51 --> Language Class Initialized
INFO - 2025-04-03 23:24:51 --> Config Class Initialized
INFO - 2025-04-03 23:24:51 --> Loader Class Initialized
INFO - 2025-04-03 23:24:51 --> Helper loaded: url_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: file_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: html_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: form_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: text_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:24:51 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:24:51 --> Database Driver Class Initialized
INFO - 2025-04-03 23:24:51 --> Email Class Initialized
INFO - 2025-04-03 23:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:24:51 --> Form Validation Class Initialized
INFO - 2025-04-03 23:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:24:51 --> Pagination Class Initialized
INFO - 2025-04-03 23:24:51 --> Controller Class Initialized
DEBUG - 2025-04-03 23:24:51 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:24:51 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:24:51 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:24:51 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:24:51 --> Model Class Initialized
ERROR - 2025-04-03 23:24:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:24:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:24:52 --> Final output sent to browser
DEBUG - 2025-04-03 23:24:52 --> Total execution time: 0.1266
INFO - 2025-04-03 23:24:52 --> Config Class Initialized
INFO - 2025-04-03 23:24:52 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:24:52 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:24:52 --> Utf8 Class Initialized
INFO - 2025-04-03 23:24:52 --> URI Class Initialized
DEBUG - 2025-04-03 23:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:24:52 --> Router Class Initialized
INFO - 2025-04-03 23:24:52 --> Output Class Initialized
INFO - 2025-04-03 23:24:52 --> Security Class Initialized
DEBUG - 2025-04-03 23:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:24:52 --> Input Class Initialized
INFO - 2025-04-03 23:24:52 --> Language Class Initialized
INFO - 2025-04-03 23:24:52 --> Language Class Initialized
INFO - 2025-04-03 23:24:52 --> Config Class Initialized
INFO - 2025-04-03 23:24:52 --> Loader Class Initialized
INFO - 2025-04-03 23:24:52 --> Helper loaded: url_helper
INFO - 2025-04-03 23:24:52 --> Helper loaded: file_helper
INFO - 2025-04-03 23:24:52 --> Helper loaded: html_helper
INFO - 2025-04-03 23:24:52 --> Helper loaded: form_helper
INFO - 2025-04-03 23:24:52 --> Helper loaded: text_helper
INFO - 2025-04-03 23:24:52 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:24:52 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:24:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:24:52 --> Database Driver Class Initialized
INFO - 2025-04-03 23:24:52 --> Email Class Initialized
INFO - 2025-04-03 23:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:24:52 --> Form Validation Class Initialized
INFO - 2025-04-03 23:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:24:52 --> Pagination Class Initialized
INFO - 2025-04-03 23:24:52 --> Controller Class Initialized
DEBUG - 2025-04-03 23:24:52 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:24:52 --> Model Class Initialized
DEBUG - 2025-04-03 23:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:24:52 --> Model Class Initialized
ERROR - 2025-04-03 23:24:52 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:24:52 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:24:52 --> Received customer_id: null
ERROR - 2025-04-03 23:24:52 --> Received customfiled: null
ERROR - 2025-04-03 23:24:52 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:24:52 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:24:52 --> Search value: 
ERROR - 2025-04-03 23:24:52 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:24:52 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:24:52 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:24:52 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:24:52 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:31:18 --> Config Class Initialized
INFO - 2025-04-03 23:31:18 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:31:18 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:31:18 --> Utf8 Class Initialized
INFO - 2025-04-03 23:31:18 --> URI Class Initialized
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:31:18 --> Router Class Initialized
INFO - 2025-04-03 23:31:18 --> Output Class Initialized
INFO - 2025-04-03 23:31:18 --> Security Class Initialized
DEBUG - 2025-04-03 23:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:31:18 --> Input Class Initialized
INFO - 2025-04-03 23:31:18 --> Language Class Initialized
INFO - 2025-04-03 23:31:18 --> Language Class Initialized
INFO - 2025-04-03 23:31:18 --> Config Class Initialized
INFO - 2025-04-03 23:31:18 --> Loader Class Initialized
INFO - 2025-04-03 23:31:18 --> Helper loaded: url_helper
INFO - 2025-04-03 23:31:18 --> Helper loaded: file_helper
INFO - 2025-04-03 23:31:18 --> Helper loaded: html_helper
INFO - 2025-04-03 23:31:18 --> Helper loaded: form_helper
INFO - 2025-04-03 23:31:18 --> Helper loaded: text_helper
INFO - 2025-04-03 23:31:18 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:31:18 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:31:18 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:31:18 --> Database Driver Class Initialized
INFO - 2025-04-03 23:31:18 --> Email Class Initialized
INFO - 2025-04-03 23:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:31:18 --> Form Validation Class Initialized
INFO - 2025-04-03 23:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:31:18 --> Pagination Class Initialized
INFO - 2025-04-03 23:31:18 --> Controller Class Initialized
DEBUG - 2025-04-03 23:31:18 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:31:18 --> Model Class Initialized
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:31:18 --> Model Class Initialized
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:31:18 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:31:18 --> Model Class Initialized
ERROR - 2025-04-03 23:31:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:31:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:31:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:31:18 --> Final output sent to browser
DEBUG - 2025-04-03 23:31:18 --> Total execution time: 0.2470
INFO - 2025-04-03 23:31:36 --> Config Class Initialized
INFO - 2025-04-03 23:31:36 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:31:36 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:31:36 --> Utf8 Class Initialized
INFO - 2025-04-03 23:31:36 --> URI Class Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:31:36 --> Router Class Initialized
INFO - 2025-04-03 23:31:36 --> Output Class Initialized
INFO - 2025-04-03 23:31:36 --> Security Class Initialized
DEBUG - 2025-04-03 23:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:31:36 --> Input Class Initialized
INFO - 2025-04-03 23:31:36 --> Language Class Initialized
INFO - 2025-04-03 23:31:36 --> Language Class Initialized
INFO - 2025-04-03 23:31:36 --> Config Class Initialized
INFO - 2025-04-03 23:31:36 --> Loader Class Initialized
INFO - 2025-04-03 23:31:36 --> Helper loaded: url_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: file_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: html_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: form_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: text_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:31:36 --> Database Driver Class Initialized
INFO - 2025-04-03 23:31:36 --> Email Class Initialized
INFO - 2025-04-03 23:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:31:36 --> Form Validation Class Initialized
INFO - 2025-04-03 23:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:31:36 --> Pagination Class Initialized
INFO - 2025-04-03 23:31:36 --> Controller Class Initialized
DEBUG - 2025-04-03 23:31:36 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:31:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:31:36 --> Model Class Initialized
INFO - 2025-04-03 23:31:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-03 23:31:36 --> Inserted new commission for customer_id=23 and set all previous to status=0
INFO - 2025-04-03 23:31:36 --> Config Class Initialized
INFO - 2025-04-03 23:31:36 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:31:36 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:31:36 --> Utf8 Class Initialized
INFO - 2025-04-03 23:31:36 --> URI Class Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:31:36 --> Router Class Initialized
INFO - 2025-04-03 23:31:36 --> Output Class Initialized
INFO - 2025-04-03 23:31:36 --> Security Class Initialized
DEBUG - 2025-04-03 23:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:31:36 --> Input Class Initialized
INFO - 2025-04-03 23:31:36 --> Language Class Initialized
INFO - 2025-04-03 23:31:36 --> Language Class Initialized
INFO - 2025-04-03 23:31:36 --> Config Class Initialized
INFO - 2025-04-03 23:31:36 --> Loader Class Initialized
INFO - 2025-04-03 23:31:36 --> Helper loaded: url_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: file_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: html_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: form_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: text_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:31:36 --> Database Driver Class Initialized
INFO - 2025-04-03 23:31:36 --> Email Class Initialized
INFO - 2025-04-03 23:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:31:36 --> Form Validation Class Initialized
INFO - 2025-04-03 23:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:31:36 --> Pagination Class Initialized
INFO - 2025-04-03 23:31:36 --> Controller Class Initialized
DEBUG - 2025-04-03 23:31:36 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:31:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:31:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-03 23:31:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-03 23:31:36 --> Model Class Initialized
ERROR - 2025-04-03 23:31:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-03 23:31:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-03 23:31:36 --> Final output sent to browser
DEBUG - 2025-04-03 23:31:36 --> Total execution time: 0.1631
INFO - 2025-04-03 23:31:36 --> Config Class Initialized
INFO - 2025-04-03 23:31:36 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:31:36 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:31:36 --> Utf8 Class Initialized
INFO - 2025-04-03 23:31:36 --> URI Class Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-04-03 23:31:36 --> Router Class Initialized
INFO - 2025-04-03 23:31:36 --> Output Class Initialized
INFO - 2025-04-03 23:31:36 --> Security Class Initialized
DEBUG - 2025-04-03 23:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:31:36 --> Input Class Initialized
INFO - 2025-04-03 23:31:36 --> Language Class Initialized
INFO - 2025-04-03 23:31:36 --> Language Class Initialized
INFO - 2025-04-03 23:31:36 --> Config Class Initialized
INFO - 2025-04-03 23:31:36 --> Loader Class Initialized
INFO - 2025-04-03 23:31:36 --> Helper loaded: url_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: file_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: html_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: form_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: text_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:31:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:31:36 --> Database Driver Class Initialized
INFO - 2025-04-03 23:31:36 --> Email Class Initialized
INFO - 2025-04-03 23:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:31:36 --> Form Validation Class Initialized
INFO - 2025-04-03 23:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:31:36 --> Pagination Class Initialized
INFO - 2025-04-03 23:31:36 --> Controller Class Initialized
DEBUG - 2025-04-03 23:31:36 --> Customer MX_Controller Initialized
INFO - 2025-04-03 23:31:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:31:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-03 23:31:36 --> Model Class Initialized
ERROR - 2025-04-03 23:31:36 --> ========= getCustomerList() START =========
ERROR - 2025-04-03 23:31:36 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-04-03 23:31:36 --> Received customer_id: null
ERROR - 2025-04-03 23:31:36 --> Received customfiled: null
ERROR - 2025-04-03 23:31:36 --> Pagination info: start=0, length=50
ERROR - 2025-04-03 23:31:36 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-04-03 23:31:36 --> Search value: 
ERROR - 2025-04-03 23:31:36 --> Total unfiltered records: 15
ERROR - 2025-04-03 23:31:36 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-04-03 23:31:36 --> Records fetched from DB: 15
ERROR - 2025-04-03 23:31:36 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-04-03 23:31:36 --> ========= getCustomerList() END =========
INFO - 2025-04-03 23:37:34 --> Config Class Initialized
INFO - 2025-04-03 23:37:34 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:37:34 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:37:34 --> Utf8 Class Initialized
INFO - 2025-04-03 23:37:34 --> URI Class Initialized
INFO - 2025-04-03 23:37:34 --> Router Class Initialized
INFO - 2025-04-03 23:37:34 --> Output Class Initialized
INFO - 2025-04-03 23:37:34 --> Security Class Initialized
DEBUG - 2025-04-03 23:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:37:34 --> Input Class Initialized
INFO - 2025-04-03 23:37:34 --> Language Class Initialized
INFO - 2025-04-03 23:37:34 --> Language Class Initialized
INFO - 2025-04-03 23:37:34 --> Config Class Initialized
INFO - 2025-04-03 23:37:34 --> Loader Class Initialized
INFO - 2025-04-03 23:37:34 --> Helper loaded: url_helper
INFO - 2025-04-03 23:37:34 --> Helper loaded: file_helper
INFO - 2025-04-03 23:37:34 --> Helper loaded: html_helper
INFO - 2025-04-03 23:37:34 --> Helper loaded: form_helper
INFO - 2025-04-03 23:37:34 --> Helper loaded: text_helper
INFO - 2025-04-03 23:37:34 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:37:34 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:37:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:37:34 --> Database Driver Class Initialized
INFO - 2025-04-03 23:37:34 --> Email Class Initialized
INFO - 2025-04-03 23:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:37:34 --> Form Validation Class Initialized
INFO - 2025-04-03 23:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:37:34 --> Pagination Class Initialized
INFO - 2025-04-03 23:37:34 --> Controller Class Initialized
INFO - 2025-04-03 23:37:34 --> Model Class Initialized
ERROR - 2025-04-03 23:37:34 --> Severity: Warning --> Attempt to read property "customer_id" on array /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1203
ERROR - 2025-04-03 23:37:34 --> Severity: error --> Exception: Attempt to assign property "commision_value" on array /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1215
INFO - 2025-04-03 23:39:04 --> Config Class Initialized
INFO - 2025-04-03 23:39:04 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:39:04 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:39:04 --> Utf8 Class Initialized
INFO - 2025-04-03 23:39:04 --> URI Class Initialized
INFO - 2025-04-03 23:39:04 --> Router Class Initialized
INFO - 2025-04-03 23:39:04 --> Output Class Initialized
INFO - 2025-04-03 23:39:04 --> Security Class Initialized
DEBUG - 2025-04-03 23:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:39:04 --> Input Class Initialized
INFO - 2025-04-03 23:39:04 --> Language Class Initialized
INFO - 2025-04-03 23:39:04 --> Language Class Initialized
INFO - 2025-04-03 23:39:04 --> Config Class Initialized
INFO - 2025-04-03 23:39:04 --> Loader Class Initialized
INFO - 2025-04-03 23:39:04 --> Helper loaded: url_helper
INFO - 2025-04-03 23:39:04 --> Helper loaded: file_helper
INFO - 2025-04-03 23:39:04 --> Helper loaded: html_helper
INFO - 2025-04-03 23:39:04 --> Helper loaded: form_helper
INFO - 2025-04-03 23:39:04 --> Helper loaded: text_helper
INFO - 2025-04-03 23:39:04 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:39:04 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:39:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:39:04 --> Database Driver Class Initialized
INFO - 2025-04-03 23:39:04 --> Email Class Initialized
INFO - 2025-04-03 23:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:39:04 --> Form Validation Class Initialized
INFO - 2025-04-03 23:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:39:04 --> Pagination Class Initialized
INFO - 2025-04-03 23:39:04 --> Controller Class Initialized
INFO - 2025-04-03 23:39:04 --> Model Class Initialized
ERROR - 2025-04-03 23:39:04 --> Severity: Warning --> Attempt to read property "customer_id" on array /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1203
ERROR - 2025-04-03 23:39:04 --> Severity: error --> Exception: Attempt to assign property "commision_value" on array /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1215
INFO - 2025-04-03 23:41:38 --> Config Class Initialized
INFO - 2025-04-03 23:41:38 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:41:38 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:41:38 --> Utf8 Class Initialized
INFO - 2025-04-03 23:41:38 --> URI Class Initialized
INFO - 2025-04-03 23:41:38 --> Router Class Initialized
INFO - 2025-04-03 23:41:38 --> Output Class Initialized
INFO - 2025-04-03 23:41:38 --> Security Class Initialized
DEBUG - 2025-04-03 23:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:41:38 --> Input Class Initialized
INFO - 2025-04-03 23:41:38 --> Language Class Initialized
INFO - 2025-04-03 23:41:38 --> Language Class Initialized
INFO - 2025-04-03 23:41:38 --> Config Class Initialized
INFO - 2025-04-03 23:41:38 --> Loader Class Initialized
INFO - 2025-04-03 23:41:38 --> Helper loaded: url_helper
INFO - 2025-04-03 23:41:38 --> Helper loaded: file_helper
INFO - 2025-04-03 23:41:38 --> Helper loaded: html_helper
INFO - 2025-04-03 23:41:38 --> Helper loaded: form_helper
INFO - 2025-04-03 23:41:38 --> Helper loaded: text_helper
INFO - 2025-04-03 23:41:38 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:41:38 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:41:38 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:41:38 --> Database Driver Class Initialized
INFO - 2025-04-03 23:41:38 --> Email Class Initialized
INFO - 2025-04-03 23:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:41:38 --> Form Validation Class Initialized
INFO - 2025-04-03 23:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:41:38 --> Pagination Class Initialized
INFO - 2025-04-03 23:41:38 --> Controller Class Initialized
INFO - 2025-04-03 23:41:38 --> Model Class Initialized
DEBUG - 2025-04-03 23:41:38 --> API Request: customer_comission_by_email | Email: abul.khayer@hotmail.com
ERROR - 2025-04-03 23:41:38 --> No customer found with email: abul.khayer@hotmail.com
INFO - 2025-04-03 23:41:38 --> Final output sent to browser
DEBUG - 2025-04-03 23:41:38 --> Total execution time: 0.0077
INFO - 2025-04-03 23:46:21 --> Config Class Initialized
INFO - 2025-04-03 23:46:21 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:46:21 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:46:21 --> Utf8 Class Initialized
INFO - 2025-04-03 23:46:21 --> URI Class Initialized
INFO - 2025-04-03 23:46:21 --> Router Class Initialized
INFO - 2025-04-03 23:46:21 --> Output Class Initialized
INFO - 2025-04-03 23:46:21 --> Security Class Initialized
DEBUG - 2025-04-03 23:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:46:21 --> Input Class Initialized
INFO - 2025-04-03 23:46:21 --> Language Class Initialized
INFO - 2025-04-03 23:46:21 --> Language Class Initialized
INFO - 2025-04-03 23:46:21 --> Config Class Initialized
INFO - 2025-04-03 23:46:21 --> Loader Class Initialized
INFO - 2025-04-03 23:46:21 --> Helper loaded: url_helper
INFO - 2025-04-03 23:46:21 --> Helper loaded: file_helper
INFO - 2025-04-03 23:46:21 --> Helper loaded: html_helper
INFO - 2025-04-03 23:46:21 --> Helper loaded: form_helper
INFO - 2025-04-03 23:46:21 --> Helper loaded: text_helper
INFO - 2025-04-03 23:46:21 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:46:21 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:46:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:46:21 --> Database Driver Class Initialized
INFO - 2025-04-03 23:46:21 --> Email Class Initialized
INFO - 2025-04-03 23:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:46:21 --> Form Validation Class Initialized
INFO - 2025-04-03 23:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:46:21 --> Pagination Class Initialized
INFO - 2025-04-03 23:46:21 --> Controller Class Initialized
INFO - 2025-04-03 23:46:21 --> Model Class Initialized
DEBUG - 2025-04-03 23:46:21 --> API Request: customer_comission_by_email | Email: abul.khayer@hotmail.com
DEBUG - 2025-04-03 23:46:21 --> Customer Found: ID = 26
DEBUG - 2025-04-03 23:46:21 --> Commission Found for Customer ID 26 | Value = 16, Type = 1
INFO - 2025-04-03 23:46:21 --> Final output sent to browser
DEBUG - 2025-04-03 23:46:21 --> Total execution time: 0.0090
INFO - 2025-04-03 23:47:26 --> Config Class Initialized
INFO - 2025-04-03 23:47:26 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:47:26 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:47:26 --> Utf8 Class Initialized
INFO - 2025-04-03 23:47:26 --> URI Class Initialized
INFO - 2025-04-03 23:47:26 --> Router Class Initialized
INFO - 2025-04-03 23:47:26 --> Output Class Initialized
INFO - 2025-04-03 23:47:26 --> Security Class Initialized
DEBUG - 2025-04-03 23:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:47:26 --> Input Class Initialized
INFO - 2025-04-03 23:47:26 --> Language Class Initialized
INFO - 2025-04-03 23:47:26 --> Language Class Initialized
INFO - 2025-04-03 23:47:26 --> Config Class Initialized
INFO - 2025-04-03 23:47:26 --> Loader Class Initialized
INFO - 2025-04-03 23:47:26 --> Helper loaded: url_helper
INFO - 2025-04-03 23:47:26 --> Helper loaded: file_helper
INFO - 2025-04-03 23:47:26 --> Helper loaded: html_helper
INFO - 2025-04-03 23:47:26 --> Helper loaded: form_helper
INFO - 2025-04-03 23:47:26 --> Helper loaded: text_helper
INFO - 2025-04-03 23:47:26 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:47:26 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:47:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:47:26 --> Database Driver Class Initialized
INFO - 2025-04-03 23:47:26 --> Email Class Initialized
INFO - 2025-04-03 23:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:47:26 --> Form Validation Class Initialized
INFO - 2025-04-03 23:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:47:26 --> Pagination Class Initialized
INFO - 2025-04-03 23:47:26 --> Controller Class Initialized
INFO - 2025-04-03 23:47:26 --> Model Class Initialized
INFO - 2025-04-03 23:47:26 --> Final output sent to browser
DEBUG - 2025-04-03 23:47:26 --> Total execution time: 0.0082
INFO - 2025-04-03 23:47:36 --> Config Class Initialized
INFO - 2025-04-03 23:47:36 --> Hooks Class Initialized
DEBUG - 2025-04-03 23:47:36 --> UTF-8 Support Enabled
INFO - 2025-04-03 23:47:36 --> Utf8 Class Initialized
INFO - 2025-04-03 23:47:36 --> URI Class Initialized
INFO - 2025-04-03 23:47:36 --> Router Class Initialized
INFO - 2025-04-03 23:47:36 --> Output Class Initialized
INFO - 2025-04-03 23:47:36 --> Security Class Initialized
DEBUG - 2025-04-03 23:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-03 23:47:36 --> Input Class Initialized
INFO - 2025-04-03 23:47:36 --> Language Class Initialized
INFO - 2025-04-03 23:47:36 --> Language Class Initialized
INFO - 2025-04-03 23:47:36 --> Config Class Initialized
INFO - 2025-04-03 23:47:36 --> Loader Class Initialized
INFO - 2025-04-03 23:47:36 --> Helper loaded: url_helper
INFO - 2025-04-03 23:47:36 --> Helper loaded: file_helper
INFO - 2025-04-03 23:47:36 --> Helper loaded: html_helper
INFO - 2025-04-03 23:47:36 --> Helper loaded: form_helper
INFO - 2025-04-03 23:47:36 --> Helper loaded: text_helper
INFO - 2025-04-03 23:47:36 --> Helper loaded: lang_helper
INFO - 2025-04-03 23:47:36 --> Helper loaded: directory_helper
INFO - 2025-04-03 23:47:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-03 23:47:36 --> Database Driver Class Initialized
INFO - 2025-04-03 23:47:36 --> Email Class Initialized
INFO - 2025-04-03 23:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-03 23:47:36 --> Form Validation Class Initialized
INFO - 2025-04-03 23:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-03 23:47:36 --> Pagination Class Initialized
INFO - 2025-04-03 23:47:36 --> Controller Class Initialized
INFO - 2025-04-03 23:47:36 --> Model Class Initialized
DEBUG - 2025-04-03 23:47:36 --> API Request: customer_comission_by_email | Email: abul.khayer@hotmail.com
DEBUG - 2025-04-03 23:47:36 --> Customer Found: ID = 26
DEBUG - 2025-04-03 23:47:36 --> Commission Found for Customer ID 26 | Value = 16, Type = 1
INFO - 2025-04-03 23:47:36 --> Final output sent to browser
DEBUG - 2025-04-03 23:47:36 --> Total execution time: 0.0048
