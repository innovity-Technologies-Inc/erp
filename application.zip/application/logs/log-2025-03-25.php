<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-25 00:31:04 --> Model Class Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:31:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
ERROR - 2025-03-25 00:31:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:31:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:31:04 --> Final output sent to browser
DEBUG - 2025-03-25 00:31:04 --> Total execution time: 0.1105
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
DEBUG - 2025-03-25 00:31:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:31:04 --> Model Class Initialized
INFO - 2025-03-25 00:31:04 --> Final output sent to browser
DEBUG - 2025-03-25 00:31:04 --> Total execution time: 0.0497
INFO - 2025-03-25 00:33:30 --> Model Class Initialized
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:33:30 --> Model Class Initialized
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 00:33:30 --> Model Class Initialized
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:33:30 --> Model Class Initialized
ERROR - 2025-03-25 00:33:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 00:33:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 00:33:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 00:33:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:33:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:33:30 --> Model Class Initialized
ERROR - 2025-03-25 00:33:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:33:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 00:33:30 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:33:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:33:30 --> Final output sent to browser
DEBUG - 2025-03-25 00:33:30 --> Total execution time: 0.1365
INFO - 2025-03-25 00:38:07 --> Model Class Initialized
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:38:07 --> Model Class Initialized
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 00:38:07 --> Model Class Initialized
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:38:07 --> Model Class Initialized
ERROR - 2025-03-25 00:38:07 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 00:38:07 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 00:38:07 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 00:38:07 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:38:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:38:07 --> Model Class Initialized
ERROR - 2025-03-25 00:38:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:38:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 00:38:07 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:38:07 --> Final output sent to browser
DEBUG - 2025-03-25 00:38:07 --> Total execution time: 0.1216
INFO - 2025-03-25 01:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 01:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 01:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 01:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 01:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:13:54 --> Model Class Initialized
ERROR - 2025-03-25 01:13:54 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 01:13:54 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 01:13:54 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 01:13:54 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 01:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 01:13:54 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 01:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 01:13:54 --> Model Class Initialized
ERROR - 2025-03-25 01:13:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 01:13:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 01:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 01:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 01:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 01:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 01:13:55 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 01:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 01:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 01:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 01:13:55 --> Final output sent to browser
DEBUG - 2025-03-25 01:13:55 --> Total execution time: 0.7929
INFO - 2025-03-25 02:09:00 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:00 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:00 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:00 --> Model Class Initialized
ERROR - 2025-03-25 02:09:00 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:09:00 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:09:00 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:09:00 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:09:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:09:00 --> Model Class Initialized
ERROR - 2025-03-25 02:09:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:09:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:09:00 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:09:00 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:00 --> Total execution time: 0.6140
INFO - 2025-03-25 02:09:26 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:26 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:26 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:26 --> Model Class Initialized
INFO - 2025-03-25 02:09:26 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:26 --> Total execution time: 0.0076
INFO - 2025-03-25 02:09:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:27 --> Model Class Initialized
INFO - 2025-03-25 02:09:27 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:27 --> Total execution time: 0.0199
INFO - 2025-03-25 02:09:31 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:31 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:31 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:31 --> Model Class Initialized
INFO - 2025-03-25 02:09:31 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:31 --> Total execution time: 0.0087
INFO - 2025-03-25 02:09:33 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:33 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:33 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:33 --> Model Class Initialized
INFO - 2025-03-25 02:09:33 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:33 --> Total execution time: 0.0151
INFO - 2025-03-25 02:09:34 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:34 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:34 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:34 --> Model Class Initialized
INFO - 2025-03-25 02:09:34 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:34 --> Total execution time: 0.0172
INFO - 2025-03-25 02:09:36 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:36 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:36 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:36 --> Model Class Initialized
INFO - 2025-03-25 02:09:36 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:36 --> Total execution time: 0.0063
INFO - 2025-03-25 02:09:38 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:38 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:38 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:38 --> Model Class Initialized
INFO - 2025-03-25 02:09:38 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:38 --> Total execution time: 0.0119
INFO - 2025-03-25 02:09:39 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:39 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:39 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:39 --> Model Class Initialized
INFO - 2025-03-25 02:09:39 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:39 --> Total execution time: 0.0141
INFO - 2025-03-25 02:09:41 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:09:41 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:09:41 --> Model Class Initialized
DEBUG - 2025-03-25 02:09:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:09:41 --> Model Class Initialized
INFO - 2025-03-25 02:09:41 --> Final output sent to browser
DEBUG - 2025-03-25 02:09:41 --> Total execution time: 0.0054
INFO - 2025-03-25 02:13:30 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:13:30 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:13:30 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:13:30 --> Model Class Initialized
ERROR - 2025-03-25 02:13:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:13:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:13:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:13:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:13:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:13:30 --> Model Class Initialized
ERROR - 2025-03-25 02:13:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:13:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:13:30 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:13:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:13:30 --> Final output sent to browser
DEBUG - 2025-03-25 02:13:30 --> Total execution time: 0.1261
INFO - 2025-03-25 02:13:53 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:13:53 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:13:53 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:13:53 --> Model Class Initialized
ERROR - 2025-03-25 02:13:53 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 1654
INFO - 2025-03-25 02:13:53 --> Final output sent to browser
DEBUG - 2025-03-25 02:13:53 --> Total execution time: 0.0103
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
INFO - 2025-03-25 02:13:54 --> Final output sent to browser
DEBUG - 2025-03-25 02:13:54 --> Total execution time: 0.0046
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:13:54 --> Model Class Initialized
INFO - 2025-03-25 02:13:54 --> Final output sent to browser
DEBUG - 2025-03-25 02:13:54 --> Total execution time: 0.0110
INFO - 2025-03-25 02:13:55 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:13:55 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:13:55 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:13:55 --> Model Class Initialized
INFO - 2025-03-25 02:13:55 --> Final output sent to browser
DEBUG - 2025-03-25 02:13:55 --> Total execution time: 0.0080
INFO - 2025-03-25 02:13:57 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:13:57 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:13:57 --> Model Class Initialized
DEBUG - 2025-03-25 02:13:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:13:57 --> Model Class Initialized
INFO - 2025-03-25 02:13:57 --> Final output sent to browser
DEBUG - 2025-03-25 02:13:57 --> Total execution time: 0.0088
INFO - 2025-03-25 02:14:09 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:09 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:09 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:09 --> Model Class Initialized
INFO - 2025-03-25 02:14:09 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:09 --> Total execution time: 0.0103
INFO - 2025-03-25 02:14:10 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:10 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:10 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:10 --> Model Class Initialized
INFO - 2025-03-25 02:14:10 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:10 --> Total execution time: 0.0139
INFO - 2025-03-25 02:14:14 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:14 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:14 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:14 --> Model Class Initialized
INFO - 2025-03-25 02:14:14 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:14 --> Total execution time: 0.0087
INFO - 2025-03-25 02:14:35 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:35 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:35 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:35 --> Model Class Initialized
ERROR - 2025-03-25 02:14:35 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:14:35 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:14:35 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:14:35 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:14:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:14:35 --> Model Class Initialized
ERROR - 2025-03-25 02:14:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:14:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:14:35 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:14:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:14:35 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:35 --> Total execution time: 0.1259
INFO - 2025-03-25 02:14:44 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:44 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:44 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:44 --> Model Class Initialized
INFO - 2025-03-25 02:14:44 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:44 --> Total execution time: 0.0069
INFO - 2025-03-25 02:14:46 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:46 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:46 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:46 --> Model Class Initialized
INFO - 2025-03-25 02:14:46 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:46 --> Total execution time: 0.0066
INFO - 2025-03-25 02:14:48 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:48 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:48 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:48 --> Model Class Initialized
INFO - 2025-03-25 02:14:48 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:48 --> Total execution time: 0.0063
INFO - 2025-03-25 02:14:50 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:50 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:50 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:50 --> Model Class Initialized
INFO - 2025-03-25 02:14:50 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:50 --> Total execution time: 0.0130
INFO - 2025-03-25 02:14:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:14:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:14:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:14:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:14:54 --> Model Class Initialized
INFO - 2025-03-25 02:14:54 --> Final output sent to browser
DEBUG - 2025-03-25 02:14:54 --> Total execution time: 0.0065
INFO - 2025-03-25 02:18:12 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:12 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:12 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:12 --> Model Class Initialized
ERROR - 2025-03-25 02:18:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:18:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:18:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:18:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:18:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:18:12 --> Model Class Initialized
ERROR - 2025-03-25 02:18:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:18:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:18:12 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:18:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:18:12 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:12 --> Total execution time: 0.1157
INFO - 2025-03-25 02:18:14 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:14 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:14 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:14 --> Model Class Initialized
ERROR - 2025-03-25 02:18:14 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:18:14 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:18:14 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:18:14 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:18:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:18:14 --> Model Class Initialized
ERROR - 2025-03-25 02:18:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:18:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:18:14 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:18:14 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:14 --> Total execution time: 0.1312
INFO - 2025-03-25 02:18:21 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:21 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:21 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:21 --> Model Class Initialized
INFO - 2025-03-25 02:18:21 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:21 --> Total execution time: 0.0081
INFO - 2025-03-25 02:18:23 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:23 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:23 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:23 --> Model Class Initialized
INFO - 2025-03-25 02:18:23 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:23 --> Total execution time: 0.0084
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
INFO - 2025-03-25 02:18:24 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:24 --> Total execution time: 0.0097
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:24 --> Model Class Initialized
INFO - 2025-03-25 02:18:24 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:24 --> Total execution time: 0.0060
INFO - 2025-03-25 02:18:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:27 --> Model Class Initialized
INFO - 2025-03-25 02:18:27 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:27 --> Total execution time: 0.0075
INFO - 2025-03-25 02:18:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:28 --> Model Class Initialized
INFO - 2025-03-25 02:18:28 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:28 --> Total execution time: 0.0125
INFO - 2025-03-25 02:18:30 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:18:30 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:18:30 --> Model Class Initialized
DEBUG - 2025-03-25 02:18:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:18:30 --> Model Class Initialized
INFO - 2025-03-25 02:18:30 --> Final output sent to browser
DEBUG - 2025-03-25 02:18:30 --> Total execution time: 0.0073
INFO - 2025-03-25 02:20:00 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:20:00 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:20:00 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:20:00 --> Model Class Initialized
ERROR - 2025-03-25 02:20:00 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:20:00 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:20:00 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:20:00 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:20:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:20:00 --> Model Class Initialized
ERROR - 2025-03-25 02:20:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:20:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:20:00 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:20:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:20:00 --> Final output sent to browser
DEBUG - 2025-03-25 02:20:00 --> Total execution time: 0.1187
INFO - 2025-03-25 02:20:06 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:20:06 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:20:06 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:20:06 --> Model Class Initialized
INFO - 2025-03-25 02:20:06 --> Final output sent to browser
DEBUG - 2025-03-25 02:20:06 --> Total execution time: 0.0077
INFO - 2025-03-25 02:20:07 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:20:07 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:20:07 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:20:07 --> Model Class Initialized
INFO - 2025-03-25 02:20:07 --> Final output sent to browser
DEBUG - 2025-03-25 02:20:07 --> Total execution time: 0.0082
INFO - 2025-03-25 02:20:11 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:20:11 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:20:11 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:20:11 --> Model Class Initialized
INFO - 2025-03-25 02:20:11 --> Final output sent to browser
DEBUG - 2025-03-25 02:20:11 --> Total execution time: 0.0081
INFO - 2025-03-25 02:20:12 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:20:12 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:20:12 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:20:12 --> Model Class Initialized
INFO - 2025-03-25 02:20:12 --> Final output sent to browser
DEBUG - 2025-03-25 02:20:12 --> Total execution time: 0.0139
INFO - 2025-03-25 02:20:22 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:20:22 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:20:22 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:20:22 --> Model Class Initialized
INFO - 2025-03-25 02:20:22 --> Final output sent to browser
DEBUG - 2025-03-25 02:20:22 --> Total execution time: 0.0074
INFO - 2025-03-25 02:20:43 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:20:43 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:20:43 --> Model Class Initialized
DEBUG - 2025-03-25 02:20:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:20:43 --> Model Class Initialized
INFO - 2025-03-25 02:20:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-03-25 02:20:43 --> Severity: error --> Exception: Column 'total_vat_amnt' cannot be null /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-25 02:21:19 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:21:19 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:21:19 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:21:19 --> Model Class Initialized
ERROR - 2025-03-25 02:21:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:21:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:21:19 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:21:19 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:21:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:21:19 --> Model Class Initialized
ERROR - 2025-03-25 02:21:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:21:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:21:19 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:21:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:21:19 --> Final output sent to browser
DEBUG - 2025-03-25 02:21:19 --> Total execution time: 0.1195
INFO - 2025-03-25 02:21:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:21:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:21:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:21:24 --> Model Class Initialized
INFO - 2025-03-25 02:21:24 --> Final output sent to browser
DEBUG - 2025-03-25 02:21:24 --> Total execution time: 0.0110
INFO - 2025-03-25 02:21:25 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:21:25 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:21:25 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:21:25 --> Model Class Initialized
INFO - 2025-03-25 02:21:25 --> Final output sent to browser
DEBUG - 2025-03-25 02:21:25 --> Total execution time: 0.0102
INFO - 2025-03-25 02:21:26 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:21:26 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:21:26 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:21:26 --> Model Class Initialized
INFO - 2025-03-25 02:21:26 --> Final output sent to browser
DEBUG - 2025-03-25 02:21:26 --> Total execution time: 0.0083
INFO - 2025-03-25 02:21:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:21:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:21:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:21:28 --> Model Class Initialized
INFO - 2025-03-25 02:21:28 --> Final output sent to browser
DEBUG - 2025-03-25 02:21:28 --> Total execution time: 0.0097
INFO - 2025-03-25 02:21:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:21:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:21:29 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:21:29 --> Model Class Initialized
INFO - 2025-03-25 02:21:29 --> Final output sent to browser
DEBUG - 2025-03-25 02:21:29 --> Total execution time: 0.0161
INFO - 2025-03-25 02:21:31 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:21:31 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:21:31 --> Model Class Initialized
DEBUG - 2025-03-25 02:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:21:31 --> Model Class Initialized
INFO - 2025-03-25 02:21:31 --> Final output sent to browser
DEBUG - 2025-03-25 02:21:31 --> Total execution time: 0.0091
INFO - 2025-03-25 02:23:13 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:23:13 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:23:13 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:23:13 --> Model Class Initialized
ERROR - 2025-03-25 02:23:13 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:23:13 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:23:13 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:23:13 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:23:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:23:13 --> Model Class Initialized
ERROR - 2025-03-25 02:23:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:23:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:23:13 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:23:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:23:13 --> Final output sent to browser
DEBUG - 2025-03-25 02:23:13 --> Total execution time: 0.0916
INFO - 2025-03-25 02:23:17 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:23:17 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:23:17 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:23:17 --> Model Class Initialized
INFO - 2025-03-25 02:23:17 --> Final output sent to browser
DEBUG - 2025-03-25 02:23:17 --> Total execution time: 0.0047
INFO - 2025-03-25 02:23:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:23:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:23:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:23:18 --> Model Class Initialized
INFO - 2025-03-25 02:23:18 --> Final output sent to browser
DEBUG - 2025-03-25 02:23:18 --> Total execution time: 0.0172
INFO - 2025-03-25 02:23:21 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:23:21 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:23:21 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:23:21 --> Model Class Initialized
INFO - 2025-03-25 02:23:21 --> Final output sent to browser
DEBUG - 2025-03-25 02:23:21 --> Total execution time: 0.0071
INFO - 2025-03-25 02:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:23:22 --> Model Class Initialized
INFO - 2025-03-25 02:23:22 --> Final output sent to browser
DEBUG - 2025-03-25 02:23:22 --> Total execution time: 0.0134
INFO - 2025-03-25 02:23:25 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:23:25 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:23:25 --> Model Class Initialized
DEBUG - 2025-03-25 02:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:23:25 --> Model Class Initialized
INFO - 2025-03-25 02:23:25 --> Final output sent to browser
DEBUG - 2025-03-25 02:23:25 --> Total execution time: 0.0103
INFO - 2025-03-25 02:26:42 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:26:42 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:26:42 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:26:42 --> Model Class Initialized
ERROR - 2025-03-25 02:26:42 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:26:42 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:26:42 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:26:42 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:26:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:26:42 --> Model Class Initialized
ERROR - 2025-03-25 02:26:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:26:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:26:42 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:26:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:26:42 --> Final output sent to browser
DEBUG - 2025-03-25 02:26:42 --> Total execution time: 0.1329
INFO - 2025-03-25 02:26:45 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:26:45 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:26:45 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:26:45 --> Model Class Initialized
ERROR - 2025-03-25 02:26:45 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:26:45 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:26:45 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:26:45 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:26:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:26:45 --> Model Class Initialized
ERROR - 2025-03-25 02:26:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:26:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:26:45 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:26:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:26:45 --> Final output sent to browser
DEBUG - 2025-03-25 02:26:45 --> Total execution time: 0.0907
INFO - 2025-03-25 02:26:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:26:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:26:54 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:26:54 --> Model Class Initialized
INFO - 2025-03-25 02:26:54 --> Final output sent to browser
DEBUG - 2025-03-25 02:26:54 --> Total execution time: 0.0080
INFO - 2025-03-25 02:26:55 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:26:55 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:26:55 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:26:55 --> Model Class Initialized
INFO - 2025-03-25 02:26:55 --> Final output sent to browser
DEBUG - 2025-03-25 02:26:55 --> Total execution time: 0.0102
INFO - 2025-03-25 02:26:57 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:26:57 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:26:57 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:26:57 --> Model Class Initialized
INFO - 2025-03-25 02:26:57 --> Final output sent to browser
DEBUG - 2025-03-25 02:26:57 --> Total execution time: 0.0091
INFO - 2025-03-25 02:26:59 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:26:59 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:26:59 --> Model Class Initialized
DEBUG - 2025-03-25 02:26:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:26:59 --> Model Class Initialized
INFO - 2025-03-25 02:26:59 --> Final output sent to browser
DEBUG - 2025-03-25 02:26:59 --> Total execution time: 0.0063
INFO - 2025-03-25 02:27:02 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:27:02 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:27:02 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:27:02 --> Model Class Initialized
INFO - 2025-03-25 02:27:02 --> Final output sent to browser
DEBUG - 2025-03-25 02:27:02 --> Total execution time: 0.0179
INFO - 2025-03-25 02:27:04 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:27:04 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:27:04 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:27:04 --> Model Class Initialized
INFO - 2025-03-25 02:27:04 --> Final output sent to browser
DEBUG - 2025-03-25 02:27:04 --> Total execution time: 0.0083
INFO - 2025-03-25 02:27:10 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:27:10 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:27:10 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:27:10 --> Model Class Initialized
INFO - 2025-03-25 02:27:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-03-25 02:27:10 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 494
ERROR - 2025-03-25 02:27:10 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
DEBUG - 2025-03-25 02:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-03-25 02:27:10 --> Final output sent to browser
DEBUG - 2025-03-25 02:27:10 --> Total execution time: 0.0897
INFO - 2025-03-25 02:27:13 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:27:13 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:27:13 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:27:13 --> Model Class Initialized
ERROR - 2025-03-25 02:27:13 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:27:13 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 02:27:13 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 02:27:13 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:27:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:27:13 --> Model Class Initialized
ERROR - 2025-03-25 02:27:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:27:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 02:27:13 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:27:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:27:13 --> Final output sent to browser
DEBUG - 2025-03-25 02:27:13 --> Total execution time: 0.1309
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:27:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
ERROR - 2025-03-25 02:27:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:27:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:27:18 --> Final output sent to browser
DEBUG - 2025-03-25 02:27:18 --> Total execution time: 0.1082
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:27:18 --> Model Class Initialized
INFO - 2025-03-25 02:27:18 --> Final output sent to browser
DEBUG - 2025-03-25 02:27:18 --> Total execution time: 0.0466
INFO - 2025-03-25 02:27:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:27:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:27:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:27:24 --> Model Class Initialized
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:27:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:27:24 --> Model Class Initialized
ERROR - 2025-03-25 02:27:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:27:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:27:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:27:24 --> Final output sent to browser
DEBUG - 2025-03-25 02:27:24 --> Total execution time: 0.0841
INFO - 2025-03-25 02:38:48 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:38:48 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:38:48 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:38:48 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:38:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:38:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:38:48 --> Model Class Initialized
ERROR - 2025-03-25 02:38:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:38:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:38:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:38:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:38:49 --> Final output sent to browser
DEBUG - 2025-03-25 02:38:49 --> Total execution time: 0.1181
INFO - 2025-03-25 02:38:49 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:38:49 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:38:49 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:38:49 --> Model Class Initialized
INFO - 2025-03-25 02:38:49 --> Final output sent to browser
DEBUG - 2025-03-25 02:38:49 --> Total execution time: 0.0524
INFO - 2025-03-25 02:38:50 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:38:50 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:38:50 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:38:50 --> Model Class Initialized
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:38:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:38:50 --> Model Class Initialized
ERROR - 2025-03-25 02:38:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:38:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:38:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:38:50 --> Final output sent to browser
DEBUG - 2025-03-25 02:38:50 --> Total execution time: 0.0913
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:56:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
ERROR - 2025-03-25 02:56:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:56:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:56:27 --> Final output sent to browser
DEBUG - 2025-03-25 02:56:27 --> Total execution time: 0.0922
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:56:27 --> Model Class Initialized
INFO - 2025-03-25 02:56:27 --> Final output sent to browser
DEBUG - 2025-03-25 02:56:27 --> Total execution time: 0.0358
INFO - 2025-03-25 02:56:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 02:56:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 02:56:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 02:56:28 --> Model Class Initialized
DEBUG - 2025-03-25 02:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 02:56:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 02:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 02:56:28 --> Model Class Initialized
ERROR - 2025-03-25 02:56:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 02:56:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 02:56:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 02:56:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 02:56:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 02:56:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 02:56:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 02:56:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 02:56:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 02:56:29 --> Final output sent to browser
DEBUG - 2025-03-25 02:56:29 --> Total execution time: 0.1138
INFO - 2025-03-25 05:26:06 --> Model Class Initialized
DEBUG - 2025-03-25 05:26:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 05:26:06 --> Model Class Initialized
DEBUG - 2025-03-25 05:26:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 05:26:06 --> Model Class Initialized
DEBUG - 2025-03-25 05:26:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 05:26:06 --> Model Class Initialized
INFO - 2025-03-25 05:27:03 --> Model Class Initialized
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 05:27:03 --> Model Class Initialized
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 05:27:03 --> Model Class Initialized
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 05:27:03 --> Model Class Initialized
ERROR - 2025-03-25 05:27:03 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 05:27:03 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 05:27:03 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 05:27:03 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 05:27:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 05:27:03 --> Model Class Initialized
ERROR - 2025-03-25 05:27:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 05:27:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 05:27:03 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 05:27:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 05:27:03 --> Final output sent to browser
DEBUG - 2025-03-25 05:27:03 --> Total execution time: 0.1124
INFO - 2025-03-25 05:27:12 --> Model Class Initialized
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 05:27:12 --> Model Class Initialized
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 05:27:12 --> Model Class Initialized
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 05:27:12 --> Model Class Initialized
ERROR - 2025-03-25 05:27:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 05:27:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 05:27:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 05:27:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 05:27:12 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 05:27:12 --> Model Class Initialized
ERROR - 2025-03-25 05:27:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 05:27:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 05:27:12 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 05:27:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 05:27:12 --> Final output sent to browser
DEBUG - 2025-03-25 05:27:12 --> Total execution time: 0.1251
INFO - 2025-03-25 00:18:43 --> Config Class Initialized
INFO - 2025-03-25 00:18:43 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:18:43 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:18:43 --> Utf8 Class Initialized
INFO - 2025-03-25 00:18:43 --> URI Class Initialized
INFO - 2025-03-25 00:18:43 --> Router Class Initialized
INFO - 2025-03-25 00:18:43 --> Output Class Initialized
INFO - 2025-03-25 00:18:43 --> Security Class Initialized
DEBUG - 2025-03-25 00:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:18:43 --> Input Class Initialized
INFO - 2025-03-25 00:18:43 --> Language Class Initialized
INFO - 2025-03-25 00:18:43 --> Language Class Initialized
INFO - 2025-03-25 00:18:43 --> Config Class Initialized
INFO - 2025-03-25 00:18:43 --> Loader Class Initialized
INFO - 2025-03-25 00:18:43 --> Helper loaded: url_helper
INFO - 2025-03-25 00:18:43 --> Helper loaded: file_helper
INFO - 2025-03-25 00:18:43 --> Helper loaded: html_helper
INFO - 2025-03-25 00:18:43 --> Helper loaded: form_helper
INFO - 2025-03-25 00:18:43 --> Helper loaded: text_helper
INFO - 2025-03-25 00:18:43 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:18:43 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:18:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:18:43 --> Database Driver Class Initialized
INFO - 2025-03-25 00:18:43 --> Email Class Initialized
INFO - 2025-03-25 00:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:18:43 --> Form Validation Class Initialized
INFO - 2025-03-25 00:18:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:18:43 --> Pagination Class Initialized
INFO - 2025-03-25 00:18:43 --> Controller Class Initialized
INFO - 2025-03-25 00:18:43 --> Model Class Initialized
DEBUG - 2025-03-25 00:18:43 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:18:43 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:18:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:18:43 --> Model Class Initialized
ERROR - 2025-03-25 00:18:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-25 00:19:31 --> Config Class Initialized
INFO - 2025-03-25 00:19:31 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:19:31 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:19:31 --> Utf8 Class Initialized
INFO - 2025-03-25 00:19:31 --> URI Class Initialized
INFO - 2025-03-25 00:19:31 --> Router Class Initialized
INFO - 2025-03-25 00:19:31 --> Output Class Initialized
INFO - 2025-03-25 00:19:31 --> Security Class Initialized
DEBUG - 2025-03-25 00:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:19:31 --> Input Class Initialized
INFO - 2025-03-25 00:19:31 --> Language Class Initialized
INFO - 2025-03-25 00:19:31 --> Language Class Initialized
INFO - 2025-03-25 00:19:31 --> Config Class Initialized
INFO - 2025-03-25 00:19:31 --> Loader Class Initialized
INFO - 2025-03-25 00:19:31 --> Helper loaded: url_helper
INFO - 2025-03-25 00:19:31 --> Helper loaded: file_helper
INFO - 2025-03-25 00:19:31 --> Helper loaded: html_helper
INFO - 2025-03-25 00:19:31 --> Helper loaded: form_helper
INFO - 2025-03-25 00:19:31 --> Helper loaded: text_helper
INFO - 2025-03-25 00:19:31 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:19:31 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:19:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:19:31 --> Database Driver Class Initialized
INFO - 2025-03-25 00:19:31 --> Email Class Initialized
INFO - 2025-03-25 00:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:19:31 --> Form Validation Class Initialized
INFO - 2025-03-25 00:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:19:31 --> Pagination Class Initialized
INFO - 2025-03-25 00:19:31 --> Controller Class Initialized
INFO - 2025-03-25 00:19:31 --> Model Class Initialized
DEBUG - 2025-03-25 00:19:31 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:19:31 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:19:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:19:31 --> Model Class Initialized
ERROR - 2025-03-25 00:19:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/system/core/Loader.php 344
INFO - 2025-03-25 00:21:25 --> Config Class Initialized
INFO - 2025-03-25 00:21:25 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:21:25 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:21:25 --> Utf8 Class Initialized
INFO - 2025-03-25 00:21:25 --> URI Class Initialized
INFO - 2025-03-25 00:21:25 --> Router Class Initialized
INFO - 2025-03-25 00:21:25 --> Output Class Initialized
INFO - 2025-03-25 00:21:25 --> Security Class Initialized
DEBUG - 2025-03-25 00:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:21:25 --> Input Class Initialized
INFO - 2025-03-25 00:21:25 --> Language Class Initialized
INFO - 2025-03-25 00:21:25 --> Language Class Initialized
INFO - 2025-03-25 00:21:25 --> Config Class Initialized
INFO - 2025-03-25 00:21:25 --> Loader Class Initialized
INFO - 2025-03-25 00:21:25 --> Helper loaded: url_helper
INFO - 2025-03-25 00:21:25 --> Helper loaded: file_helper
INFO - 2025-03-25 00:21:25 --> Helper loaded: html_helper
INFO - 2025-03-25 00:21:25 --> Helper loaded: form_helper
INFO - 2025-03-25 00:21:25 --> Helper loaded: text_helper
INFO - 2025-03-25 00:21:25 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:21:25 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:21:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:21:25 --> Database Driver Class Initialized
INFO - 2025-03-25 00:21:25 --> Email Class Initialized
INFO - 2025-03-25 00:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:21:25 --> Form Validation Class Initialized
INFO - 2025-03-25 00:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:21:25 --> Pagination Class Initialized
INFO - 2025-03-25 00:21:25 --> Controller Class Initialized
INFO - 2025-03-25 00:21:25 --> Model Class Initialized
DEBUG - 2025-03-25 00:21:25 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:21:25 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:21:25 --> Model Class Initialized
DEBUG - 2025-03-25 00:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:21:25 --> Model Class Initialized
INFO - 2025-03-25 00:21:25 --> Final output sent to browser
DEBUG - 2025-03-25 00:21:25 --> Total execution time: 0.0217
INFO - 2025-03-25 00:25:06 --> Config Class Initialized
INFO - 2025-03-25 00:25:06 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:25:06 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:25:06 --> Utf8 Class Initialized
INFO - 2025-03-25 00:25:06 --> URI Class Initialized
INFO - 2025-03-25 00:25:06 --> Router Class Initialized
INFO - 2025-03-25 00:25:06 --> Output Class Initialized
INFO - 2025-03-25 00:25:06 --> Security Class Initialized
DEBUG - 2025-03-25 00:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:25:06 --> Input Class Initialized
INFO - 2025-03-25 00:25:06 --> Language Class Initialized
INFO - 2025-03-25 00:25:06 --> Language Class Initialized
INFO - 2025-03-25 00:25:06 --> Config Class Initialized
INFO - 2025-03-25 00:25:06 --> Loader Class Initialized
INFO - 2025-03-25 00:25:06 --> Helper loaded: url_helper
INFO - 2025-03-25 00:25:06 --> Helper loaded: file_helper
INFO - 2025-03-25 00:25:06 --> Helper loaded: html_helper
INFO - 2025-03-25 00:25:06 --> Helper loaded: form_helper
INFO - 2025-03-25 00:25:06 --> Helper loaded: text_helper
INFO - 2025-03-25 00:25:06 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:25:06 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:25:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:25:06 --> Database Driver Class Initialized
INFO - 2025-03-25 00:25:06 --> Email Class Initialized
INFO - 2025-03-25 00:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:25:06 --> Form Validation Class Initialized
INFO - 2025-03-25 00:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:25:06 --> Pagination Class Initialized
INFO - 2025-03-25 00:25:06 --> Controller Class Initialized
INFO - 2025-03-25 00:25:06 --> Model Class Initialized
DEBUG - 2025-03-25 00:25:06 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:25:06 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:25:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:25:06 --> Model Class Initialized
DEBUG - 2025-03-25 00:25:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:25:06 --> Model Class Initialized
INFO - 2025-03-25 00:25:06 --> Final output sent to browser
DEBUG - 2025-03-25 00:25:06 --> Total execution time: 0.0207
INFO - 2025-03-25 00:49:29 --> Config Class Initialized
INFO - 2025-03-25 00:49:29 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:49:29 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:49:29 --> Utf8 Class Initialized
INFO - 2025-03-25 00:49:29 --> URI Class Initialized
INFO - 2025-03-25 00:49:29 --> Router Class Initialized
INFO - 2025-03-25 00:49:29 --> Output Class Initialized
INFO - 2025-03-25 00:49:29 --> Security Class Initialized
DEBUG - 2025-03-25 00:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:49:29 --> Input Class Initialized
INFO - 2025-03-25 00:49:29 --> Language Class Initialized
INFO - 2025-03-25 00:49:29 --> Language Class Initialized
INFO - 2025-03-25 00:49:29 --> Config Class Initialized
INFO - 2025-03-25 00:49:29 --> Loader Class Initialized
INFO - 2025-03-25 00:49:29 --> Helper loaded: url_helper
INFO - 2025-03-25 00:49:29 --> Helper loaded: file_helper
INFO - 2025-03-25 00:49:29 --> Helper loaded: html_helper
INFO - 2025-03-25 00:49:29 --> Helper loaded: form_helper
INFO - 2025-03-25 00:49:29 --> Helper loaded: text_helper
INFO - 2025-03-25 00:49:29 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:49:29 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:49:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:49:29 --> Database Driver Class Initialized
INFO - 2025-03-25 00:49:29 --> Email Class Initialized
INFO - 2025-03-25 00:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:49:29 --> Form Validation Class Initialized
INFO - 2025-03-25 00:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:49:29 --> Pagination Class Initialized
INFO - 2025-03-25 00:49:29 --> Controller Class Initialized
INFO - 2025-03-25 00:49:29 --> Model Class Initialized
DEBUG - 2025-03-25 00:49:29 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:49:29 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:49:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:49:29 --> Model Class Initialized
DEBUG - 2025-03-25 00:49:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:49:29 --> Model Class Initialized
ERROR - 2025-03-25 00:49:29 --> Severity: Warning --> Undefined property: Api::$Accounts_model /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 2019
ERROR - 2025-03-25 00:49:29 --> Severity: error --> Exception: Call to a member function approved_vaucher() on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 2019
INFO - 2025-03-25 00:51:00 --> Config Class Initialized
INFO - 2025-03-25 00:51:00 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:51:00 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:51:00 --> Utf8 Class Initialized
INFO - 2025-03-25 00:51:00 --> URI Class Initialized
INFO - 2025-03-25 00:51:00 --> Router Class Initialized
INFO - 2025-03-25 00:51:00 --> Output Class Initialized
INFO - 2025-03-25 00:51:00 --> Security Class Initialized
DEBUG - 2025-03-25 00:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:51:00 --> Input Class Initialized
INFO - 2025-03-25 00:51:00 --> Language Class Initialized
INFO - 2025-03-25 00:51:00 --> Language Class Initialized
INFO - 2025-03-25 00:51:00 --> Config Class Initialized
INFO - 2025-03-25 00:51:00 --> Loader Class Initialized
INFO - 2025-03-25 00:51:00 --> Helper loaded: url_helper
INFO - 2025-03-25 00:51:00 --> Helper loaded: file_helper
INFO - 2025-03-25 00:51:00 --> Helper loaded: html_helper
INFO - 2025-03-25 00:51:00 --> Helper loaded: form_helper
INFO - 2025-03-25 00:51:00 --> Helper loaded: text_helper
INFO - 2025-03-25 00:51:00 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:51:00 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:51:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:51:00 --> Database Driver Class Initialized
INFO - 2025-03-25 00:51:00 --> Email Class Initialized
INFO - 2025-03-25 00:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:51:00 --> Form Validation Class Initialized
INFO - 2025-03-25 00:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:51:00 --> Pagination Class Initialized
INFO - 2025-03-25 00:51:00 --> Controller Class Initialized
INFO - 2025-03-25 00:51:00 --> Model Class Initialized
DEBUG - 2025-03-25 00:51:00 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:51:00 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:51:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:51:00 --> Model Class Initialized
DEBUG - 2025-03-25 00:51:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:51:00 --> Model Class Initialized
DEBUG - 2025-03-25 00:51:00 --> 👤 Session set for user ID: 35
DEBUG - 2025-03-25 00:51:00 --> 🧮 Calculated grand total: 59.44
DEBUG - 2025-03-25 00:51:00 --> ✅ Invoice inserted: ID 77
DEBUG - 2025-03-25 00:51:00 --> 📦 Calculated total purchase value: 49.14
DEBUG - 2025-03-25 00:51:00 --> ✅ Invoice details inserted
DEBUG - 2025-03-25 00:51:00 --> 🧾 Approving vouchers for invoice_no = 1076
DEBUG - 2025-03-25 00:51:00 --> 🎉 Invoice successfully completed via API
INFO - 2025-03-25 00:51:00 --> Final output sent to browser
DEBUG - 2025-03-25 00:51:00 --> Total execution time: 0.0152
INFO - 2025-03-25 00:52:00 --> Config Class Initialized
INFO - 2025-03-25 00:52:00 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:52:00 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:52:00 --> Utf8 Class Initialized
INFO - 2025-03-25 00:52:00 --> URI Class Initialized
INFO - 2025-03-25 00:52:00 --> Router Class Initialized
INFO - 2025-03-25 00:52:00 --> Output Class Initialized
INFO - 2025-03-25 00:52:00 --> Security Class Initialized
DEBUG - 2025-03-25 00:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:52:00 --> Input Class Initialized
INFO - 2025-03-25 00:52:00 --> Language Class Initialized
INFO - 2025-03-25 00:52:00 --> Language Class Initialized
INFO - 2025-03-25 00:52:00 --> Config Class Initialized
INFO - 2025-03-25 00:52:00 --> Loader Class Initialized
INFO - 2025-03-25 00:52:00 --> Helper loaded: url_helper
INFO - 2025-03-25 00:52:00 --> Helper loaded: file_helper
INFO - 2025-03-25 00:52:00 --> Helper loaded: html_helper
INFO - 2025-03-25 00:52:00 --> Helper loaded: form_helper
INFO - 2025-03-25 00:52:00 --> Helper loaded: text_helper
INFO - 2025-03-25 00:52:00 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:52:00 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:52:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:52:00 --> Database Driver Class Initialized
INFO - 2025-03-25 00:52:00 --> Email Class Initialized
INFO - 2025-03-25 00:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:52:00 --> Form Validation Class Initialized
INFO - 2025-03-25 00:52:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:52:00 --> Pagination Class Initialized
INFO - 2025-03-25 00:52:00 --> Controller Class Initialized
INFO - 2025-03-25 00:52:00 --> Model Class Initialized
DEBUG - 2025-03-25 00:52:00 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:52:00 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:52:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:52:00 --> Model Class Initialized
DEBUG - 2025-03-25 00:52:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:52:00 --> Model Class Initialized
DEBUG - 2025-03-25 00:52:00 --> 👤 Session set for user ID: 35
DEBUG - 2025-03-25 00:52:00 --> 🧮 Calculated grand total: 59.44
DEBUG - 2025-03-25 00:52:00 --> ✅ Invoice inserted: ID 78
DEBUG - 2025-03-25 00:52:00 --> 📦 Calculated total purchase value: 49.14
DEBUG - 2025-03-25 00:52:00 --> ✅ Invoice details inserted
DEBUG - 2025-03-25 00:52:00 --> 🧾 Approving vouchers for invoice_no = 1077
DEBUG - 2025-03-25 00:52:00 --> 🎉 Invoice successfully completed via API
INFO - 2025-03-25 00:52:00 --> Final output sent to browser
DEBUG - 2025-03-25 00:52:00 --> Total execution time: 0.0171
INFO - 2025-03-25 00:52:53 --> Config Class Initialized
INFO - 2025-03-25 00:52:53 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:52:53 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:52:53 --> Utf8 Class Initialized
INFO - 2025-03-25 00:52:53 --> URI Class Initialized
DEBUG - 2025-03-25 00:52:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:52:53 --> Router Class Initialized
INFO - 2025-03-25 00:52:53 --> Output Class Initialized
INFO - 2025-03-25 00:52:53 --> Security Class Initialized
DEBUG - 2025-03-25 00:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:52:53 --> Input Class Initialized
INFO - 2025-03-25 00:52:53 --> Language Class Initialized
INFO - 2025-03-25 00:52:53 --> Language Class Initialized
INFO - 2025-03-25 00:52:53 --> Config Class Initialized
INFO - 2025-03-25 00:52:53 --> Loader Class Initialized
INFO - 2025-03-25 00:52:53 --> Helper loaded: url_helper
INFO - 2025-03-25 00:52:53 --> Helper loaded: file_helper
INFO - 2025-03-25 00:52:53 --> Helper loaded: html_helper
INFO - 2025-03-25 00:52:53 --> Helper loaded: form_helper
INFO - 2025-03-25 00:52:53 --> Helper loaded: text_helper
INFO - 2025-03-25 00:52:53 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:52:53 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:52:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:52:53 --> Database Driver Class Initialized
INFO - 2025-03-25 00:52:53 --> Email Class Initialized
INFO - 2025-03-25 00:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:52:53 --> Form Validation Class Initialized
INFO - 2025-03-25 00:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:52:53 --> Pagination Class Initialized
INFO - 2025-03-25 00:52:53 --> Controller Class Initialized
DEBUG - 2025-03-25 00:52:53 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:52:53 --> Model Class Initialized
DEBUG - 2025-03-25 00:52:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:52:53 --> Model Class Initialized
DEBUG - 2025-03-25 00:52:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:52:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:52:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:52:53 --> Model Class Initialized
ERROR - 2025-03-25 00:52:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:52:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:52:54 --> Final output sent to browser
DEBUG - 2025-03-25 00:52:54 --> Total execution time: 0.8600
INFO - 2025-03-25 00:52:54 --> Config Class Initialized
INFO - 2025-03-25 00:52:54 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:52:54 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:52:54 --> Utf8 Class Initialized
INFO - 2025-03-25 00:52:54 --> URI Class Initialized
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:52:54 --> Router Class Initialized
INFO - 2025-03-25 00:52:54 --> Output Class Initialized
INFO - 2025-03-25 00:52:54 --> Security Class Initialized
DEBUG - 2025-03-25 00:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:52:54 --> Input Class Initialized
INFO - 2025-03-25 00:52:54 --> Language Class Initialized
INFO - 2025-03-25 00:52:54 --> Language Class Initialized
INFO - 2025-03-25 00:52:54 --> Config Class Initialized
INFO - 2025-03-25 00:52:54 --> Loader Class Initialized
INFO - 2025-03-25 00:52:54 --> Helper loaded: url_helper
INFO - 2025-03-25 00:52:54 --> Helper loaded: file_helper
INFO - 2025-03-25 00:52:54 --> Helper loaded: html_helper
INFO - 2025-03-25 00:52:54 --> Helper loaded: form_helper
INFO - 2025-03-25 00:52:54 --> Helper loaded: text_helper
INFO - 2025-03-25 00:52:54 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:52:54 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:52:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:52:54 --> Database Driver Class Initialized
INFO - 2025-03-25 00:52:54 --> Email Class Initialized
INFO - 2025-03-25 00:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:52:54 --> Form Validation Class Initialized
INFO - 2025-03-25 00:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:52:54 --> Pagination Class Initialized
INFO - 2025-03-25 00:52:54 --> Controller Class Initialized
DEBUG - 2025-03-25 00:52:54 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:52:54 --> Model Class Initialized
DEBUG - 2025-03-25 00:52:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:52:54 --> Model Class Initialized
INFO - 2025-03-25 00:52:54 --> Final output sent to browser
DEBUG - 2025-03-25 00:52:54 --> Total execution time: 0.0115
INFO - 2025-03-25 00:53:10 --> Config Class Initialized
INFO - 2025-03-25 00:53:10 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:53:10 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:53:10 --> Utf8 Class Initialized
INFO - 2025-03-25 00:53:10 --> URI Class Initialized
INFO - 2025-03-25 00:53:10 --> Router Class Initialized
INFO - 2025-03-25 00:53:10 --> Output Class Initialized
INFO - 2025-03-25 00:53:10 --> Security Class Initialized
DEBUG - 2025-03-25 00:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:53:10 --> Input Class Initialized
INFO - 2025-03-25 00:53:10 --> Language Class Initialized
INFO - 2025-03-25 00:53:10 --> Language Class Initialized
INFO - 2025-03-25 00:53:10 --> Config Class Initialized
INFO - 2025-03-25 00:53:10 --> Loader Class Initialized
INFO - 2025-03-25 00:53:10 --> Helper loaded: url_helper
INFO - 2025-03-25 00:53:10 --> Helper loaded: file_helper
INFO - 2025-03-25 00:53:10 --> Helper loaded: html_helper
INFO - 2025-03-25 00:53:10 --> Helper loaded: form_helper
INFO - 2025-03-25 00:53:10 --> Helper loaded: text_helper
INFO - 2025-03-25 00:53:10 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:53:10 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:53:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:53:10 --> Database Driver Class Initialized
INFO - 2025-03-25 00:53:10 --> Email Class Initialized
INFO - 2025-03-25 00:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:53:10 --> Form Validation Class Initialized
INFO - 2025-03-25 00:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:53:10 --> Pagination Class Initialized
INFO - 2025-03-25 00:53:10 --> Controller Class Initialized
INFO - 2025-03-25 00:53:10 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:10 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:53:10 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:53:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:53:10 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:53:10 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:10 --> 👤 Session set for user ID: 35
DEBUG - 2025-03-25 00:53:10 --> 🧮 Calculated grand total: 59.44
DEBUG - 2025-03-25 00:53:10 --> ✅ Invoice inserted: ID 79
DEBUG - 2025-03-25 00:53:10 --> 📦 Calculated total purchase value: 49.14
DEBUG - 2025-03-25 00:53:10 --> ✅ Invoice details inserted
DEBUG - 2025-03-25 00:53:10 --> 🧾 Approving vouchers for invoice_no = 1078
DEBUG - 2025-03-25 00:53:10 --> 🎉 Invoice successfully completed via API
INFO - 2025-03-25 00:53:10 --> Final output sent to browser
DEBUG - 2025-03-25 00:53:10 --> Total execution time: 0.0160
INFO - 2025-03-25 00:53:17 --> Config Class Initialized
INFO - 2025-03-25 00:53:17 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:53:17 --> Utf8 Class Initialized
INFO - 2025-03-25 00:53:17 --> URI Class Initialized
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:53:17 --> Router Class Initialized
INFO - 2025-03-25 00:53:17 --> Output Class Initialized
INFO - 2025-03-25 00:53:17 --> Security Class Initialized
DEBUG - 2025-03-25 00:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:53:17 --> Input Class Initialized
INFO - 2025-03-25 00:53:17 --> Language Class Initialized
INFO - 2025-03-25 00:53:17 --> Language Class Initialized
INFO - 2025-03-25 00:53:17 --> Config Class Initialized
INFO - 2025-03-25 00:53:17 --> Loader Class Initialized
INFO - 2025-03-25 00:53:17 --> Helper loaded: url_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: file_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: html_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: form_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: text_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:53:17 --> Database Driver Class Initialized
INFO - 2025-03-25 00:53:17 --> Email Class Initialized
INFO - 2025-03-25 00:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:53:17 --> Form Validation Class Initialized
INFO - 2025-03-25 00:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:53:17 --> Pagination Class Initialized
INFO - 2025-03-25 00:53:17 --> Controller Class Initialized
DEBUG - 2025-03-25 00:53:17 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:53:17 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:53:17 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:53:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:53:17 --> Model Class Initialized
ERROR - 2025-03-25 00:53:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:53:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:53:17 --> Final output sent to browser
DEBUG - 2025-03-25 00:53:17 --> Total execution time: 0.1257
INFO - 2025-03-25 00:53:17 --> Config Class Initialized
INFO - 2025-03-25 00:53:17 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:53:17 --> Utf8 Class Initialized
INFO - 2025-03-25 00:53:17 --> URI Class Initialized
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:53:17 --> Router Class Initialized
INFO - 2025-03-25 00:53:17 --> Output Class Initialized
INFO - 2025-03-25 00:53:17 --> Security Class Initialized
DEBUG - 2025-03-25 00:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:53:17 --> Input Class Initialized
INFO - 2025-03-25 00:53:17 --> Language Class Initialized
INFO - 2025-03-25 00:53:17 --> Language Class Initialized
INFO - 2025-03-25 00:53:17 --> Config Class Initialized
INFO - 2025-03-25 00:53:17 --> Loader Class Initialized
INFO - 2025-03-25 00:53:17 --> Helper loaded: url_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: file_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: html_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: form_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: text_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:53:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:53:17 --> Database Driver Class Initialized
INFO - 2025-03-25 00:53:17 --> Email Class Initialized
INFO - 2025-03-25 00:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:53:17 --> Form Validation Class Initialized
INFO - 2025-03-25 00:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:53:17 --> Pagination Class Initialized
INFO - 2025-03-25 00:53:17 --> Controller Class Initialized
DEBUG - 2025-03-25 00:53:17 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:53:17 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:53:17 --> Model Class Initialized
INFO - 2025-03-25 00:53:17 --> Final output sent to browser
DEBUG - 2025-03-25 00:53:17 --> Total execution time: 0.0106
INFO - 2025-03-25 00:53:18 --> Config Class Initialized
INFO - 2025-03-25 00:53:18 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:53:18 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:53:18 --> Utf8 Class Initialized
INFO - 2025-03-25 00:53:18 --> URI Class Initialized
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:53:18 --> Router Class Initialized
INFO - 2025-03-25 00:53:18 --> Output Class Initialized
INFO - 2025-03-25 00:53:18 --> Security Class Initialized
DEBUG - 2025-03-25 00:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:53:18 --> Input Class Initialized
INFO - 2025-03-25 00:53:18 --> Language Class Initialized
INFO - 2025-03-25 00:53:18 --> Language Class Initialized
INFO - 2025-03-25 00:53:18 --> Config Class Initialized
INFO - 2025-03-25 00:53:18 --> Loader Class Initialized
INFO - 2025-03-25 00:53:18 --> Helper loaded: url_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: file_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: html_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: form_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: text_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:53:18 --> Database Driver Class Initialized
INFO - 2025-03-25 00:53:18 --> Email Class Initialized
INFO - 2025-03-25 00:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:53:18 --> Form Validation Class Initialized
INFO - 2025-03-25 00:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:53:18 --> Pagination Class Initialized
INFO - 2025-03-25 00:53:18 --> Controller Class Initialized
DEBUG - 2025-03-25 00:53:18 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:53:18 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:53:18 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:53:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:53:18 --> Model Class Initialized
ERROR - 2025-03-25 00:53:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:53:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:53:18 --> Final output sent to browser
DEBUG - 2025-03-25 00:53:18 --> Total execution time: 0.0832
INFO - 2025-03-25 00:53:18 --> Config Class Initialized
INFO - 2025-03-25 00:53:18 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:53:18 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:53:18 --> Utf8 Class Initialized
INFO - 2025-03-25 00:53:18 --> URI Class Initialized
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:53:18 --> Router Class Initialized
INFO - 2025-03-25 00:53:18 --> Output Class Initialized
INFO - 2025-03-25 00:53:18 --> Security Class Initialized
DEBUG - 2025-03-25 00:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:53:18 --> Input Class Initialized
INFO - 2025-03-25 00:53:18 --> Language Class Initialized
INFO - 2025-03-25 00:53:18 --> Language Class Initialized
INFO - 2025-03-25 00:53:18 --> Config Class Initialized
INFO - 2025-03-25 00:53:18 --> Loader Class Initialized
INFO - 2025-03-25 00:53:18 --> Helper loaded: url_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: file_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: html_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: form_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: text_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:53:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:53:18 --> Database Driver Class Initialized
INFO - 2025-03-25 00:53:18 --> Email Class Initialized
INFO - 2025-03-25 00:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:53:18 --> Form Validation Class Initialized
INFO - 2025-03-25 00:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:53:18 --> Pagination Class Initialized
INFO - 2025-03-25 00:53:18 --> Controller Class Initialized
DEBUG - 2025-03-25 00:53:18 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:53:18 --> Model Class Initialized
DEBUG - 2025-03-25 00:53:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:53:18 --> Model Class Initialized
INFO - 2025-03-25 00:53:18 --> Final output sent to browser
DEBUG - 2025-03-25 00:53:18 --> Total execution time: 0.0081
INFO - 2025-03-25 00:57:40 --> Config Class Initialized
INFO - 2025-03-25 00:57:40 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:57:40 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:57:40 --> Utf8 Class Initialized
INFO - 2025-03-25 00:57:40 --> URI Class Initialized
INFO - 2025-03-25 00:57:40 --> Router Class Initialized
INFO - 2025-03-25 00:57:40 --> Output Class Initialized
INFO - 2025-03-25 00:57:40 --> Security Class Initialized
DEBUG - 2025-03-25 00:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:57:40 --> Input Class Initialized
INFO - 2025-03-25 00:57:40 --> Language Class Initialized
INFO - 2025-03-25 00:57:40 --> Language Class Initialized
INFO - 2025-03-25 00:57:40 --> Config Class Initialized
INFO - 2025-03-25 00:57:40 --> Loader Class Initialized
INFO - 2025-03-25 00:57:40 --> Helper loaded: url_helper
INFO - 2025-03-25 00:57:40 --> Helper loaded: file_helper
INFO - 2025-03-25 00:57:40 --> Helper loaded: html_helper
INFO - 2025-03-25 00:57:40 --> Helper loaded: form_helper
INFO - 2025-03-25 00:57:40 --> Helper loaded: text_helper
INFO - 2025-03-25 00:57:40 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:57:40 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:57:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:57:40 --> Database Driver Class Initialized
INFO - 2025-03-25 00:57:40 --> Email Class Initialized
INFO - 2025-03-25 00:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:57:40 --> Form Validation Class Initialized
INFO - 2025-03-25 00:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:57:40 --> Pagination Class Initialized
INFO - 2025-03-25 00:57:40 --> Controller Class Initialized
INFO - 2025-03-25 00:57:40 --> Model Class Initialized
DEBUG - 2025-03-25 00:57:40 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:57:40 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:57:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:57:40 --> Model Class Initialized
DEBUG - 2025-03-25 00:57:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:57:40 --> Model Class Initialized
DEBUG - 2025-03-25 00:57:40 --> 🧾 Generated invoice_id = 1079
ERROR - 2025-03-25 00:57:40 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 00:57:40 --> ✅ Invoice inserted, returned invoice_id: 1079
DEBUG - 2025-03-25 00:57:40 --> ✅ Auto-approving voucher for invoice_id: 1079
ERROR - 2025-03-25 00:57:40 --> Severity: error --> Exception: Call to undefined method Api::autoapprove() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1953
INFO - 2025-03-25 00:58:10 --> Config Class Initialized
INFO - 2025-03-25 00:58:10 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:58:10 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:58:10 --> Utf8 Class Initialized
INFO - 2025-03-25 00:58:10 --> URI Class Initialized
INFO - 2025-03-25 00:58:10 --> Router Class Initialized
INFO - 2025-03-25 00:58:10 --> Output Class Initialized
INFO - 2025-03-25 00:58:10 --> Security Class Initialized
DEBUG - 2025-03-25 00:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:58:10 --> Input Class Initialized
INFO - 2025-03-25 00:58:10 --> Language Class Initialized
INFO - 2025-03-25 00:58:10 --> Language Class Initialized
INFO - 2025-03-25 00:58:10 --> Config Class Initialized
INFO - 2025-03-25 00:58:10 --> Loader Class Initialized
INFO - 2025-03-25 00:58:10 --> Helper loaded: url_helper
INFO - 2025-03-25 00:58:10 --> Helper loaded: file_helper
INFO - 2025-03-25 00:58:10 --> Helper loaded: html_helper
INFO - 2025-03-25 00:58:10 --> Helper loaded: form_helper
INFO - 2025-03-25 00:58:10 --> Helper loaded: text_helper
INFO - 2025-03-25 00:58:10 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:58:10 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:58:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:58:10 --> Database Driver Class Initialized
INFO - 2025-03-25 00:58:10 --> Email Class Initialized
INFO - 2025-03-25 00:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:58:10 --> Form Validation Class Initialized
INFO - 2025-03-25 00:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:58:10 --> Pagination Class Initialized
INFO - 2025-03-25 00:58:10 --> Controller Class Initialized
INFO - 2025-03-25 00:58:10 --> Model Class Initialized
DEBUG - 2025-03-25 00:58:10 --> ✅ API insert_sale called
DEBUG - 2025-03-25 00:58:10 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 00:58:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 00:58:10 --> Model Class Initialized
DEBUG - 2025-03-25 00:58:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 00:58:10 --> Model Class Initialized
DEBUG - 2025-03-25 00:58:10 --> 🧾 Generated invoice_id = 1080
ERROR - 2025-03-25 00:58:10 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 00:58:10 --> ✅ Invoice inserted, returned invoice_id: 1080
DEBUG - 2025-03-25 00:58:10 --> ✅ Auto-approving voucher for invoice_id: 1080
ERROR - 2025-03-25 00:58:10 --> Severity: error --> Exception: Call to undefined method Api::autoapprove() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1953
INFO - 2025-03-25 00:59:27 --> Config Class Initialized
INFO - 2025-03-25 00:59:27 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:27 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:27 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:27 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:59:27 --> Router Class Initialized
INFO - 2025-03-25 00:59:27 --> Output Class Initialized
INFO - 2025-03-25 00:59:27 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:27 --> Input Class Initialized
INFO - 2025-03-25 00:59:27 --> Language Class Initialized
INFO - 2025-03-25 00:59:27 --> Language Class Initialized
INFO - 2025-03-25 00:59:27 --> Config Class Initialized
INFO - 2025-03-25 00:59:27 --> Loader Class Initialized
INFO - 2025-03-25 00:59:27 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:27 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:27 --> Email Class Initialized
INFO - 2025-03-25 00:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:27 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:27 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:27 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:27 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:59:27 --> Model Class Initialized
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:59:27 --> Model Class Initialized
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:59:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:59:27 --> Model Class Initialized
ERROR - 2025-03-25 00:59:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:59:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:59:27 --> Final output sent to browser
DEBUG - 2025-03-25 00:59:27 --> Total execution time: 0.1285
INFO - 2025-03-25 00:59:27 --> Config Class Initialized
INFO - 2025-03-25 00:59:27 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:27 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:27 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:27 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:59:27 --> Router Class Initialized
INFO - 2025-03-25 00:59:27 --> Output Class Initialized
INFO - 2025-03-25 00:59:27 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:27 --> Input Class Initialized
INFO - 2025-03-25 00:59:27 --> Language Class Initialized
INFO - 2025-03-25 00:59:27 --> Language Class Initialized
INFO - 2025-03-25 00:59:27 --> Config Class Initialized
INFO - 2025-03-25 00:59:27 --> Loader Class Initialized
INFO - 2025-03-25 00:59:27 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:27 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:27 --> Email Class Initialized
INFO - 2025-03-25 00:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:27 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:27 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:27 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:27 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:59:27 --> Model Class Initialized
DEBUG - 2025-03-25 00:59:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:59:27 --> Model Class Initialized
INFO - 2025-03-25 00:59:27 --> Final output sent to browser
DEBUG - 2025-03-25 00:59:27 --> Total execution time: 0.0111
INFO - 2025-03-25 00:59:28 --> Config Class Initialized
INFO - 2025-03-25 00:59:28 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:28 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:28 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:28 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:59:28 --> Router Class Initialized
INFO - 2025-03-25 00:59:28 --> Output Class Initialized
INFO - 2025-03-25 00:59:28 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:28 --> Input Class Initialized
INFO - 2025-03-25 00:59:28 --> Language Class Initialized
INFO - 2025-03-25 00:59:28 --> Language Class Initialized
INFO - 2025-03-25 00:59:28 --> Config Class Initialized
INFO - 2025-03-25 00:59:28 --> Loader Class Initialized
INFO - 2025-03-25 00:59:28 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:28 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:28 --> Email Class Initialized
INFO - 2025-03-25 00:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:28 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:28 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:28 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:28 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:59:28 --> Model Class Initialized
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:59:28 --> Model Class Initialized
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 00:59:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 00:59:28 --> Model Class Initialized
ERROR - 2025-03-25 00:59:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 00:59:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 00:59:28 --> Final output sent to browser
DEBUG - 2025-03-25 00:59:28 --> Total execution time: 0.1030
INFO - 2025-03-25 00:59:28 --> Config Class Initialized
INFO - 2025-03-25 00:59:28 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:28 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:28 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:28 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 00:59:28 --> Router Class Initialized
INFO - 2025-03-25 00:59:28 --> Output Class Initialized
INFO - 2025-03-25 00:59:28 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:28 --> Input Class Initialized
INFO - 2025-03-25 00:59:28 --> Language Class Initialized
INFO - 2025-03-25 00:59:28 --> Language Class Initialized
INFO - 2025-03-25 00:59:28 --> Config Class Initialized
INFO - 2025-03-25 00:59:28 --> Loader Class Initialized
INFO - 2025-03-25 00:59:28 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:28 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:28 --> Email Class Initialized
INFO - 2025-03-25 00:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:28 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:28 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:28 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:28 --> Report MX_Controller Initialized
INFO - 2025-03-25 00:59:28 --> Model Class Initialized
DEBUG - 2025-03-25 00:59:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 00:59:28 --> Model Class Initialized
INFO - 2025-03-25 00:59:28 --> Final output sent to browser
DEBUG - 2025-03-25 00:59:28 --> Total execution time: 0.0083
INFO - 2025-03-25 00:59:43 --> Config Class Initialized
INFO - 2025-03-25 00:59:43 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:43 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:43 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:43 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 00:59:43 --> Router Class Initialized
INFO - 2025-03-25 00:59:43 --> Output Class Initialized
INFO - 2025-03-25 00:59:43 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:43 --> Input Class Initialized
INFO - 2025-03-25 00:59:43 --> Language Class Initialized
INFO - 2025-03-25 00:59:43 --> Language Class Initialized
INFO - 2025-03-25 00:59:43 --> Config Class Initialized
INFO - 2025-03-25 00:59:43 --> Loader Class Initialized
INFO - 2025-03-25 00:59:43 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:43 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:43 --> Email Class Initialized
INFO - 2025-03-25 00:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:43 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:43 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:43 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:43 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:59:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
ERROR - 2025-03-25 06:59:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 06:59:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 06:59:43 --> Final output sent to browser
DEBUG - 2025-03-25 06:59:43 --> Total execution time: 0.1255
INFO - 2025-03-25 00:59:43 --> Config Class Initialized
INFO - 2025-03-25 00:59:43 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:43 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:43 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:43 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 00:59:43 --> Router Class Initialized
INFO - 2025-03-25 00:59:43 --> Output Class Initialized
INFO - 2025-03-25 00:59:43 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:43 --> Input Class Initialized
INFO - 2025-03-25 00:59:43 --> Language Class Initialized
INFO - 2025-03-25 00:59:43 --> Language Class Initialized
INFO - 2025-03-25 00:59:43 --> Config Class Initialized
INFO - 2025-03-25 00:59:43 --> Loader Class Initialized
INFO - 2025-03-25 00:59:43 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:43 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:43 --> Email Class Initialized
INFO - 2025-03-25 00:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:43 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:43 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:43 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:43 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:59:43 --> Model Class Initialized
INFO - 2025-03-25 06:59:43 --> Final output sent to browser
DEBUG - 2025-03-25 06:59:43 --> Total execution time: 0.0469
INFO - 2025-03-25 00:59:46 --> Config Class Initialized
INFO - 2025-03-25 00:59:46 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:46 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:46 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:46 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 00:59:46 --> Router Class Initialized
INFO - 2025-03-25 00:59:46 --> Output Class Initialized
INFO - 2025-03-25 00:59:46 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:46 --> Input Class Initialized
INFO - 2025-03-25 00:59:46 --> Language Class Initialized
INFO - 2025-03-25 00:59:46 --> Language Class Initialized
INFO - 2025-03-25 00:59:46 --> Config Class Initialized
INFO - 2025-03-25 00:59:46 --> Loader Class Initialized
INFO - 2025-03-25 00:59:46 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:46 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:46 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:46 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:46 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:46 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:46 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:46 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:46 --> Email Class Initialized
INFO - 2025-03-25 00:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:46 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:46 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:46 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:46 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 06:59:46 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 06:59:46 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 06:59:46 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:59:46 --> Model Class Initialized
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:59:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:59:46 --> Model Class Initialized
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 166
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
ERROR - 2025-03-25 06:59:46 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 06:59:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 06:59:46 --> Final output sent to browser
DEBUG - 2025-03-25 06:59:46 --> Total execution time: 0.1457
INFO - 2025-03-25 00:59:49 --> Config Class Initialized
INFO - 2025-03-25 00:59:49 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:49 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:49 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:49 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 00:59:49 --> Router Class Initialized
INFO - 2025-03-25 00:59:49 --> Output Class Initialized
INFO - 2025-03-25 00:59:49 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:49 --> Input Class Initialized
INFO - 2025-03-25 00:59:49 --> Language Class Initialized
INFO - 2025-03-25 00:59:49 --> Language Class Initialized
INFO - 2025-03-25 00:59:49 --> Config Class Initialized
INFO - 2025-03-25 00:59:49 --> Loader Class Initialized
INFO - 2025-03-25 00:59:49 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:49 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:49 --> Email Class Initialized
INFO - 2025-03-25 00:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:49 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:49 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:49 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:49 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:59:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
ERROR - 2025-03-25 06:59:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 06:59:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 06:59:49 --> Final output sent to browser
DEBUG - 2025-03-25 06:59:49 --> Total execution time: 0.0899
INFO - 2025-03-25 00:59:49 --> Config Class Initialized
INFO - 2025-03-25 00:59:49 --> Hooks Class Initialized
DEBUG - 2025-03-25 00:59:49 --> UTF-8 Support Enabled
INFO - 2025-03-25 00:59:49 --> Utf8 Class Initialized
INFO - 2025-03-25 00:59:49 --> URI Class Initialized
DEBUG - 2025-03-25 00:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 00:59:49 --> Router Class Initialized
INFO - 2025-03-25 00:59:49 --> Output Class Initialized
INFO - 2025-03-25 00:59:49 --> Security Class Initialized
DEBUG - 2025-03-25 00:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 00:59:49 --> Input Class Initialized
INFO - 2025-03-25 00:59:49 --> Language Class Initialized
INFO - 2025-03-25 00:59:49 --> Language Class Initialized
INFO - 2025-03-25 00:59:49 --> Config Class Initialized
INFO - 2025-03-25 00:59:49 --> Loader Class Initialized
INFO - 2025-03-25 00:59:49 --> Helper loaded: url_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: file_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: html_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: form_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: text_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: lang_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: directory_helper
INFO - 2025-03-25 00:59:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 00:59:49 --> Database Driver Class Initialized
INFO - 2025-03-25 00:59:49 --> Email Class Initialized
INFO - 2025-03-25 00:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 00:59:49 --> Form Validation Class Initialized
INFO - 2025-03-25 00:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 00:59:49 --> Pagination Class Initialized
INFO - 2025-03-25 00:59:49 --> Controller Class Initialized
DEBUG - 2025-03-25 00:59:49 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
DEBUG - 2025-03-25 06:59:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:59:49 --> Model Class Initialized
INFO - 2025-03-25 06:59:49 --> Final output sent to browser
DEBUG - 2025-03-25 06:59:49 --> Total execution time: 0.0372
INFO - 2025-03-25 01:01:58 --> Config Class Initialized
INFO - 2025-03-25 01:01:58 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:01:58 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:01:58 --> Utf8 Class Initialized
INFO - 2025-03-25 01:01:58 --> URI Class Initialized
INFO - 2025-03-25 01:01:58 --> Router Class Initialized
INFO - 2025-03-25 01:01:58 --> Output Class Initialized
INFO - 2025-03-25 01:01:58 --> Security Class Initialized
DEBUG - 2025-03-25 01:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:01:58 --> Input Class Initialized
INFO - 2025-03-25 01:01:58 --> Language Class Initialized
INFO - 2025-03-25 01:01:58 --> Language Class Initialized
INFO - 2025-03-25 01:01:58 --> Config Class Initialized
INFO - 2025-03-25 01:01:58 --> Loader Class Initialized
INFO - 2025-03-25 01:01:58 --> Helper loaded: url_helper
INFO - 2025-03-25 01:01:58 --> Helper loaded: file_helper
INFO - 2025-03-25 01:01:58 --> Helper loaded: html_helper
INFO - 2025-03-25 01:01:58 --> Helper loaded: form_helper
INFO - 2025-03-25 01:01:58 --> Helper loaded: text_helper
INFO - 2025-03-25 01:01:58 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:01:58 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:01:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:01:58 --> Database Driver Class Initialized
INFO - 2025-03-25 01:01:58 --> Email Class Initialized
INFO - 2025-03-25 01:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:01:58 --> Form Validation Class Initialized
INFO - 2025-03-25 01:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:01:58 --> Pagination Class Initialized
INFO - 2025-03-25 01:01:58 --> Controller Class Initialized
INFO - 2025-03-25 01:01:58 --> Model Class Initialized
DEBUG - 2025-03-25 01:01:58 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:01:58 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:01:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:01:58 --> Model Class Initialized
DEBUG - 2025-03-25 01:01:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:01:58 --> Model Class Initialized
DEBUG - 2025-03-25 01:01:58 --> 🧾 Generated invoice_id = 1081
ERROR - 2025-03-25 01:01:58 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 01:01:58 --> ✅ Invoice inserted, returned invoice_id: 1081
DEBUG - 2025-03-25 01:01:58 --> ✅ Auto-approving voucher for invoice_id: 1081
ERROR - 2025-03-25 01:01:58 --> Severity: error --> Exception: Call to undefined method Api::autoapprove() /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/Api.php 1953
INFO - 2025-03-25 01:08:58 --> Config Class Initialized
INFO - 2025-03-25 01:08:58 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:08:58 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:08:58 --> Utf8 Class Initialized
INFO - 2025-03-25 01:08:58 --> URI Class Initialized
INFO - 2025-03-25 01:08:58 --> Router Class Initialized
INFO - 2025-03-25 01:08:58 --> Output Class Initialized
INFO - 2025-03-25 01:08:58 --> Security Class Initialized
DEBUG - 2025-03-25 01:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:08:58 --> Input Class Initialized
INFO - 2025-03-25 01:08:58 --> Language Class Initialized
INFO - 2025-03-25 01:08:58 --> Language Class Initialized
INFO - 2025-03-25 01:08:58 --> Config Class Initialized
INFO - 2025-03-25 01:08:58 --> Loader Class Initialized
INFO - 2025-03-25 01:08:58 --> Helper loaded: url_helper
INFO - 2025-03-25 01:08:58 --> Helper loaded: file_helper
INFO - 2025-03-25 01:08:58 --> Helper loaded: html_helper
INFO - 2025-03-25 01:08:58 --> Helper loaded: form_helper
INFO - 2025-03-25 01:08:58 --> Helper loaded: text_helper
INFO - 2025-03-25 01:08:58 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:08:58 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:08:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:08:58 --> Database Driver Class Initialized
INFO - 2025-03-25 01:08:58 --> Email Class Initialized
INFO - 2025-03-25 01:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:08:58 --> Form Validation Class Initialized
INFO - 2025-03-25 01:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:08:58 --> Pagination Class Initialized
INFO - 2025-03-25 01:08:58 --> Controller Class Initialized
INFO - 2025-03-25 01:08:58 --> Model Class Initialized
DEBUG - 2025-03-25 01:08:58 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:08:58 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:08:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:08:58 --> Model Class Initialized
DEBUG - 2025-03-25 01:08:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:08:58 --> Model Class Initialized
ERROR - 2025-03-25 01:08:58 --> Severity: error --> Exception: Call to undefined function each() /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Modules.php 83
INFO - 2025-03-25 01:16:07 --> Config Class Initialized
INFO - 2025-03-25 01:16:07 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:16:07 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:16:07 --> Utf8 Class Initialized
INFO - 2025-03-25 01:16:07 --> URI Class Initialized
DEBUG - 2025-03-25 01:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:16:07 --> Router Class Initialized
INFO - 2025-03-25 01:16:07 --> Output Class Initialized
INFO - 2025-03-25 01:16:07 --> Security Class Initialized
DEBUG - 2025-03-25 01:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:16:07 --> Input Class Initialized
INFO - 2025-03-25 01:16:07 --> Language Class Initialized
INFO - 2025-03-25 01:16:07 --> Language Class Initialized
INFO - 2025-03-25 01:16:07 --> Config Class Initialized
INFO - 2025-03-25 01:16:07 --> Loader Class Initialized
INFO - 2025-03-25 01:16:07 --> Helper loaded: url_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: file_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: html_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: form_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: text_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:16:07 --> Database Driver Class Initialized
INFO - 2025-03-25 01:16:07 --> Email Class Initialized
INFO - 2025-03-25 01:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:16:07 --> Form Validation Class Initialized
INFO - 2025-03-25 01:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:16:07 --> Pagination Class Initialized
INFO - 2025-03-25 01:16:07 --> Controller Class Initialized
DEBUG - 2025-03-25 01:16:07 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:16:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
ERROR - 2025-03-25 07:16:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:16:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:16:07 --> Final output sent to browser
DEBUG - 2025-03-25 07:16:07 --> Total execution time: 0.1158
INFO - 2025-03-25 01:16:07 --> Config Class Initialized
INFO - 2025-03-25 01:16:07 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:16:07 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:16:07 --> Utf8 Class Initialized
INFO - 2025-03-25 01:16:07 --> URI Class Initialized
DEBUG - 2025-03-25 01:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:16:07 --> Router Class Initialized
INFO - 2025-03-25 01:16:07 --> Output Class Initialized
INFO - 2025-03-25 01:16:07 --> Security Class Initialized
DEBUG - 2025-03-25 01:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:16:07 --> Input Class Initialized
INFO - 2025-03-25 01:16:07 --> Language Class Initialized
INFO - 2025-03-25 01:16:07 --> Language Class Initialized
INFO - 2025-03-25 01:16:07 --> Config Class Initialized
INFO - 2025-03-25 01:16:07 --> Loader Class Initialized
INFO - 2025-03-25 01:16:07 --> Helper loaded: url_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: file_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: html_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: form_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: text_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:16:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:16:07 --> Database Driver Class Initialized
INFO - 2025-03-25 01:16:07 --> Email Class Initialized
INFO - 2025-03-25 01:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:16:07 --> Form Validation Class Initialized
INFO - 2025-03-25 01:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:16:07 --> Pagination Class Initialized
INFO - 2025-03-25 01:16:07 --> Controller Class Initialized
DEBUG - 2025-03-25 01:16:07 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
DEBUG - 2025-03-25 07:16:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:16:07 --> Model Class Initialized
INFO - 2025-03-25 07:16:07 --> Final output sent to browser
DEBUG - 2025-03-25 07:16:07 --> Total execution time: 0.0384
INFO - 2025-03-25 01:16:20 --> Config Class Initialized
INFO - 2025-03-25 01:16:20 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:16:20 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:16:20 --> Utf8 Class Initialized
INFO - 2025-03-25 01:16:20 --> URI Class Initialized
INFO - 2025-03-25 01:16:20 --> Router Class Initialized
INFO - 2025-03-25 01:16:20 --> Output Class Initialized
INFO - 2025-03-25 01:16:20 --> Security Class Initialized
DEBUG - 2025-03-25 01:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:16:20 --> Input Class Initialized
INFO - 2025-03-25 01:16:20 --> Language Class Initialized
INFO - 2025-03-25 01:16:20 --> Language Class Initialized
INFO - 2025-03-25 01:16:20 --> Config Class Initialized
INFO - 2025-03-25 01:16:20 --> Loader Class Initialized
INFO - 2025-03-25 01:16:20 --> Helper loaded: url_helper
INFO - 2025-03-25 01:16:20 --> Helper loaded: file_helper
INFO - 2025-03-25 01:16:20 --> Helper loaded: html_helper
INFO - 2025-03-25 01:16:20 --> Helper loaded: form_helper
INFO - 2025-03-25 01:16:20 --> Helper loaded: text_helper
INFO - 2025-03-25 01:16:20 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:16:20 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:16:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:16:20 --> Database Driver Class Initialized
INFO - 2025-03-25 01:16:20 --> Email Class Initialized
INFO - 2025-03-25 01:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:16:20 --> Form Validation Class Initialized
INFO - 2025-03-25 01:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:16:20 --> Pagination Class Initialized
INFO - 2025-03-25 01:16:20 --> Controller Class Initialized
INFO - 2025-03-25 01:16:20 --> Model Class Initialized
DEBUG - 2025-03-25 01:16:20 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:16:20 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:16:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:16:20 --> Model Class Initialized
DEBUG - 2025-03-25 01:16:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:16:20 --> Model Class Initialized
DEBUG - 2025-03-25 01:16:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
ERROR - 2025-03-25 01:16:20 --> Severity: Compile Error --> Cannot declare class CI, because the name is already in use /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php 40
INFO - 2025-03-25 01:18:28 --> Config Class Initialized
INFO - 2025-03-25 01:18:28 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:18:28 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:18:28 --> Utf8 Class Initialized
INFO - 2025-03-25 01:18:28 --> URI Class Initialized
DEBUG - 2025-03-25 01:18:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:18:28 --> Router Class Initialized
INFO - 2025-03-25 01:18:28 --> Output Class Initialized
INFO - 2025-03-25 01:18:28 --> Security Class Initialized
DEBUG - 2025-03-25 01:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:18:28 --> Input Class Initialized
INFO - 2025-03-25 01:18:28 --> Language Class Initialized
ERROR - 2025-03-25 01:18:28 --> Severity: Compile Error --> Cannot declare class MX_Controller, because the name is already in use /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php 40
INFO - 2025-03-25 01:20:08 --> Config Class Initialized
INFO - 2025-03-25 01:20:08 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:20:08 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:20:08 --> Utf8 Class Initialized
INFO - 2025-03-25 01:20:08 --> URI Class Initialized
DEBUG - 2025-03-25 01:20:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:20:08 --> Router Class Initialized
INFO - 2025-03-25 01:20:08 --> Output Class Initialized
INFO - 2025-03-25 01:20:08 --> Security Class Initialized
DEBUG - 2025-03-25 01:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:20:08 --> Input Class Initialized
INFO - 2025-03-25 01:20:08 --> Language Class Initialized
ERROR - 2025-03-25 01:20:08 --> Severity: Warning --> require(/Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php): Failed to open stream: No such file or directory /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Controller.php 4
ERROR - 2025-03-25 01:20:08 --> Severity: error --> Exception: Failed opening required '/Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php' (include_path='.:/opt/homebrew/Cellar/php@8.3/8.3.16/share/php@8.3/pear') /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Controller.php 4
INFO - 2025-03-25 01:20:09 --> Config Class Initialized
INFO - 2025-03-25 01:20:09 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:20:09 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:20:09 --> Utf8 Class Initialized
INFO - 2025-03-25 01:20:09 --> URI Class Initialized
DEBUG - 2025-03-25 01:20:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:20:09 --> Router Class Initialized
INFO - 2025-03-25 01:20:09 --> Output Class Initialized
INFO - 2025-03-25 01:20:09 --> Security Class Initialized
DEBUG - 2025-03-25 01:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:20:09 --> Input Class Initialized
INFO - 2025-03-25 01:20:09 --> Language Class Initialized
ERROR - 2025-03-25 01:20:09 --> Severity: Warning --> require(/Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php): Failed to open stream: No such file or directory /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Controller.php 4
ERROR - 2025-03-25 01:20:09 --> Severity: error --> Exception: Failed opening required '/Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php' (include_path='.:/opt/homebrew/Cellar/php@8.3/8.3.16/share/php@8.3/pear') /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Controller.php 4
INFO - 2025-03-25 01:20:11 --> Config Class Initialized
INFO - 2025-03-25 01:20:11 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:20:11 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:20:11 --> Utf8 Class Initialized
INFO - 2025-03-25 01:20:11 --> URI Class Initialized
DEBUG - 2025-03-25 01:20:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:20:11 --> Router Class Initialized
INFO - 2025-03-25 01:20:11 --> Output Class Initialized
INFO - 2025-03-25 01:20:11 --> Security Class Initialized
DEBUG - 2025-03-25 01:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:20:11 --> Input Class Initialized
INFO - 2025-03-25 01:20:11 --> Language Class Initialized
ERROR - 2025-03-25 01:20:11 --> Severity: Warning --> require(/Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php): Failed to open stream: No such file or directory /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Controller.php 4
ERROR - 2025-03-25 01:20:11 --> Severity: error --> Exception: Failed opening required '/Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php' (include_path='.:/opt/homebrew/Cellar/php@8.3/8.3.16/share/php@8.3/pear') /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Controller.php 4
INFO - 2025-03-25 01:20:26 --> Config Class Initialized
INFO - 2025-03-25 01:20:26 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:20:26 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:20:26 --> Utf8 Class Initialized
INFO - 2025-03-25 01:20:26 --> URI Class Initialized
DEBUG - 2025-03-25 01:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:20:26 --> Router Class Initialized
INFO - 2025-03-25 01:20:26 --> Output Class Initialized
INFO - 2025-03-25 01:20:26 --> Security Class Initialized
DEBUG - 2025-03-25 01:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:20:26 --> Input Class Initialized
INFO - 2025-03-25 01:20:26 --> Language Class Initialized
INFO - 2025-03-25 01:20:26 --> Language Class Initialized
INFO - 2025-03-25 01:20:26 --> Config Class Initialized
INFO - 2025-03-25 01:20:26 --> Loader Class Initialized
INFO - 2025-03-25 01:20:26 --> Helper loaded: url_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: file_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: html_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: form_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: text_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:20:26 --> Database Driver Class Initialized
INFO - 2025-03-25 01:20:26 --> Email Class Initialized
INFO - 2025-03-25 01:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:20:26 --> Form Validation Class Initialized
INFO - 2025-03-25 01:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:20:26 --> Pagination Class Initialized
INFO - 2025-03-25 01:20:26 --> Controller Class Initialized
DEBUG - 2025-03-25 01:20:26 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:20:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
ERROR - 2025-03-25 07:20:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:20:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:20:26 --> Final output sent to browser
DEBUG - 2025-03-25 07:20:26 --> Total execution time: 0.1489
INFO - 2025-03-25 01:20:26 --> Config Class Initialized
INFO - 2025-03-25 01:20:26 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:20:26 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:20:26 --> Utf8 Class Initialized
INFO - 2025-03-25 01:20:26 --> URI Class Initialized
DEBUG - 2025-03-25 01:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:20:26 --> Router Class Initialized
INFO - 2025-03-25 01:20:26 --> Output Class Initialized
INFO - 2025-03-25 01:20:26 --> Security Class Initialized
DEBUG - 2025-03-25 01:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:20:26 --> Input Class Initialized
INFO - 2025-03-25 01:20:26 --> Language Class Initialized
INFO - 2025-03-25 01:20:26 --> Language Class Initialized
INFO - 2025-03-25 01:20:26 --> Config Class Initialized
INFO - 2025-03-25 01:20:26 --> Loader Class Initialized
INFO - 2025-03-25 01:20:26 --> Helper loaded: url_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: file_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: html_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: form_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: text_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:20:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:20:26 --> Database Driver Class Initialized
INFO - 2025-03-25 01:20:26 --> Email Class Initialized
INFO - 2025-03-25 01:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:20:26 --> Form Validation Class Initialized
INFO - 2025-03-25 01:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:20:26 --> Pagination Class Initialized
INFO - 2025-03-25 01:20:26 --> Controller Class Initialized
DEBUG - 2025-03-25 01:20:26 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:20:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:20:26 --> Model Class Initialized
INFO - 2025-03-25 07:20:26 --> Final output sent to browser
DEBUG - 2025-03-25 07:20:26 --> Total execution time: 0.0507
INFO - 2025-03-25 01:23:22 --> Config Class Initialized
INFO - 2025-03-25 01:23:22 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:23:22 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:23:22 --> Utf8 Class Initialized
INFO - 2025-03-25 01:23:22 --> URI Class Initialized
DEBUG - 2025-03-25 01:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:23:22 --> Router Class Initialized
INFO - 2025-03-25 01:23:22 --> Output Class Initialized
INFO - 2025-03-25 01:23:22 --> Security Class Initialized
DEBUG - 2025-03-25 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:23:22 --> Input Class Initialized
INFO - 2025-03-25 01:23:22 --> Language Class Initialized
INFO - 2025-03-25 01:23:22 --> Language Class Initialized
INFO - 2025-03-25 01:23:22 --> Config Class Initialized
INFO - 2025-03-25 01:23:22 --> Loader Class Initialized
INFO - 2025-03-25 01:23:22 --> Helper loaded: url_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: file_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: html_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: form_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: text_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:23:22 --> Database Driver Class Initialized
INFO - 2025-03-25 01:23:22 --> Email Class Initialized
INFO - 2025-03-25 01:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:23:22 --> Form Validation Class Initialized
INFO - 2025-03-25 01:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:23:22 --> Pagination Class Initialized
INFO - 2025-03-25 01:23:22 --> Controller Class Initialized
DEBUG - 2025-03-25 01:23:22 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:23:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
ERROR - 2025-03-25 07:23:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:23:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:23:22 --> Final output sent to browser
DEBUG - 2025-03-25 07:23:22 --> Total execution time: 0.1181
INFO - 2025-03-25 01:23:22 --> Config Class Initialized
INFO - 2025-03-25 01:23:22 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:23:22 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:23:22 --> Utf8 Class Initialized
INFO - 2025-03-25 01:23:22 --> URI Class Initialized
DEBUG - 2025-03-25 01:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:23:22 --> Router Class Initialized
INFO - 2025-03-25 01:23:22 --> Output Class Initialized
INFO - 2025-03-25 01:23:22 --> Security Class Initialized
DEBUG - 2025-03-25 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:23:22 --> Input Class Initialized
INFO - 2025-03-25 01:23:22 --> Language Class Initialized
INFO - 2025-03-25 01:23:22 --> Language Class Initialized
INFO - 2025-03-25 01:23:22 --> Config Class Initialized
INFO - 2025-03-25 01:23:22 --> Loader Class Initialized
INFO - 2025-03-25 01:23:22 --> Helper loaded: url_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: file_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: html_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: form_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: text_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:23:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:23:22 --> Database Driver Class Initialized
INFO - 2025-03-25 01:23:22 --> Email Class Initialized
INFO - 2025-03-25 01:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:23:22 --> Form Validation Class Initialized
INFO - 2025-03-25 01:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:23:22 --> Pagination Class Initialized
INFO - 2025-03-25 01:23:22 --> Controller Class Initialized
DEBUG - 2025-03-25 01:23:22 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:23:22 --> Model Class Initialized
INFO - 2025-03-25 07:23:22 --> Final output sent to browser
DEBUG - 2025-03-25 07:23:22 --> Total execution time: 0.0405
INFO - 2025-03-25 01:23:25 --> Config Class Initialized
INFO - 2025-03-25 01:23:25 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:23:25 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:23:25 --> Utf8 Class Initialized
INFO - 2025-03-25 01:23:25 --> URI Class Initialized
DEBUG - 2025-03-25 01:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:23:25 --> Router Class Initialized
INFO - 2025-03-25 01:23:25 --> Output Class Initialized
INFO - 2025-03-25 01:23:25 --> Security Class Initialized
DEBUG - 2025-03-25 01:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:23:25 --> Input Class Initialized
INFO - 2025-03-25 01:23:25 --> Language Class Initialized
INFO - 2025-03-25 01:23:25 --> Language Class Initialized
INFO - 2025-03-25 01:23:25 --> Config Class Initialized
INFO - 2025-03-25 01:23:25 --> Loader Class Initialized
INFO - 2025-03-25 01:23:25 --> Helper loaded: url_helper
INFO - 2025-03-25 01:23:25 --> Helper loaded: file_helper
INFO - 2025-03-25 01:23:25 --> Helper loaded: html_helper
INFO - 2025-03-25 01:23:25 --> Helper loaded: form_helper
INFO - 2025-03-25 01:23:25 --> Helper loaded: text_helper
INFO - 2025-03-25 01:23:25 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:23:25 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:23:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:23:25 --> Database Driver Class Initialized
INFO - 2025-03-25 01:23:25 --> Email Class Initialized
INFO - 2025-03-25 01:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:23:25 --> Form Validation Class Initialized
INFO - 2025-03-25 01:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:23:25 --> Pagination Class Initialized
INFO - 2025-03-25 01:23:25 --> Controller Class Initialized
DEBUG - 2025-03-25 01:23:25 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:23:25 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:23:25 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:23:25 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:23:25 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:23:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:23:25 --> Model Class Initialized
ERROR - 2025-03-25 07:23:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:23:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/terms_list.php
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:23:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:23:25 --> Final output sent to browser
DEBUG - 2025-03-25 07:23:25 --> Total execution time: 0.1187
INFO - 2025-03-25 01:23:26 --> Config Class Initialized
INFO - 2025-03-25 01:23:26 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:23:26 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:23:26 --> Utf8 Class Initialized
INFO - 2025-03-25 01:23:26 --> URI Class Initialized
DEBUG - 2025-03-25 01:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:23:26 --> Router Class Initialized
INFO - 2025-03-25 01:23:26 --> Output Class Initialized
INFO - 2025-03-25 01:23:26 --> Security Class Initialized
DEBUG - 2025-03-25 01:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:23:26 --> Input Class Initialized
INFO - 2025-03-25 01:23:26 --> Language Class Initialized
INFO - 2025-03-25 01:23:26 --> Language Class Initialized
INFO - 2025-03-25 01:23:26 --> Config Class Initialized
INFO - 2025-03-25 01:23:26 --> Loader Class Initialized
INFO - 2025-03-25 01:23:26 --> Helper loaded: url_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: file_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: html_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: form_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: text_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:23:26 --> Database Driver Class Initialized
INFO - 2025-03-25 01:23:26 --> Email Class Initialized
INFO - 2025-03-25 01:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:23:26 --> Form Validation Class Initialized
INFO - 2025-03-25 01:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:23:26 --> Pagination Class Initialized
INFO - 2025-03-25 01:23:26 --> Controller Class Initialized
DEBUG - 2025-03-25 01:23:26 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:23:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
ERROR - 2025-03-25 07:23:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:23:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:23:26 --> Final output sent to browser
DEBUG - 2025-03-25 07:23:26 --> Total execution time: 0.2225
INFO - 2025-03-25 01:23:26 --> Config Class Initialized
INFO - 2025-03-25 01:23:26 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:23:26 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:23:26 --> Utf8 Class Initialized
INFO - 2025-03-25 01:23:26 --> URI Class Initialized
DEBUG - 2025-03-25 01:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:23:26 --> Router Class Initialized
INFO - 2025-03-25 01:23:26 --> Output Class Initialized
INFO - 2025-03-25 01:23:26 --> Security Class Initialized
DEBUG - 2025-03-25 01:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:23:26 --> Input Class Initialized
INFO - 2025-03-25 01:23:26 --> Language Class Initialized
INFO - 2025-03-25 01:23:26 --> Language Class Initialized
INFO - 2025-03-25 01:23:26 --> Config Class Initialized
INFO - 2025-03-25 01:23:26 --> Loader Class Initialized
INFO - 2025-03-25 01:23:26 --> Helper loaded: url_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: file_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: html_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: form_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: text_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:23:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:23:26 --> Database Driver Class Initialized
INFO - 2025-03-25 01:23:26 --> Email Class Initialized
INFO - 2025-03-25 01:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:23:26 --> Form Validation Class Initialized
INFO - 2025-03-25 01:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:23:26 --> Pagination Class Initialized
INFO - 2025-03-25 01:23:26 --> Controller Class Initialized
DEBUG - 2025-03-25 01:23:26 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:23:26 --> Model Class Initialized
INFO - 2025-03-25 07:23:27 --> Final output sent to browser
DEBUG - 2025-03-25 07:23:27 --> Total execution time: 0.0585
INFO - 2025-03-25 01:23:28 --> Config Class Initialized
INFO - 2025-03-25 01:23:28 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:23:28 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:23:28 --> Utf8 Class Initialized
INFO - 2025-03-25 01:23:28 --> URI Class Initialized
DEBUG - 2025-03-25 01:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:23:28 --> Router Class Initialized
INFO - 2025-03-25 01:23:28 --> Output Class Initialized
INFO - 2025-03-25 01:23:28 --> Security Class Initialized
DEBUG - 2025-03-25 01:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:23:28 --> Input Class Initialized
INFO - 2025-03-25 01:23:28 --> Language Class Initialized
INFO - 2025-03-25 01:23:28 --> Language Class Initialized
INFO - 2025-03-25 01:23:28 --> Config Class Initialized
INFO - 2025-03-25 01:23:28 --> Loader Class Initialized
INFO - 2025-03-25 01:23:28 --> Helper loaded: url_helper
INFO - 2025-03-25 01:23:28 --> Helper loaded: file_helper
INFO - 2025-03-25 01:23:28 --> Helper loaded: html_helper
INFO - 2025-03-25 01:23:28 --> Helper loaded: form_helper
INFO - 2025-03-25 01:23:28 --> Helper loaded: text_helper
INFO - 2025-03-25 01:23:28 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:23:28 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:23:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:23:28 --> Database Driver Class Initialized
INFO - 2025-03-25 01:23:28 --> Email Class Initialized
INFO - 2025-03-25 01:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:23:28 --> Form Validation Class Initialized
INFO - 2025-03-25 01:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:23:28 --> Pagination Class Initialized
INFO - 2025-03-25 01:23:28 --> Controller Class Initialized
DEBUG - 2025-03-25 01:23:28 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:23:28 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:23:28 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:23:28 --> Model Class Initialized
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:23:28 --> Model Class Initialized
ERROR - 2025-03-25 07:23:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 07:23:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 07:23:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 07:23:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:23:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:23:28 --> Model Class Initialized
ERROR - 2025-03-25 07:23:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:23:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 07:23:28 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:23:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:23:28 --> Final output sent to browser
DEBUG - 2025-03-25 07:23:28 --> Total execution time: 0.1084
INFO - 2025-03-25 01:23:45 --> Config Class Initialized
INFO - 2025-03-25 01:23:45 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:23:45 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:23:45 --> Utf8 Class Initialized
INFO - 2025-03-25 01:23:45 --> URI Class Initialized
INFO - 2025-03-25 01:23:45 --> Router Class Initialized
INFO - 2025-03-25 01:23:45 --> Output Class Initialized
INFO - 2025-03-25 01:23:45 --> Security Class Initialized
DEBUG - 2025-03-25 01:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:23:45 --> Input Class Initialized
INFO - 2025-03-25 01:23:45 --> Language Class Initialized
INFO - 2025-03-25 01:23:45 --> Language Class Initialized
INFO - 2025-03-25 01:23:45 --> Config Class Initialized
INFO - 2025-03-25 01:23:45 --> Loader Class Initialized
INFO - 2025-03-25 01:23:45 --> Helper loaded: url_helper
INFO - 2025-03-25 01:23:45 --> Helper loaded: file_helper
INFO - 2025-03-25 01:23:45 --> Helper loaded: html_helper
INFO - 2025-03-25 01:23:45 --> Helper loaded: form_helper
INFO - 2025-03-25 01:23:45 --> Helper loaded: text_helper
INFO - 2025-03-25 01:23:45 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:23:45 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:23:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:23:45 --> Database Driver Class Initialized
INFO - 2025-03-25 01:23:45 --> Email Class Initialized
INFO - 2025-03-25 01:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:23:45 --> Form Validation Class Initialized
INFO - 2025-03-25 01:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:23:45 --> Pagination Class Initialized
INFO - 2025-03-25 01:23:45 --> Controller Class Initialized
INFO - 2025-03-25 01:23:45 --> Model Class Initialized
DEBUG - 2025-03-25 01:23:45 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:23:45 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:23:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:23:45 --> Model Class Initialized
DEBUG - 2025-03-25 01:23:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:23:45 --> Model Class Initialized
DEBUG - 2025-03-25 01:23:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
ERROR - 2025-03-25 01:23:45 --> Severity: Compile Error --> Cannot declare class CI, because the name is already in use /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php 40
INFO - 2025-03-25 01:24:20 --> Config Class Initialized
INFO - 2025-03-25 01:24:20 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:24:20 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:24:20 --> Utf8 Class Initialized
INFO - 2025-03-25 01:24:20 --> URI Class Initialized
INFO - 2025-03-25 01:24:20 --> Router Class Initialized
INFO - 2025-03-25 01:24:20 --> Output Class Initialized
INFO - 2025-03-25 01:24:20 --> Security Class Initialized
DEBUG - 2025-03-25 01:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:24:20 --> Input Class Initialized
INFO - 2025-03-25 01:24:20 --> Language Class Initialized
INFO - 2025-03-25 01:24:20 --> Language Class Initialized
INFO - 2025-03-25 01:24:20 --> Config Class Initialized
INFO - 2025-03-25 01:24:20 --> Loader Class Initialized
INFO - 2025-03-25 01:24:20 --> Helper loaded: url_helper
INFO - 2025-03-25 01:24:20 --> Helper loaded: file_helper
INFO - 2025-03-25 01:24:20 --> Helper loaded: html_helper
INFO - 2025-03-25 01:24:20 --> Helper loaded: form_helper
INFO - 2025-03-25 01:24:20 --> Helper loaded: text_helper
INFO - 2025-03-25 01:24:20 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:24:20 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:24:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:24:20 --> Database Driver Class Initialized
INFO - 2025-03-25 01:24:20 --> Email Class Initialized
INFO - 2025-03-25 01:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:24:20 --> Form Validation Class Initialized
INFO - 2025-03-25 01:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:24:20 --> Pagination Class Initialized
INFO - 2025-03-25 01:24:20 --> Controller Class Initialized
INFO - 2025-03-25 01:24:20 --> Model Class Initialized
DEBUG - 2025-03-25 01:24:20 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:24:20 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:24:20 --> Model Class Initialized
DEBUG - 2025-03-25 01:24:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:24:20 --> Model Class Initialized
ERROR - 2025-03-25 01:24:20 --> Severity: error --> Exception: Call to undefined function each() /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Modules.php 83
INFO - 2025-03-25 01:30:34 --> Config Class Initialized
INFO - 2025-03-25 01:30:34 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:30:34 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:30:34 --> Utf8 Class Initialized
INFO - 2025-03-25 01:30:34 --> URI Class Initialized
INFO - 2025-03-25 01:30:34 --> Router Class Initialized
INFO - 2025-03-25 01:30:34 --> Output Class Initialized
INFO - 2025-03-25 01:30:34 --> Security Class Initialized
DEBUG - 2025-03-25 01:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:30:34 --> Input Class Initialized
INFO - 2025-03-25 01:30:34 --> Language Class Initialized
INFO - 2025-03-25 01:30:34 --> Language Class Initialized
INFO - 2025-03-25 01:30:34 --> Config Class Initialized
INFO - 2025-03-25 01:30:34 --> Loader Class Initialized
INFO - 2025-03-25 01:30:34 --> Helper loaded: url_helper
INFO - 2025-03-25 01:30:34 --> Helper loaded: file_helper
INFO - 2025-03-25 01:30:34 --> Helper loaded: html_helper
INFO - 2025-03-25 01:30:34 --> Helper loaded: form_helper
INFO - 2025-03-25 01:30:34 --> Helper loaded: text_helper
INFO - 2025-03-25 01:30:34 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:30:34 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:30:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:30:34 --> Database Driver Class Initialized
INFO - 2025-03-25 01:30:34 --> Email Class Initialized
INFO - 2025-03-25 01:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:30:34 --> Form Validation Class Initialized
INFO - 2025-03-25 01:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:30:34 --> Pagination Class Initialized
INFO - 2025-03-25 01:30:34 --> Controller Class Initialized
INFO - 2025-03-25 01:30:34 --> Model Class Initialized
DEBUG - 2025-03-25 01:30:34 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:30:34 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:30:34 --> Model Class Initialized
DEBUG - 2025-03-25 01:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:30:34 --> Model Class Initialized
ERROR - 2025-03-25 01:30:34 --> Severity: Compile Error --> Cannot declare class CI, because the name is already in use /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Base.php 40
INFO - 2025-03-25 01:34:14 --> Config Class Initialized
INFO - 2025-03-25 01:34:14 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:34:14 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:34:14 --> Utf8 Class Initialized
INFO - 2025-03-25 01:34:14 --> URI Class Initialized
INFO - 2025-03-25 01:34:14 --> Router Class Initialized
INFO - 2025-03-25 01:34:14 --> Output Class Initialized
INFO - 2025-03-25 01:34:14 --> Security Class Initialized
DEBUG - 2025-03-25 01:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:34:14 --> Input Class Initialized
INFO - 2025-03-25 01:34:14 --> Language Class Initialized
INFO - 2025-03-25 01:34:14 --> Language Class Initialized
INFO - 2025-03-25 01:34:14 --> Config Class Initialized
INFO - 2025-03-25 01:34:14 --> Loader Class Initialized
INFO - 2025-03-25 01:34:14 --> Helper loaded: url_helper
INFO - 2025-03-25 01:34:14 --> Helper loaded: file_helper
INFO - 2025-03-25 01:34:14 --> Helper loaded: html_helper
INFO - 2025-03-25 01:34:14 --> Helper loaded: form_helper
INFO - 2025-03-25 01:34:14 --> Helper loaded: text_helper
INFO - 2025-03-25 01:34:14 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:34:14 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:34:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:34:14 --> Database Driver Class Initialized
INFO - 2025-03-25 01:34:14 --> Email Class Initialized
INFO - 2025-03-25 01:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:34:14 --> Form Validation Class Initialized
INFO - 2025-03-25 01:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:34:14 --> Pagination Class Initialized
INFO - 2025-03-25 01:34:14 --> Controller Class Initialized
INFO - 2025-03-25 01:34:14 --> Model Class Initialized
DEBUG - 2025-03-25 01:34:14 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:34:14 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:34:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:34:14 --> Model Class Initialized
DEBUG - 2025-03-25 01:34:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:34:14 --> Model Class Initialized
ERROR - 2025-03-25 01:34:14 --> Severity: error --> Exception: Call to undefined function each() /Users/faiz.shiraji/Sites/GenITech_B2B/application/third_party/MX/Modules.php 83
INFO - 2025-03-25 01:36:06 --> Config Class Initialized
INFO - 2025-03-25 01:36:06 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:36:06 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:36:06 --> Utf8 Class Initialized
INFO - 2025-03-25 01:36:06 --> URI Class Initialized
INFO - 2025-03-25 01:36:06 --> Router Class Initialized
INFO - 2025-03-25 01:36:06 --> Output Class Initialized
INFO - 2025-03-25 01:36:06 --> Security Class Initialized
DEBUG - 2025-03-25 01:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:36:06 --> Input Class Initialized
INFO - 2025-03-25 01:36:06 --> Language Class Initialized
INFO - 2025-03-25 01:36:06 --> Language Class Initialized
INFO - 2025-03-25 01:36:06 --> Config Class Initialized
INFO - 2025-03-25 01:36:06 --> Loader Class Initialized
INFO - 2025-03-25 01:36:06 --> Helper loaded: url_helper
INFO - 2025-03-25 01:36:06 --> Helper loaded: file_helper
INFO - 2025-03-25 01:36:06 --> Helper loaded: html_helper
INFO - 2025-03-25 01:36:06 --> Helper loaded: form_helper
INFO - 2025-03-25 01:36:06 --> Helper loaded: text_helper
INFO - 2025-03-25 01:36:06 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:36:06 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:36:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:36:06 --> Database Driver Class Initialized
INFO - 2025-03-25 01:36:06 --> Email Class Initialized
INFO - 2025-03-25 01:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:36:06 --> Form Validation Class Initialized
INFO - 2025-03-25 01:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:36:06 --> Pagination Class Initialized
INFO - 2025-03-25 01:36:06 --> Controller Class Initialized
INFO - 2025-03-25 01:36:06 --> Model Class Initialized
DEBUG - 2025-03-25 01:36:06 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:36:06 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:36:06 --> Model Class Initialized
DEBUG - 2025-03-25 01:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:36:06 --> Model Class Initialized
DEBUG - 2025-03-25 01:36:06 --> 🧾 Generated invoice_id = 1082
ERROR - 2025-03-25 01:36:06 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 01:36:06 --> ✅ Invoice inserted, returned invoice_id: 1082
INFO - 2025-03-25 01:43:52 --> Config Class Initialized
INFO - 2025-03-25 01:43:52 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:43:52 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:43:52 --> Utf8 Class Initialized
INFO - 2025-03-25 01:43:52 --> URI Class Initialized
INFO - 2025-03-25 01:43:52 --> Router Class Initialized
INFO - 2025-03-25 01:43:52 --> Output Class Initialized
INFO - 2025-03-25 01:43:52 --> Security Class Initialized
DEBUG - 2025-03-25 01:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:43:52 --> Input Class Initialized
INFO - 2025-03-25 01:43:52 --> Language Class Initialized
INFO - 2025-03-25 01:43:52 --> Language Class Initialized
INFO - 2025-03-25 01:43:52 --> Config Class Initialized
INFO - 2025-03-25 01:43:52 --> Loader Class Initialized
INFO - 2025-03-25 01:43:52 --> Helper loaded: url_helper
INFO - 2025-03-25 01:43:52 --> Helper loaded: file_helper
INFO - 2025-03-25 01:43:52 --> Helper loaded: html_helper
INFO - 2025-03-25 01:43:52 --> Helper loaded: form_helper
INFO - 2025-03-25 01:43:52 --> Helper loaded: text_helper
INFO - 2025-03-25 01:43:52 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:43:52 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:43:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:43:52 --> Database Driver Class Initialized
INFO - 2025-03-25 01:43:52 --> Email Class Initialized
INFO - 2025-03-25 01:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:43:52 --> Form Validation Class Initialized
INFO - 2025-03-25 01:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:43:52 --> Pagination Class Initialized
INFO - 2025-03-25 01:43:52 --> Controller Class Initialized
INFO - 2025-03-25 01:43:52 --> Model Class Initialized
DEBUG - 2025-03-25 01:43:52 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:43:52 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:43:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:43:52 --> Model Class Initialized
DEBUG - 2025-03-25 01:43:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:43:52 --> Model Class Initialized
DEBUG - 2025-03-25 01:43:52 --> 🧾 Generated invoice_id = 1083
ERROR - 2025-03-25 01:43:52 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 01:43:52 --> ✅ Invoice inserted, returned invoice_id: 1083
DEBUG - 2025-03-25 01:43:52 --> ✅ Auto-approving voucher for invoice_id: 1083
DEBUG - 2025-03-25 01:43:52 --> 🎯 Vouchers to approve: [{"referenceNo":"1083","VNo":"CV-37"},{"referenceNo":"1083","VNo":"JV-51"},{"referenceNo":"1083","VNo":"JV-52"}]
DEBUG - 2025-03-25 01:43:52 --> 🟢 Approving voucher: VNo=CV-37, Ref=1083
DEBUG - 2025-03-25 01:43:52 --> 📥 acc_transaction insert: {"vid":"136","fyear":"1","VNo":"CV-37","Vtype":"CV","referenceNo":"1083","VDate":"2025-03-25","COAID":"1020502","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"29.72","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:43:52"}
DEBUG - 2025-03-25 01:43:52 --> 📥 acc_transaction insert: {"vid":"136","fyear":"1","VNo":"CV-37","Vtype":"CV","referenceNo":"1083","VDate":"2025-03-25","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"29.72","StoreID":0,"IsPosted":1,"RevCodde":"1020502","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:43:52"}
DEBUG - 2025-03-25 01:43:52 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:43:52 --> 🟢 Approving voucher: VNo=JV-51, Ref=1083
DEBUG - 2025-03-25 01:43:52 --> 📥 acc_transaction insert: {"vid":"137","fyear":"1","VNo":"JV-51","Vtype":"JV","referenceNo":"1083","VDate":"2025-03-25","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"49.14","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:43:52"}
DEBUG - 2025-03-25 01:43:52 --> 📥 acc_transaction insert: {"vid":"137","fyear":"1","VNo":"JV-51","Vtype":"JV","referenceNo":"1083","VDate":"2025-03-25","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"49.14","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:43:52"}
DEBUG - 2025-03-25 01:43:52 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:43:52 --> 🟢 Approving voucher: VNo=JV-52, Ref=1083
DEBUG - 2025-03-25 01:43:52 --> 📥 acc_transaction insert: {"vid":"138","fyear":"1","VNo":"JV-52","Vtype":"JV","referenceNo":"1083","VDate":"2025-03-25","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:43:52"}
DEBUG - 2025-03-25 01:43:52 --> 📥 acc_transaction insert: {"vid":"138","fyear":"1","VNo":"JV-52","Vtype":"JV","referenceNo":"1083","VDate":"2025-03-25","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:43:52"}
DEBUG - 2025-03-25 01:43:52 --> ✅ Voucher approved: true
INFO - 2025-03-25 01:43:52 --> Final output sent to browser
DEBUG - 2025-03-25 01:43:52 --> Total execution time: 0.0533
INFO - 2025-03-25 01:46:11 --> Config Class Initialized
INFO - 2025-03-25 01:46:11 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:46:11 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:46:11 --> Utf8 Class Initialized
INFO - 2025-03-25 01:46:11 --> URI Class Initialized
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 01:46:11 --> Router Class Initialized
INFO - 2025-03-25 01:46:11 --> Output Class Initialized
INFO - 2025-03-25 01:46:11 --> Security Class Initialized
DEBUG - 2025-03-25 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:46:11 --> Input Class Initialized
INFO - 2025-03-25 01:46:11 --> Language Class Initialized
INFO - 2025-03-25 01:46:11 --> Language Class Initialized
INFO - 2025-03-25 01:46:11 --> Config Class Initialized
INFO - 2025-03-25 01:46:11 --> Loader Class Initialized
INFO - 2025-03-25 01:46:11 --> Helper loaded: url_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: file_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: html_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: form_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: text_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:46:11 --> Database Driver Class Initialized
INFO - 2025-03-25 01:46:11 --> Email Class Initialized
INFO - 2025-03-25 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:46:11 --> Form Validation Class Initialized
INFO - 2025-03-25 01:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:46:11 --> Pagination Class Initialized
INFO - 2025-03-25 01:46:11 --> Controller Class Initialized
DEBUG - 2025-03-25 01:46:11 --> Report MX_Controller Initialized
INFO - 2025-03-25 01:46:11 --> Model Class Initialized
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 01:46:11 --> Model Class Initialized
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 01:46:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 01:46:11 --> Model Class Initialized
ERROR - 2025-03-25 01:46:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 01:46:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 01:46:11 --> Final output sent to browser
DEBUG - 2025-03-25 01:46:11 --> Total execution time: 0.2423
INFO - 2025-03-25 01:46:11 --> Config Class Initialized
INFO - 2025-03-25 01:46:11 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:46:11 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:46:11 --> Utf8 Class Initialized
INFO - 2025-03-25 01:46:11 --> URI Class Initialized
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 01:46:11 --> Router Class Initialized
INFO - 2025-03-25 01:46:11 --> Output Class Initialized
INFO - 2025-03-25 01:46:11 --> Security Class Initialized
DEBUG - 2025-03-25 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:46:11 --> Input Class Initialized
INFO - 2025-03-25 01:46:11 --> Language Class Initialized
INFO - 2025-03-25 01:46:11 --> Language Class Initialized
INFO - 2025-03-25 01:46:11 --> Config Class Initialized
INFO - 2025-03-25 01:46:11 --> Loader Class Initialized
INFO - 2025-03-25 01:46:11 --> Helper loaded: url_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: file_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: html_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: form_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: text_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:46:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:46:11 --> Database Driver Class Initialized
INFO - 2025-03-25 01:46:11 --> Email Class Initialized
INFO - 2025-03-25 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:46:11 --> Form Validation Class Initialized
INFO - 2025-03-25 01:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:46:11 --> Pagination Class Initialized
INFO - 2025-03-25 01:46:11 --> Controller Class Initialized
DEBUG - 2025-03-25 01:46:11 --> Report MX_Controller Initialized
INFO - 2025-03-25 01:46:11 --> Model Class Initialized
DEBUG - 2025-03-25 01:46:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 01:46:11 --> Model Class Initialized
INFO - 2025-03-25 01:46:11 --> Final output sent to browser
DEBUG - 2025-03-25 01:46:11 --> Total execution time: 0.0100
INFO - 2025-03-25 01:47:04 --> Config Class Initialized
INFO - 2025-03-25 01:47:04 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:47:04 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:47:04 --> Utf8 Class Initialized
INFO - 2025-03-25 01:47:04 --> URI Class Initialized
INFO - 2025-03-25 01:47:04 --> Router Class Initialized
INFO - 2025-03-25 01:47:04 --> Output Class Initialized
INFO - 2025-03-25 01:47:04 --> Security Class Initialized
DEBUG - 2025-03-25 01:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:47:04 --> Input Class Initialized
INFO - 2025-03-25 01:47:04 --> Language Class Initialized
INFO - 2025-03-25 01:47:04 --> Language Class Initialized
INFO - 2025-03-25 01:47:04 --> Config Class Initialized
INFO - 2025-03-25 01:47:04 --> Loader Class Initialized
INFO - 2025-03-25 01:47:04 --> Helper loaded: url_helper
INFO - 2025-03-25 01:47:04 --> Helper loaded: file_helper
INFO - 2025-03-25 01:47:04 --> Helper loaded: html_helper
INFO - 2025-03-25 01:47:04 --> Helper loaded: form_helper
INFO - 2025-03-25 01:47:04 --> Helper loaded: text_helper
INFO - 2025-03-25 01:47:04 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:47:04 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:47:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:47:04 --> Database Driver Class Initialized
INFO - 2025-03-25 01:47:04 --> Email Class Initialized
INFO - 2025-03-25 01:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:47:04 --> Form Validation Class Initialized
INFO - 2025-03-25 01:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:47:04 --> Pagination Class Initialized
INFO - 2025-03-25 01:47:04 --> Controller Class Initialized
INFO - 2025-03-25 01:47:04 --> Model Class Initialized
INFO - 2025-03-25 01:47:04 --> Final output sent to browser
DEBUG - 2025-03-25 01:47:04 --> Total execution time: 0.0503
INFO - 2025-03-25 01:48:13 --> Config Class Initialized
INFO - 2025-03-25 01:48:13 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:13 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:13 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:13 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 01:48:13 --> Router Class Initialized
INFO - 2025-03-25 01:48:13 --> Output Class Initialized
INFO - 2025-03-25 01:48:13 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:13 --> Input Class Initialized
INFO - 2025-03-25 01:48:13 --> Language Class Initialized
INFO - 2025-03-25 01:48:13 --> Language Class Initialized
INFO - 2025-03-25 01:48:13 --> Config Class Initialized
INFO - 2025-03-25 01:48:13 --> Loader Class Initialized
INFO - 2025-03-25 01:48:13 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:13 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:13 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:13 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:13 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:13 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:13 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:13 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:13 --> Email Class Initialized
INFO - 2025-03-25 01:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:13 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:13 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:13 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:13 --> Report MX_Controller Initialized
INFO - 2025-03-25 01:48:13 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 01:48:13 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 01:48:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 01:48:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 01:48:13 --> Model Class Initialized
ERROR - 2025-03-25 01:48:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 01:48:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 01:48:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 01:48:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 01:48:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 01:48:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 01:48:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 01:48:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 01:48:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 01:48:14 --> Final output sent to browser
DEBUG - 2025-03-25 01:48:14 --> Total execution time: 0.1317
INFO - 2025-03-25 01:48:14 --> Config Class Initialized
INFO - 2025-03-25 01:48:14 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:14 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:14 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:14 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 01:48:14 --> Router Class Initialized
INFO - 2025-03-25 01:48:14 --> Output Class Initialized
INFO - 2025-03-25 01:48:14 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:14 --> Input Class Initialized
INFO - 2025-03-25 01:48:14 --> Language Class Initialized
INFO - 2025-03-25 01:48:14 --> Language Class Initialized
INFO - 2025-03-25 01:48:14 --> Config Class Initialized
INFO - 2025-03-25 01:48:14 --> Loader Class Initialized
INFO - 2025-03-25 01:48:14 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:14 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:14 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:14 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:14 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:14 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:14 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:14 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:14 --> Email Class Initialized
INFO - 2025-03-25 01:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:14 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:14 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:14 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:14 --> Report MX_Controller Initialized
INFO - 2025-03-25 01:48:14 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 01:48:14 --> Model Class Initialized
INFO - 2025-03-25 01:48:14 --> Final output sent to browser
DEBUG - 2025-03-25 01:48:14 --> Total execution time: 0.0109
INFO - 2025-03-25 01:48:30 --> Config Class Initialized
INFO - 2025-03-25 01:48:30 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:30 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:30 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:30 --> URI Class Initialized
INFO - 2025-03-25 01:48:30 --> Router Class Initialized
INFO - 2025-03-25 01:48:30 --> Output Class Initialized
INFO - 2025-03-25 01:48:30 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:30 --> Input Class Initialized
INFO - 2025-03-25 01:48:30 --> Language Class Initialized
INFO - 2025-03-25 01:48:30 --> Language Class Initialized
INFO - 2025-03-25 01:48:30 --> Config Class Initialized
INFO - 2025-03-25 01:48:30 --> Loader Class Initialized
INFO - 2025-03-25 01:48:30 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:30 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:30 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:30 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:30 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:30 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:30 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:30 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:30 --> Email Class Initialized
INFO - 2025-03-25 01:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:30 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:30 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:30 --> Controller Class Initialized
INFO - 2025-03-25 01:48:30 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:30 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:48:30 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 29.72
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 51252612252670
                    [product_quantity] => 2
                    [product_rate] => 29.72
                    [serial_no] => 
                )

        )

)

DEBUG - 2025-03-25 01:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:48:30 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:48:30 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:30 --> 🧾 Generated invoice_id = 1084
ERROR - 2025-03-25 01:48:30 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 01:48:30 --> ✅ Invoice inserted, returned invoice_id: 1084
DEBUG - 2025-03-25 01:48:30 --> ✅ Auto-approving voucher for invoice_id: 1084
DEBUG - 2025-03-25 01:48:30 --> 🎯 Vouchers to approve: [{"referenceNo":"1084","VNo":"CV-38"},{"referenceNo":"1084","VNo":"JV-53"},{"referenceNo":"1084","VNo":"JV-54"}]
DEBUG - 2025-03-25 01:48:30 --> 🟢 Approving voucher: VNo=CV-38, Ref=1084
DEBUG - 2025-03-25 01:48:30 --> 📥 acc_transaction insert: {"vid":"139","fyear":"1","VNo":"CV-38","Vtype":"CV","referenceNo":"1084","VDate":"2025-03-25","COAID":"1020502","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"29.72","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:48:30"}
DEBUG - 2025-03-25 01:48:30 --> 📥 acc_transaction insert: {"vid":"139","fyear":"1","VNo":"CV-38","Vtype":"CV","referenceNo":"1084","VDate":"2025-03-25","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"29.72","StoreID":0,"IsPosted":1,"RevCodde":"1020502","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:48:30"}
DEBUG - 2025-03-25 01:48:30 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:48:30 --> 🟢 Approving voucher: VNo=JV-53, Ref=1084
DEBUG - 2025-03-25 01:48:30 --> 📥 acc_transaction insert: {"vid":"140","fyear":"1","VNo":"JV-53","Vtype":"JV","referenceNo":"1084","VDate":"2025-03-25","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"49.14","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:48:30"}
DEBUG - 2025-03-25 01:48:30 --> 📥 acc_transaction insert: {"vid":"140","fyear":"1","VNo":"JV-53","Vtype":"JV","referenceNo":"1084","VDate":"2025-03-25","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"49.14","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:48:30"}
DEBUG - 2025-03-25 01:48:30 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:48:30 --> 🟢 Approving voucher: VNo=JV-54, Ref=1084
DEBUG - 2025-03-25 01:48:30 --> 📥 acc_transaction insert: {"vid":"141","fyear":"1","VNo":"JV-54","Vtype":"JV","referenceNo":"1084","VDate":"2025-03-25","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:48:30"}
DEBUG - 2025-03-25 01:48:30 --> 📥 acc_transaction insert: {"vid":"141","fyear":"1","VNo":"JV-54","Vtype":"JV","referenceNo":"1084","VDate":"2025-03-25","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:48:30"}
DEBUG - 2025-03-25 01:48:30 --> ✅ Voucher approved: true
INFO - 2025-03-25 01:48:30 --> Final output sent to browser
DEBUG - 2025-03-25 01:48:30 --> Total execution time: 0.0693
INFO - 2025-03-25 01:48:34 --> Config Class Initialized
INFO - 2025-03-25 01:48:34 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:34 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:34 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:34 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 01:48:34 --> Router Class Initialized
INFO - 2025-03-25 01:48:34 --> Output Class Initialized
INFO - 2025-03-25 01:48:34 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:34 --> Input Class Initialized
INFO - 2025-03-25 01:48:34 --> Language Class Initialized
INFO - 2025-03-25 01:48:34 --> Language Class Initialized
INFO - 2025-03-25 01:48:34 --> Config Class Initialized
INFO - 2025-03-25 01:48:34 --> Loader Class Initialized
INFO - 2025-03-25 01:48:34 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:34 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:34 --> Email Class Initialized
INFO - 2025-03-25 01:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:34 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:34 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:34 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:34 --> Report MX_Controller Initialized
INFO - 2025-03-25 01:48:34 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 01:48:34 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 01:48:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 01:48:34 --> Model Class Initialized
ERROR - 2025-03-25 01:48:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 01:48:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 01:48:34 --> Final output sent to browser
DEBUG - 2025-03-25 01:48:34 --> Total execution time: 0.1243
INFO - 2025-03-25 01:48:34 --> Config Class Initialized
INFO - 2025-03-25 01:48:34 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:34 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:34 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:34 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-25 01:48:34 --> Router Class Initialized
INFO - 2025-03-25 01:48:34 --> Output Class Initialized
INFO - 2025-03-25 01:48:34 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:34 --> Input Class Initialized
INFO - 2025-03-25 01:48:34 --> Language Class Initialized
INFO - 2025-03-25 01:48:34 --> Language Class Initialized
INFO - 2025-03-25 01:48:34 --> Config Class Initialized
INFO - 2025-03-25 01:48:34 --> Loader Class Initialized
INFO - 2025-03-25 01:48:34 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:34 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:34 --> Email Class Initialized
INFO - 2025-03-25 01:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:34 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:34 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:34 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:34 --> Report MX_Controller Initialized
INFO - 2025-03-25 01:48:34 --> Model Class Initialized
DEBUG - 2025-03-25 01:48:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-25 01:48:34 --> Model Class Initialized
INFO - 2025-03-25 01:48:34 --> Final output sent to browser
DEBUG - 2025-03-25 01:48:34 --> Total execution time: 0.0129
INFO - 2025-03-25 01:48:40 --> Config Class Initialized
INFO - 2025-03-25 01:48:40 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:40 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:40 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:40 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:48:40 --> Router Class Initialized
INFO - 2025-03-25 01:48:40 --> Output Class Initialized
INFO - 2025-03-25 01:48:40 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:40 --> Input Class Initialized
INFO - 2025-03-25 01:48:40 --> Language Class Initialized
INFO - 2025-03-25 01:48:40 --> Language Class Initialized
INFO - 2025-03-25 01:48:40 --> Config Class Initialized
INFO - 2025-03-25 01:48:40 --> Loader Class Initialized
INFO - 2025-03-25 01:48:40 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:40 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:40 --> Email Class Initialized
INFO - 2025-03-25 01:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:40 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:40 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:40 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:40 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:48:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
ERROR - 2025-03-25 07:48:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:48:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:48:40 --> Final output sent to browser
DEBUG - 2025-03-25 07:48:40 --> Total execution time: 0.1260
INFO - 2025-03-25 01:48:40 --> Config Class Initialized
INFO - 2025-03-25 01:48:40 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:40 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:40 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:40 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:48:40 --> Router Class Initialized
INFO - 2025-03-25 01:48:40 --> Output Class Initialized
INFO - 2025-03-25 01:48:40 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:40 --> Input Class Initialized
INFO - 2025-03-25 01:48:40 --> Language Class Initialized
INFO - 2025-03-25 01:48:40 --> Language Class Initialized
INFO - 2025-03-25 01:48:40 --> Config Class Initialized
INFO - 2025-03-25 01:48:40 --> Loader Class Initialized
INFO - 2025-03-25 01:48:40 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:40 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:40 --> Email Class Initialized
INFO - 2025-03-25 01:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:40 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:40 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:40 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:40 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:48:40 --> Model Class Initialized
INFO - 2025-03-25 07:48:40 --> Final output sent to browser
DEBUG - 2025-03-25 07:48:40 --> Total execution time: 0.0476
INFO - 2025-03-25 01:48:44 --> Config Class Initialized
INFO - 2025-03-25 01:48:44 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:44 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:44 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:44 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:48:44 --> Router Class Initialized
INFO - 2025-03-25 01:48:44 --> Output Class Initialized
INFO - 2025-03-25 01:48:44 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:44 --> Input Class Initialized
INFO - 2025-03-25 01:48:44 --> Language Class Initialized
INFO - 2025-03-25 01:48:44 --> Language Class Initialized
INFO - 2025-03-25 01:48:44 --> Config Class Initialized
INFO - 2025-03-25 01:48:44 --> Loader Class Initialized
INFO - 2025-03-25 01:48:44 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:44 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:44 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:44 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:44 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:44 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:44 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:44 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:44 --> Email Class Initialized
INFO - 2025-03-25 01:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:44 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:44 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:44 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:44 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:48:44 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:48:44 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:48:44 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:48:44 --> Model Class Initialized
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:48:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:48:44 --> Model Class Initialized
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 166
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
ERROR - 2025-03-25 07:48:44 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:48:44 --> Final output sent to browser
DEBUG - 2025-03-25 07:48:44 --> Total execution time: 0.1353
INFO - 2025-03-25 01:48:56 --> Config Class Initialized
INFO - 2025-03-25 01:48:56 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:56 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:56 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:56 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:48:56 --> Router Class Initialized
INFO - 2025-03-25 01:48:56 --> Output Class Initialized
INFO - 2025-03-25 01:48:56 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:56 --> Input Class Initialized
INFO - 2025-03-25 01:48:56 --> Language Class Initialized
INFO - 2025-03-25 01:48:56 --> Language Class Initialized
INFO - 2025-03-25 01:48:56 --> Config Class Initialized
INFO - 2025-03-25 01:48:56 --> Loader Class Initialized
INFO - 2025-03-25 01:48:56 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:56 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:56 --> Email Class Initialized
INFO - 2025-03-25 01:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:56 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:56 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:56 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:56 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:48:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
ERROR - 2025-03-25 07:48:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:48:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:48:56 --> Final output sent to browser
DEBUG - 2025-03-25 07:48:56 --> Total execution time: 0.1294
INFO - 2025-03-25 01:48:56 --> Config Class Initialized
INFO - 2025-03-25 01:48:56 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:48:56 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:48:56 --> Utf8 Class Initialized
INFO - 2025-03-25 01:48:56 --> URI Class Initialized
DEBUG - 2025-03-25 01:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:48:56 --> Router Class Initialized
INFO - 2025-03-25 01:48:56 --> Output Class Initialized
INFO - 2025-03-25 01:48:56 --> Security Class Initialized
DEBUG - 2025-03-25 01:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:48:56 --> Input Class Initialized
INFO - 2025-03-25 01:48:56 --> Language Class Initialized
INFO - 2025-03-25 01:48:56 --> Language Class Initialized
INFO - 2025-03-25 01:48:56 --> Config Class Initialized
INFO - 2025-03-25 01:48:56 --> Loader Class Initialized
INFO - 2025-03-25 01:48:56 --> Helper loaded: url_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: file_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: html_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: form_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: text_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:48:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:48:56 --> Database Driver Class Initialized
INFO - 2025-03-25 01:48:56 --> Email Class Initialized
INFO - 2025-03-25 01:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:48:56 --> Form Validation Class Initialized
INFO - 2025-03-25 01:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:48:56 --> Pagination Class Initialized
INFO - 2025-03-25 01:48:56 --> Controller Class Initialized
DEBUG - 2025-03-25 01:48:56 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
DEBUG - 2025-03-25 07:48:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:48:56 --> Model Class Initialized
INFO - 2025-03-25 07:48:56 --> Final output sent to browser
DEBUG - 2025-03-25 07:48:56 --> Total execution time: 0.0510
INFO - 2025-03-25 01:49:01 --> Config Class Initialized
INFO - 2025-03-25 01:49:01 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:49:01 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:49:01 --> Utf8 Class Initialized
INFO - 2025-03-25 01:49:01 --> URI Class Initialized
DEBUG - 2025-03-25 01:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:49:01 --> Router Class Initialized
INFO - 2025-03-25 01:49:01 --> Output Class Initialized
INFO - 2025-03-25 01:49:01 --> Security Class Initialized
DEBUG - 2025-03-25 01:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:49:01 --> Input Class Initialized
INFO - 2025-03-25 01:49:01 --> Language Class Initialized
INFO - 2025-03-25 01:49:01 --> Language Class Initialized
INFO - 2025-03-25 01:49:01 --> Config Class Initialized
INFO - 2025-03-25 01:49:01 --> Loader Class Initialized
INFO - 2025-03-25 01:49:01 --> Helper loaded: url_helper
INFO - 2025-03-25 01:49:01 --> Helper loaded: file_helper
INFO - 2025-03-25 01:49:01 --> Helper loaded: html_helper
INFO - 2025-03-25 01:49:01 --> Helper loaded: form_helper
INFO - 2025-03-25 01:49:01 --> Helper loaded: text_helper
INFO - 2025-03-25 01:49:01 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:49:01 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:49:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:49:01 --> Database Driver Class Initialized
INFO - 2025-03-25 01:49:01 --> Email Class Initialized
INFO - 2025-03-25 01:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:49:01 --> Form Validation Class Initialized
INFO - 2025-03-25 01:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:49:01 --> Pagination Class Initialized
INFO - 2025-03-25 01:49:01 --> Controller Class Initialized
DEBUG - 2025-03-25 01:49:01 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:49:01 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:49:01 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:49:01 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:49:01 --> Model Class Initialized
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:49:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:49:01 --> Model Class Initialized
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 166
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
ERROR - 2025-03-25 07:49:01 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:49:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:49:01 --> Final output sent to browser
DEBUG - 2025-03-25 07:49:01 --> Total execution time: 0.1171
INFO - 2025-03-25 01:49:04 --> Config Class Initialized
INFO - 2025-03-25 01:49:04 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:49:04 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:49:04 --> Utf8 Class Initialized
INFO - 2025-03-25 01:49:04 --> URI Class Initialized
DEBUG - 2025-03-25 01:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:49:04 --> Router Class Initialized
INFO - 2025-03-25 01:49:04 --> Output Class Initialized
INFO - 2025-03-25 01:49:04 --> Security Class Initialized
DEBUG - 2025-03-25 01:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:49:04 --> Input Class Initialized
INFO - 2025-03-25 01:49:04 --> Language Class Initialized
INFO - 2025-03-25 01:49:04 --> Language Class Initialized
INFO - 2025-03-25 01:49:04 --> Config Class Initialized
INFO - 2025-03-25 01:49:04 --> Loader Class Initialized
INFO - 2025-03-25 01:49:04 --> Helper loaded: url_helper
INFO - 2025-03-25 01:49:04 --> Helper loaded: file_helper
INFO - 2025-03-25 01:49:04 --> Helper loaded: html_helper
INFO - 2025-03-25 01:49:04 --> Helper loaded: form_helper
INFO - 2025-03-25 01:49:04 --> Helper loaded: text_helper
INFO - 2025-03-25 01:49:04 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:49:04 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:49:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:49:04 --> Database Driver Class Initialized
INFO - 2025-03-25 01:49:04 --> Email Class Initialized
INFO - 2025-03-25 01:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:49:04 --> Form Validation Class Initialized
INFO - 2025-03-25 01:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:49:04 --> Pagination Class Initialized
INFO - 2025-03-25 01:49:04 --> Controller Class Initialized
DEBUG - 2025-03-25 01:49:04 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:49:04 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:49:04 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:49:04 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:49:04 --> Model Class Initialized
ERROR - 2025-03-25 07:49:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 07:49:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-25 07:49:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-25 07:49:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:49:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:49:04 --> Model Class Initialized
ERROR - 2025-03-25 07:49:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:49:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 07:49:04 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:49:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:49:04 --> Final output sent to browser
DEBUG - 2025-03-25 07:49:04 --> Total execution time: 0.1275
INFO - 2025-03-25 01:49:08 --> Config Class Initialized
INFO - 2025-03-25 01:49:08 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:49:08 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:49:08 --> Utf8 Class Initialized
INFO - 2025-03-25 01:49:08 --> URI Class Initialized
DEBUG - 2025-03-25 01:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:49:08 --> Router Class Initialized
INFO - 2025-03-25 01:49:08 --> Output Class Initialized
INFO - 2025-03-25 01:49:08 --> Security Class Initialized
DEBUG - 2025-03-25 01:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:49:08 --> Input Class Initialized
INFO - 2025-03-25 01:49:08 --> Language Class Initialized
INFO - 2025-03-25 01:49:08 --> Language Class Initialized
INFO - 2025-03-25 01:49:08 --> Config Class Initialized
INFO - 2025-03-25 01:49:08 --> Loader Class Initialized
INFO - 2025-03-25 01:49:08 --> Helper loaded: url_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: file_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: html_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: form_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: text_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:49:08 --> Database Driver Class Initialized
INFO - 2025-03-25 01:49:08 --> Email Class Initialized
INFO - 2025-03-25 01:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:49:08 --> Form Validation Class Initialized
INFO - 2025-03-25 01:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:49:08 --> Pagination Class Initialized
INFO - 2025-03-25 01:49:08 --> Controller Class Initialized
DEBUG - 2025-03-25 01:49:08 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:49:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
ERROR - 2025-03-25 07:49:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:49:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:49:08 --> Final output sent to browser
DEBUG - 2025-03-25 07:49:08 --> Total execution time: 0.1197
INFO - 2025-03-25 01:49:08 --> Config Class Initialized
INFO - 2025-03-25 01:49:08 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:49:08 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:49:08 --> Utf8 Class Initialized
INFO - 2025-03-25 01:49:08 --> URI Class Initialized
DEBUG - 2025-03-25 01:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:49:08 --> Router Class Initialized
INFO - 2025-03-25 01:49:08 --> Output Class Initialized
INFO - 2025-03-25 01:49:08 --> Security Class Initialized
DEBUG - 2025-03-25 01:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:49:08 --> Input Class Initialized
INFO - 2025-03-25 01:49:08 --> Language Class Initialized
INFO - 2025-03-25 01:49:08 --> Language Class Initialized
INFO - 2025-03-25 01:49:08 --> Config Class Initialized
INFO - 2025-03-25 01:49:08 --> Loader Class Initialized
INFO - 2025-03-25 01:49:08 --> Helper loaded: url_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: file_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: html_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: form_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: text_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:49:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:49:08 --> Database Driver Class Initialized
INFO - 2025-03-25 01:49:08 --> Email Class Initialized
INFO - 2025-03-25 01:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:49:08 --> Form Validation Class Initialized
INFO - 2025-03-25 01:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:49:08 --> Pagination Class Initialized
INFO - 2025-03-25 01:49:08 --> Controller Class Initialized
DEBUG - 2025-03-25 01:49:08 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
DEBUG - 2025-03-25 07:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:49:08 --> Model Class Initialized
INFO - 2025-03-25 07:49:08 --> Final output sent to browser
DEBUG - 2025-03-25 07:49:08 --> Total execution time: 0.0391
INFO - 2025-03-25 01:50:34 --> Config Class Initialized
INFO - 2025-03-25 01:50:34 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:50:34 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:50:34 --> Utf8 Class Initialized
INFO - 2025-03-25 01:50:34 --> URI Class Initialized
DEBUG - 2025-03-25 01:50:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:50:34 --> Router Class Initialized
INFO - 2025-03-25 01:50:34 --> Output Class Initialized
INFO - 2025-03-25 01:50:34 --> Security Class Initialized
DEBUG - 2025-03-25 01:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:50:34 --> Input Class Initialized
INFO - 2025-03-25 01:50:34 --> Language Class Initialized
INFO - 2025-03-25 01:50:34 --> Language Class Initialized
INFO - 2025-03-25 01:50:34 --> Config Class Initialized
INFO - 2025-03-25 01:50:34 --> Loader Class Initialized
INFO - 2025-03-25 01:50:34 --> Helper loaded: url_helper
INFO - 2025-03-25 01:50:34 --> Helper loaded: file_helper
INFO - 2025-03-25 01:50:34 --> Helper loaded: html_helper
INFO - 2025-03-25 01:50:34 --> Helper loaded: form_helper
INFO - 2025-03-25 01:50:34 --> Helper loaded: text_helper
INFO - 2025-03-25 01:50:34 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:50:34 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:50:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:50:34 --> Database Driver Class Initialized
INFO - 2025-03-25 01:50:34 --> Email Class Initialized
INFO - 2025-03-25 01:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:50:34 --> Form Validation Class Initialized
INFO - 2025-03-25 01:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:50:34 --> Pagination Class Initialized
INFO - 2025-03-25 01:50:34 --> Controller Class Initialized
DEBUG - 2025-03-25 01:50:34 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:50:34 --> Model Class Initialized
DEBUG - 2025-03-25 07:50:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:50:34 --> Model Class Initialized
DEBUG - 2025-03-25 07:50:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:50:34 --> Model Class Initialized
DEBUG - 2025-03-25 07:50:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:50:34 --> Model Class Initialized
INFO - 2025-03-25 07:50:34 --> Final output sent to browser
DEBUG - 2025-03-25 07:50:34 --> Total execution time: 0.0373
INFO - 2025-03-25 01:50:37 --> Config Class Initialized
INFO - 2025-03-25 01:50:37 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:50:37 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:50:37 --> Utf8 Class Initialized
INFO - 2025-03-25 01:50:37 --> URI Class Initialized
DEBUG - 2025-03-25 01:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:50:37 --> Router Class Initialized
INFO - 2025-03-25 01:50:37 --> Output Class Initialized
INFO - 2025-03-25 01:50:37 --> Security Class Initialized
DEBUG - 2025-03-25 01:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:50:37 --> Input Class Initialized
INFO - 2025-03-25 01:50:37 --> Language Class Initialized
INFO - 2025-03-25 01:50:37 --> Language Class Initialized
INFO - 2025-03-25 01:50:37 --> Config Class Initialized
INFO - 2025-03-25 01:50:37 --> Loader Class Initialized
INFO - 2025-03-25 01:50:37 --> Helper loaded: url_helper
INFO - 2025-03-25 01:50:37 --> Helper loaded: file_helper
INFO - 2025-03-25 01:50:37 --> Helper loaded: html_helper
INFO - 2025-03-25 01:50:37 --> Helper loaded: form_helper
INFO - 2025-03-25 01:50:37 --> Helper loaded: text_helper
INFO - 2025-03-25 01:50:37 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:50:37 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:50:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:50:37 --> Database Driver Class Initialized
INFO - 2025-03-25 01:50:37 --> Email Class Initialized
INFO - 2025-03-25 01:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:50:37 --> Form Validation Class Initialized
INFO - 2025-03-25 01:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:50:37 --> Pagination Class Initialized
INFO - 2025-03-25 01:50:37 --> Controller Class Initialized
DEBUG - 2025-03-25 01:50:37 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:50:37 --> Model Class Initialized
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:50:37 --> Model Class Initialized
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:50:37 --> Model Class Initialized
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:50:37 --> Model Class Initialized
ERROR - 2025-03-25 07:50:37 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
ERROR - 2025-03-25 07:50:37 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:50:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:50:37 --> Model Class Initialized
ERROR - 2025-03-25 07:50:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:50:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:50:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:50:37 --> Final output sent to browser
DEBUG - 2025-03-25 07:50:37 --> Total execution time: 0.1491
INFO - 2025-03-25 01:51:42 --> Config Class Initialized
INFO - 2025-03-25 01:51:42 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:51:42 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:51:42 --> Utf8 Class Initialized
INFO - 2025-03-25 01:51:42 --> URI Class Initialized
INFO - 2025-03-25 01:51:42 --> Router Class Initialized
INFO - 2025-03-25 01:51:42 --> Output Class Initialized
INFO - 2025-03-25 01:51:42 --> Security Class Initialized
DEBUG - 2025-03-25 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:51:42 --> Input Class Initialized
INFO - 2025-03-25 01:51:42 --> Language Class Initialized
INFO - 2025-03-25 01:51:42 --> Language Class Initialized
INFO - 2025-03-25 01:51:42 --> Config Class Initialized
INFO - 2025-03-25 01:51:42 --> Loader Class Initialized
INFO - 2025-03-25 01:51:42 --> Helper loaded: url_helper
INFO - 2025-03-25 01:51:42 --> Helper loaded: file_helper
INFO - 2025-03-25 01:51:42 --> Helper loaded: html_helper
INFO - 2025-03-25 01:51:42 --> Helper loaded: form_helper
INFO - 2025-03-25 01:51:42 --> Helper loaded: text_helper
INFO - 2025-03-25 01:51:42 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:51:42 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:51:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:51:42 --> Database Driver Class Initialized
INFO - 2025-03-25 01:51:42 --> Email Class Initialized
INFO - 2025-03-25 01:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:51:42 --> Form Validation Class Initialized
INFO - 2025-03-25 01:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:51:42 --> Pagination Class Initialized
INFO - 2025-03-25 01:51:42 --> Controller Class Initialized
INFO - 2025-03-25 01:51:42 --> Model Class Initialized
DEBUG - 2025-03-25 01:51:42 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:51:42 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 50
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 2
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

        )

)

DEBUG - 2025-03-25 01:51:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:51:42 --> Model Class Initialized
DEBUG - 2025-03-25 01:51:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:51:42 --> Model Class Initialized
DEBUG - 2025-03-25 01:51:42 --> 🧾 Generated invoice_id = 1085
ERROR - 2025-03-25 01:51:42 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 01:51:42 --> ✅ Invoice inserted, returned invoice_id: 1085
DEBUG - 2025-03-25 01:51:42 --> ✅ Auto-approving voucher for invoice_id: 1085
DEBUG - 2025-03-25 01:51:42 --> 🎯 Vouchers to approve: [{"referenceNo":"1085","VNo":"CV-39"},{"referenceNo":"1085","VNo":"JV-55"},{"referenceNo":"1085","VNo":"JV-56"}]
DEBUG - 2025-03-25 01:51:42 --> 🟢 Approving voucher: VNo=CV-39, Ref=1085
DEBUG - 2025-03-25 01:51:42 --> 📥 acc_transaction insert: {"vid":"142","fyear":"1","VNo":"CV-39","Vtype":"CV","referenceNo":"1085","VDate":"2025-03-25","COAID":"1020502","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"50.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:51:42"}
DEBUG - 2025-03-25 01:51:42 --> 📥 acc_transaction insert: {"vid":"142","fyear":"1","VNo":"CV-39","Vtype":"CV","referenceNo":"1085","VDate":"2025-03-25","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"50.00","StoreID":0,"IsPosted":1,"RevCodde":"1020502","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:51:42"}
DEBUG - 2025-03-25 01:51:42 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:51:42 --> 🟢 Approving voucher: VNo=JV-55, Ref=1085
DEBUG - 2025-03-25 01:51:42 --> 📥 acc_transaction insert: {"vid":"143","fyear":"1","VNo":"JV-55","Vtype":"JV","referenceNo":"1085","VDate":"2025-03-25","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"40.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:51:42"}
DEBUG - 2025-03-25 01:51:42 --> 📥 acc_transaction insert: {"vid":"143","fyear":"1","VNo":"JV-55","Vtype":"JV","referenceNo":"1085","VDate":"2025-03-25","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"40.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:51:42"}
DEBUG - 2025-03-25 01:51:42 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:51:42 --> 🟢 Approving voucher: VNo=JV-56, Ref=1085
DEBUG - 2025-03-25 01:51:42 --> 📥 acc_transaction insert: {"vid":"144","fyear":"1","VNo":"JV-56","Vtype":"JV","referenceNo":"1085","VDate":"2025-03-25","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:51:42"}
DEBUG - 2025-03-25 01:51:42 --> 📥 acc_transaction insert: {"vid":"144","fyear":"1","VNo":"JV-56","Vtype":"JV","referenceNo":"1085","VDate":"2025-03-25","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:51:42"}
DEBUG - 2025-03-25 01:51:42 --> ✅ Voucher approved: true
INFO - 2025-03-25 01:51:42 --> Final output sent to browser
DEBUG - 2025-03-25 01:51:42 --> Total execution time: 0.0415
INFO - 2025-03-25 01:51:50 --> Config Class Initialized
INFO - 2025-03-25 01:51:50 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:51:50 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:51:50 --> Utf8 Class Initialized
INFO - 2025-03-25 01:51:50 --> URI Class Initialized
DEBUG - 2025-03-25 01:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:51:50 --> Router Class Initialized
INFO - 2025-03-25 01:51:50 --> Output Class Initialized
INFO - 2025-03-25 01:51:50 --> Security Class Initialized
DEBUG - 2025-03-25 01:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:51:50 --> Input Class Initialized
INFO - 2025-03-25 01:51:50 --> Language Class Initialized
INFO - 2025-03-25 01:51:50 --> Language Class Initialized
INFO - 2025-03-25 01:51:50 --> Config Class Initialized
INFO - 2025-03-25 01:51:50 --> Loader Class Initialized
INFO - 2025-03-25 01:51:50 --> Helper loaded: url_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: file_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: html_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: form_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: text_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:51:50 --> Database Driver Class Initialized
INFO - 2025-03-25 01:51:50 --> Email Class Initialized
INFO - 2025-03-25 01:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:51:50 --> Form Validation Class Initialized
INFO - 2025-03-25 01:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:51:50 --> Pagination Class Initialized
INFO - 2025-03-25 01:51:50 --> Controller Class Initialized
DEBUG - 2025-03-25 01:51:50 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:51:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
ERROR - 2025-03-25 07:51:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:51:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:51:50 --> Final output sent to browser
DEBUG - 2025-03-25 07:51:50 --> Total execution time: 0.0909
INFO - 2025-03-25 01:51:50 --> Config Class Initialized
INFO - 2025-03-25 01:51:50 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:51:50 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:51:50 --> Utf8 Class Initialized
INFO - 2025-03-25 01:51:50 --> URI Class Initialized
DEBUG - 2025-03-25 01:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:51:50 --> Router Class Initialized
INFO - 2025-03-25 01:51:50 --> Output Class Initialized
INFO - 2025-03-25 01:51:50 --> Security Class Initialized
DEBUG - 2025-03-25 01:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:51:50 --> Input Class Initialized
INFO - 2025-03-25 01:51:50 --> Language Class Initialized
INFO - 2025-03-25 01:51:50 --> Language Class Initialized
INFO - 2025-03-25 01:51:50 --> Config Class Initialized
INFO - 2025-03-25 01:51:50 --> Loader Class Initialized
INFO - 2025-03-25 01:51:50 --> Helper loaded: url_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: file_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: html_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: form_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: text_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:51:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:51:50 --> Database Driver Class Initialized
INFO - 2025-03-25 01:51:50 --> Email Class Initialized
INFO - 2025-03-25 01:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:51:50 --> Form Validation Class Initialized
INFO - 2025-03-25 01:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:51:50 --> Pagination Class Initialized
INFO - 2025-03-25 01:51:50 --> Controller Class Initialized
DEBUG - 2025-03-25 01:51:50 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:51:50 --> Model Class Initialized
INFO - 2025-03-25 07:51:50 --> Final output sent to browser
DEBUG - 2025-03-25 07:51:50 --> Total execution time: 0.0492
INFO - 2025-03-25 01:51:52 --> Config Class Initialized
INFO - 2025-03-25 01:51:52 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:51:52 --> Utf8 Class Initialized
INFO - 2025-03-25 01:51:52 --> URI Class Initialized
DEBUG - 2025-03-25 01:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:51:52 --> Router Class Initialized
INFO - 2025-03-25 01:51:52 --> Output Class Initialized
INFO - 2025-03-25 01:51:52 --> Security Class Initialized
DEBUG - 2025-03-25 01:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:51:52 --> Input Class Initialized
INFO - 2025-03-25 01:51:52 --> Language Class Initialized
INFO - 2025-03-25 01:51:52 --> Language Class Initialized
INFO - 2025-03-25 01:51:52 --> Config Class Initialized
INFO - 2025-03-25 01:51:52 --> Loader Class Initialized
INFO - 2025-03-25 01:51:52 --> Helper loaded: url_helper
INFO - 2025-03-25 01:51:52 --> Helper loaded: file_helper
INFO - 2025-03-25 01:51:52 --> Helper loaded: html_helper
INFO - 2025-03-25 01:51:52 --> Helper loaded: form_helper
INFO - 2025-03-25 01:51:52 --> Helper loaded: text_helper
INFO - 2025-03-25 01:51:52 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:51:52 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:51:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:51:52 --> Database Driver Class Initialized
INFO - 2025-03-25 01:51:52 --> Email Class Initialized
INFO - 2025-03-25 01:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:51:52 --> Form Validation Class Initialized
INFO - 2025-03-25 01:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:51:52 --> Pagination Class Initialized
INFO - 2025-03-25 01:51:52 --> Controller Class Initialized
DEBUG - 2025-03-25 01:51:52 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:51:52 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:51:52 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:51:52 --> Model Class Initialized
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:51:52 --> Model Class Initialized
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:51:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:51:52 --> Model Class Initialized
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 166
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
ERROR - 2025-03-25 07:51:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:51:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:51:52 --> Final output sent to browser
DEBUG - 2025-03-25 07:51:52 --> Total execution time: 0.1086
INFO - 2025-03-25 01:53:48 --> Config Class Initialized
INFO - 2025-03-25 01:53:48 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:53:48 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:53:48 --> Utf8 Class Initialized
INFO - 2025-03-25 01:53:48 --> URI Class Initialized
INFO - 2025-03-25 01:53:48 --> Router Class Initialized
INFO - 2025-03-25 01:53:48 --> Output Class Initialized
INFO - 2025-03-25 01:53:48 --> Security Class Initialized
DEBUG - 2025-03-25 01:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:53:48 --> Input Class Initialized
INFO - 2025-03-25 01:53:48 --> Language Class Initialized
INFO - 2025-03-25 01:53:48 --> Language Class Initialized
INFO - 2025-03-25 01:53:48 --> Config Class Initialized
INFO - 2025-03-25 01:53:48 --> Loader Class Initialized
INFO - 2025-03-25 01:53:48 --> Helper loaded: url_helper
INFO - 2025-03-25 01:53:48 --> Helper loaded: file_helper
INFO - 2025-03-25 01:53:48 --> Helper loaded: html_helper
INFO - 2025-03-25 01:53:48 --> Helper loaded: form_helper
INFO - 2025-03-25 01:53:48 --> Helper loaded: text_helper
INFO - 2025-03-25 01:53:48 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:53:48 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:53:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:53:48 --> Database Driver Class Initialized
INFO - 2025-03-25 01:53:48 --> Email Class Initialized
INFO - 2025-03-25 01:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:53:48 --> Form Validation Class Initialized
INFO - 2025-03-25 01:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:53:48 --> Pagination Class Initialized
INFO - 2025-03-25 01:53:48 --> Controller Class Initialized
INFO - 2025-03-25 01:53:48 --> Model Class Initialized
DEBUG - 2025-03-25 01:53:48 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:53:48 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 50
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 2
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

        )

)

DEBUG - 2025-03-25 01:53:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:53:48 --> Model Class Initialized
DEBUG - 2025-03-25 01:53:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:53:48 --> Model Class Initialized
DEBUG - 2025-03-25 01:53:48 --> 🧾 Generated invoice_id = 1086
ERROR - 2025-03-25 01:53:48 --> Severity: Warning --> Attempt to read property "customer_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 530
DEBUG - 2025-03-25 01:53:48 --> ✅ Invoice inserted, returned invoice_id: 1086
DEBUG - 2025-03-25 01:53:48 --> ✅ Auto-approving voucher for invoice_id: 1086
DEBUG - 2025-03-25 01:53:48 --> 🎯 Vouchers to approve: [{"referenceNo":"1086","VNo":"CV-40"},{"referenceNo":"1086","VNo":"JV-57"},{"referenceNo":"1086","VNo":"JV-58"}]
DEBUG - 2025-03-25 01:53:48 --> 🟢 Approving voucher: VNo=CV-40, Ref=1086
DEBUG - 2025-03-25 01:53:48 --> 📥 acc_transaction insert: {"vid":"145","fyear":"1","VNo":"CV-40","Vtype":"CV","referenceNo":"1086","VDate":"2025-03-25","COAID":"1020502","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"50.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:53:48"}
DEBUG - 2025-03-25 01:53:48 --> 📥 acc_transaction insert: {"vid":"145","fyear":"1","VNo":"CV-40","Vtype":"CV","referenceNo":"1086","VDate":"2025-03-25","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"50.00","StoreID":0,"IsPosted":1,"RevCodde":"1020502","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:53:48"}
DEBUG - 2025-03-25 01:53:48 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:53:48 --> 🟢 Approving voucher: VNo=JV-57, Ref=1086
DEBUG - 2025-03-25 01:53:48 --> 📥 acc_transaction insert: {"vid":"146","fyear":"1","VNo":"JV-57","Vtype":"JV","referenceNo":"1086","VDate":"2025-03-25","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"40.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:53:48"}
DEBUG - 2025-03-25 01:53:48 --> 📥 acc_transaction insert: {"vid":"146","fyear":"1","VNo":"JV-57","Vtype":"JV","referenceNo":"1086","VDate":"2025-03-25","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"40.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:53:48"}
DEBUG - 2025-03-25 01:53:48 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:53:48 --> 🟢 Approving voucher: VNo=JV-58, Ref=1086
DEBUG - 2025-03-25 01:53:48 --> 📥 acc_transaction insert: {"vid":"147","fyear":"1","VNo":"JV-58","Vtype":"JV","referenceNo":"1086","VDate":"2025-03-25","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:53:48"}
DEBUG - 2025-03-25 01:53:48 --> 📥 acc_transaction insert: {"vid":"147","fyear":"1","VNo":"JV-58","Vtype":"JV","referenceNo":"1086","VDate":"2025-03-25","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:53:48"}
DEBUG - 2025-03-25 01:53:48 --> ✅ Voucher approved: true
INFO - 2025-03-25 01:53:48 --> Final output sent to browser
DEBUG - 2025-03-25 01:53:48 --> Total execution time: 0.0378
INFO - 2025-03-25 01:56:33 --> Config Class Initialized
INFO - 2025-03-25 01:56:33 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:56:33 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:56:33 --> Utf8 Class Initialized
INFO - 2025-03-25 01:56:33 --> URI Class Initialized
INFO - 2025-03-25 01:56:33 --> Router Class Initialized
INFO - 2025-03-25 01:56:33 --> Output Class Initialized
INFO - 2025-03-25 01:56:33 --> Security Class Initialized
DEBUG - 2025-03-25 01:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:56:33 --> Input Class Initialized
INFO - 2025-03-25 01:56:33 --> Language Class Initialized
INFO - 2025-03-25 01:56:33 --> Language Class Initialized
INFO - 2025-03-25 01:56:33 --> Config Class Initialized
INFO - 2025-03-25 01:56:33 --> Loader Class Initialized
INFO - 2025-03-25 01:56:33 --> Helper loaded: url_helper
INFO - 2025-03-25 01:56:33 --> Helper loaded: file_helper
INFO - 2025-03-25 01:56:33 --> Helper loaded: html_helper
INFO - 2025-03-25 01:56:33 --> Helper loaded: form_helper
INFO - 2025-03-25 01:56:33 --> Helper loaded: text_helper
INFO - 2025-03-25 01:56:33 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:56:33 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:56:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:56:33 --> Database Driver Class Initialized
INFO - 2025-03-25 01:56:33 --> Email Class Initialized
INFO - 2025-03-25 01:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:56:33 --> Form Validation Class Initialized
INFO - 2025-03-25 01:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:56:33 --> Pagination Class Initialized
INFO - 2025-03-25 01:56:33 --> Controller Class Initialized
INFO - 2025-03-25 01:56:33 --> Model Class Initialized
DEBUG - 2025-03-25 01:56:33 --> ✅ API insert_sale called
DEBUG - 2025-03-25 01:56:33 --> 🧾 Raw request body: Array
(
    [createby] => 35
    [customer_id] => 35
    [paid_amount] => 50
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 2
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

        )

)

DEBUG - 2025-03-25 01:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 01:56:33 --> Model Class Initialized
DEBUG - 2025-03-25 01:56:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 01:56:33 --> Model Class Initialized
DEBUG - 2025-03-25 01:56:33 --> 🧾 Generated invoice_id = 1087
DEBUG - 2025-03-25 01:56:33 --> ✅ Invoice inserted, returned invoice_id: 1087
DEBUG - 2025-03-25 01:56:33 --> ✅ Auto-approving voucher for invoice_id: 1087
DEBUG - 2025-03-25 01:56:33 --> 🎯 Vouchers to approve: [{"referenceNo":"1087","VNo":"CV-41"},{"referenceNo":"1087","VNo":"JV-59"},{"referenceNo":"1087","VNo":"JV-60"}]
DEBUG - 2025-03-25 01:56:33 --> 🟢 Approving voucher: VNo=CV-41, Ref=1087
DEBUG - 2025-03-25 01:56:33 --> 📥 acc_transaction insert: {"vid":"148","fyear":"1","VNo":"CV-41","Vtype":"CV","referenceNo":"1087","VDate":"2025-03-25","COAID":"1020502","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"50.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:56:33"}
DEBUG - 2025-03-25 01:56:33 --> 📥 acc_transaction insert: {"vid":"148","fyear":"1","VNo":"CV-41","Vtype":"CV","referenceNo":"1087","VDate":"2025-03-25","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"50.00","StoreID":0,"IsPosted":1,"RevCodde":"1020502","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:56:33"}
DEBUG - 2025-03-25 01:56:33 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:56:33 --> 🟢 Approving voucher: VNo=JV-59, Ref=1087
DEBUG - 2025-03-25 01:56:33 --> 📥 acc_transaction insert: {"vid":"149","fyear":"1","VNo":"JV-59","Vtype":"JV","referenceNo":"1087","VDate":"2025-03-25","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"40.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:56:33"}
DEBUG - 2025-03-25 01:56:33 --> 📥 acc_transaction insert: {"vid":"149","fyear":"1","VNo":"JV-59","Vtype":"JV","referenceNo":"1087","VDate":"2025-03-25","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"40.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:56:33"}
DEBUG - 2025-03-25 01:56:33 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 01:56:33 --> 🟢 Approving voucher: VNo=JV-60, Ref=1087
DEBUG - 2025-03-25 01:56:33 --> 📥 acc_transaction insert: {"vid":"150","fyear":"1","VNo":"JV-60","Vtype":"JV","referenceNo":"1087","VDate":"2025-03-25","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:56:33"}
DEBUG - 2025-03-25 01:56:33 --> 📥 acc_transaction insert: {"vid":"150","fyear":"1","VNo":"JV-60","Vtype":"JV","referenceNo":"1087","VDate":"2025-03-25","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"35","CreateDate":"2025-03-25 01:56:33"}
DEBUG - 2025-03-25 01:56:33 --> ✅ Voucher approved: true
INFO - 2025-03-25 01:56:33 --> Final output sent to browser
DEBUG - 2025-03-25 01:56:33 --> Total execution time: 0.0454
INFO - 2025-03-25 01:56:47 --> Config Class Initialized
INFO - 2025-03-25 01:56:47 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:56:47 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:56:47 --> Utf8 Class Initialized
INFO - 2025-03-25 01:56:47 --> URI Class Initialized
DEBUG - 2025-03-25 01:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:56:47 --> Router Class Initialized
INFO - 2025-03-25 01:56:47 --> Output Class Initialized
INFO - 2025-03-25 01:56:47 --> Security Class Initialized
DEBUG - 2025-03-25 01:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:56:47 --> Input Class Initialized
INFO - 2025-03-25 01:56:47 --> Language Class Initialized
INFO - 2025-03-25 01:56:47 --> Language Class Initialized
INFO - 2025-03-25 01:56:47 --> Config Class Initialized
INFO - 2025-03-25 01:56:47 --> Loader Class Initialized
INFO - 2025-03-25 01:56:47 --> Helper loaded: url_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: file_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: html_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: form_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: text_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:56:47 --> Database Driver Class Initialized
INFO - 2025-03-25 01:56:47 --> Email Class Initialized
INFO - 2025-03-25 01:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:56:47 --> Form Validation Class Initialized
INFO - 2025-03-25 01:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:56:47 --> Pagination Class Initialized
INFO - 2025-03-25 01:56:47 --> Controller Class Initialized
DEBUG - 2025-03-25 01:56:47 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:56:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
ERROR - 2025-03-25 07:56:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:56:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:56:47 --> Final output sent to browser
DEBUG - 2025-03-25 07:56:47 --> Total execution time: 0.1219
INFO - 2025-03-25 01:56:47 --> Config Class Initialized
INFO - 2025-03-25 01:56:47 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:56:47 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:56:47 --> Utf8 Class Initialized
INFO - 2025-03-25 01:56:47 --> URI Class Initialized
DEBUG - 2025-03-25 01:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:56:47 --> Router Class Initialized
INFO - 2025-03-25 01:56:47 --> Output Class Initialized
INFO - 2025-03-25 01:56:47 --> Security Class Initialized
DEBUG - 2025-03-25 01:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:56:47 --> Input Class Initialized
INFO - 2025-03-25 01:56:47 --> Language Class Initialized
INFO - 2025-03-25 01:56:47 --> Language Class Initialized
INFO - 2025-03-25 01:56:47 --> Config Class Initialized
INFO - 2025-03-25 01:56:47 --> Loader Class Initialized
INFO - 2025-03-25 01:56:47 --> Helper loaded: url_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: file_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: html_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: form_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: text_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:56:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:56:47 --> Database Driver Class Initialized
INFO - 2025-03-25 01:56:47 --> Email Class Initialized
INFO - 2025-03-25 01:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:56:47 --> Form Validation Class Initialized
INFO - 2025-03-25 01:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:56:47 --> Pagination Class Initialized
INFO - 2025-03-25 01:56:47 --> Controller Class Initialized
DEBUG - 2025-03-25 01:56:47 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:56:47 --> Model Class Initialized
INFO - 2025-03-25 07:56:47 --> Final output sent to browser
DEBUG - 2025-03-25 07:56:47 --> Total execution time: 0.0465
INFO - 2025-03-25 01:56:49 --> Config Class Initialized
INFO - 2025-03-25 01:56:49 --> Hooks Class Initialized
DEBUG - 2025-03-25 01:56:49 --> UTF-8 Support Enabled
INFO - 2025-03-25 01:56:49 --> Utf8 Class Initialized
INFO - 2025-03-25 01:56:49 --> URI Class Initialized
DEBUG - 2025-03-25 01:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 01:56:49 --> Router Class Initialized
INFO - 2025-03-25 01:56:49 --> Output Class Initialized
INFO - 2025-03-25 01:56:49 --> Security Class Initialized
DEBUG - 2025-03-25 01:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 01:56:49 --> Input Class Initialized
INFO - 2025-03-25 01:56:49 --> Language Class Initialized
INFO - 2025-03-25 01:56:49 --> Language Class Initialized
INFO - 2025-03-25 01:56:49 --> Config Class Initialized
INFO - 2025-03-25 01:56:49 --> Loader Class Initialized
INFO - 2025-03-25 01:56:49 --> Helper loaded: url_helper
INFO - 2025-03-25 01:56:49 --> Helper loaded: file_helper
INFO - 2025-03-25 01:56:49 --> Helper loaded: html_helper
INFO - 2025-03-25 01:56:49 --> Helper loaded: form_helper
INFO - 2025-03-25 01:56:49 --> Helper loaded: text_helper
INFO - 2025-03-25 01:56:49 --> Helper loaded: lang_helper
INFO - 2025-03-25 01:56:49 --> Helper loaded: directory_helper
INFO - 2025-03-25 01:56:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 01:56:49 --> Database Driver Class Initialized
INFO - 2025-03-25 01:56:49 --> Email Class Initialized
INFO - 2025-03-25 01:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 01:56:49 --> Form Validation Class Initialized
INFO - 2025-03-25 01:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 01:56:49 --> Pagination Class Initialized
INFO - 2025-03-25 01:56:49 --> Controller Class Initialized
DEBUG - 2025-03-25 01:56:49 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 07:56:49 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 07:56:49 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 07:56:49 --> Model Class Initialized
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 07:56:49 --> Model Class Initialized
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 156
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 158
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 162
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 163
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 164
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 165
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 166
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 167
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 168
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 169
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 170
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 171
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 172
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 174
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 175
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 176
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 177
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 180
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 181
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 182
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 183
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 186
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 07:56:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 07:56:49 --> Model Class Initialized
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 166
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
ERROR - 2025-03-25 07:56:49 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 07:56:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 07:56:49 --> Final output sent to browser
DEBUG - 2025-03-25 07:56:49 --> Total execution time: 0.1557
INFO - 2025-03-25 06:04:13 --> Config Class Initialized
INFO - 2025-03-25 06:04:13 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:13 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:13 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:13 --> URI Class Initialized
INFO - 2025-03-25 06:04:13 --> Router Class Initialized
INFO - 2025-03-25 06:04:13 --> Output Class Initialized
INFO - 2025-03-25 06:04:13 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:13 --> Input Class Initialized
INFO - 2025-03-25 06:04:13 --> Language Class Initialized
INFO - 2025-03-25 06:04:13 --> Language Class Initialized
INFO - 2025-03-25 06:04:13 --> Config Class Initialized
INFO - 2025-03-25 06:04:13 --> Loader Class Initialized
INFO - 2025-03-25 06:04:13 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:13 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:13 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:13 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:13 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:13 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:13 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:13 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:13 --> Email Class Initialized
INFO - 2025-03-25 06:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:13 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:13 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:13 --> Controller Class Initialized
INFO - 2025-03-25 06:04:13 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:13 --> ✅ API insert_sale called
DEBUG - 2025-03-25 06:04:13 --> 🧾 Raw request body: Array
(
    [createby] => 30
    [customer_id] => 30
    [paid_amount] => 50
    [due_amount] => 0
    [total_discount] => 0
    [total_tax] => 0
    [invoice_date] => 2025-03-25
    [inva_details] => API invoice from merchant portal
    [payment_type] => 1020502
    [status] => 2
    [detailsinfo] => Array
        (
            [0] => Array
                (
                    [product_id] => 123456
                    [product_quantity] => 2
                    [product_rate] => 25
                    [serial_no] => ABC1234
                )

        )

)

DEBUG - 2025-03-25 06:04:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 06:04:13 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:04:13 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:13 --> 🧾 Generated invoice_id = 1088
DEBUG - 2025-03-25 06:04:13 --> ✅ Invoice inserted, returned invoice_id: 1088
DEBUG - 2025-03-25 06:04:13 --> ✅ Auto-approving voucher for invoice_id: 1088
DEBUG - 2025-03-25 06:04:13 --> 🎯 Vouchers to approve: [{"referenceNo":"1088","VNo":"CV-42"},{"referenceNo":"1088","VNo":"JV-61"},{"referenceNo":"1088","VNo":"JV-62"}]
DEBUG - 2025-03-25 06:04:13 --> 🟢 Approving voucher: VNo=CV-42, Ref=1088
DEBUG - 2025-03-25 06:04:13 --> 📥 acc_transaction insert: {"vid":"151","fyear":"1","VNo":"CV-42","Vtype":"CV","referenceNo":"1088","VDate":"2025-03-25","COAID":"1020502","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"50.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"30","CreateDate":"2025-03-25 06:04:13"}
DEBUG - 2025-03-25 06:04:13 --> 📥 acc_transaction insert: {"vid":"151","fyear":"1","VNo":"CV-42","Vtype":"CV","referenceNo":"1088","VDate":"2025-03-25","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"50.00","StoreID":0,"IsPosted":1,"RevCodde":"1020502","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"30","CreateDate":"2025-03-25 06:04:13"}
DEBUG - 2025-03-25 06:04:13 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 06:04:13 --> 🟢 Approving voucher: VNo=JV-61, Ref=1088
DEBUG - 2025-03-25 06:04:13 --> 📥 acc_transaction insert: {"vid":"152","fyear":"1","VNo":"JV-61","Vtype":"JV","referenceNo":"1088","VDate":"2025-03-25","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"40.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"30","CreateDate":"2025-03-25 06:04:13"}
DEBUG - 2025-03-25 06:04:13 --> 📥 acc_transaction insert: {"vid":"152","fyear":"1","VNo":"JV-61","Vtype":"JV","referenceNo":"1088","VDate":"2025-03-25","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"40.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"30","CreateDate":"2025-03-25 06:04:13"}
DEBUG - 2025-03-25 06:04:13 --> ✅ Voucher approved: true
DEBUG - 2025-03-25 06:04:13 --> 🟢 Approving voucher: VNo=JV-62, Ref=1088
DEBUG - 2025-03-25 06:04:13 --> 📥 acc_transaction insert: {"vid":"153","fyear":"1","VNo":"JV-62","Vtype":"JV","referenceNo":"1088","VDate":"2025-03-25","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"30","CreateDate":"2025-03-25 06:04:13"}
DEBUG - 2025-03-25 06:04:13 --> 📥 acc_transaction insert: {"vid":"153","fyear":"1","VNo":"JV-62","Vtype":"JV","referenceNo":"1088","VDate":"2025-03-25","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"30","CreateDate":"2025-03-25 06:04:13"}
DEBUG - 2025-03-25 06:04:13 --> ✅ Voucher approved: true
INFO - 2025-03-25 06:04:13 --> Final output sent to browser
DEBUG - 2025-03-25 06:04:13 --> Total execution time: 0.0735
INFO - 2025-03-25 06:04:26 --> Config Class Initialized
INFO - 2025-03-25 06:04:26 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:26 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:26 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:26 --> URI Class Initialized
DEBUG - 2025-03-25 06:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 06:04:26 --> Router Class Initialized
INFO - 2025-03-25 06:04:26 --> Output Class Initialized
INFO - 2025-03-25 06:04:26 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:26 --> Input Class Initialized
INFO - 2025-03-25 06:04:26 --> Language Class Initialized
INFO - 2025-03-25 06:04:26 --> Language Class Initialized
INFO - 2025-03-25 06:04:26 --> Config Class Initialized
INFO - 2025-03-25 06:04:26 --> Loader Class Initialized
INFO - 2025-03-25 06:04:26 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:26 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:26 --> Email Class Initialized
INFO - 2025-03-25 06:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:26 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:26 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:26 --> Controller Class Initialized
DEBUG - 2025-03-25 06:04:26 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 12:04:26 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 12:04:26 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 12:04:26 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 12:04:26 --> Model Class Initialized
INFO - 2025-03-25 06:04:26 --> Config Class Initialized
INFO - 2025-03-25 06:04:26 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:26 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:26 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:26 --> URI Class Initialized
DEBUG - 2025-03-25 06:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-25 06:04:26 --> Router Class Initialized
INFO - 2025-03-25 06:04:26 --> Output Class Initialized
INFO - 2025-03-25 06:04:26 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:26 --> Input Class Initialized
INFO - 2025-03-25 06:04:26 --> Language Class Initialized
INFO - 2025-03-25 06:04:26 --> Language Class Initialized
INFO - 2025-03-25 06:04:26 --> Config Class Initialized
INFO - 2025-03-25 06:04:26 --> Loader Class Initialized
INFO - 2025-03-25 06:04:26 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:26 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:26 --> Email Class Initialized
INFO - 2025-03-25 06:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:26 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:26 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:26 --> Controller Class Initialized
DEBUG - 2025-03-25 06:04:26 --> Auth MX_Controller Initialized
INFO - 2025-03-25 06:04:26 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-25 06:04:26 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:04:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:04:26 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-25 06:04:26 --> Final output sent to browser
DEBUG - 2025-03-25 06:04:26 --> Total execution time: 0.0202
INFO - 2025-03-25 06:04:35 --> Config Class Initialized
INFO - 2025-03-25 06:04:35 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:35 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:35 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:35 --> URI Class Initialized
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-25 06:04:35 --> Router Class Initialized
INFO - 2025-03-25 06:04:35 --> Output Class Initialized
INFO - 2025-03-25 06:04:35 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:35 --> Input Class Initialized
INFO - 2025-03-25 06:04:35 --> Language Class Initialized
INFO - 2025-03-25 06:04:35 --> Language Class Initialized
INFO - 2025-03-25 06:04:35 --> Config Class Initialized
INFO - 2025-03-25 06:04:35 --> Loader Class Initialized
INFO - 2025-03-25 06:04:35 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:35 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:35 --> Email Class Initialized
INFO - 2025-03-25 06:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:35 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:35 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:35 --> Controller Class Initialized
DEBUG - 2025-03-25 06:04:35 --> Auth MX_Controller Initialized
INFO - 2025-03-25 06:04:35 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-25 06:04:35 --> Model Class Initialized
INFO - 2025-03-25 06:04:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-25 06:04:35 --> Config Class Initialized
INFO - 2025-03-25 06:04:35 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:35 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:35 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:35 --> URI Class Initialized
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-25 06:04:35 --> Router Class Initialized
INFO - 2025-03-25 06:04:35 --> Output Class Initialized
INFO - 2025-03-25 06:04:35 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:35 --> Input Class Initialized
INFO - 2025-03-25 06:04:35 --> Language Class Initialized
INFO - 2025-03-25 06:04:35 --> Language Class Initialized
INFO - 2025-03-25 06:04:35 --> Config Class Initialized
INFO - 2025-03-25 06:04:35 --> Loader Class Initialized
INFO - 2025-03-25 06:04:35 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:35 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:35 --> Email Class Initialized
INFO - 2025-03-25 06:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:35 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:35 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:35 --> Controller Class Initialized
DEBUG - 2025-03-25 06:04:35 --> Home MX_Controller Initialized
INFO - 2025-03-25 06:04:35 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-25 06:04:35 --> Model Class Initialized
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:04:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:04:35 --> Model Class Initialized
ERROR - 2025-03-25 06:04:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 06:04:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 06:04:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 06:04:35 --> Final output sent to browser
DEBUG - 2025-03-25 06:04:35 --> Total execution time: 0.6187
INFO - 2025-03-25 06:04:45 --> Config Class Initialized
INFO - 2025-03-25 06:04:45 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:45 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:45 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:45 --> URI Class Initialized
DEBUG - 2025-03-25 06:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 06:04:45 --> Router Class Initialized
INFO - 2025-03-25 06:04:45 --> Output Class Initialized
INFO - 2025-03-25 06:04:45 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:45 --> Input Class Initialized
INFO - 2025-03-25 06:04:45 --> Language Class Initialized
INFO - 2025-03-25 06:04:45 --> Language Class Initialized
INFO - 2025-03-25 06:04:45 --> Config Class Initialized
INFO - 2025-03-25 06:04:45 --> Loader Class Initialized
INFO - 2025-03-25 06:04:45 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:45 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:45 --> Email Class Initialized
INFO - 2025-03-25 06:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:45 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:45 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:45 --> Controller Class Initialized
DEBUG - 2025-03-25 06:04:45 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 12:04:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
ERROR - 2025-03-25 12:04:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 12:04:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 12:04:45 --> Final output sent to browser
DEBUG - 2025-03-25 12:04:45 --> Total execution time: 0.1712
INFO - 2025-03-25 06:04:45 --> Config Class Initialized
INFO - 2025-03-25 06:04:45 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:45 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:45 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:45 --> URI Class Initialized
DEBUG - 2025-03-25 06:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 06:04:45 --> Router Class Initialized
INFO - 2025-03-25 06:04:45 --> Output Class Initialized
INFO - 2025-03-25 06:04:45 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:45 --> Input Class Initialized
INFO - 2025-03-25 06:04:45 --> Language Class Initialized
INFO - 2025-03-25 06:04:45 --> Language Class Initialized
INFO - 2025-03-25 06:04:45 --> Config Class Initialized
INFO - 2025-03-25 06:04:45 --> Loader Class Initialized
INFO - 2025-03-25 06:04:45 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:45 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:45 --> Email Class Initialized
INFO - 2025-03-25 06:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:45 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:45 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:45 --> Controller Class Initialized
DEBUG - 2025-03-25 06:04:45 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 12:04:45 --> Model Class Initialized
INFO - 2025-03-25 12:04:45 --> Final output sent to browser
DEBUG - 2025-03-25 12:04:45 --> Total execution time: 0.0516
INFO - 2025-03-25 06:04:50 --> Config Class Initialized
INFO - 2025-03-25 06:04:50 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:04:50 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:04:50 --> Utf8 Class Initialized
INFO - 2025-03-25 06:04:50 --> URI Class Initialized
DEBUG - 2025-03-25 06:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-25 06:04:50 --> Router Class Initialized
INFO - 2025-03-25 06:04:50 --> Output Class Initialized
INFO - 2025-03-25 06:04:50 --> Security Class Initialized
DEBUG - 2025-03-25 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:04:50 --> Input Class Initialized
INFO - 2025-03-25 06:04:50 --> Language Class Initialized
INFO - 2025-03-25 06:04:50 --> Language Class Initialized
INFO - 2025-03-25 06:04:50 --> Config Class Initialized
INFO - 2025-03-25 06:04:50 --> Loader Class Initialized
INFO - 2025-03-25 06:04:50 --> Helper loaded: url_helper
INFO - 2025-03-25 06:04:50 --> Helper loaded: file_helper
INFO - 2025-03-25 06:04:50 --> Helper loaded: html_helper
INFO - 2025-03-25 06:04:50 --> Helper loaded: form_helper
INFO - 2025-03-25 06:04:50 --> Helper loaded: text_helper
INFO - 2025-03-25 06:04:50 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:04:50 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:04:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:04:50 --> Database Driver Class Initialized
INFO - 2025-03-25 06:04:50 --> Email Class Initialized
INFO - 2025-03-25 06:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:04:50 --> Form Validation Class Initialized
INFO - 2025-03-25 06:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:04:50 --> Pagination Class Initialized
INFO - 2025-03-25 06:04:50 --> Controller Class Initialized
DEBUG - 2025-03-25 06:04:50 --> Invoice MX_Controller Initialized
INFO - 2025-03-25 12:04:50 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-25 12:04:50 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 12:04:50 --> Model Class Initialized
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 12:04:50 --> Model Class Initialized
ERROR - 2025-03-25 12:04:50 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
ERROR - 2025-03-25 12:04:50 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 187
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 12:04:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 12:04:50 --> Model Class Initialized
ERROR - 2025-03-25 12:04:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 12:04:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 12:04:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 12:04:50 --> Final output sent to browser
DEBUG - 2025-03-25 12:04:50 --> Total execution time: 0.1587
INFO - 2025-03-25 06:05:18 --> Config Class Initialized
INFO - 2025-03-25 06:05:18 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:05:18 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:05:18 --> Utf8 Class Initialized
INFO - 2025-03-25 06:05:18 --> URI Class Initialized
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-25 06:05:18 --> Router Class Initialized
INFO - 2025-03-25 06:05:18 --> Output Class Initialized
INFO - 2025-03-25 06:05:18 --> Security Class Initialized
DEBUG - 2025-03-25 06:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:05:18 --> Input Class Initialized
INFO - 2025-03-25 06:05:18 --> Language Class Initialized
INFO - 2025-03-25 06:05:18 --> Language Class Initialized
INFO - 2025-03-25 06:05:18 --> Config Class Initialized
INFO - 2025-03-25 06:05:18 --> Loader Class Initialized
INFO - 2025-03-25 06:05:18 --> Helper loaded: url_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: file_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: html_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: form_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: text_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:05:18 --> Database Driver Class Initialized
INFO - 2025-03-25 06:05:18 --> Email Class Initialized
INFO - 2025-03-25 06:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:05:18 --> Form Validation Class Initialized
INFO - 2025-03-25 06:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:05:18 --> Pagination Class Initialized
INFO - 2025-03-25 06:05:18 --> Controller Class Initialized
DEBUG - 2025-03-25 06:05:18 --> Accounts MX_Controller Initialized
INFO - 2025-03-25 06:05:18 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:05:18 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:05:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:05:18 --> Model Class Initialized
ERROR - 2025-03-25 06:05:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 06:05:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/journal_voucher_list.php
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 06:05:18 --> Final output sent to browser
DEBUG - 2025-03-25 06:05:18 --> Total execution time: 0.1063
INFO - 2025-03-25 06:05:18 --> Config Class Initialized
INFO - 2025-03-25 06:05:18 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:05:18 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:05:18 --> Utf8 Class Initialized
INFO - 2025-03-25 06:05:18 --> URI Class Initialized
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-25 06:05:18 --> Router Class Initialized
INFO - 2025-03-25 06:05:18 --> Output Class Initialized
INFO - 2025-03-25 06:05:18 --> Security Class Initialized
DEBUG - 2025-03-25 06:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:05:18 --> Input Class Initialized
INFO - 2025-03-25 06:05:18 --> Language Class Initialized
INFO - 2025-03-25 06:05:18 --> Language Class Initialized
INFO - 2025-03-25 06:05:18 --> Config Class Initialized
INFO - 2025-03-25 06:05:18 --> Loader Class Initialized
INFO - 2025-03-25 06:05:18 --> Helper loaded: url_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: file_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: html_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: form_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: text_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:05:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:05:18 --> Database Driver Class Initialized
INFO - 2025-03-25 06:05:18 --> Email Class Initialized
INFO - 2025-03-25 06:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:05:18 --> Form Validation Class Initialized
INFO - 2025-03-25 06:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:05:18 --> Pagination Class Initialized
INFO - 2025-03-25 06:05:18 --> Controller Class Initialized
DEBUG - 2025-03-25 06:05:18 --> Accounts MX_Controller Initialized
INFO - 2025-03-25 06:05:18 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:05:18 --> Model Class Initialized
INFO - 2025-03-25 06:05:18 --> Final output sent to browser
DEBUG - 2025-03-25 06:05:18 --> Total execution time: 0.0150
INFO - 2025-03-25 06:05:35 --> Config Class Initialized
INFO - 2025-03-25 06:05:35 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:05:35 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:05:35 --> Utf8 Class Initialized
INFO - 2025-03-25 06:05:35 --> URI Class Initialized
DEBUG - 2025-03-25 06:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-25 06:05:35 --> Router Class Initialized
INFO - 2025-03-25 06:05:35 --> Output Class Initialized
INFO - 2025-03-25 06:05:35 --> Security Class Initialized
DEBUG - 2025-03-25 06:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:05:35 --> Input Class Initialized
INFO - 2025-03-25 06:05:35 --> Language Class Initialized
INFO - 2025-03-25 06:05:35 --> Language Class Initialized
INFO - 2025-03-25 06:05:35 --> Config Class Initialized
INFO - 2025-03-25 06:05:35 --> Loader Class Initialized
INFO - 2025-03-25 06:05:35 --> Helper loaded: url_helper
INFO - 2025-03-25 06:05:35 --> Helper loaded: file_helper
INFO - 2025-03-25 06:05:35 --> Helper loaded: html_helper
INFO - 2025-03-25 06:05:35 --> Helper loaded: form_helper
INFO - 2025-03-25 06:05:35 --> Helper loaded: text_helper
INFO - 2025-03-25 06:05:35 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:05:35 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:05:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:05:35 --> Database Driver Class Initialized
INFO - 2025-03-25 06:05:35 --> Email Class Initialized
INFO - 2025-03-25 06:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:05:35 --> Form Validation Class Initialized
INFO - 2025-03-25 06:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:05:35 --> Pagination Class Initialized
INFO - 2025-03-25 06:05:35 --> Controller Class Initialized
DEBUG - 2025-03-25 06:05:35 --> Accounts MX_Controller Initialized
INFO - 2025-03-25 06:05:35 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:05:35 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/jv_view_details.php
INFO - 2025-03-25 06:05:35 --> Final output sent to browser
DEBUG - 2025-03-25 06:05:35 --> Total execution time: 0.0235
INFO - 2025-03-25 06:05:50 --> Config Class Initialized
INFO - 2025-03-25 06:05:50 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:05:50 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:05:50 --> Utf8 Class Initialized
INFO - 2025-03-25 06:05:50 --> URI Class Initialized
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-25 06:05:50 --> Router Class Initialized
INFO - 2025-03-25 06:05:50 --> Output Class Initialized
INFO - 2025-03-25 06:05:50 --> Security Class Initialized
DEBUG - 2025-03-25 06:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:05:50 --> Input Class Initialized
INFO - 2025-03-25 06:05:50 --> Language Class Initialized
INFO - 2025-03-25 06:05:50 --> Language Class Initialized
INFO - 2025-03-25 06:05:50 --> Config Class Initialized
INFO - 2025-03-25 06:05:50 --> Loader Class Initialized
INFO - 2025-03-25 06:05:50 --> Helper loaded: url_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: file_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: html_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: form_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: text_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:05:50 --> Database Driver Class Initialized
INFO - 2025-03-25 06:05:50 --> Email Class Initialized
INFO - 2025-03-25 06:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:05:50 --> Form Validation Class Initialized
INFO - 2025-03-25 06:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:05:50 --> Pagination Class Initialized
INFO - 2025-03-25 06:05:50 --> Controller Class Initialized
DEBUG - 2025-03-25 06:05:50 --> Accounts MX_Controller Initialized
INFO - 2025-03-25 06:05:50 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:05:50 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:05:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:05:50 --> Model Class Initialized
ERROR - 2025-03-25 06:05:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 06:05:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/credit_voucher_list.php
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 06:05:50 --> Final output sent to browser
DEBUG - 2025-03-25 06:05:50 --> Total execution time: 0.1372
INFO - 2025-03-25 06:05:50 --> Config Class Initialized
INFO - 2025-03-25 06:05:50 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:05:50 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:05:50 --> Utf8 Class Initialized
INFO - 2025-03-25 06:05:50 --> URI Class Initialized
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-25 06:05:50 --> Router Class Initialized
INFO - 2025-03-25 06:05:50 --> Output Class Initialized
INFO - 2025-03-25 06:05:50 --> Security Class Initialized
DEBUG - 2025-03-25 06:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:05:50 --> Input Class Initialized
INFO - 2025-03-25 06:05:50 --> Language Class Initialized
INFO - 2025-03-25 06:05:50 --> Language Class Initialized
INFO - 2025-03-25 06:05:50 --> Config Class Initialized
INFO - 2025-03-25 06:05:50 --> Loader Class Initialized
INFO - 2025-03-25 06:05:50 --> Helper loaded: url_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: file_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: html_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: form_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: text_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:05:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:05:50 --> Database Driver Class Initialized
INFO - 2025-03-25 06:05:50 --> Email Class Initialized
INFO - 2025-03-25 06:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:05:50 --> Form Validation Class Initialized
INFO - 2025-03-25 06:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:05:50 --> Pagination Class Initialized
INFO - 2025-03-25 06:05:50 --> Controller Class Initialized
DEBUG - 2025-03-25 06:05:50 --> Accounts MX_Controller Initialized
INFO - 2025-03-25 06:05:50 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:05:50 --> Model Class Initialized
INFO - 2025-03-25 06:05:50 --> Final output sent to browser
DEBUG - 2025-03-25 06:05:50 --> Total execution time: 0.0119
INFO - 2025-03-25 06:05:57 --> Config Class Initialized
INFO - 2025-03-25 06:05:57 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:05:57 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:05:57 --> Utf8 Class Initialized
INFO - 2025-03-25 06:05:57 --> URI Class Initialized
DEBUG - 2025-03-25 06:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-25 06:05:57 --> Router Class Initialized
INFO - 2025-03-25 06:05:57 --> Output Class Initialized
INFO - 2025-03-25 06:05:57 --> Security Class Initialized
DEBUG - 2025-03-25 06:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:05:57 --> Input Class Initialized
INFO - 2025-03-25 06:05:57 --> Language Class Initialized
INFO - 2025-03-25 06:05:57 --> Language Class Initialized
INFO - 2025-03-25 06:05:57 --> Config Class Initialized
INFO - 2025-03-25 06:05:57 --> Loader Class Initialized
INFO - 2025-03-25 06:05:57 --> Helper loaded: url_helper
INFO - 2025-03-25 06:05:57 --> Helper loaded: file_helper
INFO - 2025-03-25 06:05:57 --> Helper loaded: html_helper
INFO - 2025-03-25 06:05:57 --> Helper loaded: form_helper
INFO - 2025-03-25 06:05:57 --> Helper loaded: text_helper
INFO - 2025-03-25 06:05:57 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:05:57 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:05:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:05:57 --> Database Driver Class Initialized
INFO - 2025-03-25 06:05:57 --> Email Class Initialized
INFO - 2025-03-25 06:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:05:57 --> Form Validation Class Initialized
INFO - 2025-03-25 06:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:05:57 --> Pagination Class Initialized
INFO - 2025-03-25 06:05:57 --> Controller Class Initialized
DEBUG - 2025-03-25 06:05:57 --> Accounts MX_Controller Initialized
INFO - 2025-03-25 06:05:57 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-25 06:05:57 --> Model Class Initialized
DEBUG - 2025-03-25 06:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/cv_view_details.php
INFO - 2025-03-25 06:05:57 --> Final output sent to browser
DEBUG - 2025-03-25 06:05:57 --> Total execution time: 0.0253
INFO - 2025-03-25 06:06:13 --> Config Class Initialized
INFO - 2025-03-25 06:06:13 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:06:13 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:06:13 --> Utf8 Class Initialized
INFO - 2025-03-25 06:06:13 --> URI Class Initialized
DEBUG - 2025-03-25 06:06:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-25 06:06:13 --> Router Class Initialized
INFO - 2025-03-25 06:06:13 --> Output Class Initialized
INFO - 2025-03-25 06:06:13 --> Security Class Initialized
DEBUG - 2025-03-25 06:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:06:13 --> Input Class Initialized
INFO - 2025-03-25 06:06:13 --> Language Class Initialized
INFO - 2025-03-25 06:06:13 --> Language Class Initialized
INFO - 2025-03-25 06:06:13 --> Config Class Initialized
INFO - 2025-03-25 06:06:13 --> Loader Class Initialized
INFO - 2025-03-25 06:06:13 --> Helper loaded: url_helper
INFO - 2025-03-25 06:06:13 --> Helper loaded: file_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: html_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: form_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: text_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:06:14 --> Database Driver Class Initialized
INFO - 2025-03-25 06:06:14 --> Email Class Initialized
INFO - 2025-03-25 06:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:06:14 --> Form Validation Class Initialized
INFO - 2025-03-25 06:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:06:14 --> Pagination Class Initialized
INFO - 2025-03-25 06:06:14 --> Controller Class Initialized
DEBUG - 2025-03-25 06:06:14 --> Product MX_Controller Initialized
INFO - 2025-03-25 06:06:14 --> Model Class Initialized
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-25 06:06:14 --> Model Class Initialized
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-25 06:06:14 --> Model Class Initialized
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 06:06:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 06:06:14 --> Model Class Initialized
ERROR - 2025-03-25 06:06:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 06:06:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 06:06:14 --> Final output sent to browser
DEBUG - 2025-03-25 06:06:14 --> Total execution time: 0.0989
INFO - 2025-03-25 06:06:14 --> Config Class Initialized
INFO - 2025-03-25 06:06:14 --> Hooks Class Initialized
DEBUG - 2025-03-25 06:06:14 --> UTF-8 Support Enabled
INFO - 2025-03-25 06:06:14 --> Utf8 Class Initialized
INFO - 2025-03-25 06:06:14 --> URI Class Initialized
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-25 06:06:14 --> Router Class Initialized
INFO - 2025-03-25 06:06:14 --> Output Class Initialized
INFO - 2025-03-25 06:06:14 --> Security Class Initialized
DEBUG - 2025-03-25 06:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 06:06:14 --> Input Class Initialized
INFO - 2025-03-25 06:06:14 --> Language Class Initialized
INFO - 2025-03-25 06:06:14 --> Language Class Initialized
INFO - 2025-03-25 06:06:14 --> Config Class Initialized
INFO - 2025-03-25 06:06:14 --> Loader Class Initialized
INFO - 2025-03-25 06:06:14 --> Helper loaded: url_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: file_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: html_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: form_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: text_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: lang_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: directory_helper
INFO - 2025-03-25 06:06:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 06:06:14 --> Database Driver Class Initialized
INFO - 2025-03-25 06:06:14 --> Email Class Initialized
INFO - 2025-03-25 06:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 06:06:14 --> Form Validation Class Initialized
INFO - 2025-03-25 06:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 06:06:14 --> Pagination Class Initialized
INFO - 2025-03-25 06:06:14 --> Controller Class Initialized
DEBUG - 2025-03-25 06:06:14 --> Product MX_Controller Initialized
INFO - 2025-03-25 06:06:14 --> Model Class Initialized
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-25 06:06:14 --> Model Class Initialized
DEBUG - 2025-03-25 06:06:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-25 06:06:14 --> Model Class Initialized
ERROR - 2025-03-25 06:06:14 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-25 06:06:14 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-25 06:06:14 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-25 06:06:14 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-25 06:06:14 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-25 06:06:14 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-25 06:06:14 --> Final output sent to browser
DEBUG - 2025-03-25 06:06:14 --> Total execution time: 0.0257
INFO - 2025-03-25 11:03:21 --> Config Class Initialized
INFO - 2025-03-25 11:03:21 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:03:21 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:03:21 --> Utf8 Class Initialized
INFO - 2025-03-25 11:03:21 --> URI Class Initialized
INFO - 2025-03-25 11:03:21 --> Router Class Initialized
INFO - 2025-03-25 11:03:21 --> Output Class Initialized
INFO - 2025-03-25 11:03:21 --> Security Class Initialized
DEBUG - 2025-03-25 11:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:03:21 --> Input Class Initialized
INFO - 2025-03-25 11:03:21 --> Language Class Initialized
INFO - 2025-03-25 11:03:21 --> Language Class Initialized
INFO - 2025-03-25 11:03:21 --> Config Class Initialized
INFO - 2025-03-25 11:03:21 --> Loader Class Initialized
INFO - 2025-03-25 11:03:21 --> Helper loaded: url_helper
INFO - 2025-03-25 11:03:21 --> Helper loaded: file_helper
INFO - 2025-03-25 11:03:21 --> Helper loaded: html_helper
INFO - 2025-03-25 11:03:21 --> Helper loaded: form_helper
INFO - 2025-03-25 11:03:21 --> Helper loaded: text_helper
INFO - 2025-03-25 11:03:21 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:03:21 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:03:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:03:21 --> Database Driver Class Initialized
INFO - 2025-03-25 11:03:21 --> Email Class Initialized
INFO - 2025-03-25 11:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:03:21 --> Form Validation Class Initialized
INFO - 2025-03-25 11:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:03:21 --> Pagination Class Initialized
INFO - 2025-03-25 11:03:21 --> Controller Class Initialized
INFO - 2025-03-25 11:03:21 --> Model Class Initialized
INFO - 2025-03-25 11:03:21 --> Final output sent to browser
DEBUG - 2025-03-25 11:03:21 --> Total execution time: 0.0616
INFO - 2025-03-25 11:03:31 --> Config Class Initialized
INFO - 2025-03-25 11:03:31 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:03:31 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:03:31 --> Utf8 Class Initialized
INFO - 2025-03-25 11:03:31 --> URI Class Initialized
DEBUG - 2025-03-25 11:03:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-25 11:03:31 --> Router Class Initialized
INFO - 2025-03-25 11:03:31 --> Output Class Initialized
INFO - 2025-03-25 11:03:31 --> Security Class Initialized
DEBUG - 2025-03-25 11:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:03:31 --> Input Class Initialized
INFO - 2025-03-25 11:03:31 --> Language Class Initialized
INFO - 2025-03-25 11:03:31 --> Language Class Initialized
INFO - 2025-03-25 11:03:31 --> Config Class Initialized
INFO - 2025-03-25 11:03:31 --> Loader Class Initialized
INFO - 2025-03-25 11:03:31 --> Helper loaded: url_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: file_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: html_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: form_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: text_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:03:31 --> Database Driver Class Initialized
INFO - 2025-03-25 11:03:31 --> Email Class Initialized
INFO - 2025-03-25 11:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:03:31 --> Form Validation Class Initialized
INFO - 2025-03-25 11:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:03:31 --> Pagination Class Initialized
INFO - 2025-03-25 11:03:31 --> Controller Class Initialized
DEBUG - 2025-03-25 11:03:31 --> Home MX_Controller Initialized
INFO - 2025-03-25 11:03:31 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-25 11:03:31 --> Model Class Initialized
INFO - 2025-03-25 11:03:31 --> Config Class Initialized
INFO - 2025-03-25 11:03:31 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:03:31 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:03:31 --> Utf8 Class Initialized
INFO - 2025-03-25 11:03:31 --> URI Class Initialized
DEBUG - 2025-03-25 11:03:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-25 11:03:31 --> Router Class Initialized
INFO - 2025-03-25 11:03:31 --> Output Class Initialized
INFO - 2025-03-25 11:03:31 --> Security Class Initialized
DEBUG - 2025-03-25 11:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:03:31 --> Input Class Initialized
INFO - 2025-03-25 11:03:31 --> Language Class Initialized
INFO - 2025-03-25 11:03:31 --> Language Class Initialized
INFO - 2025-03-25 11:03:31 --> Config Class Initialized
INFO - 2025-03-25 11:03:31 --> Loader Class Initialized
INFO - 2025-03-25 11:03:31 --> Helper loaded: url_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: file_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: html_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: form_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: text_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:03:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:03:31 --> Database Driver Class Initialized
INFO - 2025-03-25 11:03:31 --> Email Class Initialized
INFO - 2025-03-25 11:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:03:31 --> Form Validation Class Initialized
INFO - 2025-03-25 11:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:03:31 --> Pagination Class Initialized
INFO - 2025-03-25 11:03:31 --> Controller Class Initialized
DEBUG - 2025-03-25 11:03:31 --> Auth MX_Controller Initialized
INFO - 2025-03-25 11:03:31 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-25 11:03:31 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 11:03:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 11:03:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 11:03:31 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-25 11:03:31 --> Final output sent to browser
DEBUG - 2025-03-25 11:03:31 --> Total execution time: 0.0214
INFO - 2025-03-25 11:03:38 --> Config Class Initialized
INFO - 2025-03-25 11:03:38 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:03:38 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:03:38 --> Utf8 Class Initialized
INFO - 2025-03-25 11:03:38 --> URI Class Initialized
DEBUG - 2025-03-25 11:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-25 11:03:38 --> Router Class Initialized
INFO - 2025-03-25 11:03:38 --> Output Class Initialized
INFO - 2025-03-25 11:03:38 --> Security Class Initialized
DEBUG - 2025-03-25 11:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:03:38 --> Input Class Initialized
INFO - 2025-03-25 11:03:38 --> Language Class Initialized
INFO - 2025-03-25 11:03:38 --> Language Class Initialized
INFO - 2025-03-25 11:03:38 --> Config Class Initialized
INFO - 2025-03-25 11:03:38 --> Loader Class Initialized
INFO - 2025-03-25 11:03:38 --> Helper loaded: url_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: file_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: html_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: form_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: text_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:03:38 --> Database Driver Class Initialized
INFO - 2025-03-25 11:03:38 --> Email Class Initialized
INFO - 2025-03-25 11:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:03:38 --> Form Validation Class Initialized
INFO - 2025-03-25 11:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:03:38 --> Pagination Class Initialized
INFO - 2025-03-25 11:03:38 --> Controller Class Initialized
DEBUG - 2025-03-25 11:03:38 --> Auth MX_Controller Initialized
INFO - 2025-03-25 11:03:38 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-25 11:03:38 --> Model Class Initialized
INFO - 2025-03-25 11:03:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-25 11:03:38 --> Config Class Initialized
INFO - 2025-03-25 11:03:38 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:03:38 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:03:38 --> Utf8 Class Initialized
INFO - 2025-03-25 11:03:38 --> URI Class Initialized
DEBUG - 2025-03-25 11:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-25 11:03:38 --> Router Class Initialized
INFO - 2025-03-25 11:03:38 --> Output Class Initialized
INFO - 2025-03-25 11:03:38 --> Security Class Initialized
DEBUG - 2025-03-25 11:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:03:38 --> Input Class Initialized
INFO - 2025-03-25 11:03:38 --> Language Class Initialized
INFO - 2025-03-25 11:03:38 --> Language Class Initialized
INFO - 2025-03-25 11:03:38 --> Config Class Initialized
INFO - 2025-03-25 11:03:38 --> Loader Class Initialized
INFO - 2025-03-25 11:03:38 --> Helper loaded: url_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: file_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: html_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: form_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: text_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:03:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:03:38 --> Database Driver Class Initialized
INFO - 2025-03-25 11:03:38 --> Email Class Initialized
INFO - 2025-03-25 11:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:03:38 --> Form Validation Class Initialized
INFO - 2025-03-25 11:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:03:38 --> Pagination Class Initialized
INFO - 2025-03-25 11:03:38 --> Controller Class Initialized
DEBUG - 2025-03-25 11:03:38 --> Home MX_Controller Initialized
INFO - 2025-03-25 11:03:38 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-25 11:03:38 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 11:03:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 11:03:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 11:03:38 --> Model Class Initialized
ERROR - 2025-03-25 11:03:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 11:03:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 11:03:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 11:03:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 11:03:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 11:03:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 11:03:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-25 11:03:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 11:03:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 11:03:39 --> Final output sent to browser
DEBUG - 2025-03-25 11:03:39 --> Total execution time: 0.7825
INFO - 2025-03-25 11:03:42 --> Config Class Initialized
INFO - 2025-03-25 11:03:42 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:03:42 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:03:42 --> Utf8 Class Initialized
INFO - 2025-03-25 11:03:42 --> URI Class Initialized
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-25 11:03:42 --> Router Class Initialized
INFO - 2025-03-25 11:03:42 --> Output Class Initialized
INFO - 2025-03-25 11:03:42 --> Security Class Initialized
DEBUG - 2025-03-25 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:03:42 --> Input Class Initialized
INFO - 2025-03-25 11:03:42 --> Language Class Initialized
INFO - 2025-03-25 11:03:42 --> Language Class Initialized
INFO - 2025-03-25 11:03:42 --> Config Class Initialized
INFO - 2025-03-25 11:03:42 --> Loader Class Initialized
INFO - 2025-03-25 11:03:42 --> Helper loaded: url_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: file_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: html_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: form_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: text_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:03:42 --> Database Driver Class Initialized
INFO - 2025-03-25 11:03:42 --> Email Class Initialized
INFO - 2025-03-25 11:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:03:42 --> Form Validation Class Initialized
INFO - 2025-03-25 11:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:03:42 --> Pagination Class Initialized
INFO - 2025-03-25 11:03:42 --> Controller Class Initialized
DEBUG - 2025-03-25 11:03:42 --> Customer MX_Controller Initialized
INFO - 2025-03-25 11:03:42 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 11:03:42 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 11:03:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 11:03:42 --> Model Class Initialized
ERROR - 2025-03-25 11:03:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 11:03:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 11:03:42 --> Final output sent to browser
DEBUG - 2025-03-25 11:03:42 --> Total execution time: 0.1173
INFO - 2025-03-25 11:03:42 --> Config Class Initialized
INFO - 2025-03-25 11:03:42 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:03:42 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:03:42 --> Utf8 Class Initialized
INFO - 2025-03-25 11:03:42 --> URI Class Initialized
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-25 11:03:42 --> Router Class Initialized
INFO - 2025-03-25 11:03:42 --> Output Class Initialized
INFO - 2025-03-25 11:03:42 --> Security Class Initialized
DEBUG - 2025-03-25 11:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:03:42 --> Input Class Initialized
INFO - 2025-03-25 11:03:42 --> Language Class Initialized
INFO - 2025-03-25 11:03:42 --> Language Class Initialized
INFO - 2025-03-25 11:03:42 --> Config Class Initialized
INFO - 2025-03-25 11:03:42 --> Loader Class Initialized
INFO - 2025-03-25 11:03:42 --> Helper loaded: url_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: file_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: html_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: form_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: text_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:03:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:03:42 --> Database Driver Class Initialized
INFO - 2025-03-25 11:03:42 --> Email Class Initialized
INFO - 2025-03-25 11:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:03:42 --> Form Validation Class Initialized
INFO - 2025-03-25 11:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:03:42 --> Pagination Class Initialized
INFO - 2025-03-25 11:03:42 --> Controller Class Initialized
DEBUG - 2025-03-25 11:03:42 --> Customer MX_Controller Initialized
INFO - 2025-03-25 11:03:42 --> Model Class Initialized
DEBUG - 2025-03-25 11:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 11:03:42 --> Model Class Initialized
ERROR - 2025-03-25 11:03:42 --> ========= getCustomerList() START =========
ERROR - 2025-03-25 11:03:42 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-25 11:03:42 --> Received customer_id: null
ERROR - 2025-03-25 11:03:42 --> Received customfiled: null
ERROR - 2025-03-25 11:03:42 --> Pagination info: start=0, length=50
ERROR - 2025-03-25 11:03:42 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-25 11:03:42 --> Search value: 
ERROR - 2025-03-25 11:03:42 --> Total unfiltered records: 14
ERROR - 2025-03-25 11:03:42 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-25 11:03:42 --> Records fetched from DB: 14
ERROR - 2025-03-25 11:03:42 --> JSON Response: {"draw":1,"iTotalRecords":14,"iTotalDisplayRecords":14,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-25 11:03:42 --> ========= getCustomerList() END =========
INFO - 2025-03-25 11:05:54 --> Config Class Initialized
INFO - 2025-03-25 11:05:54 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:05:54 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:05:54 --> Utf8 Class Initialized
INFO - 2025-03-25 11:05:54 --> URI Class Initialized
INFO - 2025-03-25 11:05:54 --> Router Class Initialized
INFO - 2025-03-25 11:05:54 --> Output Class Initialized
INFO - 2025-03-25 11:05:54 --> Security Class Initialized
DEBUG - 2025-03-25 11:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:05:54 --> Input Class Initialized
INFO - 2025-03-25 11:05:54 --> Language Class Initialized
INFO - 2025-03-25 11:05:54 --> Language Class Initialized
INFO - 2025-03-25 11:05:54 --> Config Class Initialized
INFO - 2025-03-25 11:05:54 --> Loader Class Initialized
INFO - 2025-03-25 11:05:54 --> Helper loaded: url_helper
INFO - 2025-03-25 11:05:54 --> Helper loaded: file_helper
INFO - 2025-03-25 11:05:54 --> Helper loaded: html_helper
INFO - 2025-03-25 11:05:54 --> Helper loaded: form_helper
INFO - 2025-03-25 11:05:54 --> Helper loaded: text_helper
INFO - 2025-03-25 11:05:54 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:05:54 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:05:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:05:54 --> Database Driver Class Initialized
INFO - 2025-03-25 11:05:54 --> Email Class Initialized
INFO - 2025-03-25 11:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:05:54 --> Form Validation Class Initialized
INFO - 2025-03-25 11:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:05:54 --> Pagination Class Initialized
INFO - 2025-03-25 11:05:54 --> Controller Class Initialized
INFO - 2025-03-25 11:05:54 --> Model Class Initialized
INFO - 2025-03-25 11:05:54 --> Upload Class Initialized
INFO - 2025-03-25 11:05:54 --> Final output sent to browser
DEBUG - 2025-03-25 11:05:54 --> Total execution time: 0.0309
INFO - 2025-03-25 11:06:11 --> Config Class Initialized
INFO - 2025-03-25 11:06:11 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:06:11 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:06:11 --> Utf8 Class Initialized
INFO - 2025-03-25 11:06:11 --> URI Class Initialized
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-25 11:06:11 --> Router Class Initialized
INFO - 2025-03-25 11:06:11 --> Output Class Initialized
INFO - 2025-03-25 11:06:11 --> Security Class Initialized
DEBUG - 2025-03-25 11:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:06:11 --> Input Class Initialized
INFO - 2025-03-25 11:06:11 --> Language Class Initialized
INFO - 2025-03-25 11:06:11 --> Language Class Initialized
INFO - 2025-03-25 11:06:11 --> Config Class Initialized
INFO - 2025-03-25 11:06:11 --> Loader Class Initialized
INFO - 2025-03-25 11:06:11 --> Helper loaded: url_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: file_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: html_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: form_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: text_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:06:11 --> Database Driver Class Initialized
INFO - 2025-03-25 11:06:11 --> Email Class Initialized
INFO - 2025-03-25 11:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:06:11 --> Form Validation Class Initialized
INFO - 2025-03-25 11:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:06:11 --> Pagination Class Initialized
INFO - 2025-03-25 11:06:11 --> Controller Class Initialized
DEBUG - 2025-03-25 11:06:11 --> Customer MX_Controller Initialized
INFO - 2025-03-25 11:06:11 --> Model Class Initialized
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 11:06:11 --> Model Class Initialized
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-25 11:06:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-25 11:06:11 --> Model Class Initialized
ERROR - 2025-03-25 11:06:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-25 11:06:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-25 11:06:11 --> Final output sent to browser
DEBUG - 2025-03-25 11:06:11 --> Total execution time: 0.1178
INFO - 2025-03-25 11:06:11 --> Config Class Initialized
INFO - 2025-03-25 11:06:11 --> Hooks Class Initialized
DEBUG - 2025-03-25 11:06:11 --> UTF-8 Support Enabled
INFO - 2025-03-25 11:06:11 --> Utf8 Class Initialized
INFO - 2025-03-25 11:06:11 --> URI Class Initialized
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-25 11:06:11 --> Router Class Initialized
INFO - 2025-03-25 11:06:11 --> Output Class Initialized
INFO - 2025-03-25 11:06:11 --> Security Class Initialized
DEBUG - 2025-03-25 11:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-25 11:06:11 --> Input Class Initialized
INFO - 2025-03-25 11:06:11 --> Language Class Initialized
INFO - 2025-03-25 11:06:11 --> Language Class Initialized
INFO - 2025-03-25 11:06:11 --> Config Class Initialized
INFO - 2025-03-25 11:06:11 --> Loader Class Initialized
INFO - 2025-03-25 11:06:11 --> Helper loaded: url_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: file_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: html_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: form_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: text_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: lang_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: directory_helper
INFO - 2025-03-25 11:06:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-25 11:06:11 --> Database Driver Class Initialized
INFO - 2025-03-25 11:06:11 --> Email Class Initialized
INFO - 2025-03-25 11:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-25 11:06:11 --> Form Validation Class Initialized
INFO - 2025-03-25 11:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-25 11:06:11 --> Pagination Class Initialized
INFO - 2025-03-25 11:06:11 --> Controller Class Initialized
DEBUG - 2025-03-25 11:06:11 --> Customer MX_Controller Initialized
INFO - 2025-03-25 11:06:11 --> Model Class Initialized
DEBUG - 2025-03-25 11:06:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-25 11:06:11 --> Model Class Initialized
ERROR - 2025-03-25 11:06:11 --> ========= getCustomerList() START =========
ERROR - 2025-03-25 11:06:11 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-25 11:06:11 --> Received customer_id: null
ERROR - 2025-03-25 11:06:11 --> Received customfiled: null
ERROR - 2025-03-25 11:06:11 --> Pagination info: start=0, length=50
ERROR - 2025-03-25 11:06:11 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-25 11:06:11 --> Search value: 
ERROR - 2025-03-25 11:06:11 --> Total unfiltered records: 15
ERROR - 2025-03-25 11:06:11 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-25 11:06:11 --> Records fetched from DB: 15
ERROR - 2025-03-25 11:06:11 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-25 11:06:11 --> ========= getCustomerList() END =========
