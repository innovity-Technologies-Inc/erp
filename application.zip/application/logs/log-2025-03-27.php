<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-27 00:15:22 --> Config Class Initialized
INFO - 2025-03-27 00:15:22 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:22 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:22 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:22 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-27 00:15:22 --> No URI present. Default controller set.
INFO - 2025-03-27 00:15:22 --> Router Class Initialized
INFO - 2025-03-27 00:15:22 --> Output Class Initialized
INFO - 2025-03-27 00:15:22 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:22 --> Input Class Initialized
INFO - 2025-03-27 00:15:22 --> Language Class Initialized
INFO - 2025-03-27 00:15:22 --> Language Class Initialized
INFO - 2025-03-27 00:15:22 --> Config Class Initialized
INFO - 2025-03-27 00:15:22 --> Loader Class Initialized
INFO - 2025-03-27 00:15:22 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:22 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:22 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:22 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:22 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:22 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:22 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:22 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:22 --> Email Class Initialized
INFO - 2025-03-27 00:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:22 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:22 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:22 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:22 --> Auth MX_Controller Initialized
INFO - 2025-03-27 00:15:22 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 00:15:22 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 00:15:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 00:15:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 00:15:22 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 00:15:22 --> Final output sent to browser
DEBUG - 2025-03-27 00:15:22 --> Total execution time: 0.0665
INFO - 2025-03-27 00:15:31 --> Config Class Initialized
INFO - 2025-03-27 00:15:31 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:31 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:31 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:31 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 00:15:31 --> Router Class Initialized
INFO - 2025-03-27 00:15:31 --> Output Class Initialized
INFO - 2025-03-27 00:15:31 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:31 --> Input Class Initialized
INFO - 2025-03-27 00:15:31 --> Language Class Initialized
INFO - 2025-03-27 00:15:31 --> Language Class Initialized
INFO - 2025-03-27 00:15:31 --> Config Class Initialized
INFO - 2025-03-27 00:15:31 --> Loader Class Initialized
INFO - 2025-03-27 00:15:31 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:31 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:31 --> Email Class Initialized
INFO - 2025-03-27 00:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:31 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:31 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:31 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:31 --> Auth MX_Controller Initialized
INFO - 2025-03-27 00:15:31 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 00:15:31 --> Model Class Initialized
INFO - 2025-03-27 00:15:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 00:15:31 --> Config Class Initialized
INFO - 2025-03-27 00:15:31 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:31 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:31 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:31 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 00:15:31 --> Router Class Initialized
INFO - 2025-03-27 00:15:31 --> Output Class Initialized
INFO - 2025-03-27 00:15:31 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:31 --> Input Class Initialized
INFO - 2025-03-27 00:15:31 --> Language Class Initialized
INFO - 2025-03-27 00:15:31 --> Language Class Initialized
INFO - 2025-03-27 00:15:31 --> Config Class Initialized
INFO - 2025-03-27 00:15:31 --> Loader Class Initialized
INFO - 2025-03-27 00:15:31 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:31 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:31 --> Email Class Initialized
INFO - 2025-03-27 00:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:31 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:31 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:31 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:31 --> Home MX_Controller Initialized
INFO - 2025-03-27 00:15:31 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-27 00:15:31 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 00:15:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 00:15:31 --> Model Class Initialized
ERROR - 2025-03-27 00:15:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 00:15:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 00:15:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 00:15:31 --> Final output sent to browser
DEBUG - 2025-03-27 00:15:31 --> Total execution time: 0.5546
INFO - 2025-03-27 00:15:45 --> Config Class Initialized
INFO - 2025-03-27 00:15:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:45 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:45 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 00:15:45 --> Router Class Initialized
INFO - 2025-03-27 00:15:45 --> Output Class Initialized
INFO - 2025-03-27 00:15:45 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:45 --> Input Class Initialized
INFO - 2025-03-27 00:15:45 --> Language Class Initialized
INFO - 2025-03-27 00:15:45 --> Language Class Initialized
INFO - 2025-03-27 00:15:45 --> Config Class Initialized
INFO - 2025-03-27 00:15:45 --> Loader Class Initialized
INFO - 2025-03-27 00:15:45 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:45 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:45 --> Email Class Initialized
INFO - 2025-03-27 00:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:45 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:45 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:45 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 00:15:45 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 00:15:45 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 00:15:45 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 00:15:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 00:15:45 --> Model Class Initialized
ERROR - 2025-03-27 00:15:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 00:15:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 00:15:45 --> Final output sent to browser
DEBUG - 2025-03-27 00:15:45 --> Total execution time: 0.1053
INFO - 2025-03-27 00:15:45 --> Config Class Initialized
INFO - 2025-03-27 00:15:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:45 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:45 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 00:15:45 --> Router Class Initialized
INFO - 2025-03-27 00:15:45 --> Output Class Initialized
INFO - 2025-03-27 00:15:45 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:45 --> Input Class Initialized
INFO - 2025-03-27 00:15:45 --> Language Class Initialized
INFO - 2025-03-27 00:15:45 --> Language Class Initialized
INFO - 2025-03-27 00:15:45 --> Config Class Initialized
INFO - 2025-03-27 00:15:45 --> Loader Class Initialized
INFO - 2025-03-27 00:15:45 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:45 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:45 --> Email Class Initialized
INFO - 2025-03-27 00:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:45 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:45 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:45 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 00:15:45 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 00:15:45 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 00:15:45 --> Model Class Initialized
ERROR - 2025-03-27 00:15:46 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:46 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:46 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:46 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:46 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:46 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 00:15:46 --> Final output sent to browser
DEBUG - 2025-03-27 00:15:46 --> Total execution time: 0.0489
INFO - 2025-03-27 00:15:49 --> Config Class Initialized
INFO - 2025-03-27 00:15:49 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:49 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:49 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:49 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 00:15:49 --> Router Class Initialized
INFO - 2025-03-27 00:15:49 --> Output Class Initialized
INFO - 2025-03-27 00:15:49 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:49 --> Input Class Initialized
INFO - 2025-03-27 00:15:49 --> Language Class Initialized
INFO - 2025-03-27 00:15:49 --> Language Class Initialized
INFO - 2025-03-27 00:15:49 --> Config Class Initialized
INFO - 2025-03-27 00:15:49 --> Loader Class Initialized
INFO - 2025-03-27 00:15:49 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:49 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:49 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:49 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:49 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:49 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:49 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:49 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:49 --> Email Class Initialized
INFO - 2025-03-27 00:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:49 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:49 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:49 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:49 --> Product MX_Controller Initialized
INFO - 2025-03-27 00:15:49 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 00:15:49 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 00:15:49 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 00:15:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 00:15:49 --> Model Class Initialized
ERROR - 2025-03-27 00:15:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 00:15:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 00:15:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 00:15:49 --> Final output sent to browser
DEBUG - 2025-03-27 00:15:49 --> Total execution time: 0.1401
INFO - 2025-03-27 00:15:52 --> Config Class Initialized
INFO - 2025-03-27 00:15:52 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:52 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:52 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:52 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 00:15:52 --> Router Class Initialized
INFO - 2025-03-27 00:15:52 --> Output Class Initialized
INFO - 2025-03-27 00:15:52 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:52 --> Input Class Initialized
INFO - 2025-03-27 00:15:52 --> Language Class Initialized
INFO - 2025-03-27 00:15:52 --> Language Class Initialized
INFO - 2025-03-27 00:15:52 --> Config Class Initialized
INFO - 2025-03-27 00:15:52 --> Loader Class Initialized
INFO - 2025-03-27 00:15:52 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:52 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:52 --> Email Class Initialized
INFO - 2025-03-27 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:52 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:52 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:52 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:52 --> Product MX_Controller Initialized
INFO - 2025-03-27 00:15:52 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 00:15:52 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 00:15:52 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 00:15:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 00:15:52 --> Model Class Initialized
ERROR - 2025-03-27 00:15:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 00:15:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 00:15:52 --> Final output sent to browser
DEBUG - 2025-03-27 00:15:52 --> Total execution time: 0.1293
INFO - 2025-03-27 00:15:52 --> Config Class Initialized
INFO - 2025-03-27 00:15:52 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:15:52 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:15:52 --> Utf8 Class Initialized
INFO - 2025-03-27 00:15:52 --> URI Class Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 00:15:52 --> Router Class Initialized
INFO - 2025-03-27 00:15:52 --> Output Class Initialized
INFO - 2025-03-27 00:15:52 --> Security Class Initialized
DEBUG - 2025-03-27 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:15:52 --> Input Class Initialized
INFO - 2025-03-27 00:15:52 --> Language Class Initialized
INFO - 2025-03-27 00:15:52 --> Language Class Initialized
INFO - 2025-03-27 00:15:52 --> Config Class Initialized
INFO - 2025-03-27 00:15:52 --> Loader Class Initialized
INFO - 2025-03-27 00:15:52 --> Helper loaded: url_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: file_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: html_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: form_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: text_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:15:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:15:52 --> Database Driver Class Initialized
INFO - 2025-03-27 00:15:52 --> Email Class Initialized
INFO - 2025-03-27 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:15:52 --> Form Validation Class Initialized
INFO - 2025-03-27 00:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:15:52 --> Pagination Class Initialized
INFO - 2025-03-27 00:15:52 --> Controller Class Initialized
DEBUG - 2025-03-27 00:15:52 --> Product MX_Controller Initialized
INFO - 2025-03-27 00:15:52 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 00:15:52 --> Model Class Initialized
DEBUG - 2025-03-27 00:15:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 00:15:52 --> Model Class Initialized
ERROR - 2025-03-27 00:15:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 00:15:52 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 00:15:52 --> Final output sent to browser
DEBUG - 2025-03-27 00:15:52 --> Total execution time: 0.0371
INFO - 2025-03-27 00:17:24 --> Config Class Initialized
INFO - 2025-03-27 00:17:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:17:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:17:24 --> Utf8 Class Initialized
INFO - 2025-03-27 00:17:24 --> URI Class Initialized
DEBUG - 2025-03-27 00:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-27 00:17:24 --> Router Class Initialized
INFO - 2025-03-27 00:17:24 --> Output Class Initialized
INFO - 2025-03-27 00:17:24 --> Security Class Initialized
DEBUG - 2025-03-27 00:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:17:24 --> Input Class Initialized
INFO - 2025-03-27 00:17:24 --> Language Class Initialized
INFO - 2025-03-27 00:17:24 --> Language Class Initialized
INFO - 2025-03-27 00:17:24 --> Config Class Initialized
INFO - 2025-03-27 00:17:24 --> Loader Class Initialized
INFO - 2025-03-27 00:17:24 --> Helper loaded: url_helper
INFO - 2025-03-27 00:17:24 --> Helper loaded: file_helper
INFO - 2025-03-27 00:17:24 --> Helper loaded: html_helper
INFO - 2025-03-27 00:17:24 --> Helper loaded: form_helper
INFO - 2025-03-27 00:17:24 --> Helper loaded: text_helper
INFO - 2025-03-27 00:17:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:17:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:17:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:17:24 --> Database Driver Class Initialized
INFO - 2025-03-27 00:17:24 --> Email Class Initialized
INFO - 2025-03-27 00:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:17:24 --> Form Validation Class Initialized
INFO - 2025-03-27 00:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:17:24 --> Pagination Class Initialized
INFO - 2025-03-27 00:17:24 --> Controller Class Initialized
DEBUG - 2025-03-27 00:17:24 --> Supplier MX_Controller Initialized
INFO - 2025-03-27 00:17:24 --> Model Class Initialized
DEBUG - 2025-03-27 00:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 00:17:24 --> Model Class Initialized
DEBUG - 2025-03-27 00:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 00:17:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 00:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 00:17:24 --> Model Class Initialized
ERROR - 2025-03-27 00:17:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 00:17:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 00:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 00:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 00:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 00:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 00:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/supplier_list.php
DEBUG - 2025-03-27 00:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 00:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 00:17:25 --> Final output sent to browser
DEBUG - 2025-03-27 00:17:25 --> Total execution time: 0.1366
INFO - 2025-03-27 00:17:25 --> Config Class Initialized
INFO - 2025-03-27 00:17:25 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:17:25 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:17:25 --> Utf8 Class Initialized
INFO - 2025-03-27 00:17:25 --> URI Class Initialized
DEBUG - 2025-03-27 00:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-27 00:17:25 --> Router Class Initialized
INFO - 2025-03-27 00:17:25 --> Output Class Initialized
INFO - 2025-03-27 00:17:25 --> Security Class Initialized
DEBUG - 2025-03-27 00:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:17:25 --> Input Class Initialized
INFO - 2025-03-27 00:17:25 --> Language Class Initialized
INFO - 2025-03-27 00:17:25 --> Language Class Initialized
INFO - 2025-03-27 00:17:25 --> Config Class Initialized
INFO - 2025-03-27 00:17:25 --> Loader Class Initialized
INFO - 2025-03-27 00:17:25 --> Helper loaded: url_helper
INFO - 2025-03-27 00:17:25 --> Helper loaded: file_helper
INFO - 2025-03-27 00:17:25 --> Helper loaded: html_helper
INFO - 2025-03-27 00:17:25 --> Helper loaded: form_helper
INFO - 2025-03-27 00:17:25 --> Helper loaded: text_helper
INFO - 2025-03-27 00:17:25 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:17:25 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:17:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:17:25 --> Database Driver Class Initialized
INFO - 2025-03-27 00:17:25 --> Email Class Initialized
INFO - 2025-03-27 00:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:17:25 --> Form Validation Class Initialized
INFO - 2025-03-27 00:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:17:25 --> Pagination Class Initialized
INFO - 2025-03-27 00:17:25 --> Controller Class Initialized
DEBUG - 2025-03-27 00:17:25 --> Supplier MX_Controller Initialized
INFO - 2025-03-27 00:17:25 --> Model Class Initialized
DEBUG - 2025-03-27 00:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 00:17:25 --> Model Class Initialized
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$address2 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 224
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$phone /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 226
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$emailnumber /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 227
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$email_address /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 228
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$contact /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 229
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$fax /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 230
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$address2 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 224
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$phone /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 226
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$emailnumber /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 227
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$email_address /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 228
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$contact /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 229
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$fax /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 230
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$address2 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 224
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$phone /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 226
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$emailnumber /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 227
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$email_address /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 228
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$contact /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 229
ERROR - 2025-03-27 00:17:25 --> Severity: Warning --> Undefined property: stdClass::$fax /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php 230
ERROR - 2025-03-27 00:17:25 --> DEBUG: Supplier List JSON Response -> {"draw":1,"iTotalRecords":3,"iTotalDisplayRecords":3,"aaData":[{"sl":1,"supplier_name":"AG agro","address":"Ahsan Tower, 76 Bir Uttam A.k. Khandakar Sarak, Mohakhali, C\\A , ","address2":null,"mobile":"8801867449163","phone":null,"email":null,"email_address":null,"contact":null,"fax":null,"city":"Dhaka","state":"","zip":"1213","country":"Bangladesh","balance":"245.70","button":" <a href=\"http:\/\/localhost:8000\/edit_supplier\/3\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"Update\"><i class=\"pe-7s-note\" aria-hidden=\"true\"><\/i><\/a> <a onclick=\"supplierdelete(3)\" href=\"javascript:void(0)\"  class=\"btn btn-danger btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"Delete \"><i class=\"pe-7s-trash\" aria-hidden=\"true\"><\/i><\/a>"},{"sl":2,"supplier_name":"Danish","address":"abc","address2":null,"mobile":"01949452343","phone":null,"email":null,"email_address":null,"contact":null,"fax":null,"city":"dhaka","state":"","zip":"4000","country":"Bangladesh","balance":"100.00","button":" <a href=\"http:\/\/localhost:8000\/edit_supplier\/2\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"Update\"><i class=\"pe-7s-note\" aria-hidden=\"true\"><\/i><\/a> <a onclick=\"supplierdelete(2)\" href=\"javascript:void(0)\"  class=\"btn btn-danger btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"Delete \"><i class=\"pe-7s-trash\" aria-hidden=\"true\"><\/i><\/a>"},{"sl":3,"supplier_name":"Pran Company Limited","address":"","address2":null,"mobile":"","phone":null,"email":null,"email_address":null,"contact":null,"fax":null,"city":"","state":"","zip":"","country":"","balance":"0.00","button":" <a href=\"http:\/\/localhost:8000\/edit_supplier\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"Update\"><i class=\"pe-7s-note\" aria-hidden=\"true\"><\/i><\/a> <a onclick=\"supplierdelete(1)\" href=\"javascript:void(0)\"  class=\"btn btn-danger btn-xs m-b-5 custom_btn\" data-toggle=\"tooltip\" data-placement=\"right\" title=\"Delete \"><i class=\"pe-7s-trash\" aria-hidden=\"true\"><\/i><\/a>"}]}
INFO - 2025-03-27 00:17:30 --> Config Class Initialized
INFO - 2025-03-27 00:17:30 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:17:30 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:17:30 --> Utf8 Class Initialized
INFO - 2025-03-27 00:17:30 --> URI Class Initialized
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 00:17:30 --> Router Class Initialized
INFO - 2025-03-27 00:17:30 --> Output Class Initialized
INFO - 2025-03-27 00:17:30 --> Security Class Initialized
DEBUG - 2025-03-27 00:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:17:30 --> Input Class Initialized
INFO - 2025-03-27 00:17:30 --> Language Class Initialized
INFO - 2025-03-27 00:17:30 --> Language Class Initialized
INFO - 2025-03-27 00:17:30 --> Config Class Initialized
INFO - 2025-03-27 00:17:30 --> Loader Class Initialized
INFO - 2025-03-27 00:17:30 --> Helper loaded: url_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: file_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: html_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: form_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: text_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:17:30 --> Database Driver Class Initialized
INFO - 2025-03-27 00:17:30 --> Email Class Initialized
INFO - 2025-03-27 00:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:17:30 --> Form Validation Class Initialized
INFO - 2025-03-27 00:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:17:30 --> Pagination Class Initialized
INFO - 2025-03-27 00:17:30 --> Controller Class Initialized
DEBUG - 2025-03-27 00:17:30 --> Customer MX_Controller Initialized
INFO - 2025-03-27 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 00:17:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 00:17:30 --> Model Class Initialized
ERROR - 2025-03-27 00:17:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 00:17:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 00:17:30 --> Final output sent to browser
DEBUG - 2025-03-27 00:17:30 --> Total execution time: 0.1482
INFO - 2025-03-27 00:17:30 --> Config Class Initialized
INFO - 2025-03-27 00:17:30 --> Hooks Class Initialized
DEBUG - 2025-03-27 00:17:30 --> UTF-8 Support Enabled
INFO - 2025-03-27 00:17:30 --> Utf8 Class Initialized
INFO - 2025-03-27 00:17:30 --> URI Class Initialized
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 00:17:30 --> Router Class Initialized
INFO - 2025-03-27 00:17:30 --> Output Class Initialized
INFO - 2025-03-27 00:17:30 --> Security Class Initialized
DEBUG - 2025-03-27 00:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 00:17:30 --> Input Class Initialized
INFO - 2025-03-27 00:17:30 --> Language Class Initialized
INFO - 2025-03-27 00:17:30 --> Language Class Initialized
INFO - 2025-03-27 00:17:30 --> Config Class Initialized
INFO - 2025-03-27 00:17:30 --> Loader Class Initialized
INFO - 2025-03-27 00:17:30 --> Helper loaded: url_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: file_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: html_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: form_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: text_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: lang_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: directory_helper
INFO - 2025-03-27 00:17:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 00:17:30 --> Database Driver Class Initialized
INFO - 2025-03-27 00:17:30 --> Email Class Initialized
INFO - 2025-03-27 00:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 00:17:30 --> Form Validation Class Initialized
INFO - 2025-03-27 00:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 00:17:30 --> Pagination Class Initialized
INFO - 2025-03-27 00:17:30 --> Controller Class Initialized
DEBUG - 2025-03-27 00:17:30 --> Customer MX_Controller Initialized
INFO - 2025-03-27 00:17:30 --> Model Class Initialized
DEBUG - 2025-03-27 00:17:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 00:17:30 --> Model Class Initialized
ERROR - 2025-03-27 00:17:30 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 00:17:30 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 00:17:30 --> Received customer_id: null
ERROR - 2025-03-27 00:17:30 --> Received customfiled: null
ERROR - 2025-03-27 00:17:30 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 00:17:30 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 00:17:30 --> Search value: 
ERROR - 2025-03-27 00:17:30 --> Total unfiltered records: 15
ERROR - 2025-03-27 00:17:30 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 00:17:30 --> Records fetched from DB: 15
ERROR - 2025-03-27 00:17:30 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 00:17:30 --> ========= getCustomerList() END =========
INFO - 2025-03-27 04:11:49 --> Config Class Initialized
INFO - 2025-03-27 04:11:49 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:11:49 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:11:49 --> Utf8 Class Initialized
INFO - 2025-03-27 04:11:49 --> URI Class Initialized
DEBUG - 2025-03-27 04:11:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-27 04:11:49 --> No URI present. Default controller set.
INFO - 2025-03-27 04:11:49 --> Router Class Initialized
INFO - 2025-03-27 04:11:49 --> Output Class Initialized
INFO - 2025-03-27 04:11:49 --> Security Class Initialized
DEBUG - 2025-03-27 04:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:11:49 --> Input Class Initialized
INFO - 2025-03-27 04:11:49 --> Language Class Initialized
INFO - 2025-03-27 04:11:49 --> Language Class Initialized
INFO - 2025-03-27 04:11:49 --> Config Class Initialized
INFO - 2025-03-27 04:11:49 --> Loader Class Initialized
INFO - 2025-03-27 04:11:49 --> Helper loaded: url_helper
INFO - 2025-03-27 04:11:49 --> Helper loaded: file_helper
INFO - 2025-03-27 04:11:49 --> Helper loaded: html_helper
INFO - 2025-03-27 04:11:49 --> Helper loaded: form_helper
INFO - 2025-03-27 04:11:49 --> Helper loaded: text_helper
INFO - 2025-03-27 04:11:49 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:11:49 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:11:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:11:49 --> Database Driver Class Initialized
INFO - 2025-03-27 04:11:49 --> Email Class Initialized
INFO - 2025-03-27 04:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:11:49 --> Form Validation Class Initialized
INFO - 2025-03-27 04:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:11:49 --> Pagination Class Initialized
INFO - 2025-03-27 04:11:49 --> Controller Class Initialized
DEBUG - 2025-03-27 04:11:49 --> Auth MX_Controller Initialized
INFO - 2025-03-27 04:11:49 --> Model Class Initialized
DEBUG - 2025-03-27 04:11:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 04:11:49 --> Model Class Initialized
DEBUG - 2025-03-27 04:11:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:11:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:11:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:11:49 --> Model Class Initialized
DEBUG - 2025-03-27 04:11:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 04:11:49 --> Final output sent to browser
DEBUG - 2025-03-27 04:11:49 --> Total execution time: 0.0541
INFO - 2025-03-27 04:23:37 --> Config Class Initialized
INFO - 2025-03-27 04:23:37 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:23:37 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:23:37 --> Utf8 Class Initialized
INFO - 2025-03-27 04:23:37 --> URI Class Initialized
DEBUG - 2025-03-27 04:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-27 04:23:37 --> Router Class Initialized
INFO - 2025-03-27 04:23:37 --> Output Class Initialized
INFO - 2025-03-27 04:23:37 --> Security Class Initialized
DEBUG - 2025-03-27 04:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:23:37 --> Input Class Initialized
INFO - 2025-03-27 04:23:37 --> Language Class Initialized
INFO - 2025-03-27 04:23:37 --> Language Class Initialized
INFO - 2025-03-27 04:23:37 --> Config Class Initialized
INFO - 2025-03-27 04:23:37 --> Loader Class Initialized
INFO - 2025-03-27 04:23:37 --> Helper loaded: url_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: file_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: html_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: form_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: text_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:23:37 --> Database Driver Class Initialized
INFO - 2025-03-27 04:23:37 --> Email Class Initialized
INFO - 2025-03-27 04:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:23:37 --> Form Validation Class Initialized
INFO - 2025-03-27 04:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:23:37 --> Pagination Class Initialized
INFO - 2025-03-27 04:23:37 --> Controller Class Initialized
DEBUG - 2025-03-27 04:23:37 --> Invoice MX_Controller Initialized
INFO - 2025-03-27 10:23:37 --> Model Class Initialized
DEBUG - 2025-03-27 10:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-27 10:23:37 --> Model Class Initialized
DEBUG - 2025-03-27 10:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 10:23:37 --> Model Class Initialized
DEBUG - 2025-03-27 10:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-27 10:23:37 --> Model Class Initialized
INFO - 2025-03-27 04:23:37 --> Config Class Initialized
INFO - 2025-03-27 04:23:37 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:23:37 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:23:37 --> Utf8 Class Initialized
INFO - 2025-03-27 04:23:37 --> URI Class Initialized
DEBUG - 2025-03-27 04:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 04:23:37 --> Router Class Initialized
INFO - 2025-03-27 04:23:37 --> Output Class Initialized
INFO - 2025-03-27 04:23:37 --> Security Class Initialized
DEBUG - 2025-03-27 04:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:23:37 --> Input Class Initialized
INFO - 2025-03-27 04:23:37 --> Language Class Initialized
INFO - 2025-03-27 04:23:37 --> Language Class Initialized
INFO - 2025-03-27 04:23:37 --> Config Class Initialized
INFO - 2025-03-27 04:23:37 --> Loader Class Initialized
INFO - 2025-03-27 04:23:37 --> Helper loaded: url_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: file_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: html_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: form_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: text_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:23:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:23:37 --> Database Driver Class Initialized
INFO - 2025-03-27 04:23:37 --> Email Class Initialized
INFO - 2025-03-27 04:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:23:37 --> Form Validation Class Initialized
INFO - 2025-03-27 04:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:23:37 --> Pagination Class Initialized
INFO - 2025-03-27 04:23:37 --> Controller Class Initialized
DEBUG - 2025-03-27 04:23:37 --> Auth MX_Controller Initialized
INFO - 2025-03-27 04:23:37 --> Model Class Initialized
DEBUG - 2025-03-27 04:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 04:23:37 --> Model Class Initialized
DEBUG - 2025-03-27 04:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:23:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:23:37 --> Model Class Initialized
DEBUG - 2025-03-27 04:23:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 04:23:37 --> Final output sent to browser
DEBUG - 2025-03-27 04:23:37 --> Total execution time: 0.0118
INFO - 2025-03-27 04:25:47 --> Config Class Initialized
INFO - 2025-03-27 04:25:47 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:25:47 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:25:47 --> Utf8 Class Initialized
INFO - 2025-03-27 04:25:47 --> URI Class Initialized
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 04:25:47 --> Router Class Initialized
INFO - 2025-03-27 04:25:47 --> Output Class Initialized
INFO - 2025-03-27 04:25:47 --> Security Class Initialized
DEBUG - 2025-03-27 04:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:25:47 --> Input Class Initialized
INFO - 2025-03-27 04:25:47 --> Language Class Initialized
INFO - 2025-03-27 04:25:47 --> Language Class Initialized
INFO - 2025-03-27 04:25:47 --> Config Class Initialized
INFO - 2025-03-27 04:25:47 --> Loader Class Initialized
INFO - 2025-03-27 04:25:47 --> Helper loaded: url_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: file_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: html_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: form_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: text_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:25:47 --> Database Driver Class Initialized
INFO - 2025-03-27 04:25:47 --> Email Class Initialized
INFO - 2025-03-27 04:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:25:47 --> Form Validation Class Initialized
INFO - 2025-03-27 04:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:25:47 --> Pagination Class Initialized
INFO - 2025-03-27 04:25:47 --> Controller Class Initialized
DEBUG - 2025-03-27 04:25:47 --> Auth MX_Controller Initialized
INFO - 2025-03-27 04:25:47 --> Model Class Initialized
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 04:25:47 --> Model Class Initialized
INFO - 2025-03-27 04:25:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 04:25:47 --> Config Class Initialized
INFO - 2025-03-27 04:25:47 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:25:47 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:25:47 --> Utf8 Class Initialized
INFO - 2025-03-27 04:25:47 --> URI Class Initialized
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 04:25:47 --> Router Class Initialized
INFO - 2025-03-27 04:25:47 --> Output Class Initialized
INFO - 2025-03-27 04:25:47 --> Security Class Initialized
DEBUG - 2025-03-27 04:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:25:47 --> Input Class Initialized
INFO - 2025-03-27 04:25:47 --> Language Class Initialized
INFO - 2025-03-27 04:25:47 --> Language Class Initialized
INFO - 2025-03-27 04:25:47 --> Config Class Initialized
INFO - 2025-03-27 04:25:47 --> Loader Class Initialized
INFO - 2025-03-27 04:25:47 --> Helper loaded: url_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: file_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: html_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: form_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: text_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:25:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:25:47 --> Database Driver Class Initialized
INFO - 2025-03-27 04:25:47 --> Email Class Initialized
INFO - 2025-03-27 04:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:25:47 --> Form Validation Class Initialized
INFO - 2025-03-27 04:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:25:47 --> Pagination Class Initialized
INFO - 2025-03-27 04:25:47 --> Controller Class Initialized
DEBUG - 2025-03-27 04:25:47 --> Home MX_Controller Initialized
INFO - 2025-03-27 04:25:47 --> Model Class Initialized
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-27 04:25:47 --> Model Class Initialized
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:25:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:25:47 --> Model Class Initialized
ERROR - 2025-03-27 04:25:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:25:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:25:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:25:47 --> Final output sent to browser
DEBUG - 2025-03-27 04:25:47 --> Total execution time: 0.8775
INFO - 2025-03-27 04:26:36 --> Config Class Initialized
INFO - 2025-03-27 04:26:36 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:26:36 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:26:36 --> Utf8 Class Initialized
INFO - 2025-03-27 04:26:36 --> URI Class Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:26:36 --> Router Class Initialized
INFO - 2025-03-27 04:26:36 --> Output Class Initialized
INFO - 2025-03-27 04:26:36 --> Security Class Initialized
DEBUG - 2025-03-27 04:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:26:36 --> Input Class Initialized
INFO - 2025-03-27 04:26:36 --> Language Class Initialized
INFO - 2025-03-27 04:26:36 --> Language Class Initialized
INFO - 2025-03-27 04:26:36 --> Config Class Initialized
INFO - 2025-03-27 04:26:36 --> Loader Class Initialized
INFO - 2025-03-27 04:26:36 --> Helper loaded: url_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: file_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: html_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: form_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: text_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:26:36 --> Database Driver Class Initialized
INFO - 2025-03-27 04:26:36 --> Email Class Initialized
INFO - 2025-03-27 04:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:26:36 --> Form Validation Class Initialized
INFO - 2025-03-27 04:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:26:36 --> Pagination Class Initialized
INFO - 2025-03-27 04:26:36 --> Controller Class Initialized
DEBUG - 2025-03-27 04:26:36 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:26:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:26:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:26:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:26:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:26:36 --> Model Class Initialized
ERROR - 2025-03-27 04:26:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:26:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:26:36 --> Final output sent to browser
DEBUG - 2025-03-27 04:26:36 --> Total execution time: 0.1539
INFO - 2025-03-27 04:26:36 --> Config Class Initialized
INFO - 2025-03-27 04:26:36 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:26:36 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:26:36 --> Utf8 Class Initialized
INFO - 2025-03-27 04:26:36 --> URI Class Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:26:36 --> Router Class Initialized
INFO - 2025-03-27 04:26:36 --> Output Class Initialized
INFO - 2025-03-27 04:26:36 --> Security Class Initialized
DEBUG - 2025-03-27 04:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:26:36 --> Input Class Initialized
INFO - 2025-03-27 04:26:36 --> Language Class Initialized
INFO - 2025-03-27 04:26:36 --> Language Class Initialized
INFO - 2025-03-27 04:26:36 --> Config Class Initialized
INFO - 2025-03-27 04:26:36 --> Loader Class Initialized
INFO - 2025-03-27 04:26:36 --> Helper loaded: url_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: file_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: html_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: form_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: text_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:26:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:26:36 --> Database Driver Class Initialized
INFO - 2025-03-27 04:26:36 --> Email Class Initialized
INFO - 2025-03-27 04:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:26:36 --> Form Validation Class Initialized
INFO - 2025-03-27 04:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:26:36 --> Pagination Class Initialized
INFO - 2025-03-27 04:26:36 --> Controller Class Initialized
DEBUG - 2025-03-27 04:26:36 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:26:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:26:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:26:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:26:36 --> Model Class Initialized
ERROR - 2025-03-27 04:26:36 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:26:36 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:26:36 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:26:36 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:26:36 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:26:36 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 04:26:36 --> Final output sent to browser
DEBUG - 2025-03-27 04:26:36 --> Total execution time: 0.0361
INFO - 2025-03-27 04:28:04 --> Config Class Initialized
INFO - 2025-03-27 04:28:04 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:28:04 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:28:04 --> Utf8 Class Initialized
INFO - 2025-03-27 04:28:04 --> URI Class Initialized
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:28:04 --> Router Class Initialized
INFO - 2025-03-27 04:28:04 --> Output Class Initialized
INFO - 2025-03-27 04:28:04 --> Security Class Initialized
DEBUG - 2025-03-27 04:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:28:04 --> Input Class Initialized
INFO - 2025-03-27 04:28:04 --> Language Class Initialized
INFO - 2025-03-27 04:28:04 --> Language Class Initialized
INFO - 2025-03-27 04:28:04 --> Config Class Initialized
INFO - 2025-03-27 04:28:04 --> Loader Class Initialized
INFO - 2025-03-27 04:28:04 --> Helper loaded: url_helper
INFO - 2025-03-27 04:28:04 --> Helper loaded: file_helper
INFO - 2025-03-27 04:28:04 --> Helper loaded: html_helper
INFO - 2025-03-27 04:28:04 --> Helper loaded: form_helper
INFO - 2025-03-27 04:28:04 --> Helper loaded: text_helper
INFO - 2025-03-27 04:28:04 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:28:04 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:28:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:28:04 --> Database Driver Class Initialized
INFO - 2025-03-27 04:28:04 --> Email Class Initialized
INFO - 2025-03-27 04:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:28:04 --> Form Validation Class Initialized
INFO - 2025-03-27 04:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:28:04 --> Pagination Class Initialized
INFO - 2025-03-27 04:28:04 --> Controller Class Initialized
DEBUG - 2025-03-27 04:28:04 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:28:04 --> Model Class Initialized
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:28:04 --> Model Class Initialized
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:28:04 --> Model Class Initialized
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:28:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:28:04 --> Model Class Initialized
ERROR - 2025-03-27 04:28:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:28:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:28:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:28:04 --> Final output sent to browser
DEBUG - 2025-03-27 04:28:04 --> Total execution time: 0.1373
INFO - 2025-03-27 04:47:36 --> Config Class Initialized
INFO - 2025-03-27 04:47:36 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:47:36 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:47:36 --> Utf8 Class Initialized
INFO - 2025-03-27 04:47:36 --> URI Class Initialized
DEBUG - 2025-03-27 04:47:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:47:36 --> Router Class Initialized
INFO - 2025-03-27 04:47:36 --> Output Class Initialized
INFO - 2025-03-27 04:47:36 --> Security Class Initialized
DEBUG - 2025-03-27 04:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:47:36 --> Input Class Initialized
INFO - 2025-03-27 04:47:36 --> Language Class Initialized
INFO - 2025-03-27 04:47:36 --> Language Class Initialized
INFO - 2025-03-27 04:47:36 --> Config Class Initialized
INFO - 2025-03-27 04:47:36 --> Loader Class Initialized
INFO - 2025-03-27 04:47:36 --> Helper loaded: url_helper
INFO - 2025-03-27 04:47:36 --> Helper loaded: file_helper
INFO - 2025-03-27 04:47:36 --> Helper loaded: html_helper
INFO - 2025-03-27 04:47:36 --> Helper loaded: form_helper
INFO - 2025-03-27 04:47:36 --> Helper loaded: text_helper
INFO - 2025-03-27 04:47:36 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:47:36 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:47:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:47:36 --> Database Driver Class Initialized
INFO - 2025-03-27 04:47:36 --> Email Class Initialized
INFO - 2025-03-27 04:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:47:36 --> Form Validation Class Initialized
INFO - 2025-03-27 04:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:47:36 --> Pagination Class Initialized
INFO - 2025-03-27 04:47:36 --> Controller Class Initialized
DEBUG - 2025-03-27 04:47:36 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:47:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:47:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:47:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:47:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:47:36 --> Model Class Initialized
DEBUG - 2025-03-27 04:47:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:47:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:47:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:47:36 --> Model Class Initialized
ERROR - 2025-03-27 04:47:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:47:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:47:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:47:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:47:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:47:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:47:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 04:47:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:47:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:47:37 --> Final output sent to browser
DEBUG - 2025-03-27 04:47:37 --> Total execution time: 0.4013
INFO - 2025-03-27 04:48:28 --> Config Class Initialized
INFO - 2025-03-27 04:48:28 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:48:28 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:48:28 --> Utf8 Class Initialized
INFO - 2025-03-27 04:48:28 --> URI Class Initialized
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:48:28 --> Router Class Initialized
INFO - 2025-03-27 04:48:28 --> Output Class Initialized
INFO - 2025-03-27 04:48:28 --> Security Class Initialized
DEBUG - 2025-03-27 04:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:48:28 --> Input Class Initialized
INFO - 2025-03-27 04:48:28 --> Language Class Initialized
INFO - 2025-03-27 04:48:28 --> Language Class Initialized
INFO - 2025-03-27 04:48:28 --> Config Class Initialized
INFO - 2025-03-27 04:48:28 --> Loader Class Initialized
INFO - 2025-03-27 04:48:28 --> Helper loaded: url_helper
INFO - 2025-03-27 04:48:28 --> Helper loaded: file_helper
INFO - 2025-03-27 04:48:28 --> Helper loaded: html_helper
INFO - 2025-03-27 04:48:28 --> Helper loaded: form_helper
INFO - 2025-03-27 04:48:28 --> Helper loaded: text_helper
INFO - 2025-03-27 04:48:28 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:48:28 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:48:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:48:28 --> Database Driver Class Initialized
INFO - 2025-03-27 04:48:28 --> Email Class Initialized
INFO - 2025-03-27 04:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:48:28 --> Form Validation Class Initialized
INFO - 2025-03-27 04:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:48:28 --> Pagination Class Initialized
INFO - 2025-03-27 04:48:28 --> Controller Class Initialized
DEBUG - 2025-03-27 04:48:28 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:48:28 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:48:28 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:48:28 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:48:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:48:28 --> Model Class Initialized
ERROR - 2025-03-27 04:48:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:48:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:48:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:48:28 --> Final output sent to browser
DEBUG - 2025-03-27 04:48:28 --> Total execution time: 0.1246
INFO - 2025-03-27 04:48:43 --> Config Class Initialized
INFO - 2025-03-27 04:48:43 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:48:43 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:48:43 --> Utf8 Class Initialized
INFO - 2025-03-27 04:48:43 --> URI Class Initialized
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:48:43 --> Router Class Initialized
INFO - 2025-03-27 04:48:43 --> Output Class Initialized
INFO - 2025-03-27 04:48:43 --> Security Class Initialized
DEBUG - 2025-03-27 04:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:48:43 --> Input Class Initialized
INFO - 2025-03-27 04:48:43 --> Language Class Initialized
INFO - 2025-03-27 04:48:43 --> Language Class Initialized
INFO - 2025-03-27 04:48:43 --> Config Class Initialized
INFO - 2025-03-27 04:48:43 --> Loader Class Initialized
INFO - 2025-03-27 04:48:43 --> Helper loaded: url_helper
INFO - 2025-03-27 04:48:43 --> Helper loaded: file_helper
INFO - 2025-03-27 04:48:43 --> Helper loaded: html_helper
INFO - 2025-03-27 04:48:43 --> Helper loaded: form_helper
INFO - 2025-03-27 04:48:43 --> Helper loaded: text_helper
INFO - 2025-03-27 04:48:43 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:48:43 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:48:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:48:43 --> Database Driver Class Initialized
INFO - 2025-03-27 04:48:43 --> Email Class Initialized
INFO - 2025-03-27 04:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:48:43 --> Form Validation Class Initialized
INFO - 2025-03-27 04:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:48:43 --> Pagination Class Initialized
INFO - 2025-03-27 04:48:43 --> Controller Class Initialized
DEBUG - 2025-03-27 04:48:43 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:48:43 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:48:43 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:48:43 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:48:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:48:43 --> Model Class Initialized
ERROR - 2025-03-27 04:48:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:48:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:48:43 --> Final output sent to browser
DEBUG - 2025-03-27 04:48:43 --> Total execution time: 0.0816
INFO - 2025-03-27 04:48:44 --> Config Class Initialized
INFO - 2025-03-27 04:48:44 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:48:44 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:48:44 --> Utf8 Class Initialized
INFO - 2025-03-27 04:48:44 --> URI Class Initialized
DEBUG - 2025-03-27 04:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:48:44 --> Router Class Initialized
INFO - 2025-03-27 04:48:44 --> Output Class Initialized
INFO - 2025-03-27 04:48:44 --> Security Class Initialized
DEBUG - 2025-03-27 04:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:48:44 --> Input Class Initialized
INFO - 2025-03-27 04:48:44 --> Language Class Initialized
INFO - 2025-03-27 04:48:44 --> Language Class Initialized
INFO - 2025-03-27 04:48:44 --> Config Class Initialized
INFO - 2025-03-27 04:48:44 --> Loader Class Initialized
INFO - 2025-03-27 04:48:44 --> Helper loaded: url_helper
INFO - 2025-03-27 04:48:44 --> Helper loaded: file_helper
INFO - 2025-03-27 04:48:44 --> Helper loaded: html_helper
INFO - 2025-03-27 04:48:44 --> Helper loaded: form_helper
INFO - 2025-03-27 04:48:44 --> Helper loaded: text_helper
INFO - 2025-03-27 04:48:44 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:48:44 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:48:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:48:44 --> Database Driver Class Initialized
INFO - 2025-03-27 04:48:44 --> Email Class Initialized
INFO - 2025-03-27 04:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:48:44 --> Form Validation Class Initialized
INFO - 2025-03-27 04:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:48:44 --> Pagination Class Initialized
INFO - 2025-03-27 04:48:44 --> Controller Class Initialized
DEBUG - 2025-03-27 04:48:44 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:48:44 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:48:44 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:48:44 --> Model Class Initialized
ERROR - 2025-03-27 04:48:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:48:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:48:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:48:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:48:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:48:44 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 04:48:44 --> Final output sent to browser
DEBUG - 2025-03-27 04:48:44 --> Total execution time: 0.0804
INFO - 2025-03-27 04:48:53 --> Config Class Initialized
INFO - 2025-03-27 04:48:53 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:48:53 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:48:53 --> Utf8 Class Initialized
INFO - 2025-03-27 04:48:53 --> URI Class Initialized
DEBUG - 2025-03-27 04:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:48:53 --> Router Class Initialized
INFO - 2025-03-27 04:48:53 --> Output Class Initialized
INFO - 2025-03-27 04:48:53 --> Security Class Initialized
DEBUG - 2025-03-27 04:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:48:53 --> Input Class Initialized
INFO - 2025-03-27 04:48:53 --> Language Class Initialized
INFO - 2025-03-27 04:48:53 --> Language Class Initialized
INFO - 2025-03-27 04:48:53 --> Config Class Initialized
INFO - 2025-03-27 04:48:53 --> Loader Class Initialized
INFO - 2025-03-27 04:48:53 --> Helper loaded: url_helper
INFO - 2025-03-27 04:48:53 --> Helper loaded: file_helper
INFO - 2025-03-27 04:48:53 --> Helper loaded: html_helper
INFO - 2025-03-27 04:48:53 --> Helper loaded: form_helper
INFO - 2025-03-27 04:48:53 --> Helper loaded: text_helper
INFO - 2025-03-27 04:48:53 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:48:53 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:48:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:48:53 --> Database Driver Class Initialized
INFO - 2025-03-27 04:48:53 --> Email Class Initialized
INFO - 2025-03-27 04:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:48:53 --> Form Validation Class Initialized
INFO - 2025-03-27 04:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:48:53 --> Pagination Class Initialized
INFO - 2025-03-27 04:48:53 --> Controller Class Initialized
DEBUG - 2025-03-27 04:48:53 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:48:53 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:48:53 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:48:53 --> Model Class Initialized
DEBUG - 2025-03-27 04:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:48:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:48:53 --> Model Class Initialized
ERROR - 2025-03-27 04:48:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:48:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:48:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:48:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:48:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:48:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 04:48:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:48:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:48:54 --> Final output sent to browser
DEBUG - 2025-03-27 04:48:54 --> Total execution time: 0.1881
INFO - 2025-03-27 04:49:02 --> Config Class Initialized
INFO - 2025-03-27 04:49:02 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:49:02 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:49:02 --> Utf8 Class Initialized
INFO - 2025-03-27 04:49:02 --> URI Class Initialized
DEBUG - 2025-03-27 04:49:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:49:02 --> Router Class Initialized
INFO - 2025-03-27 04:49:02 --> Output Class Initialized
INFO - 2025-03-27 04:49:02 --> Security Class Initialized
DEBUG - 2025-03-27 04:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:49:02 --> Input Class Initialized
INFO - 2025-03-27 04:49:02 --> Language Class Initialized
INFO - 2025-03-27 04:49:02 --> Language Class Initialized
INFO - 2025-03-27 04:49:02 --> Config Class Initialized
INFO - 2025-03-27 04:49:02 --> Loader Class Initialized
INFO - 2025-03-27 04:49:02 --> Helper loaded: url_helper
INFO - 2025-03-27 04:49:02 --> Helper loaded: file_helper
INFO - 2025-03-27 04:49:02 --> Helper loaded: html_helper
INFO - 2025-03-27 04:49:02 --> Helper loaded: form_helper
INFO - 2025-03-27 04:49:02 --> Helper loaded: text_helper
INFO - 2025-03-27 04:49:02 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:49:02 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:49:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:49:02 --> Database Driver Class Initialized
INFO - 2025-03-27 04:49:02 --> Email Class Initialized
INFO - 2025-03-27 04:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:49:02 --> Form Validation Class Initialized
INFO - 2025-03-27 04:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:49:02 --> Pagination Class Initialized
INFO - 2025-03-27 04:49:02 --> Controller Class Initialized
DEBUG - 2025-03-27 04:49:02 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:49:02 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:49:02 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:49:02 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:49:02 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:49:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:49:02 --> Model Class Initialized
ERROR - 2025-03-27 04:49:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:49:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:49:03 --> Final output sent to browser
DEBUG - 2025-03-27 04:49:03 --> Total execution time: 0.0840
INFO - 2025-03-27 04:49:03 --> Config Class Initialized
INFO - 2025-03-27 04:49:03 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:49:03 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:49:03 --> Utf8 Class Initialized
INFO - 2025-03-27 04:49:03 --> URI Class Initialized
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:49:03 --> Router Class Initialized
INFO - 2025-03-27 04:49:03 --> Output Class Initialized
INFO - 2025-03-27 04:49:03 --> Security Class Initialized
DEBUG - 2025-03-27 04:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:49:03 --> Input Class Initialized
INFO - 2025-03-27 04:49:03 --> Language Class Initialized
INFO - 2025-03-27 04:49:03 --> Language Class Initialized
INFO - 2025-03-27 04:49:03 --> Config Class Initialized
INFO - 2025-03-27 04:49:03 --> Loader Class Initialized
INFO - 2025-03-27 04:49:03 --> Helper loaded: url_helper
INFO - 2025-03-27 04:49:03 --> Helper loaded: file_helper
INFO - 2025-03-27 04:49:03 --> Helper loaded: html_helper
INFO - 2025-03-27 04:49:03 --> Helper loaded: form_helper
INFO - 2025-03-27 04:49:03 --> Helper loaded: text_helper
INFO - 2025-03-27 04:49:03 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:49:03 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:49:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:49:03 --> Database Driver Class Initialized
INFO - 2025-03-27 04:49:03 --> Email Class Initialized
INFO - 2025-03-27 04:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:49:03 --> Form Validation Class Initialized
INFO - 2025-03-27 04:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:49:03 --> Pagination Class Initialized
INFO - 2025-03-27 04:49:03 --> Controller Class Initialized
DEBUG - 2025-03-27 04:49:03 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:49:03 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:49:03 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:49:03 --> Model Class Initialized
ERROR - 2025-03-27 04:49:03 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:03 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:03 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:03 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:03 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:03 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 04:49:03 --> Final output sent to browser
DEBUG - 2025-03-27 04:49:03 --> Total execution time: 0.0423
INFO - 2025-03-27 04:49:07 --> Config Class Initialized
INFO - 2025-03-27 04:49:07 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:49:07 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:49:07 --> Utf8 Class Initialized
INFO - 2025-03-27 04:49:07 --> URI Class Initialized
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:49:07 --> Router Class Initialized
INFO - 2025-03-27 04:49:07 --> Output Class Initialized
INFO - 2025-03-27 04:49:07 --> Security Class Initialized
DEBUG - 2025-03-27 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:49:07 --> Input Class Initialized
INFO - 2025-03-27 04:49:07 --> Language Class Initialized
INFO - 2025-03-27 04:49:07 --> Language Class Initialized
INFO - 2025-03-27 04:49:07 --> Config Class Initialized
INFO - 2025-03-27 04:49:07 --> Loader Class Initialized
INFO - 2025-03-27 04:49:07 --> Helper loaded: url_helper
INFO - 2025-03-27 04:49:07 --> Helper loaded: file_helper
INFO - 2025-03-27 04:49:07 --> Helper loaded: html_helper
INFO - 2025-03-27 04:49:07 --> Helper loaded: form_helper
INFO - 2025-03-27 04:49:07 --> Helper loaded: text_helper
INFO - 2025-03-27 04:49:07 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:49:07 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:49:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:49:07 --> Database Driver Class Initialized
INFO - 2025-03-27 04:49:07 --> Email Class Initialized
INFO - 2025-03-27 04:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:49:07 --> Form Validation Class Initialized
INFO - 2025-03-27 04:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:49:07 --> Pagination Class Initialized
INFO - 2025-03-27 04:49:07 --> Controller Class Initialized
DEBUG - 2025-03-27 04:49:07 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:49:07 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:49:07 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:49:07 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:49:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:49:07 --> Model Class Initialized
ERROR - 2025-03-27 04:49:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:49:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:49:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:49:07 --> Final output sent to browser
DEBUG - 2025-03-27 04:49:07 --> Total execution time: 0.1174
INFO - 2025-03-27 04:49:08 --> Config Class Initialized
INFO - 2025-03-27 04:49:08 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:49:08 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:49:08 --> Utf8 Class Initialized
INFO - 2025-03-27 04:49:08 --> URI Class Initialized
DEBUG - 2025-03-27 04:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:49:08 --> Router Class Initialized
INFO - 2025-03-27 04:49:08 --> Output Class Initialized
INFO - 2025-03-27 04:49:08 --> Security Class Initialized
DEBUG - 2025-03-27 04:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:49:08 --> Input Class Initialized
INFO - 2025-03-27 04:49:08 --> Language Class Initialized
INFO - 2025-03-27 04:49:08 --> Language Class Initialized
INFO - 2025-03-27 04:49:08 --> Config Class Initialized
INFO - 2025-03-27 04:49:08 --> Loader Class Initialized
INFO - 2025-03-27 04:49:08 --> Helper loaded: url_helper
INFO - 2025-03-27 04:49:08 --> Helper loaded: file_helper
INFO - 2025-03-27 04:49:08 --> Helper loaded: html_helper
INFO - 2025-03-27 04:49:08 --> Helper loaded: form_helper
INFO - 2025-03-27 04:49:08 --> Helper loaded: text_helper
INFO - 2025-03-27 04:49:08 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:49:08 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:49:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:49:08 --> Database Driver Class Initialized
INFO - 2025-03-27 04:49:08 --> Email Class Initialized
INFO - 2025-03-27 04:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:49:08 --> Form Validation Class Initialized
INFO - 2025-03-27 04:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:49:08 --> Pagination Class Initialized
INFO - 2025-03-27 04:49:08 --> Controller Class Initialized
DEBUG - 2025-03-27 04:49:08 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:49:08 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:49:08 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:49:08 --> Model Class Initialized
ERROR - 2025-03-27 04:49:08 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:08 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:08 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:08 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:08 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:49:08 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 04:49:08 --> Final output sent to browser
DEBUG - 2025-03-27 04:49:08 --> Total execution time: 0.0362
INFO - 2025-03-27 04:49:11 --> Config Class Initialized
INFO - 2025-03-27 04:49:11 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:49:11 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:49:11 --> Utf8 Class Initialized
INFO - 2025-03-27 04:49:11 --> URI Class Initialized
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:49:11 --> Router Class Initialized
INFO - 2025-03-27 04:49:11 --> Output Class Initialized
INFO - 2025-03-27 04:49:11 --> Security Class Initialized
DEBUG - 2025-03-27 04:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:49:11 --> Input Class Initialized
INFO - 2025-03-27 04:49:11 --> Language Class Initialized
INFO - 2025-03-27 04:49:11 --> Language Class Initialized
INFO - 2025-03-27 04:49:11 --> Config Class Initialized
INFO - 2025-03-27 04:49:11 --> Loader Class Initialized
INFO - 2025-03-27 04:49:11 --> Helper loaded: url_helper
INFO - 2025-03-27 04:49:11 --> Helper loaded: file_helper
INFO - 2025-03-27 04:49:11 --> Helper loaded: html_helper
INFO - 2025-03-27 04:49:11 --> Helper loaded: form_helper
INFO - 2025-03-27 04:49:11 --> Helper loaded: text_helper
INFO - 2025-03-27 04:49:11 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:49:11 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:49:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:49:11 --> Database Driver Class Initialized
INFO - 2025-03-27 04:49:11 --> Email Class Initialized
INFO - 2025-03-27 04:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:49:11 --> Form Validation Class Initialized
INFO - 2025-03-27 04:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:49:11 --> Pagination Class Initialized
INFO - 2025-03-27 04:49:11 --> Controller Class Initialized
DEBUG - 2025-03-27 04:49:11 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:49:11 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:49:11 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:49:11 --> Model Class Initialized
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:49:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:49:11 --> Model Class Initialized
ERROR - 2025-03-27 04:49:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:49:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:49:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:49:11 --> Final output sent to browser
DEBUG - 2025-03-27 04:49:11 --> Total execution time: 0.1237
INFO - 2025-03-27 04:59:45 --> Config Class Initialized
INFO - 2025-03-27 04:59:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:59:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:59:45 --> Utf8 Class Initialized
INFO - 2025-03-27 04:59:45 --> URI Class Initialized
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:59:45 --> Router Class Initialized
INFO - 2025-03-27 04:59:45 --> Output Class Initialized
INFO - 2025-03-27 04:59:45 --> Security Class Initialized
DEBUG - 2025-03-27 04:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:59:45 --> Input Class Initialized
INFO - 2025-03-27 04:59:45 --> Language Class Initialized
INFO - 2025-03-27 04:59:45 --> Language Class Initialized
INFO - 2025-03-27 04:59:45 --> Config Class Initialized
INFO - 2025-03-27 04:59:45 --> Loader Class Initialized
INFO - 2025-03-27 04:59:45 --> Helper loaded: url_helper
INFO - 2025-03-27 04:59:45 --> Helper loaded: file_helper
INFO - 2025-03-27 04:59:45 --> Helper loaded: html_helper
INFO - 2025-03-27 04:59:45 --> Helper loaded: form_helper
INFO - 2025-03-27 04:59:45 --> Helper loaded: text_helper
INFO - 2025-03-27 04:59:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:59:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:59:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:59:45 --> Database Driver Class Initialized
INFO - 2025-03-27 04:59:45 --> Email Class Initialized
INFO - 2025-03-27 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:59:45 --> Form Validation Class Initialized
INFO - 2025-03-27 04:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:59:45 --> Pagination Class Initialized
INFO - 2025-03-27 04:59:45 --> Controller Class Initialized
DEBUG - 2025-03-27 04:59:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:59:45 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:59:45 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:59:45 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:59:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:59:45 --> Model Class Initialized
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 66
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 83
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 83
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 83
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 83
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 83
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 100
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 100
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 100
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 218
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 218
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 218
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 218
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 218
ERROR - 2025-03-27 04:59:45 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 218
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:59:45 --> Final output sent to browser
DEBUG - 2025-03-27 04:59:45 --> Total execution time: 0.1180
INFO - 2025-03-27 04:59:52 --> Config Class Initialized
INFO - 2025-03-27 04:59:52 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:59:52 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:59:52 --> Utf8 Class Initialized
INFO - 2025-03-27 04:59:52 --> URI Class Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:59:52 --> Router Class Initialized
INFO - 2025-03-27 04:59:52 --> Output Class Initialized
INFO - 2025-03-27 04:59:52 --> Security Class Initialized
DEBUG - 2025-03-27 04:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:59:52 --> Input Class Initialized
INFO - 2025-03-27 04:59:52 --> Language Class Initialized
INFO - 2025-03-27 04:59:52 --> Language Class Initialized
INFO - 2025-03-27 04:59:52 --> Config Class Initialized
INFO - 2025-03-27 04:59:52 --> Loader Class Initialized
INFO - 2025-03-27 04:59:52 --> Helper loaded: url_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: file_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: html_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: form_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: text_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:59:52 --> Database Driver Class Initialized
INFO - 2025-03-27 04:59:52 --> Email Class Initialized
INFO - 2025-03-27 04:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:59:52 --> Form Validation Class Initialized
INFO - 2025-03-27 04:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:59:52 --> Pagination Class Initialized
INFO - 2025-03-27 04:59:52 --> Controller Class Initialized
DEBUG - 2025-03-27 04:59:52 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:59:52 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:59:52 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:59:52 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 04:59:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 04:59:52 --> Model Class Initialized
ERROR - 2025-03-27 04:59:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 04:59:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 04:59:52 --> Final output sent to browser
DEBUG - 2025-03-27 04:59:52 --> Total execution time: 0.1184
INFO - 2025-03-27 04:59:52 --> Config Class Initialized
INFO - 2025-03-27 04:59:52 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:59:52 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:59:52 --> Utf8 Class Initialized
INFO - 2025-03-27 04:59:52 --> URI Class Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:59:52 --> Router Class Initialized
INFO - 2025-03-27 04:59:52 --> Output Class Initialized
INFO - 2025-03-27 04:59:52 --> Security Class Initialized
DEBUG - 2025-03-27 04:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:59:52 --> Input Class Initialized
INFO - 2025-03-27 04:59:52 --> Language Class Initialized
INFO - 2025-03-27 04:59:52 --> Language Class Initialized
INFO - 2025-03-27 04:59:52 --> Config Class Initialized
INFO - 2025-03-27 04:59:52 --> Loader Class Initialized
INFO - 2025-03-27 04:59:52 --> Helper loaded: url_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: file_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: html_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: form_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: text_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:59:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:59:52 --> Database Driver Class Initialized
INFO - 2025-03-27 04:59:52 --> Email Class Initialized
INFO - 2025-03-27 04:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:59:52 --> Form Validation Class Initialized
INFO - 2025-03-27 04:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:59:52 --> Pagination Class Initialized
INFO - 2025-03-27 04:59:52 --> Controller Class Initialized
DEBUG - 2025-03-27 04:59:52 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:59:52 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:59:52 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:59:52 --> Model Class Initialized
ERROR - 2025-03-27 04:59:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:59:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:59:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:59:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:59:52 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 04:59:52 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 04:59:52 --> Final output sent to browser
DEBUG - 2025-03-27 04:59:52 --> Total execution time: 0.0348
INFO - 2025-03-27 04:59:59 --> Config Class Initialized
INFO - 2025-03-27 04:59:59 --> Hooks Class Initialized
DEBUG - 2025-03-27 04:59:59 --> UTF-8 Support Enabled
INFO - 2025-03-27 04:59:59 --> Utf8 Class Initialized
INFO - 2025-03-27 04:59:59 --> URI Class Initialized
DEBUG - 2025-03-27 04:59:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 04:59:59 --> Router Class Initialized
INFO - 2025-03-27 04:59:59 --> Output Class Initialized
INFO - 2025-03-27 04:59:59 --> Security Class Initialized
DEBUG - 2025-03-27 04:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 04:59:59 --> Input Class Initialized
INFO - 2025-03-27 04:59:59 --> Language Class Initialized
INFO - 2025-03-27 04:59:59 --> Language Class Initialized
INFO - 2025-03-27 04:59:59 --> Config Class Initialized
INFO - 2025-03-27 04:59:59 --> Loader Class Initialized
INFO - 2025-03-27 04:59:59 --> Helper loaded: url_helper
INFO - 2025-03-27 04:59:59 --> Helper loaded: file_helper
INFO - 2025-03-27 04:59:59 --> Helper loaded: html_helper
INFO - 2025-03-27 04:59:59 --> Helper loaded: form_helper
INFO - 2025-03-27 04:59:59 --> Helper loaded: text_helper
INFO - 2025-03-27 04:59:59 --> Helper loaded: lang_helper
INFO - 2025-03-27 04:59:59 --> Helper loaded: directory_helper
INFO - 2025-03-27 04:59:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 04:59:59 --> Database Driver Class Initialized
INFO - 2025-03-27 04:59:59 --> Email Class Initialized
INFO - 2025-03-27 04:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 04:59:59 --> Form Validation Class Initialized
INFO - 2025-03-27 04:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 04:59:59 --> Pagination Class Initialized
INFO - 2025-03-27 04:59:59 --> Controller Class Initialized
DEBUG - 2025-03-27 04:59:59 --> Product MX_Controller Initialized
INFO - 2025-03-27 04:59:59 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 04:59:59 --> Model Class Initialized
DEBUG - 2025-03-27 04:59:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 04:59:59 --> Model Class Initialized
ERROR - 2025-03-27 04:59:59 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 447
INFO - 2025-03-27 05:00:05 --> Config Class Initialized
INFO - 2025-03-27 05:00:05 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:00:05 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:00:05 --> Utf8 Class Initialized
INFO - 2025-03-27 05:00:05 --> URI Class Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:00:05 --> Router Class Initialized
INFO - 2025-03-27 05:00:05 --> Output Class Initialized
INFO - 2025-03-27 05:00:05 --> Security Class Initialized
DEBUG - 2025-03-27 05:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:00:05 --> Input Class Initialized
INFO - 2025-03-27 05:00:05 --> Language Class Initialized
INFO - 2025-03-27 05:00:05 --> Language Class Initialized
INFO - 2025-03-27 05:00:05 --> Config Class Initialized
INFO - 2025-03-27 05:00:05 --> Loader Class Initialized
INFO - 2025-03-27 05:00:05 --> Helper loaded: url_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: file_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: html_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: form_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: text_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:00:05 --> Database Driver Class Initialized
INFO - 2025-03-27 05:00:05 --> Email Class Initialized
INFO - 2025-03-27 05:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:00:05 --> Form Validation Class Initialized
INFO - 2025-03-27 05:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:00:05 --> Pagination Class Initialized
INFO - 2025-03-27 05:00:05 --> Controller Class Initialized
DEBUG - 2025-03-27 05:00:05 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:00:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:00:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:00:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:00:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:00:05 --> Model Class Initialized
ERROR - 2025-03-27 05:00:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:00:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:00:05 --> Final output sent to browser
DEBUG - 2025-03-27 05:00:05 --> Total execution time: 0.1131
INFO - 2025-03-27 05:00:05 --> Config Class Initialized
INFO - 2025-03-27 05:00:05 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:00:05 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:00:05 --> Utf8 Class Initialized
INFO - 2025-03-27 05:00:05 --> URI Class Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:00:05 --> Router Class Initialized
INFO - 2025-03-27 05:00:05 --> Output Class Initialized
INFO - 2025-03-27 05:00:05 --> Security Class Initialized
DEBUG - 2025-03-27 05:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:00:05 --> Input Class Initialized
INFO - 2025-03-27 05:00:05 --> Language Class Initialized
INFO - 2025-03-27 05:00:05 --> Language Class Initialized
INFO - 2025-03-27 05:00:05 --> Config Class Initialized
INFO - 2025-03-27 05:00:05 --> Loader Class Initialized
INFO - 2025-03-27 05:00:05 --> Helper loaded: url_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: file_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: html_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: form_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: text_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:00:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:00:05 --> Database Driver Class Initialized
INFO - 2025-03-27 05:00:05 --> Email Class Initialized
INFO - 2025-03-27 05:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:00:05 --> Form Validation Class Initialized
INFO - 2025-03-27 05:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:00:05 --> Pagination Class Initialized
INFO - 2025-03-27 05:00:05 --> Controller Class Initialized
DEBUG - 2025-03-27 05:00:05 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:00:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:00:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:00:05 --> Model Class Initialized
ERROR - 2025-03-27 05:00:05 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:00:05 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:00:05 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:00:05 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:00:05 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:00:05 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:00:05 --> Final output sent to browser
DEBUG - 2025-03-27 05:00:05 --> Total execution time: 0.0253
INFO - 2025-03-27 05:00:08 --> Config Class Initialized
INFO - 2025-03-27 05:00:08 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:00:08 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:00:08 --> Utf8 Class Initialized
INFO - 2025-03-27 05:00:08 --> URI Class Initialized
DEBUG - 2025-03-27 05:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:00:08 --> Router Class Initialized
INFO - 2025-03-27 05:00:08 --> Output Class Initialized
INFO - 2025-03-27 05:00:08 --> Security Class Initialized
DEBUG - 2025-03-27 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:00:08 --> Input Class Initialized
INFO - 2025-03-27 05:00:08 --> Language Class Initialized
INFO - 2025-03-27 05:00:08 --> Language Class Initialized
INFO - 2025-03-27 05:00:08 --> Config Class Initialized
INFO - 2025-03-27 05:00:08 --> Loader Class Initialized
INFO - 2025-03-27 05:00:08 --> Helper loaded: url_helper
INFO - 2025-03-27 05:00:08 --> Helper loaded: file_helper
INFO - 2025-03-27 05:00:08 --> Helper loaded: html_helper
INFO - 2025-03-27 05:00:08 --> Helper loaded: form_helper
INFO - 2025-03-27 05:00:08 --> Helper loaded: text_helper
INFO - 2025-03-27 05:00:08 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:00:08 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:00:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:00:08 --> Database Driver Class Initialized
INFO - 2025-03-27 05:00:08 --> Email Class Initialized
INFO - 2025-03-27 05:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:00:08 --> Form Validation Class Initialized
INFO - 2025-03-27 05:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:00:08 --> Pagination Class Initialized
INFO - 2025-03-27 05:00:08 --> Controller Class Initialized
DEBUG - 2025-03-27 05:00:08 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:00:08 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:00:08 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:00:08 --> Model Class Initialized
DEBUG - 2025-03-27 05:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:00:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:00:08 --> Model Class Initialized
ERROR - 2025-03-27 05:00:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:00:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:00:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 05:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:00:09 --> Final output sent to browser
DEBUG - 2025-03-27 05:00:09 --> Total execution time: 0.0923
INFO - 2025-03-27 05:04:05 --> Config Class Initialized
INFO - 2025-03-27 05:04:05 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:04:05 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:04:05 --> Utf8 Class Initialized
INFO - 2025-03-27 05:04:05 --> URI Class Initialized
DEBUG - 2025-03-27 05:04:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:04:05 --> Router Class Initialized
INFO - 2025-03-27 05:04:05 --> Output Class Initialized
INFO - 2025-03-27 05:04:05 --> Security Class Initialized
DEBUG - 2025-03-27 05:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:04:05 --> Input Class Initialized
INFO - 2025-03-27 05:04:05 --> Language Class Initialized
INFO - 2025-03-27 05:04:05 --> Language Class Initialized
INFO - 2025-03-27 05:04:05 --> Config Class Initialized
INFO - 2025-03-27 05:04:05 --> Loader Class Initialized
INFO - 2025-03-27 05:04:05 --> Helper loaded: url_helper
INFO - 2025-03-27 05:04:05 --> Helper loaded: file_helper
INFO - 2025-03-27 05:04:05 --> Helper loaded: html_helper
INFO - 2025-03-27 05:04:05 --> Helper loaded: form_helper
INFO - 2025-03-27 05:04:05 --> Helper loaded: text_helper
INFO - 2025-03-27 05:04:05 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:04:05 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:04:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:04:05 --> Database Driver Class Initialized
INFO - 2025-03-27 05:04:05 --> Email Class Initialized
INFO - 2025-03-27 05:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:04:05 --> Form Validation Class Initialized
INFO - 2025-03-27 05:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:04:05 --> Pagination Class Initialized
INFO - 2025-03-27 05:04:05 --> Controller Class Initialized
DEBUG - 2025-03-27 05:04:05 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:04:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:04:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:04:05 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:04:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:04:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:04:05 --> Model Class Initialized
ERROR - 2025-03-27 05:04:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:04:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:04:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:04:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:04:06 --> Final output sent to browser
DEBUG - 2025-03-27 05:04:06 --> Total execution time: 0.1153
INFO - 2025-03-27 05:04:06 --> Config Class Initialized
INFO - 2025-03-27 05:04:06 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:04:06 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:04:06 --> Utf8 Class Initialized
INFO - 2025-03-27 05:04:06 --> URI Class Initialized
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:04:06 --> Router Class Initialized
INFO - 2025-03-27 05:04:06 --> Output Class Initialized
INFO - 2025-03-27 05:04:06 --> Security Class Initialized
DEBUG - 2025-03-27 05:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:04:06 --> Input Class Initialized
INFO - 2025-03-27 05:04:06 --> Language Class Initialized
INFO - 2025-03-27 05:04:06 --> Language Class Initialized
INFO - 2025-03-27 05:04:06 --> Config Class Initialized
INFO - 2025-03-27 05:04:06 --> Loader Class Initialized
INFO - 2025-03-27 05:04:06 --> Helper loaded: url_helper
INFO - 2025-03-27 05:04:06 --> Helper loaded: file_helper
INFO - 2025-03-27 05:04:06 --> Helper loaded: html_helper
INFO - 2025-03-27 05:04:06 --> Helper loaded: form_helper
INFO - 2025-03-27 05:04:06 --> Helper loaded: text_helper
INFO - 2025-03-27 05:04:06 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:04:06 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:04:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:04:06 --> Database Driver Class Initialized
INFO - 2025-03-27 05:04:06 --> Email Class Initialized
INFO - 2025-03-27 05:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:04:06 --> Form Validation Class Initialized
INFO - 2025-03-27 05:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:04:06 --> Pagination Class Initialized
INFO - 2025-03-27 05:04:06 --> Controller Class Initialized
DEBUG - 2025-03-27 05:04:06 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:04:06 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:04:06 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:04:06 --> Model Class Initialized
ERROR - 2025-03-27 05:04:06 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:06 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:06 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:06 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:06 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:06 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:04:06 --> Final output sent to browser
DEBUG - 2025-03-27 05:04:06 --> Total execution time: 0.0341
INFO - 2025-03-27 05:04:09 --> Config Class Initialized
INFO - 2025-03-27 05:04:09 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:04:09 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:04:09 --> Utf8 Class Initialized
INFO - 2025-03-27 05:04:09 --> URI Class Initialized
DEBUG - 2025-03-27 05:04:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:04:09 --> Router Class Initialized
INFO - 2025-03-27 05:04:09 --> Output Class Initialized
INFO - 2025-03-27 05:04:09 --> Security Class Initialized
DEBUG - 2025-03-27 05:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:04:09 --> Input Class Initialized
INFO - 2025-03-27 05:04:09 --> Language Class Initialized
INFO - 2025-03-27 05:04:09 --> Language Class Initialized
INFO - 2025-03-27 05:04:09 --> Config Class Initialized
INFO - 2025-03-27 05:04:09 --> Loader Class Initialized
INFO - 2025-03-27 05:04:09 --> Helper loaded: url_helper
INFO - 2025-03-27 05:04:09 --> Helper loaded: file_helper
INFO - 2025-03-27 05:04:09 --> Helper loaded: html_helper
INFO - 2025-03-27 05:04:09 --> Helper loaded: form_helper
INFO - 2025-03-27 05:04:09 --> Helper loaded: text_helper
INFO - 2025-03-27 05:04:09 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:04:09 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:04:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:04:09 --> Database Driver Class Initialized
INFO - 2025-03-27 05:04:09 --> Email Class Initialized
INFO - 2025-03-27 05:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:04:09 --> Form Validation Class Initialized
INFO - 2025-03-27 05:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:04:09 --> Pagination Class Initialized
INFO - 2025-03-27 05:04:09 --> Controller Class Initialized
DEBUG - 2025-03-27 05:04:09 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:04:09 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:04:09 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:04:09 --> Model Class Initialized
ERROR - 2025-03-27 05:04:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 447
INFO - 2025-03-27 05:04:11 --> Config Class Initialized
INFO - 2025-03-27 05:04:11 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:04:11 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:04:11 --> Utf8 Class Initialized
INFO - 2025-03-27 05:04:11 --> URI Class Initialized
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:04:11 --> Router Class Initialized
INFO - 2025-03-27 05:04:11 --> Output Class Initialized
INFO - 2025-03-27 05:04:11 --> Security Class Initialized
DEBUG - 2025-03-27 05:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:04:11 --> Input Class Initialized
INFO - 2025-03-27 05:04:11 --> Language Class Initialized
INFO - 2025-03-27 05:04:11 --> Language Class Initialized
INFO - 2025-03-27 05:04:11 --> Config Class Initialized
INFO - 2025-03-27 05:04:11 --> Loader Class Initialized
INFO - 2025-03-27 05:04:11 --> Helper loaded: url_helper
INFO - 2025-03-27 05:04:11 --> Helper loaded: file_helper
INFO - 2025-03-27 05:04:11 --> Helper loaded: html_helper
INFO - 2025-03-27 05:04:11 --> Helper loaded: form_helper
INFO - 2025-03-27 05:04:11 --> Helper loaded: text_helper
INFO - 2025-03-27 05:04:11 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:04:11 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:04:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:04:11 --> Database Driver Class Initialized
INFO - 2025-03-27 05:04:11 --> Email Class Initialized
INFO - 2025-03-27 05:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:04:11 --> Form Validation Class Initialized
INFO - 2025-03-27 05:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:04:11 --> Pagination Class Initialized
INFO - 2025-03-27 05:04:11 --> Controller Class Initialized
DEBUG - 2025-03-27 05:04:11 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:04:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:04:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:04:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:04:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:04:11 --> Model Class Initialized
ERROR - 2025-03-27 05:04:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:04:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:04:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:04:11 --> Final output sent to browser
DEBUG - 2025-03-27 05:04:11 --> Total execution time: 0.1092
INFO - 2025-03-27 05:04:12 --> Config Class Initialized
INFO - 2025-03-27 05:04:12 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:04:12 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:04:12 --> Utf8 Class Initialized
INFO - 2025-03-27 05:04:12 --> URI Class Initialized
DEBUG - 2025-03-27 05:04:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:04:12 --> Router Class Initialized
INFO - 2025-03-27 05:04:12 --> Output Class Initialized
INFO - 2025-03-27 05:04:12 --> Security Class Initialized
DEBUG - 2025-03-27 05:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:04:12 --> Input Class Initialized
INFO - 2025-03-27 05:04:12 --> Language Class Initialized
INFO - 2025-03-27 05:04:12 --> Language Class Initialized
INFO - 2025-03-27 05:04:12 --> Config Class Initialized
INFO - 2025-03-27 05:04:12 --> Loader Class Initialized
INFO - 2025-03-27 05:04:12 --> Helper loaded: url_helper
INFO - 2025-03-27 05:04:12 --> Helper loaded: file_helper
INFO - 2025-03-27 05:04:12 --> Helper loaded: html_helper
INFO - 2025-03-27 05:04:12 --> Helper loaded: form_helper
INFO - 2025-03-27 05:04:12 --> Helper loaded: text_helper
INFO - 2025-03-27 05:04:12 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:04:12 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:04:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:04:12 --> Database Driver Class Initialized
INFO - 2025-03-27 05:04:12 --> Email Class Initialized
INFO - 2025-03-27 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:04:12 --> Form Validation Class Initialized
INFO - 2025-03-27 05:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:04:12 --> Pagination Class Initialized
INFO - 2025-03-27 05:04:12 --> Controller Class Initialized
DEBUG - 2025-03-27 05:04:12 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:04:12 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:04:12 --> Model Class Initialized
DEBUG - 2025-03-27 05:04:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:04:12 --> Model Class Initialized
ERROR - 2025-03-27 05:04:12 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:12 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:12 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:12 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:12 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:04:12 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:04:12 --> Final output sent to browser
DEBUG - 2025-03-27 05:04:12 --> Total execution time: 0.0403
INFO - 2025-03-27 05:05:45 --> Config Class Initialized
INFO - 2025-03-27 05:05:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:05:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:05:45 --> Utf8 Class Initialized
INFO - 2025-03-27 05:05:45 --> URI Class Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:05:45 --> Router Class Initialized
INFO - 2025-03-27 05:05:45 --> Output Class Initialized
INFO - 2025-03-27 05:05:45 --> Security Class Initialized
DEBUG - 2025-03-27 05:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:05:45 --> Input Class Initialized
INFO - 2025-03-27 05:05:45 --> Language Class Initialized
INFO - 2025-03-27 05:05:45 --> Language Class Initialized
INFO - 2025-03-27 05:05:45 --> Config Class Initialized
INFO - 2025-03-27 05:05:45 --> Loader Class Initialized
INFO - 2025-03-27 05:05:45 --> Helper loaded: url_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: file_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: html_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: form_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: text_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:05:45 --> Database Driver Class Initialized
INFO - 2025-03-27 05:05:45 --> Email Class Initialized
INFO - 2025-03-27 05:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:05:45 --> Form Validation Class Initialized
INFO - 2025-03-27 05:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:05:45 --> Pagination Class Initialized
INFO - 2025-03-27 05:05:45 --> Controller Class Initialized
DEBUG - 2025-03-27 05:05:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:05:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:05:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:05:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:05:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:05:45 --> Model Class Initialized
ERROR - 2025-03-27 05:05:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:05:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:05:45 --> Final output sent to browser
DEBUG - 2025-03-27 05:05:45 --> Total execution time: 0.1043
INFO - 2025-03-27 05:05:45 --> Config Class Initialized
INFO - 2025-03-27 05:05:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:05:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:05:45 --> Utf8 Class Initialized
INFO - 2025-03-27 05:05:45 --> URI Class Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:05:45 --> Router Class Initialized
INFO - 2025-03-27 05:05:45 --> Output Class Initialized
INFO - 2025-03-27 05:05:45 --> Security Class Initialized
DEBUG - 2025-03-27 05:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:05:45 --> Input Class Initialized
INFO - 2025-03-27 05:05:45 --> Language Class Initialized
INFO - 2025-03-27 05:05:45 --> Language Class Initialized
INFO - 2025-03-27 05:05:45 --> Config Class Initialized
INFO - 2025-03-27 05:05:45 --> Loader Class Initialized
INFO - 2025-03-27 05:05:45 --> Helper loaded: url_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: file_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: html_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: form_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: text_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:05:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:05:45 --> Database Driver Class Initialized
INFO - 2025-03-27 05:05:45 --> Email Class Initialized
INFO - 2025-03-27 05:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:05:45 --> Form Validation Class Initialized
INFO - 2025-03-27 05:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:05:45 --> Pagination Class Initialized
INFO - 2025-03-27 05:05:45 --> Controller Class Initialized
DEBUG - 2025-03-27 05:05:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:05:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:05:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:05:45 --> Model Class Initialized
ERROR - 2025-03-27 05:05:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:45 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:05:45 --> Final output sent to browser
DEBUG - 2025-03-27 05:05:45 --> Total execution time: 0.0307
INFO - 2025-03-27 05:05:49 --> Config Class Initialized
INFO - 2025-03-27 05:05:49 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:05:49 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:05:49 --> Utf8 Class Initialized
INFO - 2025-03-27 05:05:49 --> URI Class Initialized
DEBUG - 2025-03-27 05:05:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:05:49 --> Router Class Initialized
INFO - 2025-03-27 05:05:49 --> Output Class Initialized
INFO - 2025-03-27 05:05:49 --> Security Class Initialized
DEBUG - 2025-03-27 05:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:05:49 --> Input Class Initialized
INFO - 2025-03-27 05:05:49 --> Language Class Initialized
INFO - 2025-03-27 05:05:49 --> Language Class Initialized
INFO - 2025-03-27 05:05:49 --> Config Class Initialized
INFO - 2025-03-27 05:05:49 --> Loader Class Initialized
INFO - 2025-03-27 05:05:49 --> Helper loaded: url_helper
INFO - 2025-03-27 05:05:49 --> Helper loaded: file_helper
INFO - 2025-03-27 05:05:49 --> Helper loaded: html_helper
INFO - 2025-03-27 05:05:49 --> Helper loaded: form_helper
INFO - 2025-03-27 05:05:49 --> Helper loaded: text_helper
INFO - 2025-03-27 05:05:49 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:05:49 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:05:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:05:49 --> Database Driver Class Initialized
INFO - 2025-03-27 05:05:49 --> Email Class Initialized
INFO - 2025-03-27 05:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:05:49 --> Form Validation Class Initialized
INFO - 2025-03-27 05:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:05:49 --> Pagination Class Initialized
INFO - 2025-03-27 05:05:49 --> Controller Class Initialized
DEBUG - 2025-03-27 05:05:49 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:05:49 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:05:49 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:05:49 --> Model Class Initialized
ERROR - 2025-03-27 05:05:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 447
INFO - 2025-03-27 05:05:52 --> Config Class Initialized
INFO - 2025-03-27 05:05:52 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:05:52 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:05:52 --> Utf8 Class Initialized
INFO - 2025-03-27 05:05:52 --> URI Class Initialized
DEBUG - 2025-03-27 05:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:05:52 --> Router Class Initialized
INFO - 2025-03-27 05:05:52 --> Output Class Initialized
INFO - 2025-03-27 05:05:52 --> Security Class Initialized
DEBUG - 2025-03-27 05:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:05:52 --> Input Class Initialized
INFO - 2025-03-27 05:05:52 --> Language Class Initialized
INFO - 2025-03-27 05:05:52 --> Language Class Initialized
INFO - 2025-03-27 05:05:52 --> Config Class Initialized
INFO - 2025-03-27 05:05:52 --> Loader Class Initialized
INFO - 2025-03-27 05:05:52 --> Helper loaded: url_helper
INFO - 2025-03-27 05:05:52 --> Helper loaded: file_helper
INFO - 2025-03-27 05:05:52 --> Helper loaded: html_helper
INFO - 2025-03-27 05:05:52 --> Helper loaded: form_helper
INFO - 2025-03-27 05:05:52 --> Helper loaded: text_helper
INFO - 2025-03-27 05:05:52 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:05:52 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:05:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:05:52 --> Database Driver Class Initialized
INFO - 2025-03-27 05:05:52 --> Email Class Initialized
INFO - 2025-03-27 05:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:05:52 --> Form Validation Class Initialized
INFO - 2025-03-27 05:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:05:52 --> Pagination Class Initialized
INFO - 2025-03-27 05:05:52 --> Controller Class Initialized
DEBUG - 2025-03-27 05:05:52 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:05:52 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:05:52 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:05:52 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:05:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:05:52 --> Model Class Initialized
ERROR - 2025-03-27 05:05:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:05:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:05:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:05:53 --> Final output sent to browser
DEBUG - 2025-03-27 05:05:53 --> Total execution time: 0.1133
INFO - 2025-03-27 05:05:53 --> Config Class Initialized
INFO - 2025-03-27 05:05:53 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:05:53 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:05:53 --> Utf8 Class Initialized
INFO - 2025-03-27 05:05:53 --> URI Class Initialized
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:05:53 --> Router Class Initialized
INFO - 2025-03-27 05:05:53 --> Output Class Initialized
INFO - 2025-03-27 05:05:53 --> Security Class Initialized
DEBUG - 2025-03-27 05:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:05:53 --> Input Class Initialized
INFO - 2025-03-27 05:05:53 --> Language Class Initialized
INFO - 2025-03-27 05:05:53 --> Language Class Initialized
INFO - 2025-03-27 05:05:53 --> Config Class Initialized
INFO - 2025-03-27 05:05:53 --> Loader Class Initialized
INFO - 2025-03-27 05:05:53 --> Helper loaded: url_helper
INFO - 2025-03-27 05:05:53 --> Helper loaded: file_helper
INFO - 2025-03-27 05:05:53 --> Helper loaded: html_helper
INFO - 2025-03-27 05:05:53 --> Helper loaded: form_helper
INFO - 2025-03-27 05:05:53 --> Helper loaded: text_helper
INFO - 2025-03-27 05:05:53 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:05:53 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:05:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:05:53 --> Database Driver Class Initialized
INFO - 2025-03-27 05:05:53 --> Email Class Initialized
INFO - 2025-03-27 05:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:05:53 --> Form Validation Class Initialized
INFO - 2025-03-27 05:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:05:53 --> Pagination Class Initialized
INFO - 2025-03-27 05:05:53 --> Controller Class Initialized
DEBUG - 2025-03-27 05:05:53 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:05:53 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:05:53 --> Model Class Initialized
DEBUG - 2025-03-27 05:05:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:05:53 --> Model Class Initialized
ERROR - 2025-03-27 05:05:53 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:53 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:53 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:53 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:53 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:05:53 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:05:53 --> Final output sent to browser
DEBUG - 2025-03-27 05:05:53 --> Total execution time: 0.0362
INFO - 2025-03-27 05:06:42 --> Config Class Initialized
INFO - 2025-03-27 05:06:42 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:06:42 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:06:42 --> Utf8 Class Initialized
INFO - 2025-03-27 05:06:42 --> URI Class Initialized
DEBUG - 2025-03-27 05:06:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:06:42 --> Router Class Initialized
INFO - 2025-03-27 05:06:42 --> Output Class Initialized
INFO - 2025-03-27 05:06:42 --> Security Class Initialized
DEBUG - 2025-03-27 05:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:06:42 --> Input Class Initialized
INFO - 2025-03-27 05:06:42 --> Language Class Initialized
INFO - 2025-03-27 05:06:42 --> Language Class Initialized
INFO - 2025-03-27 05:06:42 --> Config Class Initialized
INFO - 2025-03-27 05:06:42 --> Loader Class Initialized
INFO - 2025-03-27 05:06:42 --> Helper loaded: url_helper
INFO - 2025-03-27 05:06:42 --> Helper loaded: file_helper
INFO - 2025-03-27 05:06:42 --> Helper loaded: html_helper
INFO - 2025-03-27 05:06:42 --> Helper loaded: form_helper
INFO - 2025-03-27 05:06:42 --> Helper loaded: text_helper
INFO - 2025-03-27 05:06:42 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:06:42 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:06:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:06:42 --> Database Driver Class Initialized
INFO - 2025-03-27 05:06:42 --> Email Class Initialized
INFO - 2025-03-27 05:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:06:42 --> Form Validation Class Initialized
INFO - 2025-03-27 05:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:06:42 --> Pagination Class Initialized
INFO - 2025-03-27 05:06:42 --> Controller Class Initialized
DEBUG - 2025-03-27 05:06:42 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:06:42 --> Model Class Initialized
DEBUG - 2025-03-27 05:06:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:06:42 --> Model Class Initialized
DEBUG - 2025-03-27 05:06:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:06:42 --> Model Class Initialized
ERROR - 2025-03-27 05:06:42 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 447
INFO - 2025-03-27 05:09:00 --> Config Class Initialized
INFO - 2025-03-27 05:09:00 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:00 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:00 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:00 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:00 --> Router Class Initialized
INFO - 2025-03-27 05:09:00 --> Output Class Initialized
INFO - 2025-03-27 05:09:00 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:00 --> Input Class Initialized
INFO - 2025-03-27 05:09:00 --> Language Class Initialized
INFO - 2025-03-27 05:09:00 --> Language Class Initialized
INFO - 2025-03-27 05:09:00 --> Config Class Initialized
INFO - 2025-03-27 05:09:00 --> Loader Class Initialized
INFO - 2025-03-27 05:09:00 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:00 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:00 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:00 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:00 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:00 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:00 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:00 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:00 --> Email Class Initialized
INFO - 2025-03-27 05:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:00 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:00 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:00 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:00 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:00 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:00 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:00 --> Model Class Initialized
ERROR - 2025-03-27 05:09:00 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 428
INFO - 2025-03-27 05:09:01 --> Config Class Initialized
INFO - 2025-03-27 05:09:01 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:01 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:01 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:01 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:01 --> Router Class Initialized
INFO - 2025-03-27 05:09:01 --> Output Class Initialized
INFO - 2025-03-27 05:09:01 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:01 --> Input Class Initialized
INFO - 2025-03-27 05:09:01 --> Language Class Initialized
INFO - 2025-03-27 05:09:01 --> Language Class Initialized
INFO - 2025-03-27 05:09:01 --> Config Class Initialized
INFO - 2025-03-27 05:09:01 --> Loader Class Initialized
INFO - 2025-03-27 05:09:01 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:01 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:01 --> Email Class Initialized
INFO - 2025-03-27 05:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:01 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:01 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:01 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:01 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:01 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:01 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:01 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:09:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:09:01 --> Model Class Initialized
ERROR - 2025-03-27 05:09:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:09:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:09:01 --> Final output sent to browser
DEBUG - 2025-03-27 05:09:01 --> Total execution time: 0.0852
INFO - 2025-03-27 05:09:01 --> Config Class Initialized
INFO - 2025-03-27 05:09:01 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:01 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:01 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:01 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:01 --> Router Class Initialized
INFO - 2025-03-27 05:09:01 --> Output Class Initialized
INFO - 2025-03-27 05:09:01 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:01 --> Input Class Initialized
INFO - 2025-03-27 05:09:01 --> Language Class Initialized
INFO - 2025-03-27 05:09:01 --> Language Class Initialized
INFO - 2025-03-27 05:09:01 --> Config Class Initialized
INFO - 2025-03-27 05:09:01 --> Loader Class Initialized
INFO - 2025-03-27 05:09:01 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:01 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:01 --> Email Class Initialized
INFO - 2025-03-27 05:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:01 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:01 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:01 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:01 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:01 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:01 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:01 --> Model Class Initialized
ERROR - 2025-03-27 05:09:01 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

        )

)

INFO - 2025-03-27 05:09:01 --> Final output sent to browser
DEBUG - 2025-03-27 05:09:01 --> Total execution time: 0.0391
INFO - 2025-03-27 05:09:04 --> Config Class Initialized
INFO - 2025-03-27 05:09:04 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:04 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:04 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:04 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:04 --> Router Class Initialized
INFO - 2025-03-27 05:09:04 --> Output Class Initialized
INFO - 2025-03-27 05:09:04 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:04 --> Input Class Initialized
INFO - 2025-03-27 05:09:04 --> Language Class Initialized
INFO - 2025-03-27 05:09:04 --> Language Class Initialized
INFO - 2025-03-27 05:09:04 --> Config Class Initialized
INFO - 2025-03-27 05:09:04 --> Loader Class Initialized
INFO - 2025-03-27 05:09:04 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:04 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:04 --> Email Class Initialized
INFO - 2025-03-27 05:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:04 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:04 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:04 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:04 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:04 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:04 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:04 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:09:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:09:04 --> Model Class Initialized
ERROR - 2025-03-27 05:09:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:09:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:09:04 --> Final output sent to browser
DEBUG - 2025-03-27 05:09:04 --> Total execution time: 0.1218
INFO - 2025-03-27 05:09:04 --> Config Class Initialized
INFO - 2025-03-27 05:09:04 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:04 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:04 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:04 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:04 --> Router Class Initialized
INFO - 2025-03-27 05:09:04 --> Output Class Initialized
INFO - 2025-03-27 05:09:04 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:04 --> Input Class Initialized
INFO - 2025-03-27 05:09:04 --> Language Class Initialized
INFO - 2025-03-27 05:09:04 --> Language Class Initialized
INFO - 2025-03-27 05:09:04 --> Config Class Initialized
INFO - 2025-03-27 05:09:04 --> Loader Class Initialized
INFO - 2025-03-27 05:09:04 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:04 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:04 --> Email Class Initialized
INFO - 2025-03-27 05:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:04 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:04 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:04 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:04 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:04 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:04 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:04 --> Model Class Initialized
ERROR - 2025-03-27 05:09:04 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

        )

)

INFO - 2025-03-27 05:09:04 --> Final output sent to browser
DEBUG - 2025-03-27 05:09:04 --> Total execution time: 0.0354
INFO - 2025-03-27 05:09:07 --> Config Class Initialized
INFO - 2025-03-27 05:09:07 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:07 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:07 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:07 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:07 --> Router Class Initialized
INFO - 2025-03-27 05:09:07 --> Output Class Initialized
INFO - 2025-03-27 05:09:07 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:07 --> Input Class Initialized
INFO - 2025-03-27 05:09:07 --> Language Class Initialized
INFO - 2025-03-27 05:09:07 --> Language Class Initialized
INFO - 2025-03-27 05:09:07 --> Config Class Initialized
INFO - 2025-03-27 05:09:07 --> Loader Class Initialized
INFO - 2025-03-27 05:09:07 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:07 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:07 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:07 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:07 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:07 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:07 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:07 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:07 --> Email Class Initialized
INFO - 2025-03-27 05:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:07 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:07 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:07 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:07 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:07 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:07 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:07 --> Model Class Initialized
ERROR - 2025-03-27 05:09:07 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 428
INFO - 2025-03-27 05:09:26 --> Config Class Initialized
INFO - 2025-03-27 05:09:26 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:26 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:26 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:26 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:26 --> Router Class Initialized
INFO - 2025-03-27 05:09:26 --> Output Class Initialized
INFO - 2025-03-27 05:09:26 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:26 --> Input Class Initialized
INFO - 2025-03-27 05:09:26 --> Language Class Initialized
INFO - 2025-03-27 05:09:26 --> Language Class Initialized
INFO - 2025-03-27 05:09:26 --> Config Class Initialized
INFO - 2025-03-27 05:09:26 --> Loader Class Initialized
INFO - 2025-03-27 05:09:26 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:26 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:26 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:26 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:26 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:26 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:26 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:26 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:26 --> Email Class Initialized
INFO - 2025-03-27 05:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:26 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:26 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:26 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:26 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:26 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:26 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:26 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:09:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:09:26 --> Model Class Initialized
ERROR - 2025-03-27 05:09:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:09:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:09:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:09:26 --> Final output sent to browser
DEBUG - 2025-03-27 05:09:26 --> Total execution time: 0.1602
INFO - 2025-03-27 05:09:27 --> Config Class Initialized
INFO - 2025-03-27 05:09:27 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:27 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:27 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:27 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:27 --> Router Class Initialized
INFO - 2025-03-27 05:09:27 --> Output Class Initialized
INFO - 2025-03-27 05:09:27 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:27 --> Input Class Initialized
INFO - 2025-03-27 05:09:27 --> Language Class Initialized
INFO - 2025-03-27 05:09:27 --> Language Class Initialized
INFO - 2025-03-27 05:09:27 --> Config Class Initialized
INFO - 2025-03-27 05:09:27 --> Loader Class Initialized
INFO - 2025-03-27 05:09:27 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:27 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:27 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:27 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:27 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:27 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:27 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:27 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:27 --> Email Class Initialized
INFO - 2025-03-27 05:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:27 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:27 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:27 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:27 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:27 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:27 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:27 --> Model Class Initialized
ERROR - 2025-03-27 05:09:27 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a> <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="Qr-Code"><i class="fa fa-qrcode"></i></a> <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil"></i></a>
                )

        )

)

INFO - 2025-03-27 05:09:27 --> Final output sent to browser
DEBUG - 2025-03-27 05:09:27 --> Total execution time: 0.0345
INFO - 2025-03-27 05:09:32 --> Config Class Initialized
INFO - 2025-03-27 05:09:32 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:09:32 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:09:32 --> Utf8 Class Initialized
INFO - 2025-03-27 05:09:32 --> URI Class Initialized
DEBUG - 2025-03-27 05:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:09:32 --> Router Class Initialized
INFO - 2025-03-27 05:09:32 --> Output Class Initialized
INFO - 2025-03-27 05:09:32 --> Security Class Initialized
DEBUG - 2025-03-27 05:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:09:32 --> Input Class Initialized
INFO - 2025-03-27 05:09:32 --> Language Class Initialized
INFO - 2025-03-27 05:09:32 --> Language Class Initialized
INFO - 2025-03-27 05:09:32 --> Config Class Initialized
INFO - 2025-03-27 05:09:32 --> Loader Class Initialized
INFO - 2025-03-27 05:09:32 --> Helper loaded: url_helper
INFO - 2025-03-27 05:09:32 --> Helper loaded: file_helper
INFO - 2025-03-27 05:09:32 --> Helper loaded: html_helper
INFO - 2025-03-27 05:09:32 --> Helper loaded: form_helper
INFO - 2025-03-27 05:09:32 --> Helper loaded: text_helper
INFO - 2025-03-27 05:09:32 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:09:32 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:09:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:09:32 --> Database Driver Class Initialized
INFO - 2025-03-27 05:09:32 --> Email Class Initialized
INFO - 2025-03-27 05:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:09:32 --> Form Validation Class Initialized
INFO - 2025-03-27 05:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:09:32 --> Pagination Class Initialized
INFO - 2025-03-27 05:09:32 --> Controller Class Initialized
DEBUG - 2025-03-27 05:09:32 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:09:32 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:09:32 --> Model Class Initialized
DEBUG - 2025-03-27 05:09:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:09:32 --> Model Class Initialized
ERROR - 2025-03-27 05:09:32 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 428
INFO - 2025-03-27 05:11:21 --> Config Class Initialized
INFO - 2025-03-27 05:11:21 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:11:21 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:11:21 --> Utf8 Class Initialized
INFO - 2025-03-27 05:11:21 --> URI Class Initialized
DEBUG - 2025-03-27 05:11:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:11:21 --> Router Class Initialized
INFO - 2025-03-27 05:11:21 --> Output Class Initialized
INFO - 2025-03-27 05:11:21 --> Security Class Initialized
DEBUG - 2025-03-27 05:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:11:21 --> Input Class Initialized
INFO - 2025-03-27 05:11:21 --> Language Class Initialized
INFO - 2025-03-27 05:11:21 --> Language Class Initialized
INFO - 2025-03-27 05:11:21 --> Config Class Initialized
INFO - 2025-03-27 05:11:21 --> Loader Class Initialized
INFO - 2025-03-27 05:11:21 --> Helper loaded: url_helper
INFO - 2025-03-27 05:11:21 --> Helper loaded: file_helper
INFO - 2025-03-27 05:11:21 --> Helper loaded: html_helper
INFO - 2025-03-27 05:11:21 --> Helper loaded: form_helper
INFO - 2025-03-27 05:11:21 --> Helper loaded: text_helper
INFO - 2025-03-27 05:11:21 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:11:21 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:11:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:11:21 --> Database Driver Class Initialized
INFO - 2025-03-27 05:11:21 --> Email Class Initialized
INFO - 2025-03-27 05:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:11:21 --> Form Validation Class Initialized
INFO - 2025-03-27 05:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:11:21 --> Pagination Class Initialized
INFO - 2025-03-27 05:11:21 --> Controller Class Initialized
DEBUG - 2025-03-27 05:11:21 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:11:21 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:11:21 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:11:21 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:11:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:11:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:11:21 --> Model Class Initialized
ERROR - 2025-03-27 05:11:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:11:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:11:22 --> Final output sent to browser
DEBUG - 2025-03-27 05:11:22 --> Total execution time: 0.1183
INFO - 2025-03-27 05:11:22 --> Config Class Initialized
INFO - 2025-03-27 05:11:22 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:11:22 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:11:22 --> Utf8 Class Initialized
INFO - 2025-03-27 05:11:22 --> URI Class Initialized
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:11:22 --> Router Class Initialized
INFO - 2025-03-27 05:11:22 --> Output Class Initialized
INFO - 2025-03-27 05:11:22 --> Security Class Initialized
DEBUG - 2025-03-27 05:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:11:22 --> Input Class Initialized
INFO - 2025-03-27 05:11:22 --> Language Class Initialized
INFO - 2025-03-27 05:11:22 --> Language Class Initialized
INFO - 2025-03-27 05:11:22 --> Config Class Initialized
INFO - 2025-03-27 05:11:22 --> Loader Class Initialized
INFO - 2025-03-27 05:11:22 --> Helper loaded: url_helper
INFO - 2025-03-27 05:11:22 --> Helper loaded: file_helper
INFO - 2025-03-27 05:11:22 --> Helper loaded: html_helper
INFO - 2025-03-27 05:11:22 --> Helper loaded: form_helper
INFO - 2025-03-27 05:11:22 --> Helper loaded: text_helper
INFO - 2025-03-27 05:11:22 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:11:22 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:11:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:11:22 --> Database Driver Class Initialized
INFO - 2025-03-27 05:11:22 --> Email Class Initialized
INFO - 2025-03-27 05:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:11:22 --> Form Validation Class Initialized
INFO - 2025-03-27 05:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:11:22 --> Pagination Class Initialized
INFO - 2025-03-27 05:11:22 --> Controller Class Initialized
DEBUG - 2025-03-27 05:11:22 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:11:22 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:11:22 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:11:22 --> Model Class Initialized
ERROR - 2025-03-27 05:11:22 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:22 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:22 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:22 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:22 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:22 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:11:22 --> Final output sent to browser
DEBUG - 2025-03-27 05:11:22 --> Total execution time: 0.0450
INFO - 2025-03-27 05:11:24 --> Config Class Initialized
INFO - 2025-03-27 05:11:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:11:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:11:24 --> Utf8 Class Initialized
INFO - 2025-03-27 05:11:24 --> URI Class Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:11:24 --> Router Class Initialized
INFO - 2025-03-27 05:11:24 --> Output Class Initialized
INFO - 2025-03-27 05:11:24 --> Security Class Initialized
DEBUG - 2025-03-27 05:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:11:24 --> Input Class Initialized
INFO - 2025-03-27 05:11:24 --> Language Class Initialized
INFO - 2025-03-27 05:11:24 --> Language Class Initialized
INFO - 2025-03-27 05:11:24 --> Config Class Initialized
INFO - 2025-03-27 05:11:24 --> Loader Class Initialized
INFO - 2025-03-27 05:11:24 --> Helper loaded: url_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: file_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: html_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: form_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: text_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:11:24 --> Database Driver Class Initialized
INFO - 2025-03-27 05:11:24 --> Email Class Initialized
INFO - 2025-03-27 05:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:11:24 --> Form Validation Class Initialized
INFO - 2025-03-27 05:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:11:24 --> Pagination Class Initialized
INFO - 2025-03-27 05:11:24 --> Controller Class Initialized
DEBUG - 2025-03-27 05:11:24 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:11:24 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:11:24 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:11:24 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:11:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:11:24 --> Model Class Initialized
ERROR - 2025-03-27 05:11:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:11:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:11:24 --> Final output sent to browser
DEBUG - 2025-03-27 05:11:24 --> Total execution time: 0.1244
INFO - 2025-03-27 05:11:24 --> Config Class Initialized
INFO - 2025-03-27 05:11:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:11:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:11:24 --> Utf8 Class Initialized
INFO - 2025-03-27 05:11:24 --> URI Class Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:11:24 --> Router Class Initialized
INFO - 2025-03-27 05:11:24 --> Output Class Initialized
INFO - 2025-03-27 05:11:24 --> Security Class Initialized
DEBUG - 2025-03-27 05:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:11:24 --> Input Class Initialized
INFO - 2025-03-27 05:11:24 --> Language Class Initialized
INFO - 2025-03-27 05:11:24 --> Language Class Initialized
INFO - 2025-03-27 05:11:24 --> Config Class Initialized
INFO - 2025-03-27 05:11:24 --> Loader Class Initialized
INFO - 2025-03-27 05:11:24 --> Helper loaded: url_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: file_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: html_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: form_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: text_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:11:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:11:24 --> Database Driver Class Initialized
INFO - 2025-03-27 05:11:24 --> Email Class Initialized
INFO - 2025-03-27 05:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:11:24 --> Form Validation Class Initialized
INFO - 2025-03-27 05:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:11:24 --> Pagination Class Initialized
INFO - 2025-03-27 05:11:24 --> Controller Class Initialized
DEBUG - 2025-03-27 05:11:24 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:11:24 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:11:24 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:11:24 --> Model Class Initialized
ERROR - 2025-03-27 05:11:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:24 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:11:24 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:11:24 --> Final output sent to browser
DEBUG - 2025-03-27 05:11:24 --> Total execution time: 0.0435
INFO - 2025-03-27 05:11:26 --> Config Class Initialized
INFO - 2025-03-27 05:11:26 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:11:26 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:11:26 --> Utf8 Class Initialized
INFO - 2025-03-27 05:11:26 --> URI Class Initialized
DEBUG - 2025-03-27 05:11:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:11:26 --> Router Class Initialized
INFO - 2025-03-27 05:11:26 --> Output Class Initialized
INFO - 2025-03-27 05:11:26 --> Security Class Initialized
DEBUG - 2025-03-27 05:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:11:26 --> Input Class Initialized
INFO - 2025-03-27 05:11:26 --> Language Class Initialized
INFO - 2025-03-27 05:11:26 --> Language Class Initialized
INFO - 2025-03-27 05:11:26 --> Config Class Initialized
INFO - 2025-03-27 05:11:26 --> Loader Class Initialized
INFO - 2025-03-27 05:11:26 --> Helper loaded: url_helper
INFO - 2025-03-27 05:11:26 --> Helper loaded: file_helper
INFO - 2025-03-27 05:11:26 --> Helper loaded: html_helper
INFO - 2025-03-27 05:11:26 --> Helper loaded: form_helper
INFO - 2025-03-27 05:11:26 --> Helper loaded: text_helper
INFO - 2025-03-27 05:11:26 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:11:26 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:11:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:11:26 --> Database Driver Class Initialized
INFO - 2025-03-27 05:11:26 --> Email Class Initialized
INFO - 2025-03-27 05:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:11:26 --> Form Validation Class Initialized
INFO - 2025-03-27 05:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:11:26 --> Pagination Class Initialized
INFO - 2025-03-27 05:11:26 --> Controller Class Initialized
DEBUG - 2025-03-27 05:11:26 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:11:26 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:11:26 --> Model Class Initialized
DEBUG - 2025-03-27 05:11:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:11:26 --> Model Class Initialized
ERROR - 2025-03-27 05:11:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 447
INFO - 2025-03-27 05:12:41 --> Config Class Initialized
INFO - 2025-03-27 05:12:41 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:12:41 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:12:41 --> Utf8 Class Initialized
INFO - 2025-03-27 05:12:41 --> URI Class Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:12:41 --> Router Class Initialized
INFO - 2025-03-27 05:12:41 --> Output Class Initialized
INFO - 2025-03-27 05:12:41 --> Security Class Initialized
DEBUG - 2025-03-27 05:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:12:41 --> Input Class Initialized
INFO - 2025-03-27 05:12:41 --> Language Class Initialized
INFO - 2025-03-27 05:12:41 --> Language Class Initialized
INFO - 2025-03-27 05:12:41 --> Config Class Initialized
INFO - 2025-03-27 05:12:41 --> Loader Class Initialized
INFO - 2025-03-27 05:12:41 --> Helper loaded: url_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: file_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: html_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: form_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: text_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:12:41 --> Database Driver Class Initialized
INFO - 2025-03-27 05:12:41 --> Email Class Initialized
INFO - 2025-03-27 05:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:12:41 --> Form Validation Class Initialized
INFO - 2025-03-27 05:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:12:41 --> Pagination Class Initialized
INFO - 2025-03-27 05:12:41 --> Controller Class Initialized
DEBUG - 2025-03-27 05:12:41 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:12:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:12:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:12:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:12:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:12:41 --> Model Class Initialized
ERROR - 2025-03-27 05:12:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:12:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:12:41 --> Final output sent to browser
DEBUG - 2025-03-27 05:12:41 --> Total execution time: 0.1096
INFO - 2025-03-27 05:12:41 --> Config Class Initialized
INFO - 2025-03-27 05:12:41 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:12:41 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:12:41 --> Utf8 Class Initialized
INFO - 2025-03-27 05:12:41 --> URI Class Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:12:41 --> Router Class Initialized
INFO - 2025-03-27 05:12:41 --> Output Class Initialized
INFO - 2025-03-27 05:12:41 --> Security Class Initialized
DEBUG - 2025-03-27 05:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:12:41 --> Input Class Initialized
INFO - 2025-03-27 05:12:41 --> Language Class Initialized
INFO - 2025-03-27 05:12:41 --> Language Class Initialized
INFO - 2025-03-27 05:12:41 --> Config Class Initialized
INFO - 2025-03-27 05:12:41 --> Loader Class Initialized
INFO - 2025-03-27 05:12:41 --> Helper loaded: url_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: file_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: html_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: form_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: text_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:12:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:12:41 --> Database Driver Class Initialized
INFO - 2025-03-27 05:12:41 --> Email Class Initialized
INFO - 2025-03-27 05:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:12:41 --> Form Validation Class Initialized
INFO - 2025-03-27 05:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:12:41 --> Pagination Class Initialized
INFO - 2025-03-27 05:12:41 --> Controller Class Initialized
DEBUG - 2025-03-27 05:12:41 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:12:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:12:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:12:41 --> Model Class Initialized
ERROR - 2025-03-27 05:12:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:41 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:41 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:12:41 --> Final output sent to browser
DEBUG - 2025-03-27 05:12:41 --> Total execution time: 0.0240
INFO - 2025-03-27 05:12:43 --> Config Class Initialized
INFO - 2025-03-27 05:12:43 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:12:43 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:12:43 --> Utf8 Class Initialized
INFO - 2025-03-27 05:12:43 --> URI Class Initialized
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:12:43 --> Router Class Initialized
INFO - 2025-03-27 05:12:43 --> Output Class Initialized
INFO - 2025-03-27 05:12:43 --> Security Class Initialized
DEBUG - 2025-03-27 05:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:12:43 --> Input Class Initialized
INFO - 2025-03-27 05:12:43 --> Language Class Initialized
INFO - 2025-03-27 05:12:43 --> Language Class Initialized
INFO - 2025-03-27 05:12:43 --> Config Class Initialized
INFO - 2025-03-27 05:12:43 --> Loader Class Initialized
INFO - 2025-03-27 05:12:43 --> Helper loaded: url_helper
INFO - 2025-03-27 05:12:43 --> Helper loaded: file_helper
INFO - 2025-03-27 05:12:43 --> Helper loaded: html_helper
INFO - 2025-03-27 05:12:43 --> Helper loaded: form_helper
INFO - 2025-03-27 05:12:43 --> Helper loaded: text_helper
INFO - 2025-03-27 05:12:43 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:12:43 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:12:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:12:43 --> Database Driver Class Initialized
INFO - 2025-03-27 05:12:43 --> Email Class Initialized
INFO - 2025-03-27 05:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:12:43 --> Form Validation Class Initialized
INFO - 2025-03-27 05:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:12:43 --> Pagination Class Initialized
INFO - 2025-03-27 05:12:43 --> Controller Class Initialized
DEBUG - 2025-03-27 05:12:43 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:12:43 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:12:43 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:12:43 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:12:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:12:43 --> Model Class Initialized
ERROR - 2025-03-27 05:12:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:12:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:12:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:12:43 --> Final output sent to browser
DEBUG - 2025-03-27 05:12:43 --> Total execution time: 0.1314
INFO - 2025-03-27 05:12:44 --> Config Class Initialized
INFO - 2025-03-27 05:12:44 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:12:44 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:12:44 --> Utf8 Class Initialized
INFO - 2025-03-27 05:12:44 --> URI Class Initialized
DEBUG - 2025-03-27 05:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:12:44 --> Router Class Initialized
INFO - 2025-03-27 05:12:44 --> Output Class Initialized
INFO - 2025-03-27 05:12:44 --> Security Class Initialized
DEBUG - 2025-03-27 05:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:12:44 --> Input Class Initialized
INFO - 2025-03-27 05:12:44 --> Language Class Initialized
INFO - 2025-03-27 05:12:44 --> Language Class Initialized
INFO - 2025-03-27 05:12:44 --> Config Class Initialized
INFO - 2025-03-27 05:12:44 --> Loader Class Initialized
INFO - 2025-03-27 05:12:44 --> Helper loaded: url_helper
INFO - 2025-03-27 05:12:44 --> Helper loaded: file_helper
INFO - 2025-03-27 05:12:44 --> Helper loaded: html_helper
INFO - 2025-03-27 05:12:44 --> Helper loaded: form_helper
INFO - 2025-03-27 05:12:44 --> Helper loaded: text_helper
INFO - 2025-03-27 05:12:44 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:12:44 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:12:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:12:44 --> Database Driver Class Initialized
INFO - 2025-03-27 05:12:44 --> Email Class Initialized
INFO - 2025-03-27 05:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:12:44 --> Form Validation Class Initialized
INFO - 2025-03-27 05:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:12:44 --> Pagination Class Initialized
INFO - 2025-03-27 05:12:44 --> Controller Class Initialized
DEBUG - 2025-03-27 05:12:44 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:12:44 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:12:44 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:12:44 --> Model Class Initialized
ERROR - 2025-03-27 05:12:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:44 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:12:44 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:12:44 --> Final output sent to browser
DEBUG - 2025-03-27 05:12:44 --> Total execution time: 0.0283
INFO - 2025-03-27 05:12:48 --> Config Class Initialized
INFO - 2025-03-27 05:12:48 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:12:48 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:12:48 --> Utf8 Class Initialized
INFO - 2025-03-27 05:12:48 --> URI Class Initialized
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:12:48 --> Router Class Initialized
INFO - 2025-03-27 05:12:48 --> Output Class Initialized
INFO - 2025-03-27 05:12:48 --> Security Class Initialized
DEBUG - 2025-03-27 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:12:48 --> Input Class Initialized
INFO - 2025-03-27 05:12:48 --> Language Class Initialized
INFO - 2025-03-27 05:12:48 --> Language Class Initialized
INFO - 2025-03-27 05:12:48 --> Config Class Initialized
INFO - 2025-03-27 05:12:48 --> Loader Class Initialized
INFO - 2025-03-27 05:12:48 --> Helper loaded: url_helper
INFO - 2025-03-27 05:12:48 --> Helper loaded: file_helper
INFO - 2025-03-27 05:12:48 --> Helper loaded: html_helper
INFO - 2025-03-27 05:12:48 --> Helper loaded: form_helper
INFO - 2025-03-27 05:12:48 --> Helper loaded: text_helper
INFO - 2025-03-27 05:12:48 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:12:48 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:12:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:12:48 --> Database Driver Class Initialized
INFO - 2025-03-27 05:12:48 --> Email Class Initialized
INFO - 2025-03-27 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:12:48 --> Form Validation Class Initialized
INFO - 2025-03-27 05:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:12:48 --> Pagination Class Initialized
INFO - 2025-03-27 05:12:48 --> Controller Class Initialized
DEBUG - 2025-03-27 05:12:48 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:12:48 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:12:48 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:12:48 --> Model Class Initialized
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:12:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:12:48 --> Model Class Initialized
ERROR - 2025-03-27 05:12:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:12:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:12:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:12:48 --> Final output sent to browser
DEBUG - 2025-03-27 05:12:48 --> Total execution time: 0.1760
INFO - 2025-03-27 05:13:10 --> Config Class Initialized
INFO - 2025-03-27 05:13:10 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:13:10 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:13:10 --> Utf8 Class Initialized
INFO - 2025-03-27 05:13:10 --> URI Class Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:13:10 --> Router Class Initialized
INFO - 2025-03-27 05:13:10 --> Output Class Initialized
INFO - 2025-03-27 05:13:10 --> Security Class Initialized
DEBUG - 2025-03-27 05:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:13:10 --> Input Class Initialized
INFO - 2025-03-27 05:13:10 --> Language Class Initialized
INFO - 2025-03-27 05:13:10 --> Language Class Initialized
INFO - 2025-03-27 05:13:10 --> Config Class Initialized
INFO - 2025-03-27 05:13:10 --> Loader Class Initialized
INFO - 2025-03-27 05:13:10 --> Helper loaded: url_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: file_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: html_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: form_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: text_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:13:10 --> Database Driver Class Initialized
INFO - 2025-03-27 05:13:10 --> Email Class Initialized
INFO - 2025-03-27 05:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:13:10 --> Form Validation Class Initialized
INFO - 2025-03-27 05:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:13:10 --> Pagination Class Initialized
INFO - 2025-03-27 05:13:10 --> Controller Class Initialized
DEBUG - 2025-03-27 05:13:10 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:13:10 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:13:10 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:13:10 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:13:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:13:10 --> Model Class Initialized
ERROR - 2025-03-27 05:13:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:13:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:13:10 --> Final output sent to browser
DEBUG - 2025-03-27 05:13:10 --> Total execution time: 0.0896
INFO - 2025-03-27 05:13:10 --> Config Class Initialized
INFO - 2025-03-27 05:13:10 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:13:10 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:13:10 --> Utf8 Class Initialized
INFO - 2025-03-27 05:13:10 --> URI Class Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:13:10 --> Router Class Initialized
INFO - 2025-03-27 05:13:10 --> Output Class Initialized
INFO - 2025-03-27 05:13:10 --> Security Class Initialized
DEBUG - 2025-03-27 05:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:13:10 --> Input Class Initialized
INFO - 2025-03-27 05:13:10 --> Language Class Initialized
INFO - 2025-03-27 05:13:10 --> Language Class Initialized
INFO - 2025-03-27 05:13:10 --> Config Class Initialized
INFO - 2025-03-27 05:13:10 --> Loader Class Initialized
INFO - 2025-03-27 05:13:10 --> Helper loaded: url_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: file_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: html_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: form_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: text_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:13:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:13:10 --> Database Driver Class Initialized
INFO - 2025-03-27 05:13:10 --> Email Class Initialized
INFO - 2025-03-27 05:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:13:10 --> Form Validation Class Initialized
INFO - 2025-03-27 05:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:13:10 --> Pagination Class Initialized
INFO - 2025-03-27 05:13:10 --> Controller Class Initialized
DEBUG - 2025-03-27 05:13:10 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:13:10 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:13:10 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:13:10 --> Model Class Initialized
ERROR - 2025-03-27 05:13:10 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:13:10 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:13:10 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:13:10 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:13:10 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:13:10 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:13:10 --> Final output sent to browser
DEBUG - 2025-03-27 05:13:10 --> Total execution time: 0.0403
INFO - 2025-03-27 05:13:13 --> Config Class Initialized
INFO - 2025-03-27 05:13:13 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:13:13 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:13:13 --> Utf8 Class Initialized
INFO - 2025-03-27 05:13:13 --> URI Class Initialized
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:13:13 --> Router Class Initialized
INFO - 2025-03-27 05:13:13 --> Output Class Initialized
INFO - 2025-03-27 05:13:13 --> Security Class Initialized
DEBUG - 2025-03-27 05:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:13:13 --> Input Class Initialized
INFO - 2025-03-27 05:13:13 --> Language Class Initialized
INFO - 2025-03-27 05:13:13 --> Language Class Initialized
INFO - 2025-03-27 05:13:13 --> Config Class Initialized
INFO - 2025-03-27 05:13:13 --> Loader Class Initialized
INFO - 2025-03-27 05:13:13 --> Helper loaded: url_helper
INFO - 2025-03-27 05:13:13 --> Helper loaded: file_helper
INFO - 2025-03-27 05:13:13 --> Helper loaded: html_helper
INFO - 2025-03-27 05:13:13 --> Helper loaded: form_helper
INFO - 2025-03-27 05:13:13 --> Helper loaded: text_helper
INFO - 2025-03-27 05:13:13 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:13:13 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:13:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:13:13 --> Database Driver Class Initialized
INFO - 2025-03-27 05:13:13 --> Email Class Initialized
INFO - 2025-03-27 05:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:13:13 --> Form Validation Class Initialized
INFO - 2025-03-27 05:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:13:13 --> Pagination Class Initialized
INFO - 2025-03-27 05:13:13 --> Controller Class Initialized
DEBUG - 2025-03-27 05:13:13 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:13:13 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:13:13 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:13:13 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:13:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:13:13 --> Model Class Initialized
ERROR - 2025-03-27 05:13:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:13:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:13:13 --> Final output sent to browser
DEBUG - 2025-03-27 05:13:13 --> Total execution time: 0.1309
INFO - 2025-03-27 05:13:52 --> Config Class Initialized
INFO - 2025-03-27 05:13:52 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:13:52 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:13:52 --> Utf8 Class Initialized
INFO - 2025-03-27 05:13:52 --> URI Class Initialized
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:13:52 --> Router Class Initialized
INFO - 2025-03-27 05:13:52 --> Output Class Initialized
INFO - 2025-03-27 05:13:52 --> Security Class Initialized
DEBUG - 2025-03-27 05:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:13:52 --> Input Class Initialized
INFO - 2025-03-27 05:13:52 --> Language Class Initialized
INFO - 2025-03-27 05:13:52 --> Language Class Initialized
INFO - 2025-03-27 05:13:52 --> Config Class Initialized
INFO - 2025-03-27 05:13:52 --> Loader Class Initialized
INFO - 2025-03-27 05:13:52 --> Helper loaded: url_helper
INFO - 2025-03-27 05:13:52 --> Helper loaded: file_helper
INFO - 2025-03-27 05:13:52 --> Helper loaded: html_helper
INFO - 2025-03-27 05:13:52 --> Helper loaded: form_helper
INFO - 2025-03-27 05:13:52 --> Helper loaded: text_helper
INFO - 2025-03-27 05:13:52 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:13:52 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:13:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:13:52 --> Database Driver Class Initialized
INFO - 2025-03-27 05:13:52 --> Email Class Initialized
INFO - 2025-03-27 05:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:13:52 --> Form Validation Class Initialized
INFO - 2025-03-27 05:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:13:52 --> Pagination Class Initialized
INFO - 2025-03-27 05:13:52 --> Controller Class Initialized
DEBUG - 2025-03-27 05:13:52 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:13:52 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:13:52 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:13:52 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:13:52 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:13:52 --> Model Class Initialized
ERROR - 2025-03-27 05:13:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:13:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:13:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:13:52 --> Final output sent to browser
DEBUG - 2025-03-27 05:13:52 --> Total execution time: 0.1360
INFO - 2025-03-27 05:13:55 --> Config Class Initialized
INFO - 2025-03-27 05:13:55 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:13:55 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:13:55 --> Utf8 Class Initialized
INFO - 2025-03-27 05:13:55 --> URI Class Initialized
DEBUG - 2025-03-27 05:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:13:55 --> Router Class Initialized
INFO - 2025-03-27 05:13:55 --> Output Class Initialized
INFO - 2025-03-27 05:13:55 --> Security Class Initialized
DEBUG - 2025-03-27 05:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:13:55 --> Input Class Initialized
INFO - 2025-03-27 05:13:55 --> Language Class Initialized
INFO - 2025-03-27 05:13:55 --> Language Class Initialized
INFO - 2025-03-27 05:13:55 --> Config Class Initialized
INFO - 2025-03-27 05:13:55 --> Loader Class Initialized
INFO - 2025-03-27 05:13:55 --> Helper loaded: url_helper
INFO - 2025-03-27 05:13:55 --> Helper loaded: file_helper
INFO - 2025-03-27 05:13:55 --> Helper loaded: html_helper
INFO - 2025-03-27 05:13:55 --> Helper loaded: form_helper
INFO - 2025-03-27 05:13:55 --> Helper loaded: text_helper
INFO - 2025-03-27 05:13:55 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:13:55 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:13:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:13:55 --> Database Driver Class Initialized
INFO - 2025-03-27 05:13:55 --> Email Class Initialized
INFO - 2025-03-27 05:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:13:55 --> Form Validation Class Initialized
INFO - 2025-03-27 05:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:13:55 --> Pagination Class Initialized
INFO - 2025-03-27 05:13:55 --> Controller Class Initialized
DEBUG - 2025-03-27 05:13:55 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:13:55 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:13:55 --> Model Class Initialized
DEBUG - 2025-03-27 05:13:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:13:55 --> Model Class Initialized
INFO - 2025-03-27 05:13:55 --> Final output sent to browser
DEBUG - 2025-03-27 05:13:55 --> Total execution time: 0.0099
INFO - 2025-03-27 05:14:03 --> Config Class Initialized
INFO - 2025-03-27 05:14:03 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:03 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:03 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:03 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:03 --> Router Class Initialized
INFO - 2025-03-27 05:14:03 --> Output Class Initialized
INFO - 2025-03-27 05:14:03 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:03 --> Input Class Initialized
INFO - 2025-03-27 05:14:03 --> Language Class Initialized
INFO - 2025-03-27 05:14:03 --> Language Class Initialized
INFO - 2025-03-27 05:14:03 --> Config Class Initialized
INFO - 2025-03-27 05:14:03 --> Loader Class Initialized
INFO - 2025-03-27 05:14:03 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:03 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:03 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:03 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:03 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:03 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:03 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:03 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:03 --> Email Class Initialized
INFO - 2025-03-27 05:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:03 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:03 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:03 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:03 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:03 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:03 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:03 --> Model Class Initialized
INFO - 2025-03-27 05:14:03 --> Final output sent to browser
DEBUG - 2025-03-27 05:14:03 --> Total execution time: 0.0109
INFO - 2025-03-27 05:14:33 --> Config Class Initialized
INFO - 2025-03-27 05:14:33 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:33 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:33 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:33 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:33 --> Router Class Initialized
INFO - 2025-03-27 05:14:33 --> Output Class Initialized
INFO - 2025-03-27 05:14:33 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:33 --> Input Class Initialized
INFO - 2025-03-27 05:14:33 --> Language Class Initialized
INFO - 2025-03-27 05:14:33 --> Language Class Initialized
INFO - 2025-03-27 05:14:33 --> Config Class Initialized
INFO - 2025-03-27 05:14:33 --> Loader Class Initialized
INFO - 2025-03-27 05:14:33 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:33 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:33 --> Email Class Initialized
INFO - 2025-03-27 05:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:33 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:33 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:33 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:33 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:33 --> Model Class Initialized
INFO - 2025-03-27 05:14:33 --> Upload Class Initialized
INFO - 2025-03-27 05:14:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:14:33 --> Config Class Initialized
INFO - 2025-03-27 05:14:33 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:33 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:33 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:33 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:33 --> Router Class Initialized
INFO - 2025-03-27 05:14:33 --> Output Class Initialized
INFO - 2025-03-27 05:14:33 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:33 --> Input Class Initialized
INFO - 2025-03-27 05:14:33 --> Language Class Initialized
INFO - 2025-03-27 05:14:33 --> Language Class Initialized
INFO - 2025-03-27 05:14:33 --> Config Class Initialized
INFO - 2025-03-27 05:14:33 --> Loader Class Initialized
INFO - 2025-03-27 05:14:33 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:33 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:33 --> Email Class Initialized
INFO - 2025-03-27 05:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:33 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:33 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:33 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:33 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:14:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:14:33 --> Model Class Initialized
ERROR - 2025-03-27 05:14:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:14:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:14:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:14:33 --> Final output sent to browser
DEBUG - 2025-03-27 05:14:33 --> Total execution time: 0.3970
INFO - 2025-03-27 05:14:34 --> Config Class Initialized
INFO - 2025-03-27 05:14:34 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:34 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:34 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:34 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:34 --> Router Class Initialized
INFO - 2025-03-27 05:14:34 --> Output Class Initialized
INFO - 2025-03-27 05:14:34 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:34 --> Input Class Initialized
INFO - 2025-03-27 05:14:34 --> Language Class Initialized
INFO - 2025-03-27 05:14:34 --> Language Class Initialized
INFO - 2025-03-27 05:14:34 --> Config Class Initialized
INFO - 2025-03-27 05:14:34 --> Loader Class Initialized
INFO - 2025-03-27 05:14:34 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:34 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:34 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:34 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:34 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:34 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:34 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:34 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:34 --> Email Class Initialized
INFO - 2025-03-27 05:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:34 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:34 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:34 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:34 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:34 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:34 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:34 --> Model Class Initialized
ERROR - 2025-03-27 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:34 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food- Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:14:34 --> Final output sent to browser
DEBUG - 2025-03-27 05:14:34 --> Total execution time: 0.0502
INFO - 2025-03-27 05:14:38 --> Config Class Initialized
INFO - 2025-03-27 05:14:38 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:38 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:38 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:38 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:38 --> Router Class Initialized
INFO - 2025-03-27 05:14:38 --> Output Class Initialized
INFO - 2025-03-27 05:14:38 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:38 --> Input Class Initialized
INFO - 2025-03-27 05:14:38 --> Language Class Initialized
INFO - 2025-03-27 05:14:38 --> Language Class Initialized
INFO - 2025-03-27 05:14:38 --> Config Class Initialized
INFO - 2025-03-27 05:14:38 --> Loader Class Initialized
INFO - 2025-03-27 05:14:38 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:38 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:38 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:38 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:38 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:38 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:38 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:38 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:38 --> Email Class Initialized
INFO - 2025-03-27 05:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:38 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:38 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:38 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:38 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:38 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:38 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:38 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:14:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:14:38 --> Model Class Initialized
ERROR - 2025-03-27 05:14:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:14:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:14:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:14:38 --> Final output sent to browser
DEBUG - 2025-03-27 05:14:38 --> Total execution time: 0.1601
INFO - 2025-03-27 05:14:45 --> Config Class Initialized
INFO - 2025-03-27 05:14:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:45 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:45 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:45 --> Router Class Initialized
INFO - 2025-03-27 05:14:45 --> Output Class Initialized
INFO - 2025-03-27 05:14:45 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:45 --> Input Class Initialized
INFO - 2025-03-27 05:14:45 --> Language Class Initialized
INFO - 2025-03-27 05:14:45 --> Language Class Initialized
INFO - 2025-03-27 05:14:45 --> Config Class Initialized
INFO - 2025-03-27 05:14:45 --> Loader Class Initialized
INFO - 2025-03-27 05:14:45 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:45 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:45 --> Email Class Initialized
INFO - 2025-03-27 05:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:45 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:45 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:45 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
INFO - 2025-03-27 05:14:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:14:45 --> Config Class Initialized
INFO - 2025-03-27 05:14:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:45 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:45 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:45 --> Router Class Initialized
INFO - 2025-03-27 05:14:45 --> Output Class Initialized
INFO - 2025-03-27 05:14:45 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:45 --> Input Class Initialized
INFO - 2025-03-27 05:14:45 --> Language Class Initialized
INFO - 2025-03-27 05:14:45 --> Language Class Initialized
INFO - 2025-03-27 05:14:45 --> Config Class Initialized
INFO - 2025-03-27 05:14:45 --> Loader Class Initialized
INFO - 2025-03-27 05:14:45 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:45 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:45 --> Email Class Initialized
INFO - 2025-03-27 05:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:45 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:45 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:45 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:14:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
ERROR - 2025-03-27 05:14:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:14:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:14:45 --> Final output sent to browser
DEBUG - 2025-03-27 05:14:45 --> Total execution time: 0.1056
INFO - 2025-03-27 05:14:45 --> Config Class Initialized
INFO - 2025-03-27 05:14:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:14:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:14:45 --> Utf8 Class Initialized
INFO - 2025-03-27 05:14:45 --> URI Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:14:45 --> Router Class Initialized
INFO - 2025-03-27 05:14:45 --> Output Class Initialized
INFO - 2025-03-27 05:14:45 --> Security Class Initialized
DEBUG - 2025-03-27 05:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:14:45 --> Input Class Initialized
INFO - 2025-03-27 05:14:45 --> Language Class Initialized
INFO - 2025-03-27 05:14:45 --> Language Class Initialized
INFO - 2025-03-27 05:14:45 --> Config Class Initialized
INFO - 2025-03-27 05:14:45 --> Loader Class Initialized
INFO - 2025-03-27 05:14:45 --> Helper loaded: url_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: file_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: html_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: form_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: text_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:14:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:14:45 --> Database Driver Class Initialized
INFO - 2025-03-27 05:14:45 --> Email Class Initialized
INFO - 2025-03-27 05:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:14:45 --> Form Validation Class Initialized
INFO - 2025-03-27 05:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:14:45 --> Pagination Class Initialized
INFO - 2025-03-27 05:14:45 --> Controller Class Initialized
DEBUG - 2025-03-27 05:14:45 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
DEBUG - 2025-03-27 05:14:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:14:45 --> Model Class Initialized
ERROR - 2025-03-27 05:14:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:45 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:14:45 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food- Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:14:45 --> Final output sent to browser
DEBUG - 2025-03-27 05:14:45 --> Total execution time: 0.0409
INFO - 2025-03-27 05:47:33 --> Config Class Initialized
INFO - 2025-03-27 05:47:33 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:47:33 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:47:33 --> Utf8 Class Initialized
INFO - 2025-03-27 05:47:33 --> URI Class Initialized
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:47:33 --> Router Class Initialized
INFO - 2025-03-27 05:47:33 --> Output Class Initialized
INFO - 2025-03-27 05:47:33 --> Security Class Initialized
DEBUG - 2025-03-27 05:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:47:33 --> Input Class Initialized
INFO - 2025-03-27 05:47:33 --> Language Class Initialized
INFO - 2025-03-27 05:47:33 --> Language Class Initialized
INFO - 2025-03-27 05:47:33 --> Config Class Initialized
INFO - 2025-03-27 05:47:33 --> Loader Class Initialized
INFO - 2025-03-27 05:47:33 --> Helper loaded: url_helper
INFO - 2025-03-27 05:47:33 --> Helper loaded: file_helper
INFO - 2025-03-27 05:47:33 --> Helper loaded: html_helper
INFO - 2025-03-27 05:47:33 --> Helper loaded: form_helper
INFO - 2025-03-27 05:47:33 --> Helper loaded: text_helper
INFO - 2025-03-27 05:47:33 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:47:33 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:47:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:47:33 --> Database Driver Class Initialized
INFO - 2025-03-27 05:47:33 --> Email Class Initialized
INFO - 2025-03-27 05:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:47:33 --> Form Validation Class Initialized
INFO - 2025-03-27 05:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:47:33 --> Pagination Class Initialized
INFO - 2025-03-27 05:47:33 --> Controller Class Initialized
DEBUG - 2025-03-27 05:47:33 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:47:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:47:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:47:33 --> Model Class Initialized
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:47:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:47:33 --> Model Class Initialized
ERROR - 2025-03-27 05:47:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:47:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:47:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:47:33 --> Final output sent to browser
DEBUG - 2025-03-27 05:47:33 --> Total execution time: 0.5328
INFO - 2025-03-27 05:48:11 --> Config Class Initialized
INFO - 2025-03-27 05:48:11 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:48:11 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:48:11 --> Utf8 Class Initialized
INFO - 2025-03-27 05:48:11 --> URI Class Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:48:11 --> Router Class Initialized
INFO - 2025-03-27 05:48:11 --> Output Class Initialized
INFO - 2025-03-27 05:48:11 --> Security Class Initialized
DEBUG - 2025-03-27 05:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:48:11 --> Input Class Initialized
INFO - 2025-03-27 05:48:11 --> Language Class Initialized
INFO - 2025-03-27 05:48:11 --> Language Class Initialized
INFO - 2025-03-27 05:48:11 --> Config Class Initialized
INFO - 2025-03-27 05:48:11 --> Loader Class Initialized
INFO - 2025-03-27 05:48:11 --> Helper loaded: url_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: file_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: html_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: form_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: text_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:48:11 --> Database Driver Class Initialized
INFO - 2025-03-27 05:48:11 --> Email Class Initialized
INFO - 2025-03-27 05:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:48:11 --> Form Validation Class Initialized
INFO - 2025-03-27 05:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:48:11 --> Pagination Class Initialized
INFO - 2025-03-27 05:48:11 --> Controller Class Initialized
DEBUG - 2025-03-27 05:48:11 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:48:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:48:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:48:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:48:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:48:11 --> Model Class Initialized
ERROR - 2025-03-27 05:48:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:48:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:48:11 --> Final output sent to browser
DEBUG - 2025-03-27 05:48:11 --> Total execution time: 0.1164
INFO - 2025-03-27 05:48:11 --> Config Class Initialized
INFO - 2025-03-27 05:48:11 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:48:11 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:48:11 --> Utf8 Class Initialized
INFO - 2025-03-27 05:48:11 --> URI Class Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:48:11 --> Router Class Initialized
INFO - 2025-03-27 05:48:11 --> Output Class Initialized
INFO - 2025-03-27 05:48:11 --> Security Class Initialized
DEBUG - 2025-03-27 05:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:48:11 --> Input Class Initialized
INFO - 2025-03-27 05:48:11 --> Language Class Initialized
INFO - 2025-03-27 05:48:11 --> Language Class Initialized
INFO - 2025-03-27 05:48:11 --> Config Class Initialized
INFO - 2025-03-27 05:48:11 --> Loader Class Initialized
INFO - 2025-03-27 05:48:11 --> Helper loaded: url_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: file_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: html_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: form_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: text_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:48:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:48:11 --> Database Driver Class Initialized
INFO - 2025-03-27 05:48:11 --> Email Class Initialized
INFO - 2025-03-27 05:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:48:11 --> Form Validation Class Initialized
INFO - 2025-03-27 05:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:48:11 --> Pagination Class Initialized
INFO - 2025-03-27 05:48:11 --> Controller Class Initialized
DEBUG - 2025-03-27 05:48:11 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:48:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:48:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:48:11 --> Model Class Initialized
ERROR - 2025-03-27 05:48:11 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:11 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:11 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:11 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:11 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:11 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food- Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:48:11 --> Final output sent to browser
DEBUG - 2025-03-27 05:48:11 --> Total execution time: 0.0381
INFO - 2025-03-27 05:48:22 --> Config Class Initialized
INFO - 2025-03-27 05:48:22 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:48:22 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:48:22 --> Utf8 Class Initialized
INFO - 2025-03-27 05:48:22 --> URI Class Initialized
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:48:22 --> Router Class Initialized
INFO - 2025-03-27 05:48:22 --> Output Class Initialized
INFO - 2025-03-27 05:48:22 --> Security Class Initialized
DEBUG - 2025-03-27 05:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:48:22 --> Input Class Initialized
INFO - 2025-03-27 05:48:22 --> Language Class Initialized
INFO - 2025-03-27 05:48:22 --> Language Class Initialized
INFO - 2025-03-27 05:48:22 --> Config Class Initialized
INFO - 2025-03-27 05:48:22 --> Loader Class Initialized
INFO - 2025-03-27 05:48:22 --> Helper loaded: url_helper
INFO - 2025-03-27 05:48:22 --> Helper loaded: file_helper
INFO - 2025-03-27 05:48:22 --> Helper loaded: html_helper
INFO - 2025-03-27 05:48:22 --> Helper loaded: form_helper
INFO - 2025-03-27 05:48:22 --> Helper loaded: text_helper
INFO - 2025-03-27 05:48:22 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:48:22 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:48:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:48:22 --> Database Driver Class Initialized
INFO - 2025-03-27 05:48:22 --> Email Class Initialized
INFO - 2025-03-27 05:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:48:22 --> Form Validation Class Initialized
INFO - 2025-03-27 05:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:48:22 --> Pagination Class Initialized
INFO - 2025-03-27 05:48:22 --> Controller Class Initialized
DEBUG - 2025-03-27 05:48:22 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:48:22 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:48:22 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:48:22 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:48:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:48:22 --> Model Class Initialized
ERROR - 2025-03-27 05:48:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:48:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:48:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:48:22 --> Final output sent to browser
DEBUG - 2025-03-27 05:48:22 --> Total execution time: 0.0901
INFO - 2025-03-27 05:48:39 --> Config Class Initialized
INFO - 2025-03-27 05:48:39 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:48:39 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:48:39 --> Utf8 Class Initialized
INFO - 2025-03-27 05:48:39 --> URI Class Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:48:39 --> Router Class Initialized
INFO - 2025-03-27 05:48:39 --> Output Class Initialized
INFO - 2025-03-27 05:48:39 --> Security Class Initialized
DEBUG - 2025-03-27 05:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:48:39 --> Input Class Initialized
INFO - 2025-03-27 05:48:39 --> Language Class Initialized
INFO - 2025-03-27 05:48:39 --> Language Class Initialized
INFO - 2025-03-27 05:48:39 --> Config Class Initialized
INFO - 2025-03-27 05:48:39 --> Loader Class Initialized
INFO - 2025-03-27 05:48:39 --> Helper loaded: url_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: file_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: html_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: form_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: text_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:48:39 --> Database Driver Class Initialized
INFO - 2025-03-27 05:48:39 --> Email Class Initialized
INFO - 2025-03-27 05:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:48:39 --> Form Validation Class Initialized
INFO - 2025-03-27 05:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:48:39 --> Pagination Class Initialized
INFO - 2025-03-27 05:48:39 --> Controller Class Initialized
DEBUG - 2025-03-27 05:48:39 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:48:39 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:48:39 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:48:39 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:48:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:48:39 --> Model Class Initialized
ERROR - 2025-03-27 05:48:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:48:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:48:39 --> Final output sent to browser
DEBUG - 2025-03-27 05:48:39 --> Total execution time: 0.1221
INFO - 2025-03-27 05:48:39 --> Config Class Initialized
INFO - 2025-03-27 05:48:39 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:48:39 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:48:39 --> Utf8 Class Initialized
INFO - 2025-03-27 05:48:39 --> URI Class Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:48:39 --> Router Class Initialized
INFO - 2025-03-27 05:48:39 --> Output Class Initialized
INFO - 2025-03-27 05:48:39 --> Security Class Initialized
DEBUG - 2025-03-27 05:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:48:39 --> Input Class Initialized
INFO - 2025-03-27 05:48:39 --> Language Class Initialized
INFO - 2025-03-27 05:48:39 --> Language Class Initialized
INFO - 2025-03-27 05:48:39 --> Config Class Initialized
INFO - 2025-03-27 05:48:39 --> Loader Class Initialized
INFO - 2025-03-27 05:48:39 --> Helper loaded: url_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: file_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: html_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: form_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: text_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:48:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:48:39 --> Database Driver Class Initialized
INFO - 2025-03-27 05:48:39 --> Email Class Initialized
INFO - 2025-03-27 05:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:48:39 --> Form Validation Class Initialized
INFO - 2025-03-27 05:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:48:39 --> Pagination Class Initialized
INFO - 2025-03-27 05:48:39 --> Controller Class Initialized
DEBUG - 2025-03-27 05:48:39 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:48:39 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:48:39 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:48:39 --> Model Class Initialized
ERROR - 2025-03-27 05:48:39 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:39 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:39 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:39 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:39 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 05:48:39 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food- Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakora</a>
                    [category] => Frozen Food- Veg Pakora- small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 05:48:39 --> Final output sent to browser
DEBUG - 2025-03-27 05:48:39 --> Total execution time: 0.0377
INFO - 2025-03-27 05:48:45 --> Config Class Initialized
INFO - 2025-03-27 05:48:45 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:48:45 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:48:45 --> Utf8 Class Initialized
INFO - 2025-03-27 05:48:45 --> URI Class Initialized
DEBUG - 2025-03-27 05:48:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:48:45 --> Router Class Initialized
INFO - 2025-03-27 05:48:45 --> Output Class Initialized
INFO - 2025-03-27 05:48:45 --> Security Class Initialized
DEBUG - 2025-03-27 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:48:45 --> Input Class Initialized
INFO - 2025-03-27 05:48:45 --> Language Class Initialized
INFO - 2025-03-27 05:48:45 --> Language Class Initialized
INFO - 2025-03-27 05:48:45 --> Config Class Initialized
INFO - 2025-03-27 05:48:46 --> Loader Class Initialized
INFO - 2025-03-27 05:48:46 --> Helper loaded: url_helper
INFO - 2025-03-27 05:48:46 --> Helper loaded: file_helper
INFO - 2025-03-27 05:48:46 --> Helper loaded: html_helper
INFO - 2025-03-27 05:48:46 --> Helper loaded: form_helper
INFO - 2025-03-27 05:48:46 --> Helper loaded: text_helper
INFO - 2025-03-27 05:48:46 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:48:46 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:48:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:48:46 --> Database Driver Class Initialized
INFO - 2025-03-27 05:48:46 --> Email Class Initialized
INFO - 2025-03-27 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:48:46 --> Form Validation Class Initialized
INFO - 2025-03-27 05:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:48:46 --> Pagination Class Initialized
INFO - 2025-03-27 05:48:46 --> Controller Class Initialized
DEBUG - 2025-03-27 05:48:46 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:48:46 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:48:46 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:48:46 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:48:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:48:46 --> Model Class Initialized
ERROR - 2025-03-27 05:48:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:48:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:48:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:48:46 --> Final output sent to browser
DEBUG - 2025-03-27 05:48:46 --> Total execution time: 0.1081
INFO - 2025-03-27 05:48:50 --> Config Class Initialized
INFO - 2025-03-27 05:48:50 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:48:50 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:48:50 --> Utf8 Class Initialized
INFO - 2025-03-27 05:48:50 --> URI Class Initialized
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:48:50 --> Router Class Initialized
INFO - 2025-03-27 05:48:50 --> Output Class Initialized
INFO - 2025-03-27 05:48:50 --> Security Class Initialized
DEBUG - 2025-03-27 05:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:48:50 --> Input Class Initialized
INFO - 2025-03-27 05:48:50 --> Language Class Initialized
INFO - 2025-03-27 05:48:50 --> Language Class Initialized
INFO - 2025-03-27 05:48:50 --> Config Class Initialized
INFO - 2025-03-27 05:48:50 --> Loader Class Initialized
INFO - 2025-03-27 05:48:50 --> Helper loaded: url_helper
INFO - 2025-03-27 05:48:50 --> Helper loaded: file_helper
INFO - 2025-03-27 05:48:50 --> Helper loaded: html_helper
INFO - 2025-03-27 05:48:50 --> Helper loaded: form_helper
INFO - 2025-03-27 05:48:50 --> Helper loaded: text_helper
INFO - 2025-03-27 05:48:50 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:48:50 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:48:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:48:50 --> Database Driver Class Initialized
INFO - 2025-03-27 05:48:50 --> Email Class Initialized
INFO - 2025-03-27 05:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:48:50 --> Form Validation Class Initialized
INFO - 2025-03-27 05:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:48:50 --> Pagination Class Initialized
INFO - 2025-03-27 05:48:50 --> Controller Class Initialized
DEBUG - 2025-03-27 05:48:50 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:48:50 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:48:50 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:48:50 --> Model Class Initialized
DEBUG - 2025-03-27 05:48:50 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"28","category_name":"Frozen Food- Veg Pakora- small","parent_id":"27","status":"1"},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food- Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food- Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food- Paratha- 1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food- Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food- Veg Pakora- small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:48:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:48:50 --> Model Class Initialized
ERROR - 2025-03-27 05:48:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:48:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:48:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:48:50 --> Final output sent to browser
DEBUG - 2025-03-27 05:48:50 --> Total execution time: 0.0833
INFO - 2025-03-27 05:49:19 --> Config Class Initialized
INFO - 2025-03-27 05:49:19 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:49:19 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:49:19 --> Utf8 Class Initialized
INFO - 2025-03-27 05:49:19 --> URI Class Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:49:19 --> Router Class Initialized
INFO - 2025-03-27 05:49:19 --> Output Class Initialized
INFO - 2025-03-27 05:49:19 --> Security Class Initialized
DEBUG - 2025-03-27 05:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:49:19 --> Input Class Initialized
INFO - 2025-03-27 05:49:19 --> Language Class Initialized
INFO - 2025-03-27 05:49:19 --> Language Class Initialized
INFO - 2025-03-27 05:49:19 --> Config Class Initialized
INFO - 2025-03-27 05:49:19 --> Loader Class Initialized
INFO - 2025-03-27 05:49:19 --> Helper loaded: url_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: file_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: html_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: form_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: text_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:49:19 --> Database Driver Class Initialized
INFO - 2025-03-27 05:49:19 --> Email Class Initialized
INFO - 2025-03-27 05:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:49:19 --> Form Validation Class Initialized
INFO - 2025-03-27 05:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:49:19 --> Pagination Class Initialized
INFO - 2025-03-27 05:49:19 --> Controller Class Initialized
DEBUG - 2025-03-27 05:49:19 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:49:19 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:49:19 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:49:19 --> Model Class Initialized
INFO - 2025-03-27 05:49:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:49:19 --> INFO: Category Updated Successfully -> Frozen Food- Veg Pakora->small
INFO - 2025-03-27 05:49:19 --> Config Class Initialized
INFO - 2025-03-27 05:49:19 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:49:19 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:49:19 --> Utf8 Class Initialized
INFO - 2025-03-27 05:49:19 --> URI Class Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:49:19 --> Router Class Initialized
INFO - 2025-03-27 05:49:19 --> Output Class Initialized
INFO - 2025-03-27 05:49:19 --> Security Class Initialized
DEBUG - 2025-03-27 05:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:49:19 --> Input Class Initialized
INFO - 2025-03-27 05:49:19 --> Language Class Initialized
INFO - 2025-03-27 05:49:19 --> Language Class Initialized
INFO - 2025-03-27 05:49:19 --> Config Class Initialized
INFO - 2025-03-27 05:49:19 --> Loader Class Initialized
INFO - 2025-03-27 05:49:19 --> Helper loaded: url_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: file_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: html_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: form_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: text_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:49:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:49:19 --> Database Driver Class Initialized
INFO - 2025-03-27 05:49:19 --> Email Class Initialized
INFO - 2025-03-27 05:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:49:19 --> Form Validation Class Initialized
INFO - 2025-03-27 05:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:49:19 --> Pagination Class Initialized
INFO - 2025-03-27 05:49:19 --> Controller Class Initialized
DEBUG - 2025-03-27 05:49:19 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:49:19 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:49:19 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:49:19 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:49:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:49:19 --> Model Class Initialized
ERROR - 2025-03-27 05:49:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:49:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:49:19 --> Final output sent to browser
DEBUG - 2025-03-27 05:49:19 --> Total execution time: 0.1054
INFO - 2025-03-27 05:49:32 --> Config Class Initialized
INFO - 2025-03-27 05:49:32 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:49:32 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:49:32 --> Utf8 Class Initialized
INFO - 2025-03-27 05:49:32 --> URI Class Initialized
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:49:32 --> Router Class Initialized
INFO - 2025-03-27 05:49:32 --> Output Class Initialized
INFO - 2025-03-27 05:49:32 --> Security Class Initialized
DEBUG - 2025-03-27 05:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:49:32 --> Input Class Initialized
INFO - 2025-03-27 05:49:32 --> Language Class Initialized
INFO - 2025-03-27 05:49:32 --> Language Class Initialized
INFO - 2025-03-27 05:49:32 --> Config Class Initialized
INFO - 2025-03-27 05:49:32 --> Loader Class Initialized
INFO - 2025-03-27 05:49:32 --> Helper loaded: url_helper
INFO - 2025-03-27 05:49:32 --> Helper loaded: file_helper
INFO - 2025-03-27 05:49:32 --> Helper loaded: html_helper
INFO - 2025-03-27 05:49:32 --> Helper loaded: form_helper
INFO - 2025-03-27 05:49:32 --> Helper loaded: text_helper
INFO - 2025-03-27 05:49:32 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:49:32 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:49:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:49:32 --> Database Driver Class Initialized
INFO - 2025-03-27 05:49:32 --> Email Class Initialized
INFO - 2025-03-27 05:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:49:32 --> Form Validation Class Initialized
INFO - 2025-03-27 05:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:49:32 --> Pagination Class Initialized
INFO - 2025-03-27 05:49:32 --> Controller Class Initialized
DEBUG - 2025-03-27 05:49:32 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:49:32 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:49:32 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:49:32 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:32 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"26","category_name":"Frozen Food- Paratha- 1600g X 10pac","parent_id":"25","status":"1"},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food- Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food- Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food- Paratha- 1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food- Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food- Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:49:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:49:32 --> Model Class Initialized
ERROR - 2025-03-27 05:49:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:49:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:49:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:49:32 --> Final output sent to browser
DEBUG - 2025-03-27 05:49:32 --> Total execution time: 0.1133
INFO - 2025-03-27 05:49:53 --> Config Class Initialized
INFO - 2025-03-27 05:49:53 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:49:53 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:49:53 --> Utf8 Class Initialized
INFO - 2025-03-27 05:49:53 --> URI Class Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:49:53 --> Router Class Initialized
INFO - 2025-03-27 05:49:53 --> Output Class Initialized
INFO - 2025-03-27 05:49:53 --> Security Class Initialized
DEBUG - 2025-03-27 05:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:49:53 --> Input Class Initialized
INFO - 2025-03-27 05:49:53 --> Language Class Initialized
INFO - 2025-03-27 05:49:53 --> Language Class Initialized
INFO - 2025-03-27 05:49:53 --> Config Class Initialized
INFO - 2025-03-27 05:49:53 --> Loader Class Initialized
INFO - 2025-03-27 05:49:53 --> Helper loaded: url_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: file_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: html_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: form_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: text_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:49:53 --> Database Driver Class Initialized
INFO - 2025-03-27 05:49:53 --> Email Class Initialized
INFO - 2025-03-27 05:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:49:53 --> Form Validation Class Initialized
INFO - 2025-03-27 05:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:49:53 --> Pagination Class Initialized
INFO - 2025-03-27 05:49:53 --> Controller Class Initialized
DEBUG - 2025-03-27 05:49:53 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:49:53 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:49:53 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:49:53 --> Model Class Initialized
INFO - 2025-03-27 05:49:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:49:53 --> INFO: Category Updated Successfully -> Frozen Food- Paratha->1600g X 10pac
INFO - 2025-03-27 05:49:53 --> Config Class Initialized
INFO - 2025-03-27 05:49:53 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:49:53 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:49:53 --> Utf8 Class Initialized
INFO - 2025-03-27 05:49:53 --> URI Class Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:49:53 --> Router Class Initialized
INFO - 2025-03-27 05:49:53 --> Output Class Initialized
INFO - 2025-03-27 05:49:53 --> Security Class Initialized
DEBUG - 2025-03-27 05:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:49:53 --> Input Class Initialized
INFO - 2025-03-27 05:49:53 --> Language Class Initialized
INFO - 2025-03-27 05:49:53 --> Language Class Initialized
INFO - 2025-03-27 05:49:53 --> Config Class Initialized
INFO - 2025-03-27 05:49:53 --> Loader Class Initialized
INFO - 2025-03-27 05:49:53 --> Helper loaded: url_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: file_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: html_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: form_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: text_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:49:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:49:53 --> Database Driver Class Initialized
INFO - 2025-03-27 05:49:53 --> Email Class Initialized
INFO - 2025-03-27 05:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:49:53 --> Form Validation Class Initialized
INFO - 2025-03-27 05:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:49:53 --> Pagination Class Initialized
INFO - 2025-03-27 05:49:53 --> Controller Class Initialized
DEBUG - 2025-03-27 05:49:53 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:49:53 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:49:53 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:49:53 --> Model Class Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:49:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:49:53 --> Model Class Initialized
ERROR - 2025-03-27 05:49:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:49:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:49:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:49:53 --> Final output sent to browser
DEBUG - 2025-03-27 05:49:53 --> Total execution time: 0.0740
INFO - 2025-03-27 05:50:02 --> Config Class Initialized
INFO - 2025-03-27 05:50:02 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:02 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:02 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:02 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:02 --> Router Class Initialized
INFO - 2025-03-27 05:50:02 --> Output Class Initialized
INFO - 2025-03-27 05:50:02 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:02 --> Input Class Initialized
INFO - 2025-03-27 05:50:02 --> Language Class Initialized
INFO - 2025-03-27 05:50:02 --> Language Class Initialized
INFO - 2025-03-27 05:50:02 --> Config Class Initialized
INFO - 2025-03-27 05:50:02 --> Loader Class Initialized
INFO - 2025-03-27 05:50:02 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:02 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:02 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:02 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:02 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:02 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:02 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:02 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:02 --> Email Class Initialized
INFO - 2025-03-27 05:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:02 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:02 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:02 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:02 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:02 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:02 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:02 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:02 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"25","category_name":"Frozen Food- Paratha","parent_id":"23","status":"1"},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food- Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food- Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food- Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food- Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food- Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:50:02 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:50:02 --> Model Class Initialized
ERROR - 2025-03-27 05:50:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:50:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:50:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:50:02 --> Final output sent to browser
DEBUG - 2025-03-27 05:50:02 --> Total execution time: 0.1174
INFO - 2025-03-27 05:50:15 --> Config Class Initialized
INFO - 2025-03-27 05:50:15 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:15 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:15 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:15 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:15 --> Router Class Initialized
INFO - 2025-03-27 05:50:15 --> Output Class Initialized
INFO - 2025-03-27 05:50:15 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:15 --> Input Class Initialized
INFO - 2025-03-27 05:50:15 --> Language Class Initialized
INFO - 2025-03-27 05:50:15 --> Language Class Initialized
INFO - 2025-03-27 05:50:15 --> Config Class Initialized
INFO - 2025-03-27 05:50:15 --> Loader Class Initialized
INFO - 2025-03-27 05:50:15 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:15 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:15 --> Email Class Initialized
INFO - 2025-03-27 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:15 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:15 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:15 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:15 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:15 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:15 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:15 --> Model Class Initialized
INFO - 2025-03-27 05:50:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:50:15 --> INFO: Category Updated Successfully -> Frozen Food->Paratha
INFO - 2025-03-27 05:50:15 --> Config Class Initialized
INFO - 2025-03-27 05:50:15 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:15 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:15 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:15 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:15 --> Router Class Initialized
INFO - 2025-03-27 05:50:15 --> Output Class Initialized
INFO - 2025-03-27 05:50:15 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:15 --> Input Class Initialized
INFO - 2025-03-27 05:50:15 --> Language Class Initialized
INFO - 2025-03-27 05:50:15 --> Language Class Initialized
INFO - 2025-03-27 05:50:15 --> Config Class Initialized
INFO - 2025-03-27 05:50:15 --> Loader Class Initialized
INFO - 2025-03-27 05:50:15 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:15 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:15 --> Email Class Initialized
INFO - 2025-03-27 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:15 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:15 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:15 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:15 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:15 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:15 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:15 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:50:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:50:15 --> Model Class Initialized
ERROR - 2025-03-27 05:50:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:50:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:50:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:50:15 --> Final output sent to browser
DEBUG - 2025-03-27 05:50:15 --> Total execution time: 0.1024
INFO - 2025-03-27 05:50:28 --> Config Class Initialized
INFO - 2025-03-27 05:50:28 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:28 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:28 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:28 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:28 --> Router Class Initialized
INFO - 2025-03-27 05:50:28 --> Output Class Initialized
INFO - 2025-03-27 05:50:28 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:28 --> Input Class Initialized
INFO - 2025-03-27 05:50:28 --> Language Class Initialized
INFO - 2025-03-27 05:50:28 --> Language Class Initialized
INFO - 2025-03-27 05:50:28 --> Config Class Initialized
INFO - 2025-03-27 05:50:28 --> Loader Class Initialized
INFO - 2025-03-27 05:50:28 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:28 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:28 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:28 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:28 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:28 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:28 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:28 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:28 --> Email Class Initialized
INFO - 2025-03-27 05:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:28 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:28 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:28 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:28 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:28 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:28 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:28 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:28 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"26","category_name":"Frozen Food- Paratha->1600g X 10pac","parent_id":"25","status":"1"},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"27","category_name":"Frozen Food- Veg Pakora","parent_id":"23","status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food- Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food- Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food- Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:50:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:50:28 --> Model Class Initialized
ERROR - 2025-03-27 05:50:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:50:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:50:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:50:28 --> Final output sent to browser
DEBUG - 2025-03-27 05:50:28 --> Total execution time: 0.1118
INFO - 2025-03-27 05:50:41 --> Config Class Initialized
INFO - 2025-03-27 05:50:41 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:41 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:41 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:41 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:41 --> Router Class Initialized
INFO - 2025-03-27 05:50:41 --> Output Class Initialized
INFO - 2025-03-27 05:50:41 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:41 --> Input Class Initialized
INFO - 2025-03-27 05:50:41 --> Language Class Initialized
INFO - 2025-03-27 05:50:41 --> Language Class Initialized
INFO - 2025-03-27 05:50:41 --> Config Class Initialized
INFO - 2025-03-27 05:50:41 --> Loader Class Initialized
INFO - 2025-03-27 05:50:41 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:41 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:41 --> Email Class Initialized
INFO - 2025-03-27 05:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:41 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:41 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:41 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:41 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:41 --> Model Class Initialized
INFO - 2025-03-27 05:50:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:50:41 --> INFO: Category Updated Successfully -> Frozen Food->Paratha->1600g X 10pac
INFO - 2025-03-27 05:50:41 --> Config Class Initialized
INFO - 2025-03-27 05:50:41 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:41 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:41 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:41 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:41 --> Router Class Initialized
INFO - 2025-03-27 05:50:41 --> Output Class Initialized
INFO - 2025-03-27 05:50:41 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:41 --> Input Class Initialized
INFO - 2025-03-27 05:50:41 --> Language Class Initialized
INFO - 2025-03-27 05:50:41 --> Language Class Initialized
INFO - 2025-03-27 05:50:41 --> Config Class Initialized
INFO - 2025-03-27 05:50:41 --> Loader Class Initialized
INFO - 2025-03-27 05:50:41 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:41 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:41 --> Email Class Initialized
INFO - 2025-03-27 05:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:41 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:41 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:41 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:41 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:41 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:50:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:50:41 --> Model Class Initialized
ERROR - 2025-03-27 05:50:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:50:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:50:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:50:41 --> Final output sent to browser
DEBUG - 2025-03-27 05:50:41 --> Total execution time: 0.0927
INFO - 2025-03-27 05:50:50 --> Config Class Initialized
INFO - 2025-03-27 05:50:50 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:50 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:50 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:50 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:50 --> Router Class Initialized
INFO - 2025-03-27 05:50:50 --> Output Class Initialized
INFO - 2025-03-27 05:50:50 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:50 --> Input Class Initialized
INFO - 2025-03-27 05:50:50 --> Language Class Initialized
INFO - 2025-03-27 05:50:50 --> Language Class Initialized
INFO - 2025-03-27 05:50:50 --> Config Class Initialized
INFO - 2025-03-27 05:50:50 --> Loader Class Initialized
INFO - 2025-03-27 05:50:50 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:50 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:50 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:50 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:50 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:50 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:50 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:50 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:50 --> Email Class Initialized
INFO - 2025-03-27 05:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:50 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:50 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:50 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:50 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:50 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:50 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:50 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:50 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"32","category_name":"Frozen Food- Paratha->2400gmx12Pac","parent_id":"25","status":"1"},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"27","category_name":"Frozen Food- Veg Pakora","parent_id":"23","status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"32","category_name":"Frozen Food- Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food- Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:50:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:50:50 --> Model Class Initialized
ERROR - 2025-03-27 05:50:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:50:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:50:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:50:50 --> Final output sent to browser
DEBUG - 2025-03-27 05:50:50 --> Total execution time: 0.1209
INFO - 2025-03-27 05:50:56 --> Config Class Initialized
INFO - 2025-03-27 05:50:56 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:56 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:56 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:56 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:56 --> Router Class Initialized
INFO - 2025-03-27 05:50:56 --> Output Class Initialized
INFO - 2025-03-27 05:50:56 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:56 --> Input Class Initialized
INFO - 2025-03-27 05:50:56 --> Language Class Initialized
INFO - 2025-03-27 05:50:56 --> Language Class Initialized
INFO - 2025-03-27 05:50:56 --> Config Class Initialized
INFO - 2025-03-27 05:50:56 --> Loader Class Initialized
INFO - 2025-03-27 05:50:56 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:56 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:56 --> Email Class Initialized
INFO - 2025-03-27 05:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:56 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:56 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:56 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:56 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:56 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:56 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:56 --> Model Class Initialized
INFO - 2025-03-27 05:50:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:50:56 --> INFO: Category Updated Successfully -> Frozen Food->Paratha->2400gmx12Pac
INFO - 2025-03-27 05:50:56 --> Config Class Initialized
INFO - 2025-03-27 05:50:56 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:50:56 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:50:56 --> Utf8 Class Initialized
INFO - 2025-03-27 05:50:56 --> URI Class Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:50:56 --> Router Class Initialized
INFO - 2025-03-27 05:50:56 --> Output Class Initialized
INFO - 2025-03-27 05:50:56 --> Security Class Initialized
DEBUG - 2025-03-27 05:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:50:56 --> Input Class Initialized
INFO - 2025-03-27 05:50:56 --> Language Class Initialized
INFO - 2025-03-27 05:50:56 --> Language Class Initialized
INFO - 2025-03-27 05:50:56 --> Config Class Initialized
INFO - 2025-03-27 05:50:56 --> Loader Class Initialized
INFO - 2025-03-27 05:50:56 --> Helper loaded: url_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: file_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: html_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: form_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: text_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:50:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:50:56 --> Database Driver Class Initialized
INFO - 2025-03-27 05:50:56 --> Email Class Initialized
INFO - 2025-03-27 05:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:50:56 --> Form Validation Class Initialized
INFO - 2025-03-27 05:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:50:56 --> Pagination Class Initialized
INFO - 2025-03-27 05:50:56 --> Controller Class Initialized
DEBUG - 2025-03-27 05:50:56 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:50:56 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:50:56 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:50:56 --> Model Class Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:50:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:50:56 --> Model Class Initialized
ERROR - 2025-03-27 05:50:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:50:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:50:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:50:56 --> Final output sent to browser
DEBUG - 2025-03-27 05:50:56 --> Total execution time: 0.1141
INFO - 2025-03-27 05:51:06 --> Config Class Initialized
INFO - 2025-03-27 05:51:06 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:51:06 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:51:06 --> Utf8 Class Initialized
INFO - 2025-03-27 05:51:06 --> URI Class Initialized
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:51:06 --> Router Class Initialized
INFO - 2025-03-27 05:51:06 --> Output Class Initialized
INFO - 2025-03-27 05:51:06 --> Security Class Initialized
DEBUG - 2025-03-27 05:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:51:06 --> Input Class Initialized
INFO - 2025-03-27 05:51:06 --> Language Class Initialized
INFO - 2025-03-27 05:51:06 --> Language Class Initialized
INFO - 2025-03-27 05:51:06 --> Config Class Initialized
INFO - 2025-03-27 05:51:06 --> Loader Class Initialized
INFO - 2025-03-27 05:51:06 --> Helper loaded: url_helper
INFO - 2025-03-27 05:51:06 --> Helper loaded: file_helper
INFO - 2025-03-27 05:51:06 --> Helper loaded: html_helper
INFO - 2025-03-27 05:51:06 --> Helper loaded: form_helper
INFO - 2025-03-27 05:51:06 --> Helper loaded: text_helper
INFO - 2025-03-27 05:51:06 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:51:06 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:51:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:51:06 --> Database Driver Class Initialized
INFO - 2025-03-27 05:51:06 --> Email Class Initialized
INFO - 2025-03-27 05:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:51:06 --> Form Validation Class Initialized
INFO - 2025-03-27 05:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:51:06 --> Pagination Class Initialized
INFO - 2025-03-27 05:51:06 --> Controller Class Initialized
DEBUG - 2025-03-27 05:51:06 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:51:06 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:51:06 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:51:06 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:06 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"27","category_name":"Frozen Food- Veg Pakora","parent_id":"23","status":"1"},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"27","category_name":"Frozen Food- Veg Pakora","parent_id":"23","status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food- Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:51:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:51:06 --> Model Class Initialized
ERROR - 2025-03-27 05:51:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:51:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:51:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:51:06 --> Final output sent to browser
DEBUG - 2025-03-27 05:51:06 --> Total execution time: 0.1208
INFO - 2025-03-27 05:51:11 --> Config Class Initialized
INFO - 2025-03-27 05:51:11 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:51:11 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:51:11 --> Utf8 Class Initialized
INFO - 2025-03-27 05:51:11 --> URI Class Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:51:11 --> Router Class Initialized
INFO - 2025-03-27 05:51:11 --> Output Class Initialized
INFO - 2025-03-27 05:51:11 --> Security Class Initialized
DEBUG - 2025-03-27 05:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:51:11 --> Input Class Initialized
INFO - 2025-03-27 05:51:11 --> Language Class Initialized
INFO - 2025-03-27 05:51:11 --> Language Class Initialized
INFO - 2025-03-27 05:51:11 --> Config Class Initialized
INFO - 2025-03-27 05:51:11 --> Loader Class Initialized
INFO - 2025-03-27 05:51:11 --> Helper loaded: url_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: file_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: html_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: form_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: text_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:51:11 --> Database Driver Class Initialized
INFO - 2025-03-27 05:51:11 --> Email Class Initialized
INFO - 2025-03-27 05:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:51:11 --> Form Validation Class Initialized
INFO - 2025-03-27 05:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:51:11 --> Pagination Class Initialized
INFO - 2025-03-27 05:51:11 --> Controller Class Initialized
DEBUG - 2025-03-27 05:51:11 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:51:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:51:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:51:11 --> Model Class Initialized
INFO - 2025-03-27 05:51:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:51:11 --> INFO: Category Updated Successfully -> Frozen Food->Veg Pakora
INFO - 2025-03-27 05:51:11 --> Config Class Initialized
INFO - 2025-03-27 05:51:11 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:51:11 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:51:11 --> Utf8 Class Initialized
INFO - 2025-03-27 05:51:11 --> URI Class Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:51:11 --> Router Class Initialized
INFO - 2025-03-27 05:51:11 --> Output Class Initialized
INFO - 2025-03-27 05:51:11 --> Security Class Initialized
DEBUG - 2025-03-27 05:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:51:11 --> Input Class Initialized
INFO - 2025-03-27 05:51:11 --> Language Class Initialized
INFO - 2025-03-27 05:51:11 --> Language Class Initialized
INFO - 2025-03-27 05:51:11 --> Config Class Initialized
INFO - 2025-03-27 05:51:11 --> Loader Class Initialized
INFO - 2025-03-27 05:51:11 --> Helper loaded: url_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: file_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: html_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: form_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: text_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:51:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:51:11 --> Database Driver Class Initialized
INFO - 2025-03-27 05:51:11 --> Email Class Initialized
INFO - 2025-03-27 05:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:51:11 --> Form Validation Class Initialized
INFO - 2025-03-27 05:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:51:11 --> Pagination Class Initialized
INFO - 2025-03-27 05:51:11 --> Controller Class Initialized
DEBUG - 2025-03-27 05:51:11 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:51:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:51:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:51:11 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:51:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:51:11 --> Model Class Initialized
ERROR - 2025-03-27 05:51:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:51:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:51:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:51:11 --> Final output sent to browser
DEBUG - 2025-03-27 05:51:11 --> Total execution time: 0.0745
INFO - 2025-03-27 05:51:21 --> Config Class Initialized
INFO - 2025-03-27 05:51:21 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:51:21 --> Utf8 Class Initialized
INFO - 2025-03-27 05:51:21 --> URI Class Initialized
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:51:21 --> Router Class Initialized
INFO - 2025-03-27 05:51:21 --> Output Class Initialized
INFO - 2025-03-27 05:51:21 --> Security Class Initialized
DEBUG - 2025-03-27 05:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:51:21 --> Input Class Initialized
INFO - 2025-03-27 05:51:21 --> Language Class Initialized
INFO - 2025-03-27 05:51:21 --> Language Class Initialized
INFO - 2025-03-27 05:51:21 --> Config Class Initialized
INFO - 2025-03-27 05:51:21 --> Loader Class Initialized
INFO - 2025-03-27 05:51:21 --> Helper loaded: url_helper
INFO - 2025-03-27 05:51:21 --> Helper loaded: file_helper
INFO - 2025-03-27 05:51:21 --> Helper loaded: html_helper
INFO - 2025-03-27 05:51:21 --> Helper loaded: form_helper
INFO - 2025-03-27 05:51:21 --> Helper loaded: text_helper
INFO - 2025-03-27 05:51:21 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:51:21 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:51:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:51:21 --> Database Driver Class Initialized
INFO - 2025-03-27 05:51:21 --> Email Class Initialized
INFO - 2025-03-27 05:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:51:21 --> Form Validation Class Initialized
INFO - 2025-03-27 05:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:51:21 --> Pagination Class Initialized
INFO - 2025-03-27 05:51:21 --> Controller Class Initialized
DEBUG - 2025-03-27 05:51:21 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:51:21 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:51:21 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:51:21 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:21 --> DEBUG: Loading category_form page with data -> {"title":false,"category":{"category_id":"28","category_name":"Frozen Food- Veg Pakora->small","parent_id":"27","status":"1"},"categories":[{"category_id":"23","category_name":"Frozen Food","parent_id":null,"status":"1"},{"category_id":"25","category_name":"Frozen Food->Paratha","parent_id":"23","status":"1"},{"category_id":"27","category_name":"Frozen Food->Veg Pakora","parent_id":"23","status":"1"},{"category_id":"26","category_name":"Frozen Food->Paratha->1600g X 10pac","parent_id":"25","status":"1"},{"category_id":"32","category_name":"Frozen Food->Paratha->2400gmx12Pac","parent_id":"25","status":"1"},{"category_id":"28","category_name":"Frozen Food- Veg Pakora->small","parent_id":"27","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:51:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:51:21 --> Model Class Initialized
ERROR - 2025-03-27 05:51:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:51:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:51:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:51:21 --> Final output sent to browser
DEBUG - 2025-03-27 05:51:21 --> Total execution time: 0.1177
INFO - 2025-03-27 05:51:30 --> Config Class Initialized
INFO - 2025-03-27 05:51:30 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:51:30 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:51:30 --> Utf8 Class Initialized
INFO - 2025-03-27 05:51:30 --> URI Class Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:51:30 --> Router Class Initialized
INFO - 2025-03-27 05:51:30 --> Output Class Initialized
INFO - 2025-03-27 05:51:30 --> Security Class Initialized
DEBUG - 2025-03-27 05:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:51:30 --> Input Class Initialized
INFO - 2025-03-27 05:51:30 --> Language Class Initialized
INFO - 2025-03-27 05:51:30 --> Language Class Initialized
INFO - 2025-03-27 05:51:30 --> Config Class Initialized
INFO - 2025-03-27 05:51:30 --> Loader Class Initialized
INFO - 2025-03-27 05:51:30 --> Helper loaded: url_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: file_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: html_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: form_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: text_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:51:30 --> Database Driver Class Initialized
INFO - 2025-03-27 05:51:30 --> Email Class Initialized
INFO - 2025-03-27 05:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:51:30 --> Form Validation Class Initialized
INFO - 2025-03-27 05:51:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:51:30 --> Pagination Class Initialized
INFO - 2025-03-27 05:51:30 --> Controller Class Initialized
DEBUG - 2025-03-27 05:51:30 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:51:30 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:51:30 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:51:30 --> Model Class Initialized
INFO - 2025-03-27 05:51:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 05:51:30 --> INFO: Category Updated Successfully -> Frozen Food->Veg Pakora->small
INFO - 2025-03-27 05:51:30 --> Config Class Initialized
INFO - 2025-03-27 05:51:30 --> Hooks Class Initialized
DEBUG - 2025-03-27 05:51:30 --> UTF-8 Support Enabled
INFO - 2025-03-27 05:51:30 --> Utf8 Class Initialized
INFO - 2025-03-27 05:51:30 --> URI Class Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 05:51:30 --> Router Class Initialized
INFO - 2025-03-27 05:51:30 --> Output Class Initialized
INFO - 2025-03-27 05:51:30 --> Security Class Initialized
DEBUG - 2025-03-27 05:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 05:51:30 --> Input Class Initialized
INFO - 2025-03-27 05:51:30 --> Language Class Initialized
INFO - 2025-03-27 05:51:30 --> Language Class Initialized
INFO - 2025-03-27 05:51:30 --> Config Class Initialized
INFO - 2025-03-27 05:51:30 --> Loader Class Initialized
INFO - 2025-03-27 05:51:30 --> Helper loaded: url_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: file_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: html_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: form_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: text_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: lang_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: directory_helper
INFO - 2025-03-27 05:51:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 05:51:30 --> Database Driver Class Initialized
INFO - 2025-03-27 05:51:30 --> Email Class Initialized
INFO - 2025-03-27 05:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 05:51:30 --> Form Validation Class Initialized
INFO - 2025-03-27 05:51:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 05:51:30 --> Pagination Class Initialized
INFO - 2025-03-27 05:51:30 --> Controller Class Initialized
DEBUG - 2025-03-27 05:51:30 --> Product MX_Controller Initialized
INFO - 2025-03-27 05:51:30 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 05:51:30 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 05:51:30 --> Model Class Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 05:51:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 05:51:30 --> Model Class Initialized
ERROR - 2025-03-27 05:51:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 05:51:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 05:51:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 05:51:30 --> Final output sent to browser
DEBUG - 2025-03-27 05:51:30 --> Total execution time: 0.0749
INFO - 2025-03-27 08:31:10 --> Config Class Initialized
INFO - 2025-03-27 08:31:10 --> Hooks Class Initialized
DEBUG - 2025-03-27 08:31:10 --> UTF-8 Support Enabled
INFO - 2025-03-27 08:31:10 --> Utf8 Class Initialized
INFO - 2025-03-27 08:31:10 --> URI Class Initialized
DEBUG - 2025-03-27 08:31:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-27 08:31:10 --> Router Class Initialized
INFO - 2025-03-27 08:31:10 --> Output Class Initialized
INFO - 2025-03-27 08:31:10 --> Security Class Initialized
DEBUG - 2025-03-27 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 08:31:10 --> Input Class Initialized
INFO - 2025-03-27 08:31:10 --> Language Class Initialized
INFO - 2025-03-27 08:31:10 --> Language Class Initialized
INFO - 2025-03-27 08:31:10 --> Config Class Initialized
INFO - 2025-03-27 08:31:10 --> Loader Class Initialized
INFO - 2025-03-27 08:31:10 --> Helper loaded: url_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: file_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: html_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: form_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: text_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: lang_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: directory_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 08:31:10 --> Database Driver Class Initialized
INFO - 2025-03-27 08:31:10 --> Email Class Initialized
INFO - 2025-03-27 08:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 08:31:10 --> Form Validation Class Initialized
INFO - 2025-03-27 08:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 08:31:10 --> Pagination Class Initialized
INFO - 2025-03-27 08:31:10 --> Controller Class Initialized
DEBUG - 2025-03-27 08:31:10 --> Report MX_Controller Initialized
INFO - 2025-03-27 08:31:10 --> Model Class Initialized
DEBUG - 2025-03-27 08:31:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-27 08:31:10 --> Model Class Initialized
INFO - 2025-03-27 08:31:10 --> Config Class Initialized
INFO - 2025-03-27 08:31:10 --> Hooks Class Initialized
DEBUG - 2025-03-27 08:31:10 --> UTF-8 Support Enabled
INFO - 2025-03-27 08:31:10 --> Utf8 Class Initialized
INFO - 2025-03-27 08:31:10 --> URI Class Initialized
DEBUG - 2025-03-27 08:31:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 08:31:10 --> Router Class Initialized
INFO - 2025-03-27 08:31:10 --> Output Class Initialized
INFO - 2025-03-27 08:31:10 --> Security Class Initialized
DEBUG - 2025-03-27 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 08:31:10 --> Input Class Initialized
INFO - 2025-03-27 08:31:10 --> Language Class Initialized
INFO - 2025-03-27 08:31:10 --> Language Class Initialized
INFO - 2025-03-27 08:31:10 --> Config Class Initialized
INFO - 2025-03-27 08:31:10 --> Loader Class Initialized
INFO - 2025-03-27 08:31:10 --> Helper loaded: url_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: file_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: html_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: form_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: text_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: lang_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: directory_helper
INFO - 2025-03-27 08:31:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 08:31:10 --> Database Driver Class Initialized
INFO - 2025-03-27 08:31:10 --> Email Class Initialized
INFO - 2025-03-27 08:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 08:31:10 --> Form Validation Class Initialized
INFO - 2025-03-27 08:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 08:31:10 --> Pagination Class Initialized
INFO - 2025-03-27 08:31:10 --> Controller Class Initialized
DEBUG - 2025-03-27 08:31:10 --> Auth MX_Controller Initialized
INFO - 2025-03-27 08:31:10 --> Model Class Initialized
DEBUG - 2025-03-27 08:31:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 08:31:10 --> Model Class Initialized
DEBUG - 2025-03-27 08:31:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 08:31:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 08:31:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 08:31:10 --> Model Class Initialized
DEBUG - 2025-03-27 08:31:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 08:31:10 --> Final output sent to browser
DEBUG - 2025-03-27 08:31:10 --> Total execution time: 0.0144
INFO - 2025-03-27 08:31:19 --> Config Class Initialized
INFO - 2025-03-27 08:31:19 --> Hooks Class Initialized
DEBUG - 2025-03-27 08:31:19 --> UTF-8 Support Enabled
INFO - 2025-03-27 08:31:19 --> Utf8 Class Initialized
INFO - 2025-03-27 08:31:19 --> URI Class Initialized
DEBUG - 2025-03-27 08:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 08:31:19 --> Router Class Initialized
INFO - 2025-03-27 08:31:19 --> Output Class Initialized
INFO - 2025-03-27 08:31:19 --> Security Class Initialized
DEBUG - 2025-03-27 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 08:31:19 --> Input Class Initialized
INFO - 2025-03-27 08:31:19 --> Language Class Initialized
INFO - 2025-03-27 08:31:19 --> Language Class Initialized
INFO - 2025-03-27 08:31:19 --> Config Class Initialized
INFO - 2025-03-27 08:31:19 --> Loader Class Initialized
INFO - 2025-03-27 08:31:19 --> Helper loaded: url_helper
INFO - 2025-03-27 08:31:19 --> Helper loaded: file_helper
INFO - 2025-03-27 08:31:19 --> Helper loaded: html_helper
INFO - 2025-03-27 08:31:19 --> Helper loaded: form_helper
INFO - 2025-03-27 08:31:19 --> Helper loaded: text_helper
INFO - 2025-03-27 08:31:19 --> Helper loaded: lang_helper
INFO - 2025-03-27 08:31:19 --> Helper loaded: directory_helper
INFO - 2025-03-27 08:31:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 08:31:19 --> Database Driver Class Initialized
INFO - 2025-03-27 08:31:19 --> Email Class Initialized
INFO - 2025-03-27 08:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 08:31:19 --> Form Validation Class Initialized
INFO - 2025-03-27 08:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 08:31:19 --> Pagination Class Initialized
INFO - 2025-03-27 08:31:19 --> Controller Class Initialized
DEBUG - 2025-03-27 08:31:19 --> Auth MX_Controller Initialized
INFO - 2025-03-27 08:31:19 --> Model Class Initialized
DEBUG - 2025-03-27 08:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 08:31:19 --> Model Class Initialized
INFO - 2025-03-27 08:31:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 08:31:20 --> Config Class Initialized
INFO - 2025-03-27 08:31:20 --> Hooks Class Initialized
DEBUG - 2025-03-27 08:31:20 --> UTF-8 Support Enabled
INFO - 2025-03-27 08:31:20 --> Utf8 Class Initialized
INFO - 2025-03-27 08:31:20 --> URI Class Initialized
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 08:31:20 --> Router Class Initialized
INFO - 2025-03-27 08:31:20 --> Output Class Initialized
INFO - 2025-03-27 08:31:20 --> Security Class Initialized
DEBUG - 2025-03-27 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 08:31:20 --> Input Class Initialized
INFO - 2025-03-27 08:31:20 --> Language Class Initialized
INFO - 2025-03-27 08:31:20 --> Language Class Initialized
INFO - 2025-03-27 08:31:20 --> Config Class Initialized
INFO - 2025-03-27 08:31:20 --> Loader Class Initialized
INFO - 2025-03-27 08:31:20 --> Helper loaded: url_helper
INFO - 2025-03-27 08:31:20 --> Helper loaded: file_helper
INFO - 2025-03-27 08:31:20 --> Helper loaded: html_helper
INFO - 2025-03-27 08:31:20 --> Helper loaded: form_helper
INFO - 2025-03-27 08:31:20 --> Helper loaded: text_helper
INFO - 2025-03-27 08:31:20 --> Helper loaded: lang_helper
INFO - 2025-03-27 08:31:20 --> Helper loaded: directory_helper
INFO - 2025-03-27 08:31:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 08:31:20 --> Database Driver Class Initialized
INFO - 2025-03-27 08:31:20 --> Email Class Initialized
INFO - 2025-03-27 08:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 08:31:20 --> Form Validation Class Initialized
INFO - 2025-03-27 08:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 08:31:20 --> Pagination Class Initialized
INFO - 2025-03-27 08:31:20 --> Controller Class Initialized
DEBUG - 2025-03-27 08:31:20 --> Home MX_Controller Initialized
INFO - 2025-03-27 08:31:20 --> Model Class Initialized
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-27 08:31:20 --> Model Class Initialized
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 08:31:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 08:31:20 --> Model Class Initialized
ERROR - 2025-03-27 08:31:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 08:31:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 08:31:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 08:31:20 --> Final output sent to browser
DEBUG - 2025-03-27 08:31:20 --> Total execution time: 0.8240
INFO - 2025-03-27 08:39:08 --> Config Class Initialized
INFO - 2025-03-27 08:39:08 --> Hooks Class Initialized
DEBUG - 2025-03-27 08:39:08 --> UTF-8 Support Enabled
INFO - 2025-03-27 08:39:08 --> Utf8 Class Initialized
INFO - 2025-03-27 08:39:08 --> URI Class Initialized
DEBUG - 2025-03-27 08:39:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-27 08:39:08 --> No URI present. Default controller set.
INFO - 2025-03-27 08:39:08 --> Router Class Initialized
INFO - 2025-03-27 08:39:08 --> Output Class Initialized
INFO - 2025-03-27 08:39:08 --> Security Class Initialized
DEBUG - 2025-03-27 08:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 08:39:08 --> Input Class Initialized
INFO - 2025-03-27 08:39:08 --> Language Class Initialized
INFO - 2025-03-27 08:39:08 --> Language Class Initialized
INFO - 2025-03-27 08:39:08 --> Config Class Initialized
INFO - 2025-03-27 08:39:08 --> Loader Class Initialized
INFO - 2025-03-27 08:39:08 --> Helper loaded: url_helper
INFO - 2025-03-27 08:39:08 --> Helper loaded: file_helper
INFO - 2025-03-27 08:39:08 --> Helper loaded: html_helper
INFO - 2025-03-27 08:39:08 --> Helper loaded: form_helper
INFO - 2025-03-27 08:39:08 --> Helper loaded: text_helper
INFO - 2025-03-27 08:39:08 --> Helper loaded: lang_helper
INFO - 2025-03-27 08:39:08 --> Helper loaded: directory_helper
INFO - 2025-03-27 08:39:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 08:39:08 --> Database Driver Class Initialized
INFO - 2025-03-27 08:39:08 --> Email Class Initialized
INFO - 2025-03-27 08:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 08:39:08 --> Form Validation Class Initialized
INFO - 2025-03-27 08:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 08:39:08 --> Pagination Class Initialized
INFO - 2025-03-27 08:39:08 --> Controller Class Initialized
DEBUG - 2025-03-27 08:39:08 --> Auth MX_Controller Initialized
INFO - 2025-03-27 08:39:08 --> Model Class Initialized
DEBUG - 2025-03-27 08:39:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 08:39:08 --> Model Class Initialized
DEBUG - 2025-03-27 08:39:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 08:39:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 08:39:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 08:39:08 --> Model Class Initialized
DEBUG - 2025-03-27 08:39:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 08:39:08 --> Final output sent to browser
DEBUG - 2025-03-27 08:39:08 --> Total execution time: 0.0311
INFO - 2025-03-27 08:39:20 --> Config Class Initialized
INFO - 2025-03-27 08:39:20 --> Hooks Class Initialized
DEBUG - 2025-03-27 08:39:20 --> UTF-8 Support Enabled
INFO - 2025-03-27 08:39:20 --> Utf8 Class Initialized
INFO - 2025-03-27 08:39:20 --> URI Class Initialized
DEBUG - 2025-03-27 08:39:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-27 08:39:20 --> No URI present. Default controller set.
INFO - 2025-03-27 08:39:20 --> Router Class Initialized
INFO - 2025-03-27 08:39:20 --> Output Class Initialized
INFO - 2025-03-27 08:39:20 --> Security Class Initialized
DEBUG - 2025-03-27 08:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 08:39:20 --> Input Class Initialized
INFO - 2025-03-27 08:39:20 --> Language Class Initialized
INFO - 2025-03-27 08:39:20 --> Language Class Initialized
INFO - 2025-03-27 08:39:20 --> Config Class Initialized
INFO - 2025-03-27 08:39:20 --> Loader Class Initialized
INFO - 2025-03-27 08:39:20 --> Helper loaded: url_helper
INFO - 2025-03-27 08:39:20 --> Helper loaded: file_helper
INFO - 2025-03-27 08:39:20 --> Helper loaded: html_helper
INFO - 2025-03-27 08:39:20 --> Helper loaded: form_helper
INFO - 2025-03-27 08:39:20 --> Helper loaded: text_helper
INFO - 2025-03-27 08:39:20 --> Helper loaded: lang_helper
INFO - 2025-03-27 08:39:20 --> Helper loaded: directory_helper
INFO - 2025-03-27 08:39:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 08:39:20 --> Database Driver Class Initialized
INFO - 2025-03-27 08:39:20 --> Email Class Initialized
INFO - 2025-03-27 08:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 08:39:20 --> Form Validation Class Initialized
INFO - 2025-03-27 08:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 08:39:20 --> Pagination Class Initialized
INFO - 2025-03-27 08:39:20 --> Controller Class Initialized
DEBUG - 2025-03-27 08:39:20 --> Auth MX_Controller Initialized
INFO - 2025-03-27 08:39:20 --> Model Class Initialized
DEBUG - 2025-03-27 08:39:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 08:39:20 --> Model Class Initialized
DEBUG - 2025-03-27 08:39:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 08:39:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 08:39:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 08:39:20 --> Model Class Initialized
DEBUG - 2025-03-27 08:39:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 08:39:20 --> Final output sent to browser
DEBUG - 2025-03-27 08:39:20 --> Total execution time: 0.0154
INFO - 2025-03-27 13:38:20 --> Config Class Initialized
INFO - 2025-03-27 13:38:20 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:38:20 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:38:20 --> Utf8 Class Initialized
INFO - 2025-03-27 13:38:20 --> URI Class Initialized
DEBUG - 2025-03-27 13:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-27 13:38:20 --> No URI present. Default controller set.
INFO - 2025-03-27 13:38:20 --> Router Class Initialized
INFO - 2025-03-27 13:38:20 --> Output Class Initialized
INFO - 2025-03-27 13:38:20 --> Security Class Initialized
DEBUG - 2025-03-27 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:38:20 --> Input Class Initialized
INFO - 2025-03-27 13:38:20 --> Language Class Initialized
INFO - 2025-03-27 13:38:20 --> Language Class Initialized
INFO - 2025-03-27 13:38:20 --> Config Class Initialized
INFO - 2025-03-27 13:38:20 --> Loader Class Initialized
INFO - 2025-03-27 13:38:20 --> Helper loaded: url_helper
INFO - 2025-03-27 13:38:20 --> Helper loaded: file_helper
INFO - 2025-03-27 13:38:20 --> Helper loaded: html_helper
INFO - 2025-03-27 13:38:20 --> Helper loaded: form_helper
INFO - 2025-03-27 13:38:20 --> Helper loaded: text_helper
INFO - 2025-03-27 13:38:20 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:38:20 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:38:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:38:20 --> Database Driver Class Initialized
INFO - 2025-03-27 13:38:20 --> Email Class Initialized
INFO - 2025-03-27 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:38:20 --> Form Validation Class Initialized
INFO - 2025-03-27 13:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:38:20 --> Pagination Class Initialized
INFO - 2025-03-27 13:38:20 --> Controller Class Initialized
DEBUG - 2025-03-27 13:38:20 --> Auth MX_Controller Initialized
INFO - 2025-03-27 13:38:20 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 13:38:20 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 13:38:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 13:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 13:38:20 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 13:38:20 --> Final output sent to browser
DEBUG - 2025-03-27 13:38:20 --> Total execution time: 0.0563
INFO - 2025-03-27 13:38:27 --> Config Class Initialized
INFO - 2025-03-27 13:38:27 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:38:27 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:38:27 --> Utf8 Class Initialized
INFO - 2025-03-27 13:38:27 --> URI Class Initialized
DEBUG - 2025-03-27 13:38:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 13:38:27 --> Router Class Initialized
INFO - 2025-03-27 13:38:27 --> Output Class Initialized
INFO - 2025-03-27 13:38:27 --> Security Class Initialized
DEBUG - 2025-03-27 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:38:27 --> Input Class Initialized
INFO - 2025-03-27 13:38:27 --> Language Class Initialized
INFO - 2025-03-27 13:38:27 --> Language Class Initialized
INFO - 2025-03-27 13:38:27 --> Config Class Initialized
INFO - 2025-03-27 13:38:27 --> Loader Class Initialized
INFO - 2025-03-27 13:38:27 --> Helper loaded: url_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: file_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: html_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: form_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: text_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:38:27 --> Database Driver Class Initialized
INFO - 2025-03-27 13:38:27 --> Email Class Initialized
INFO - 2025-03-27 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:38:27 --> Form Validation Class Initialized
INFO - 2025-03-27 13:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:38:27 --> Pagination Class Initialized
INFO - 2025-03-27 13:38:27 --> Controller Class Initialized
DEBUG - 2025-03-27 13:38:27 --> Auth MX_Controller Initialized
INFO - 2025-03-27 13:38:27 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 13:38:27 --> Model Class Initialized
INFO - 2025-03-27 13:38:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 13:38:27 --> Config Class Initialized
INFO - 2025-03-27 13:38:27 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:38:27 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:38:27 --> Utf8 Class Initialized
INFO - 2025-03-27 13:38:27 --> URI Class Initialized
DEBUG - 2025-03-27 13:38:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 13:38:27 --> Router Class Initialized
INFO - 2025-03-27 13:38:27 --> Output Class Initialized
INFO - 2025-03-27 13:38:27 --> Security Class Initialized
DEBUG - 2025-03-27 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:38:27 --> Input Class Initialized
INFO - 2025-03-27 13:38:27 --> Language Class Initialized
INFO - 2025-03-27 13:38:27 --> Language Class Initialized
INFO - 2025-03-27 13:38:27 --> Config Class Initialized
INFO - 2025-03-27 13:38:27 --> Loader Class Initialized
INFO - 2025-03-27 13:38:27 --> Helper loaded: url_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: file_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: html_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: form_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: text_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:38:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:38:27 --> Database Driver Class Initialized
INFO - 2025-03-27 13:38:27 --> Email Class Initialized
INFO - 2025-03-27 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:38:27 --> Form Validation Class Initialized
INFO - 2025-03-27 13:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:38:27 --> Pagination Class Initialized
INFO - 2025-03-27 13:38:27 --> Controller Class Initialized
DEBUG - 2025-03-27 13:38:27 --> Home MX_Controller Initialized
INFO - 2025-03-27 13:38:27 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-27 13:38:27 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 13:38:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 13:38:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 13:38:27 --> Model Class Initialized
ERROR - 2025-03-27 13:38:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 13:38:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 13:38:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 13:38:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 13:38:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 13:38:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 13:38:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-27 13:38:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 13:38:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 13:38:28 --> Final output sent to browser
DEBUG - 2025-03-27 13:38:28 --> Total execution time: 0.4339
INFO - 2025-03-27 13:38:37 --> Config Class Initialized
INFO - 2025-03-27 13:38:37 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:38:37 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:38:37 --> Utf8 Class Initialized
INFO - 2025-03-27 13:38:37 --> URI Class Initialized
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 13:38:37 --> Router Class Initialized
INFO - 2025-03-27 13:38:37 --> Output Class Initialized
INFO - 2025-03-27 13:38:37 --> Security Class Initialized
DEBUG - 2025-03-27 13:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:38:37 --> Input Class Initialized
INFO - 2025-03-27 13:38:37 --> Language Class Initialized
INFO - 2025-03-27 13:38:37 --> Language Class Initialized
INFO - 2025-03-27 13:38:37 --> Config Class Initialized
INFO - 2025-03-27 13:38:37 --> Loader Class Initialized
INFO - 2025-03-27 13:38:37 --> Helper loaded: url_helper
INFO - 2025-03-27 13:38:37 --> Helper loaded: file_helper
INFO - 2025-03-27 13:38:37 --> Helper loaded: html_helper
INFO - 2025-03-27 13:38:37 --> Helper loaded: form_helper
INFO - 2025-03-27 13:38:37 --> Helper loaded: text_helper
INFO - 2025-03-27 13:38:37 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:38:37 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:38:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:38:37 --> Database Driver Class Initialized
INFO - 2025-03-27 13:38:37 --> Email Class Initialized
INFO - 2025-03-27 13:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:38:37 --> Form Validation Class Initialized
INFO - 2025-03-27 13:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:38:37 --> Pagination Class Initialized
INFO - 2025-03-27 13:38:37 --> Controller Class Initialized
DEBUG - 2025-03-27 13:38:37 --> Product MX_Controller Initialized
INFO - 2025-03-27 13:38:37 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 13:38:37 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 13:38:37 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 13:38:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 13:38:37 --> Model Class Initialized
ERROR - 2025-03-27 13:38:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 13:38:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 13:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 13:38:37 --> Final output sent to browser
DEBUG - 2025-03-27 13:38:37 --> Total execution time: 0.1283
INFO - 2025-03-27 13:38:38 --> Config Class Initialized
INFO - 2025-03-27 13:38:38 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:38:38 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:38:38 --> Utf8 Class Initialized
INFO - 2025-03-27 13:38:38 --> URI Class Initialized
DEBUG - 2025-03-27 13:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 13:38:38 --> Router Class Initialized
INFO - 2025-03-27 13:38:38 --> Output Class Initialized
INFO - 2025-03-27 13:38:38 --> Security Class Initialized
DEBUG - 2025-03-27 13:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:38:38 --> Input Class Initialized
INFO - 2025-03-27 13:38:38 --> Language Class Initialized
INFO - 2025-03-27 13:38:38 --> Language Class Initialized
INFO - 2025-03-27 13:38:38 --> Config Class Initialized
INFO - 2025-03-27 13:38:38 --> Loader Class Initialized
INFO - 2025-03-27 13:38:38 --> Helper loaded: url_helper
INFO - 2025-03-27 13:38:38 --> Helper loaded: file_helper
INFO - 2025-03-27 13:38:38 --> Helper loaded: html_helper
INFO - 2025-03-27 13:38:38 --> Helper loaded: form_helper
INFO - 2025-03-27 13:38:38 --> Helper loaded: text_helper
INFO - 2025-03-27 13:38:38 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:38:38 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:38:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:38:38 --> Database Driver Class Initialized
INFO - 2025-03-27 13:38:38 --> Email Class Initialized
INFO - 2025-03-27 13:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:38:38 --> Form Validation Class Initialized
INFO - 2025-03-27 13:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:38:38 --> Pagination Class Initialized
INFO - 2025-03-27 13:38:38 --> Controller Class Initialized
DEBUG - 2025-03-27 13:38:38 --> Product MX_Controller Initialized
INFO - 2025-03-27 13:38:38 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 13:38:38 --> Model Class Initialized
DEBUG - 2025-03-27 13:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 13:38:38 --> Model Class Initialized
ERROR - 2025-03-27 13:38:38 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:38:38 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:38:38 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:38:38 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:38:38 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:38:38 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 13:38:38 --> Final output sent to browser
DEBUG - 2025-03-27 13:38:38 --> Total execution time: 0.0315
INFO - 2025-03-27 13:39:25 --> Config Class Initialized
INFO - 2025-03-27 13:39:25 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:39:25 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:39:25 --> Utf8 Class Initialized
INFO - 2025-03-27 13:39:25 --> URI Class Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 13:39:25 --> Router Class Initialized
INFO - 2025-03-27 13:39:25 --> Output Class Initialized
INFO - 2025-03-27 13:39:25 --> Security Class Initialized
DEBUG - 2025-03-27 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:39:25 --> Input Class Initialized
INFO - 2025-03-27 13:39:25 --> Language Class Initialized
INFO - 2025-03-27 13:39:25 --> Language Class Initialized
INFO - 2025-03-27 13:39:25 --> Config Class Initialized
INFO - 2025-03-27 13:39:25 --> Loader Class Initialized
INFO - 2025-03-27 13:39:25 --> Helper loaded: url_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: file_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: html_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: form_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: text_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:39:25 --> Database Driver Class Initialized
INFO - 2025-03-27 13:39:25 --> Email Class Initialized
INFO - 2025-03-27 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:39:25 --> Form Validation Class Initialized
INFO - 2025-03-27 13:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:39:25 --> Pagination Class Initialized
INFO - 2025-03-27 13:39:25 --> Controller Class Initialized
DEBUG - 2025-03-27 13:39:25 --> Product MX_Controller Initialized
INFO - 2025-03-27 13:39:25 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 13:39:25 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 13:39:25 --> Model Class Initialized
INFO - 2025-03-27 13:39:25 --> Config Class Initialized
INFO - 2025-03-27 13:39:25 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:39:25 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:39:25 --> Utf8 Class Initialized
INFO - 2025-03-27 13:39:25 --> URI Class Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 13:39:25 --> Router Class Initialized
INFO - 2025-03-27 13:39:25 --> Output Class Initialized
INFO - 2025-03-27 13:39:25 --> Security Class Initialized
DEBUG - 2025-03-27 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:39:25 --> Input Class Initialized
INFO - 2025-03-27 13:39:25 --> Language Class Initialized
INFO - 2025-03-27 13:39:25 --> Language Class Initialized
INFO - 2025-03-27 13:39:25 --> Config Class Initialized
INFO - 2025-03-27 13:39:25 --> Loader Class Initialized
INFO - 2025-03-27 13:39:25 --> Helper loaded: url_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: file_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: html_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: form_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: text_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:39:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:39:25 --> Database Driver Class Initialized
INFO - 2025-03-27 13:39:25 --> Email Class Initialized
INFO - 2025-03-27 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:39:25 --> Form Validation Class Initialized
INFO - 2025-03-27 13:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:39:25 --> Pagination Class Initialized
INFO - 2025-03-27 13:39:25 --> Controller Class Initialized
DEBUG - 2025-03-27 13:39:25 --> Auth MX_Controller Initialized
INFO - 2025-03-27 13:39:25 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 13:39:25 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 13:39:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 13:39:25 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 13:39:25 --> Final output sent to browser
DEBUG - 2025-03-27 13:39:25 --> Total execution time: 0.0127
INFO - 2025-03-27 13:39:46 --> Config Class Initialized
INFO - 2025-03-27 13:39:46 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:39:46 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:39:46 --> Utf8 Class Initialized
INFO - 2025-03-27 13:39:46 --> URI Class Initialized
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 13:39:46 --> Router Class Initialized
INFO - 2025-03-27 13:39:46 --> Output Class Initialized
INFO - 2025-03-27 13:39:46 --> Security Class Initialized
DEBUG - 2025-03-27 13:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:39:46 --> Input Class Initialized
INFO - 2025-03-27 13:39:46 --> Language Class Initialized
INFO - 2025-03-27 13:39:46 --> Language Class Initialized
INFO - 2025-03-27 13:39:46 --> Config Class Initialized
INFO - 2025-03-27 13:39:46 --> Loader Class Initialized
INFO - 2025-03-27 13:39:46 --> Helper loaded: url_helper
INFO - 2025-03-27 13:39:46 --> Helper loaded: file_helper
INFO - 2025-03-27 13:39:46 --> Helper loaded: html_helper
INFO - 2025-03-27 13:39:46 --> Helper loaded: form_helper
INFO - 2025-03-27 13:39:46 --> Helper loaded: text_helper
INFO - 2025-03-27 13:39:46 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:39:46 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:39:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:39:46 --> Database Driver Class Initialized
INFO - 2025-03-27 13:39:46 --> Email Class Initialized
INFO - 2025-03-27 13:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:39:46 --> Form Validation Class Initialized
INFO - 2025-03-27 13:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:39:46 --> Pagination Class Initialized
INFO - 2025-03-27 13:39:46 --> Controller Class Initialized
DEBUG - 2025-03-27 13:39:46 --> Product MX_Controller Initialized
INFO - 2025-03-27 13:39:46 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 13:39:46 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 13:39:46 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 13:39:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 13:39:46 --> Model Class Initialized
ERROR - 2025-03-27 13:39:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 13:39:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 13:39:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 13:39:46 --> Final output sent to browser
DEBUG - 2025-03-27 13:39:46 --> Total execution time: 0.1089
INFO - 2025-03-27 13:39:47 --> Config Class Initialized
INFO - 2025-03-27 13:39:47 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:39:47 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:39:47 --> Utf8 Class Initialized
INFO - 2025-03-27 13:39:47 --> URI Class Initialized
DEBUG - 2025-03-27 13:39:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 13:39:47 --> Router Class Initialized
INFO - 2025-03-27 13:39:47 --> Output Class Initialized
INFO - 2025-03-27 13:39:47 --> Security Class Initialized
DEBUG - 2025-03-27 13:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:39:47 --> Input Class Initialized
INFO - 2025-03-27 13:39:47 --> Language Class Initialized
INFO - 2025-03-27 13:39:47 --> Language Class Initialized
INFO - 2025-03-27 13:39:47 --> Config Class Initialized
INFO - 2025-03-27 13:39:47 --> Loader Class Initialized
INFO - 2025-03-27 13:39:47 --> Helper loaded: url_helper
INFO - 2025-03-27 13:39:47 --> Helper loaded: file_helper
INFO - 2025-03-27 13:39:47 --> Helper loaded: html_helper
INFO - 2025-03-27 13:39:47 --> Helper loaded: form_helper
INFO - 2025-03-27 13:39:47 --> Helper loaded: text_helper
INFO - 2025-03-27 13:39:47 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:39:47 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:39:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:39:47 --> Database Driver Class Initialized
INFO - 2025-03-27 13:39:47 --> Email Class Initialized
INFO - 2025-03-27 13:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:39:47 --> Form Validation Class Initialized
INFO - 2025-03-27 13:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:39:47 --> Pagination Class Initialized
INFO - 2025-03-27 13:39:47 --> Controller Class Initialized
DEBUG - 2025-03-27 13:39:47 --> Product MX_Controller Initialized
INFO - 2025-03-27 13:39:47 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 13:39:47 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 13:39:47 --> Model Class Initialized
ERROR - 2025-03-27 13:39:47 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:47 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:47 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:47 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:47 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:47 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 13:39:47 --> Final output sent to browser
DEBUG - 2025-03-27 13:39:47 --> Total execution time: 0.0394
INFO - 2025-03-27 13:39:50 --> Config Class Initialized
INFO - 2025-03-27 13:39:50 --> Hooks Class Initialized
DEBUG - 2025-03-27 13:39:50 --> UTF-8 Support Enabled
INFO - 2025-03-27 13:39:50 --> Utf8 Class Initialized
INFO - 2025-03-27 13:39:50 --> URI Class Initialized
DEBUG - 2025-03-27 13:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-27 13:39:50 --> Router Class Initialized
INFO - 2025-03-27 13:39:50 --> Output Class Initialized
INFO - 2025-03-27 13:39:50 --> Security Class Initialized
DEBUG - 2025-03-27 13:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 13:39:50 --> Input Class Initialized
INFO - 2025-03-27 13:39:50 --> Language Class Initialized
INFO - 2025-03-27 13:39:50 --> Language Class Initialized
INFO - 2025-03-27 13:39:50 --> Config Class Initialized
INFO - 2025-03-27 13:39:50 --> Loader Class Initialized
INFO - 2025-03-27 13:39:50 --> Helper loaded: url_helper
INFO - 2025-03-27 13:39:50 --> Helper loaded: file_helper
INFO - 2025-03-27 13:39:50 --> Helper loaded: html_helper
INFO - 2025-03-27 13:39:50 --> Helper loaded: form_helper
INFO - 2025-03-27 13:39:50 --> Helper loaded: text_helper
INFO - 2025-03-27 13:39:50 --> Helper loaded: lang_helper
INFO - 2025-03-27 13:39:50 --> Helper loaded: directory_helper
INFO - 2025-03-27 13:39:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 13:39:50 --> Database Driver Class Initialized
INFO - 2025-03-27 13:39:50 --> Email Class Initialized
INFO - 2025-03-27 13:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 13:39:50 --> Form Validation Class Initialized
INFO - 2025-03-27 13:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 13:39:50 --> Pagination Class Initialized
INFO - 2025-03-27 13:39:50 --> Controller Class Initialized
DEBUG - 2025-03-27 13:39:50 --> Product MX_Controller Initialized
INFO - 2025-03-27 13:39:50 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-27 13:39:50 --> Model Class Initialized
DEBUG - 2025-03-27 13:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-27 13:39:50 --> Model Class Initialized
ERROR - 2025-03-27 13:39:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:50 --> Severity: Warning --> Undefined property: stdClass::$price /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php 386
ERROR - 2025-03-27 13:39:50 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 5
    [iTotalDisplayRecords] => 5
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => 
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/my-assets/image/product.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-14/6c3b46c501892b0d0528a82b24b9e674.jpeg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="Qr-Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-03-27 13:39:50 --> Final output sent to browser
DEBUG - 2025-03-27 13:39:50 --> Total execution time: 0.0303
INFO - 2025-03-27 23:35:26 --> Config Class Initialized
INFO - 2025-03-27 23:35:26 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:26 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:26 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:26 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:35:26 --> Router Class Initialized
INFO - 2025-03-27 23:35:26 --> Output Class Initialized
INFO - 2025-03-27 23:35:26 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:26 --> Input Class Initialized
INFO - 2025-03-27 23:35:26 --> Language Class Initialized
INFO - 2025-03-27 23:35:26 --> Language Class Initialized
INFO - 2025-03-27 23:35:26 --> Config Class Initialized
INFO - 2025-03-27 23:35:26 --> Loader Class Initialized
INFO - 2025-03-27 23:35:26 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:26 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:26 --> Email Class Initialized
INFO - 2025-03-27 23:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:26 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:26 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:26 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:26 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:35:26 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:35:26 --> Model Class Initialized
INFO - 2025-03-27 23:35:26 --> Config Class Initialized
INFO - 2025-03-27 23:35:26 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:26 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:26 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:26 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 23:35:26 --> Router Class Initialized
INFO - 2025-03-27 23:35:26 --> Output Class Initialized
INFO - 2025-03-27 23:35:26 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:26 --> Input Class Initialized
INFO - 2025-03-27 23:35:26 --> Language Class Initialized
INFO - 2025-03-27 23:35:26 --> Language Class Initialized
INFO - 2025-03-27 23:35:26 --> Config Class Initialized
INFO - 2025-03-27 23:35:26 --> Loader Class Initialized
INFO - 2025-03-27 23:35:26 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:26 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:26 --> Email Class Initialized
INFO - 2025-03-27 23:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:26 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:26 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:26 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:26 --> Auth MX_Controller Initialized
INFO - 2025-03-27 23:35:26 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 23:35:26 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:35:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:35:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:35:26 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-27 23:35:26 --> Final output sent to browser
DEBUG - 2025-03-27 23:35:26 --> Total execution time: 0.0162
INFO - 2025-03-27 23:35:36 --> Config Class Initialized
INFO - 2025-03-27 23:35:36 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:36 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:36 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:36 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 23:35:36 --> Router Class Initialized
INFO - 2025-03-27 23:35:36 --> Output Class Initialized
INFO - 2025-03-27 23:35:36 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:36 --> Input Class Initialized
INFO - 2025-03-27 23:35:36 --> Language Class Initialized
INFO - 2025-03-27 23:35:36 --> Language Class Initialized
INFO - 2025-03-27 23:35:36 --> Config Class Initialized
INFO - 2025-03-27 23:35:36 --> Loader Class Initialized
INFO - 2025-03-27 23:35:36 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:36 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:36 --> Email Class Initialized
INFO - 2025-03-27 23:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:36 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:36 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:36 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:36 --> Auth MX_Controller Initialized
INFO - 2025-03-27 23:35:36 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-27 23:35:36 --> Model Class Initialized
INFO - 2025-03-27 23:35:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 23:35:36 --> Config Class Initialized
INFO - 2025-03-27 23:35:36 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:36 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:36 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:36 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-27 23:35:36 --> Router Class Initialized
INFO - 2025-03-27 23:35:36 --> Output Class Initialized
INFO - 2025-03-27 23:35:36 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:36 --> Input Class Initialized
INFO - 2025-03-27 23:35:36 --> Language Class Initialized
INFO - 2025-03-27 23:35:36 --> Language Class Initialized
INFO - 2025-03-27 23:35:36 --> Config Class Initialized
INFO - 2025-03-27 23:35:36 --> Loader Class Initialized
INFO - 2025-03-27 23:35:36 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:36 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:36 --> Email Class Initialized
INFO - 2025-03-27 23:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:36 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:36 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:36 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:36 --> Home MX_Controller Initialized
INFO - 2025-03-27 23:35:36 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-27 23:35:36 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:35:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:35:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:35:36 --> Model Class Initialized
ERROR - 2025-03-27 23:35:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:35:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:35:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:35:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:35:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:35:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:35:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-27 23:35:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:35:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:35:37 --> Final output sent to browser
DEBUG - 2025-03-27 23:35:37 --> Total execution time: 0.8512
INFO - 2025-03-27 23:35:43 --> Config Class Initialized
INFO - 2025-03-27 23:35:43 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:43 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:43 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:43 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:35:43 --> Router Class Initialized
INFO - 2025-03-27 23:35:43 --> Output Class Initialized
INFO - 2025-03-27 23:35:43 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:43 --> Input Class Initialized
INFO - 2025-03-27 23:35:43 --> Language Class Initialized
INFO - 2025-03-27 23:35:43 --> Language Class Initialized
INFO - 2025-03-27 23:35:43 --> Config Class Initialized
INFO - 2025-03-27 23:35:43 --> Loader Class Initialized
INFO - 2025-03-27 23:35:43 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:43 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:43 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:43 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:43 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:43 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:43 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:43 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:43 --> Email Class Initialized
INFO - 2025-03-27 23:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:43 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:43 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:43 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:43 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:35:43 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:35:43 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:35:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:35:43 --> Model Class Initialized
ERROR - 2025-03-27 23:35:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:35:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:35:43 --> Final output sent to browser
DEBUG - 2025-03-27 23:35:43 --> Total execution time: 0.1256
INFO - 2025-03-27 23:35:43 --> Config Class Initialized
INFO - 2025-03-27 23:35:43 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:43 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:43 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:44 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:35:44 --> Router Class Initialized
INFO - 2025-03-27 23:35:44 --> Output Class Initialized
INFO - 2025-03-27 23:35:44 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:44 --> Input Class Initialized
INFO - 2025-03-27 23:35:44 --> Language Class Initialized
INFO - 2025-03-27 23:35:44 --> Language Class Initialized
INFO - 2025-03-27 23:35:44 --> Config Class Initialized
INFO - 2025-03-27 23:35:44 --> Loader Class Initialized
INFO - 2025-03-27 23:35:44 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:44 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:44 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:44 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:44 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:44 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:44 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:44 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:44 --> Email Class Initialized
INFO - 2025-03-27 23:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:44 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:44 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:44 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:44 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:35:44 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:35:44 --> Model Class Initialized
ERROR - 2025-03-27 23:35:44 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:35:44 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:35:44 --> Received customer_id: null
ERROR - 2025-03-27 23:35:44 --> Received customfiled: null
ERROR - 2025-03-27 23:35:44 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:35:44 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:35:44 --> Search value: 
ERROR - 2025-03-27 23:35:44 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:35:44 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:35:44 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:35:44 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:35:44 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:35:48 --> Config Class Initialized
INFO - 2025-03-27 23:35:48 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:48 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:48 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:48 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:35:48 --> Router Class Initialized
INFO - 2025-03-27 23:35:48 --> Output Class Initialized
INFO - 2025-03-27 23:35:48 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:48 --> Input Class Initialized
INFO - 2025-03-27 23:35:48 --> Language Class Initialized
INFO - 2025-03-27 23:35:48 --> Language Class Initialized
INFO - 2025-03-27 23:35:48 --> Config Class Initialized
INFO - 2025-03-27 23:35:48 --> Loader Class Initialized
INFO - 2025-03-27 23:35:48 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:48 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:48 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:48 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:48 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:48 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:48 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:48 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:48 --> Email Class Initialized
INFO - 2025-03-27 23:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:48 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:48 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:48 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:48 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:35:48 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:35:48 --> Model Class Initialized
ERROR - 2025-03-27 23:35:48 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:35:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:35:48 --> Model Class Initialized
ERROR - 2025-03-27 23:35:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:35:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:35:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:35:48 --> Final output sent to browser
DEBUG - 2025-03-27 23:35:48 --> Total execution time: 0.0919
INFO - 2025-03-27 23:35:55 --> Config Class Initialized
INFO - 2025-03-27 23:35:55 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:35:55 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:35:55 --> Utf8 Class Initialized
INFO - 2025-03-27 23:35:55 --> URI Class Initialized
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:35:55 --> Router Class Initialized
INFO - 2025-03-27 23:35:55 --> Output Class Initialized
INFO - 2025-03-27 23:35:55 --> Security Class Initialized
DEBUG - 2025-03-27 23:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:35:55 --> Input Class Initialized
INFO - 2025-03-27 23:35:55 --> Language Class Initialized
INFO - 2025-03-27 23:35:55 --> Language Class Initialized
INFO - 2025-03-27 23:35:55 --> Config Class Initialized
INFO - 2025-03-27 23:35:55 --> Loader Class Initialized
INFO - 2025-03-27 23:35:55 --> Helper loaded: url_helper
INFO - 2025-03-27 23:35:55 --> Helper loaded: file_helper
INFO - 2025-03-27 23:35:55 --> Helper loaded: html_helper
INFO - 2025-03-27 23:35:55 --> Helper loaded: form_helper
INFO - 2025-03-27 23:35:55 --> Helper loaded: text_helper
INFO - 2025-03-27 23:35:55 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:35:55 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:35:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:35:55 --> Database Driver Class Initialized
INFO - 2025-03-27 23:35:55 --> Email Class Initialized
INFO - 2025-03-27 23:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:35:55 --> Form Validation Class Initialized
INFO - 2025-03-27 23:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:35:55 --> Pagination Class Initialized
INFO - 2025-03-27 23:35:55 --> Controller Class Initialized
DEBUG - 2025-03-27 23:35:55 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:35:55 --> Model Class Initialized
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:35:55 --> Model Class Initialized
ERROR - 2025-03-27 23:35:55 --> DEBUG: File Upload Attempt - Filename: 
INFO - 2025-03-27 23:35:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:35:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:35:55 --> Model Class Initialized
ERROR - 2025-03-27 23:35:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:35:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:35:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:35:55 --> Final output sent to browser
DEBUG - 2025-03-27 23:35:55 --> Total execution time: 0.1342
INFO - 2025-03-27 23:36:00 --> Config Class Initialized
INFO - 2025-03-27 23:36:00 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:00 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:00 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:00 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:00 --> Router Class Initialized
INFO - 2025-03-27 23:36:00 --> Output Class Initialized
INFO - 2025-03-27 23:36:00 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:00 --> Input Class Initialized
INFO - 2025-03-27 23:36:00 --> Language Class Initialized
INFO - 2025-03-27 23:36:00 --> Language Class Initialized
INFO - 2025-03-27 23:36:00 --> Config Class Initialized
INFO - 2025-03-27 23:36:00 --> Loader Class Initialized
INFO - 2025-03-27 23:36:00 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:00 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:00 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:00 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:00 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:00 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:00 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:00 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:00 --> Email Class Initialized
INFO - 2025-03-27 23:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:00 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:00 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:00 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:00 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:00 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:00 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:36:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:36:00 --> Model Class Initialized
ERROR - 2025-03-27 23:36:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:36:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:36:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:36:00 --> Final output sent to browser
DEBUG - 2025-03-27 23:36:00 --> Total execution time: 0.1169
INFO - 2025-03-27 23:36:01 --> Config Class Initialized
INFO - 2025-03-27 23:36:01 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:01 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:01 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:01 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:01 --> Router Class Initialized
INFO - 2025-03-27 23:36:01 --> Output Class Initialized
INFO - 2025-03-27 23:36:01 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:01 --> Input Class Initialized
INFO - 2025-03-27 23:36:01 --> Language Class Initialized
INFO - 2025-03-27 23:36:01 --> Language Class Initialized
INFO - 2025-03-27 23:36:01 --> Config Class Initialized
INFO - 2025-03-27 23:36:01 --> Loader Class Initialized
INFO - 2025-03-27 23:36:01 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:01 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:01 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:01 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:01 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:01 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:01 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:01 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:01 --> Email Class Initialized
INFO - 2025-03-27 23:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:01 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:01 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:01 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:01 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:01 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:01 --> Model Class Initialized
ERROR - 2025-03-27 23:36:01 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:36:01 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:36:01 --> Received customer_id: null
ERROR - 2025-03-27 23:36:01 --> Received customfiled: null
ERROR - 2025-03-27 23:36:01 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:36:01 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:36:01 --> Search value: 
ERROR - 2025-03-27 23:36:01 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:36:01 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:36:01 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:36:01 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:36:01 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:36:03 --> Config Class Initialized
INFO - 2025-03-27 23:36:03 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:03 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:03 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:03 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:03 --> Router Class Initialized
INFO - 2025-03-27 23:36:03 --> Output Class Initialized
INFO - 2025-03-27 23:36:03 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:03 --> Input Class Initialized
INFO - 2025-03-27 23:36:03 --> Language Class Initialized
INFO - 2025-03-27 23:36:03 --> Language Class Initialized
INFO - 2025-03-27 23:36:03 --> Config Class Initialized
INFO - 2025-03-27 23:36:03 --> Loader Class Initialized
INFO - 2025-03-27 23:36:03 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:03 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:03 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:03 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:03 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:03 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:03 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:03 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:03 --> Email Class Initialized
INFO - 2025-03-27 23:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:03 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:03 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:03 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:03 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:03 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:03 --> Model Class Initialized
ERROR - 2025-03-27 23:36:03 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:36:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:36:03 --> Model Class Initialized
ERROR - 2025-03-27 23:36:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:36:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:36:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:36:03 --> Final output sent to browser
DEBUG - 2025-03-27 23:36:03 --> Total execution time: 0.0911
INFO - 2025-03-27 23:36:06 --> Config Class Initialized
INFO - 2025-03-27 23:36:06 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:06 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:06 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:06 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:06 --> Router Class Initialized
INFO - 2025-03-27 23:36:06 --> Output Class Initialized
INFO - 2025-03-27 23:36:06 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:06 --> Input Class Initialized
INFO - 2025-03-27 23:36:06 --> Language Class Initialized
INFO - 2025-03-27 23:36:06 --> Language Class Initialized
INFO - 2025-03-27 23:36:06 --> Config Class Initialized
INFO - 2025-03-27 23:36:06 --> Loader Class Initialized
INFO - 2025-03-27 23:36:06 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:06 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:06 --> Email Class Initialized
INFO - 2025-03-27 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:06 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:06 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:06 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:06 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:06 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:06 --> Model Class Initialized
ERROR - 2025-03-27 23:36:06 --> DEBUG: File Upload Attempt - Filename: 
INFO - 2025-03-27 23:36:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 23:36:06 --> Config Class Initialized
INFO - 2025-03-27 23:36:06 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:06 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:06 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:06 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:06 --> Router Class Initialized
INFO - 2025-03-27 23:36:06 --> Output Class Initialized
INFO - 2025-03-27 23:36:06 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:06 --> Input Class Initialized
INFO - 2025-03-27 23:36:06 --> Language Class Initialized
INFO - 2025-03-27 23:36:06 --> Language Class Initialized
INFO - 2025-03-27 23:36:06 --> Config Class Initialized
INFO - 2025-03-27 23:36:06 --> Loader Class Initialized
INFO - 2025-03-27 23:36:06 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:06 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:06 --> Email Class Initialized
INFO - 2025-03-27 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:06 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:06 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:06 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:06 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:06 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:06 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:36:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:36:06 --> Model Class Initialized
ERROR - 2025-03-27 23:36:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:36:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:36:06 --> Final output sent to browser
DEBUG - 2025-03-27 23:36:06 --> Total execution time: 0.1064
INFO - 2025-03-27 23:36:06 --> Config Class Initialized
INFO - 2025-03-27 23:36:06 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:06 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:06 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:06 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:06 --> Router Class Initialized
INFO - 2025-03-27 23:36:06 --> Output Class Initialized
INFO - 2025-03-27 23:36:06 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:06 --> Input Class Initialized
INFO - 2025-03-27 23:36:06 --> Language Class Initialized
INFO - 2025-03-27 23:36:06 --> Language Class Initialized
INFO - 2025-03-27 23:36:06 --> Config Class Initialized
INFO - 2025-03-27 23:36:06 --> Loader Class Initialized
INFO - 2025-03-27 23:36:06 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:06 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:06 --> Email Class Initialized
INFO - 2025-03-27 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:06 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:06 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:06 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:06 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:06 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:06 --> Model Class Initialized
ERROR - 2025-03-27 23:36:06 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:36:06 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:36:06 --> Received customer_id: null
ERROR - 2025-03-27 23:36:06 --> Received customfiled: null
ERROR - 2025-03-27 23:36:06 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:36:06 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:36:06 --> Search value: 
ERROR - 2025-03-27 23:36:06 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:36:06 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:36:06 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:36:06 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:36:06 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:36:11 --> Config Class Initialized
INFO - 2025-03-27 23:36:11 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:11 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:11 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:11 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:11 --> Router Class Initialized
INFO - 2025-03-27 23:36:11 --> Output Class Initialized
INFO - 2025-03-27 23:36:11 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:11 --> Input Class Initialized
INFO - 2025-03-27 23:36:11 --> Language Class Initialized
INFO - 2025-03-27 23:36:11 --> Language Class Initialized
INFO - 2025-03-27 23:36:11 --> Config Class Initialized
INFO - 2025-03-27 23:36:11 --> Loader Class Initialized
INFO - 2025-03-27 23:36:11 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:11 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:11 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:11 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:11 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:11 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:11 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:11 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:11 --> Email Class Initialized
INFO - 2025-03-27 23:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:11 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:11 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:11 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:11 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:11 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:11 --> Model Class Initialized
ERROR - 2025-03-27 23:36:11 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:36:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:36:11 --> Model Class Initialized
ERROR - 2025-03-27 23:36:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:36:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:36:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:36:11 --> Final output sent to browser
DEBUG - 2025-03-27 23:36:11 --> Total execution time: 0.1330
INFO - 2025-03-27 23:36:24 --> Config Class Initialized
INFO - 2025-03-27 23:36:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:24 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:24 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:24 --> Router Class Initialized
INFO - 2025-03-27 23:36:24 --> Output Class Initialized
INFO - 2025-03-27 23:36:24 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:24 --> Input Class Initialized
INFO - 2025-03-27 23:36:24 --> Language Class Initialized
INFO - 2025-03-27 23:36:24 --> Language Class Initialized
INFO - 2025-03-27 23:36:24 --> Config Class Initialized
INFO - 2025-03-27 23:36:24 --> Loader Class Initialized
INFO - 2025-03-27 23:36:24 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:24 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:24 --> Email Class Initialized
INFO - 2025-03-27 23:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:24 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:24 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:24 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:24 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:24 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:24 --> Model Class Initialized
ERROR - 2025-03-27 23:36:24 --> DEBUG: File Upload Attempt - Filename: 
INFO - 2025-03-27 23:36:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 23:36:24 --> Config Class Initialized
INFO - 2025-03-27 23:36:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:24 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:24 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:24 --> Router Class Initialized
INFO - 2025-03-27 23:36:24 --> Output Class Initialized
INFO - 2025-03-27 23:36:24 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:24 --> Input Class Initialized
INFO - 2025-03-27 23:36:24 --> Language Class Initialized
INFO - 2025-03-27 23:36:24 --> Language Class Initialized
INFO - 2025-03-27 23:36:24 --> Config Class Initialized
INFO - 2025-03-27 23:36:24 --> Loader Class Initialized
INFO - 2025-03-27 23:36:24 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:24 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:24 --> Email Class Initialized
INFO - 2025-03-27 23:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:24 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:24 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:24 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:24 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:24 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:24 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:36:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:36:24 --> Model Class Initialized
ERROR - 2025-03-27 23:36:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:36:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:36:24 --> Final output sent to browser
DEBUG - 2025-03-27 23:36:24 --> Total execution time: 0.1034
INFO - 2025-03-27 23:36:24 --> Config Class Initialized
INFO - 2025-03-27 23:36:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:36:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:36:24 --> Utf8 Class Initialized
INFO - 2025-03-27 23:36:24 --> URI Class Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:36:24 --> Router Class Initialized
INFO - 2025-03-27 23:36:24 --> Output Class Initialized
INFO - 2025-03-27 23:36:24 --> Security Class Initialized
DEBUG - 2025-03-27 23:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:36:24 --> Input Class Initialized
INFO - 2025-03-27 23:36:24 --> Language Class Initialized
INFO - 2025-03-27 23:36:24 --> Language Class Initialized
INFO - 2025-03-27 23:36:24 --> Config Class Initialized
INFO - 2025-03-27 23:36:24 --> Loader Class Initialized
INFO - 2025-03-27 23:36:24 --> Helper loaded: url_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: file_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: html_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: form_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: text_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:36:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:36:24 --> Database Driver Class Initialized
INFO - 2025-03-27 23:36:24 --> Email Class Initialized
INFO - 2025-03-27 23:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:36:24 --> Form Validation Class Initialized
INFO - 2025-03-27 23:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:36:24 --> Pagination Class Initialized
INFO - 2025-03-27 23:36:24 --> Controller Class Initialized
DEBUG - 2025-03-27 23:36:24 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:36:24 --> Model Class Initialized
DEBUG - 2025-03-27 23:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:36:24 --> Model Class Initialized
ERROR - 2025-03-27 23:36:24 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:36:24 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:36:24 --> Received customer_id: null
ERROR - 2025-03-27 23:36:24 --> Received customfiled: null
ERROR - 2025-03-27 23:36:24 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:36:24 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:36:24 --> Search value: 
ERROR - 2025-03-27 23:36:24 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:36:24 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:36:24 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:36:24 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:36:24 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:37:32 --> Config Class Initialized
INFO - 2025-03-27 23:37:32 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:37:32 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:37:32 --> Utf8 Class Initialized
INFO - 2025-03-27 23:37:32 --> URI Class Initialized
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:37:32 --> Router Class Initialized
INFO - 2025-03-27 23:37:32 --> Output Class Initialized
INFO - 2025-03-27 23:37:32 --> Security Class Initialized
DEBUG - 2025-03-27 23:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:37:32 --> Input Class Initialized
INFO - 2025-03-27 23:37:32 --> Language Class Initialized
INFO - 2025-03-27 23:37:32 --> Language Class Initialized
INFO - 2025-03-27 23:37:32 --> Config Class Initialized
INFO - 2025-03-27 23:37:32 --> Loader Class Initialized
INFO - 2025-03-27 23:37:32 --> Helper loaded: url_helper
INFO - 2025-03-27 23:37:32 --> Helper loaded: file_helper
INFO - 2025-03-27 23:37:32 --> Helper loaded: html_helper
INFO - 2025-03-27 23:37:32 --> Helper loaded: form_helper
INFO - 2025-03-27 23:37:32 --> Helper loaded: text_helper
INFO - 2025-03-27 23:37:32 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:37:32 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:37:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:37:32 --> Database Driver Class Initialized
INFO - 2025-03-27 23:37:32 --> Email Class Initialized
INFO - 2025-03-27 23:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:37:32 --> Form Validation Class Initialized
INFO - 2025-03-27 23:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:37:32 --> Pagination Class Initialized
INFO - 2025-03-27 23:37:32 --> Controller Class Initialized
DEBUG - 2025-03-27 23:37:32 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:37:32 --> Model Class Initialized
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:37:32 --> Model Class Initialized
ERROR - 2025-03-27 23:37:32 --> DEBUG: File Upload Attempt - Filename: No File
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:37:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:37:32 --> Model Class Initialized
ERROR - 2025-03-27 23:37:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:37:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:37:32 --> Final output sent to browser
DEBUG - 2025-03-27 23:37:32 --> Total execution time: 0.1354
INFO - 2025-03-27 23:37:35 --> Config Class Initialized
INFO - 2025-03-27 23:37:35 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:37:35 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:37:35 --> Utf8 Class Initialized
INFO - 2025-03-27 23:37:35 --> URI Class Initialized
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:37:35 --> Router Class Initialized
INFO - 2025-03-27 23:37:35 --> Output Class Initialized
INFO - 2025-03-27 23:37:35 --> Security Class Initialized
DEBUG - 2025-03-27 23:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:37:35 --> Input Class Initialized
INFO - 2025-03-27 23:37:35 --> Language Class Initialized
INFO - 2025-03-27 23:37:35 --> Language Class Initialized
INFO - 2025-03-27 23:37:35 --> Config Class Initialized
INFO - 2025-03-27 23:37:35 --> Loader Class Initialized
INFO - 2025-03-27 23:37:35 --> Helper loaded: url_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: file_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: html_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: form_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: text_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:37:35 --> Database Driver Class Initialized
INFO - 2025-03-27 23:37:35 --> Email Class Initialized
INFO - 2025-03-27 23:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:37:35 --> Form Validation Class Initialized
INFO - 2025-03-27 23:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:37:35 --> Pagination Class Initialized
INFO - 2025-03-27 23:37:35 --> Controller Class Initialized
DEBUG - 2025-03-27 23:37:35 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:37:35 --> Model Class Initialized
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:37:35 --> Model Class Initialized
ERROR - 2025-03-27 23:37:35 --> DEBUG: File Upload Attempt - Filename: 
INFO - 2025-03-27 23:37:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-27 23:37:35 --> Config Class Initialized
INFO - 2025-03-27 23:37:35 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:37:35 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:37:35 --> Utf8 Class Initialized
INFO - 2025-03-27 23:37:35 --> URI Class Initialized
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:37:35 --> Router Class Initialized
INFO - 2025-03-27 23:37:35 --> Output Class Initialized
INFO - 2025-03-27 23:37:35 --> Security Class Initialized
DEBUG - 2025-03-27 23:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:37:35 --> Input Class Initialized
INFO - 2025-03-27 23:37:35 --> Language Class Initialized
INFO - 2025-03-27 23:37:35 --> Language Class Initialized
INFO - 2025-03-27 23:37:35 --> Config Class Initialized
INFO - 2025-03-27 23:37:35 --> Loader Class Initialized
INFO - 2025-03-27 23:37:35 --> Helper loaded: url_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: file_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: html_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: form_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: text_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:37:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:37:35 --> Database Driver Class Initialized
INFO - 2025-03-27 23:37:35 --> Email Class Initialized
INFO - 2025-03-27 23:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:37:35 --> Form Validation Class Initialized
INFO - 2025-03-27 23:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:37:35 --> Pagination Class Initialized
INFO - 2025-03-27 23:37:35 --> Controller Class Initialized
DEBUG - 2025-03-27 23:37:35 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:37:35 --> Model Class Initialized
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:37:35 --> Model Class Initialized
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:37:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:37:35 --> Model Class Initialized
ERROR - 2025-03-27 23:37:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:37:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:37:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:37:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:37:36 --> Final output sent to browser
DEBUG - 2025-03-27 23:37:36 --> Total execution time: 0.1011
INFO - 2025-03-27 23:37:36 --> Config Class Initialized
INFO - 2025-03-27 23:37:36 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:37:36 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:37:36 --> Utf8 Class Initialized
INFO - 2025-03-27 23:37:36 --> URI Class Initialized
DEBUG - 2025-03-27 23:37:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:37:36 --> Router Class Initialized
INFO - 2025-03-27 23:37:36 --> Output Class Initialized
INFO - 2025-03-27 23:37:36 --> Security Class Initialized
DEBUG - 2025-03-27 23:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:37:36 --> Input Class Initialized
INFO - 2025-03-27 23:37:36 --> Language Class Initialized
INFO - 2025-03-27 23:37:36 --> Language Class Initialized
INFO - 2025-03-27 23:37:36 --> Config Class Initialized
INFO - 2025-03-27 23:37:36 --> Loader Class Initialized
INFO - 2025-03-27 23:37:36 --> Helper loaded: url_helper
INFO - 2025-03-27 23:37:36 --> Helper loaded: file_helper
INFO - 2025-03-27 23:37:36 --> Helper loaded: html_helper
INFO - 2025-03-27 23:37:36 --> Helper loaded: form_helper
INFO - 2025-03-27 23:37:36 --> Helper loaded: text_helper
INFO - 2025-03-27 23:37:36 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:37:36 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:37:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:37:36 --> Database Driver Class Initialized
INFO - 2025-03-27 23:37:36 --> Email Class Initialized
INFO - 2025-03-27 23:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:37:36 --> Form Validation Class Initialized
INFO - 2025-03-27 23:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:37:36 --> Pagination Class Initialized
INFO - 2025-03-27 23:37:36 --> Controller Class Initialized
DEBUG - 2025-03-27 23:37:36 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:37:36 --> Model Class Initialized
DEBUG - 2025-03-27 23:37:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:37:36 --> Model Class Initialized
ERROR - 2025-03-27 23:37:36 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:37:36 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:37:36 --> Received customer_id: null
ERROR - 2025-03-27 23:37:36 --> Received customfiled: null
ERROR - 2025-03-27 23:37:36 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:37:36 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:37:36 --> Search value: 
ERROR - 2025-03-27 23:37:36 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:37:36 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:37:36 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:37:36 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:37:36 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:38:00 --> Config Class Initialized
INFO - 2025-03-27 23:38:00 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:38:00 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:38:00 --> Utf8 Class Initialized
INFO - 2025-03-27 23:38:00 --> URI Class Initialized
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:38:00 --> Router Class Initialized
INFO - 2025-03-27 23:38:00 --> Output Class Initialized
INFO - 2025-03-27 23:38:00 --> Security Class Initialized
DEBUG - 2025-03-27 23:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:38:00 --> Input Class Initialized
INFO - 2025-03-27 23:38:00 --> Language Class Initialized
INFO - 2025-03-27 23:38:00 --> Language Class Initialized
INFO - 2025-03-27 23:38:00 --> Config Class Initialized
INFO - 2025-03-27 23:38:00 --> Loader Class Initialized
INFO - 2025-03-27 23:38:00 --> Helper loaded: url_helper
INFO - 2025-03-27 23:38:00 --> Helper loaded: file_helper
INFO - 2025-03-27 23:38:00 --> Helper loaded: html_helper
INFO - 2025-03-27 23:38:00 --> Helper loaded: form_helper
INFO - 2025-03-27 23:38:00 --> Helper loaded: text_helper
INFO - 2025-03-27 23:38:00 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:38:00 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:38:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:38:00 --> Database Driver Class Initialized
INFO - 2025-03-27 23:38:00 --> Email Class Initialized
INFO - 2025-03-27 23:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:38:00 --> Form Validation Class Initialized
INFO - 2025-03-27 23:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:38:00 --> Pagination Class Initialized
INFO - 2025-03-27 23:38:00 --> Controller Class Initialized
DEBUG - 2025-03-27 23:38:00 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:38:00 --> Model Class Initialized
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:38:00 --> Model Class Initialized
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:38:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:38:00 --> Model Class Initialized
ERROR - 2025-03-27 23:38:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:38:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:38:00 --> Final output sent to browser
DEBUG - 2025-03-27 23:38:00 --> Total execution time: 0.1057
INFO - 2025-03-27 23:38:01 --> Config Class Initialized
INFO - 2025-03-27 23:38:01 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:38:01 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:38:01 --> Utf8 Class Initialized
INFO - 2025-03-27 23:38:01 --> URI Class Initialized
DEBUG - 2025-03-27 23:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:38:01 --> Router Class Initialized
INFO - 2025-03-27 23:38:01 --> Output Class Initialized
INFO - 2025-03-27 23:38:01 --> Security Class Initialized
DEBUG - 2025-03-27 23:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:38:01 --> Input Class Initialized
INFO - 2025-03-27 23:38:01 --> Language Class Initialized
INFO - 2025-03-27 23:38:01 --> Language Class Initialized
INFO - 2025-03-27 23:38:01 --> Config Class Initialized
INFO - 2025-03-27 23:38:01 --> Loader Class Initialized
INFO - 2025-03-27 23:38:01 --> Helper loaded: url_helper
INFO - 2025-03-27 23:38:01 --> Helper loaded: file_helper
INFO - 2025-03-27 23:38:01 --> Helper loaded: html_helper
INFO - 2025-03-27 23:38:01 --> Helper loaded: form_helper
INFO - 2025-03-27 23:38:01 --> Helper loaded: text_helper
INFO - 2025-03-27 23:38:01 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:38:01 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:38:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:38:01 --> Database Driver Class Initialized
INFO - 2025-03-27 23:38:01 --> Email Class Initialized
INFO - 2025-03-27 23:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:38:01 --> Form Validation Class Initialized
INFO - 2025-03-27 23:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:38:01 --> Pagination Class Initialized
INFO - 2025-03-27 23:38:01 --> Controller Class Initialized
DEBUG - 2025-03-27 23:38:01 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:38:01 --> Model Class Initialized
DEBUG - 2025-03-27 23:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:38:01 --> Model Class Initialized
ERROR - 2025-03-27 23:38:01 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:38:01 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:38:01 --> Received customer_id: null
ERROR - 2025-03-27 23:38:01 --> Received customfiled: null
ERROR - 2025-03-27 23:38:01 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:38:01 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:38:01 --> Search value: 
ERROR - 2025-03-27 23:38:01 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:38:01 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:38:01 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:38:01 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:38:01 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:38:08 --> Config Class Initialized
INFO - 2025-03-27 23:38:08 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:38:08 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:38:08 --> Utf8 Class Initialized
INFO - 2025-03-27 23:38:08 --> URI Class Initialized
DEBUG - 2025-03-27 23:38:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:38:08 --> Router Class Initialized
INFO - 2025-03-27 23:38:08 --> Output Class Initialized
INFO - 2025-03-27 23:38:08 --> Security Class Initialized
DEBUG - 2025-03-27 23:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:38:08 --> Input Class Initialized
INFO - 2025-03-27 23:38:08 --> Language Class Initialized
INFO - 2025-03-27 23:38:08 --> Language Class Initialized
INFO - 2025-03-27 23:38:08 --> Config Class Initialized
INFO - 2025-03-27 23:38:08 --> Loader Class Initialized
INFO - 2025-03-27 23:38:08 --> Helper loaded: url_helper
INFO - 2025-03-27 23:38:08 --> Helper loaded: file_helper
INFO - 2025-03-27 23:38:08 --> Helper loaded: html_helper
INFO - 2025-03-27 23:38:08 --> Helper loaded: form_helper
INFO - 2025-03-27 23:38:08 --> Helper loaded: text_helper
INFO - 2025-03-27 23:38:08 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:38:08 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:38:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:38:08 --> Database Driver Class Initialized
INFO - 2025-03-27 23:38:08 --> Email Class Initialized
INFO - 2025-03-27 23:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:38:08 --> Form Validation Class Initialized
INFO - 2025-03-27 23:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:38:08 --> Pagination Class Initialized
INFO - 2025-03-27 23:38:08 --> Controller Class Initialized
DEBUG - 2025-03-27 23:38:08 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:38:08 --> Model Class Initialized
DEBUG - 2025-03-27 23:38:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:38:08 --> Model Class Initialized
ERROR - 2025-03-27 23:38:08 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:38:08 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:38:08 --> Received customer_id: null
ERROR - 2025-03-27 23:38:08 --> Received customfiled: null
ERROR - 2025-03-27 23:38:08 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:38:08 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:38:08 --> Search value: 
ERROR - 2025-03-27 23:38:08 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:38:08 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:38:08 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:38:08 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:38:08 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:46:57 --> Config Class Initialized
INFO - 2025-03-27 23:46:57 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:46:57 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:46:57 --> Utf8 Class Initialized
INFO - 2025-03-27 23:46:57 --> URI Class Initialized
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:46:57 --> Router Class Initialized
INFO - 2025-03-27 23:46:57 --> Output Class Initialized
INFO - 2025-03-27 23:46:57 --> Security Class Initialized
DEBUG - 2025-03-27 23:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:46:57 --> Input Class Initialized
INFO - 2025-03-27 23:46:57 --> Language Class Initialized
INFO - 2025-03-27 23:46:57 --> Language Class Initialized
INFO - 2025-03-27 23:46:57 --> Config Class Initialized
INFO - 2025-03-27 23:46:57 --> Loader Class Initialized
INFO - 2025-03-27 23:46:57 --> Helper loaded: url_helper
INFO - 2025-03-27 23:46:57 --> Helper loaded: file_helper
INFO - 2025-03-27 23:46:57 --> Helper loaded: html_helper
INFO - 2025-03-27 23:46:57 --> Helper loaded: form_helper
INFO - 2025-03-27 23:46:57 --> Helper loaded: text_helper
INFO - 2025-03-27 23:46:57 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:46:57 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:46:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:46:57 --> Database Driver Class Initialized
INFO - 2025-03-27 23:46:57 --> Email Class Initialized
INFO - 2025-03-27 23:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:46:57 --> Form Validation Class Initialized
INFO - 2025-03-27 23:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:46:57 --> Pagination Class Initialized
INFO - 2025-03-27 23:46:57 --> Controller Class Initialized
DEBUG - 2025-03-27 23:46:57 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:46:57 --> Model Class Initialized
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:46:57 --> Model Class Initialized
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:46:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:46:57 --> Model Class Initialized
ERROR - 2025-03-27 23:46:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:46:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:46:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:46:57 --> Final output sent to browser
DEBUG - 2025-03-27 23:46:57 --> Total execution time: 0.1125
INFO - 2025-03-27 23:46:58 --> Config Class Initialized
INFO - 2025-03-27 23:46:58 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:46:58 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:46:58 --> Utf8 Class Initialized
INFO - 2025-03-27 23:46:58 --> URI Class Initialized
DEBUG - 2025-03-27 23:46:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:46:58 --> Router Class Initialized
INFO - 2025-03-27 23:46:58 --> Output Class Initialized
INFO - 2025-03-27 23:46:58 --> Security Class Initialized
DEBUG - 2025-03-27 23:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:46:58 --> Input Class Initialized
INFO - 2025-03-27 23:46:58 --> Language Class Initialized
INFO - 2025-03-27 23:46:58 --> Language Class Initialized
INFO - 2025-03-27 23:46:58 --> Config Class Initialized
INFO - 2025-03-27 23:46:58 --> Loader Class Initialized
INFO - 2025-03-27 23:46:58 --> Helper loaded: url_helper
INFO - 2025-03-27 23:46:58 --> Helper loaded: file_helper
INFO - 2025-03-27 23:46:58 --> Helper loaded: html_helper
INFO - 2025-03-27 23:46:58 --> Helper loaded: form_helper
INFO - 2025-03-27 23:46:58 --> Helper loaded: text_helper
INFO - 2025-03-27 23:46:58 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:46:58 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:46:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:46:58 --> Database Driver Class Initialized
INFO - 2025-03-27 23:46:58 --> Email Class Initialized
INFO - 2025-03-27 23:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:46:58 --> Form Validation Class Initialized
INFO - 2025-03-27 23:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:46:58 --> Pagination Class Initialized
INFO - 2025-03-27 23:46:58 --> Controller Class Initialized
DEBUG - 2025-03-27 23:46:58 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:46:58 --> Model Class Initialized
DEBUG - 2025-03-27 23:46:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:46:58 --> Model Class Initialized
ERROR - 2025-03-27 23:46:58 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:46:58 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:46:58 --> Received customer_id: null
ERROR - 2025-03-27 23:46:58 --> Received customfiled: null
ERROR - 2025-03-27 23:46:58 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:46:58 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:46:58 --> Search value: 
ERROR - 2025-03-27 23:46:58 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:46:58 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:46:58 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:46:58 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:46:58 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:47:42 --> Config Class Initialized
INFO - 2025-03-27 23:47:42 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:47:42 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:47:42 --> Utf8 Class Initialized
INFO - 2025-03-27 23:47:42 --> URI Class Initialized
DEBUG - 2025-03-27 23:47:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:47:42 --> Router Class Initialized
INFO - 2025-03-27 23:47:42 --> Output Class Initialized
INFO - 2025-03-27 23:47:42 --> Security Class Initialized
DEBUG - 2025-03-27 23:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:47:42 --> Input Class Initialized
INFO - 2025-03-27 23:47:42 --> Language Class Initialized
INFO - 2025-03-27 23:47:42 --> Language Class Initialized
INFO - 2025-03-27 23:47:42 --> Config Class Initialized
INFO - 2025-03-27 23:47:42 --> Loader Class Initialized
INFO - 2025-03-27 23:47:42 --> Helper loaded: url_helper
INFO - 2025-03-27 23:47:42 --> Helper loaded: file_helper
INFO - 2025-03-27 23:47:42 --> Helper loaded: html_helper
INFO - 2025-03-27 23:47:42 --> Helper loaded: form_helper
INFO - 2025-03-27 23:47:42 --> Helper loaded: text_helper
INFO - 2025-03-27 23:47:42 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:47:42 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:47:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:47:42 --> Database Driver Class Initialized
INFO - 2025-03-27 23:47:42 --> Email Class Initialized
INFO - 2025-03-27 23:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:47:42 --> Form Validation Class Initialized
INFO - 2025-03-27 23:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:47:42 --> Pagination Class Initialized
INFO - 2025-03-27 23:47:42 --> Controller Class Initialized
DEBUG - 2025-03-27 23:47:42 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:47:42 --> Model Class Initialized
DEBUG - 2025-03-27 23:47:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:47:42 --> Model Class Initialized
DEBUG - 2025-03-27 23:47:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:47:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:47:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:47:42 --> Model Class Initialized
ERROR - 2025-03-27 23:47:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:47:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:47:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:47:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:47:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:47:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:47:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:47:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:47:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:47:43 --> Final output sent to browser
DEBUG - 2025-03-27 23:47:43 --> Total execution time: 0.1152
INFO - 2025-03-27 23:47:43 --> Config Class Initialized
INFO - 2025-03-27 23:47:43 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:47:43 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:47:43 --> Utf8 Class Initialized
INFO - 2025-03-27 23:47:43 --> URI Class Initialized
DEBUG - 2025-03-27 23:47:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:47:43 --> Router Class Initialized
INFO - 2025-03-27 23:47:43 --> Output Class Initialized
INFO - 2025-03-27 23:47:43 --> Security Class Initialized
DEBUG - 2025-03-27 23:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:47:43 --> Input Class Initialized
INFO - 2025-03-27 23:47:43 --> Language Class Initialized
INFO - 2025-03-27 23:47:43 --> Language Class Initialized
INFO - 2025-03-27 23:47:43 --> Config Class Initialized
INFO - 2025-03-27 23:47:43 --> Loader Class Initialized
INFO - 2025-03-27 23:47:43 --> Helper loaded: url_helper
INFO - 2025-03-27 23:47:43 --> Helper loaded: file_helper
INFO - 2025-03-27 23:47:43 --> Helper loaded: html_helper
INFO - 2025-03-27 23:47:43 --> Helper loaded: form_helper
INFO - 2025-03-27 23:47:43 --> Helper loaded: text_helper
INFO - 2025-03-27 23:47:43 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:47:43 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:47:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:47:43 --> Database Driver Class Initialized
INFO - 2025-03-27 23:47:43 --> Email Class Initialized
INFO - 2025-03-27 23:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:47:43 --> Form Validation Class Initialized
INFO - 2025-03-27 23:47:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:47:43 --> Pagination Class Initialized
INFO - 2025-03-27 23:47:43 --> Controller Class Initialized
DEBUG - 2025-03-27 23:47:43 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:47:43 --> Model Class Initialized
DEBUG - 2025-03-27 23:47:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:47:43 --> Model Class Initialized
ERROR - 2025-03-27 23:47:43 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:47:43 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:47:43 --> Received customer_id: null
ERROR - 2025-03-27 23:47:43 --> Received customfiled: null
ERROR - 2025-03-27 23:47:43 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:47:43 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:47:43 --> Search value: 
ERROR - 2025-03-27 23:47:43 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:47:43 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:47:43 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:47:43 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:47:43 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:47:50 --> Config Class Initialized
INFO - 2025-03-27 23:47:50 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:47:50 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:47:50 --> Utf8 Class Initialized
INFO - 2025-03-27 23:47:50 --> URI Class Initialized
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:47:50 --> Router Class Initialized
INFO - 2025-03-27 23:47:50 --> Output Class Initialized
INFO - 2025-03-27 23:47:50 --> Security Class Initialized
DEBUG - 2025-03-27 23:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:47:50 --> Input Class Initialized
INFO - 2025-03-27 23:47:50 --> Language Class Initialized
INFO - 2025-03-27 23:47:50 --> Language Class Initialized
INFO - 2025-03-27 23:47:50 --> Config Class Initialized
INFO - 2025-03-27 23:47:50 --> Loader Class Initialized
INFO - 2025-03-27 23:47:50 --> Helper loaded: url_helper
INFO - 2025-03-27 23:47:50 --> Helper loaded: file_helper
INFO - 2025-03-27 23:47:50 --> Helper loaded: html_helper
INFO - 2025-03-27 23:47:50 --> Helper loaded: form_helper
INFO - 2025-03-27 23:47:50 --> Helper loaded: text_helper
INFO - 2025-03-27 23:47:50 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:47:50 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:47:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:47:50 --> Database Driver Class Initialized
INFO - 2025-03-27 23:47:50 --> Email Class Initialized
INFO - 2025-03-27 23:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:47:50 --> Form Validation Class Initialized
INFO - 2025-03-27 23:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:47:50 --> Pagination Class Initialized
INFO - 2025-03-27 23:47:50 --> Controller Class Initialized
DEBUG - 2025-03-27 23:47:50 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:47:50 --> Model Class Initialized
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:47:50 --> Model Class Initialized
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:47:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:47:50 --> Model Class Initialized
ERROR - 2025-03-27 23:47:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:47:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:47:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:47:50 --> Final output sent to browser
DEBUG - 2025-03-27 23:47:50 --> Total execution time: 0.1044
INFO - 2025-03-27 23:47:51 --> Config Class Initialized
INFO - 2025-03-27 23:47:51 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:47:51 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:47:51 --> Utf8 Class Initialized
INFO - 2025-03-27 23:47:51 --> URI Class Initialized
DEBUG - 2025-03-27 23:47:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:47:51 --> Router Class Initialized
INFO - 2025-03-27 23:47:51 --> Output Class Initialized
INFO - 2025-03-27 23:47:51 --> Security Class Initialized
DEBUG - 2025-03-27 23:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:47:51 --> Input Class Initialized
INFO - 2025-03-27 23:47:51 --> Language Class Initialized
INFO - 2025-03-27 23:47:51 --> Language Class Initialized
INFO - 2025-03-27 23:47:51 --> Config Class Initialized
INFO - 2025-03-27 23:47:51 --> Loader Class Initialized
INFO - 2025-03-27 23:47:51 --> Helper loaded: url_helper
INFO - 2025-03-27 23:47:51 --> Helper loaded: file_helper
INFO - 2025-03-27 23:47:51 --> Helper loaded: html_helper
INFO - 2025-03-27 23:47:51 --> Helper loaded: form_helper
INFO - 2025-03-27 23:47:51 --> Helper loaded: text_helper
INFO - 2025-03-27 23:47:51 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:47:51 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:47:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:47:51 --> Database Driver Class Initialized
INFO - 2025-03-27 23:47:51 --> Email Class Initialized
INFO - 2025-03-27 23:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:47:51 --> Form Validation Class Initialized
INFO - 2025-03-27 23:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:47:51 --> Pagination Class Initialized
INFO - 2025-03-27 23:47:51 --> Controller Class Initialized
DEBUG - 2025-03-27 23:47:51 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:47:51 --> Model Class Initialized
DEBUG - 2025-03-27 23:47:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:47:51 --> Model Class Initialized
ERROR - 2025-03-27 23:47:51 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:47:51 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:47:51 --> Received customer_id: null
ERROR - 2025-03-27 23:47:51 --> Received customfiled: null
ERROR - 2025-03-27 23:47:51 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:47:51 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:47:51 --> Search value: 
ERROR - 2025-03-27 23:47:51 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:47:51 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:47:51 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:47:51 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:47:51 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:48:24 --> Config Class Initialized
INFO - 2025-03-27 23:48:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:48:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:48:24 --> Utf8 Class Initialized
INFO - 2025-03-27 23:48:24 --> URI Class Initialized
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:48:24 --> Router Class Initialized
INFO - 2025-03-27 23:48:24 --> Output Class Initialized
INFO - 2025-03-27 23:48:24 --> Security Class Initialized
DEBUG - 2025-03-27 23:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:48:24 --> Input Class Initialized
INFO - 2025-03-27 23:48:24 --> Language Class Initialized
INFO - 2025-03-27 23:48:24 --> Language Class Initialized
INFO - 2025-03-27 23:48:24 --> Config Class Initialized
INFO - 2025-03-27 23:48:24 --> Loader Class Initialized
INFO - 2025-03-27 23:48:24 --> Helper loaded: url_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: file_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: html_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: form_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: text_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:48:24 --> Database Driver Class Initialized
INFO - 2025-03-27 23:48:24 --> Email Class Initialized
INFO - 2025-03-27 23:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:48:24 --> Form Validation Class Initialized
INFO - 2025-03-27 23:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:48:24 --> Pagination Class Initialized
INFO - 2025-03-27 23:48:24 --> Controller Class Initialized
DEBUG - 2025-03-27 23:48:24 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:48:24 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:48:24 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:48:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:48:24 --> Model Class Initialized
ERROR - 2025-03-27 23:48:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:48:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:48:24 --> Final output sent to browser
DEBUG - 2025-03-27 23:48:24 --> Total execution time: 0.1111
INFO - 2025-03-27 23:48:24 --> Config Class Initialized
INFO - 2025-03-27 23:48:24 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:48:24 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:48:24 --> Utf8 Class Initialized
INFO - 2025-03-27 23:48:24 --> URI Class Initialized
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:48:24 --> Router Class Initialized
INFO - 2025-03-27 23:48:24 --> Output Class Initialized
INFO - 2025-03-27 23:48:24 --> Security Class Initialized
DEBUG - 2025-03-27 23:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:48:24 --> Input Class Initialized
INFO - 2025-03-27 23:48:24 --> Language Class Initialized
INFO - 2025-03-27 23:48:24 --> Language Class Initialized
INFO - 2025-03-27 23:48:24 --> Config Class Initialized
INFO - 2025-03-27 23:48:24 --> Loader Class Initialized
INFO - 2025-03-27 23:48:24 --> Helper loaded: url_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: file_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: html_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: form_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: text_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:48:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:48:24 --> Database Driver Class Initialized
INFO - 2025-03-27 23:48:24 --> Email Class Initialized
INFO - 2025-03-27 23:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:48:24 --> Form Validation Class Initialized
INFO - 2025-03-27 23:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:48:24 --> Pagination Class Initialized
INFO - 2025-03-27 23:48:24 --> Controller Class Initialized
DEBUG - 2025-03-27 23:48:24 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:48:24 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:48:24 --> Model Class Initialized
ERROR - 2025-03-27 23:48:24 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:48:24 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:48:24 --> Received customer_id: null
ERROR - 2025-03-27 23:48:24 --> Received customfiled: null
ERROR - 2025-03-27 23:48:24 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:48:24 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:48:24 --> Search value: 
ERROR - 2025-03-27 23:48:24 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:48:24 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:48:24 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:48:24 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:48:24 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:48:27 --> Config Class Initialized
INFO - 2025-03-27 23:48:27 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:48:27 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:48:27 --> Utf8 Class Initialized
INFO - 2025-03-27 23:48:27 --> URI Class Initialized
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:48:27 --> Router Class Initialized
INFO - 2025-03-27 23:48:27 --> Output Class Initialized
INFO - 2025-03-27 23:48:27 --> Security Class Initialized
DEBUG - 2025-03-27 23:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:48:27 --> Input Class Initialized
INFO - 2025-03-27 23:48:27 --> Language Class Initialized
INFO - 2025-03-27 23:48:27 --> Language Class Initialized
INFO - 2025-03-27 23:48:27 --> Config Class Initialized
INFO - 2025-03-27 23:48:27 --> Loader Class Initialized
INFO - 2025-03-27 23:48:27 --> Helper loaded: url_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: file_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: html_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: form_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: text_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:48:27 --> Database Driver Class Initialized
INFO - 2025-03-27 23:48:27 --> Email Class Initialized
INFO - 2025-03-27 23:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:48:27 --> Form Validation Class Initialized
INFO - 2025-03-27 23:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:48:27 --> Pagination Class Initialized
INFO - 2025-03-27 23:48:27 --> Controller Class Initialized
DEBUG - 2025-03-27 23:48:27 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:48:27 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:48:27 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:48:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:48:27 --> Model Class Initialized
ERROR - 2025-03-27 23:48:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:48:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:48:27 --> Final output sent to browser
DEBUG - 2025-03-27 23:48:27 --> Total execution time: 0.1107
INFO - 2025-03-27 23:48:27 --> Config Class Initialized
INFO - 2025-03-27 23:48:27 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:48:27 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:48:27 --> Utf8 Class Initialized
INFO - 2025-03-27 23:48:27 --> URI Class Initialized
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:48:27 --> Router Class Initialized
INFO - 2025-03-27 23:48:27 --> Output Class Initialized
INFO - 2025-03-27 23:48:27 --> Security Class Initialized
DEBUG - 2025-03-27 23:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:48:27 --> Input Class Initialized
INFO - 2025-03-27 23:48:27 --> Language Class Initialized
INFO - 2025-03-27 23:48:27 --> Language Class Initialized
INFO - 2025-03-27 23:48:27 --> Config Class Initialized
INFO - 2025-03-27 23:48:27 --> Loader Class Initialized
INFO - 2025-03-27 23:48:27 --> Helper loaded: url_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: file_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: html_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: form_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: text_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:48:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:48:27 --> Database Driver Class Initialized
INFO - 2025-03-27 23:48:27 --> Email Class Initialized
INFO - 2025-03-27 23:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:48:27 --> Form Validation Class Initialized
INFO - 2025-03-27 23:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:48:27 --> Pagination Class Initialized
INFO - 2025-03-27 23:48:27 --> Controller Class Initialized
DEBUG - 2025-03-27 23:48:27 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:48:27 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:48:27 --> Model Class Initialized
ERROR - 2025-03-27 23:48:27 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:48:27 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:48:27 --> Received customer_id: null
ERROR - 2025-03-27 23:48:27 --> Received customfiled: null
ERROR - 2025-03-27 23:48:27 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:48:27 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:48:27 --> Search value: 
ERROR - 2025-03-27 23:48:27 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:48:27 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:48:27 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:48:27 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:48:27 --> ========= getCustomerList() END =========
INFO - 2025-03-27 23:48:43 --> Config Class Initialized
INFO - 2025-03-27 23:48:43 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:48:43 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:48:43 --> Utf8 Class Initialized
INFO - 2025-03-27 23:48:43 --> URI Class Initialized
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:48:43 --> Router Class Initialized
INFO - 2025-03-27 23:48:43 --> Output Class Initialized
INFO - 2025-03-27 23:48:43 --> Security Class Initialized
DEBUG - 2025-03-27 23:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:48:43 --> Input Class Initialized
INFO - 2025-03-27 23:48:43 --> Language Class Initialized
INFO - 2025-03-27 23:48:43 --> Language Class Initialized
INFO - 2025-03-27 23:48:43 --> Config Class Initialized
INFO - 2025-03-27 23:48:43 --> Loader Class Initialized
INFO - 2025-03-27 23:48:43 --> Helper loaded: url_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: file_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: html_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: form_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: text_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:48:43 --> Database Driver Class Initialized
INFO - 2025-03-27 23:48:43 --> Email Class Initialized
INFO - 2025-03-27 23:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:48:43 --> Form Validation Class Initialized
INFO - 2025-03-27 23:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:48:43 --> Pagination Class Initialized
INFO - 2025-03-27 23:48:43 --> Controller Class Initialized
DEBUG - 2025-03-27 23:48:43 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:48:43 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:48:43 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-27 23:48:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-27 23:48:43 --> Model Class Initialized
ERROR - 2025-03-27 23:48:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-27 23:48:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-27 23:48:43 --> Final output sent to browser
DEBUG - 2025-03-27 23:48:43 --> Total execution time: 0.1252
INFO - 2025-03-27 23:48:43 --> Config Class Initialized
INFO - 2025-03-27 23:48:43 --> Hooks Class Initialized
DEBUG - 2025-03-27 23:48:43 --> UTF-8 Support Enabled
INFO - 2025-03-27 23:48:43 --> Utf8 Class Initialized
INFO - 2025-03-27 23:48:43 --> URI Class Initialized
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-27 23:48:43 --> Router Class Initialized
INFO - 2025-03-27 23:48:43 --> Output Class Initialized
INFO - 2025-03-27 23:48:43 --> Security Class Initialized
DEBUG - 2025-03-27 23:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-27 23:48:43 --> Input Class Initialized
INFO - 2025-03-27 23:48:43 --> Language Class Initialized
INFO - 2025-03-27 23:48:43 --> Language Class Initialized
INFO - 2025-03-27 23:48:43 --> Config Class Initialized
INFO - 2025-03-27 23:48:43 --> Loader Class Initialized
INFO - 2025-03-27 23:48:43 --> Helper loaded: url_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: file_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: html_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: form_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: text_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: lang_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: directory_helper
INFO - 2025-03-27 23:48:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-27 23:48:43 --> Database Driver Class Initialized
INFO - 2025-03-27 23:48:43 --> Email Class Initialized
INFO - 2025-03-27 23:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-27 23:48:43 --> Form Validation Class Initialized
INFO - 2025-03-27 23:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-27 23:48:43 --> Pagination Class Initialized
INFO - 2025-03-27 23:48:43 --> Controller Class Initialized
DEBUG - 2025-03-27 23:48:43 --> Customer MX_Controller Initialized
INFO - 2025-03-27 23:48:43 --> Model Class Initialized
DEBUG - 2025-03-27 23:48:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-27 23:48:43 --> Model Class Initialized
ERROR - 2025-03-27 23:48:43 --> ========= getCustomerList() START =========
ERROR - 2025-03-27 23:48:43 --> POST Data: {"draw":"1","columns":[{"data":"sl","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"customer_name","name":"","searchable":"true","orderable":"true","search":{"value":"","regex":"false"}},{"data":"address","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"mobile","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"email","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"vat_no","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit_number","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"sales_permit","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"zip","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"country","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"balance","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"status","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}},{"data":"button","name":"","searchable":"true","orderable":"false","search":{"value":"","regex":"false"}}],"order":[{"column":"1","dir":"asc"}],"start":"0","length":"50","search":{"value":"","regex":"false"},"csrf_test_name":""}
ERROR - 2025-03-27 23:48:43 --> Received customer_id: null
ERROR - 2025-03-27 23:48:43 --> Received customfiled: null
ERROR - 2025-03-27 23:48:43 --> Pagination info: start=0, length=50
ERROR - 2025-03-27 23:48:43 --> Ordering: column=customer_name, direction=asc
ERROR - 2025-03-27 23:48:43 --> Search value: 
ERROR - 2025-03-27 23:48:43 --> Total unfiltered records: 15
ERROR - 2025-03-27 23:48:43 --> Applying LIMIT: 50 OFFSET: 0
ERROR - 2025-03-27 23:48:43 --> Records fetched from DB: 15
ERROR - 2025-03-27 23:48:43 --> JSON Response: {"draw":1,"iTotalRecords":15,"iTotalDisplayRecords":15,"aaData":[{"sl":1,"customer_name":null,"address":null,"mobile":null,"email":null,"vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/29\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(29)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":2,"customer_name":"Abdul  Bulbul","address":"West Rampura","mobile":"01926537799","email":"abul.bulbul@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"2","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/28\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(28)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":3,"customer_name":"Abdul Kader","address":"80\/2 West Rampura","mobile":"01816537777","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/18\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(18)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":4,"customer_name":"Abdul Khayer Bulbul","address":"West Rampura","mobile":"01926537777","email":"abul.khayer@hotmail.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/26\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(26)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":5,"customer_name":"Abul Kashem","address":"80\/2 West Rampura","mobile":"01816537164","email":"dolown@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/11\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(11)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":6,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":"11223344","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742284328_deshi_shaad_fav1.png\" target=\"_blank\">View File<\/a>","zip":"21228","country":"United States","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/23\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":7,"customer_name":"Elham Chowdhury","address":"West Rampura","mobile":"019887766554","email":"elham.chowdhury@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742718173_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/30\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(30)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":8,"customer_name":"Elham khan","address":"West Rampura","mobile":"019887760987","email":"elham.khan@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/31\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(31)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":9,"customer_name":"Elham khanom","address":"West Rampura","mobile":"019887760933","email":"elham.khanom@gmail.com","vat_no":null,"sales_permit_number":"1122334243","sales_permit":"<a href=\"http:\/\/localhost:8000\/uploads\/sales_permits\/1742900754_Labeo_rohita.JPG\" target=\"_blank\">View File<\/a>","zip":"1219","country":"Bangladesh","balance":"0.00","status":"0","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/32\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(32)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":10,"customer_name":"Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01816537163","email":"faiz.shiraji@hotmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/14\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(14)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":11,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/15\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":12,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/20\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":13,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":"","sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/22\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":14,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/19\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"},{"sl":15,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":"<a href=\"http:\/\/localhost:8000\/edit_customer\/1\" class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\"><i class=\"pe-7s-note\"><\/i><\/a><a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\"><i class=\"pe-7s-trash\"><\/i><\/a>"}]}
ERROR - 2025-03-27 23:48:43 --> ========= getCustomerList() END =========
