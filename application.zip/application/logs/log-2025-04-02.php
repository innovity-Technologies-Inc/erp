<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-02 07:03:13 --> Config Class Initialized
INFO - 2025-04-02 07:03:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:13 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:13 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-02 07:03:13 --> No URI present. Default controller set.
INFO - 2025-04-02 07:03:13 --> Router Class Initialized
INFO - 2025-04-02 07:03:13 --> Output Class Initialized
INFO - 2025-04-02 07:03:13 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:13 --> Input Class Initialized
INFO - 2025-04-02 07:03:13 --> Language Class Initialized
INFO - 2025-04-02 07:03:13 --> Language Class Initialized
INFO - 2025-04-02 07:03:13 --> Config Class Initialized
INFO - 2025-04-02 07:03:13 --> Loader Class Initialized
INFO - 2025-04-02 07:03:13 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:13 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:13 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:13 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:13 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:13 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:13 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:13 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:13 --> Email Class Initialized
INFO - 2025-04-02 07:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:13 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:13 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:13 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:13 --> Auth MX_Controller Initialized
INFO - 2025-04-02 07:03:13 --> Model Class Initialized
DEBUG - 2025-04-02 07:03:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-02 07:03:13 --> Model Class Initialized
DEBUG - 2025-04-02 07:03:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:03:13 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:03:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:03:13 --> Model Class Initialized
DEBUG - 2025-04-02 07:03:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-02 07:03:13 --> Final output sent to browser
DEBUG - 2025-04-02 07:03:13 --> Total execution time: 0.0497
INFO - 2025-04-02 07:03:22 --> Config Class Initialized
INFO - 2025-04-02 07:03:22 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:22 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:22 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:22 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-02 07:03:22 --> Router Class Initialized
INFO - 2025-04-02 07:03:22 --> Output Class Initialized
INFO - 2025-04-02 07:03:22 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:22 --> Input Class Initialized
INFO - 2025-04-02 07:03:22 --> Language Class Initialized
INFO - 2025-04-02 07:03:22 --> Language Class Initialized
INFO - 2025-04-02 07:03:22 --> Config Class Initialized
INFO - 2025-04-02 07:03:22 --> Loader Class Initialized
INFO - 2025-04-02 07:03:22 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:22 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:22 --> Email Class Initialized
INFO - 2025-04-02 07:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:22 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:22 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:22 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:22 --> Auth MX_Controller Initialized
INFO - 2025-04-02 07:03:22 --> Model Class Initialized
DEBUG - 2025-04-02 07:03:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-02 07:03:22 --> Model Class Initialized
INFO - 2025-04-02 07:03:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-02 07:03:22 --> Config Class Initialized
INFO - 2025-04-02 07:03:22 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:22 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:22 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:22 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-02 07:03:22 --> Router Class Initialized
INFO - 2025-04-02 07:03:22 --> Output Class Initialized
INFO - 2025-04-02 07:03:22 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:22 --> Input Class Initialized
INFO - 2025-04-02 07:03:22 --> Language Class Initialized
INFO - 2025-04-02 07:03:22 --> Language Class Initialized
INFO - 2025-04-02 07:03:22 --> Config Class Initialized
INFO - 2025-04-02 07:03:22 --> Loader Class Initialized
INFO - 2025-04-02 07:03:22 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:22 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:22 --> Email Class Initialized
INFO - 2025-04-02 07:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:22 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:22 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:22 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:22 --> Home MX_Controller Initialized
INFO - 2025-04-02 07:03:22 --> Model Class Initialized
DEBUG - 2025-04-02 07:03:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-02 07:03:22 --> Model Class Initialized
DEBUG - 2025-04-02 07:03:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:03:22 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:03:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:03:22 --> Model Class Initialized
ERROR - 2025-04-02 07:03:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:03:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:03:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:03:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:03:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:03:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:03:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-02 07:03:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:03:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:03:23 --> Final output sent to browser
DEBUG - 2025-04-02 07:03:23 --> Total execution time: 0.6511
INFO - 2025-04-02 07:03:30 --> Config Class Initialized
INFO - 2025-04-02 07:03:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:30 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:30 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:30 --> Router Class Initialized
INFO - 2025-04-02 07:03:30 --> Output Class Initialized
INFO - 2025-04-02 07:03:30 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:30 --> Input Class Initialized
INFO - 2025-04-02 07:03:30 --> Language Class Initialized
INFO - 2025-04-02 07:03:30 --> Language Class Initialized
INFO - 2025-04-02 07:03:30 --> Config Class Initialized
INFO - 2025-04-02 07:03:30 --> Loader Class Initialized
INFO - 2025-04-02 07:03:30 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:30 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:30 --> Email Class Initialized
INFO - 2025-04-02 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:30 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:30 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:30 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:30 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 13:03:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
ERROR - 2025-04-02 13:03:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 13:03:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 13:03:30 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:30 --> Total execution time: 0.1407
INFO - 2025-04-02 07:03:30 --> Config Class Initialized
INFO - 2025-04-02 07:03:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:30 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:30 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:30 --> Router Class Initialized
INFO - 2025-04-02 07:03:30 --> Output Class Initialized
INFO - 2025-04-02 07:03:30 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:30 --> Input Class Initialized
INFO - 2025-04-02 07:03:30 --> Language Class Initialized
INFO - 2025-04-02 07:03:30 --> Language Class Initialized
INFO - 2025-04-02 07:03:30 --> Config Class Initialized
INFO - 2025-04-02 07:03:30 --> Loader Class Initialized
INFO - 2025-04-02 07:03:30 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:30 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:30 --> Email Class Initialized
INFO - 2025-04-02 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:30 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:30 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:30 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:30 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:30 --> Model Class Initialized
INFO - 2025-04-02 13:03:30 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:30 --> Total execution time: 0.0275
INFO - 2025-04-02 07:03:34 --> Config Class Initialized
INFO - 2025-04-02 07:03:34 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:34 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:34 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:34 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:34 --> Router Class Initialized
INFO - 2025-04-02 07:03:34 --> Output Class Initialized
INFO - 2025-04-02 07:03:34 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:34 --> Input Class Initialized
INFO - 2025-04-02 07:03:34 --> Language Class Initialized
INFO - 2025-04-02 07:03:34 --> Language Class Initialized
INFO - 2025-04-02 07:03:34 --> Config Class Initialized
INFO - 2025-04-02 07:03:34 --> Loader Class Initialized
INFO - 2025-04-02 07:03:34 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:34 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:34 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:34 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:34 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:34 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:34 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:34 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:34 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:34 --> Email Class Initialized
INFO - 2025-04-02 07:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:34 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:34 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:34 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:34 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:34 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:34 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:34 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:34 --> Model Class Initialized
ERROR - 2025-04-02 13:03:34 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 13:03:34 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 13:03:34 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-02 13:03:34 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-02 13:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 13:03:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 13:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 13:03:34 --> Model Class Initialized
ERROR - 2025-04-02 13:03:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 13:03:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 13:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 13:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 13:03:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 13:03:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 13:03:35 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-02 13:03:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-02 13:03:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 13:03:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 13:03:35 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:35 --> Total execution time: 0.2130
INFO - 2025-04-02 07:03:41 --> Config Class Initialized
INFO - 2025-04-02 07:03:41 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:41 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:41 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:41 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:41 --> Router Class Initialized
INFO - 2025-04-02 07:03:41 --> Output Class Initialized
INFO - 2025-04-02 07:03:41 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:41 --> Input Class Initialized
INFO - 2025-04-02 07:03:41 --> Language Class Initialized
INFO - 2025-04-02 07:03:41 --> Language Class Initialized
INFO - 2025-04-02 07:03:41 --> Config Class Initialized
INFO - 2025-04-02 07:03:41 --> Loader Class Initialized
INFO - 2025-04-02 07:03:41 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:41 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:41 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:41 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:41 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:41 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:41 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:41 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:41 --> Email Class Initialized
INFO - 2025-04-02 07:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:41 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:41 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:41 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:41 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:41 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:41 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:41 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:41 --> Model Class Initialized
INFO - 2025-04-02 13:03:41 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:41 --> Total execution time: 0.0156
INFO - 2025-04-02 07:03:42 --> Config Class Initialized
INFO - 2025-04-02 07:03:42 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:42 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:42 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:42 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:42 --> Router Class Initialized
INFO - 2025-04-02 07:03:42 --> Output Class Initialized
INFO - 2025-04-02 07:03:42 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:42 --> Input Class Initialized
INFO - 2025-04-02 07:03:42 --> Language Class Initialized
INFO - 2025-04-02 07:03:42 --> Language Class Initialized
INFO - 2025-04-02 07:03:42 --> Config Class Initialized
INFO - 2025-04-02 07:03:42 --> Loader Class Initialized
INFO - 2025-04-02 07:03:42 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:42 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:42 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:42 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:42 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:42 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:42 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:42 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:42 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:42 --> Email Class Initialized
INFO - 2025-04-02 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:42 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:42 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:42 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:42 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:42 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:42 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:42 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:42 --> Model Class Initialized
INFO - 2025-04-02 13:03:42 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:42 --> Total execution time: 0.0227
INFO - 2025-04-02 07:03:46 --> Config Class Initialized
INFO - 2025-04-02 07:03:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:46 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:46 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:46 --> Router Class Initialized
INFO - 2025-04-02 07:03:46 --> Output Class Initialized
INFO - 2025-04-02 07:03:46 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:46 --> Input Class Initialized
INFO - 2025-04-02 07:03:46 --> Language Class Initialized
INFO - 2025-04-02 07:03:46 --> Language Class Initialized
INFO - 2025-04-02 07:03:46 --> Config Class Initialized
INFO - 2025-04-02 07:03:46 --> Loader Class Initialized
INFO - 2025-04-02 07:03:46 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:46 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:46 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:46 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:46 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:46 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:46 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:46 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:46 --> Email Class Initialized
INFO - 2025-04-02 07:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:46 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:46 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:46 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:46 --> Model Class Initialized
INFO - 2025-04-02 13:03:46 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:46 --> Total execution time: 0.0153
INFO - 2025-04-02 07:03:47 --> Config Class Initialized
INFO - 2025-04-02 07:03:47 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:47 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:47 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:47 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:47 --> Router Class Initialized
INFO - 2025-04-02 07:03:47 --> Output Class Initialized
INFO - 2025-04-02 07:03:47 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:47 --> Input Class Initialized
INFO - 2025-04-02 07:03:47 --> Language Class Initialized
INFO - 2025-04-02 07:03:47 --> Language Class Initialized
INFO - 2025-04-02 07:03:47 --> Config Class Initialized
INFO - 2025-04-02 07:03:47 --> Loader Class Initialized
INFO - 2025-04-02 07:03:47 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:47 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:47 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:47 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:47 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:47 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:47 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:47 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:47 --> Email Class Initialized
INFO - 2025-04-02 07:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:47 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:47 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:47 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:47 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:47 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:47 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:47 --> Model Class Initialized
INFO - 2025-04-02 13:03:47 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:47 --> Total execution time: 0.0339
INFO - 2025-04-02 07:03:49 --> Config Class Initialized
INFO - 2025-04-02 07:03:49 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:03:49 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:03:49 --> Utf8 Class Initialized
INFO - 2025-04-02 07:03:49 --> URI Class Initialized
DEBUG - 2025-04-02 07:03:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:03:49 --> Router Class Initialized
INFO - 2025-04-02 07:03:49 --> Output Class Initialized
INFO - 2025-04-02 07:03:49 --> Security Class Initialized
DEBUG - 2025-04-02 07:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:03:49 --> Input Class Initialized
INFO - 2025-04-02 07:03:49 --> Language Class Initialized
INFO - 2025-04-02 07:03:49 --> Language Class Initialized
INFO - 2025-04-02 07:03:49 --> Config Class Initialized
INFO - 2025-04-02 07:03:49 --> Loader Class Initialized
INFO - 2025-04-02 07:03:49 --> Helper loaded: url_helper
INFO - 2025-04-02 07:03:49 --> Helper loaded: file_helper
INFO - 2025-04-02 07:03:49 --> Helper loaded: html_helper
INFO - 2025-04-02 07:03:49 --> Helper loaded: form_helper
INFO - 2025-04-02 07:03:49 --> Helper loaded: text_helper
INFO - 2025-04-02 07:03:49 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:03:49 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:03:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:03:49 --> Database Driver Class Initialized
INFO - 2025-04-02 07:03:49 --> Email Class Initialized
INFO - 2025-04-02 07:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:03:49 --> Form Validation Class Initialized
INFO - 2025-04-02 07:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:03:49 --> Pagination Class Initialized
INFO - 2025-04-02 07:03:49 --> Controller Class Initialized
DEBUG - 2025-04-02 07:03:49 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:03:49 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:03:49 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:03:49 --> Model Class Initialized
DEBUG - 2025-04-02 13:03:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:03:49 --> Model Class Initialized
INFO - 2025-04-02 13:03:49 --> Final output sent to browser
DEBUG - 2025-04-02 13:03:49 --> Total execution time: 0.0149
INFO - 2025-04-02 07:04:00 --> Config Class Initialized
INFO - 2025-04-02 07:04:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:00 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:00 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:00 --> Router Class Initialized
INFO - 2025-04-02 07:04:00 --> Output Class Initialized
INFO - 2025-04-02 07:04:00 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:00 --> Input Class Initialized
INFO - 2025-04-02 07:04:00 --> Language Class Initialized
INFO - 2025-04-02 07:04:00 --> Language Class Initialized
INFO - 2025-04-02 07:04:00 --> Config Class Initialized
INFO - 2025-04-02 07:04:00 --> Loader Class Initialized
INFO - 2025-04-02 07:04:00 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:00 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:00 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:00 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:00 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:00 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:00 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:00 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:00 --> Email Class Initialized
INFO - 2025-04-02 07:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:00 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:00 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:00 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:00 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:00 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:00 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:00 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:00 --> Model Class Initialized
INFO - 2025-04-02 13:04:00 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:00 --> Total execution time: 0.0174
INFO - 2025-04-02 07:04:03 --> Config Class Initialized
INFO - 2025-04-02 07:04:03 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:03 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:03 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:03 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:03 --> Router Class Initialized
INFO - 2025-04-02 07:04:03 --> Output Class Initialized
INFO - 2025-04-02 07:04:03 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:03 --> Input Class Initialized
INFO - 2025-04-02 07:04:03 --> Language Class Initialized
INFO - 2025-04-02 07:04:03 --> Language Class Initialized
INFO - 2025-04-02 07:04:03 --> Config Class Initialized
INFO - 2025-04-02 07:04:03 --> Loader Class Initialized
INFO - 2025-04-02 07:04:03 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:03 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:03 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:03 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:03 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:03 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:03 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:03 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:03 --> Email Class Initialized
INFO - 2025-04-02 07:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:03 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:03 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:03 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:03 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:03 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:03 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:03 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:03 --> Model Class Initialized
INFO - 2025-04-02 13:04:03 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:03 --> Total execution time: 0.0102
INFO - 2025-04-02 07:04:10 --> Config Class Initialized
INFO - 2025-04-02 07:04:10 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:10 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:10 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:10 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:10 --> Router Class Initialized
INFO - 2025-04-02 07:04:10 --> Output Class Initialized
INFO - 2025-04-02 07:04:10 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:10 --> Input Class Initialized
INFO - 2025-04-02 07:04:10 --> Language Class Initialized
INFO - 2025-04-02 07:04:10 --> Language Class Initialized
INFO - 2025-04-02 07:04:10 --> Config Class Initialized
INFO - 2025-04-02 07:04:10 --> Loader Class Initialized
INFO - 2025-04-02 07:04:10 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:10 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:10 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:10 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:10 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:10 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:10 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:10 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:10 --> Email Class Initialized
INFO - 2025-04-02 07:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:10 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:10 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:10 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:10 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:10 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:10 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:10 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:10 --> Model Class Initialized
INFO - 2025-04-02 13:04:10 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:10 --> Total execution time: 0.0128
INFO - 2025-04-02 07:04:12 --> Config Class Initialized
INFO - 2025-04-02 07:04:12 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:12 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:12 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:12 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:12 --> Router Class Initialized
INFO - 2025-04-02 07:04:12 --> Output Class Initialized
INFO - 2025-04-02 07:04:12 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:12 --> Input Class Initialized
INFO - 2025-04-02 07:04:12 --> Language Class Initialized
INFO - 2025-04-02 07:04:12 --> Language Class Initialized
INFO - 2025-04-02 07:04:12 --> Config Class Initialized
INFO - 2025-04-02 07:04:12 --> Loader Class Initialized
INFO - 2025-04-02 07:04:12 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:12 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:12 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:12 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:12 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:12 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:12 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:12 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:12 --> Email Class Initialized
INFO - 2025-04-02 07:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:12 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:12 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:12 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:12 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:12 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:12 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:12 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:12 --> Model Class Initialized
INFO - 2025-04-02 13:04:12 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:12 --> Total execution time: 0.0254
INFO - 2025-04-02 07:04:13 --> Config Class Initialized
INFO - 2025-04-02 07:04:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:13 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:13 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:13 --> Router Class Initialized
INFO - 2025-04-02 07:04:13 --> Output Class Initialized
INFO - 2025-04-02 07:04:13 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:13 --> Input Class Initialized
INFO - 2025-04-02 07:04:13 --> Language Class Initialized
INFO - 2025-04-02 07:04:13 --> Language Class Initialized
INFO - 2025-04-02 07:04:13 --> Config Class Initialized
INFO - 2025-04-02 07:04:13 --> Loader Class Initialized
INFO - 2025-04-02 07:04:13 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:13 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:13 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:13 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:13 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:13 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:13 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:13 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:13 --> Email Class Initialized
INFO - 2025-04-02 07:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:13 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:13 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:13 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:13 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:13 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:13 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:13 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:13 --> Model Class Initialized
INFO - 2025-04-02 13:04:13 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:13 --> Total execution time: 0.0130
INFO - 2025-04-02 07:04:25 --> Config Class Initialized
INFO - 2025-04-02 07:04:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:25 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:25 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:25 --> Router Class Initialized
INFO - 2025-04-02 07:04:25 --> Output Class Initialized
INFO - 2025-04-02 07:04:25 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:25 --> Input Class Initialized
INFO - 2025-04-02 07:04:25 --> Language Class Initialized
INFO - 2025-04-02 07:04:25 --> Language Class Initialized
INFO - 2025-04-02 07:04:25 --> Config Class Initialized
INFO - 2025-04-02 07:04:25 --> Loader Class Initialized
INFO - 2025-04-02 07:04:25 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:25 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:25 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:25 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:25 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:25 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:25 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:25 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:25 --> Email Class Initialized
INFO - 2025-04-02 07:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:25 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:25 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:25 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:25 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:25 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:25 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:25 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:25 --> Model Class Initialized
INFO - 2025-04-02 13:04:25 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:25 --> Total execution time: 0.0138
INFO - 2025-04-02 07:04:26 --> Config Class Initialized
INFO - 2025-04-02 07:04:26 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:26 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:26 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:26 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:26 --> Router Class Initialized
INFO - 2025-04-02 07:04:26 --> Output Class Initialized
INFO - 2025-04-02 07:04:26 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:26 --> Input Class Initialized
INFO - 2025-04-02 07:04:26 --> Language Class Initialized
INFO - 2025-04-02 07:04:26 --> Language Class Initialized
INFO - 2025-04-02 07:04:26 --> Config Class Initialized
INFO - 2025-04-02 07:04:26 --> Loader Class Initialized
INFO - 2025-04-02 07:04:26 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:26 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:26 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:26 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:26 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:26 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:26 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:26 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:26 --> Email Class Initialized
INFO - 2025-04-02 07:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:26 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:26 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:26 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:26 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:26 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:26 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:26 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:26 --> Model Class Initialized
INFO - 2025-04-02 13:04:26 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:26 --> Total execution time: 0.0120
INFO - 2025-04-02 07:04:29 --> Config Class Initialized
INFO - 2025-04-02 07:04:29 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:29 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:29 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:29 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:29 --> Router Class Initialized
INFO - 2025-04-02 07:04:29 --> Output Class Initialized
INFO - 2025-04-02 07:04:29 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:29 --> Input Class Initialized
INFO - 2025-04-02 07:04:29 --> Language Class Initialized
INFO - 2025-04-02 07:04:29 --> Language Class Initialized
INFO - 2025-04-02 07:04:29 --> Config Class Initialized
INFO - 2025-04-02 07:04:29 --> Loader Class Initialized
INFO - 2025-04-02 07:04:29 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:29 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:29 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:29 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:29 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:29 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:29 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:29 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:29 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:29 --> Email Class Initialized
INFO - 2025-04-02 07:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:29 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:29 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:29 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:29 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:29 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:29 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:29 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:29 --> Model Class Initialized
INFO - 2025-04-02 13:04:29 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:29 --> Total execution time: 0.0246
INFO - 2025-04-02 07:04:32 --> Config Class Initialized
INFO - 2025-04-02 07:04:32 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:32 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:32 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:32 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:32 --> Router Class Initialized
INFO - 2025-04-02 07:04:32 --> Output Class Initialized
INFO - 2025-04-02 07:04:32 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:32 --> Input Class Initialized
INFO - 2025-04-02 07:04:32 --> Language Class Initialized
INFO - 2025-04-02 07:04:32 --> Language Class Initialized
INFO - 2025-04-02 07:04:32 --> Config Class Initialized
INFO - 2025-04-02 07:04:32 --> Loader Class Initialized
INFO - 2025-04-02 07:04:32 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:32 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:32 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:32 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:32 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:32 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:32 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:32 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:32 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:32 --> Email Class Initialized
INFO - 2025-04-02 07:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:32 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:32 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:32 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:32 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:32 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:32 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:32 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:32 --> Model Class Initialized
INFO - 2025-04-02 13:04:32 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:32 --> Total execution time: 0.0117
INFO - 2025-04-02 07:04:46 --> Config Class Initialized
INFO - 2025-04-02 07:04:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:46 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:46 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:46 --> Router Class Initialized
INFO - 2025-04-02 07:04:46 --> Output Class Initialized
INFO - 2025-04-02 07:04:46 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:46 --> Input Class Initialized
INFO - 2025-04-02 07:04:46 --> Language Class Initialized
INFO - 2025-04-02 07:04:46 --> Language Class Initialized
INFO - 2025-04-02 07:04:46 --> Config Class Initialized
INFO - 2025-04-02 07:04:46 --> Loader Class Initialized
INFO - 2025-04-02 07:04:46 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:46 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:46 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:46 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:46 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:46 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:46 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:46 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:46 --> Email Class Initialized
INFO - 2025-04-02 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:46 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:46 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:46 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:46 --> Model Class Initialized
INFO - 2025-04-02 13:04:46 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:46 --> Total execution time: 0.0127
INFO - 2025-04-02 07:04:47 --> Config Class Initialized
INFO - 2025-04-02 07:04:47 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:47 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:47 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:47 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:47 --> Router Class Initialized
INFO - 2025-04-02 07:04:47 --> Output Class Initialized
INFO - 2025-04-02 07:04:47 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:47 --> Input Class Initialized
INFO - 2025-04-02 07:04:47 --> Language Class Initialized
INFO - 2025-04-02 07:04:47 --> Language Class Initialized
INFO - 2025-04-02 07:04:47 --> Config Class Initialized
INFO - 2025-04-02 07:04:47 --> Loader Class Initialized
INFO - 2025-04-02 07:04:47 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:47 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:47 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:47 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:47 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:47 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:47 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:47 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:47 --> Email Class Initialized
INFO - 2025-04-02 07:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:47 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:47 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:47 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:47 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:47 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:47 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:47 --> Model Class Initialized
INFO - 2025-04-02 13:04:47 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:47 --> Total execution time: 0.0079
INFO - 2025-04-02 07:04:48 --> Config Class Initialized
INFO - 2025-04-02 07:04:48 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:48 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:48 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:48 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:48 --> Router Class Initialized
INFO - 2025-04-02 07:04:48 --> Output Class Initialized
INFO - 2025-04-02 07:04:48 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:48 --> Input Class Initialized
INFO - 2025-04-02 07:04:48 --> Language Class Initialized
INFO - 2025-04-02 07:04:48 --> Language Class Initialized
INFO - 2025-04-02 07:04:48 --> Config Class Initialized
INFO - 2025-04-02 07:04:48 --> Loader Class Initialized
INFO - 2025-04-02 07:04:48 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:48 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:48 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:48 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:48 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:48 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:48 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:48 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:48 --> Email Class Initialized
INFO - 2025-04-02 07:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:48 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:48 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:48 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:48 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:48 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:48 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:48 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:48 --> Model Class Initialized
INFO - 2025-04-02 13:04:48 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:48 --> Total execution time: 0.0076
INFO - 2025-04-02 07:04:55 --> Config Class Initialized
INFO - 2025-04-02 07:04:55 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:55 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:55 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:55 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:55 --> Router Class Initialized
INFO - 2025-04-02 07:04:55 --> Output Class Initialized
INFO - 2025-04-02 07:04:55 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:55 --> Input Class Initialized
INFO - 2025-04-02 07:04:55 --> Language Class Initialized
INFO - 2025-04-02 07:04:55 --> Language Class Initialized
INFO - 2025-04-02 07:04:55 --> Config Class Initialized
INFO - 2025-04-02 07:04:55 --> Loader Class Initialized
INFO - 2025-04-02 07:04:55 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:55 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:55 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:55 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:55 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:55 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:55 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:55 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:55 --> Email Class Initialized
INFO - 2025-04-02 07:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:55 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:55 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:55 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:55 --> Model Class Initialized
INFO - 2025-04-02 13:04:55 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:55 --> Total execution time: 0.0141
INFO - 2025-04-02 07:04:59 --> Config Class Initialized
INFO - 2025-04-02 07:04:59 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:04:59 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:04:59 --> Utf8 Class Initialized
INFO - 2025-04-02 07:04:59 --> URI Class Initialized
DEBUG - 2025-04-02 07:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:04:59 --> Router Class Initialized
INFO - 2025-04-02 07:04:59 --> Output Class Initialized
INFO - 2025-04-02 07:04:59 --> Security Class Initialized
DEBUG - 2025-04-02 07:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:04:59 --> Input Class Initialized
INFO - 2025-04-02 07:04:59 --> Language Class Initialized
INFO - 2025-04-02 07:04:59 --> Language Class Initialized
INFO - 2025-04-02 07:04:59 --> Config Class Initialized
INFO - 2025-04-02 07:04:59 --> Loader Class Initialized
INFO - 2025-04-02 07:04:59 --> Helper loaded: url_helper
INFO - 2025-04-02 07:04:59 --> Helper loaded: file_helper
INFO - 2025-04-02 07:04:59 --> Helper loaded: html_helper
INFO - 2025-04-02 07:04:59 --> Helper loaded: form_helper
INFO - 2025-04-02 07:04:59 --> Helper loaded: text_helper
INFO - 2025-04-02 07:04:59 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:04:59 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:04:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:04:59 --> Database Driver Class Initialized
INFO - 2025-04-02 07:04:59 --> Email Class Initialized
INFO - 2025-04-02 07:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:04:59 --> Form Validation Class Initialized
INFO - 2025-04-02 07:04:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:04:59 --> Pagination Class Initialized
INFO - 2025-04-02 07:04:59 --> Controller Class Initialized
DEBUG - 2025-04-02 07:04:59 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:04:59 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:04:59 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:04:59 --> Model Class Initialized
DEBUG - 2025-04-02 13:04:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:04:59 --> Model Class Initialized
INFO - 2025-04-02 13:04:59 --> Final output sent to browser
DEBUG - 2025-04-02 13:04:59 --> Total execution time: 0.0300
INFO - 2025-04-02 07:05:02 --> Config Class Initialized
INFO - 2025-04-02 07:05:02 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:05:02 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:05:02 --> Utf8 Class Initialized
INFO - 2025-04-02 07:05:02 --> URI Class Initialized
DEBUG - 2025-04-02 07:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:05:02 --> Router Class Initialized
INFO - 2025-04-02 07:05:02 --> Output Class Initialized
INFO - 2025-04-02 07:05:02 --> Security Class Initialized
DEBUG - 2025-04-02 07:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:05:02 --> Input Class Initialized
INFO - 2025-04-02 07:05:02 --> Language Class Initialized
INFO - 2025-04-02 07:05:02 --> Language Class Initialized
INFO - 2025-04-02 07:05:02 --> Config Class Initialized
INFO - 2025-04-02 07:05:02 --> Loader Class Initialized
INFO - 2025-04-02 07:05:02 --> Helper loaded: url_helper
INFO - 2025-04-02 07:05:02 --> Helper loaded: file_helper
INFO - 2025-04-02 07:05:02 --> Helper loaded: html_helper
INFO - 2025-04-02 07:05:02 --> Helper loaded: form_helper
INFO - 2025-04-02 07:05:02 --> Helper loaded: text_helper
INFO - 2025-04-02 07:05:02 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:05:02 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:05:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:05:02 --> Database Driver Class Initialized
INFO - 2025-04-02 07:05:02 --> Email Class Initialized
INFO - 2025-04-02 07:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:05:02 --> Form Validation Class Initialized
INFO - 2025-04-02 07:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:05:02 --> Pagination Class Initialized
INFO - 2025-04-02 07:05:02 --> Controller Class Initialized
DEBUG - 2025-04-02 07:05:02 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:05:02 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:05:02 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:05:02 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:05:02 --> Model Class Initialized
INFO - 2025-04-02 13:05:02 --> Final output sent to browser
DEBUG - 2025-04-02 13:05:02 --> Total execution time: 0.0107
INFO - 2025-04-02 07:05:17 --> Config Class Initialized
INFO - 2025-04-02 07:05:17 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:05:17 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:05:17 --> Utf8 Class Initialized
INFO - 2025-04-02 07:05:17 --> URI Class Initialized
DEBUG - 2025-04-02 07:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:05:17 --> Router Class Initialized
INFO - 2025-04-02 07:05:17 --> Output Class Initialized
INFO - 2025-04-02 07:05:17 --> Security Class Initialized
DEBUG - 2025-04-02 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:05:17 --> Input Class Initialized
INFO - 2025-04-02 07:05:17 --> Language Class Initialized
INFO - 2025-04-02 07:05:17 --> Language Class Initialized
INFO - 2025-04-02 07:05:17 --> Config Class Initialized
INFO - 2025-04-02 07:05:17 --> Loader Class Initialized
INFO - 2025-04-02 07:05:17 --> Helper loaded: url_helper
INFO - 2025-04-02 07:05:17 --> Helper loaded: file_helper
INFO - 2025-04-02 07:05:17 --> Helper loaded: html_helper
INFO - 2025-04-02 07:05:17 --> Helper loaded: form_helper
INFO - 2025-04-02 07:05:17 --> Helper loaded: text_helper
INFO - 2025-04-02 07:05:17 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:05:17 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:05:17 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:05:17 --> Database Driver Class Initialized
INFO - 2025-04-02 07:05:17 --> Email Class Initialized
INFO - 2025-04-02 07:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:05:17 --> Form Validation Class Initialized
INFO - 2025-04-02 07:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:05:17 --> Pagination Class Initialized
INFO - 2025-04-02 07:05:17 --> Controller Class Initialized
DEBUG - 2025-04-02 07:05:17 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:05:17 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:05:17 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:05:17 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:05:17 --> Model Class Initialized
INFO - 2025-04-02 13:05:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 494
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 494
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 494
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 494
ERROR - 2025-04-02 13:05:17 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
DEBUG - 2025-04-02 13:05:17 --> 📥 acc_transaction insert: {"vid":"154","fyear":"1","VNo":"CV-43","Vtype":"CV","referenceNo":"1089","VDate":"2025-04-02","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"288.88","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 13:05:17"}
DEBUG - 2025-04-02 13:05:17 --> 📥 acc_transaction insert: {"vid":"154","fyear":"1","VNo":"CV-43","Vtype":"CV","referenceNo":"1089","VDate":"2025-04-02","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"288.88","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 13:05:17"}
DEBUG - 2025-04-02 13:05:17 --> 📥 acc_transaction insert: {"vid":"155","fyear":"1","VNo":"JV-63","Vtype":"JV","referenceNo":"1089","VDate":"2025-04-02","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"169.14","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 13:05:17"}
DEBUG - 2025-04-02 13:05:17 --> 📥 acc_transaction insert: {"vid":"155","fyear":"1","VNo":"JV-63","Vtype":"JV","referenceNo":"1089","VDate":"2025-04-02","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"169.14","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 13:05:17"}
DEBUG - 2025-04-02 13:05:17 --> 📥 acc_transaction insert: {"vid":"156","fyear":"1","VNo":"JV-64","Vtype":"JV","referenceNo":"1089","VDate":"2025-04-02","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 13:05:17"}
DEBUG - 2025-04-02 13:05:17 --> 📥 acc_transaction insert: {"vid":"156","fyear":"1","VNo":"JV-64","Vtype":"JV","referenceNo":"1089","VDate":"2025-04-02","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 13:05:17"}
DEBUG - 2025-04-02 13:05:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-02 13:05:17 --> Final output sent to browser
DEBUG - 2025-04-02 13:05:17 --> Total execution time: 0.1369
INFO - 2025-04-02 07:05:21 --> Config Class Initialized
INFO - 2025-04-02 07:05:21 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:05:21 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:05:21 --> Utf8 Class Initialized
INFO - 2025-04-02 07:05:21 --> URI Class Initialized
DEBUG - 2025-04-02 07:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:05:21 --> Router Class Initialized
INFO - 2025-04-02 07:05:21 --> Output Class Initialized
INFO - 2025-04-02 07:05:21 --> Security Class Initialized
DEBUG - 2025-04-02 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:05:21 --> Input Class Initialized
INFO - 2025-04-02 07:05:21 --> Language Class Initialized
INFO - 2025-04-02 07:05:21 --> Language Class Initialized
INFO - 2025-04-02 07:05:21 --> Config Class Initialized
INFO - 2025-04-02 07:05:21 --> Loader Class Initialized
INFO - 2025-04-02 07:05:21 --> Helper loaded: url_helper
INFO - 2025-04-02 07:05:21 --> Helper loaded: file_helper
INFO - 2025-04-02 07:05:21 --> Helper loaded: html_helper
INFO - 2025-04-02 07:05:21 --> Helper loaded: form_helper
INFO - 2025-04-02 07:05:21 --> Helper loaded: text_helper
INFO - 2025-04-02 07:05:21 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:05:21 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:05:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:05:21 --> Database Driver Class Initialized
INFO - 2025-04-02 07:05:21 --> Email Class Initialized
INFO - 2025-04-02 07:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:05:21 --> Form Validation Class Initialized
INFO - 2025-04-02 07:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:05:21 --> Pagination Class Initialized
INFO - 2025-04-02 07:05:21 --> Controller Class Initialized
DEBUG - 2025-04-02 07:05:21 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:05:21 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:05:21 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:05:21 --> Model Class Initialized
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:05:21 --> Model Class Initialized
ERROR - 2025-04-02 13:05:21 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 13:05:21 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 13:05:21 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-02 13:05:21 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 13:05:21 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 13:05:21 --> Model Class Initialized
ERROR - 2025-04-02 13:05:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 13:05:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 13:05:21 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 13:05:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 13:05:21 --> Final output sent to browser
DEBUG - 2025-04-02 13:05:21 --> Total execution time: 0.1592
INFO - 2025-04-02 07:14:14 --> Config Class Initialized
INFO - 2025-04-02 07:14:14 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:14:14 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:14:14 --> Utf8 Class Initialized
INFO - 2025-04-02 07:14:14 --> URI Class Initialized
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-02 07:14:14 --> Router Class Initialized
INFO - 2025-04-02 07:14:14 --> Output Class Initialized
INFO - 2025-04-02 07:14:14 --> Security Class Initialized
DEBUG - 2025-04-02 07:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:14:14 --> Input Class Initialized
INFO - 2025-04-02 07:14:14 --> Language Class Initialized
INFO - 2025-04-02 07:14:14 --> Language Class Initialized
INFO - 2025-04-02 07:14:14 --> Config Class Initialized
INFO - 2025-04-02 07:14:14 --> Loader Class Initialized
INFO - 2025-04-02 07:14:14 --> Helper loaded: url_helper
INFO - 2025-04-02 07:14:14 --> Helper loaded: file_helper
INFO - 2025-04-02 07:14:14 --> Helper loaded: html_helper
INFO - 2025-04-02 07:14:14 --> Helper loaded: form_helper
INFO - 2025-04-02 07:14:14 --> Helper loaded: text_helper
INFO - 2025-04-02 07:14:14 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:14:14 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:14:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:14:14 --> Database Driver Class Initialized
INFO - 2025-04-02 07:14:14 --> Email Class Initialized
INFO - 2025-04-02 07:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:14:14 --> Form Validation Class Initialized
INFO - 2025-04-02 07:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:14:14 --> Pagination Class Initialized
INFO - 2025-04-02 07:14:14 --> Controller Class Initialized
DEBUG - 2025-04-02 07:14:14 --> Report MX_Controller Initialized
INFO - 2025-04-02 07:14:14 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-02 07:14:14 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:14:14 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:14:14 --> Model Class Initialized
ERROR - 2025-04-02 07:14:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:14:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:14:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:14:14 --> Final output sent to browser
DEBUG - 2025-04-02 07:14:14 --> Total execution time: 0.2018
INFO - 2025-04-02 07:14:15 --> Config Class Initialized
INFO - 2025-04-02 07:14:15 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:14:15 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:14:15 --> Utf8 Class Initialized
INFO - 2025-04-02 07:14:15 --> URI Class Initialized
DEBUG - 2025-04-02 07:14:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-02 07:14:15 --> Router Class Initialized
INFO - 2025-04-02 07:14:15 --> Output Class Initialized
INFO - 2025-04-02 07:14:15 --> Security Class Initialized
DEBUG - 2025-04-02 07:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:14:15 --> Input Class Initialized
INFO - 2025-04-02 07:14:15 --> Language Class Initialized
INFO - 2025-04-02 07:14:15 --> Language Class Initialized
INFO - 2025-04-02 07:14:15 --> Config Class Initialized
INFO - 2025-04-02 07:14:15 --> Loader Class Initialized
INFO - 2025-04-02 07:14:15 --> Helper loaded: url_helper
INFO - 2025-04-02 07:14:15 --> Helper loaded: file_helper
INFO - 2025-04-02 07:14:15 --> Helper loaded: html_helper
INFO - 2025-04-02 07:14:15 --> Helper loaded: form_helper
INFO - 2025-04-02 07:14:15 --> Helper loaded: text_helper
INFO - 2025-04-02 07:14:15 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:14:15 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:14:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:14:15 --> Database Driver Class Initialized
INFO - 2025-04-02 07:14:15 --> Email Class Initialized
INFO - 2025-04-02 07:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:14:15 --> Form Validation Class Initialized
INFO - 2025-04-02 07:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:14:15 --> Pagination Class Initialized
INFO - 2025-04-02 07:14:15 --> Controller Class Initialized
DEBUG - 2025-04-02 07:14:15 --> Report MX_Controller Initialized
INFO - 2025-04-02 07:14:15 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-02 07:14:15 --> Model Class Initialized
INFO - 2025-04-02 07:14:15 --> Final output sent to browser
DEBUG - 2025-04-02 07:14:15 --> Total execution time: 0.0067
INFO - 2025-04-02 07:14:47 --> Config Class Initialized
INFO - 2025-04-02 07:14:47 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:14:47 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:14:47 --> Utf8 Class Initialized
INFO - 2025-04-02 07:14:47 --> URI Class Initialized
DEBUG - 2025-04-02 07:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:14:47 --> Router Class Initialized
INFO - 2025-04-02 07:14:47 --> Output Class Initialized
INFO - 2025-04-02 07:14:47 --> Security Class Initialized
DEBUG - 2025-04-02 07:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:14:47 --> Input Class Initialized
INFO - 2025-04-02 07:14:47 --> Language Class Initialized
INFO - 2025-04-02 07:14:47 --> Language Class Initialized
INFO - 2025-04-02 07:14:47 --> Config Class Initialized
INFO - 2025-04-02 07:14:47 --> Loader Class Initialized
INFO - 2025-04-02 07:14:47 --> Helper loaded: url_helper
INFO - 2025-04-02 07:14:47 --> Helper loaded: file_helper
INFO - 2025-04-02 07:14:47 --> Helper loaded: html_helper
INFO - 2025-04-02 07:14:47 --> Helper loaded: form_helper
INFO - 2025-04-02 07:14:47 --> Helper loaded: text_helper
INFO - 2025-04-02 07:14:47 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:14:47 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:14:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:14:47 --> Database Driver Class Initialized
INFO - 2025-04-02 07:14:47 --> Email Class Initialized
INFO - 2025-04-02 07:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:14:47 --> Form Validation Class Initialized
INFO - 2025-04-02 07:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:14:47 --> Pagination Class Initialized
INFO - 2025-04-02 07:14:47 --> Controller Class Initialized
DEBUG - 2025-04-02 07:14:47 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:14:47 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:14:47 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:14:47 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:14:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:14:47 --> Model Class Initialized
ERROR - 2025-04-02 07:14:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:14:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-02 07:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:14:48 --> Final output sent to browser
DEBUG - 2025-04-02 07:14:48 --> Total execution time: 0.2365
INFO - 2025-04-02 07:14:49 --> Config Class Initialized
INFO - 2025-04-02 07:14:49 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:14:49 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:14:49 --> Utf8 Class Initialized
INFO - 2025-04-02 07:14:49 --> URI Class Initialized
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:14:49 --> Router Class Initialized
INFO - 2025-04-02 07:14:49 --> Output Class Initialized
INFO - 2025-04-02 07:14:49 --> Security Class Initialized
DEBUG - 2025-04-02 07:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:14:49 --> Input Class Initialized
INFO - 2025-04-02 07:14:49 --> Language Class Initialized
INFO - 2025-04-02 07:14:49 --> Language Class Initialized
INFO - 2025-04-02 07:14:49 --> Config Class Initialized
INFO - 2025-04-02 07:14:49 --> Loader Class Initialized
INFO - 2025-04-02 07:14:49 --> Helper loaded: url_helper
INFO - 2025-04-02 07:14:49 --> Helper loaded: file_helper
INFO - 2025-04-02 07:14:49 --> Helper loaded: html_helper
INFO - 2025-04-02 07:14:49 --> Helper loaded: form_helper
INFO - 2025-04-02 07:14:49 --> Helper loaded: text_helper
INFO - 2025-04-02 07:14:49 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:14:49 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:14:49 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:14:49 --> Database Driver Class Initialized
INFO - 2025-04-02 07:14:49 --> Email Class Initialized
INFO - 2025-04-02 07:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:14:49 --> Form Validation Class Initialized
INFO - 2025-04-02 07:14:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:14:49 --> Pagination Class Initialized
INFO - 2025-04-02 07:14:49 --> Controller Class Initialized
DEBUG - 2025-04-02 07:14:49 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:14:49 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:14:49 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:14:49 --> Model Class Initialized
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:14:49 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:14:49 --> Model Class Initialized
ERROR - 2025-04-02 07:14:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:14:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:14:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:14:49 --> Final output sent to browser
DEBUG - 2025-04-02 07:14:49 --> Total execution time: 0.2131
INFO - 2025-04-02 07:14:55 --> Config Class Initialized
INFO - 2025-04-02 07:14:55 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:14:55 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:14:55 --> Utf8 Class Initialized
INFO - 2025-04-02 07:14:55 --> URI Class Initialized
DEBUG - 2025-04-02 07:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:14:55 --> Router Class Initialized
INFO - 2025-04-02 07:14:55 --> Output Class Initialized
INFO - 2025-04-02 07:14:55 --> Security Class Initialized
DEBUG - 2025-04-02 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:14:55 --> Input Class Initialized
INFO - 2025-04-02 07:14:55 --> Language Class Initialized
INFO - 2025-04-02 07:14:55 --> Language Class Initialized
INFO - 2025-04-02 07:14:55 --> Config Class Initialized
INFO - 2025-04-02 07:14:55 --> Loader Class Initialized
INFO - 2025-04-02 07:14:55 --> Helper loaded: url_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: file_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: html_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: form_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: text_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:14:55 --> Database Driver Class Initialized
INFO - 2025-04-02 07:14:55 --> Email Class Initialized
INFO - 2025-04-02 07:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:14:55 --> Form Validation Class Initialized
INFO - 2025-04-02 07:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:14:55 --> Pagination Class Initialized
INFO - 2025-04-02 07:14:55 --> Controller Class Initialized
DEBUG - 2025-04-02 07:14:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 13:14:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
ERROR - 2025-04-02 13:14:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 13:14:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 13:14:55 --> Final output sent to browser
DEBUG - 2025-04-02 13:14:55 --> Total execution time: 0.1547
INFO - 2025-04-02 07:14:55 --> Config Class Initialized
INFO - 2025-04-02 07:14:55 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:14:55 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:14:55 --> Utf8 Class Initialized
INFO - 2025-04-02 07:14:55 --> URI Class Initialized
DEBUG - 2025-04-02 07:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:14:55 --> Router Class Initialized
INFO - 2025-04-02 07:14:55 --> Output Class Initialized
INFO - 2025-04-02 07:14:55 --> Security Class Initialized
DEBUG - 2025-04-02 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:14:55 --> Input Class Initialized
INFO - 2025-04-02 07:14:55 --> Language Class Initialized
INFO - 2025-04-02 07:14:55 --> Language Class Initialized
INFO - 2025-04-02 07:14:55 --> Config Class Initialized
INFO - 2025-04-02 07:14:55 --> Loader Class Initialized
INFO - 2025-04-02 07:14:55 --> Helper loaded: url_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: file_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: html_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: form_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: text_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:14:55 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:14:55 --> Database Driver Class Initialized
INFO - 2025-04-02 07:14:55 --> Email Class Initialized
INFO - 2025-04-02 07:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:14:55 --> Form Validation Class Initialized
INFO - 2025-04-02 07:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:14:55 --> Pagination Class Initialized
INFO - 2025-04-02 07:14:55 --> Controller Class Initialized
DEBUG - 2025-04-02 07:14:55 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
DEBUG - 2025-04-02 13:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:14:55 --> Model Class Initialized
INFO - 2025-04-02 13:14:55 --> Final output sent to browser
DEBUG - 2025-04-02 13:14:55 --> Total execution time: 0.0498
INFO - 2025-04-02 07:15:03 --> Config Class Initialized
INFO - 2025-04-02 07:15:03 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:15:03 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:15:03 --> Utf8 Class Initialized
INFO - 2025-04-02 07:15:03 --> URI Class Initialized
DEBUG - 2025-04-02 07:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:15:03 --> Router Class Initialized
INFO - 2025-04-02 07:15:03 --> Output Class Initialized
INFO - 2025-04-02 07:15:03 --> Security Class Initialized
DEBUG - 2025-04-02 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:15:03 --> Input Class Initialized
INFO - 2025-04-02 07:15:03 --> Language Class Initialized
INFO - 2025-04-02 07:15:03 --> Language Class Initialized
INFO - 2025-04-02 07:15:03 --> Config Class Initialized
INFO - 2025-04-02 07:15:03 --> Loader Class Initialized
INFO - 2025-04-02 07:15:03 --> Helper loaded: url_helper
INFO - 2025-04-02 07:15:03 --> Helper loaded: file_helper
INFO - 2025-04-02 07:15:03 --> Helper loaded: html_helper
INFO - 2025-04-02 07:15:03 --> Helper loaded: form_helper
INFO - 2025-04-02 07:15:03 --> Helper loaded: text_helper
INFO - 2025-04-02 07:15:03 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:15:03 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:15:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:15:03 --> Database Driver Class Initialized
INFO - 2025-04-02 07:15:03 --> Email Class Initialized
INFO - 2025-04-02 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:15:03 --> Form Validation Class Initialized
INFO - 2025-04-02 07:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:15:03 --> Pagination Class Initialized
INFO - 2025-04-02 07:15:03 --> Controller Class Initialized
DEBUG - 2025-04-02 07:15:03 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:15:03 --> Model Class Initialized
DEBUG - 2025-04-02 07:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:15:03 --> Model Class Initialized
DEBUG - 2025-04-02 07:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:15:03 --> Model Class Initialized
DEBUG - 2025-04-02 07:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:15:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:15:03 --> Model Class Initialized
ERROR - 2025-04-02 07:15:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:15:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:15:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:15:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:15:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:15:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-02 07:15:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:15:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:15:04 --> Final output sent to browser
DEBUG - 2025-04-02 07:15:04 --> Total execution time: 0.2075
INFO - 2025-04-02 07:15:11 --> Config Class Initialized
INFO - 2025-04-02 07:15:11 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:15:11 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:15:11 --> Utf8 Class Initialized
INFO - 2025-04-02 07:15:11 --> URI Class Initialized
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:15:11 --> Router Class Initialized
INFO - 2025-04-02 07:15:11 --> Output Class Initialized
INFO - 2025-04-02 07:15:11 --> Security Class Initialized
DEBUG - 2025-04-02 07:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:15:11 --> Input Class Initialized
INFO - 2025-04-02 07:15:11 --> Language Class Initialized
INFO - 2025-04-02 07:15:11 --> Language Class Initialized
INFO - 2025-04-02 07:15:11 --> Config Class Initialized
INFO - 2025-04-02 07:15:11 --> Loader Class Initialized
INFO - 2025-04-02 07:15:11 --> Helper loaded: url_helper
INFO - 2025-04-02 07:15:11 --> Helper loaded: file_helper
INFO - 2025-04-02 07:15:11 --> Helper loaded: html_helper
INFO - 2025-04-02 07:15:11 --> Helper loaded: form_helper
INFO - 2025-04-02 07:15:11 --> Helper loaded: text_helper
INFO - 2025-04-02 07:15:11 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:15:11 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:15:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:15:11 --> Database Driver Class Initialized
INFO - 2025-04-02 07:15:11 --> Email Class Initialized
INFO - 2025-04-02 07:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:15:11 --> Form Validation Class Initialized
INFO - 2025-04-02 07:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:15:11 --> Pagination Class Initialized
INFO - 2025-04-02 07:15:11 --> Controller Class Initialized
DEBUG - 2025-04-02 07:15:11 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:15:11 --> Model Class Initialized
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:15:11 --> Model Class Initialized
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:15:11 --> Model Class Initialized
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:15:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:15:11 --> Model Class Initialized
ERROR - 2025-04-02 07:15:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:15:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:15:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:15:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-02 07:15:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:15:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:15:12 --> Final output sent to browser
DEBUG - 2025-04-02 07:15:12 --> Total execution time: 0.1480
INFO - 2025-04-02 07:16:36 --> Config Class Initialized
INFO - 2025-04-02 07:16:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:16:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:16:36 --> Utf8 Class Initialized
INFO - 2025-04-02 07:16:36 --> URI Class Initialized
DEBUG - 2025-04-02 07:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:16:36 --> Router Class Initialized
INFO - 2025-04-02 07:16:36 --> Output Class Initialized
INFO - 2025-04-02 07:16:36 --> Security Class Initialized
DEBUG - 2025-04-02 07:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:16:36 --> Input Class Initialized
INFO - 2025-04-02 07:16:36 --> Language Class Initialized
INFO - 2025-04-02 07:16:36 --> Language Class Initialized
INFO - 2025-04-02 07:16:36 --> Config Class Initialized
INFO - 2025-04-02 07:16:36 --> Loader Class Initialized
INFO - 2025-04-02 07:16:36 --> Helper loaded: url_helper
INFO - 2025-04-02 07:16:36 --> Helper loaded: file_helper
INFO - 2025-04-02 07:16:36 --> Helper loaded: html_helper
INFO - 2025-04-02 07:16:36 --> Helper loaded: form_helper
INFO - 2025-04-02 07:16:36 --> Helper loaded: text_helper
INFO - 2025-04-02 07:16:36 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:16:36 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:16:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:16:36 --> Database Driver Class Initialized
INFO - 2025-04-02 07:16:36 --> Email Class Initialized
INFO - 2025-04-02 07:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:16:36 --> Form Validation Class Initialized
INFO - 2025-04-02 07:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:16:36 --> Pagination Class Initialized
INFO - 2025-04-02 07:16:36 --> Controller Class Initialized
DEBUG - 2025-04-02 07:16:36 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:16:36 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:16:36 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:16:36 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:16:36 --> Model Class Initialized
INFO - 2025-04-02 13:16:36 --> Final output sent to browser
DEBUG - 2025-04-02 13:16:36 --> Total execution time: 0.0146
INFO - 2025-04-02 07:16:38 --> Config Class Initialized
INFO - 2025-04-02 07:16:38 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:16:38 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:16:38 --> Utf8 Class Initialized
INFO - 2025-04-02 07:16:38 --> URI Class Initialized
DEBUG - 2025-04-02 07:16:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:16:38 --> Router Class Initialized
INFO - 2025-04-02 07:16:38 --> Output Class Initialized
INFO - 2025-04-02 07:16:38 --> Security Class Initialized
DEBUG - 2025-04-02 07:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:16:38 --> Input Class Initialized
INFO - 2025-04-02 07:16:38 --> Language Class Initialized
INFO - 2025-04-02 07:16:38 --> Language Class Initialized
INFO - 2025-04-02 07:16:38 --> Config Class Initialized
INFO - 2025-04-02 07:16:38 --> Loader Class Initialized
INFO - 2025-04-02 07:16:38 --> Helper loaded: url_helper
INFO - 2025-04-02 07:16:38 --> Helper loaded: file_helper
INFO - 2025-04-02 07:16:38 --> Helper loaded: html_helper
INFO - 2025-04-02 07:16:38 --> Helper loaded: form_helper
INFO - 2025-04-02 07:16:38 --> Helper loaded: text_helper
INFO - 2025-04-02 07:16:38 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:16:38 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:16:38 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:16:38 --> Database Driver Class Initialized
INFO - 2025-04-02 07:16:38 --> Email Class Initialized
INFO - 2025-04-02 07:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:16:38 --> Form Validation Class Initialized
INFO - 2025-04-02 07:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:16:38 --> Pagination Class Initialized
INFO - 2025-04-02 07:16:38 --> Controller Class Initialized
DEBUG - 2025-04-02 07:16:38 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:16:38 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:16:38 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:16:38 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:16:38 --> Model Class Initialized
INFO - 2025-04-02 13:16:38 --> Final output sent to browser
DEBUG - 2025-04-02 13:16:38 --> Total execution time: 0.0285
INFO - 2025-04-02 07:16:46 --> Config Class Initialized
INFO - 2025-04-02 07:16:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:16:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:16:46 --> Utf8 Class Initialized
INFO - 2025-04-02 07:16:46 --> URI Class Initialized
DEBUG - 2025-04-02 07:16:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:16:46 --> Router Class Initialized
INFO - 2025-04-02 07:16:46 --> Output Class Initialized
INFO - 2025-04-02 07:16:46 --> Security Class Initialized
DEBUG - 2025-04-02 07:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:16:46 --> Input Class Initialized
INFO - 2025-04-02 07:16:46 --> Language Class Initialized
INFO - 2025-04-02 07:16:46 --> Language Class Initialized
INFO - 2025-04-02 07:16:46 --> Config Class Initialized
INFO - 2025-04-02 07:16:46 --> Loader Class Initialized
INFO - 2025-04-02 07:16:46 --> Helper loaded: url_helper
INFO - 2025-04-02 07:16:46 --> Helper loaded: file_helper
INFO - 2025-04-02 07:16:46 --> Helper loaded: html_helper
INFO - 2025-04-02 07:16:46 --> Helper loaded: form_helper
INFO - 2025-04-02 07:16:46 --> Helper loaded: text_helper
INFO - 2025-04-02 07:16:46 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:16:46 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:16:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:16:46 --> Database Driver Class Initialized
INFO - 2025-04-02 07:16:46 --> Email Class Initialized
INFO - 2025-04-02 07:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:16:46 --> Form Validation Class Initialized
INFO - 2025-04-02 07:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:16:46 --> Pagination Class Initialized
INFO - 2025-04-02 07:16:46 --> Controller Class Initialized
DEBUG - 2025-04-02 07:16:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:16:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:16:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:16:46 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:16:46 --> Model Class Initialized
INFO - 2025-04-02 13:16:46 --> Final output sent to browser
DEBUG - 2025-04-02 13:16:46 --> Total execution time: 0.0096
INFO - 2025-04-02 07:16:57 --> Config Class Initialized
INFO - 2025-04-02 07:16:57 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:16:57 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:16:57 --> Utf8 Class Initialized
INFO - 2025-04-02 07:16:57 --> URI Class Initialized
DEBUG - 2025-04-02 07:16:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:16:57 --> Router Class Initialized
INFO - 2025-04-02 07:16:57 --> Output Class Initialized
INFO - 2025-04-02 07:16:57 --> Security Class Initialized
DEBUG - 2025-04-02 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:16:57 --> Input Class Initialized
INFO - 2025-04-02 07:16:57 --> Language Class Initialized
INFO - 2025-04-02 07:16:57 --> Language Class Initialized
INFO - 2025-04-02 07:16:57 --> Config Class Initialized
INFO - 2025-04-02 07:16:57 --> Loader Class Initialized
INFO - 2025-04-02 07:16:57 --> Helper loaded: url_helper
INFO - 2025-04-02 07:16:57 --> Helper loaded: file_helper
INFO - 2025-04-02 07:16:57 --> Helper loaded: html_helper
INFO - 2025-04-02 07:16:57 --> Helper loaded: form_helper
INFO - 2025-04-02 07:16:57 --> Helper loaded: text_helper
INFO - 2025-04-02 07:16:57 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:16:57 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:16:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:16:57 --> Database Driver Class Initialized
INFO - 2025-04-02 07:16:57 --> Email Class Initialized
INFO - 2025-04-02 07:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:16:57 --> Form Validation Class Initialized
INFO - 2025-04-02 07:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:16:57 --> Pagination Class Initialized
INFO - 2025-04-02 07:16:57 --> Controller Class Initialized
DEBUG - 2025-04-02 07:16:57 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:16:57 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:16:57 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:16:57 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:16:57 --> Model Class Initialized
INFO - 2025-04-02 13:16:57 --> Final output sent to browser
DEBUG - 2025-04-02 13:16:57 --> Total execution time: 0.0096
INFO - 2025-04-02 07:16:58 --> Config Class Initialized
INFO - 2025-04-02 07:16:58 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:16:58 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:16:58 --> Utf8 Class Initialized
INFO - 2025-04-02 07:16:58 --> URI Class Initialized
DEBUG - 2025-04-02 07:16:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:16:58 --> Router Class Initialized
INFO - 2025-04-02 07:16:58 --> Output Class Initialized
INFO - 2025-04-02 07:16:58 --> Security Class Initialized
DEBUG - 2025-04-02 07:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:16:58 --> Input Class Initialized
INFO - 2025-04-02 07:16:58 --> Language Class Initialized
INFO - 2025-04-02 07:16:58 --> Language Class Initialized
INFO - 2025-04-02 07:16:58 --> Config Class Initialized
INFO - 2025-04-02 07:16:58 --> Loader Class Initialized
INFO - 2025-04-02 07:16:58 --> Helper loaded: url_helper
INFO - 2025-04-02 07:16:58 --> Helper loaded: file_helper
INFO - 2025-04-02 07:16:58 --> Helper loaded: html_helper
INFO - 2025-04-02 07:16:58 --> Helper loaded: form_helper
INFO - 2025-04-02 07:16:58 --> Helper loaded: text_helper
INFO - 2025-04-02 07:16:58 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:16:58 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:16:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:16:58 --> Database Driver Class Initialized
INFO - 2025-04-02 07:16:58 --> Email Class Initialized
INFO - 2025-04-02 07:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:16:58 --> Form Validation Class Initialized
INFO - 2025-04-02 07:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:16:58 --> Pagination Class Initialized
INFO - 2025-04-02 07:16:58 --> Controller Class Initialized
DEBUG - 2025-04-02 07:16:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:16:58 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:16:58 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:16:58 --> Model Class Initialized
DEBUG - 2025-04-02 13:16:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:16:58 --> Model Class Initialized
INFO - 2025-04-02 13:16:58 --> Final output sent to browser
DEBUG - 2025-04-02 13:16:58 --> Total execution time: 0.0143
INFO - 2025-04-02 07:17:00 --> Config Class Initialized
INFO - 2025-04-02 07:17:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:00 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:00 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:17:00 --> Router Class Initialized
INFO - 2025-04-02 07:17:00 --> Output Class Initialized
INFO - 2025-04-02 07:17:00 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:00 --> Input Class Initialized
INFO - 2025-04-02 07:17:00 --> Language Class Initialized
INFO - 2025-04-02 07:17:00 --> Language Class Initialized
INFO - 2025-04-02 07:17:00 --> Config Class Initialized
INFO - 2025-04-02 07:17:00 --> Loader Class Initialized
INFO - 2025-04-02 07:17:00 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:00 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:00 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:00 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:00 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:00 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:00 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:00 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:00 --> Email Class Initialized
INFO - 2025-04-02 07:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:00 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:00 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:00 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:00 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:17:00 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:17:00 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:17:00 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:17:00 --> Model Class Initialized
INFO - 2025-04-02 13:17:00 --> Final output sent to browser
DEBUG - 2025-04-02 13:17:00 --> Total execution time: 0.0250
INFO - 2025-04-02 07:17:01 --> Config Class Initialized
INFO - 2025-04-02 07:17:01 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:01 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:01 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:01 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:17:01 --> Router Class Initialized
INFO - 2025-04-02 07:17:01 --> Output Class Initialized
INFO - 2025-04-02 07:17:01 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:01 --> Input Class Initialized
INFO - 2025-04-02 07:17:01 --> Language Class Initialized
INFO - 2025-04-02 07:17:01 --> Language Class Initialized
INFO - 2025-04-02 07:17:01 --> Config Class Initialized
INFO - 2025-04-02 07:17:01 --> Loader Class Initialized
INFO - 2025-04-02 07:17:01 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:01 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:01 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:01 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:01 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:01 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:01 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:01 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:01 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:01 --> Email Class Initialized
INFO - 2025-04-02 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:01 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:01 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:01 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:01 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:17:01 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:17:01 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:17:01 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:17:01 --> Model Class Initialized
INFO - 2025-04-02 13:17:01 --> Final output sent to browser
DEBUG - 2025-04-02 13:17:01 --> Total execution time: 0.0060
INFO - 2025-04-02 07:17:12 --> Config Class Initialized
INFO - 2025-04-02 07:17:12 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:12 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:12 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:12 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:17:12 --> Router Class Initialized
INFO - 2025-04-02 07:17:12 --> Output Class Initialized
INFO - 2025-04-02 07:17:12 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:12 --> Input Class Initialized
INFO - 2025-04-02 07:17:12 --> Language Class Initialized
INFO - 2025-04-02 07:17:12 --> Language Class Initialized
INFO - 2025-04-02 07:17:12 --> Config Class Initialized
INFO - 2025-04-02 07:17:12 --> Loader Class Initialized
INFO - 2025-04-02 07:17:12 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:12 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:12 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:12 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:12 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:12 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:12 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:12 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:12 --> Email Class Initialized
INFO - 2025-04-02 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:12 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:12 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:12 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:12 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:17:12 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:17:12 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:17:12 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:17:12 --> Model Class Initialized
INFO - 2025-04-02 13:17:12 --> Final output sent to browser
DEBUG - 2025-04-02 13:17:12 --> Total execution time: 0.0142
INFO - 2025-04-02 07:17:13 --> Config Class Initialized
INFO - 2025-04-02 07:17:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:13 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:13 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:17:13 --> Router Class Initialized
INFO - 2025-04-02 07:17:13 --> Output Class Initialized
INFO - 2025-04-02 07:17:13 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:13 --> Input Class Initialized
INFO - 2025-04-02 07:17:13 --> Language Class Initialized
INFO - 2025-04-02 07:17:13 --> Language Class Initialized
INFO - 2025-04-02 07:17:13 --> Config Class Initialized
INFO - 2025-04-02 07:17:13 --> Loader Class Initialized
INFO - 2025-04-02 07:17:13 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:13 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:13 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:13 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:13 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:13 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:13 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:13 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:13 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:13 --> Email Class Initialized
INFO - 2025-04-02 07:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:13 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:13 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:13 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:13 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:17:13 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:17:13 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:17:13 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:17:13 --> Model Class Initialized
INFO - 2025-04-02 13:17:13 --> Final output sent to browser
DEBUG - 2025-04-02 13:17:13 --> Total execution time: 0.0130
INFO - 2025-04-02 07:17:14 --> Config Class Initialized
INFO - 2025-04-02 07:17:14 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:14 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:14 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:14 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:17:14 --> Router Class Initialized
INFO - 2025-04-02 07:17:14 --> Output Class Initialized
INFO - 2025-04-02 07:17:14 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:14 --> Input Class Initialized
INFO - 2025-04-02 07:17:14 --> Language Class Initialized
INFO - 2025-04-02 07:17:14 --> Language Class Initialized
INFO - 2025-04-02 07:17:14 --> Config Class Initialized
INFO - 2025-04-02 07:17:14 --> Loader Class Initialized
INFO - 2025-04-02 07:17:14 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:14 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:14 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:14 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:14 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:14 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:14 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:14 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:14 --> Email Class Initialized
INFO - 2025-04-02 07:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:14 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:14 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:14 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:14 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:17:14 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:17:14 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:17:14 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:17:14 --> Model Class Initialized
INFO - 2025-04-02 13:17:14 --> Final output sent to browser
DEBUG - 2025-04-02 13:17:14 --> Total execution time: 0.0362
INFO - 2025-04-02 07:17:23 --> Config Class Initialized
INFO - 2025-04-02 07:17:23 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:23 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:23 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:23 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:17:23 --> Router Class Initialized
INFO - 2025-04-02 07:17:23 --> Output Class Initialized
INFO - 2025-04-02 07:17:23 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:23 --> Input Class Initialized
INFO - 2025-04-02 07:17:23 --> Language Class Initialized
INFO - 2025-04-02 07:17:23 --> Language Class Initialized
INFO - 2025-04-02 07:17:23 --> Config Class Initialized
INFO - 2025-04-02 07:17:23 --> Loader Class Initialized
INFO - 2025-04-02 07:17:23 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:23 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:23 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:23 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:23 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:23 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:23 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:23 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:23 --> Email Class Initialized
INFO - 2025-04-02 07:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:23 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:23 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:23 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:23 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:17:23 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:17:23 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:17:23 --> Model Class Initialized
DEBUG - 2025-04-02 13:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:17:23 --> Model Class Initialized
INFO - 2025-04-02 13:17:23 --> Final output sent to browser
DEBUG - 2025-04-02 13:17:23 --> Total execution time: 0.0123
INFO - 2025-04-02 07:17:37 --> Config Class Initialized
INFO - 2025-04-02 07:17:37 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:37 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:37 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:37 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:17:37 --> Router Class Initialized
INFO - 2025-04-02 07:17:37 --> Output Class Initialized
INFO - 2025-04-02 07:17:37 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:37 --> Input Class Initialized
INFO - 2025-04-02 07:17:37 --> Language Class Initialized
INFO - 2025-04-02 07:17:37 --> Language Class Initialized
INFO - 2025-04-02 07:17:37 --> Config Class Initialized
INFO - 2025-04-02 07:17:37 --> Loader Class Initialized
INFO - 2025-04-02 07:17:37 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:37 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:37 --> Email Class Initialized
INFO - 2025-04-02 07:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:37 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:37 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:37 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:37 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:17:37 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:17:37 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:17:37 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:37 --> 📥 acc_transaction insert: {"vid":"157","fyear":"1","VNo":"CV-44","Vtype":"CV","referenceNo":"3071737734","VDate":"2025-04-02","COAID":"1020101","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 07:17:37"}
DEBUG - 2025-04-02 07:17:37 --> 📥 acc_transaction insert: {"vid":"157","fyear":"1","VNo":"CV-44","Vtype":"CV","referenceNo":"3071737734","VDate":"2025-04-02","COAID":"3010301","Narration":"Sales Return Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Return Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 07:17:37"}
INFO - 2025-04-02 07:17:37 --> Config Class Initialized
INFO - 2025-04-02 07:17:37 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:37 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:37 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:37 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:17:37 --> Router Class Initialized
INFO - 2025-04-02 07:17:37 --> Output Class Initialized
INFO - 2025-04-02 07:17:37 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:37 --> Input Class Initialized
INFO - 2025-04-02 07:17:37 --> Language Class Initialized
INFO - 2025-04-02 07:17:37 --> Language Class Initialized
INFO - 2025-04-02 07:17:37 --> Config Class Initialized
INFO - 2025-04-02 07:17:37 --> Loader Class Initialized
INFO - 2025-04-02 07:17:37 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:37 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:37 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:37 --> Email Class Initialized
INFO - 2025-04-02 07:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:37 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:37 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:37 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:37 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:17:37 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:17:37 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:17:37 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:17:37 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:17:37 --> Model Class Initialized
ERROR - 2025-04-02 07:17:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:17:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:17:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:17:37 --> Final output sent to browser
DEBUG - 2025-04-02 07:17:37 --> Total execution time: 0.1327
INFO - 2025-04-02 07:17:45 --> Config Class Initialized
INFO - 2025-04-02 07:17:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:45 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:45 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-02 07:17:45 --> Router Class Initialized
INFO - 2025-04-02 07:17:45 --> Output Class Initialized
INFO - 2025-04-02 07:17:45 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:45 --> Input Class Initialized
INFO - 2025-04-02 07:17:45 --> Language Class Initialized
INFO - 2025-04-02 07:17:45 --> Language Class Initialized
INFO - 2025-04-02 07:17:45 --> Config Class Initialized
INFO - 2025-04-02 07:17:45 --> Loader Class Initialized
INFO - 2025-04-02 07:17:45 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:45 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:45 --> Email Class Initialized
INFO - 2025-04-02 07:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:45 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:45 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:45 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:45 --> Report MX_Controller Initialized
INFO - 2025-04-02 07:17:45 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-02 07:17:45 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:17:45 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:17:45 --> Model Class Initialized
ERROR - 2025-04-02 07:17:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:17:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:17:45 --> Final output sent to browser
DEBUG - 2025-04-02 07:17:45 --> Total execution time: 0.1306
INFO - 2025-04-02 07:17:45 --> Config Class Initialized
INFO - 2025-04-02 07:17:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:17:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:17:45 --> Utf8 Class Initialized
INFO - 2025-04-02 07:17:45 --> URI Class Initialized
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-02 07:17:45 --> Router Class Initialized
INFO - 2025-04-02 07:17:45 --> Output Class Initialized
INFO - 2025-04-02 07:17:45 --> Security Class Initialized
DEBUG - 2025-04-02 07:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:17:45 --> Input Class Initialized
INFO - 2025-04-02 07:17:45 --> Language Class Initialized
INFO - 2025-04-02 07:17:45 --> Language Class Initialized
INFO - 2025-04-02 07:17:45 --> Config Class Initialized
INFO - 2025-04-02 07:17:45 --> Loader Class Initialized
INFO - 2025-04-02 07:17:45 --> Helper loaded: url_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: file_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: html_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: form_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: text_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:17:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:17:45 --> Database Driver Class Initialized
INFO - 2025-04-02 07:17:45 --> Email Class Initialized
INFO - 2025-04-02 07:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:17:45 --> Form Validation Class Initialized
INFO - 2025-04-02 07:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:17:45 --> Pagination Class Initialized
INFO - 2025-04-02 07:17:45 --> Controller Class Initialized
DEBUG - 2025-04-02 07:17:45 --> Report MX_Controller Initialized
INFO - 2025-04-02 07:17:45 --> Model Class Initialized
DEBUG - 2025-04-02 07:17:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-02 07:17:45 --> Model Class Initialized
INFO - 2025-04-02 07:17:45 --> Final output sent to browser
DEBUG - 2025-04-02 07:17:45 --> Total execution time: 0.0118
INFO - 2025-04-02 07:22:16 --> Config Class Initialized
INFO - 2025-04-02 07:22:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:22:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:22:16 --> Utf8 Class Initialized
INFO - 2025-04-02 07:22:16 --> URI Class Initialized
DEBUG - 2025-04-02 07:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:22:16 --> Router Class Initialized
INFO - 2025-04-02 07:22:16 --> Output Class Initialized
INFO - 2025-04-02 07:22:16 --> Security Class Initialized
DEBUG - 2025-04-02 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:22:16 --> Input Class Initialized
INFO - 2025-04-02 07:22:16 --> Language Class Initialized
INFO - 2025-04-02 07:22:16 --> Language Class Initialized
INFO - 2025-04-02 07:22:16 --> Config Class Initialized
INFO - 2025-04-02 07:22:16 --> Loader Class Initialized
INFO - 2025-04-02 07:22:16 --> Helper loaded: url_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: file_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: html_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: form_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: text_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:22:16 --> Database Driver Class Initialized
INFO - 2025-04-02 07:22:16 --> Email Class Initialized
INFO - 2025-04-02 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:22:16 --> Form Validation Class Initialized
INFO - 2025-04-02 07:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:22:16 --> Pagination Class Initialized
INFO - 2025-04-02 07:22:16 --> Controller Class Initialized
DEBUG - 2025-04-02 07:22:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 13:22:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
ERROR - 2025-04-02 13:22:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 13:22:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 13:22:16 --> Final output sent to browser
DEBUG - 2025-04-02 13:22:16 --> Total execution time: 0.1752
INFO - 2025-04-02 07:22:16 --> Config Class Initialized
INFO - 2025-04-02 07:22:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:22:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:22:16 --> Utf8 Class Initialized
INFO - 2025-04-02 07:22:16 --> URI Class Initialized
DEBUG - 2025-04-02 07:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:22:16 --> Router Class Initialized
INFO - 2025-04-02 07:22:16 --> Output Class Initialized
INFO - 2025-04-02 07:22:16 --> Security Class Initialized
DEBUG - 2025-04-02 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:22:16 --> Input Class Initialized
INFO - 2025-04-02 07:22:16 --> Language Class Initialized
INFO - 2025-04-02 07:22:16 --> Language Class Initialized
INFO - 2025-04-02 07:22:16 --> Config Class Initialized
INFO - 2025-04-02 07:22:16 --> Loader Class Initialized
INFO - 2025-04-02 07:22:16 --> Helper loaded: url_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: file_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: html_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: form_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: text_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:22:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:22:16 --> Database Driver Class Initialized
INFO - 2025-04-02 07:22:16 --> Email Class Initialized
INFO - 2025-04-02 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:22:16 --> Form Validation Class Initialized
INFO - 2025-04-02 07:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:22:16 --> Pagination Class Initialized
INFO - 2025-04-02 07:22:16 --> Controller Class Initialized
DEBUG - 2025-04-02 07:22:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:22:16 --> Model Class Initialized
INFO - 2025-04-02 13:22:16 --> Final output sent to browser
DEBUG - 2025-04-02 13:22:16 --> Total execution time: 0.0617
INFO - 2025-04-02 07:22:20 --> Config Class Initialized
INFO - 2025-04-02 07:22:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:22:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:22:20 --> Utf8 Class Initialized
INFO - 2025-04-02 07:22:20 --> URI Class Initialized
DEBUG - 2025-04-02 07:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 07:22:20 --> Router Class Initialized
INFO - 2025-04-02 07:22:20 --> Output Class Initialized
INFO - 2025-04-02 07:22:20 --> Security Class Initialized
DEBUG - 2025-04-02 07:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:22:20 --> Input Class Initialized
INFO - 2025-04-02 07:22:20 --> Language Class Initialized
INFO - 2025-04-02 07:22:20 --> Language Class Initialized
INFO - 2025-04-02 07:22:20 --> Config Class Initialized
INFO - 2025-04-02 07:22:20 --> Loader Class Initialized
INFO - 2025-04-02 07:22:20 --> Helper loaded: url_helper
INFO - 2025-04-02 07:22:20 --> Helper loaded: file_helper
INFO - 2025-04-02 07:22:20 --> Helper loaded: html_helper
INFO - 2025-04-02 07:22:20 --> Helper loaded: form_helper
INFO - 2025-04-02 07:22:20 --> Helper loaded: text_helper
INFO - 2025-04-02 07:22:20 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:22:20 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:22:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:22:20 --> Database Driver Class Initialized
INFO - 2025-04-02 07:22:20 --> Email Class Initialized
INFO - 2025-04-02 07:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:22:20 --> Form Validation Class Initialized
INFO - 2025-04-02 07:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:22:20 --> Pagination Class Initialized
INFO - 2025-04-02 07:22:20 --> Controller Class Initialized
DEBUG - 2025-04-02 07:22:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 13:22:20 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 13:22:20 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 13:22:20 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 13:22:20 --> Model Class Initialized
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 13:22:20 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 13:22:20 --> Model Class Initialized
ERROR - 2025-04-02 13:22:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 13:22:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 13:22:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 13:22:20 --> Final output sent to browser
DEBUG - 2025-04-02 13:22:20 --> Total execution time: 0.1539
INFO - 2025-04-02 07:22:31 --> Config Class Initialized
INFO - 2025-04-02 07:22:31 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:22:31 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:22:31 --> Utf8 Class Initialized
INFO - 2025-04-02 07:22:31 --> URI Class Initialized
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:22:31 --> Router Class Initialized
INFO - 2025-04-02 07:22:31 --> Output Class Initialized
INFO - 2025-04-02 07:22:31 --> Security Class Initialized
DEBUG - 2025-04-02 07:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:22:31 --> Input Class Initialized
INFO - 2025-04-02 07:22:31 --> Language Class Initialized
INFO - 2025-04-02 07:22:31 --> Language Class Initialized
INFO - 2025-04-02 07:22:31 --> Config Class Initialized
INFO - 2025-04-02 07:22:31 --> Loader Class Initialized
INFO - 2025-04-02 07:22:31 --> Helper loaded: url_helper
INFO - 2025-04-02 07:22:31 --> Helper loaded: file_helper
INFO - 2025-04-02 07:22:31 --> Helper loaded: html_helper
INFO - 2025-04-02 07:22:31 --> Helper loaded: form_helper
INFO - 2025-04-02 07:22:31 --> Helper loaded: text_helper
INFO - 2025-04-02 07:22:31 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:22:31 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:22:31 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:22:31 --> Database Driver Class Initialized
INFO - 2025-04-02 07:22:31 --> Email Class Initialized
INFO - 2025-04-02 07:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:22:31 --> Form Validation Class Initialized
INFO - 2025-04-02 07:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:22:31 --> Pagination Class Initialized
INFO - 2025-04-02 07:22:31 --> Controller Class Initialized
DEBUG - 2025-04-02 07:22:31 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:22:31 --> Model Class Initialized
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:22:31 --> Model Class Initialized
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:22:31 --> Model Class Initialized
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:22:31 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:22:31 --> Model Class Initialized
ERROR - 2025-04-02 07:22:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:22:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:22:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:22:31 --> Final output sent to browser
DEBUG - 2025-04-02 07:22:31 --> Total execution time: 0.2159
INFO - 2025-04-02 07:22:35 --> Config Class Initialized
INFO - 2025-04-02 07:22:35 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:22:35 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:22:35 --> Utf8 Class Initialized
INFO - 2025-04-02 07:22:35 --> URI Class Initialized
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:22:35 --> Router Class Initialized
INFO - 2025-04-02 07:22:35 --> Output Class Initialized
INFO - 2025-04-02 07:22:35 --> Security Class Initialized
DEBUG - 2025-04-02 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:22:35 --> Input Class Initialized
INFO - 2025-04-02 07:22:35 --> Language Class Initialized
INFO - 2025-04-02 07:22:35 --> Language Class Initialized
INFO - 2025-04-02 07:22:35 --> Config Class Initialized
INFO - 2025-04-02 07:22:35 --> Loader Class Initialized
INFO - 2025-04-02 07:22:35 --> Helper loaded: url_helper
INFO - 2025-04-02 07:22:35 --> Helper loaded: file_helper
INFO - 2025-04-02 07:22:35 --> Helper loaded: html_helper
INFO - 2025-04-02 07:22:35 --> Helper loaded: form_helper
INFO - 2025-04-02 07:22:35 --> Helper loaded: text_helper
INFO - 2025-04-02 07:22:35 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:22:35 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:22:35 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:22:35 --> Database Driver Class Initialized
INFO - 2025-04-02 07:22:35 --> Email Class Initialized
INFO - 2025-04-02 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:22:35 --> Form Validation Class Initialized
INFO - 2025-04-02 07:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:22:35 --> Pagination Class Initialized
INFO - 2025-04-02 07:22:35 --> Controller Class Initialized
DEBUG - 2025-04-02 07:22:35 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:22:35 --> Model Class Initialized
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:22:35 --> Model Class Initialized
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:22:35 --> Model Class Initialized
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:22:35 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:22:35 --> Model Class Initialized
ERROR - 2025-04-02 07:22:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:22:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:22:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:22:35 --> Final output sent to browser
DEBUG - 2025-04-02 07:22:35 --> Total execution time: 0.0985
INFO - 2025-04-02 07:23:21 --> Config Class Initialized
INFO - 2025-04-02 07:23:21 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:23:21 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:23:21 --> Utf8 Class Initialized
INFO - 2025-04-02 07:23:21 --> URI Class Initialized
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:23:21 --> Router Class Initialized
INFO - 2025-04-02 07:23:21 --> Output Class Initialized
INFO - 2025-04-02 07:23:21 --> Security Class Initialized
DEBUG - 2025-04-02 07:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:23:21 --> Input Class Initialized
INFO - 2025-04-02 07:23:21 --> Language Class Initialized
INFO - 2025-04-02 07:23:21 --> Language Class Initialized
INFO - 2025-04-02 07:23:21 --> Config Class Initialized
INFO - 2025-04-02 07:23:21 --> Loader Class Initialized
INFO - 2025-04-02 07:23:21 --> Helper loaded: url_helper
INFO - 2025-04-02 07:23:21 --> Helper loaded: file_helper
INFO - 2025-04-02 07:23:21 --> Helper loaded: html_helper
INFO - 2025-04-02 07:23:21 --> Helper loaded: form_helper
INFO - 2025-04-02 07:23:21 --> Helper loaded: text_helper
INFO - 2025-04-02 07:23:21 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:23:21 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:23:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:23:21 --> Database Driver Class Initialized
INFO - 2025-04-02 07:23:21 --> Email Class Initialized
INFO - 2025-04-02 07:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:23:21 --> Form Validation Class Initialized
INFO - 2025-04-02 07:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:23:21 --> Pagination Class Initialized
INFO - 2025-04-02 07:23:21 --> Controller Class Initialized
DEBUG - 2025-04-02 07:23:21 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:23:21 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:23:21 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:23:21 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:23:21 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:23:21 --> Model Class Initialized
ERROR - 2025-04-02 07:23:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:23:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:23:21 --> Final output sent to browser
DEBUG - 2025-04-02 07:23:21 --> Total execution time: 0.1758
INFO - 2025-04-02 07:23:23 --> Config Class Initialized
INFO - 2025-04-02 07:23:23 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:23:23 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:23:23 --> Utf8 Class Initialized
INFO - 2025-04-02 07:23:23 --> URI Class Initialized
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:23:23 --> Router Class Initialized
INFO - 2025-04-02 07:23:23 --> Output Class Initialized
INFO - 2025-04-02 07:23:23 --> Security Class Initialized
DEBUG - 2025-04-02 07:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:23:23 --> Input Class Initialized
INFO - 2025-04-02 07:23:23 --> Language Class Initialized
INFO - 2025-04-02 07:23:23 --> Language Class Initialized
INFO - 2025-04-02 07:23:23 --> Config Class Initialized
INFO - 2025-04-02 07:23:23 --> Loader Class Initialized
INFO - 2025-04-02 07:23:23 --> Helper loaded: url_helper
INFO - 2025-04-02 07:23:23 --> Helper loaded: file_helper
INFO - 2025-04-02 07:23:23 --> Helper loaded: html_helper
INFO - 2025-04-02 07:23:23 --> Helper loaded: form_helper
INFO - 2025-04-02 07:23:23 --> Helper loaded: text_helper
INFO - 2025-04-02 07:23:23 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:23:23 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:23:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:23:23 --> Database Driver Class Initialized
INFO - 2025-04-02 07:23:23 --> Email Class Initialized
INFO - 2025-04-02 07:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:23:23 --> Form Validation Class Initialized
INFO - 2025-04-02 07:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:23:23 --> Pagination Class Initialized
INFO - 2025-04-02 07:23:23 --> Controller Class Initialized
DEBUG - 2025-04-02 07:23:23 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:23:23 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:23:23 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:23:23 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:23:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:23:23 --> Model Class Initialized
ERROR - 2025-04-02 07:23:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:23:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:23:23 --> Final output sent to browser
DEBUG - 2025-04-02 07:23:23 --> Total execution time: 0.1392
INFO - 2025-04-02 07:23:30 --> Config Class Initialized
INFO - 2025-04-02 07:23:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:23:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:23:30 --> Utf8 Class Initialized
INFO - 2025-04-02 07:23:30 --> URI Class Initialized
DEBUG - 2025-04-02 07:23:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:23:30 --> Router Class Initialized
INFO - 2025-04-02 07:23:30 --> Output Class Initialized
INFO - 2025-04-02 07:23:30 --> Security Class Initialized
DEBUG - 2025-04-02 07:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:23:30 --> Input Class Initialized
INFO - 2025-04-02 07:23:30 --> Language Class Initialized
INFO - 2025-04-02 07:23:30 --> Language Class Initialized
INFO - 2025-04-02 07:23:30 --> Config Class Initialized
INFO - 2025-04-02 07:23:30 --> Loader Class Initialized
INFO - 2025-04-02 07:23:30 --> Helper loaded: url_helper
INFO - 2025-04-02 07:23:30 --> Helper loaded: file_helper
INFO - 2025-04-02 07:23:30 --> Helper loaded: html_helper
INFO - 2025-04-02 07:23:30 --> Helper loaded: form_helper
INFO - 2025-04-02 07:23:30 --> Helper loaded: text_helper
INFO - 2025-04-02 07:23:30 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:23:30 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:23:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:23:30 --> Database Driver Class Initialized
INFO - 2025-04-02 07:23:30 --> Email Class Initialized
INFO - 2025-04-02 07:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:23:30 --> Form Validation Class Initialized
INFO - 2025-04-02 07:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:23:30 --> Pagination Class Initialized
INFO - 2025-04-02 07:23:30 --> Controller Class Initialized
DEBUG - 2025-04-02 07:23:30 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:23:30 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:23:30 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:23:30 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:23:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:23:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:23:30 --> Model Class Initialized
ERROR - 2025-04-02 07:23:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:23:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:23:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:23:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:23:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:23:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:23:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-02 07:23:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:23:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:23:31 --> Final output sent to browser
DEBUG - 2025-04-02 07:23:31 --> Total execution time: 0.1882
INFO - 2025-04-02 07:23:39 --> Config Class Initialized
INFO - 2025-04-02 07:23:39 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:23:39 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:23:39 --> Utf8 Class Initialized
INFO - 2025-04-02 07:23:39 --> URI Class Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:23:39 --> Router Class Initialized
INFO - 2025-04-02 07:23:39 --> Output Class Initialized
INFO - 2025-04-02 07:23:39 --> Security Class Initialized
DEBUG - 2025-04-02 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:23:39 --> Input Class Initialized
INFO - 2025-04-02 07:23:39 --> Language Class Initialized
INFO - 2025-04-02 07:23:39 --> Language Class Initialized
INFO - 2025-04-02 07:23:39 --> Config Class Initialized
INFO - 2025-04-02 07:23:39 --> Loader Class Initialized
INFO - 2025-04-02 07:23:39 --> Helper loaded: url_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: file_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: html_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: form_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: text_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:23:39 --> Database Driver Class Initialized
INFO - 2025-04-02 07:23:39 --> Email Class Initialized
INFO - 2025-04-02 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:23:39 --> Form Validation Class Initialized
INFO - 2025-04-02 07:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:23:39 --> Pagination Class Initialized
INFO - 2025-04-02 07:23:39 --> Controller Class Initialized
DEBUG - 2025-04-02 07:23:39 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:23:39 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:23:39 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:23:39 --> Model Class Initialized
INFO - 2025-04-02 07:23:39 --> Config Class Initialized
INFO - 2025-04-02 07:23:39 --> Hooks Class Initialized
DEBUG - 2025-04-02 07:23:39 --> UTF-8 Support Enabled
INFO - 2025-04-02 07:23:39 --> Utf8 Class Initialized
INFO - 2025-04-02 07:23:39 --> URI Class Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-02 07:23:39 --> Router Class Initialized
INFO - 2025-04-02 07:23:39 --> Output Class Initialized
INFO - 2025-04-02 07:23:39 --> Security Class Initialized
DEBUG - 2025-04-02 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 07:23:39 --> Input Class Initialized
INFO - 2025-04-02 07:23:39 --> Language Class Initialized
INFO - 2025-04-02 07:23:39 --> Language Class Initialized
INFO - 2025-04-02 07:23:39 --> Config Class Initialized
INFO - 2025-04-02 07:23:39 --> Loader Class Initialized
INFO - 2025-04-02 07:23:39 --> Helper loaded: url_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: file_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: html_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: form_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: text_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: lang_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: directory_helper
INFO - 2025-04-02 07:23:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 07:23:39 --> Database Driver Class Initialized
INFO - 2025-04-02 07:23:39 --> Email Class Initialized
INFO - 2025-04-02 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 07:23:39 --> Form Validation Class Initialized
INFO - 2025-04-02 07:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 07:23:39 --> Pagination Class Initialized
INFO - 2025-04-02 07:23:39 --> Controller Class Initialized
DEBUG - 2025-04-02 07:23:39 --> Returns MX_Controller Initialized
INFO - 2025-04-02 07:23:39 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-02 07:23:39 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 07:23:39 --> Model Class Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 07:23:39 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 07:23:39 --> Model Class Initialized
ERROR - 2025-04-02 07:23:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 07:23:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 07:23:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 07:23:39 --> Final output sent to browser
DEBUG - 2025-04-02 07:23:39 --> Total execution time: 0.1583
INFO - 2025-04-02 08:27:48 --> Config Class Initialized
INFO - 2025-04-02 08:27:48 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:27:48 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:27:48 --> Utf8 Class Initialized
INFO - 2025-04-02 08:27:48 --> URI Class Initialized
DEBUG - 2025-04-02 08:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:27:48 --> Router Class Initialized
INFO - 2025-04-02 08:27:48 --> Output Class Initialized
INFO - 2025-04-02 08:27:48 --> Security Class Initialized
DEBUG - 2025-04-02 08:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:27:48 --> Input Class Initialized
INFO - 2025-04-02 08:27:48 --> Language Class Initialized
INFO - 2025-04-02 08:27:48 --> Language Class Initialized
INFO - 2025-04-02 08:27:48 --> Config Class Initialized
INFO - 2025-04-02 08:27:48 --> Loader Class Initialized
INFO - 2025-04-02 08:27:48 --> Helper loaded: url_helper
INFO - 2025-04-02 08:27:48 --> Helper loaded: file_helper
INFO - 2025-04-02 08:27:48 --> Helper loaded: html_helper
INFO - 2025-04-02 08:27:48 --> Helper loaded: form_helper
INFO - 2025-04-02 08:27:48 --> Helper loaded: text_helper
INFO - 2025-04-02 08:27:48 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:27:48 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:27:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:27:48 --> Database Driver Class Initialized
INFO - 2025-04-02 08:27:48 --> Email Class Initialized
INFO - 2025-04-02 08:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:27:48 --> Form Validation Class Initialized
INFO - 2025-04-02 08:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:27:48 --> Pagination Class Initialized
INFO - 2025-04-02 08:27:48 --> Controller Class Initialized
DEBUG - 2025-04-02 08:27:48 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:27:48 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:27:48 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:27:48 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:27:48 --> Model Class Initialized
ERROR - 2025-04-02 14:27:48 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:27:48 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:27:48 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-02 14:27:48 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 14:27:48 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 14:27:48 --> Model Class Initialized
ERROR - 2025-04-02 14:27:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 14:27:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 14:27:48 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 14:27:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 14:27:48 --> Final output sent to browser
DEBUG - 2025-04-02 14:27:48 --> Total execution time: 0.5199
INFO - 2025-04-02 08:27:57 --> Config Class Initialized
INFO - 2025-04-02 08:27:57 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:27:57 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:27:57 --> Utf8 Class Initialized
INFO - 2025-04-02 08:27:57 --> URI Class Initialized
DEBUG - 2025-04-02 08:27:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:27:57 --> Router Class Initialized
INFO - 2025-04-02 08:27:57 --> Output Class Initialized
INFO - 2025-04-02 08:27:57 --> Security Class Initialized
DEBUG - 2025-04-02 08:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:27:57 --> Input Class Initialized
INFO - 2025-04-02 08:27:57 --> Language Class Initialized
INFO - 2025-04-02 08:27:57 --> Language Class Initialized
INFO - 2025-04-02 08:27:57 --> Config Class Initialized
INFO - 2025-04-02 08:27:57 --> Loader Class Initialized
INFO - 2025-04-02 08:27:57 --> Helper loaded: url_helper
INFO - 2025-04-02 08:27:57 --> Helper loaded: file_helper
INFO - 2025-04-02 08:27:57 --> Helper loaded: html_helper
INFO - 2025-04-02 08:27:57 --> Helper loaded: form_helper
INFO - 2025-04-02 08:27:57 --> Helper loaded: text_helper
INFO - 2025-04-02 08:27:57 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:27:57 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:27:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:27:57 --> Database Driver Class Initialized
INFO - 2025-04-02 08:27:57 --> Email Class Initialized
INFO - 2025-04-02 08:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:27:57 --> Form Validation Class Initialized
INFO - 2025-04-02 08:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:27:57 --> Pagination Class Initialized
INFO - 2025-04-02 08:27:57 --> Controller Class Initialized
DEBUG - 2025-04-02 08:27:57 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:27:57 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:27:57 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:27:57 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:27:57 --> Model Class Initialized
INFO - 2025-04-02 14:27:57 --> Final output sent to browser
DEBUG - 2025-04-02 14:27:57 --> Total execution time: 0.0105
INFO - 2025-04-02 08:27:58 --> Config Class Initialized
INFO - 2025-04-02 08:27:58 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:27:58 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:27:58 --> Utf8 Class Initialized
INFO - 2025-04-02 08:27:58 --> URI Class Initialized
DEBUG - 2025-04-02 08:27:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:27:58 --> Router Class Initialized
INFO - 2025-04-02 08:27:58 --> Output Class Initialized
INFO - 2025-04-02 08:27:58 --> Security Class Initialized
DEBUG - 2025-04-02 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:27:58 --> Input Class Initialized
INFO - 2025-04-02 08:27:58 --> Language Class Initialized
INFO - 2025-04-02 08:27:58 --> Language Class Initialized
INFO - 2025-04-02 08:27:58 --> Config Class Initialized
INFO - 2025-04-02 08:27:58 --> Loader Class Initialized
INFO - 2025-04-02 08:27:58 --> Helper loaded: url_helper
INFO - 2025-04-02 08:27:58 --> Helper loaded: file_helper
INFO - 2025-04-02 08:27:58 --> Helper loaded: html_helper
INFO - 2025-04-02 08:27:58 --> Helper loaded: form_helper
INFO - 2025-04-02 08:27:58 --> Helper loaded: text_helper
INFO - 2025-04-02 08:27:58 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:27:58 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:27:58 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:27:58 --> Database Driver Class Initialized
INFO - 2025-04-02 08:27:58 --> Email Class Initialized
INFO - 2025-04-02 08:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:27:58 --> Form Validation Class Initialized
INFO - 2025-04-02 08:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:27:58 --> Pagination Class Initialized
INFO - 2025-04-02 08:27:58 --> Controller Class Initialized
DEBUG - 2025-04-02 08:27:58 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:27:58 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:27:58 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:27:58 --> Model Class Initialized
DEBUG - 2025-04-02 14:27:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:27:58 --> Model Class Initialized
INFO - 2025-04-02 14:27:58 --> Final output sent to browser
DEBUG - 2025-04-02 14:27:58 --> Total execution time: 0.0119
INFO - 2025-04-02 08:28:11 --> Config Class Initialized
INFO - 2025-04-02 08:28:11 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:28:11 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:28:11 --> Utf8 Class Initialized
INFO - 2025-04-02 08:28:11 --> URI Class Initialized
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:28:11 --> Router Class Initialized
INFO - 2025-04-02 08:28:11 --> Output Class Initialized
INFO - 2025-04-02 08:28:11 --> Security Class Initialized
DEBUG - 2025-04-02 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:28:11 --> Input Class Initialized
INFO - 2025-04-02 08:28:11 --> Language Class Initialized
INFO - 2025-04-02 08:28:11 --> Language Class Initialized
INFO - 2025-04-02 08:28:11 --> Config Class Initialized
INFO - 2025-04-02 08:28:11 --> Loader Class Initialized
INFO - 2025-04-02 08:28:11 --> Helper loaded: url_helper
INFO - 2025-04-02 08:28:11 --> Helper loaded: file_helper
INFO - 2025-04-02 08:28:11 --> Helper loaded: html_helper
INFO - 2025-04-02 08:28:11 --> Helper loaded: form_helper
INFO - 2025-04-02 08:28:11 --> Helper loaded: text_helper
INFO - 2025-04-02 08:28:11 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:28:11 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:28:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:28:11 --> Database Driver Class Initialized
INFO - 2025-04-02 08:28:11 --> Email Class Initialized
INFO - 2025-04-02 08:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:28:11 --> Form Validation Class Initialized
INFO - 2025-04-02 08:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:28:11 --> Pagination Class Initialized
INFO - 2025-04-02 08:28:11 --> Controller Class Initialized
DEBUG - 2025-04-02 08:28:11 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:28:11 --> Model Class Initialized
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:28:11 --> Model Class Initialized
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:28:11 --> Model Class Initialized
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:28:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:28:11 --> Model Class Initialized
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 115
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:28:11 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:28:11 --> Final output sent to browser
DEBUG - 2025-04-02 08:28:11 --> Total execution time: 0.1467
INFO - 2025-04-02 08:28:21 --> Config Class Initialized
INFO - 2025-04-02 08:28:21 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:28:21 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:28:21 --> Utf8 Class Initialized
INFO - 2025-04-02 08:28:21 --> URI Class Initialized
DEBUG - 2025-04-02 08:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:28:21 --> Router Class Initialized
INFO - 2025-04-02 08:28:21 --> Output Class Initialized
INFO - 2025-04-02 08:28:21 --> Security Class Initialized
DEBUG - 2025-04-02 08:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:28:21 --> Input Class Initialized
INFO - 2025-04-02 08:28:21 --> Language Class Initialized
INFO - 2025-04-02 08:28:21 --> Language Class Initialized
INFO - 2025-04-02 08:28:21 --> Config Class Initialized
INFO - 2025-04-02 08:28:21 --> Loader Class Initialized
INFO - 2025-04-02 08:28:21 --> Helper loaded: url_helper
INFO - 2025-04-02 08:28:21 --> Helper loaded: file_helper
INFO - 2025-04-02 08:28:21 --> Helper loaded: html_helper
INFO - 2025-04-02 08:28:21 --> Helper loaded: form_helper
INFO - 2025-04-02 08:28:21 --> Helper loaded: text_helper
INFO - 2025-04-02 08:28:21 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:28:21 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:28:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:28:21 --> Database Driver Class Initialized
INFO - 2025-04-02 08:28:21 --> Email Class Initialized
INFO - 2025-04-02 08:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:28:21 --> Form Validation Class Initialized
INFO - 2025-04-02 08:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:28:21 --> Pagination Class Initialized
INFO - 2025-04-02 08:28:21 --> Controller Class Initialized
DEBUG - 2025-04-02 08:28:21 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:28:21 --> Model Class Initialized
DEBUG - 2025-04-02 08:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:28:21 --> Model Class Initialized
DEBUG - 2025-04-02 08:28:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:28:21 --> Model Class Initialized
INFO - 2025-04-02 08:28:21 --> Final output sent to browser
DEBUG - 2025-04-02 08:28:21 --> Total execution time: 0.0132
INFO - 2025-04-02 08:28:24 --> Config Class Initialized
INFO - 2025-04-02 08:28:24 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:28:24 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:28:24 --> Utf8 Class Initialized
INFO - 2025-04-02 08:28:24 --> URI Class Initialized
DEBUG - 2025-04-02 08:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:28:24 --> Router Class Initialized
INFO - 2025-04-02 08:28:24 --> Output Class Initialized
INFO - 2025-04-02 08:28:24 --> Security Class Initialized
DEBUG - 2025-04-02 08:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:28:24 --> Input Class Initialized
INFO - 2025-04-02 08:28:24 --> Language Class Initialized
INFO - 2025-04-02 08:28:24 --> Language Class Initialized
INFO - 2025-04-02 08:28:24 --> Config Class Initialized
INFO - 2025-04-02 08:28:24 --> Loader Class Initialized
INFO - 2025-04-02 08:28:24 --> Helper loaded: url_helper
INFO - 2025-04-02 08:28:24 --> Helper loaded: file_helper
INFO - 2025-04-02 08:28:24 --> Helper loaded: html_helper
INFO - 2025-04-02 08:28:24 --> Helper loaded: form_helper
INFO - 2025-04-02 08:28:24 --> Helper loaded: text_helper
INFO - 2025-04-02 08:28:24 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:28:24 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:28:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:28:24 --> Database Driver Class Initialized
INFO - 2025-04-02 08:28:24 --> Email Class Initialized
INFO - 2025-04-02 08:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:28:24 --> Form Validation Class Initialized
INFO - 2025-04-02 08:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:28:24 --> Pagination Class Initialized
INFO - 2025-04-02 08:28:24 --> Controller Class Initialized
DEBUG - 2025-04-02 08:28:24 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:28:24 --> Model Class Initialized
DEBUG - 2025-04-02 08:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:28:24 --> Model Class Initialized
DEBUG - 2025-04-02 08:28:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:28:24 --> Model Class Initialized
INFO - 2025-04-02 08:28:24 --> Final output sent to browser
DEBUG - 2025-04-02 08:28:24 --> Total execution time: 0.0126
INFO - 2025-04-02 08:29:02 --> Config Class Initialized
INFO - 2025-04-02 08:29:02 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:02 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:02 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:02 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:02 --> Router Class Initialized
INFO - 2025-04-02 08:29:02 --> Output Class Initialized
INFO - 2025-04-02 08:29:02 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:02 --> Input Class Initialized
INFO - 2025-04-02 08:29:02 --> Language Class Initialized
INFO - 2025-04-02 08:29:02 --> Language Class Initialized
INFO - 2025-04-02 08:29:02 --> Config Class Initialized
INFO - 2025-04-02 08:29:02 --> Loader Class Initialized
INFO - 2025-04-02 08:29:02 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:02 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:02 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:02 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:02 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:02 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:02 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:02 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:02 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:02 --> Email Class Initialized
INFO - 2025-04-02 08:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:02 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:02 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:02 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:02 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:02 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:02 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:02 --> Model Class Initialized
INFO - 2025-04-02 08:29:02 --> Upload Class Initialized
INFO - 2025-04-02 08:29:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-02 08:29:02 --> Severity: error --> Exception: Field 'slug' doesn't have a default value /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-04-02 08:29:12 --> Config Class Initialized
INFO - 2025-04-02 08:29:12 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:12 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:12 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:12 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:12 --> Router Class Initialized
INFO - 2025-04-02 08:29:12 --> Output Class Initialized
INFO - 2025-04-02 08:29:12 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:12 --> Input Class Initialized
INFO - 2025-04-02 08:29:12 --> Language Class Initialized
INFO - 2025-04-02 08:29:12 --> Language Class Initialized
INFO - 2025-04-02 08:29:12 --> Config Class Initialized
INFO - 2025-04-02 08:29:12 --> Loader Class Initialized
INFO - 2025-04-02 08:29:12 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:12 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:12 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:12 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:12 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:12 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:12 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:12 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:12 --> Email Class Initialized
INFO - 2025-04-02 08:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:12 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:12 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:12 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:12 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:12 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:12 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:12 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:29:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:29:12 --> Model Class Initialized
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 115
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:12 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:29:12 --> Final output sent to browser
DEBUG - 2025-04-02 08:29:12 --> Total execution time: 0.1844
INFO - 2025-04-02 08:29:15 --> Config Class Initialized
INFO - 2025-04-02 08:29:15 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:15 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:15 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:15 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:15 --> Router Class Initialized
INFO - 2025-04-02 08:29:15 --> Output Class Initialized
INFO - 2025-04-02 08:29:15 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:15 --> Input Class Initialized
INFO - 2025-04-02 08:29:15 --> Language Class Initialized
INFO - 2025-04-02 08:29:15 --> Language Class Initialized
INFO - 2025-04-02 08:29:15 --> Config Class Initialized
INFO - 2025-04-02 08:29:15 --> Loader Class Initialized
INFO - 2025-04-02 08:29:15 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:15 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:15 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:15 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:15 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:15 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:15 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:15 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:15 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:15 --> Email Class Initialized
INFO - 2025-04-02 08:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:15 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:15 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:15 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:15 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:15 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:15 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:15 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:29:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:29:15 --> Model Class Initialized
ERROR - 2025-04-02 08:29:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:29:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:29:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:29:15 --> Final output sent to browser
DEBUG - 2025-04-02 08:29:15 --> Total execution time: 0.1668
INFO - 2025-04-02 08:29:16 --> Config Class Initialized
INFO - 2025-04-02 08:29:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:16 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:16 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:16 --> Router Class Initialized
INFO - 2025-04-02 08:29:16 --> Output Class Initialized
INFO - 2025-04-02 08:29:16 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:16 --> Input Class Initialized
INFO - 2025-04-02 08:29:16 --> Language Class Initialized
INFO - 2025-04-02 08:29:16 --> Language Class Initialized
INFO - 2025-04-02 08:29:16 --> Config Class Initialized
INFO - 2025-04-02 08:29:16 --> Loader Class Initialized
INFO - 2025-04-02 08:29:16 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:16 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:16 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:16 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:16 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:16 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:16 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:16 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:16 --> Email Class Initialized
INFO - 2025-04-02 08:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:16 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:16 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:16 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:16 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:16 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:16 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:16 --> Model Class Initialized
ERROR - 2025-04-02 08:29:16 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 6
    [iTotalDisplayRecords] => 6
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/34769578">Test Product</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/"></a>
                    [price] => 200
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-02/c19c9bec0db94a53a3cbe5c4adce6cc7.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/34769578" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/34769578" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/34769578" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/34769578" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/cd23e47393890cd08fe0269c490e4dec.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [5] => Array
                (
                    [sl] => 6
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-04-02 08:29:16 --> Final output sent to browser
DEBUG - 2025-04-02 08:29:16 --> Total execution time: 0.0079
INFO - 2025-04-02 08:29:28 --> Config Class Initialized
INFO - 2025-04-02 08:29:28 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:28 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:28 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:28 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:28 --> Router Class Initialized
INFO - 2025-04-02 08:29:28 --> Output Class Initialized
INFO - 2025-04-02 08:29:28 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:28 --> Input Class Initialized
INFO - 2025-04-02 08:29:28 --> Language Class Initialized
INFO - 2025-04-02 08:29:28 --> Language Class Initialized
INFO - 2025-04-02 08:29:28 --> Config Class Initialized
INFO - 2025-04-02 08:29:28 --> Loader Class Initialized
INFO - 2025-04-02 08:29:28 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:28 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:28 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:28 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:28 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:28 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:28 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:28 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:28 --> Email Class Initialized
INFO - 2025-04-02 08:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:28 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:28 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:28 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:28 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:28 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:28 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:28 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:29:28 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:29:28 --> Model Class Initialized
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:29:28 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:29:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:29:28 --> Final output sent to browser
DEBUG - 2025-04-02 08:29:28 --> Total execution time: 0.1930
INFO - 2025-04-02 08:29:36 --> Config Class Initialized
INFO - 2025-04-02 08:29:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:36 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:36 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:36 --> Router Class Initialized
INFO - 2025-04-02 08:29:36 --> Output Class Initialized
INFO - 2025-04-02 08:29:36 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:36 --> Input Class Initialized
INFO - 2025-04-02 08:29:36 --> Language Class Initialized
INFO - 2025-04-02 08:29:36 --> Language Class Initialized
INFO - 2025-04-02 08:29:36 --> Config Class Initialized
INFO - 2025-04-02 08:29:36 --> Loader Class Initialized
INFO - 2025-04-02 08:29:36 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:36 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:36 --> Email Class Initialized
INFO - 2025-04-02 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:36 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:36 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:36 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:36 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
INFO - 2025-04-02 08:29:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-02 08:29:36 --> Config Class Initialized
INFO - 2025-04-02 08:29:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:36 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:36 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:36 --> Router Class Initialized
INFO - 2025-04-02 08:29:36 --> Output Class Initialized
INFO - 2025-04-02 08:29:36 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:36 --> Input Class Initialized
INFO - 2025-04-02 08:29:36 --> Language Class Initialized
INFO - 2025-04-02 08:29:36 --> Language Class Initialized
INFO - 2025-04-02 08:29:36 --> Config Class Initialized
INFO - 2025-04-02 08:29:36 --> Loader Class Initialized
INFO - 2025-04-02 08:29:36 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:36 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:36 --> Email Class Initialized
INFO - 2025-04-02 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:36 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:36 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:36 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:36 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:29:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
ERROR - 2025-04-02 08:29:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:29:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:29:36 --> Final output sent to browser
DEBUG - 2025-04-02 08:29:36 --> Total execution time: 0.0901
INFO - 2025-04-02 08:29:36 --> Config Class Initialized
INFO - 2025-04-02 08:29:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:36 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:36 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:29:36 --> Router Class Initialized
INFO - 2025-04-02 08:29:36 --> Output Class Initialized
INFO - 2025-04-02 08:29:36 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:36 --> Input Class Initialized
INFO - 2025-04-02 08:29:36 --> Language Class Initialized
INFO - 2025-04-02 08:29:36 --> Language Class Initialized
INFO - 2025-04-02 08:29:36 --> Config Class Initialized
INFO - 2025-04-02 08:29:36 --> Loader Class Initialized
INFO - 2025-04-02 08:29:36 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:36 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:36 --> Email Class Initialized
INFO - 2025-04-02 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:36 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:36 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:36 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:36 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:29:36 --> Model Class Initialized
ERROR - 2025-04-02 08:29:36 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 6
    [iTotalDisplayRecords] => 6
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/34769578">Test Product</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 200
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-02/c19c9bec0db94a53a3cbe5c4adce6cc7.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/34769578" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/34769578" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/34769578" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/34769578" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/cd23e47393890cd08fe0269c490e4dec.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [5] => Array
                (
                    [sl] => 6
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-04-02 08:29:36 --> Final output sent to browser
DEBUG - 2025-04-02 08:29:36 --> Total execution time: 0.0048
INFO - 2025-04-02 08:29:52 --> Config Class Initialized
INFO - 2025-04-02 08:29:52 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:29:52 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:29:52 --> Utf8 Class Initialized
INFO - 2025-04-02 08:29:52 --> URI Class Initialized
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-02 08:29:52 --> Router Class Initialized
INFO - 2025-04-02 08:29:52 --> Output Class Initialized
INFO - 2025-04-02 08:29:52 --> Security Class Initialized
DEBUG - 2025-04-02 08:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:29:52 --> Input Class Initialized
INFO - 2025-04-02 08:29:52 --> Language Class Initialized
INFO - 2025-04-02 08:29:52 --> Language Class Initialized
INFO - 2025-04-02 08:29:52 --> Config Class Initialized
INFO - 2025-04-02 08:29:52 --> Loader Class Initialized
INFO - 2025-04-02 08:29:52 --> Helper loaded: url_helper
INFO - 2025-04-02 08:29:52 --> Helper loaded: file_helper
INFO - 2025-04-02 08:29:52 --> Helper loaded: html_helper
INFO - 2025-04-02 08:29:52 --> Helper loaded: form_helper
INFO - 2025-04-02 08:29:52 --> Helper loaded: text_helper
INFO - 2025-04-02 08:29:52 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:29:52 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:29:52 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:29:52 --> Database Driver Class Initialized
INFO - 2025-04-02 08:29:52 --> Email Class Initialized
INFO - 2025-04-02 08:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:29:52 --> Form Validation Class Initialized
INFO - 2025-04-02 08:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:29:52 --> Pagination Class Initialized
INFO - 2025-04-02 08:29:52 --> Controller Class Initialized
DEBUG - 2025-04-02 08:29:52 --> Purchase MX_Controller Initialized
INFO - 2025-04-02 08:29:52 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-02 08:29:52 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 08:29:52 --> Model Class Initialized
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:29:52 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:29:52 --> Model Class Initialized
ERROR - 2025-04-02 08:29:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:29:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:29:52 --> Final output sent to browser
DEBUG - 2025-04-02 08:29:52 --> Total execution time: 0.1992
INFO - 2025-04-02 08:30:10 --> Config Class Initialized
INFO - 2025-04-02 08:30:10 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:30:10 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:30:10 --> Utf8 Class Initialized
INFO - 2025-04-02 08:30:10 --> URI Class Initialized
DEBUG - 2025-04-02 08:30:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-02 08:30:10 --> Router Class Initialized
INFO - 2025-04-02 08:30:10 --> Output Class Initialized
INFO - 2025-04-02 08:30:10 --> Security Class Initialized
DEBUG - 2025-04-02 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:30:10 --> Input Class Initialized
INFO - 2025-04-02 08:30:10 --> Language Class Initialized
INFO - 2025-04-02 08:30:10 --> Language Class Initialized
INFO - 2025-04-02 08:30:10 --> Config Class Initialized
INFO - 2025-04-02 08:30:10 --> Loader Class Initialized
INFO - 2025-04-02 08:30:10 --> Helper loaded: url_helper
INFO - 2025-04-02 08:30:10 --> Helper loaded: file_helper
INFO - 2025-04-02 08:30:10 --> Helper loaded: html_helper
INFO - 2025-04-02 08:30:10 --> Helper loaded: form_helper
INFO - 2025-04-02 08:30:10 --> Helper loaded: text_helper
INFO - 2025-04-02 08:30:10 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:30:10 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:30:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:30:10 --> Database Driver Class Initialized
INFO - 2025-04-02 08:30:10 --> Email Class Initialized
INFO - 2025-04-02 08:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:30:10 --> Form Validation Class Initialized
INFO - 2025-04-02 08:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:30:10 --> Pagination Class Initialized
INFO - 2025-04-02 08:30:10 --> Controller Class Initialized
DEBUG - 2025-04-02 08:30:10 --> Purchase MX_Controller Initialized
INFO - 2025-04-02 08:30:10 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-02 08:30:10 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 08:30:10 --> Model Class Initialized
INFO - 2025-04-02 08:30:10 --> Final output sent to browser
DEBUG - 2025-04-02 08:30:10 --> Total execution time: 0.0124
INFO - 2025-04-02 08:30:11 --> Config Class Initialized
INFO - 2025-04-02 08:30:11 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:30:11 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:30:11 --> Utf8 Class Initialized
INFO - 2025-04-02 08:30:11 --> URI Class Initialized
DEBUG - 2025-04-02 08:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-02 08:30:11 --> Router Class Initialized
INFO - 2025-04-02 08:30:11 --> Output Class Initialized
INFO - 2025-04-02 08:30:11 --> Security Class Initialized
DEBUG - 2025-04-02 08:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:30:11 --> Input Class Initialized
INFO - 2025-04-02 08:30:11 --> Language Class Initialized
INFO - 2025-04-02 08:30:11 --> Language Class Initialized
INFO - 2025-04-02 08:30:11 --> Config Class Initialized
INFO - 2025-04-02 08:30:11 --> Loader Class Initialized
INFO - 2025-04-02 08:30:11 --> Helper loaded: url_helper
INFO - 2025-04-02 08:30:11 --> Helper loaded: file_helper
INFO - 2025-04-02 08:30:11 --> Helper loaded: html_helper
INFO - 2025-04-02 08:30:11 --> Helper loaded: form_helper
INFO - 2025-04-02 08:30:11 --> Helper loaded: text_helper
INFO - 2025-04-02 08:30:11 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:30:11 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:30:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:30:11 --> Database Driver Class Initialized
INFO - 2025-04-02 08:30:11 --> Email Class Initialized
INFO - 2025-04-02 08:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:30:11 --> Form Validation Class Initialized
INFO - 2025-04-02 08:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:30:11 --> Pagination Class Initialized
INFO - 2025-04-02 08:30:11 --> Controller Class Initialized
DEBUG - 2025-04-02 08:30:11 --> Purchase MX_Controller Initialized
INFO - 2025-04-02 08:30:11 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-02 08:30:11 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 08:30:11 --> Model Class Initialized
INFO - 2025-04-02 08:30:11 --> Final output sent to browser
DEBUG - 2025-04-02 08:30:11 --> Total execution time: 0.0079
INFO - 2025-04-02 08:30:47 --> Config Class Initialized
INFO - 2025-04-02 08:30:47 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:30:47 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:30:47 --> Utf8 Class Initialized
INFO - 2025-04-02 08:30:47 --> URI Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-02 08:30:47 --> Router Class Initialized
INFO - 2025-04-02 08:30:47 --> Output Class Initialized
INFO - 2025-04-02 08:30:47 --> Security Class Initialized
DEBUG - 2025-04-02 08:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:30:47 --> Input Class Initialized
INFO - 2025-04-02 08:30:47 --> Language Class Initialized
INFO - 2025-04-02 08:30:47 --> Language Class Initialized
INFO - 2025-04-02 08:30:47 --> Config Class Initialized
INFO - 2025-04-02 08:30:47 --> Loader Class Initialized
INFO - 2025-04-02 08:30:47 --> Helper loaded: url_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: file_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: html_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: form_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: text_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:30:47 --> Database Driver Class Initialized
INFO - 2025-04-02 08:30:47 --> Email Class Initialized
INFO - 2025-04-02 08:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:30:47 --> Form Validation Class Initialized
INFO - 2025-04-02 08:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:30:47 --> Pagination Class Initialized
INFO - 2025-04-02 08:30:47 --> Controller Class Initialized
DEBUG - 2025-04-02 08:30:47 --> Purchase MX_Controller Initialized
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
INFO - 2025-04-02 08:30:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-02 08:30:47 --> Config Class Initialized
INFO - 2025-04-02 08:30:47 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:30:47 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:30:47 --> Utf8 Class Initialized
INFO - 2025-04-02 08:30:47 --> URI Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-02 08:30:47 --> Router Class Initialized
INFO - 2025-04-02 08:30:47 --> Output Class Initialized
INFO - 2025-04-02 08:30:47 --> Security Class Initialized
DEBUG - 2025-04-02 08:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:30:47 --> Input Class Initialized
INFO - 2025-04-02 08:30:47 --> Language Class Initialized
INFO - 2025-04-02 08:30:47 --> Language Class Initialized
INFO - 2025-04-02 08:30:47 --> Config Class Initialized
INFO - 2025-04-02 08:30:47 --> Loader Class Initialized
INFO - 2025-04-02 08:30:47 --> Helper loaded: url_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: file_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: html_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: form_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: text_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:30:47 --> Database Driver Class Initialized
INFO - 2025-04-02 08:30:47 --> Email Class Initialized
INFO - 2025-04-02 08:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:30:47 --> Form Validation Class Initialized
INFO - 2025-04-02 08:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:30:47 --> Pagination Class Initialized
INFO - 2025-04-02 08:30:47 --> Controller Class Initialized
DEBUG - 2025-04-02 08:30:47 --> Purchase MX_Controller Initialized
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:30:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
ERROR - 2025-04-02 08:30:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:30:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/purchase.php
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:30:47 --> Final output sent to browser
DEBUG - 2025-04-02 08:30:47 --> Total execution time: 0.1313
INFO - 2025-04-02 08:30:47 --> Config Class Initialized
INFO - 2025-04-02 08:30:47 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:30:47 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:30:47 --> Utf8 Class Initialized
INFO - 2025-04-02 08:30:47 --> URI Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-04-02 08:30:47 --> Router Class Initialized
INFO - 2025-04-02 08:30:47 --> Output Class Initialized
INFO - 2025-04-02 08:30:47 --> Security Class Initialized
DEBUG - 2025-04-02 08:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:30:47 --> Input Class Initialized
INFO - 2025-04-02 08:30:47 --> Language Class Initialized
INFO - 2025-04-02 08:30:47 --> Language Class Initialized
INFO - 2025-04-02 08:30:47 --> Config Class Initialized
INFO - 2025-04-02 08:30:47 --> Loader Class Initialized
INFO - 2025-04-02 08:30:47 --> Helper loaded: url_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: file_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: html_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: form_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: text_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:30:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:30:47 --> Database Driver Class Initialized
INFO - 2025-04-02 08:30:47 --> Email Class Initialized
INFO - 2025-04-02 08:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:30:47 --> Form Validation Class Initialized
INFO - 2025-04-02 08:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:30:47 --> Pagination Class Initialized
INFO - 2025-04-02 08:30:47 --> Controller Class Initialized
DEBUG - 2025-04-02 08:30:47 --> Purchase MX_Controller Initialized
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
DEBUG - 2025-04-02 08:30:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 08:30:47 --> Model Class Initialized
INFO - 2025-04-02 08:30:47 --> Final output sent to browser
DEBUG - 2025-04-02 08:30:47 --> Total execution time: 0.0325
INFO - 2025-04-02 08:30:54 --> Config Class Initialized
INFO - 2025-04-02 08:30:54 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:30:54 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:30:54 --> Utf8 Class Initialized
INFO - 2025-04-02 08:30:54 --> URI Class Initialized
DEBUG - 2025-04-02 08:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:30:54 --> Router Class Initialized
INFO - 2025-04-02 08:30:54 --> Output Class Initialized
INFO - 2025-04-02 08:30:54 --> Security Class Initialized
DEBUG - 2025-04-02 08:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:30:54 --> Input Class Initialized
INFO - 2025-04-02 08:30:54 --> Language Class Initialized
INFO - 2025-04-02 08:30:54 --> Language Class Initialized
INFO - 2025-04-02 08:30:54 --> Config Class Initialized
INFO - 2025-04-02 08:30:54 --> Loader Class Initialized
INFO - 2025-04-02 08:30:54 --> Helper loaded: url_helper
INFO - 2025-04-02 08:30:54 --> Helper loaded: file_helper
INFO - 2025-04-02 08:30:54 --> Helper loaded: html_helper
INFO - 2025-04-02 08:30:54 --> Helper loaded: form_helper
INFO - 2025-04-02 08:30:54 --> Helper loaded: text_helper
INFO - 2025-04-02 08:30:54 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:30:54 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:30:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:30:54 --> Database Driver Class Initialized
INFO - 2025-04-02 08:30:54 --> Email Class Initialized
INFO - 2025-04-02 08:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:30:54 --> Form Validation Class Initialized
INFO - 2025-04-02 08:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:30:54 --> Pagination Class Initialized
INFO - 2025-04-02 08:30:54 --> Controller Class Initialized
DEBUG - 2025-04-02 08:30:54 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:30:54 --> Model Class Initialized
DEBUG - 2025-04-02 14:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:30:54 --> Model Class Initialized
DEBUG - 2025-04-02 14:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:30:54 --> Model Class Initialized
DEBUG - 2025-04-02 14:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:30:54 --> Model Class Initialized
ERROR - 2025-04-02 14:30:54 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:30:54 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:30:54 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-02 14:30:54 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-02 14:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 14:30:54 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 14:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 14:30:54 --> Model Class Initialized
ERROR - 2025-04-02 14:30:54 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 14:30:54 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 14:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 14:30:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 14:30:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 14:30:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 14:30:55 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-02 14:30:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-02 14:30:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 14:30:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 14:30:55 --> Final output sent to browser
DEBUG - 2025-04-02 14:30:55 --> Total execution time: 0.2256
INFO - 2025-04-02 08:30:59 --> Config Class Initialized
INFO - 2025-04-02 08:30:59 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:30:59 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:30:59 --> Utf8 Class Initialized
INFO - 2025-04-02 08:30:59 --> URI Class Initialized
DEBUG - 2025-04-02 08:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:30:59 --> Router Class Initialized
INFO - 2025-04-02 08:30:59 --> Output Class Initialized
INFO - 2025-04-02 08:30:59 --> Security Class Initialized
DEBUG - 2025-04-02 08:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:30:59 --> Input Class Initialized
INFO - 2025-04-02 08:30:59 --> Language Class Initialized
INFO - 2025-04-02 08:30:59 --> Language Class Initialized
INFO - 2025-04-02 08:30:59 --> Config Class Initialized
INFO - 2025-04-02 08:30:59 --> Loader Class Initialized
INFO - 2025-04-02 08:30:59 --> Helper loaded: url_helper
INFO - 2025-04-02 08:30:59 --> Helper loaded: file_helper
INFO - 2025-04-02 08:30:59 --> Helper loaded: html_helper
INFO - 2025-04-02 08:30:59 --> Helper loaded: form_helper
INFO - 2025-04-02 08:30:59 --> Helper loaded: text_helper
INFO - 2025-04-02 08:30:59 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:30:59 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:30:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:30:59 --> Database Driver Class Initialized
INFO - 2025-04-02 08:30:59 --> Email Class Initialized
INFO - 2025-04-02 08:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:30:59 --> Form Validation Class Initialized
INFO - 2025-04-02 08:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:30:59 --> Pagination Class Initialized
INFO - 2025-04-02 08:30:59 --> Controller Class Initialized
DEBUG - 2025-04-02 08:30:59 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:30:59 --> Model Class Initialized
DEBUG - 2025-04-02 14:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:30:59 --> Model Class Initialized
DEBUG - 2025-04-02 14:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:30:59 --> Model Class Initialized
DEBUG - 2025-04-02 14:30:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:30:59 --> Model Class Initialized
INFO - 2025-04-02 14:30:59 --> Final output sent to browser
DEBUG - 2025-04-02 14:30:59 --> Total execution time: 0.0134
INFO - 2025-04-02 08:31:00 --> Config Class Initialized
INFO - 2025-04-02 08:31:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:00 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:00 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:00 --> Router Class Initialized
INFO - 2025-04-02 08:31:00 --> Output Class Initialized
INFO - 2025-04-02 08:31:00 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:00 --> Input Class Initialized
INFO - 2025-04-02 08:31:00 --> Language Class Initialized
INFO - 2025-04-02 08:31:00 --> Language Class Initialized
INFO - 2025-04-02 08:31:00 --> Config Class Initialized
INFO - 2025-04-02 08:31:00 --> Loader Class Initialized
INFO - 2025-04-02 08:31:00 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:00 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:00 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:00 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:00 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:00 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:00 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:00 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:00 --> Email Class Initialized
INFO - 2025-04-02 08:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:00 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:00 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:00 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:00 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:00 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:00 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:00 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:00 --> Model Class Initialized
INFO - 2025-04-02 14:31:00 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:00 --> Total execution time: 0.0119
INFO - 2025-04-02 08:31:05 --> Config Class Initialized
INFO - 2025-04-02 08:31:05 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:05 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:05 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:05 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:05 --> Router Class Initialized
INFO - 2025-04-02 08:31:05 --> Output Class Initialized
INFO - 2025-04-02 08:31:05 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:05 --> Input Class Initialized
INFO - 2025-04-02 08:31:05 --> Language Class Initialized
INFO - 2025-04-02 08:31:05 --> Language Class Initialized
INFO - 2025-04-02 08:31:05 --> Config Class Initialized
INFO - 2025-04-02 08:31:05 --> Loader Class Initialized
INFO - 2025-04-02 08:31:05 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:05 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:05 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:05 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:05 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:05 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:05 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:05 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:05 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:05 --> Email Class Initialized
INFO - 2025-04-02 08:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:05 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:05 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:05 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:05 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:05 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:05 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:05 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:05 --> Model Class Initialized
INFO - 2025-04-02 14:31:05 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:05 --> Total execution time: 0.0137
INFO - 2025-04-02 08:31:07 --> Config Class Initialized
INFO - 2025-04-02 08:31:07 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:07 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:07 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:07 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:07 --> Router Class Initialized
INFO - 2025-04-02 08:31:07 --> Output Class Initialized
INFO - 2025-04-02 08:31:07 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:07 --> Input Class Initialized
INFO - 2025-04-02 08:31:07 --> Language Class Initialized
INFO - 2025-04-02 08:31:07 --> Language Class Initialized
INFO - 2025-04-02 08:31:07 --> Config Class Initialized
INFO - 2025-04-02 08:31:07 --> Loader Class Initialized
INFO - 2025-04-02 08:31:07 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:07 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:07 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:07 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:07 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:07 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:07 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:07 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:07 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:07 --> Email Class Initialized
INFO - 2025-04-02 08:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:07 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:07 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:07 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:07 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:07 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:07 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:07 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:07 --> Model Class Initialized
INFO - 2025-04-02 14:31:07 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:07 --> Total execution time: 0.0138
INFO - 2025-04-02 08:31:11 --> Config Class Initialized
INFO - 2025-04-02 08:31:11 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:11 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:11 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:11 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:11 --> Router Class Initialized
INFO - 2025-04-02 08:31:11 --> Output Class Initialized
INFO - 2025-04-02 08:31:11 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:11 --> Input Class Initialized
INFO - 2025-04-02 08:31:11 --> Language Class Initialized
INFO - 2025-04-02 08:31:11 --> Language Class Initialized
INFO - 2025-04-02 08:31:11 --> Config Class Initialized
INFO - 2025-04-02 08:31:11 --> Loader Class Initialized
INFO - 2025-04-02 08:31:11 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:11 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:11 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:11 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:11 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:11 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:11 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:11 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:11 --> Email Class Initialized
INFO - 2025-04-02 08:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:11 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:11 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:11 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:11 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:11 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:11 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:11 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:11 --> Model Class Initialized
INFO - 2025-04-02 14:31:11 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:11 --> Total execution time: 0.0147
INFO - 2025-04-02 08:31:12 --> Config Class Initialized
INFO - 2025-04-02 08:31:12 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:12 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:12 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:12 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:12 --> Router Class Initialized
INFO - 2025-04-02 08:31:12 --> Output Class Initialized
INFO - 2025-04-02 08:31:12 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:12 --> Input Class Initialized
INFO - 2025-04-02 08:31:12 --> Language Class Initialized
INFO - 2025-04-02 08:31:12 --> Language Class Initialized
INFO - 2025-04-02 08:31:12 --> Config Class Initialized
INFO - 2025-04-02 08:31:12 --> Loader Class Initialized
INFO - 2025-04-02 08:31:12 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:12 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:12 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:12 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:12 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:12 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:12 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:12 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:12 --> Email Class Initialized
INFO - 2025-04-02 08:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:12 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:12 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:12 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:12 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:12 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:12 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:12 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:12 --> Model Class Initialized
INFO - 2025-04-02 14:31:12 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:12 --> Total execution time: 0.0231
INFO - 2025-04-02 08:31:14 --> Config Class Initialized
INFO - 2025-04-02 08:31:14 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:14 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:14 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:14 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:14 --> Router Class Initialized
INFO - 2025-04-02 08:31:14 --> Output Class Initialized
INFO - 2025-04-02 08:31:14 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:14 --> Input Class Initialized
INFO - 2025-04-02 08:31:14 --> Language Class Initialized
INFO - 2025-04-02 08:31:14 --> Language Class Initialized
INFO - 2025-04-02 08:31:14 --> Config Class Initialized
INFO - 2025-04-02 08:31:14 --> Loader Class Initialized
INFO - 2025-04-02 08:31:14 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:14 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:14 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:14 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:14 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:14 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:14 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:14 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:14 --> Email Class Initialized
INFO - 2025-04-02 08:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:14 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:14 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:14 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:14 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:14 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:14 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:14 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:14 --> Model Class Initialized
INFO - 2025-04-02 14:31:14 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:14 --> Total execution time: 0.0120
INFO - 2025-04-02 08:31:48 --> Config Class Initialized
INFO - 2025-04-02 08:31:48 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:48 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:48 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:48 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:48 --> Router Class Initialized
INFO - 2025-04-02 08:31:48 --> Output Class Initialized
INFO - 2025-04-02 08:31:48 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:48 --> Input Class Initialized
INFO - 2025-04-02 08:31:48 --> Language Class Initialized
INFO - 2025-04-02 08:31:48 --> Language Class Initialized
INFO - 2025-04-02 08:31:48 --> Config Class Initialized
INFO - 2025-04-02 08:31:48 --> Loader Class Initialized
INFO - 2025-04-02 08:31:48 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:48 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:48 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:48 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:48 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:48 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:48 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:48 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:48 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:48 --> Email Class Initialized
INFO - 2025-04-02 08:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:48 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:48 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:48 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:48 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:48 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:48 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:48 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:48 --> Model Class Initialized
INFO - 2025-04-02 14:31:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-02 14:31:48 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
DEBUG - 2025-04-02 14:31:48 --> 📥 acc_transaction insert: {"vid":"159","fyear":"1","VNo":"CV-45","Vtype":"CV","referenceNo":"1090","VDate":"2025-04-02","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"2000.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:31:48"}
DEBUG - 2025-04-02 14:31:48 --> 📥 acc_transaction insert: {"vid":"159","fyear":"1","VNo":"CV-45","Vtype":"CV","referenceNo":"1090","VDate":"2025-04-02","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"2000.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:31:48"}
DEBUG - 2025-04-02 14:31:48 --> 📥 acc_transaction insert: {"vid":"160","fyear":"1","VNo":"JV-65","Vtype":"JV","referenceNo":"1090","VDate":"2025-04-02","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"900.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:31:48"}
DEBUG - 2025-04-02 14:31:48 --> 📥 acc_transaction insert: {"vid":"160","fyear":"1","VNo":"JV-65","Vtype":"JV","referenceNo":"1090","VDate":"2025-04-02","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"900.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:31:48"}
DEBUG - 2025-04-02 14:31:48 --> 📥 acc_transaction insert: {"vid":"161","fyear":"1","VNo":"JV-66","Vtype":"JV","referenceNo":"1090","VDate":"2025-04-02","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:31:48"}
DEBUG - 2025-04-02 14:31:48 --> 📥 acc_transaction insert: {"vid":"161","fyear":"1","VNo":"JV-66","Vtype":"JV","referenceNo":"1090","VDate":"2025-04-02","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:31:48"}
DEBUG - 2025-04-02 14:31:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-02 14:31:48 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:48 --> Total execution time: 0.1294
INFO - 2025-04-02 08:31:53 --> Config Class Initialized
INFO - 2025-04-02 08:31:53 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:53 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:53 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:53 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:53 --> Router Class Initialized
INFO - 2025-04-02 08:31:53 --> Output Class Initialized
INFO - 2025-04-02 08:31:53 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:53 --> Input Class Initialized
INFO - 2025-04-02 08:31:53 --> Language Class Initialized
INFO - 2025-04-02 08:31:53 --> Language Class Initialized
INFO - 2025-04-02 08:31:53 --> Config Class Initialized
INFO - 2025-04-02 08:31:53 --> Loader Class Initialized
INFO - 2025-04-02 08:31:53 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:53 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:53 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:53 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:53 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:53 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:53 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:53 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:53 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:53 --> Email Class Initialized
INFO - 2025-04-02 08:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:53 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:53 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:53 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:53 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:53 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:53 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:53 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:53 --> Model Class Initialized
ERROR - 2025-04-02 14:31:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:31:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:31:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-02 14:31:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-02 14:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 14:31:53 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 14:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 14:31:53 --> Model Class Initialized
ERROR - 2025-04-02 14:31:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 14:31:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 14:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 14:31:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 14:31:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 14:31:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 14:31:54 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-02 14:31:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-02 14:31:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 14:31:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 14:31:54 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:54 --> Total execution time: 0.1505
INFO - 2025-04-02 08:31:59 --> Config Class Initialized
INFO - 2025-04-02 08:31:59 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:31:59 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:31:59 --> Utf8 Class Initialized
INFO - 2025-04-02 08:31:59 --> URI Class Initialized
DEBUG - 2025-04-02 08:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:31:59 --> Router Class Initialized
INFO - 2025-04-02 08:31:59 --> Output Class Initialized
INFO - 2025-04-02 08:31:59 --> Security Class Initialized
DEBUG - 2025-04-02 08:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:31:59 --> Input Class Initialized
INFO - 2025-04-02 08:31:59 --> Language Class Initialized
INFO - 2025-04-02 08:31:59 --> Language Class Initialized
INFO - 2025-04-02 08:31:59 --> Config Class Initialized
INFO - 2025-04-02 08:31:59 --> Loader Class Initialized
INFO - 2025-04-02 08:31:59 --> Helper loaded: url_helper
INFO - 2025-04-02 08:31:59 --> Helper loaded: file_helper
INFO - 2025-04-02 08:31:59 --> Helper loaded: html_helper
INFO - 2025-04-02 08:31:59 --> Helper loaded: form_helper
INFO - 2025-04-02 08:31:59 --> Helper loaded: text_helper
INFO - 2025-04-02 08:31:59 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:31:59 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:31:59 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:31:59 --> Database Driver Class Initialized
INFO - 2025-04-02 08:31:59 --> Email Class Initialized
INFO - 2025-04-02 08:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:31:59 --> Form Validation Class Initialized
INFO - 2025-04-02 08:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:31:59 --> Pagination Class Initialized
INFO - 2025-04-02 08:31:59 --> Controller Class Initialized
DEBUG - 2025-04-02 08:31:59 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:31:59 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:31:59 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:31:59 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:31:59 --> Model Class Initialized
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 14:31:59 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 14:31:59 --> Model Class Initialized
ERROR - 2025-04-02 14:31:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 14:31:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 14:31:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 14:31:59 --> Final output sent to browser
DEBUG - 2025-04-02 14:31:59 --> Total execution time: 0.0973
INFO - 2025-04-02 08:32:00 --> Config Class Initialized
INFO - 2025-04-02 08:32:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:32:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:32:00 --> Utf8 Class Initialized
INFO - 2025-04-02 08:32:00 --> URI Class Initialized
DEBUG - 2025-04-02 08:32:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:32:00 --> Router Class Initialized
INFO - 2025-04-02 08:32:00 --> Output Class Initialized
INFO - 2025-04-02 08:32:00 --> Security Class Initialized
DEBUG - 2025-04-02 08:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:32:00 --> Input Class Initialized
INFO - 2025-04-02 08:32:00 --> Language Class Initialized
INFO - 2025-04-02 08:32:00 --> Language Class Initialized
INFO - 2025-04-02 08:32:00 --> Config Class Initialized
INFO - 2025-04-02 08:32:00 --> Loader Class Initialized
INFO - 2025-04-02 08:32:00 --> Helper loaded: url_helper
INFO - 2025-04-02 08:32:00 --> Helper loaded: file_helper
INFO - 2025-04-02 08:32:00 --> Helper loaded: html_helper
INFO - 2025-04-02 08:32:00 --> Helper loaded: form_helper
INFO - 2025-04-02 08:32:00 --> Helper loaded: text_helper
INFO - 2025-04-02 08:32:00 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:32:00 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:32:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:32:00 --> Database Driver Class Initialized
INFO - 2025-04-02 08:32:00 --> Email Class Initialized
INFO - 2025-04-02 08:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:32:00 --> Form Validation Class Initialized
INFO - 2025-04-02 08:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:32:00 --> Pagination Class Initialized
INFO - 2025-04-02 08:32:00 --> Controller Class Initialized
DEBUG - 2025-04-02 08:32:00 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:32:00 --> Model Class Initialized
DEBUG - 2025-04-02 14:32:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:32:00 --> Model Class Initialized
DEBUG - 2025-04-02 14:32:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:32:00 --> Model Class Initialized
DEBUG - 2025-04-02 14:32:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:32:00 --> Model Class Initialized
INFO - 2025-04-02 14:32:00 --> Final output sent to browser
DEBUG - 2025-04-02 14:32:00 --> Total execution time: 0.0358
INFO - 2025-04-02 08:32:03 --> Config Class Initialized
INFO - 2025-04-02 08:32:03 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:32:03 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:32:03 --> Utf8 Class Initialized
INFO - 2025-04-02 08:32:03 --> URI Class Initialized
DEBUG - 2025-04-02 08:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:32:03 --> Router Class Initialized
INFO - 2025-04-02 08:32:03 --> Output Class Initialized
INFO - 2025-04-02 08:32:03 --> Security Class Initialized
DEBUG - 2025-04-02 08:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:32:03 --> Input Class Initialized
INFO - 2025-04-02 08:32:03 --> Language Class Initialized
INFO - 2025-04-02 08:32:03 --> Language Class Initialized
INFO - 2025-04-02 08:32:03 --> Config Class Initialized
INFO - 2025-04-02 08:32:03 --> Loader Class Initialized
INFO - 2025-04-02 08:32:03 --> Helper loaded: url_helper
INFO - 2025-04-02 08:32:03 --> Helper loaded: file_helper
INFO - 2025-04-02 08:32:03 --> Helper loaded: html_helper
INFO - 2025-04-02 08:32:03 --> Helper loaded: form_helper
INFO - 2025-04-02 08:32:03 --> Helper loaded: text_helper
INFO - 2025-04-02 08:32:03 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:32:03 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:32:03 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:32:03 --> Database Driver Class Initialized
INFO - 2025-04-02 08:32:03 --> Email Class Initialized
INFO - 2025-04-02 08:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:32:03 --> Form Validation Class Initialized
INFO - 2025-04-02 08:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:32:03 --> Pagination Class Initialized
INFO - 2025-04-02 08:32:03 --> Controller Class Initialized
DEBUG - 2025-04-02 08:32:03 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:32:03 --> Model Class Initialized
DEBUG - 2025-04-02 14:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:32:03 --> Model Class Initialized
DEBUG - 2025-04-02 14:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:32:03 --> Model Class Initialized
DEBUG - 2025-04-02 14:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:32:03 --> Model Class Initialized
DEBUG - 2025-04-02 14:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 14:32:03 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 14:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 14:32:03 --> Model Class Initialized
ERROR - 2025-04-02 14:32:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 14:32:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 14:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 14:32:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 14:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 14:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 14:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-02 14:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 14:32:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 14:32:04 --> Final output sent to browser
DEBUG - 2025-04-02 14:32:04 --> Total execution time: 0.0972
INFO - 2025-04-02 08:34:10 --> Config Class Initialized
INFO - 2025-04-02 08:34:10 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:10 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:10 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:10 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:10 --> Router Class Initialized
INFO - 2025-04-02 08:34:10 --> Output Class Initialized
INFO - 2025-04-02 08:34:10 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:10 --> Input Class Initialized
INFO - 2025-04-02 08:34:10 --> Language Class Initialized
INFO - 2025-04-02 08:34:10 --> Language Class Initialized
INFO - 2025-04-02 08:34:10 --> Config Class Initialized
INFO - 2025-04-02 08:34:10 --> Loader Class Initialized
INFO - 2025-04-02 08:34:10 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:10 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:10 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:10 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:10 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:10 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:10 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:10 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:10 --> Email Class Initialized
INFO - 2025-04-02 08:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:10 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:10 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:10 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:10 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:10 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:10 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:10 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:10 --> Model Class Initialized
ERROR - 2025-04-02 14:34:10 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:34:10 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:34:10 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-02 14:34:10 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 14:34:10 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 14:34:10 --> Model Class Initialized
ERROR - 2025-04-02 14:34:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 14:34:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 14:34:10 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 14:34:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 14:34:10 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:10 --> Total execution time: 0.1841
INFO - 2025-04-02 08:34:18 --> Config Class Initialized
INFO - 2025-04-02 08:34:18 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:18 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:18 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:18 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:18 --> Router Class Initialized
INFO - 2025-04-02 08:34:18 --> Output Class Initialized
INFO - 2025-04-02 08:34:18 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:18 --> Input Class Initialized
INFO - 2025-04-02 08:34:18 --> Language Class Initialized
INFO - 2025-04-02 08:34:18 --> Language Class Initialized
INFO - 2025-04-02 08:34:18 --> Config Class Initialized
INFO - 2025-04-02 08:34:18 --> Loader Class Initialized
INFO - 2025-04-02 08:34:18 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:18 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:18 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:18 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:18 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:18 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:18 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:18 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:18 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:18 --> Email Class Initialized
INFO - 2025-04-02 08:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:18 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:18 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:18 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:18 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:18 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:18 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:18 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:18 --> Model Class Initialized
INFO - 2025-04-02 14:34:18 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:18 --> Total execution time: 0.0059
INFO - 2025-04-02 08:34:19 --> Config Class Initialized
INFO - 2025-04-02 08:34:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:19 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:19 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:19 --> Router Class Initialized
INFO - 2025-04-02 08:34:19 --> Output Class Initialized
INFO - 2025-04-02 08:34:19 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:19 --> Input Class Initialized
INFO - 2025-04-02 08:34:19 --> Language Class Initialized
INFO - 2025-04-02 08:34:19 --> Language Class Initialized
INFO - 2025-04-02 08:34:19 --> Config Class Initialized
INFO - 2025-04-02 08:34:19 --> Loader Class Initialized
INFO - 2025-04-02 08:34:19 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:19 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:19 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:19 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:19 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:19 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:19 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:19 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:19 --> Email Class Initialized
INFO - 2025-04-02 08:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:19 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:19 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:19 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:19 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:19 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:19 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:19 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:19 --> Model Class Initialized
INFO - 2025-04-02 14:34:19 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:19 --> Total execution time: 0.0156
INFO - 2025-04-02 08:34:22 --> Config Class Initialized
INFO - 2025-04-02 08:34:22 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:22 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:22 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:22 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:22 --> Router Class Initialized
INFO - 2025-04-02 08:34:22 --> Output Class Initialized
INFO - 2025-04-02 08:34:22 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:22 --> Input Class Initialized
INFO - 2025-04-02 08:34:22 --> Language Class Initialized
INFO - 2025-04-02 08:34:22 --> Language Class Initialized
INFO - 2025-04-02 08:34:22 --> Config Class Initialized
INFO - 2025-04-02 08:34:22 --> Loader Class Initialized
INFO - 2025-04-02 08:34:22 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:22 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:22 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:22 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:22 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:22 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:22 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:22 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:22 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:22 --> Email Class Initialized
INFO - 2025-04-02 08:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:22 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:22 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:22 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:22 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:22 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:22 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:22 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:22 --> Model Class Initialized
INFO - 2025-04-02 14:34:22 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:22 --> Total execution time: 0.0140
INFO - 2025-04-02 08:34:23 --> Config Class Initialized
INFO - 2025-04-02 08:34:23 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:23 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:23 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:23 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:23 --> Router Class Initialized
INFO - 2025-04-02 08:34:23 --> Output Class Initialized
INFO - 2025-04-02 08:34:23 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:23 --> Input Class Initialized
INFO - 2025-04-02 08:34:23 --> Language Class Initialized
INFO - 2025-04-02 08:34:23 --> Language Class Initialized
INFO - 2025-04-02 08:34:23 --> Config Class Initialized
INFO - 2025-04-02 08:34:23 --> Loader Class Initialized
INFO - 2025-04-02 08:34:23 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:23 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:23 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:23 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:23 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:23 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:23 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:23 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:23 --> Email Class Initialized
INFO - 2025-04-02 08:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:23 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:23 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:23 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:23 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:23 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:23 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:23 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:23 --> Model Class Initialized
INFO - 2025-04-02 14:34:23 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:23 --> Total execution time: 0.0231
INFO - 2025-04-02 08:34:25 --> Config Class Initialized
INFO - 2025-04-02 08:34:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:25 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:25 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:25 --> Router Class Initialized
INFO - 2025-04-02 08:34:25 --> Output Class Initialized
INFO - 2025-04-02 08:34:25 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:25 --> Input Class Initialized
INFO - 2025-04-02 08:34:25 --> Language Class Initialized
INFO - 2025-04-02 08:34:25 --> Language Class Initialized
INFO - 2025-04-02 08:34:25 --> Config Class Initialized
INFO - 2025-04-02 08:34:25 --> Loader Class Initialized
INFO - 2025-04-02 08:34:25 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:25 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:25 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:25 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:25 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:25 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:25 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:25 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:25 --> Email Class Initialized
INFO - 2025-04-02 08:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:25 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:25 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:25 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:25 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:25 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:25 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:25 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:25 --> Model Class Initialized
INFO - 2025-04-02 14:34:25 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:25 --> Total execution time: 0.0115
INFO - 2025-04-02 08:34:35 --> Config Class Initialized
INFO - 2025-04-02 08:34:35 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:35 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:35 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:35 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:35 --> Router Class Initialized
INFO - 2025-04-02 08:34:35 --> Output Class Initialized
INFO - 2025-04-02 08:34:35 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:35 --> Input Class Initialized
INFO - 2025-04-02 08:34:35 --> Language Class Initialized
INFO - 2025-04-02 08:34:35 --> Language Class Initialized
INFO - 2025-04-02 08:34:35 --> Config Class Initialized
INFO - 2025-04-02 08:34:35 --> Loader Class Initialized
INFO - 2025-04-02 08:34:35 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:35 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:35 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:35 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:35 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:35 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:35 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:35 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:35 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:35 --> Email Class Initialized
INFO - 2025-04-02 08:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:35 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:35 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:35 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:35 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:35 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:35 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:35 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:35 --> Model Class Initialized
INFO - 2025-04-02 14:34:35 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:35 --> Total execution time: 0.0099
INFO - 2025-04-02 08:34:36 --> Config Class Initialized
INFO - 2025-04-02 08:34:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:36 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:36 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:36 --> Router Class Initialized
INFO - 2025-04-02 08:34:36 --> Output Class Initialized
INFO - 2025-04-02 08:34:36 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:36 --> Input Class Initialized
INFO - 2025-04-02 08:34:36 --> Language Class Initialized
INFO - 2025-04-02 08:34:36 --> Language Class Initialized
INFO - 2025-04-02 08:34:36 --> Config Class Initialized
INFO - 2025-04-02 08:34:36 --> Loader Class Initialized
INFO - 2025-04-02 08:34:36 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:36 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:36 --> Email Class Initialized
INFO - 2025-04-02 08:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:36 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:36 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:36 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:36 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
INFO - 2025-04-02 14:34:36 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:36 --> Total execution time: 0.0125
INFO - 2025-04-02 08:34:36 --> Config Class Initialized
INFO - 2025-04-02 08:34:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:36 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:36 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:36 --> Router Class Initialized
INFO - 2025-04-02 08:34:36 --> Output Class Initialized
INFO - 2025-04-02 08:34:36 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:36 --> Input Class Initialized
INFO - 2025-04-02 08:34:36 --> Language Class Initialized
INFO - 2025-04-02 08:34:36 --> Language Class Initialized
INFO - 2025-04-02 08:34:36 --> Config Class Initialized
INFO - 2025-04-02 08:34:36 --> Loader Class Initialized
INFO - 2025-04-02 08:34:36 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:36 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:36 --> Email Class Initialized
INFO - 2025-04-02 08:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:36 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:36 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:36 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:36 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:36 --> Model Class Initialized
INFO - 2025-04-02 14:34:36 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:36 --> Total execution time: 0.0193
INFO - 2025-04-02 08:34:38 --> Config Class Initialized
INFO - 2025-04-02 08:34:38 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:34:38 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:34:38 --> Utf8 Class Initialized
INFO - 2025-04-02 08:34:38 --> URI Class Initialized
DEBUG - 2025-04-02 08:34:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:34:38 --> Router Class Initialized
INFO - 2025-04-02 08:34:38 --> Output Class Initialized
INFO - 2025-04-02 08:34:38 --> Security Class Initialized
DEBUG - 2025-04-02 08:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:34:38 --> Input Class Initialized
INFO - 2025-04-02 08:34:38 --> Language Class Initialized
INFO - 2025-04-02 08:34:38 --> Language Class Initialized
INFO - 2025-04-02 08:34:38 --> Config Class Initialized
INFO - 2025-04-02 08:34:38 --> Loader Class Initialized
INFO - 2025-04-02 08:34:38 --> Helper loaded: url_helper
INFO - 2025-04-02 08:34:38 --> Helper loaded: file_helper
INFO - 2025-04-02 08:34:38 --> Helper loaded: html_helper
INFO - 2025-04-02 08:34:38 --> Helper loaded: form_helper
INFO - 2025-04-02 08:34:38 --> Helper loaded: text_helper
INFO - 2025-04-02 08:34:38 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:34:38 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:34:38 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:34:38 --> Database Driver Class Initialized
INFO - 2025-04-02 08:34:38 --> Email Class Initialized
INFO - 2025-04-02 08:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:34:38 --> Form Validation Class Initialized
INFO - 2025-04-02 08:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:34:38 --> Pagination Class Initialized
INFO - 2025-04-02 08:34:38 --> Controller Class Initialized
DEBUG - 2025-04-02 08:34:38 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:34:38 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:34:38 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:34:38 --> Model Class Initialized
DEBUG - 2025-04-02 14:34:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:34:38 --> Model Class Initialized
INFO - 2025-04-02 14:34:38 --> Final output sent to browser
DEBUG - 2025-04-02 14:34:38 --> Total execution time: 0.0088
INFO - 2025-04-02 08:35:14 --> Config Class Initialized
INFO - 2025-04-02 08:35:14 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:35:14 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:35:14 --> Utf8 Class Initialized
INFO - 2025-04-02 08:35:14 --> URI Class Initialized
DEBUG - 2025-04-02 08:35:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:35:14 --> Router Class Initialized
INFO - 2025-04-02 08:35:14 --> Output Class Initialized
INFO - 2025-04-02 08:35:14 --> Security Class Initialized
DEBUG - 2025-04-02 08:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:35:14 --> Input Class Initialized
INFO - 2025-04-02 08:35:14 --> Language Class Initialized
INFO - 2025-04-02 08:35:14 --> Language Class Initialized
INFO - 2025-04-02 08:35:14 --> Config Class Initialized
INFO - 2025-04-02 08:35:14 --> Loader Class Initialized
INFO - 2025-04-02 08:35:14 --> Helper loaded: url_helper
INFO - 2025-04-02 08:35:14 --> Helper loaded: file_helper
INFO - 2025-04-02 08:35:14 --> Helper loaded: html_helper
INFO - 2025-04-02 08:35:14 --> Helper loaded: form_helper
INFO - 2025-04-02 08:35:14 --> Helper loaded: text_helper
INFO - 2025-04-02 08:35:14 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:35:14 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:35:14 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:35:14 --> Database Driver Class Initialized
INFO - 2025-04-02 08:35:14 --> Email Class Initialized
INFO - 2025-04-02 08:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:35:14 --> Form Validation Class Initialized
INFO - 2025-04-02 08:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:35:14 --> Pagination Class Initialized
INFO - 2025-04-02 08:35:14 --> Controller Class Initialized
DEBUG - 2025-04-02 08:35:14 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:35:14 --> Model Class Initialized
DEBUG - 2025-04-02 14:35:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:35:14 --> Model Class Initialized
DEBUG - 2025-04-02 14:35:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:35:14 --> Model Class Initialized
DEBUG - 2025-04-02 14:35:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:35:14 --> Model Class Initialized
INFO - 2025-04-02 14:35:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-02 14:35:14 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
ERROR - 2025-04-02 14:35:14 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 495
DEBUG - 2025-04-02 14:35:14 --> 📥 acc_transaction insert: {"vid":"162","fyear":"1","VNo":"CV-46","Vtype":"CV","referenceNo":"1091","VDate":"2025-04-02","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"450.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:35:14"}
DEBUG - 2025-04-02 14:35:14 --> 📥 acc_transaction insert: {"vid":"162","fyear":"1","VNo":"CV-46","Vtype":"CV","referenceNo":"1091","VDate":"2025-04-02","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"450.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:35:14"}
DEBUG - 2025-04-02 14:35:14 --> 📥 acc_transaction insert: {"vid":"163","fyear":"1","VNo":"JV-67","Vtype":"JV","referenceNo":"1091","VDate":"2025-04-02","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"290.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:35:14"}
DEBUG - 2025-04-02 14:35:14 --> 📥 acc_transaction insert: {"vid":"163","fyear":"1","VNo":"JV-67","Vtype":"JV","referenceNo":"1091","VDate":"2025-04-02","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"290.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:35:14"}
DEBUG - 2025-04-02 14:35:14 --> 📥 acc_transaction insert: {"vid":"164","fyear":"1","VNo":"JV-68","Vtype":"JV","referenceNo":"1091","VDate":"2025-04-02","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:35:14"}
DEBUG - 2025-04-02 14:35:14 --> 📥 acc_transaction insert: {"vid":"164","fyear":"1","VNo":"JV-68","Vtype":"JV","referenceNo":"1091","VDate":"2025-04-02","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-02 14:35:14"}
DEBUG - 2025-04-02 14:35:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-02 14:35:14 --> Final output sent to browser
DEBUG - 2025-04-02 14:35:14 --> Total execution time: 0.1004
INFO - 2025-04-02 08:35:16 --> Config Class Initialized
INFO - 2025-04-02 08:35:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:35:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:35:16 --> Utf8 Class Initialized
INFO - 2025-04-02 08:35:16 --> URI Class Initialized
DEBUG - 2025-04-02 08:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-02 08:35:16 --> Router Class Initialized
INFO - 2025-04-02 08:35:16 --> Output Class Initialized
INFO - 2025-04-02 08:35:16 --> Security Class Initialized
DEBUG - 2025-04-02 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:35:16 --> Input Class Initialized
INFO - 2025-04-02 08:35:16 --> Language Class Initialized
INFO - 2025-04-02 08:35:16 --> Language Class Initialized
INFO - 2025-04-02 08:35:16 --> Config Class Initialized
INFO - 2025-04-02 08:35:16 --> Loader Class Initialized
INFO - 2025-04-02 08:35:16 --> Helper loaded: url_helper
INFO - 2025-04-02 08:35:16 --> Helper loaded: file_helper
INFO - 2025-04-02 08:35:16 --> Helper loaded: html_helper
INFO - 2025-04-02 08:35:16 --> Helper loaded: form_helper
INFO - 2025-04-02 08:35:16 --> Helper loaded: text_helper
INFO - 2025-04-02 08:35:16 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:35:16 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:35:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:35:16 --> Database Driver Class Initialized
INFO - 2025-04-02 08:35:16 --> Email Class Initialized
INFO - 2025-04-02 08:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:35:16 --> Form Validation Class Initialized
INFO - 2025-04-02 08:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:35:16 --> Pagination Class Initialized
INFO - 2025-04-02 08:35:16 --> Controller Class Initialized
DEBUG - 2025-04-02 08:35:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-02 14:35:16 --> Model Class Initialized
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-02 14:35:16 --> Model Class Initialized
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-02 14:35:16 --> Model Class Initialized
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-02 14:35:16 --> Model Class Initialized
ERROR - 2025-04-02 14:35:16 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:35:16 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-02 14:35:16 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-02 14:35:16 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 14:35:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 14:35:16 --> Model Class Initialized
ERROR - 2025-04-02 14:35:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 14:35:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 14:35:16 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 14:35:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 14:35:16 --> Final output sent to browser
DEBUG - 2025-04-02 14:35:16 --> Total execution time: 0.1614
INFO - 2025-04-02 08:35:25 --> Config Class Initialized
INFO - 2025-04-02 08:35:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:35:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:35:25 --> Utf8 Class Initialized
INFO - 2025-04-02 08:35:25 --> URI Class Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:35:25 --> Router Class Initialized
INFO - 2025-04-02 08:35:25 --> Output Class Initialized
INFO - 2025-04-02 08:35:25 --> Security Class Initialized
DEBUG - 2025-04-02 08:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:35:25 --> Input Class Initialized
INFO - 2025-04-02 08:35:25 --> Language Class Initialized
INFO - 2025-04-02 08:35:25 --> Language Class Initialized
INFO - 2025-04-02 08:35:25 --> Config Class Initialized
INFO - 2025-04-02 08:35:25 --> Loader Class Initialized
INFO - 2025-04-02 08:35:25 --> Helper loaded: url_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: file_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: html_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: form_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: text_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:35:25 --> Database Driver Class Initialized
INFO - 2025-04-02 08:35:25 --> Email Class Initialized
INFO - 2025-04-02 08:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:35:25 --> Form Validation Class Initialized
INFO - 2025-04-02 08:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:35:25 --> Pagination Class Initialized
INFO - 2025-04-02 08:35:25 --> Controller Class Initialized
DEBUG - 2025-04-02 08:35:25 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:35:25 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:35:25 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:35:25 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:35:25 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:35:25 --> Model Class Initialized
ERROR - 2025-04-02 08:35:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:35:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_list.php
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:35:25 --> Final output sent to browser
DEBUG - 2025-04-02 08:35:25 --> Total execution time: 0.0978
INFO - 2025-04-02 08:35:25 --> Config Class Initialized
INFO - 2025-04-02 08:35:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:35:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:35:25 --> Utf8 Class Initialized
INFO - 2025-04-02 08:35:25 --> URI Class Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:35:25 --> Router Class Initialized
INFO - 2025-04-02 08:35:25 --> Output Class Initialized
INFO - 2025-04-02 08:35:25 --> Security Class Initialized
DEBUG - 2025-04-02 08:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:35:25 --> Input Class Initialized
INFO - 2025-04-02 08:35:25 --> Language Class Initialized
INFO - 2025-04-02 08:35:25 --> Language Class Initialized
INFO - 2025-04-02 08:35:25 --> Config Class Initialized
INFO - 2025-04-02 08:35:25 --> Loader Class Initialized
INFO - 2025-04-02 08:35:25 --> Helper loaded: url_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: file_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: html_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: form_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: text_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:35:25 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:35:25 --> Database Driver Class Initialized
INFO - 2025-04-02 08:35:25 --> Email Class Initialized
INFO - 2025-04-02 08:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:35:25 --> Form Validation Class Initialized
INFO - 2025-04-02 08:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:35:25 --> Pagination Class Initialized
INFO - 2025-04-02 08:35:25 --> Controller Class Initialized
DEBUG - 2025-04-02 08:35:25 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:35:25 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:35:25 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:35:25 --> Model Class Initialized
ERROR - 2025-04-02 08:35:25 --> Controller Product Name: Array
(
    [draw] => 1
    [iTotalRecords] => 6
    [iTotalDisplayRecords] => 6
    [aaData] => Array
        (
            [0] => Array
                (
                    [sl] => 1
                    [product_name] => <a href="http://localhost:8000/product_details/5998830">Pran Mango Juice</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/0ade1c1df8678a2bd6da9da683652050.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/5998830" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/5998830" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/5998830" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/5998830" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [1] => Array
                (
                    [sl] => 2
                    [product_name] => <a href="http://localhost:8000/product_details/34769578">Test Product</a>
                    [category] => Beverage->Cold Drinks->Cola
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/2">Danish</a>
                    [price] => 200
                    [purchase_p] => 
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-04-02/c19c9bec0db94a53a3cbe5c4adce6cc7.png" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/34769578" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/34769578" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/34769578" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/34769578" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [2] => Array
                (
                    [sl] => 3
                    [product_name] => <a href="http://localhost:8000/product_details/123456">Pran Juice</a>
                    [category] => Frozen Food->Paratha->2400gmx12Pac
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 25
                    [purchase_p] => 20
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-27/9a9bf7f4f8e815522fe6b496bf2d9fed.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/123456" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/123456" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/123456" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/123456" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [3] => Array
                (
                    [sl] => 4
                    [product_name] => <a href="http://localhost:8000/product_details/79291734">Ruhi Fish</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/1">Pran Company Limited</a>
                    [price] => 350
                    [purchase_p] => 250
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/b15999f825736a896f6bb7d3dd874f65.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/79291734" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/79291734" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/79291734" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/79291734" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [4] => Array
                (
                    [sl] => 5
                    [product_name] => <a href="http://localhost:8000/product_details/84213421">Ruhi</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/4">Karim & Sons</a>
                    [price] => 10
                    [purchase_p] => 5
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/cd23e47393890cd08fe0269c490e4dec.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/84213421" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/84213421" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/84213421" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/84213421" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

            [5] => Array
                (
                    [sl] => 6
                    [product_name] => <a href="http://localhost:8000/product_details/51252612252670">Vegetable Pakorass</a>
                    [category] => Frozen Food->Veg Pakora->small
                    [supplier_name] => <a href="http://localhost:8000/supplier_ledgerinfo/3">AG agro</a>
                    [price] => 29.72
                    [purchase_p] => 24.57
                    [image] => <img src="http://localhost:8000/./my-assets/image/product/2025-03-28/1602e603ce762137e843206d13d97fa3.jpg" class="img img-responsive" height="50" width="50">
                    [button] => <a href="http://localhost:8000/product/product/paysenz_deleteproduct/51252612252670" class="btn btn-xs btn-danger " onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash"></i></a>  <a href="http://localhost:8000/qrcode/51252612252670" class="btn btn-success btn-xs" title="QR Code"><i class="fa fa-qrcode" aria-hidden="true"></i></a>  <a href="http://localhost:8000/barcode/51252612252670" class="btn btn-warning btn-xs" title="Barcode"><i class="fa fa-barcode" aria-hidden="true"></i></a> <a href="http://localhost:8000/product_form/51252612252670" class="btn btn-info btn-xs" title="Update"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                )

        )

)

INFO - 2025-04-02 08:35:25 --> Final output sent to browser
DEBUG - 2025-04-02 08:35:25 --> Total execution time: 0.0064
INFO - 2025-04-02 08:35:30 --> Config Class Initialized
INFO - 2025-04-02 08:35:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:35:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:35:30 --> Utf8 Class Initialized
INFO - 2025-04-02 08:35:30 --> URI Class Initialized
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:35:30 --> Router Class Initialized
INFO - 2025-04-02 08:35:30 --> Output Class Initialized
INFO - 2025-04-02 08:35:30 --> Security Class Initialized
DEBUG - 2025-04-02 08:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:35:30 --> Input Class Initialized
INFO - 2025-04-02 08:35:30 --> Language Class Initialized
INFO - 2025-04-02 08:35:30 --> Language Class Initialized
INFO - 2025-04-02 08:35:30 --> Config Class Initialized
INFO - 2025-04-02 08:35:30 --> Loader Class Initialized
INFO - 2025-04-02 08:35:30 --> Helper loaded: url_helper
INFO - 2025-04-02 08:35:30 --> Helper loaded: file_helper
INFO - 2025-04-02 08:35:30 --> Helper loaded: html_helper
INFO - 2025-04-02 08:35:30 --> Helper loaded: form_helper
INFO - 2025-04-02 08:35:30 --> Helper loaded: text_helper
INFO - 2025-04-02 08:35:30 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:35:30 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:35:30 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:35:30 --> Database Driver Class Initialized
INFO - 2025-04-02 08:35:30 --> Email Class Initialized
INFO - 2025-04-02 08:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:35:30 --> Form Validation Class Initialized
INFO - 2025-04-02 08:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:35:30 --> Pagination Class Initialized
INFO - 2025-04-02 08:35:30 --> Controller Class Initialized
DEBUG - 2025-04-02 08:35:30 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:35:30 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:35:30 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:35:30 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-02 08:35:30 --> Template MX_Controller Initialized
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-02 08:35:30 --> Model Class Initialized
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $parent_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 67
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $sub_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 86
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 105
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Undefined variable $child_category_id /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 115
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
ERROR - 2025-04-02 08:35:30 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php 223
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/product_form.php
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-02 08:35:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-02 08:35:30 --> Final output sent to browser
DEBUG - 2025-04-02 08:35:30 --> Total execution time: 0.1911
INFO - 2025-04-02 08:35:39 --> Config Class Initialized
INFO - 2025-04-02 08:35:39 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:35:39 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:35:39 --> Utf8 Class Initialized
INFO - 2025-04-02 08:35:39 --> URI Class Initialized
DEBUG - 2025-04-02 08:35:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:35:39 --> Router Class Initialized
INFO - 2025-04-02 08:35:39 --> Output Class Initialized
INFO - 2025-04-02 08:35:39 --> Security Class Initialized
DEBUG - 2025-04-02 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:35:39 --> Input Class Initialized
INFO - 2025-04-02 08:35:39 --> Language Class Initialized
INFO - 2025-04-02 08:35:39 --> Language Class Initialized
INFO - 2025-04-02 08:35:39 --> Config Class Initialized
INFO - 2025-04-02 08:35:39 --> Loader Class Initialized
INFO - 2025-04-02 08:35:39 --> Helper loaded: url_helper
INFO - 2025-04-02 08:35:39 --> Helper loaded: file_helper
INFO - 2025-04-02 08:35:39 --> Helper loaded: html_helper
INFO - 2025-04-02 08:35:39 --> Helper loaded: form_helper
INFO - 2025-04-02 08:35:39 --> Helper loaded: text_helper
INFO - 2025-04-02 08:35:39 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:35:39 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:35:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:35:39 --> Database Driver Class Initialized
INFO - 2025-04-02 08:35:39 --> Email Class Initialized
INFO - 2025-04-02 08:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:35:39 --> Form Validation Class Initialized
INFO - 2025-04-02 08:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:35:39 --> Pagination Class Initialized
INFO - 2025-04-02 08:35:39 --> Controller Class Initialized
DEBUG - 2025-04-02 08:35:39 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:35:39 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:35:39 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:35:39 --> Model Class Initialized
INFO - 2025-04-02 08:35:39 --> Final output sent to browser
DEBUG - 2025-04-02 08:35:39 --> Total execution time: 0.0081
INFO - 2025-04-02 08:35:43 --> Config Class Initialized
INFO - 2025-04-02 08:35:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:35:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:35:43 --> Utf8 Class Initialized
INFO - 2025-04-02 08:35:43 --> URI Class Initialized
DEBUG - 2025-04-02 08:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:35:43 --> Router Class Initialized
INFO - 2025-04-02 08:35:43 --> Output Class Initialized
INFO - 2025-04-02 08:35:43 --> Security Class Initialized
DEBUG - 2025-04-02 08:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:35:43 --> Input Class Initialized
INFO - 2025-04-02 08:35:43 --> Language Class Initialized
INFO - 2025-04-02 08:35:43 --> Language Class Initialized
INFO - 2025-04-02 08:35:43 --> Config Class Initialized
INFO - 2025-04-02 08:35:43 --> Loader Class Initialized
INFO - 2025-04-02 08:35:43 --> Helper loaded: url_helper
INFO - 2025-04-02 08:35:43 --> Helper loaded: file_helper
INFO - 2025-04-02 08:35:43 --> Helper loaded: html_helper
INFO - 2025-04-02 08:35:43 --> Helper loaded: form_helper
INFO - 2025-04-02 08:35:43 --> Helper loaded: text_helper
INFO - 2025-04-02 08:35:43 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:35:43 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:35:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:35:43 --> Database Driver Class Initialized
INFO - 2025-04-02 08:35:43 --> Email Class Initialized
INFO - 2025-04-02 08:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:35:43 --> Form Validation Class Initialized
INFO - 2025-04-02 08:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:35:43 --> Pagination Class Initialized
INFO - 2025-04-02 08:35:43 --> Controller Class Initialized
DEBUG - 2025-04-02 08:35:43 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:35:43 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:35:43 --> Model Class Initialized
DEBUG - 2025-04-02 08:35:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:35:43 --> Model Class Initialized
INFO - 2025-04-02 08:35:43 --> Final output sent to browser
DEBUG - 2025-04-02 08:35:43 --> Total execution time: 0.0110
INFO - 2025-04-02 08:36:19 --> Config Class Initialized
INFO - 2025-04-02 08:36:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 08:36:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 08:36:19 --> Utf8 Class Initialized
INFO - 2025-04-02 08:36:19 --> URI Class Initialized
DEBUG - 2025-04-02 08:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-04-02 08:36:19 --> Router Class Initialized
INFO - 2025-04-02 08:36:19 --> Output Class Initialized
INFO - 2025-04-02 08:36:19 --> Security Class Initialized
DEBUG - 2025-04-02 08:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 08:36:19 --> Input Class Initialized
INFO - 2025-04-02 08:36:19 --> Language Class Initialized
INFO - 2025-04-02 08:36:19 --> Language Class Initialized
INFO - 2025-04-02 08:36:19 --> Config Class Initialized
INFO - 2025-04-02 08:36:19 --> Loader Class Initialized
INFO - 2025-04-02 08:36:19 --> Helper loaded: url_helper
INFO - 2025-04-02 08:36:19 --> Helper loaded: file_helper
INFO - 2025-04-02 08:36:19 --> Helper loaded: html_helper
INFO - 2025-04-02 08:36:19 --> Helper loaded: form_helper
INFO - 2025-04-02 08:36:19 --> Helper loaded: text_helper
INFO - 2025-04-02 08:36:19 --> Helper loaded: lang_helper
INFO - 2025-04-02 08:36:19 --> Helper loaded: directory_helper
INFO - 2025-04-02 08:36:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-02 08:36:19 --> Database Driver Class Initialized
INFO - 2025-04-02 08:36:19 --> Email Class Initialized
INFO - 2025-04-02 08:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 08:36:19 --> Form Validation Class Initialized
INFO - 2025-04-02 08:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-02 08:36:19 --> Pagination Class Initialized
INFO - 2025-04-02 08:36:19 --> Controller Class Initialized
DEBUG - 2025-04-02 08:36:19 --> Product MX_Controller Initialized
INFO - 2025-04-02 08:36:19 --> Model Class Initialized
DEBUG - 2025-04-02 08:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-04-02 08:36:19 --> Model Class Initialized
DEBUG - 2025-04-02 08:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-04-02 08:36:19 --> Model Class Initialized
INFO - 2025-04-02 08:36:19 --> Upload Class Initialized
INFO - 2025-04-02 08:36:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-02 08:36:19 --> Severity: error --> Exception: Field 'slug' doesn't have a default value /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
