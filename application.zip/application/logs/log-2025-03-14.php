<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-14 06:23:08 --> Config Class Initialized
INFO - 2025-03-14 06:23:08 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:23:08 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:23:08 --> Utf8 Class Initialized
INFO - 2025-03-14 06:23:08 --> URI Class Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:23:08 --> Router Class Initialized
INFO - 2025-03-14 06:23:08 --> Output Class Initialized
INFO - 2025-03-14 06:23:08 --> Security Class Initialized
DEBUG - 2025-03-14 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:23:08 --> Input Class Initialized
INFO - 2025-03-14 06:23:08 --> Language Class Initialized
INFO - 2025-03-14 06:23:08 --> Language Class Initialized
INFO - 2025-03-14 06:23:08 --> Config Class Initialized
INFO - 2025-03-14 06:23:08 --> Loader Class Initialized
INFO - 2025-03-14 06:23:08 --> Helper loaded: url_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: file_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: html_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: form_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: text_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:23:08 --> Database Driver Class Initialized
INFO - 2025-03-14 06:23:08 --> Email Class Initialized
INFO - 2025-03-14 06:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:23:08 --> Form Validation Class Initialized
INFO - 2025-03-14 06:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:23:08 --> Pagination Class Initialized
INFO - 2025-03-14 06:23:08 --> Controller Class Initialized
DEBUG - 2025-03-14 06:23:08 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:23:08 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:23:08 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:23:08 --> Model Class Initialized
INFO - 2025-03-14 06:23:08 --> Config Class Initialized
INFO - 2025-03-14 06:23:08 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:23:08 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:23:08 --> Utf8 Class Initialized
INFO - 2025-03-14 06:23:08 --> URI Class Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 06:23:08 --> Router Class Initialized
INFO - 2025-03-14 06:23:08 --> Output Class Initialized
INFO - 2025-03-14 06:23:08 --> Security Class Initialized
DEBUG - 2025-03-14 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:23:08 --> Input Class Initialized
INFO - 2025-03-14 06:23:08 --> Language Class Initialized
INFO - 2025-03-14 06:23:08 --> Language Class Initialized
INFO - 2025-03-14 06:23:08 --> Config Class Initialized
INFO - 2025-03-14 06:23:08 --> Loader Class Initialized
INFO - 2025-03-14 06:23:08 --> Helper loaded: url_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: file_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: html_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: form_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: text_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:23:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:23:08 --> Database Driver Class Initialized
INFO - 2025-03-14 06:23:08 --> Email Class Initialized
INFO - 2025-03-14 06:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:23:08 --> Form Validation Class Initialized
INFO - 2025-03-14 06:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:23:08 --> Pagination Class Initialized
INFO - 2025-03-14 06:23:08 --> Controller Class Initialized
DEBUG - 2025-03-14 06:23:08 --> Auth MX_Controller Initialized
INFO - 2025-03-14 06:23:08 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 06:23:08 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 06:23:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 06:23:08 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-14 06:23:08 --> Final output sent to browser
DEBUG - 2025-03-14 06:23:08 --> Total execution time: 0.0484
INFO - 2025-03-14 06:23:21 --> Config Class Initialized
INFO - 2025-03-14 06:23:21 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:23:21 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:23:21 --> Utf8 Class Initialized
INFO - 2025-03-14 06:23:21 --> URI Class Initialized
DEBUG - 2025-03-14 06:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 06:23:21 --> Router Class Initialized
INFO - 2025-03-14 06:23:21 --> Output Class Initialized
INFO - 2025-03-14 06:23:21 --> Security Class Initialized
DEBUG - 2025-03-14 06:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:23:21 --> Input Class Initialized
INFO - 2025-03-14 06:23:21 --> Language Class Initialized
INFO - 2025-03-14 06:23:21 --> Language Class Initialized
INFO - 2025-03-14 06:23:21 --> Config Class Initialized
INFO - 2025-03-14 06:23:21 --> Loader Class Initialized
INFO - 2025-03-14 06:23:21 --> Helper loaded: url_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: file_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: html_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: form_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: text_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:23:21 --> Database Driver Class Initialized
INFO - 2025-03-14 06:23:21 --> Email Class Initialized
INFO - 2025-03-14 06:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:23:21 --> Form Validation Class Initialized
INFO - 2025-03-14 06:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:23:21 --> Pagination Class Initialized
INFO - 2025-03-14 06:23:21 --> Controller Class Initialized
DEBUG - 2025-03-14 06:23:21 --> Auth MX_Controller Initialized
INFO - 2025-03-14 06:23:21 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 06:23:21 --> Model Class Initialized
INFO - 2025-03-14 06:23:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 06:23:21 --> Config Class Initialized
INFO - 2025-03-14 06:23:21 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:23:21 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:23:21 --> Utf8 Class Initialized
INFO - 2025-03-14 06:23:21 --> URI Class Initialized
DEBUG - 2025-03-14 06:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 06:23:21 --> Router Class Initialized
INFO - 2025-03-14 06:23:21 --> Output Class Initialized
INFO - 2025-03-14 06:23:21 --> Security Class Initialized
DEBUG - 2025-03-14 06:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:23:21 --> Input Class Initialized
INFO - 2025-03-14 06:23:21 --> Language Class Initialized
INFO - 2025-03-14 06:23:21 --> Language Class Initialized
INFO - 2025-03-14 06:23:21 --> Config Class Initialized
INFO - 2025-03-14 06:23:21 --> Loader Class Initialized
INFO - 2025-03-14 06:23:21 --> Helper loaded: url_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: file_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: html_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: form_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: text_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:23:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:23:21 --> Database Driver Class Initialized
INFO - 2025-03-14 06:23:21 --> Email Class Initialized
INFO - 2025-03-14 06:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:23:21 --> Form Validation Class Initialized
INFO - 2025-03-14 06:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:23:21 --> Pagination Class Initialized
INFO - 2025-03-14 06:23:21 --> Controller Class Initialized
DEBUG - 2025-03-14 06:23:21 --> Home MX_Controller Initialized
INFO - 2025-03-14 06:23:21 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 06:23:21 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 06:23:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 06:23:22 --> Model Class Initialized
ERROR - 2025-03-14 06:23:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 06:23:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 06:23:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 06:23:22 --> Final output sent to browser
DEBUG - 2025-03-14 06:23:22 --> Total execution time: 0.7457
INFO - 2025-03-14 06:23:26 --> Config Class Initialized
INFO - 2025-03-14 06:23:26 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:23:26 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:23:26 --> Utf8 Class Initialized
INFO - 2025-03-14 06:23:26 --> URI Class Initialized
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:23:26 --> Router Class Initialized
INFO - 2025-03-14 06:23:26 --> Output Class Initialized
INFO - 2025-03-14 06:23:26 --> Security Class Initialized
DEBUG - 2025-03-14 06:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:23:26 --> Input Class Initialized
INFO - 2025-03-14 06:23:26 --> Language Class Initialized
INFO - 2025-03-14 06:23:26 --> Language Class Initialized
INFO - 2025-03-14 06:23:26 --> Config Class Initialized
INFO - 2025-03-14 06:23:26 --> Loader Class Initialized
INFO - 2025-03-14 06:23:26 --> Helper loaded: url_helper
INFO - 2025-03-14 06:23:26 --> Helper loaded: file_helper
INFO - 2025-03-14 06:23:26 --> Helper loaded: html_helper
INFO - 2025-03-14 06:23:26 --> Helper loaded: form_helper
INFO - 2025-03-14 06:23:26 --> Helper loaded: text_helper
INFO - 2025-03-14 06:23:26 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:23:26 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:23:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:23:26 --> Database Driver Class Initialized
INFO - 2025-03-14 06:23:26 --> Email Class Initialized
INFO - 2025-03-14 06:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:23:26 --> Form Validation Class Initialized
INFO - 2025-03-14 06:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:23:26 --> Pagination Class Initialized
INFO - 2025-03-14 06:23:26 --> Controller Class Initialized
DEBUG - 2025-03-14 06:23:26 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:23:26 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:23:26 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:23:26 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 06:23:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 06:23:26 --> Model Class Initialized
ERROR - 2025-03-14 06:23:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 06:23:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 06:23:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 06:23:26 --> Final output sent to browser
DEBUG - 2025-03-14 06:23:26 --> Total execution time: 0.2841
INFO - 2025-03-14 06:23:43 --> Config Class Initialized
INFO - 2025-03-14 06:23:43 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:23:43 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:23:43 --> Utf8 Class Initialized
INFO - 2025-03-14 06:23:43 --> URI Class Initialized
DEBUG - 2025-03-14 06:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:23:43 --> Router Class Initialized
INFO - 2025-03-14 06:23:43 --> Output Class Initialized
INFO - 2025-03-14 06:23:43 --> Security Class Initialized
DEBUG - 2025-03-14 06:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:23:43 --> Input Class Initialized
INFO - 2025-03-14 06:23:43 --> Language Class Initialized
INFO - 2025-03-14 06:23:43 --> Language Class Initialized
INFO - 2025-03-14 06:23:43 --> Config Class Initialized
INFO - 2025-03-14 06:23:43 --> Loader Class Initialized
INFO - 2025-03-14 06:23:43 --> Helper loaded: url_helper
INFO - 2025-03-14 06:23:43 --> Helper loaded: file_helper
INFO - 2025-03-14 06:23:43 --> Helper loaded: html_helper
INFO - 2025-03-14 06:23:43 --> Helper loaded: form_helper
INFO - 2025-03-14 06:23:43 --> Helper loaded: text_helper
INFO - 2025-03-14 06:23:43 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:23:43 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:23:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:23:43 --> Database Driver Class Initialized
INFO - 2025-03-14 06:23:43 --> Email Class Initialized
INFO - 2025-03-14 06:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:23:43 --> Form Validation Class Initialized
INFO - 2025-03-14 06:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:23:43 --> Pagination Class Initialized
INFO - 2025-03-14 06:23:43 --> Controller Class Initialized
DEBUG - 2025-03-14 06:23:43 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:23:43 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:23:43 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:23:43 --> Model Class Initialized
INFO - 2025-03-14 06:23:43 --> Final output sent to browser
DEBUG - 2025-03-14 06:23:43 --> Total execution time: 0.0159
INFO - 2025-03-14 06:23:44 --> Config Class Initialized
INFO - 2025-03-14 06:23:44 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:23:44 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:23:44 --> Utf8 Class Initialized
INFO - 2025-03-14 06:23:44 --> URI Class Initialized
DEBUG - 2025-03-14 06:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:23:44 --> Router Class Initialized
INFO - 2025-03-14 06:23:44 --> Output Class Initialized
INFO - 2025-03-14 06:23:44 --> Security Class Initialized
DEBUG - 2025-03-14 06:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:23:44 --> Input Class Initialized
INFO - 2025-03-14 06:23:44 --> Language Class Initialized
INFO - 2025-03-14 06:23:44 --> Language Class Initialized
INFO - 2025-03-14 06:23:44 --> Config Class Initialized
INFO - 2025-03-14 06:23:44 --> Loader Class Initialized
INFO - 2025-03-14 06:23:44 --> Helper loaded: url_helper
INFO - 2025-03-14 06:23:44 --> Helper loaded: file_helper
INFO - 2025-03-14 06:23:44 --> Helper loaded: html_helper
INFO - 2025-03-14 06:23:44 --> Helper loaded: form_helper
INFO - 2025-03-14 06:23:44 --> Helper loaded: text_helper
INFO - 2025-03-14 06:23:44 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:23:44 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:23:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:23:44 --> Database Driver Class Initialized
INFO - 2025-03-14 06:23:44 --> Email Class Initialized
INFO - 2025-03-14 06:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:23:44 --> Form Validation Class Initialized
INFO - 2025-03-14 06:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:23:44 --> Pagination Class Initialized
INFO - 2025-03-14 06:23:44 --> Controller Class Initialized
DEBUG - 2025-03-14 06:23:44 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:23:44 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:23:44 --> Model Class Initialized
DEBUG - 2025-03-14 06:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:23:44 --> Model Class Initialized
INFO - 2025-03-14 06:23:44 --> Final output sent to browser
DEBUG - 2025-03-14 06:23:44 --> Total execution time: 0.0143
INFO - 2025-03-14 06:24:03 --> Config Class Initialized
INFO - 2025-03-14 06:24:03 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:24:03 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:24:03 --> Utf8 Class Initialized
INFO - 2025-03-14 06:24:03 --> URI Class Initialized
DEBUG - 2025-03-14 06:24:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:24:03 --> Router Class Initialized
INFO - 2025-03-14 06:24:03 --> Output Class Initialized
INFO - 2025-03-14 06:24:03 --> Security Class Initialized
DEBUG - 2025-03-14 06:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:24:03 --> Input Class Initialized
INFO - 2025-03-14 06:24:03 --> Language Class Initialized
INFO - 2025-03-14 06:24:03 --> Language Class Initialized
INFO - 2025-03-14 06:24:03 --> Config Class Initialized
INFO - 2025-03-14 06:24:03 --> Loader Class Initialized
INFO - 2025-03-14 06:24:03 --> Helper loaded: url_helper
INFO - 2025-03-14 06:24:03 --> Helper loaded: file_helper
INFO - 2025-03-14 06:24:03 --> Helper loaded: html_helper
INFO - 2025-03-14 06:24:03 --> Helper loaded: form_helper
INFO - 2025-03-14 06:24:03 --> Helper loaded: text_helper
INFO - 2025-03-14 06:24:03 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:24:03 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:24:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:24:03 --> Database Driver Class Initialized
INFO - 2025-03-14 06:24:03 --> Email Class Initialized
INFO - 2025-03-14 06:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:24:03 --> Form Validation Class Initialized
INFO - 2025-03-14 06:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:24:03 --> Pagination Class Initialized
INFO - 2025-03-14 06:24:03 --> Controller Class Initialized
DEBUG - 2025-03-14 06:24:03 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:24:03 --> Model Class Initialized
DEBUG - 2025-03-14 06:24:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:24:03 --> Model Class Initialized
DEBUG - 2025-03-14 06:24:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:24:03 --> Model Class Initialized
INFO - 2025-03-14 06:24:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-03-14 06:24:03 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php 435
ERROR - 2025-03-14 06:24:03 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php 436
ERROR - 2025-03-14 06:24:03 --> Severity: error --> Exception: Column 'vat_amnt_per' cannot be null /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-14 06:27:10 --> Config Class Initialized
INFO - 2025-03-14 06:27:10 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:27:10 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:27:10 --> Utf8 Class Initialized
INFO - 2025-03-14 06:27:10 --> URI Class Initialized
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:27:10 --> Router Class Initialized
INFO - 2025-03-14 06:27:10 --> Output Class Initialized
INFO - 2025-03-14 06:27:10 --> Security Class Initialized
DEBUG - 2025-03-14 06:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:27:10 --> Input Class Initialized
INFO - 2025-03-14 06:27:10 --> Language Class Initialized
INFO - 2025-03-14 06:27:10 --> Language Class Initialized
INFO - 2025-03-14 06:27:10 --> Config Class Initialized
INFO - 2025-03-14 06:27:10 --> Loader Class Initialized
INFO - 2025-03-14 06:27:10 --> Helper loaded: url_helper
INFO - 2025-03-14 06:27:10 --> Helper loaded: file_helper
INFO - 2025-03-14 06:27:10 --> Helper loaded: html_helper
INFO - 2025-03-14 06:27:10 --> Helper loaded: form_helper
INFO - 2025-03-14 06:27:10 --> Helper loaded: text_helper
INFO - 2025-03-14 06:27:10 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:27:10 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:27:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:27:10 --> Database Driver Class Initialized
INFO - 2025-03-14 06:27:10 --> Email Class Initialized
INFO - 2025-03-14 06:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:27:10 --> Form Validation Class Initialized
INFO - 2025-03-14 06:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:27:10 --> Pagination Class Initialized
INFO - 2025-03-14 06:27:10 --> Controller Class Initialized
DEBUG - 2025-03-14 06:27:10 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:27:10 --> Model Class Initialized
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:27:10 --> Model Class Initialized
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:27:10 --> Model Class Initialized
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 06:27:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 06:27:10 --> Model Class Initialized
ERROR - 2025-03-14 06:27:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 06:27:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 06:27:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 06:27:10 --> Final output sent to browser
DEBUG - 2025-03-14 06:27:10 --> Total execution time: 0.1054
INFO - 2025-03-14 06:33:25 --> Config Class Initialized
INFO - 2025-03-14 06:33:25 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:33:25 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:33:25 --> Utf8 Class Initialized
INFO - 2025-03-14 06:33:25 --> URI Class Initialized
DEBUG - 2025-03-14 06:33:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:33:25 --> Router Class Initialized
INFO - 2025-03-14 06:33:25 --> Output Class Initialized
INFO - 2025-03-14 06:33:25 --> Security Class Initialized
DEBUG - 2025-03-14 06:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:33:25 --> Input Class Initialized
INFO - 2025-03-14 06:33:25 --> Language Class Initialized
INFO - 2025-03-14 06:33:25 --> Language Class Initialized
INFO - 2025-03-14 06:33:25 --> Config Class Initialized
INFO - 2025-03-14 06:33:25 --> Loader Class Initialized
INFO - 2025-03-14 06:33:25 --> Helper loaded: url_helper
INFO - 2025-03-14 06:33:25 --> Helper loaded: file_helper
INFO - 2025-03-14 06:33:25 --> Helper loaded: html_helper
INFO - 2025-03-14 06:33:25 --> Helper loaded: form_helper
INFO - 2025-03-14 06:33:25 --> Helper loaded: text_helper
INFO - 2025-03-14 06:33:25 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:33:25 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:33:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:33:25 --> Database Driver Class Initialized
INFO - 2025-03-14 06:33:25 --> Email Class Initialized
INFO - 2025-03-14 06:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:33:25 --> Form Validation Class Initialized
INFO - 2025-03-14 06:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:33:25 --> Pagination Class Initialized
INFO - 2025-03-14 06:33:25 --> Controller Class Initialized
DEBUG - 2025-03-14 06:33:25 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:33:25 --> Model Class Initialized
DEBUG - 2025-03-14 06:33:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:33:25 --> Model Class Initialized
DEBUG - 2025-03-14 06:33:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:33:25 --> Model Class Initialized
INFO - 2025-03-14 06:33:25 --> Final output sent to browser
DEBUG - 2025-03-14 06:33:25 --> Total execution time: 0.0103
INFO - 2025-03-14 06:33:26 --> Config Class Initialized
INFO - 2025-03-14 06:33:26 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:33:26 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:33:26 --> Utf8 Class Initialized
INFO - 2025-03-14 06:33:26 --> URI Class Initialized
DEBUG - 2025-03-14 06:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:33:26 --> Router Class Initialized
INFO - 2025-03-14 06:33:26 --> Output Class Initialized
INFO - 2025-03-14 06:33:26 --> Security Class Initialized
DEBUG - 2025-03-14 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:33:26 --> Input Class Initialized
INFO - 2025-03-14 06:33:26 --> Language Class Initialized
INFO - 2025-03-14 06:33:26 --> Language Class Initialized
INFO - 2025-03-14 06:33:26 --> Config Class Initialized
INFO - 2025-03-14 06:33:26 --> Loader Class Initialized
INFO - 2025-03-14 06:33:26 --> Helper loaded: url_helper
INFO - 2025-03-14 06:33:26 --> Helper loaded: file_helper
INFO - 2025-03-14 06:33:26 --> Helper loaded: html_helper
INFO - 2025-03-14 06:33:26 --> Helper loaded: form_helper
INFO - 2025-03-14 06:33:26 --> Helper loaded: text_helper
INFO - 2025-03-14 06:33:26 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:33:26 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:33:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:33:26 --> Database Driver Class Initialized
INFO - 2025-03-14 06:33:26 --> Email Class Initialized
INFO - 2025-03-14 06:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:33:26 --> Form Validation Class Initialized
INFO - 2025-03-14 06:33:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:33:26 --> Pagination Class Initialized
INFO - 2025-03-14 06:33:26 --> Controller Class Initialized
DEBUG - 2025-03-14 06:33:26 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:33:26 --> Model Class Initialized
DEBUG - 2025-03-14 06:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:33:26 --> Model Class Initialized
DEBUG - 2025-03-14 06:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:33:26 --> Model Class Initialized
INFO - 2025-03-14 06:33:26 --> Final output sent to browser
DEBUG - 2025-03-14 06:33:26 --> Total execution time: 0.0084
INFO - 2025-03-14 06:33:37 --> Config Class Initialized
INFO - 2025-03-14 06:33:37 --> Hooks Class Initialized
DEBUG - 2025-03-14 06:33:37 --> UTF-8 Support Enabled
INFO - 2025-03-14 06:33:37 --> Utf8 Class Initialized
INFO - 2025-03-14 06:33:37 --> URI Class Initialized
DEBUG - 2025-03-14 06:33:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 06:33:37 --> Router Class Initialized
INFO - 2025-03-14 06:33:37 --> Output Class Initialized
INFO - 2025-03-14 06:33:37 --> Security Class Initialized
DEBUG - 2025-03-14 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 06:33:37 --> Input Class Initialized
INFO - 2025-03-14 06:33:37 --> Language Class Initialized
INFO - 2025-03-14 06:33:37 --> Language Class Initialized
INFO - 2025-03-14 06:33:37 --> Config Class Initialized
INFO - 2025-03-14 06:33:37 --> Loader Class Initialized
INFO - 2025-03-14 06:33:37 --> Helper loaded: url_helper
INFO - 2025-03-14 06:33:37 --> Helper loaded: file_helper
INFO - 2025-03-14 06:33:37 --> Helper loaded: html_helper
INFO - 2025-03-14 06:33:37 --> Helper loaded: form_helper
INFO - 2025-03-14 06:33:37 --> Helper loaded: text_helper
INFO - 2025-03-14 06:33:37 --> Helper loaded: lang_helper
INFO - 2025-03-14 06:33:37 --> Helper loaded: directory_helper
INFO - 2025-03-14 06:33:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 06:33:37 --> Database Driver Class Initialized
INFO - 2025-03-14 06:33:37 --> Email Class Initialized
INFO - 2025-03-14 06:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 06:33:37 --> Form Validation Class Initialized
INFO - 2025-03-14 06:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 06:33:37 --> Pagination Class Initialized
INFO - 2025-03-14 06:33:37 --> Controller Class Initialized
DEBUG - 2025-03-14 06:33:37 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 06:33:37 --> Model Class Initialized
DEBUG - 2025-03-14 06:33:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 06:33:37 --> Model Class Initialized
DEBUG - 2025-03-14 06:33:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 06:33:37 --> Model Class Initialized
INFO - 2025-03-14 06:33:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-03-14 06:33:37 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php 435
ERROR - 2025-03-14 06:33:37 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php 436
ERROR - 2025-03-14 06:33:37 --> Severity: error --> Exception: Column 'vat_amnt_per' cannot be null /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-03-14 19:59:02 --> Config Class Initialized
INFO - 2025-03-14 19:59:02 --> Hooks Class Initialized
DEBUG - 2025-03-14 19:59:02 --> UTF-8 Support Enabled
INFO - 2025-03-14 19:59:02 --> Utf8 Class Initialized
INFO - 2025-03-14 19:59:02 --> URI Class Initialized
DEBUG - 2025-03-14 19:59:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-14 19:59:02 --> No URI present. Default controller set.
INFO - 2025-03-14 19:59:02 --> Router Class Initialized
INFO - 2025-03-14 19:59:02 --> Output Class Initialized
INFO - 2025-03-14 19:59:03 --> Security Class Initialized
DEBUG - 2025-03-14 19:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 19:59:03 --> Input Class Initialized
INFO - 2025-03-14 19:59:03 --> Language Class Initialized
INFO - 2025-03-14 19:59:03 --> Language Class Initialized
INFO - 2025-03-14 19:59:03 --> Config Class Initialized
INFO - 2025-03-14 19:59:03 --> Loader Class Initialized
INFO - 2025-03-14 19:59:03 --> Helper loaded: url_helper
INFO - 2025-03-14 19:59:03 --> Helper loaded: file_helper
INFO - 2025-03-14 19:59:03 --> Helper loaded: html_helper
INFO - 2025-03-14 19:59:03 --> Helper loaded: form_helper
INFO - 2025-03-14 19:59:03 --> Helper loaded: text_helper
INFO - 2025-03-14 19:59:03 --> Helper loaded: lang_helper
INFO - 2025-03-14 19:59:03 --> Helper loaded: directory_helper
INFO - 2025-03-14 19:59:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 19:59:03 --> Database Driver Class Initialized
INFO - 2025-03-14 19:59:03 --> Email Class Initialized
INFO - 2025-03-14 19:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 19:59:03 --> Form Validation Class Initialized
INFO - 2025-03-14 19:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 19:59:03 --> Pagination Class Initialized
INFO - 2025-03-14 19:59:03 --> Controller Class Initialized
DEBUG - 2025-03-14 19:59:03 --> Auth MX_Controller Initialized
INFO - 2025-03-14 19:59:03 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 19:59:03 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 19:59:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 19:59:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 19:59:03 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-14 19:59:03 --> Final output sent to browser
DEBUG - 2025-03-14 19:59:03 --> Total execution time: 0.0676
INFO - 2025-03-14 19:59:26 --> Config Class Initialized
INFO - 2025-03-14 19:59:26 --> Hooks Class Initialized
DEBUG - 2025-03-14 19:59:26 --> UTF-8 Support Enabled
INFO - 2025-03-14 19:59:26 --> Utf8 Class Initialized
INFO - 2025-03-14 19:59:26 --> URI Class Initialized
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 19:59:26 --> Router Class Initialized
INFO - 2025-03-14 19:59:26 --> Output Class Initialized
INFO - 2025-03-14 19:59:26 --> Security Class Initialized
DEBUG - 2025-03-14 19:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 19:59:26 --> Input Class Initialized
INFO - 2025-03-14 19:59:26 --> Language Class Initialized
INFO - 2025-03-14 19:59:26 --> Language Class Initialized
INFO - 2025-03-14 19:59:26 --> Config Class Initialized
INFO - 2025-03-14 19:59:26 --> Loader Class Initialized
INFO - 2025-03-14 19:59:26 --> Helper loaded: url_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: file_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: html_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: form_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: text_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: lang_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: directory_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 19:59:26 --> Database Driver Class Initialized
INFO - 2025-03-14 19:59:26 --> Email Class Initialized
INFO - 2025-03-14 19:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 19:59:26 --> Form Validation Class Initialized
INFO - 2025-03-14 19:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 19:59:26 --> Pagination Class Initialized
INFO - 2025-03-14 19:59:26 --> Controller Class Initialized
DEBUG - 2025-03-14 19:59:26 --> Auth MX_Controller Initialized
INFO - 2025-03-14 19:59:26 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 19:59:26 --> Model Class Initialized
INFO - 2025-03-14 19:59:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 19:59:26 --> Config Class Initialized
INFO - 2025-03-14 19:59:26 --> Hooks Class Initialized
DEBUG - 2025-03-14 19:59:26 --> UTF-8 Support Enabled
INFO - 2025-03-14 19:59:26 --> Utf8 Class Initialized
INFO - 2025-03-14 19:59:26 --> URI Class Initialized
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 19:59:26 --> Router Class Initialized
INFO - 2025-03-14 19:59:26 --> Output Class Initialized
INFO - 2025-03-14 19:59:26 --> Security Class Initialized
DEBUG - 2025-03-14 19:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 19:59:26 --> Input Class Initialized
INFO - 2025-03-14 19:59:26 --> Language Class Initialized
INFO - 2025-03-14 19:59:26 --> Language Class Initialized
INFO - 2025-03-14 19:59:26 --> Config Class Initialized
INFO - 2025-03-14 19:59:26 --> Loader Class Initialized
INFO - 2025-03-14 19:59:26 --> Helper loaded: url_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: file_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: html_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: form_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: text_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: lang_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: directory_helper
INFO - 2025-03-14 19:59:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 19:59:26 --> Database Driver Class Initialized
INFO - 2025-03-14 19:59:26 --> Email Class Initialized
INFO - 2025-03-14 19:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 19:59:26 --> Form Validation Class Initialized
INFO - 2025-03-14 19:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 19:59:26 --> Pagination Class Initialized
INFO - 2025-03-14 19:59:26 --> Controller Class Initialized
DEBUG - 2025-03-14 19:59:26 --> Home MX_Controller Initialized
INFO - 2025-03-14 19:59:26 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 19:59:26 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 19:59:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 19:59:26 --> Model Class Initialized
ERROR - 2025-03-14 19:59:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 19:59:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 19:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 19:59:26 --> Final output sent to browser
DEBUG - 2025-03-14 19:59:26 --> Total execution time: 0.6142
INFO - 2025-03-14 19:59:41 --> Config Class Initialized
INFO - 2025-03-14 19:59:41 --> Hooks Class Initialized
DEBUG - 2025-03-14 19:59:41 --> UTF-8 Support Enabled
INFO - 2025-03-14 19:59:41 --> Utf8 Class Initialized
INFO - 2025-03-14 19:59:41 --> URI Class Initialized
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 19:59:41 --> Router Class Initialized
INFO - 2025-03-14 19:59:41 --> Output Class Initialized
INFO - 2025-03-14 19:59:41 --> Security Class Initialized
DEBUG - 2025-03-14 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 19:59:41 --> Input Class Initialized
INFO - 2025-03-14 19:59:41 --> Language Class Initialized
INFO - 2025-03-14 19:59:41 --> Language Class Initialized
INFO - 2025-03-14 19:59:41 --> Config Class Initialized
INFO - 2025-03-14 19:59:41 --> Loader Class Initialized
INFO - 2025-03-14 19:59:41 --> Helper loaded: url_helper
INFO - 2025-03-14 19:59:41 --> Helper loaded: file_helper
INFO - 2025-03-14 19:59:41 --> Helper loaded: html_helper
INFO - 2025-03-14 19:59:41 --> Helper loaded: form_helper
INFO - 2025-03-14 19:59:41 --> Helper loaded: text_helper
INFO - 2025-03-14 19:59:41 --> Helper loaded: lang_helper
INFO - 2025-03-14 19:59:41 --> Helper loaded: directory_helper
INFO - 2025-03-14 19:59:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 19:59:41 --> Database Driver Class Initialized
INFO - 2025-03-14 19:59:41 --> Email Class Initialized
INFO - 2025-03-14 19:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 19:59:41 --> Form Validation Class Initialized
INFO - 2025-03-14 19:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 19:59:41 --> Pagination Class Initialized
INFO - 2025-03-14 19:59:41 --> Controller Class Initialized
DEBUG - 2025-03-14 19:59:41 --> Product MX_Controller Initialized
INFO - 2025-03-14 19:59:41 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 19:59:41 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 19:59:41 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 19:59:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 19:59:41 --> Model Class Initialized
ERROR - 2025-03-14 19:59:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 19:59:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 19:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 19:59:41 --> Final output sent to browser
DEBUG - 2025-03-14 19:59:41 --> Total execution time: 0.1233
INFO - 2025-03-14 19:59:44 --> Config Class Initialized
INFO - 2025-03-14 19:59:44 --> Hooks Class Initialized
DEBUG - 2025-03-14 19:59:44 --> UTF-8 Support Enabled
INFO - 2025-03-14 19:59:44 --> Utf8 Class Initialized
INFO - 2025-03-14 19:59:44 --> URI Class Initialized
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 19:59:44 --> Router Class Initialized
INFO - 2025-03-14 19:59:44 --> Output Class Initialized
INFO - 2025-03-14 19:59:44 --> Security Class Initialized
DEBUG - 2025-03-14 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 19:59:44 --> Input Class Initialized
INFO - 2025-03-14 19:59:44 --> Language Class Initialized
INFO - 2025-03-14 19:59:44 --> Language Class Initialized
INFO - 2025-03-14 19:59:44 --> Config Class Initialized
INFO - 2025-03-14 19:59:44 --> Loader Class Initialized
INFO - 2025-03-14 19:59:44 --> Helper loaded: url_helper
INFO - 2025-03-14 19:59:44 --> Helper loaded: file_helper
INFO - 2025-03-14 19:59:44 --> Helper loaded: html_helper
INFO - 2025-03-14 19:59:44 --> Helper loaded: form_helper
INFO - 2025-03-14 19:59:44 --> Helper loaded: text_helper
INFO - 2025-03-14 19:59:44 --> Helper loaded: lang_helper
INFO - 2025-03-14 19:59:44 --> Helper loaded: directory_helper
INFO - 2025-03-14 19:59:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 19:59:44 --> Database Driver Class Initialized
INFO - 2025-03-14 19:59:44 --> Email Class Initialized
INFO - 2025-03-14 19:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 19:59:44 --> Form Validation Class Initialized
INFO - 2025-03-14 19:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 19:59:44 --> Pagination Class Initialized
INFO - 2025-03-14 19:59:44 --> Controller Class Initialized
DEBUG - 2025-03-14 19:59:44 --> Product MX_Controller Initialized
INFO - 2025-03-14 19:59:44 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 19:59:44 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 19:59:44 --> Model Class Initialized
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 19:59:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 19:59:44 --> Model Class Initialized
ERROR - 2025-03-14 19:59:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 19:59:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 19:59:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 19:59:44 --> Final output sent to browser
DEBUG - 2025-03-14 19:59:44 --> Total execution time: 0.1776
INFO - 2025-03-14 20:05:57 --> Config Class Initialized
INFO - 2025-03-14 20:05:57 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:05:57 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:05:57 --> Utf8 Class Initialized
INFO - 2025-03-14 20:05:57 --> URI Class Initialized
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:05:57 --> Router Class Initialized
INFO - 2025-03-14 20:05:57 --> Output Class Initialized
INFO - 2025-03-14 20:05:57 --> Security Class Initialized
DEBUG - 2025-03-14 20:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:05:57 --> Input Class Initialized
INFO - 2025-03-14 20:05:57 --> Language Class Initialized
INFO - 2025-03-14 20:05:57 --> Language Class Initialized
INFO - 2025-03-14 20:05:57 --> Config Class Initialized
INFO - 2025-03-14 20:05:57 --> Loader Class Initialized
INFO - 2025-03-14 20:05:57 --> Helper loaded: url_helper
INFO - 2025-03-14 20:05:57 --> Helper loaded: file_helper
INFO - 2025-03-14 20:05:57 --> Helper loaded: html_helper
INFO - 2025-03-14 20:05:57 --> Helper loaded: form_helper
INFO - 2025-03-14 20:05:57 --> Helper loaded: text_helper
INFO - 2025-03-14 20:05:57 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:05:57 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:05:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:05:57 --> Database Driver Class Initialized
INFO - 2025-03-14 20:05:57 --> Email Class Initialized
INFO - 2025-03-14 20:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:05:57 --> Form Validation Class Initialized
INFO - 2025-03-14 20:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:05:57 --> Pagination Class Initialized
INFO - 2025-03-14 20:05:57 --> Controller Class Initialized
DEBUG - 2025-03-14 20:05:57 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:05:57 --> Model Class Initialized
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:05:57 --> Model Class Initialized
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:05:57 --> Model Class Initialized
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:05:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:05:57 --> Model Class Initialized
ERROR - 2025-03-14 20:05:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:05:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:05:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:05:57 --> Final output sent to browser
DEBUG - 2025-03-14 20:05:57 --> Total execution time: 0.1442
INFO - 2025-03-14 20:06:03 --> Config Class Initialized
INFO - 2025-03-14 20:06:03 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:06:03 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:06:03 --> Utf8 Class Initialized
INFO - 2025-03-14 20:06:03 --> URI Class Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:06:03 --> Router Class Initialized
INFO - 2025-03-14 20:06:03 --> Output Class Initialized
INFO - 2025-03-14 20:06:03 --> Security Class Initialized
DEBUG - 2025-03-14 20:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:06:03 --> Input Class Initialized
INFO - 2025-03-14 20:06:03 --> Language Class Initialized
INFO - 2025-03-14 20:06:03 --> Language Class Initialized
INFO - 2025-03-14 20:06:03 --> Config Class Initialized
INFO - 2025-03-14 20:06:03 --> Loader Class Initialized
INFO - 2025-03-14 20:06:03 --> Helper loaded: url_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: file_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: html_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: form_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: text_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:06:03 --> Database Driver Class Initialized
INFO - 2025-03-14 20:06:03 --> Email Class Initialized
INFO - 2025-03-14 20:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:06:03 --> Form Validation Class Initialized
INFO - 2025-03-14 20:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:06:03 --> Pagination Class Initialized
INFO - 2025-03-14 20:06:03 --> Controller Class Initialized
DEBUG - 2025-03-14 20:06:03 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:06:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:06:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:06:03 --> Model Class Initialized
INFO - 2025-03-14 20:06:03 --> Config Class Initialized
INFO - 2025-03-14 20:06:03 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:06:03 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:06:03 --> Utf8 Class Initialized
INFO - 2025-03-14 20:06:03 --> URI Class Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:06:03 --> Router Class Initialized
INFO - 2025-03-14 20:06:03 --> Output Class Initialized
INFO - 2025-03-14 20:06:03 --> Security Class Initialized
DEBUG - 2025-03-14 20:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:06:03 --> Input Class Initialized
INFO - 2025-03-14 20:06:03 --> Language Class Initialized
INFO - 2025-03-14 20:06:03 --> Language Class Initialized
INFO - 2025-03-14 20:06:03 --> Config Class Initialized
INFO - 2025-03-14 20:06:03 --> Loader Class Initialized
INFO - 2025-03-14 20:06:03 --> Helper loaded: url_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: file_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: html_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: form_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: text_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:06:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:06:03 --> Database Driver Class Initialized
INFO - 2025-03-14 20:06:03 --> Email Class Initialized
INFO - 2025-03-14 20:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:06:03 --> Form Validation Class Initialized
INFO - 2025-03-14 20:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:06:03 --> Pagination Class Initialized
INFO - 2025-03-14 20:06:03 --> Controller Class Initialized
DEBUG - 2025-03-14 20:06:03 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:06:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:06:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:06:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:06:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:06:03 --> Model Class Initialized
ERROR - 2025-03-14 20:06:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:06:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:06:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:06:03 --> Final output sent to browser
DEBUG - 2025-03-14 20:06:03 --> Total execution time: 0.1703
INFO - 2025-03-14 20:06:34 --> Config Class Initialized
INFO - 2025-03-14 20:06:34 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:06:34 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:06:34 --> Utf8 Class Initialized
INFO - 2025-03-14 20:06:34 --> URI Class Initialized
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:06:34 --> Router Class Initialized
INFO - 2025-03-14 20:06:34 --> Output Class Initialized
INFO - 2025-03-14 20:06:34 --> Security Class Initialized
DEBUG - 2025-03-14 20:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:06:34 --> Input Class Initialized
INFO - 2025-03-14 20:06:34 --> Language Class Initialized
INFO - 2025-03-14 20:06:34 --> Language Class Initialized
INFO - 2025-03-14 20:06:34 --> Config Class Initialized
INFO - 2025-03-14 20:06:34 --> Loader Class Initialized
INFO - 2025-03-14 20:06:34 --> Helper loaded: url_helper
INFO - 2025-03-14 20:06:34 --> Helper loaded: file_helper
INFO - 2025-03-14 20:06:34 --> Helper loaded: html_helper
INFO - 2025-03-14 20:06:34 --> Helper loaded: form_helper
INFO - 2025-03-14 20:06:34 --> Helper loaded: text_helper
INFO - 2025-03-14 20:06:34 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:06:34 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:06:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:06:34 --> Database Driver Class Initialized
INFO - 2025-03-14 20:06:34 --> Email Class Initialized
INFO - 2025-03-14 20:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:06:34 --> Form Validation Class Initialized
INFO - 2025-03-14 20:06:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:06:34 --> Pagination Class Initialized
INFO - 2025-03-14 20:06:34 --> Controller Class Initialized
DEBUG - 2025-03-14 20:06:34 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:06:34 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:06:34 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:06:34 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:06:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:06:34 --> Model Class Initialized
ERROR - 2025-03-14 20:06:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:06:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:06:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:06:34 --> Final output sent to browser
DEBUG - 2025-03-14 20:06:34 --> Total execution time: 0.2012
INFO - 2025-03-14 20:06:49 --> Config Class Initialized
INFO - 2025-03-14 20:06:49 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:06:49 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:06:49 --> Utf8 Class Initialized
INFO - 2025-03-14 20:06:49 --> URI Class Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:06:49 --> Router Class Initialized
INFO - 2025-03-14 20:06:49 --> Output Class Initialized
INFO - 2025-03-14 20:06:49 --> Security Class Initialized
DEBUG - 2025-03-14 20:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:06:49 --> Input Class Initialized
INFO - 2025-03-14 20:06:49 --> Language Class Initialized
INFO - 2025-03-14 20:06:49 --> Language Class Initialized
INFO - 2025-03-14 20:06:49 --> Config Class Initialized
INFO - 2025-03-14 20:06:49 --> Loader Class Initialized
INFO - 2025-03-14 20:06:49 --> Helper loaded: url_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: file_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: html_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: form_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: text_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:06:49 --> Database Driver Class Initialized
INFO - 2025-03-14 20:06:49 --> Email Class Initialized
INFO - 2025-03-14 20:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:06:49 --> Form Validation Class Initialized
INFO - 2025-03-14 20:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:06:49 --> Pagination Class Initialized
INFO - 2025-03-14 20:06:49 --> Controller Class Initialized
DEBUG - 2025-03-14 20:06:49 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:06:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:06:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:06:49 --> Model Class Initialized
INFO - 2025-03-14 20:06:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 20:06:49 --> Config Class Initialized
INFO - 2025-03-14 20:06:49 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:06:49 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:06:49 --> Utf8 Class Initialized
INFO - 2025-03-14 20:06:49 --> URI Class Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:06:49 --> Router Class Initialized
INFO - 2025-03-14 20:06:49 --> Output Class Initialized
INFO - 2025-03-14 20:06:49 --> Security Class Initialized
DEBUG - 2025-03-14 20:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:06:49 --> Input Class Initialized
INFO - 2025-03-14 20:06:49 --> Language Class Initialized
INFO - 2025-03-14 20:06:49 --> Language Class Initialized
INFO - 2025-03-14 20:06:49 --> Config Class Initialized
INFO - 2025-03-14 20:06:49 --> Loader Class Initialized
INFO - 2025-03-14 20:06:49 --> Helper loaded: url_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: file_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: html_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: form_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: text_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:06:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:06:49 --> Database Driver Class Initialized
INFO - 2025-03-14 20:06:49 --> Email Class Initialized
INFO - 2025-03-14 20:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:06:49 --> Form Validation Class Initialized
INFO - 2025-03-14 20:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:06:49 --> Pagination Class Initialized
INFO - 2025-03-14 20:06:49 --> Controller Class Initialized
DEBUG - 2025-03-14 20:06:49 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:06:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:06:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:06:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:06:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:06:49 --> Model Class Initialized
ERROR - 2025-03-14 20:06:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:06:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:06:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:06:49 --> Final output sent to browser
DEBUG - 2025-03-14 20:06:49 --> Total execution time: 0.0913
INFO - 2025-03-14 20:07:14 --> Config Class Initialized
INFO - 2025-03-14 20:07:14 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:07:14 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:07:14 --> Utf8 Class Initialized
INFO - 2025-03-14 20:07:14 --> URI Class Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:07:14 --> Router Class Initialized
INFO - 2025-03-14 20:07:14 --> Output Class Initialized
INFO - 2025-03-14 20:07:14 --> Security Class Initialized
DEBUG - 2025-03-14 20:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:07:14 --> Input Class Initialized
INFO - 2025-03-14 20:07:14 --> Language Class Initialized
INFO - 2025-03-14 20:07:14 --> Language Class Initialized
INFO - 2025-03-14 20:07:14 --> Config Class Initialized
INFO - 2025-03-14 20:07:14 --> Loader Class Initialized
INFO - 2025-03-14 20:07:14 --> Helper loaded: url_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: file_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: html_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: form_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: text_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:07:14 --> Database Driver Class Initialized
INFO - 2025-03-14 20:07:14 --> Email Class Initialized
INFO - 2025-03-14 20:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:07:14 --> Form Validation Class Initialized
INFO - 2025-03-14 20:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:07:14 --> Pagination Class Initialized
INFO - 2025-03-14 20:07:14 --> Controller Class Initialized
DEBUG - 2025-03-14 20:07:14 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:07:14 --> Model Class Initialized
INFO - 2025-03-14 20:07:14 --> Config Class Initialized
INFO - 2025-03-14 20:07:14 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:07:14 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:07:14 --> Utf8 Class Initialized
INFO - 2025-03-14 20:07:14 --> URI Class Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:07:14 --> Router Class Initialized
INFO - 2025-03-14 20:07:14 --> Output Class Initialized
INFO - 2025-03-14 20:07:14 --> Security Class Initialized
DEBUG - 2025-03-14 20:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:07:14 --> Input Class Initialized
INFO - 2025-03-14 20:07:14 --> Language Class Initialized
INFO - 2025-03-14 20:07:14 --> Language Class Initialized
INFO - 2025-03-14 20:07:14 --> Config Class Initialized
INFO - 2025-03-14 20:07:14 --> Loader Class Initialized
INFO - 2025-03-14 20:07:14 --> Helper loaded: url_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: file_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: html_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: form_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: text_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:07:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:07:14 --> Database Driver Class Initialized
INFO - 2025-03-14 20:07:14 --> Email Class Initialized
INFO - 2025-03-14 20:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:07:14 --> Form Validation Class Initialized
INFO - 2025-03-14 20:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:07:14 --> Pagination Class Initialized
INFO - 2025-03-14 20:07:14 --> Controller Class Initialized
DEBUG - 2025-03-14 20:07:14 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:07:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:07:14 --> Model Class Initialized
ERROR - 2025-03-14 20:07:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:07:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:07:14 --> Final output sent to browser
DEBUG - 2025-03-14 20:07:14 --> Total execution time: 0.1371
INFO - 2025-03-14 20:07:27 --> Config Class Initialized
INFO - 2025-03-14 20:07:27 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:07:27 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:07:27 --> Utf8 Class Initialized
INFO - 2025-03-14 20:07:27 --> URI Class Initialized
DEBUG - 2025-03-14 20:07:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:07:27 --> Router Class Initialized
INFO - 2025-03-14 20:07:27 --> Output Class Initialized
INFO - 2025-03-14 20:07:27 --> Security Class Initialized
DEBUG - 2025-03-14 20:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:07:27 --> Input Class Initialized
INFO - 2025-03-14 20:07:27 --> Language Class Initialized
INFO - 2025-03-14 20:07:27 --> Language Class Initialized
INFO - 2025-03-14 20:07:27 --> Config Class Initialized
INFO - 2025-03-14 20:07:27 --> Loader Class Initialized
INFO - 2025-03-14 20:07:27 --> Helper loaded: url_helper
INFO - 2025-03-14 20:07:27 --> Helper loaded: file_helper
INFO - 2025-03-14 20:07:27 --> Helper loaded: html_helper
INFO - 2025-03-14 20:07:27 --> Helper loaded: form_helper
INFO - 2025-03-14 20:07:27 --> Helper loaded: text_helper
INFO - 2025-03-14 20:07:27 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:07:27 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:07:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:07:27 --> Database Driver Class Initialized
INFO - 2025-03-14 20:07:27 --> Email Class Initialized
INFO - 2025-03-14 20:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:07:27 --> Form Validation Class Initialized
INFO - 2025-03-14 20:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:07:27 --> Pagination Class Initialized
INFO - 2025-03-14 20:07:27 --> Controller Class Initialized
DEBUG - 2025-03-14 20:07:27 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:07:27 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:07:27 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:07:27 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:07:27 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:07:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:07:27 --> Model Class Initialized
ERROR - 2025-03-14 20:07:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:07:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:07:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:07:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:07:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:07:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:07:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:07:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:07:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:07:28 --> Final output sent to browser
DEBUG - 2025-03-14 20:07:28 --> Total execution time: 0.1001
INFO - 2025-03-14 20:07:37 --> Config Class Initialized
INFO - 2025-03-14 20:07:37 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:07:37 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:07:37 --> Utf8 Class Initialized
INFO - 2025-03-14 20:07:37 --> URI Class Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:07:37 --> Router Class Initialized
INFO - 2025-03-14 20:07:37 --> Output Class Initialized
INFO - 2025-03-14 20:07:37 --> Security Class Initialized
DEBUG - 2025-03-14 20:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:07:37 --> Input Class Initialized
INFO - 2025-03-14 20:07:37 --> Language Class Initialized
INFO - 2025-03-14 20:07:37 --> Language Class Initialized
INFO - 2025-03-14 20:07:37 --> Config Class Initialized
INFO - 2025-03-14 20:07:37 --> Loader Class Initialized
INFO - 2025-03-14 20:07:37 --> Helper loaded: url_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: file_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: html_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: form_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: text_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:07:37 --> Database Driver Class Initialized
INFO - 2025-03-14 20:07:37 --> Email Class Initialized
INFO - 2025-03-14 20:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:07:37 --> Form Validation Class Initialized
INFO - 2025-03-14 20:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:07:37 --> Pagination Class Initialized
INFO - 2025-03-14 20:07:37 --> Controller Class Initialized
DEBUG - 2025-03-14 20:07:37 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:07:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:07:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:07:37 --> Model Class Initialized
INFO - 2025-03-14 20:07:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 20:07:37 --> Config Class Initialized
INFO - 2025-03-14 20:07:37 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:07:37 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:07:37 --> Utf8 Class Initialized
INFO - 2025-03-14 20:07:37 --> URI Class Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:07:37 --> Router Class Initialized
INFO - 2025-03-14 20:07:37 --> Output Class Initialized
INFO - 2025-03-14 20:07:37 --> Security Class Initialized
DEBUG - 2025-03-14 20:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:07:37 --> Input Class Initialized
INFO - 2025-03-14 20:07:37 --> Language Class Initialized
INFO - 2025-03-14 20:07:37 --> Language Class Initialized
INFO - 2025-03-14 20:07:37 --> Config Class Initialized
INFO - 2025-03-14 20:07:37 --> Loader Class Initialized
INFO - 2025-03-14 20:07:37 --> Helper loaded: url_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: file_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: html_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: form_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: text_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:07:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:07:37 --> Database Driver Class Initialized
INFO - 2025-03-14 20:07:37 --> Email Class Initialized
INFO - 2025-03-14 20:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:07:37 --> Form Validation Class Initialized
INFO - 2025-03-14 20:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:07:37 --> Pagination Class Initialized
INFO - 2025-03-14 20:07:37 --> Controller Class Initialized
DEBUG - 2025-03-14 20:07:37 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:07:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:07:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:07:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:07:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:07:37 --> Model Class Initialized
ERROR - 2025-03-14 20:07:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:07:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:07:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:07:37 --> Final output sent to browser
DEBUG - 2025-03-14 20:07:37 --> Total execution time: 0.1306
INFO - 2025-03-14 20:16:05 --> Config Class Initialized
INFO - 2025-03-14 20:16:05 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:16:05 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:16:05 --> Utf8 Class Initialized
INFO - 2025-03-14 20:16:05 --> URI Class Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:16:05 --> Router Class Initialized
INFO - 2025-03-14 20:16:05 --> Output Class Initialized
INFO - 2025-03-14 20:16:05 --> Security Class Initialized
DEBUG - 2025-03-14 20:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:16:05 --> Input Class Initialized
INFO - 2025-03-14 20:16:05 --> Language Class Initialized
INFO - 2025-03-14 20:16:05 --> Language Class Initialized
INFO - 2025-03-14 20:16:05 --> Config Class Initialized
INFO - 2025-03-14 20:16:05 --> Loader Class Initialized
INFO - 2025-03-14 20:16:05 --> Helper loaded: url_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: file_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: html_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: form_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: text_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:16:05 --> Database Driver Class Initialized
INFO - 2025-03-14 20:16:05 --> Email Class Initialized
INFO - 2025-03-14 20:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:16:05 --> Form Validation Class Initialized
INFO - 2025-03-14 20:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:16:05 --> Pagination Class Initialized
INFO - 2025-03-14 20:16:05 --> Controller Class Initialized
DEBUG - 2025-03-14 20:16:05 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:16:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:16:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:16:05 --> Model Class Initialized
INFO - 2025-03-14 20:16:05 --> Config Class Initialized
INFO - 2025-03-14 20:16:05 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:16:05 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:16:05 --> Utf8 Class Initialized
INFO - 2025-03-14 20:16:05 --> URI Class Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:16:05 --> Router Class Initialized
INFO - 2025-03-14 20:16:05 --> Output Class Initialized
INFO - 2025-03-14 20:16:05 --> Security Class Initialized
DEBUG - 2025-03-14 20:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:16:05 --> Input Class Initialized
INFO - 2025-03-14 20:16:05 --> Language Class Initialized
INFO - 2025-03-14 20:16:05 --> Language Class Initialized
INFO - 2025-03-14 20:16:05 --> Config Class Initialized
INFO - 2025-03-14 20:16:05 --> Loader Class Initialized
INFO - 2025-03-14 20:16:05 --> Helper loaded: url_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: file_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: html_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: form_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: text_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:16:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:16:05 --> Database Driver Class Initialized
INFO - 2025-03-14 20:16:05 --> Email Class Initialized
INFO - 2025-03-14 20:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:16:05 --> Form Validation Class Initialized
INFO - 2025-03-14 20:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:16:05 --> Pagination Class Initialized
INFO - 2025-03-14 20:16:05 --> Controller Class Initialized
DEBUG - 2025-03-14 20:16:05 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:16:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:16:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:16:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:16:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:16:05 --> Model Class Initialized
ERROR - 2025-03-14 20:16:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:16:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:16:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:16:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:16:06 --> Final output sent to browser
DEBUG - 2025-03-14 20:16:06 --> Total execution time: 0.1572
INFO - 2025-03-14 20:16:08 --> Config Class Initialized
INFO - 2025-03-14 20:16:08 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:16:08 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:16:08 --> Utf8 Class Initialized
INFO - 2025-03-14 20:16:08 --> URI Class Initialized
DEBUG - 2025-03-14 20:16:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:16:08 --> Router Class Initialized
INFO - 2025-03-14 20:16:08 --> Output Class Initialized
INFO - 2025-03-14 20:16:08 --> Security Class Initialized
DEBUG - 2025-03-14 20:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:16:08 --> Input Class Initialized
INFO - 2025-03-14 20:16:08 --> Language Class Initialized
INFO - 2025-03-14 20:16:08 --> Language Class Initialized
INFO - 2025-03-14 20:16:08 --> Config Class Initialized
INFO - 2025-03-14 20:16:08 --> Loader Class Initialized
INFO - 2025-03-14 20:16:08 --> Helper loaded: url_helper
INFO - 2025-03-14 20:16:08 --> Helper loaded: file_helper
INFO - 2025-03-14 20:16:08 --> Helper loaded: html_helper
INFO - 2025-03-14 20:16:08 --> Helper loaded: form_helper
INFO - 2025-03-14 20:16:08 --> Helper loaded: text_helper
INFO - 2025-03-14 20:16:08 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:16:08 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:16:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:16:08 --> Database Driver Class Initialized
INFO - 2025-03-14 20:16:08 --> Email Class Initialized
INFO - 2025-03-14 20:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:16:08 --> Form Validation Class Initialized
INFO - 2025-03-14 20:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:16:08 --> Pagination Class Initialized
INFO - 2025-03-14 20:16:08 --> Controller Class Initialized
DEBUG - 2025-03-14 20:16:08 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:16:08 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:16:08 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:16:08 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:08 --> DEBUG: Final Category Name -> 
INFO - 2025-03-14 20:16:18 --> Config Class Initialized
INFO - 2025-03-14 20:16:18 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:16:18 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:16:18 --> Utf8 Class Initialized
INFO - 2025-03-14 20:16:18 --> URI Class Initialized
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:16:18 --> Router Class Initialized
INFO - 2025-03-14 20:16:18 --> Output Class Initialized
INFO - 2025-03-14 20:16:18 --> Security Class Initialized
DEBUG - 2025-03-14 20:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:16:18 --> Input Class Initialized
INFO - 2025-03-14 20:16:18 --> Language Class Initialized
INFO - 2025-03-14 20:16:18 --> Language Class Initialized
INFO - 2025-03-14 20:16:18 --> Config Class Initialized
INFO - 2025-03-14 20:16:18 --> Loader Class Initialized
INFO - 2025-03-14 20:16:18 --> Helper loaded: url_helper
INFO - 2025-03-14 20:16:18 --> Helper loaded: file_helper
INFO - 2025-03-14 20:16:18 --> Helper loaded: html_helper
INFO - 2025-03-14 20:16:18 --> Helper loaded: form_helper
INFO - 2025-03-14 20:16:18 --> Helper loaded: text_helper
INFO - 2025-03-14 20:16:18 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:16:18 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:16:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:16:18 --> Database Driver Class Initialized
INFO - 2025-03-14 20:16:18 --> Email Class Initialized
INFO - 2025-03-14 20:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:16:18 --> Form Validation Class Initialized
INFO - 2025-03-14 20:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:16:18 --> Pagination Class Initialized
INFO - 2025-03-14 20:16:18 --> Controller Class Initialized
DEBUG - 2025-03-14 20:16:18 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:16:18 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:16:18 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:16:18 --> Model Class Initialized
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:16:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:16:18 --> Model Class Initialized
ERROR - 2025-03-14 20:16:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:16:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:16:18 --> Final output sent to browser
DEBUG - 2025-03-14 20:16:18 --> Total execution time: 0.1782
INFO - 2025-03-14 20:17:01 --> Config Class Initialized
INFO - 2025-03-14 20:17:01 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:17:01 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:17:01 --> Utf8 Class Initialized
INFO - 2025-03-14 20:17:01 --> URI Class Initialized
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:17:01 --> Router Class Initialized
INFO - 2025-03-14 20:17:01 --> Output Class Initialized
INFO - 2025-03-14 20:17:01 --> Security Class Initialized
DEBUG - 2025-03-14 20:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:17:01 --> Input Class Initialized
INFO - 2025-03-14 20:17:01 --> Language Class Initialized
INFO - 2025-03-14 20:17:01 --> Language Class Initialized
INFO - 2025-03-14 20:17:01 --> Config Class Initialized
INFO - 2025-03-14 20:17:01 --> Loader Class Initialized
INFO - 2025-03-14 20:17:01 --> Helper loaded: url_helper
INFO - 2025-03-14 20:17:01 --> Helper loaded: file_helper
INFO - 2025-03-14 20:17:01 --> Helper loaded: html_helper
INFO - 2025-03-14 20:17:01 --> Helper loaded: form_helper
INFO - 2025-03-14 20:17:01 --> Helper loaded: text_helper
INFO - 2025-03-14 20:17:01 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:17:01 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:17:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:17:01 --> Database Driver Class Initialized
INFO - 2025-03-14 20:17:01 --> Email Class Initialized
INFO - 2025-03-14 20:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:17:01 --> Form Validation Class Initialized
INFO - 2025-03-14 20:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:17:01 --> Pagination Class Initialized
INFO - 2025-03-14 20:17:01 --> Controller Class Initialized
DEBUG - 2025-03-14 20:17:01 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:17:01 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:17:01 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:17:01 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:17:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:17:01 --> Model Class Initialized
ERROR - 2025-03-14 20:17:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:17:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:17:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:17:01 --> Final output sent to browser
DEBUG - 2025-03-14 20:17:01 --> Total execution time: 0.0978
INFO - 2025-03-14 20:17:03 --> Config Class Initialized
INFO - 2025-03-14 20:17:03 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:17:03 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:17:03 --> Utf8 Class Initialized
INFO - 2025-03-14 20:17:03 --> URI Class Initialized
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:17:03 --> Router Class Initialized
INFO - 2025-03-14 20:17:03 --> Output Class Initialized
INFO - 2025-03-14 20:17:03 --> Security Class Initialized
DEBUG - 2025-03-14 20:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:17:03 --> Input Class Initialized
INFO - 2025-03-14 20:17:03 --> Language Class Initialized
INFO - 2025-03-14 20:17:03 --> Language Class Initialized
INFO - 2025-03-14 20:17:03 --> Config Class Initialized
INFO - 2025-03-14 20:17:03 --> Loader Class Initialized
INFO - 2025-03-14 20:17:03 --> Helper loaded: url_helper
INFO - 2025-03-14 20:17:03 --> Helper loaded: file_helper
INFO - 2025-03-14 20:17:03 --> Helper loaded: html_helper
INFO - 2025-03-14 20:17:03 --> Helper loaded: form_helper
INFO - 2025-03-14 20:17:03 --> Helper loaded: text_helper
INFO - 2025-03-14 20:17:03 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:17:03 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:17:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:17:03 --> Database Driver Class Initialized
INFO - 2025-03-14 20:17:03 --> Email Class Initialized
INFO - 2025-03-14 20:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:17:03 --> Form Validation Class Initialized
INFO - 2025-03-14 20:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:17:03 --> Pagination Class Initialized
INFO - 2025-03-14 20:17:03 --> Controller Class Initialized
DEBUG - 2025-03-14 20:17:03 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:17:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:17:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:17:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:17:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:17:03 --> Model Class Initialized
ERROR - 2025-03-14 20:17:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:17:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:17:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:17:04 --> Final output sent to browser
DEBUG - 2025-03-14 20:17:04 --> Total execution time: 0.1798
INFO - 2025-03-14 20:17:05 --> Config Class Initialized
INFO - 2025-03-14 20:17:05 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:17:05 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:17:05 --> Utf8 Class Initialized
INFO - 2025-03-14 20:17:05 --> URI Class Initialized
DEBUG - 2025-03-14 20:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:17:05 --> Router Class Initialized
INFO - 2025-03-14 20:17:05 --> Output Class Initialized
INFO - 2025-03-14 20:17:05 --> Security Class Initialized
DEBUG - 2025-03-14 20:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:17:05 --> Input Class Initialized
INFO - 2025-03-14 20:17:05 --> Language Class Initialized
INFO - 2025-03-14 20:17:05 --> Language Class Initialized
INFO - 2025-03-14 20:17:05 --> Config Class Initialized
INFO - 2025-03-14 20:17:05 --> Loader Class Initialized
INFO - 2025-03-14 20:17:05 --> Helper loaded: url_helper
INFO - 2025-03-14 20:17:05 --> Helper loaded: file_helper
INFO - 2025-03-14 20:17:05 --> Helper loaded: html_helper
INFO - 2025-03-14 20:17:05 --> Helper loaded: form_helper
INFO - 2025-03-14 20:17:05 --> Helper loaded: text_helper
INFO - 2025-03-14 20:17:05 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:17:05 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:17:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:17:05 --> Database Driver Class Initialized
INFO - 2025-03-14 20:17:05 --> Email Class Initialized
INFO - 2025-03-14 20:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:17:05 --> Form Validation Class Initialized
INFO - 2025-03-14 20:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:17:05 --> Pagination Class Initialized
INFO - 2025-03-14 20:17:05 --> Controller Class Initialized
DEBUG - 2025-03-14 20:17:05 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:17:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:17:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:17:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:05 --> DEBUG: Final Category Name -> 
INFO - 2025-03-14 20:17:25 --> Config Class Initialized
INFO - 2025-03-14 20:17:25 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:17:25 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:17:25 --> Utf8 Class Initialized
INFO - 2025-03-14 20:17:25 --> URI Class Initialized
DEBUG - 2025-03-14 20:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:17:25 --> Router Class Initialized
INFO - 2025-03-14 20:17:25 --> Output Class Initialized
INFO - 2025-03-14 20:17:25 --> Security Class Initialized
DEBUG - 2025-03-14 20:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:17:25 --> Input Class Initialized
INFO - 2025-03-14 20:17:25 --> Language Class Initialized
INFO - 2025-03-14 20:17:25 --> Language Class Initialized
INFO - 2025-03-14 20:17:25 --> Config Class Initialized
INFO - 2025-03-14 20:17:25 --> Loader Class Initialized
INFO - 2025-03-14 20:17:25 --> Helper loaded: url_helper
INFO - 2025-03-14 20:17:25 --> Helper loaded: file_helper
INFO - 2025-03-14 20:17:25 --> Helper loaded: html_helper
INFO - 2025-03-14 20:17:25 --> Helper loaded: form_helper
INFO - 2025-03-14 20:17:25 --> Helper loaded: text_helper
INFO - 2025-03-14 20:17:25 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:17:25 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:17:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:17:25 --> Database Driver Class Initialized
INFO - 2025-03-14 20:17:25 --> Email Class Initialized
INFO - 2025-03-14 20:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:17:25 --> Form Validation Class Initialized
INFO - 2025-03-14 20:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:17:25 --> Pagination Class Initialized
INFO - 2025-03-14 20:17:25 --> Controller Class Initialized
DEBUG - 2025-03-14 20:17:25 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:17:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:17:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:17:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:25 --> DEBUG: Final Category Name -> 
INFO - 2025-03-14 20:17:26 --> Config Class Initialized
INFO - 2025-03-14 20:17:26 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:17:26 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:17:26 --> Utf8 Class Initialized
INFO - 2025-03-14 20:17:26 --> URI Class Initialized
DEBUG - 2025-03-14 20:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:17:26 --> Router Class Initialized
INFO - 2025-03-14 20:17:26 --> Output Class Initialized
INFO - 2025-03-14 20:17:26 --> Security Class Initialized
DEBUG - 2025-03-14 20:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:17:26 --> Input Class Initialized
INFO - 2025-03-14 20:17:26 --> Language Class Initialized
INFO - 2025-03-14 20:17:26 --> Language Class Initialized
INFO - 2025-03-14 20:17:26 --> Config Class Initialized
INFO - 2025-03-14 20:17:26 --> Loader Class Initialized
INFO - 2025-03-14 20:17:26 --> Helper loaded: url_helper
INFO - 2025-03-14 20:17:26 --> Helper loaded: file_helper
INFO - 2025-03-14 20:17:26 --> Helper loaded: html_helper
INFO - 2025-03-14 20:17:26 --> Helper loaded: form_helper
INFO - 2025-03-14 20:17:26 --> Helper loaded: text_helper
INFO - 2025-03-14 20:17:26 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:17:26 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:17:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:17:26 --> Database Driver Class Initialized
INFO - 2025-03-14 20:17:26 --> Email Class Initialized
INFO - 2025-03-14 20:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:17:26 --> Form Validation Class Initialized
INFO - 2025-03-14 20:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:17:26 --> Pagination Class Initialized
INFO - 2025-03-14 20:17:26 --> Controller Class Initialized
DEBUG - 2025-03-14 20:17:26 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:17:26 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:17:26 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:17:26 --> Model Class Initialized
DEBUG - 2025-03-14 20:17:26 --> DEBUG: Final Category Name -> 
INFO - 2025-03-14 20:18:00 --> Config Class Initialized
INFO - 2025-03-14 20:18:00 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:18:00 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:18:00 --> Utf8 Class Initialized
INFO - 2025-03-14 20:18:00 --> URI Class Initialized
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:18:00 --> Router Class Initialized
INFO - 2025-03-14 20:18:00 --> Output Class Initialized
INFO - 2025-03-14 20:18:00 --> Security Class Initialized
DEBUG - 2025-03-14 20:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:18:00 --> Input Class Initialized
INFO - 2025-03-14 20:18:00 --> Language Class Initialized
INFO - 2025-03-14 20:18:00 --> Language Class Initialized
INFO - 2025-03-14 20:18:00 --> Config Class Initialized
INFO - 2025-03-14 20:18:00 --> Loader Class Initialized
INFO - 2025-03-14 20:18:00 --> Helper loaded: url_helper
INFO - 2025-03-14 20:18:00 --> Helper loaded: file_helper
INFO - 2025-03-14 20:18:00 --> Helper loaded: html_helper
INFO - 2025-03-14 20:18:00 --> Helper loaded: form_helper
INFO - 2025-03-14 20:18:00 --> Helper loaded: text_helper
INFO - 2025-03-14 20:18:00 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:18:00 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:18:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:18:00 --> Database Driver Class Initialized
INFO - 2025-03-14 20:18:00 --> Email Class Initialized
INFO - 2025-03-14 20:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:18:00 --> Form Validation Class Initialized
INFO - 2025-03-14 20:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:18:00 --> Pagination Class Initialized
INFO - 2025-03-14 20:18:00 --> Controller Class Initialized
DEBUG - 2025-03-14 20:18:00 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:18:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:18:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:18:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:00 --> DEBUG: Final Category Name -> 
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:18:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:18:00 --> Model Class Initialized
ERROR - 2025-03-14 20:18:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:18:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:18:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:18:00 --> Final output sent to browser
DEBUG - 2025-03-14 20:18:00 --> Total execution time: 0.1526
INFO - 2025-03-14 20:18:03 --> Config Class Initialized
INFO - 2025-03-14 20:18:03 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:18:03 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:18:03 --> Utf8 Class Initialized
INFO - 2025-03-14 20:18:03 --> URI Class Initialized
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:18:03 --> Router Class Initialized
INFO - 2025-03-14 20:18:03 --> Output Class Initialized
INFO - 2025-03-14 20:18:03 --> Security Class Initialized
DEBUG - 2025-03-14 20:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:18:03 --> Input Class Initialized
INFO - 2025-03-14 20:18:03 --> Language Class Initialized
INFO - 2025-03-14 20:18:03 --> Language Class Initialized
INFO - 2025-03-14 20:18:03 --> Config Class Initialized
INFO - 2025-03-14 20:18:03 --> Loader Class Initialized
INFO - 2025-03-14 20:18:03 --> Helper loaded: url_helper
INFO - 2025-03-14 20:18:03 --> Helper loaded: file_helper
INFO - 2025-03-14 20:18:03 --> Helper loaded: html_helper
INFO - 2025-03-14 20:18:03 --> Helper loaded: form_helper
INFO - 2025-03-14 20:18:03 --> Helper loaded: text_helper
INFO - 2025-03-14 20:18:03 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:18:03 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:18:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:18:03 --> Database Driver Class Initialized
INFO - 2025-03-14 20:18:03 --> Email Class Initialized
INFO - 2025-03-14 20:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:18:03 --> Form Validation Class Initialized
INFO - 2025-03-14 20:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:18:03 --> Pagination Class Initialized
INFO - 2025-03-14 20:18:03 --> Controller Class Initialized
DEBUG - 2025-03-14 20:18:03 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:18:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:18:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:18:03 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:03 --> DEBUG: Final Category Name -> 
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:18:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:18:03 --> Model Class Initialized
ERROR - 2025-03-14 20:18:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:18:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:18:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:18:03 --> Final output sent to browser
DEBUG - 2025-03-14 20:18:03 --> Total execution time: 0.2047
INFO - 2025-03-14 20:18:14 --> Config Class Initialized
INFO - 2025-03-14 20:18:14 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:18:14 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:18:14 --> Utf8 Class Initialized
INFO - 2025-03-14 20:18:14 --> URI Class Initialized
DEBUG - 2025-03-14 20:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:18:14 --> Router Class Initialized
INFO - 2025-03-14 20:18:14 --> Output Class Initialized
INFO - 2025-03-14 20:18:14 --> Security Class Initialized
DEBUG - 2025-03-14 20:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:18:14 --> Input Class Initialized
INFO - 2025-03-14 20:18:14 --> Language Class Initialized
INFO - 2025-03-14 20:18:14 --> Language Class Initialized
INFO - 2025-03-14 20:18:14 --> Config Class Initialized
INFO - 2025-03-14 20:18:14 --> Loader Class Initialized
INFO - 2025-03-14 20:18:14 --> Helper loaded: url_helper
INFO - 2025-03-14 20:18:14 --> Helper loaded: file_helper
INFO - 2025-03-14 20:18:14 --> Helper loaded: html_helper
INFO - 2025-03-14 20:18:14 --> Helper loaded: form_helper
INFO - 2025-03-14 20:18:14 --> Helper loaded: text_helper
INFO - 2025-03-14 20:18:14 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:18:14 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:18:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:18:14 --> Database Driver Class Initialized
INFO - 2025-03-14 20:18:14 --> Email Class Initialized
INFO - 2025-03-14 20:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:18:14 --> Form Validation Class Initialized
INFO - 2025-03-14 20:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:18:14 --> Pagination Class Initialized
INFO - 2025-03-14 20:18:14 --> Controller Class Initialized
DEBUG - 2025-03-14 20:18:14 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:18:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:18:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:18:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:18:14 --> Model Class Initialized
INFO - 2025-03-14 20:18:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-14 20:18:14 --> DEBUG: Final Category Name -> Import->Import->Test1->ChieldTest1
INFO - 2025-03-14 20:21:12 --> Config Class Initialized
INFO - 2025-03-14 20:21:12 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:12 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:12 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:12 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:12 --> Router Class Initialized
INFO - 2025-03-14 20:21:12 --> Output Class Initialized
INFO - 2025-03-14 20:21:12 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:12 --> Input Class Initialized
INFO - 2025-03-14 20:21:12 --> Language Class Initialized
INFO - 2025-03-14 20:21:12 --> Language Class Initialized
INFO - 2025-03-14 20:21:12 --> Config Class Initialized
INFO - 2025-03-14 20:21:12 --> Loader Class Initialized
INFO - 2025-03-14 20:21:12 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:12 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:12 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:12 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:12 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:12 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:12 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:12 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:12 --> Email Class Initialized
INFO - 2025-03-14 20:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:12 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:12 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:12 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:12 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:12 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:12 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:12 --> Model Class Initialized
INFO - 2025-03-14 20:21:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-14 20:21:12 --> DEBUG: Final Category Name -> Import->Import->Test1->ChieldTest1
INFO - 2025-03-14 20:21:17 --> Config Class Initialized
INFO - 2025-03-14 20:21:17 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:17 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:17 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:17 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:17 --> Router Class Initialized
INFO - 2025-03-14 20:21:17 --> Output Class Initialized
INFO - 2025-03-14 20:21:17 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:17 --> Input Class Initialized
INFO - 2025-03-14 20:21:17 --> Language Class Initialized
INFO - 2025-03-14 20:21:17 --> Language Class Initialized
INFO - 2025-03-14 20:21:17 --> Config Class Initialized
INFO - 2025-03-14 20:21:17 --> Loader Class Initialized
INFO - 2025-03-14 20:21:17 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:17 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:17 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:17 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:17 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:17 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:17 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:17 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:17 --> Email Class Initialized
INFO - 2025-03-14 20:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:17 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:17 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:17 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:17 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:17 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:17 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:17 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:17 --> DEBUG: Final Category Name -> 
DEBUG - 2025-03-14 20:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:21:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:21:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:21:17 --> Model Class Initialized
ERROR - 2025-03-14 20:21:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:21:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:21:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:21:18 --> Final output sent to browser
DEBUG - 2025-03-14 20:21:18 --> Total execution time: 0.6503
INFO - 2025-03-14 20:21:20 --> Config Class Initialized
INFO - 2025-03-14 20:21:20 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:20 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:20 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:20 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:20 --> Router Class Initialized
INFO - 2025-03-14 20:21:20 --> Output Class Initialized
INFO - 2025-03-14 20:21:20 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:20 --> Input Class Initialized
INFO - 2025-03-14 20:21:20 --> Language Class Initialized
INFO - 2025-03-14 20:21:20 --> Language Class Initialized
INFO - 2025-03-14 20:21:20 --> Config Class Initialized
INFO - 2025-03-14 20:21:20 --> Loader Class Initialized
INFO - 2025-03-14 20:21:20 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:20 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:20 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:20 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:20 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:20 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:20 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:20 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:20 --> Email Class Initialized
INFO - 2025-03-14 20:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:20 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:20 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:20 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:20 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:20 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:20 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:20 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:21:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:21:20 --> Model Class Initialized
ERROR - 2025-03-14 20:21:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:21:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:21:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:21:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:21:21 --> Final output sent to browser
DEBUG - 2025-03-14 20:21:21 --> Total execution time: 0.1241
INFO - 2025-03-14 20:21:25 --> Config Class Initialized
INFO - 2025-03-14 20:21:25 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:25 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:25 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:25 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:25 --> Router Class Initialized
INFO - 2025-03-14 20:21:25 --> Output Class Initialized
INFO - 2025-03-14 20:21:25 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:25 --> Input Class Initialized
INFO - 2025-03-14 20:21:25 --> Language Class Initialized
INFO - 2025-03-14 20:21:25 --> Language Class Initialized
INFO - 2025-03-14 20:21:25 --> Config Class Initialized
INFO - 2025-03-14 20:21:25 --> Loader Class Initialized
INFO - 2025-03-14 20:21:25 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:25 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:25 --> Email Class Initialized
INFO - 2025-03-14 20:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:25 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:25 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:25 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:25 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:25 --> Model Class Initialized
INFO - 2025-03-14 20:21:25 --> Config Class Initialized
INFO - 2025-03-14 20:21:25 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:25 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:25 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:25 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:25 --> Router Class Initialized
INFO - 2025-03-14 20:21:25 --> Output Class Initialized
INFO - 2025-03-14 20:21:25 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:25 --> Input Class Initialized
INFO - 2025-03-14 20:21:25 --> Language Class Initialized
INFO - 2025-03-14 20:21:25 --> Language Class Initialized
INFO - 2025-03-14 20:21:25 --> Config Class Initialized
INFO - 2025-03-14 20:21:25 --> Loader Class Initialized
INFO - 2025-03-14 20:21:25 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:25 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:25 --> Email Class Initialized
INFO - 2025-03-14 20:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:25 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:25 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:25 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:25 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:21:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:21:25 --> Model Class Initialized
ERROR - 2025-03-14 20:21:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:21:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:21:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:21:25 --> Final output sent to browser
DEBUG - 2025-03-14 20:21:25 --> Total execution time: 0.1553
INFO - 2025-03-14 20:21:29 --> Config Class Initialized
INFO - 2025-03-14 20:21:29 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:29 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:29 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:29 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:29 --> Router Class Initialized
INFO - 2025-03-14 20:21:29 --> Output Class Initialized
INFO - 2025-03-14 20:21:29 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:29 --> Input Class Initialized
INFO - 2025-03-14 20:21:29 --> Language Class Initialized
INFO - 2025-03-14 20:21:29 --> Language Class Initialized
INFO - 2025-03-14 20:21:29 --> Config Class Initialized
INFO - 2025-03-14 20:21:29 --> Loader Class Initialized
INFO - 2025-03-14 20:21:29 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:29 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:29 --> Email Class Initialized
INFO - 2025-03-14 20:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:29 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:29 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:29 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:29 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:29 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:29 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:29 --> Model Class Initialized
INFO - 2025-03-14 20:21:29 --> Config Class Initialized
INFO - 2025-03-14 20:21:29 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:29 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:29 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:29 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:29 --> Router Class Initialized
INFO - 2025-03-14 20:21:29 --> Output Class Initialized
INFO - 2025-03-14 20:21:29 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:29 --> Input Class Initialized
INFO - 2025-03-14 20:21:29 --> Language Class Initialized
INFO - 2025-03-14 20:21:29 --> Language Class Initialized
INFO - 2025-03-14 20:21:29 --> Config Class Initialized
INFO - 2025-03-14 20:21:29 --> Loader Class Initialized
INFO - 2025-03-14 20:21:29 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:29 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:29 --> Email Class Initialized
INFO - 2025-03-14 20:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:29 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:29 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:29 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:29 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:29 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:29 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:29 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:21:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:21:29 --> Model Class Initialized
ERROR - 2025-03-14 20:21:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:21:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:21:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:21:29 --> Final output sent to browser
DEBUG - 2025-03-14 20:21:29 --> Total execution time: 0.0976
INFO - 2025-03-14 20:21:31 --> Config Class Initialized
INFO - 2025-03-14 20:21:31 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:31 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:31 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:31 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:31 --> Router Class Initialized
INFO - 2025-03-14 20:21:31 --> Output Class Initialized
INFO - 2025-03-14 20:21:31 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:31 --> Input Class Initialized
INFO - 2025-03-14 20:21:31 --> Language Class Initialized
INFO - 2025-03-14 20:21:31 --> Language Class Initialized
INFO - 2025-03-14 20:21:31 --> Config Class Initialized
INFO - 2025-03-14 20:21:31 --> Loader Class Initialized
INFO - 2025-03-14 20:21:31 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:31 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:31 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:31 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:31 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:31 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:31 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:31 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:31 --> Email Class Initialized
INFO - 2025-03-14 20:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:31 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:31 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:31 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:31 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:31 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:31 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:31 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:31 --> DEBUG: Final Category Name -> 
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:21:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:21:31 --> Model Class Initialized
ERROR - 2025-03-14 20:21:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:21:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:21:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:21:31 --> Final output sent to browser
DEBUG - 2025-03-14 20:21:31 --> Total execution time: 0.2044
INFO - 2025-03-14 20:21:39 --> Config Class Initialized
INFO - 2025-03-14 20:21:39 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:21:39 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:21:39 --> Utf8 Class Initialized
INFO - 2025-03-14 20:21:39 --> URI Class Initialized
DEBUG - 2025-03-14 20:21:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:21:39 --> Router Class Initialized
INFO - 2025-03-14 20:21:39 --> Output Class Initialized
INFO - 2025-03-14 20:21:39 --> Security Class Initialized
DEBUG - 2025-03-14 20:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:21:39 --> Input Class Initialized
INFO - 2025-03-14 20:21:39 --> Language Class Initialized
INFO - 2025-03-14 20:21:39 --> Language Class Initialized
INFO - 2025-03-14 20:21:39 --> Config Class Initialized
INFO - 2025-03-14 20:21:39 --> Loader Class Initialized
INFO - 2025-03-14 20:21:39 --> Helper loaded: url_helper
INFO - 2025-03-14 20:21:39 --> Helper loaded: file_helper
INFO - 2025-03-14 20:21:39 --> Helper loaded: html_helper
INFO - 2025-03-14 20:21:39 --> Helper loaded: form_helper
INFO - 2025-03-14 20:21:39 --> Helper loaded: text_helper
INFO - 2025-03-14 20:21:39 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:21:39 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:21:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:21:39 --> Database Driver Class Initialized
INFO - 2025-03-14 20:21:39 --> Email Class Initialized
INFO - 2025-03-14 20:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:21:39 --> Form Validation Class Initialized
INFO - 2025-03-14 20:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:21:39 --> Pagination Class Initialized
INFO - 2025-03-14 20:21:39 --> Controller Class Initialized
DEBUG - 2025-03-14 20:21:39 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:21:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:21:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:21:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:21:39 --> Model Class Initialized
INFO - 2025-03-14 20:21:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-14 20:21:39 --> DEBUG: Final Category Name -> Import->Import->Test1->ChieldTest1
INFO - 2025-03-14 20:23:36 --> Config Class Initialized
INFO - 2025-03-14 20:23:36 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:23:36 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:23:36 --> Utf8 Class Initialized
INFO - 2025-03-14 20:23:36 --> URI Class Initialized
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:23:36 --> Router Class Initialized
INFO - 2025-03-14 20:23:36 --> Output Class Initialized
INFO - 2025-03-14 20:23:36 --> Security Class Initialized
DEBUG - 2025-03-14 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:23:36 --> Input Class Initialized
INFO - 2025-03-14 20:23:36 --> Language Class Initialized
INFO - 2025-03-14 20:23:36 --> Language Class Initialized
INFO - 2025-03-14 20:23:36 --> Config Class Initialized
INFO - 2025-03-14 20:23:36 --> Loader Class Initialized
INFO - 2025-03-14 20:23:36 --> Helper loaded: url_helper
INFO - 2025-03-14 20:23:36 --> Helper loaded: file_helper
INFO - 2025-03-14 20:23:36 --> Helper loaded: html_helper
INFO - 2025-03-14 20:23:36 --> Helper loaded: form_helper
INFO - 2025-03-14 20:23:36 --> Helper loaded: text_helper
INFO - 2025-03-14 20:23:36 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:23:36 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:23:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:23:36 --> Database Driver Class Initialized
INFO - 2025-03-14 20:23:36 --> Email Class Initialized
INFO - 2025-03-14 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:23:36 --> Form Validation Class Initialized
INFO - 2025-03-14 20:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:23:36 --> Pagination Class Initialized
INFO - 2025-03-14 20:23:36 --> Controller Class Initialized
DEBUG - 2025-03-14 20:23:36 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:23:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:23:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:23:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:36 --> DEBUG: Final Category Name -> 
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:23:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:23:36 --> Model Class Initialized
ERROR - 2025-03-14 20:23:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:23:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:23:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:23:36 --> Final output sent to browser
DEBUG - 2025-03-14 20:23:36 --> Total execution time: 0.1458
INFO - 2025-03-14 20:23:38 --> Config Class Initialized
INFO - 2025-03-14 20:23:38 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:23:38 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:23:38 --> Utf8 Class Initialized
INFO - 2025-03-14 20:23:38 --> URI Class Initialized
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:23:38 --> Router Class Initialized
INFO - 2025-03-14 20:23:38 --> Output Class Initialized
INFO - 2025-03-14 20:23:38 --> Security Class Initialized
DEBUG - 2025-03-14 20:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:23:38 --> Input Class Initialized
INFO - 2025-03-14 20:23:38 --> Language Class Initialized
INFO - 2025-03-14 20:23:38 --> Language Class Initialized
INFO - 2025-03-14 20:23:38 --> Config Class Initialized
INFO - 2025-03-14 20:23:38 --> Loader Class Initialized
INFO - 2025-03-14 20:23:38 --> Helper loaded: url_helper
INFO - 2025-03-14 20:23:38 --> Helper loaded: file_helper
INFO - 2025-03-14 20:23:38 --> Helper loaded: html_helper
INFO - 2025-03-14 20:23:38 --> Helper loaded: form_helper
INFO - 2025-03-14 20:23:38 --> Helper loaded: text_helper
INFO - 2025-03-14 20:23:38 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:23:38 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:23:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:23:38 --> Database Driver Class Initialized
INFO - 2025-03-14 20:23:38 --> Email Class Initialized
INFO - 2025-03-14 20:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:23:38 --> Form Validation Class Initialized
INFO - 2025-03-14 20:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:23:38 --> Pagination Class Initialized
INFO - 2025-03-14 20:23:38 --> Controller Class Initialized
DEBUG - 2025-03-14 20:23:38 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:23:38 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:23:38 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:23:38 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:23:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:23:38 --> Model Class Initialized
ERROR - 2025-03-14 20:23:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:23:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:23:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:23:38 --> Final output sent to browser
DEBUG - 2025-03-14 20:23:38 --> Total execution time: 0.1747
INFO - 2025-03-14 20:23:44 --> Config Class Initialized
INFO - 2025-03-14 20:23:44 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:23:44 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:23:44 --> Utf8 Class Initialized
INFO - 2025-03-14 20:23:44 --> URI Class Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:23:44 --> Router Class Initialized
INFO - 2025-03-14 20:23:44 --> Output Class Initialized
INFO - 2025-03-14 20:23:44 --> Security Class Initialized
DEBUG - 2025-03-14 20:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:23:44 --> Input Class Initialized
INFO - 2025-03-14 20:23:44 --> Language Class Initialized
INFO - 2025-03-14 20:23:44 --> Language Class Initialized
INFO - 2025-03-14 20:23:44 --> Config Class Initialized
INFO - 2025-03-14 20:23:44 --> Loader Class Initialized
INFO - 2025-03-14 20:23:44 --> Helper loaded: url_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: file_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: html_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: form_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: text_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:23:44 --> Database Driver Class Initialized
INFO - 2025-03-14 20:23:44 --> Email Class Initialized
INFO - 2025-03-14 20:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:23:44 --> Form Validation Class Initialized
INFO - 2025-03-14 20:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:23:44 --> Pagination Class Initialized
INFO - 2025-03-14 20:23:44 --> Controller Class Initialized
DEBUG - 2025-03-14 20:23:44 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:23:44 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:23:44 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:23:44 --> Model Class Initialized
INFO - 2025-03-14 20:23:44 --> Config Class Initialized
INFO - 2025-03-14 20:23:44 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:23:44 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:23:44 --> Utf8 Class Initialized
INFO - 2025-03-14 20:23:44 --> URI Class Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:23:44 --> Router Class Initialized
INFO - 2025-03-14 20:23:44 --> Output Class Initialized
INFO - 2025-03-14 20:23:44 --> Security Class Initialized
DEBUG - 2025-03-14 20:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:23:44 --> Input Class Initialized
INFO - 2025-03-14 20:23:44 --> Language Class Initialized
INFO - 2025-03-14 20:23:44 --> Language Class Initialized
INFO - 2025-03-14 20:23:44 --> Config Class Initialized
INFO - 2025-03-14 20:23:44 --> Loader Class Initialized
INFO - 2025-03-14 20:23:44 --> Helper loaded: url_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: file_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: html_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: form_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: text_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:23:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:23:44 --> Database Driver Class Initialized
INFO - 2025-03-14 20:23:44 --> Email Class Initialized
INFO - 2025-03-14 20:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:23:44 --> Form Validation Class Initialized
INFO - 2025-03-14 20:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:23:44 --> Pagination Class Initialized
INFO - 2025-03-14 20:23:44 --> Controller Class Initialized
DEBUG - 2025-03-14 20:23:44 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:23:44 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:23:44 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:23:44 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:23:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:23:44 --> Model Class Initialized
ERROR - 2025-03-14 20:23:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:23:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:23:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:23:44 --> Final output sent to browser
DEBUG - 2025-03-14 20:23:44 --> Total execution time: 0.1710
INFO - 2025-03-14 20:23:47 --> Config Class Initialized
INFO - 2025-03-14 20:23:47 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:23:47 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:23:47 --> Utf8 Class Initialized
INFO - 2025-03-14 20:23:47 --> URI Class Initialized
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:23:47 --> Router Class Initialized
INFO - 2025-03-14 20:23:47 --> Output Class Initialized
INFO - 2025-03-14 20:23:47 --> Security Class Initialized
DEBUG - 2025-03-14 20:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:23:47 --> Input Class Initialized
INFO - 2025-03-14 20:23:47 --> Language Class Initialized
INFO - 2025-03-14 20:23:47 --> Language Class Initialized
INFO - 2025-03-14 20:23:47 --> Config Class Initialized
INFO - 2025-03-14 20:23:47 --> Loader Class Initialized
INFO - 2025-03-14 20:23:47 --> Helper loaded: url_helper
INFO - 2025-03-14 20:23:47 --> Helper loaded: file_helper
INFO - 2025-03-14 20:23:47 --> Helper loaded: html_helper
INFO - 2025-03-14 20:23:47 --> Helper loaded: form_helper
INFO - 2025-03-14 20:23:47 --> Helper loaded: text_helper
INFO - 2025-03-14 20:23:47 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:23:47 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:23:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:23:47 --> Database Driver Class Initialized
INFO - 2025-03-14 20:23:47 --> Email Class Initialized
INFO - 2025-03-14 20:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:23:47 --> Form Validation Class Initialized
INFO - 2025-03-14 20:23:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:23:47 --> Pagination Class Initialized
INFO - 2025-03-14 20:23:47 --> Controller Class Initialized
DEBUG - 2025-03-14 20:23:47 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:23:47 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:23:47 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:23:47 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:47 --> DEBUG: Final Category Name -> 
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:23:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:23:47 --> Model Class Initialized
ERROR - 2025-03-14 20:23:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:23:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:23:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:23:47 --> Final output sent to browser
DEBUG - 2025-03-14 20:23:47 --> Total execution time: 0.0925
INFO - 2025-03-14 20:23:57 --> Config Class Initialized
INFO - 2025-03-14 20:23:57 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:23:57 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:23:57 --> Utf8 Class Initialized
INFO - 2025-03-14 20:23:57 --> URI Class Initialized
DEBUG - 2025-03-14 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:23:57 --> Router Class Initialized
INFO - 2025-03-14 20:23:57 --> Output Class Initialized
INFO - 2025-03-14 20:23:57 --> Security Class Initialized
DEBUG - 2025-03-14 20:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:23:57 --> Input Class Initialized
INFO - 2025-03-14 20:23:57 --> Language Class Initialized
INFO - 2025-03-14 20:23:57 --> Language Class Initialized
INFO - 2025-03-14 20:23:57 --> Config Class Initialized
INFO - 2025-03-14 20:23:57 --> Loader Class Initialized
INFO - 2025-03-14 20:23:57 --> Helper loaded: url_helper
INFO - 2025-03-14 20:23:57 --> Helper loaded: file_helper
INFO - 2025-03-14 20:23:57 --> Helper loaded: html_helper
INFO - 2025-03-14 20:23:57 --> Helper loaded: form_helper
INFO - 2025-03-14 20:23:57 --> Helper loaded: text_helper
INFO - 2025-03-14 20:23:57 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:23:57 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:23:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:23:57 --> Database Driver Class Initialized
INFO - 2025-03-14 20:23:57 --> Email Class Initialized
INFO - 2025-03-14 20:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:23:57 --> Form Validation Class Initialized
INFO - 2025-03-14 20:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:23:57 --> Pagination Class Initialized
INFO - 2025-03-14 20:23:57 --> Controller Class Initialized
DEBUG - 2025-03-14 20:23:57 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:23:57 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:23:57 --> Model Class Initialized
DEBUG - 2025-03-14 20:23:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:23:57 --> Model Class Initialized
INFO - 2025-03-14 20:23:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-14 20:23:57 --> DEBUG: Final Category Name -> Import->Import->Test1->ChieldTest1
INFO - 2025-03-14 20:30:37 --> Config Class Initialized
INFO - 2025-03-14 20:30:37 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:30:37 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:30:37 --> Utf8 Class Initialized
INFO - 2025-03-14 20:30:37 --> URI Class Initialized
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:30:37 --> Router Class Initialized
INFO - 2025-03-14 20:30:37 --> Output Class Initialized
INFO - 2025-03-14 20:30:37 --> Security Class Initialized
DEBUG - 2025-03-14 20:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:30:37 --> Input Class Initialized
INFO - 2025-03-14 20:30:37 --> Language Class Initialized
INFO - 2025-03-14 20:30:37 --> Language Class Initialized
INFO - 2025-03-14 20:30:37 --> Config Class Initialized
INFO - 2025-03-14 20:30:37 --> Loader Class Initialized
INFO - 2025-03-14 20:30:37 --> Helper loaded: url_helper
INFO - 2025-03-14 20:30:37 --> Helper loaded: file_helper
INFO - 2025-03-14 20:30:37 --> Helper loaded: html_helper
INFO - 2025-03-14 20:30:37 --> Helper loaded: form_helper
INFO - 2025-03-14 20:30:37 --> Helper loaded: text_helper
INFO - 2025-03-14 20:30:37 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:30:37 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:30:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:30:37 --> Database Driver Class Initialized
INFO - 2025-03-14 20:30:37 --> Email Class Initialized
INFO - 2025-03-14 20:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:30:37 --> Form Validation Class Initialized
INFO - 2025-03-14 20:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:30:37 --> Pagination Class Initialized
INFO - 2025-03-14 20:30:37 --> Controller Class Initialized
DEBUG - 2025-03-14 20:30:37 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:30:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:30:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:30:37 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Form Data -> []
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Selected Parent ID -> 
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entered Subcategory Name -> 
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Parent Category Level -> 1
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Parent Category Hierarchy -> 
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Category Name Before Saving -> 
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Data to be Inserted/Updated -> {"category_id":null,"category_name":"","parent_id":null,"status":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"30","category_name":"Import->Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:30:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:30:37 --> Model Class Initialized
ERROR - 2025-03-14 20:30:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:30:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 1
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Juice","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Juice
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 3
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Fishs","parent_id":"2"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Frozen->Fishs
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 6
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"River Fish","parent_id":"3"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 3
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Fishs","parent_id":"2"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Frozen->Fishs
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Frozen->Fishs->River Fish
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 8
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Fish","parent_id":"7"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import->Fish
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 18
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import->Test1","parent_id":"7"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import->Import->Test1
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 9
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Sea Fish","parent_id":"8"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 8
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Fish","parent_id":"7"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import->Fish
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import->Fish->Sea Fish
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 30
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import->Import->Test1->ChieldTest1","parent_id":"18"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 18
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import->Test1","parent_id":"7"}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import->Import->Test1
DEBUG - 2025-03-14 20:30:37 --> DEBUG: Final Computed Category Name -> Import->Import->Test1->Import->Import->Test1->ChieldTest1
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:30:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:30:37 --> Final output sent to browser
DEBUG - 2025-03-14 20:30:37 --> Total execution time: 0.1237
INFO - 2025-03-14 20:30:39 --> Config Class Initialized
INFO - 2025-03-14 20:30:39 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:30:39 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:30:39 --> Utf8 Class Initialized
INFO - 2025-03-14 20:30:39 --> URI Class Initialized
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:30:39 --> Router Class Initialized
INFO - 2025-03-14 20:30:39 --> Output Class Initialized
INFO - 2025-03-14 20:30:39 --> Security Class Initialized
DEBUG - 2025-03-14 20:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:30:39 --> Input Class Initialized
INFO - 2025-03-14 20:30:39 --> Language Class Initialized
INFO - 2025-03-14 20:30:39 --> Language Class Initialized
INFO - 2025-03-14 20:30:39 --> Config Class Initialized
INFO - 2025-03-14 20:30:39 --> Loader Class Initialized
INFO - 2025-03-14 20:30:39 --> Helper loaded: url_helper
INFO - 2025-03-14 20:30:39 --> Helper loaded: file_helper
INFO - 2025-03-14 20:30:39 --> Helper loaded: html_helper
INFO - 2025-03-14 20:30:39 --> Helper loaded: form_helper
INFO - 2025-03-14 20:30:39 --> Helper loaded: text_helper
INFO - 2025-03-14 20:30:39 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:30:39 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:30:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:30:39 --> Database Driver Class Initialized
INFO - 2025-03-14 20:30:39 --> Email Class Initialized
INFO - 2025-03-14 20:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:30:39 --> Form Validation Class Initialized
INFO - 2025-03-14 20:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:30:39 --> Pagination Class Initialized
INFO - 2025-03-14 20:30:39 --> Controller Class Initialized
DEBUG - 2025-03-14 20:30:39 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:30:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:30:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:30:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:30:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:30:39 --> Model Class Initialized
ERROR - 2025-03-14 20:30:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:30:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:30:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:30:39 --> Final output sent to browser
DEBUG - 2025-03-14 20:30:39 --> Total execution time: 0.1729
INFO - 2025-03-14 20:30:43 --> Config Class Initialized
INFO - 2025-03-14 20:30:43 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:30:43 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:30:43 --> Utf8 Class Initialized
INFO - 2025-03-14 20:30:43 --> URI Class Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:30:43 --> Router Class Initialized
INFO - 2025-03-14 20:30:43 --> Output Class Initialized
INFO - 2025-03-14 20:30:43 --> Security Class Initialized
DEBUG - 2025-03-14 20:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:30:43 --> Input Class Initialized
INFO - 2025-03-14 20:30:43 --> Language Class Initialized
INFO - 2025-03-14 20:30:43 --> Language Class Initialized
INFO - 2025-03-14 20:30:43 --> Config Class Initialized
INFO - 2025-03-14 20:30:43 --> Loader Class Initialized
INFO - 2025-03-14 20:30:43 --> Helper loaded: url_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: file_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: html_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: form_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: text_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:30:43 --> Database Driver Class Initialized
INFO - 2025-03-14 20:30:43 --> Email Class Initialized
INFO - 2025-03-14 20:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:30:43 --> Form Validation Class Initialized
INFO - 2025-03-14 20:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:30:43 --> Pagination Class Initialized
INFO - 2025-03-14 20:30:43 --> Controller Class Initialized
DEBUG - 2025-03-14 20:30:43 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:30:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:30:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:30:43 --> Model Class Initialized
INFO - 2025-03-14 20:30:43 --> Config Class Initialized
INFO - 2025-03-14 20:30:43 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:30:43 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:30:43 --> Utf8 Class Initialized
INFO - 2025-03-14 20:30:43 --> URI Class Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:30:43 --> Router Class Initialized
INFO - 2025-03-14 20:30:43 --> Output Class Initialized
INFO - 2025-03-14 20:30:43 --> Security Class Initialized
DEBUG - 2025-03-14 20:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:30:43 --> Input Class Initialized
INFO - 2025-03-14 20:30:43 --> Language Class Initialized
INFO - 2025-03-14 20:30:43 --> Language Class Initialized
INFO - 2025-03-14 20:30:43 --> Config Class Initialized
INFO - 2025-03-14 20:30:43 --> Loader Class Initialized
INFO - 2025-03-14 20:30:43 --> Helper loaded: url_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: file_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: html_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: form_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: text_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:30:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:30:43 --> Database Driver Class Initialized
INFO - 2025-03-14 20:30:43 --> Email Class Initialized
INFO - 2025-03-14 20:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:30:43 --> Form Validation Class Initialized
INFO - 2025-03-14 20:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:30:43 --> Pagination Class Initialized
INFO - 2025-03-14 20:30:43 --> Controller Class Initialized
DEBUG - 2025-03-14 20:30:43 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:30:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:30:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:30:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:30:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:30:43 --> Model Class Initialized
ERROR - 2025-03-14 20:30:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:30:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:30:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:30:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:30:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:30:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:30:44 --> Final output sent to browser
DEBUG - 2025-03-14 20:30:44 --> Total execution time: 0.1721
INFO - 2025-03-14 20:31:19 --> Config Class Initialized
INFO - 2025-03-14 20:31:19 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:31:19 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:31:19 --> Utf8 Class Initialized
INFO - 2025-03-14 20:31:19 --> URI Class Initialized
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:31:19 --> Router Class Initialized
INFO - 2025-03-14 20:31:19 --> Output Class Initialized
INFO - 2025-03-14 20:31:19 --> Security Class Initialized
DEBUG - 2025-03-14 20:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:31:19 --> Input Class Initialized
INFO - 2025-03-14 20:31:19 --> Language Class Initialized
INFO - 2025-03-14 20:31:19 --> Language Class Initialized
INFO - 2025-03-14 20:31:19 --> Config Class Initialized
INFO - 2025-03-14 20:31:19 --> Loader Class Initialized
INFO - 2025-03-14 20:31:19 --> Helper loaded: url_helper
INFO - 2025-03-14 20:31:19 --> Helper loaded: file_helper
INFO - 2025-03-14 20:31:19 --> Helper loaded: html_helper
INFO - 2025-03-14 20:31:19 --> Helper loaded: form_helper
INFO - 2025-03-14 20:31:19 --> Helper loaded: text_helper
INFO - 2025-03-14 20:31:19 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:31:19 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:31:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:31:19 --> Database Driver Class Initialized
INFO - 2025-03-14 20:31:19 --> Email Class Initialized
INFO - 2025-03-14 20:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:31:19 --> Form Validation Class Initialized
INFO - 2025-03-14 20:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:31:19 --> Pagination Class Initialized
INFO - 2025-03-14 20:31:19 --> Controller Class Initialized
DEBUG - 2025-03-14 20:31:19 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:31:19 --> Model Class Initialized
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:31:19 --> Model Class Initialized
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:31:19 --> Model Class Initialized
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Form Data -> []
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Selected Parent ID -> 
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entered Subcategory Name -> 
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Parent Category Level -> 1
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Parent Category Hierarchy -> 
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Category Name Before Saving -> 
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Data to be Inserted/Updated -> {"category_id":null,"category_name":"","parent_id":null,"status":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:31:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:31:19 --> Model Class Initialized
ERROR - 2025-03-14 20:31:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:31:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 1
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Juice","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Juice
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 3
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Fishs","parent_id":"2"}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Frozen->Fishs
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 6
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"River Fish","parent_id":"3"}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 3
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Fishs","parent_id":"2"}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Frozen->Fishs
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Frozen->Fishs->River Fish
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 8
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Fish","parent_id":"7"}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import->Fish
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 18
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Import->Test1","parent_id":"7"}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import->Import->Test1
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 9
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Sea Fish","parent_id":"8"}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 8
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Fish","parent_id":"7"}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import->Fish
DEBUG - 2025-03-14 20:31:19 --> DEBUG: Final Computed Category Name -> Import->Fish->Sea Fish
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:31:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:31:19 --> Final output sent to browser
DEBUG - 2025-03-14 20:31:19 --> Total execution time: 0.2012
INFO - 2025-03-14 20:32:05 --> Config Class Initialized
INFO - 2025-03-14 20:32:05 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:32:05 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:32:05 --> Utf8 Class Initialized
INFO - 2025-03-14 20:32:05 --> URI Class Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:32:05 --> Router Class Initialized
INFO - 2025-03-14 20:32:05 --> Output Class Initialized
INFO - 2025-03-14 20:32:05 --> Security Class Initialized
DEBUG - 2025-03-14 20:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:32:05 --> Input Class Initialized
INFO - 2025-03-14 20:32:05 --> Language Class Initialized
INFO - 2025-03-14 20:32:05 --> Language Class Initialized
INFO - 2025-03-14 20:32:05 --> Config Class Initialized
INFO - 2025-03-14 20:32:05 --> Loader Class Initialized
INFO - 2025-03-14 20:32:05 --> Helper loaded: url_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: file_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: html_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: form_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: text_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:32:05 --> Database Driver Class Initialized
INFO - 2025-03-14 20:32:05 --> Email Class Initialized
INFO - 2025-03-14 20:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:32:05 --> Form Validation Class Initialized
INFO - 2025-03-14 20:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:32:05 --> Pagination Class Initialized
INFO - 2025-03-14 20:32:05 --> Controller Class Initialized
DEBUG - 2025-03-14 20:32:05 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:32:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:32:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:32:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Form Data -> {"category_id":"","final_category_name":"Import->Import->Test1->ChieldTest1","category_name":"ChieldTest1","parent_id":"18","status":"1"}
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Selected Parent ID -> 18
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Entered Subcategory Name -> ChieldTest1
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Parent Category Level -> 2
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Entering get_category_name() for category_id: 18
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Retrieved Category -> {"category_name":"Import->Test1","parent_id":"7"}
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Final Computed Category Name -> Import->Import->Test1
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Parent Category Hierarchy -> Import->Import->Test1
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Final Category Name Before Saving -> Import->Import->Test1->ChieldTest1
DEBUG - 2025-03-14 20:32:05 --> DEBUG: Data to be Inserted/Updated -> {"category_id":null,"category_name":"Import->Import->Test1->ChieldTest1","parent_id":"18","status":"1"}
INFO - 2025-03-14 20:32:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 20:32:05 --> INFO: Category Created Successfully -> Import->Import->Test1->ChieldTest1
INFO - 2025-03-14 20:32:05 --> Config Class Initialized
INFO - 2025-03-14 20:32:05 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:32:05 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:32:05 --> Utf8 Class Initialized
INFO - 2025-03-14 20:32:05 --> URI Class Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:32:05 --> Router Class Initialized
INFO - 2025-03-14 20:32:05 --> Output Class Initialized
INFO - 2025-03-14 20:32:05 --> Security Class Initialized
DEBUG - 2025-03-14 20:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:32:05 --> Input Class Initialized
INFO - 2025-03-14 20:32:05 --> Language Class Initialized
INFO - 2025-03-14 20:32:05 --> Language Class Initialized
INFO - 2025-03-14 20:32:05 --> Config Class Initialized
INFO - 2025-03-14 20:32:05 --> Loader Class Initialized
INFO - 2025-03-14 20:32:05 --> Helper loaded: url_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: file_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: html_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: form_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: text_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:32:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:32:05 --> Database Driver Class Initialized
INFO - 2025-03-14 20:32:05 --> Email Class Initialized
INFO - 2025-03-14 20:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:32:05 --> Form Validation Class Initialized
INFO - 2025-03-14 20:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:32:05 --> Pagination Class Initialized
INFO - 2025-03-14 20:32:05 --> Controller Class Initialized
DEBUG - 2025-03-14 20:32:05 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:32:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:32:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:32:05 --> Model Class Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:32:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:32:05 --> Model Class Initialized
ERROR - 2025-03-14 20:32:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:32:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:32:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:32:05 --> Final output sent to browser
DEBUG - 2025-03-14 20:32:05 --> Total execution time: 0.1580
INFO - 2025-03-14 20:38:00 --> Config Class Initialized
INFO - 2025-03-14 20:38:00 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:38:00 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:38:00 --> Utf8 Class Initialized
INFO - 2025-03-14 20:38:00 --> URI Class Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:38:00 --> Router Class Initialized
INFO - 2025-03-14 20:38:00 --> Output Class Initialized
INFO - 2025-03-14 20:38:00 --> Security Class Initialized
DEBUG - 2025-03-14 20:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:38:00 --> Input Class Initialized
INFO - 2025-03-14 20:38:00 --> Language Class Initialized
INFO - 2025-03-14 20:38:00 --> Language Class Initialized
INFO - 2025-03-14 20:38:00 --> Config Class Initialized
INFO - 2025-03-14 20:38:00 --> Loader Class Initialized
INFO - 2025-03-14 20:38:00 --> Helper loaded: url_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: file_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: html_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: form_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: text_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:38:00 --> Database Driver Class Initialized
INFO - 2025-03-14 20:38:00 --> Email Class Initialized
INFO - 2025-03-14 20:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:38:00 --> Form Validation Class Initialized
INFO - 2025-03-14 20:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:38:00 --> Pagination Class Initialized
INFO - 2025-03-14 20:38:00 --> Controller Class Initialized
DEBUG - 2025-03-14 20:38:00 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:38:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:38:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:38:00 --> Model Class Initialized
INFO - 2025-03-14 20:38:00 --> Config Class Initialized
INFO - 2025-03-14 20:38:00 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:38:00 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:38:00 --> Utf8 Class Initialized
INFO - 2025-03-14 20:38:00 --> URI Class Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:38:00 --> Router Class Initialized
INFO - 2025-03-14 20:38:00 --> Output Class Initialized
INFO - 2025-03-14 20:38:00 --> Security Class Initialized
DEBUG - 2025-03-14 20:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:38:00 --> Input Class Initialized
INFO - 2025-03-14 20:38:00 --> Language Class Initialized
INFO - 2025-03-14 20:38:00 --> Language Class Initialized
INFO - 2025-03-14 20:38:00 --> Config Class Initialized
INFO - 2025-03-14 20:38:00 --> Loader Class Initialized
INFO - 2025-03-14 20:38:00 --> Helper loaded: url_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: file_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: html_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: form_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: text_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:38:00 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:38:00 --> Database Driver Class Initialized
INFO - 2025-03-14 20:38:00 --> Email Class Initialized
INFO - 2025-03-14 20:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:38:00 --> Form Validation Class Initialized
INFO - 2025-03-14 20:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:38:00 --> Pagination Class Initialized
INFO - 2025-03-14 20:38:00 --> Controller Class Initialized
DEBUG - 2025-03-14 20:38:00 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:38:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:38:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:38:00 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:38:00 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:38:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:38:00 --> Model Class Initialized
ERROR - 2025-03-14 20:38:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:38:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:38:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:38:01 --> Final output sent to browser
DEBUG - 2025-03-14 20:38:01 --> Total execution time: 0.2541
INFO - 2025-03-14 20:38:06 --> Config Class Initialized
INFO - 2025-03-14 20:38:06 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:38:06 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:38:06 --> Utf8 Class Initialized
INFO - 2025-03-14 20:38:06 --> URI Class Initialized
DEBUG - 2025-03-14 20:38:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:38:06 --> Router Class Initialized
INFO - 2025-03-14 20:38:06 --> Output Class Initialized
INFO - 2025-03-14 20:38:06 --> Security Class Initialized
DEBUG - 2025-03-14 20:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:38:06 --> Input Class Initialized
INFO - 2025-03-14 20:38:06 --> Language Class Initialized
INFO - 2025-03-14 20:38:06 --> Language Class Initialized
INFO - 2025-03-14 20:38:06 --> Config Class Initialized
INFO - 2025-03-14 20:38:06 --> Loader Class Initialized
INFO - 2025-03-14 20:38:06 --> Helper loaded: url_helper
INFO - 2025-03-14 20:38:06 --> Helper loaded: file_helper
INFO - 2025-03-14 20:38:06 --> Helper loaded: html_helper
INFO - 2025-03-14 20:38:06 --> Helper loaded: form_helper
INFO - 2025-03-14 20:38:06 --> Helper loaded: text_helper
INFO - 2025-03-14 20:38:06 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:38:06 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:38:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:38:06 --> Database Driver Class Initialized
INFO - 2025-03-14 20:38:06 --> Email Class Initialized
INFO - 2025-03-14 20:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:38:06 --> Form Validation Class Initialized
INFO - 2025-03-14 20:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:38:06 --> Pagination Class Initialized
INFO - 2025-03-14 20:38:06 --> Controller Class Initialized
DEBUG - 2025-03-14 20:38:06 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:38:06 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:38:06 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:38:06 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Form Data -> []
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Selected Parent ID -> 
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Entered Subcategory Name -> 
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Parent Category Level -> 1
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Parent Category Hierarchy -> 
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Final Category Name Before Saving -> 
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Data to be Inserted/Updated -> {"category_id":null,"category_name":"","parent_id":null,"status":null}
DEBUG - 2025-03-14 20:38:06 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:38:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:38:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:38:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:38:06 --> Model Class Initialized
ERROR - 2025-03-14 20:38:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:38:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:38:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:38:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 1
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Juice","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Juice
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 3
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Fishs","parent_id":"2"}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Frozen->Fishs
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 6
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"River Fish","parent_id":"3"}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 3
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Fishs","parent_id":"2"}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 2
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Frozen","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Frozen
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Frozen->Fishs
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Frozen->Fishs->River Fish
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 8
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Fish","parent_id":"7"}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import->Fish
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 18
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Import->Test1","parent_id":"7"}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import->Import->Test1
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 9
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Sea Fish","parent_id":"8"}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 8
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Fish","parent_id":"7"}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import->Fish
DEBUG - 2025-03-14 20:38:07 --> DEBUG: Final Computed Category Name -> Import->Fish->Sea Fish
DEBUG - 2025-03-14 20:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:38:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:38:07 --> Final output sent to browser
DEBUG - 2025-03-14 20:38:07 --> Total execution time: 0.1842
INFO - 2025-03-14 20:38:16 --> Config Class Initialized
INFO - 2025-03-14 20:38:16 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:38:16 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:38:16 --> Utf8 Class Initialized
INFO - 2025-03-14 20:38:16 --> URI Class Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:38:16 --> Router Class Initialized
INFO - 2025-03-14 20:38:16 --> Output Class Initialized
INFO - 2025-03-14 20:38:16 --> Security Class Initialized
DEBUG - 2025-03-14 20:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:38:16 --> Input Class Initialized
INFO - 2025-03-14 20:38:16 --> Language Class Initialized
INFO - 2025-03-14 20:38:16 --> Language Class Initialized
INFO - 2025-03-14 20:38:16 --> Config Class Initialized
INFO - 2025-03-14 20:38:16 --> Loader Class Initialized
INFO - 2025-03-14 20:38:16 --> Helper loaded: url_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: file_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: html_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: form_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: text_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:38:16 --> Database Driver Class Initialized
INFO - 2025-03-14 20:38:16 --> Email Class Initialized
INFO - 2025-03-14 20:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:38:16 --> Form Validation Class Initialized
INFO - 2025-03-14 20:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:38:16 --> Pagination Class Initialized
INFO - 2025-03-14 20:38:16 --> Controller Class Initialized
DEBUG - 2025-03-14 20:38:16 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:38:16 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:38:16 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:38:16 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Form Data -> {"category_id":"","final_category_name":"Import->Import->Test1->ChieldTest1","category_name":"ChieldTest1","parent_id":"18","status":"1"}
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Selected Parent ID -> 18
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Entered Subcategory Name -> ChieldTest1
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Parent Category Level -> 2
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Entering get_category_name() for category_id: 18
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Retrieved Category -> {"category_name":"Import->Test1","parent_id":"7"}
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Entering get_category_name() for category_id: 7
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Retrieved Category -> {"category_name":"Import","parent_id":null}
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Final Computed Category Name -> Import
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Final Computed Category Name -> Import->Import->Test1
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Parent Category Hierarchy -> Import->Import->Test1
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Final Category Name Before Saving -> Import->Import->Test1->ChieldTest1
DEBUG - 2025-03-14 20:38:16 --> DEBUG: Data to be Inserted/Updated -> {"category_id":null,"category_name":"Import->Import->Test1->ChieldTest1","parent_id":"18","status":"1"}
INFO - 2025-03-14 20:38:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 20:38:16 --> INFO: Category Created Successfully -> Import->Import->Test1->ChieldTest1
INFO - 2025-03-14 20:38:16 --> Config Class Initialized
INFO - 2025-03-14 20:38:16 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:38:16 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:38:16 --> Utf8 Class Initialized
INFO - 2025-03-14 20:38:16 --> URI Class Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:38:16 --> Router Class Initialized
INFO - 2025-03-14 20:38:16 --> Output Class Initialized
INFO - 2025-03-14 20:38:16 --> Security Class Initialized
DEBUG - 2025-03-14 20:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:38:16 --> Input Class Initialized
INFO - 2025-03-14 20:38:16 --> Language Class Initialized
INFO - 2025-03-14 20:38:16 --> Language Class Initialized
INFO - 2025-03-14 20:38:16 --> Config Class Initialized
INFO - 2025-03-14 20:38:16 --> Loader Class Initialized
INFO - 2025-03-14 20:38:16 --> Helper loaded: url_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: file_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: html_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: form_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: text_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:38:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:38:16 --> Database Driver Class Initialized
INFO - 2025-03-14 20:38:16 --> Email Class Initialized
INFO - 2025-03-14 20:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:38:16 --> Form Validation Class Initialized
INFO - 2025-03-14 20:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:38:16 --> Pagination Class Initialized
INFO - 2025-03-14 20:38:16 --> Controller Class Initialized
DEBUG - 2025-03-14 20:38:16 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:38:16 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:38:16 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:38:16 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:38:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:38:16 --> Model Class Initialized
ERROR - 2025-03-14 20:38:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:38:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:38:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:38:16 --> Final output sent to browser
DEBUG - 2025-03-14 20:38:16 --> Total execution time: 0.1013
INFO - 2025-03-14 20:38:22 --> Config Class Initialized
INFO - 2025-03-14 20:38:22 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:38:22 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:38:22 --> Utf8 Class Initialized
INFO - 2025-03-14 20:38:22 --> URI Class Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:38:22 --> Router Class Initialized
INFO - 2025-03-14 20:38:22 --> Output Class Initialized
INFO - 2025-03-14 20:38:22 --> Security Class Initialized
DEBUG - 2025-03-14 20:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:38:22 --> Input Class Initialized
INFO - 2025-03-14 20:38:22 --> Language Class Initialized
INFO - 2025-03-14 20:38:22 --> Language Class Initialized
INFO - 2025-03-14 20:38:22 --> Config Class Initialized
INFO - 2025-03-14 20:38:22 --> Loader Class Initialized
INFO - 2025-03-14 20:38:22 --> Helper loaded: url_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: file_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: html_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: form_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: text_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:38:22 --> Database Driver Class Initialized
INFO - 2025-03-14 20:38:22 --> Email Class Initialized
INFO - 2025-03-14 20:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:38:22 --> Form Validation Class Initialized
INFO - 2025-03-14 20:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:38:22 --> Pagination Class Initialized
INFO - 2025-03-14 20:38:22 --> Controller Class Initialized
DEBUG - 2025-03-14 20:38:22 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:38:22 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:38:22 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:38:22 --> Model Class Initialized
INFO - 2025-03-14 20:38:22 --> Config Class Initialized
INFO - 2025-03-14 20:38:22 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:38:22 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:38:22 --> Utf8 Class Initialized
INFO - 2025-03-14 20:38:22 --> URI Class Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:38:22 --> Router Class Initialized
INFO - 2025-03-14 20:38:22 --> Output Class Initialized
INFO - 2025-03-14 20:38:22 --> Security Class Initialized
DEBUG - 2025-03-14 20:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:38:22 --> Input Class Initialized
INFO - 2025-03-14 20:38:22 --> Language Class Initialized
INFO - 2025-03-14 20:38:22 --> Language Class Initialized
INFO - 2025-03-14 20:38:22 --> Config Class Initialized
INFO - 2025-03-14 20:38:22 --> Loader Class Initialized
INFO - 2025-03-14 20:38:22 --> Helper loaded: url_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: file_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: html_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: form_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: text_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:38:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:38:22 --> Database Driver Class Initialized
INFO - 2025-03-14 20:38:22 --> Email Class Initialized
INFO - 2025-03-14 20:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:38:22 --> Form Validation Class Initialized
INFO - 2025-03-14 20:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:38:22 --> Pagination Class Initialized
INFO - 2025-03-14 20:38:22 --> Controller Class Initialized
DEBUG - 2025-03-14 20:38:22 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:38:22 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:38:22 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:38:22 --> Model Class Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:38:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:38:22 --> Model Class Initialized
ERROR - 2025-03-14 20:38:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:38:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:38:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:38:22 --> Final output sent to browser
DEBUG - 2025-03-14 20:38:22 --> Total execution time: 0.1592
INFO - 2025-03-14 20:41:21 --> Config Class Initialized
INFO - 2025-03-14 20:41:21 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:41:21 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:41:21 --> Utf8 Class Initialized
INFO - 2025-03-14 20:41:21 --> URI Class Initialized
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:41:21 --> Router Class Initialized
INFO - 2025-03-14 20:41:21 --> Output Class Initialized
INFO - 2025-03-14 20:41:21 --> Security Class Initialized
DEBUG - 2025-03-14 20:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:41:21 --> Input Class Initialized
INFO - 2025-03-14 20:41:21 --> Language Class Initialized
INFO - 2025-03-14 20:41:21 --> Language Class Initialized
INFO - 2025-03-14 20:41:21 --> Config Class Initialized
INFO - 2025-03-14 20:41:21 --> Loader Class Initialized
INFO - 2025-03-14 20:41:21 --> Helper loaded: url_helper
INFO - 2025-03-14 20:41:21 --> Helper loaded: file_helper
INFO - 2025-03-14 20:41:21 --> Helper loaded: html_helper
INFO - 2025-03-14 20:41:21 --> Helper loaded: form_helper
INFO - 2025-03-14 20:41:21 --> Helper loaded: text_helper
INFO - 2025-03-14 20:41:21 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:41:21 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:41:21 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:41:21 --> Database Driver Class Initialized
INFO - 2025-03-14 20:41:21 --> Email Class Initialized
INFO - 2025-03-14 20:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:41:21 --> Form Validation Class Initialized
INFO - 2025-03-14 20:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:41:21 --> Pagination Class Initialized
INFO - 2025-03-14 20:41:21 --> Controller Class Initialized
DEBUG - 2025-03-14 20:41:21 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:41:21 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:41:21 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:41:21 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:41:21 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:41:21 --> Model Class Initialized
ERROR - 2025-03-14 20:41:21 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:41:21 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:41:21 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:41:21 --> Final output sent to browser
DEBUG - 2025-03-14 20:41:21 --> Total execution time: 0.6429
INFO - 2025-03-14 20:41:25 --> Config Class Initialized
INFO - 2025-03-14 20:41:25 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:41:25 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:41:25 --> Utf8 Class Initialized
INFO - 2025-03-14 20:41:25 --> URI Class Initialized
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:41:25 --> Router Class Initialized
INFO - 2025-03-14 20:41:25 --> Output Class Initialized
INFO - 2025-03-14 20:41:25 --> Security Class Initialized
DEBUG - 2025-03-14 20:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:41:25 --> Input Class Initialized
INFO - 2025-03-14 20:41:25 --> Language Class Initialized
INFO - 2025-03-14 20:41:25 --> Language Class Initialized
INFO - 2025-03-14 20:41:25 --> Config Class Initialized
INFO - 2025-03-14 20:41:25 --> Loader Class Initialized
INFO - 2025-03-14 20:41:25 --> Helper loaded: url_helper
INFO - 2025-03-14 20:41:25 --> Helper loaded: file_helper
INFO - 2025-03-14 20:41:25 --> Helper loaded: html_helper
INFO - 2025-03-14 20:41:25 --> Helper loaded: form_helper
INFO - 2025-03-14 20:41:25 --> Helper loaded: text_helper
INFO - 2025-03-14 20:41:25 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:41:25 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:41:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:41:25 --> Database Driver Class Initialized
INFO - 2025-03-14 20:41:25 --> Email Class Initialized
INFO - 2025-03-14 20:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:41:25 --> Form Validation Class Initialized
INFO - 2025-03-14 20:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:41:25 --> Pagination Class Initialized
INFO - 2025-03-14 20:41:25 --> Controller Class Initialized
DEBUG - 2025-03-14 20:41:25 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:41:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:41:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:41:25 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Form Data -> []
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Selected Parent ID -> 
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Entered Subcategory Name -> 
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Parent Category Level -> 1
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Corrected Final Category Name -> 
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Final Category Name Before Saving -> 
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Data to be Inserted/Updated -> {"category_id":null,"category_name":"","parent_id":null,"status":null}
DEBUG - 2025-03-14 20:41:25 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:41:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:41:25 --> Model Class Initialized
ERROR - 2025-03-14 20:41:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:41:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:41:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:41:25 --> Final output sent to browser
DEBUG - 2025-03-14 20:41:25 --> Total execution time: 0.1497
INFO - 2025-03-14 20:41:36 --> Config Class Initialized
INFO - 2025-03-14 20:41:36 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:41:36 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:41:36 --> Utf8 Class Initialized
INFO - 2025-03-14 20:41:36 --> URI Class Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:41:36 --> Router Class Initialized
INFO - 2025-03-14 20:41:36 --> Output Class Initialized
INFO - 2025-03-14 20:41:36 --> Security Class Initialized
DEBUG - 2025-03-14 20:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:41:36 --> Input Class Initialized
INFO - 2025-03-14 20:41:36 --> Language Class Initialized
INFO - 2025-03-14 20:41:36 --> Language Class Initialized
INFO - 2025-03-14 20:41:36 --> Config Class Initialized
INFO - 2025-03-14 20:41:36 --> Loader Class Initialized
INFO - 2025-03-14 20:41:36 --> Helper loaded: url_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: file_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: html_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: form_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: text_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:41:36 --> Database Driver Class Initialized
INFO - 2025-03-14 20:41:36 --> Email Class Initialized
INFO - 2025-03-14 20:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:41:36 --> Form Validation Class Initialized
INFO - 2025-03-14 20:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:41:36 --> Pagination Class Initialized
INFO - 2025-03-14 20:41:36 --> Controller Class Initialized
DEBUG - 2025-03-14 20:41:36 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:41:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:41:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:41:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:36 --> DEBUG: Form Data -> {"category_id":"","final_category_name":"Import->Test1->ChieldTest1","category_name":"ChieldTest1","parent_id":"18","status":"1"}
DEBUG - 2025-03-14 20:41:36 --> DEBUG: Selected Parent ID -> 18
DEBUG - 2025-03-14 20:41:36 --> DEBUG: Entered Subcategory Name -> ChieldTest1
DEBUG - 2025-03-14 20:41:36 --> DEBUG: Parent Category Level -> 2
DEBUG - 2025-03-14 20:41:36 --> DEBUG: Corrected Final Category Name -> Import->Test1->ChieldTest1
DEBUG - 2025-03-14 20:41:36 --> DEBUG: Final Category Name Before Saving -> Import->Test1->ChieldTest1
DEBUG - 2025-03-14 20:41:36 --> DEBUG: Data to be Inserted/Updated -> {"category_id":null,"category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}
INFO - 2025-03-14 20:41:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 20:41:36 --> INFO: Category Created Successfully -> Import->Test1->ChieldTest1
INFO - 2025-03-14 20:41:36 --> Config Class Initialized
INFO - 2025-03-14 20:41:36 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:41:36 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:41:36 --> Utf8 Class Initialized
INFO - 2025-03-14 20:41:36 --> URI Class Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:41:36 --> Router Class Initialized
INFO - 2025-03-14 20:41:36 --> Output Class Initialized
INFO - 2025-03-14 20:41:36 --> Security Class Initialized
DEBUG - 2025-03-14 20:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:41:36 --> Input Class Initialized
INFO - 2025-03-14 20:41:36 --> Language Class Initialized
INFO - 2025-03-14 20:41:36 --> Language Class Initialized
INFO - 2025-03-14 20:41:36 --> Config Class Initialized
INFO - 2025-03-14 20:41:36 --> Loader Class Initialized
INFO - 2025-03-14 20:41:36 --> Helper loaded: url_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: file_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: html_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: form_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: text_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:41:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:41:36 --> Database Driver Class Initialized
INFO - 2025-03-14 20:41:36 --> Email Class Initialized
INFO - 2025-03-14 20:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:41:36 --> Form Validation Class Initialized
INFO - 2025-03-14 20:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:41:36 --> Pagination Class Initialized
INFO - 2025-03-14 20:41:36 --> Controller Class Initialized
DEBUG - 2025-03-14 20:41:36 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:41:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:41:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:41:36 --> Model Class Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:41:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:41:36 --> Model Class Initialized
ERROR - 2025-03-14 20:41:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:41:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:41:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:41:36 --> Final output sent to browser
DEBUG - 2025-03-14 20:41:36 --> Total execution time: 0.1593
INFO - 2025-03-14 20:44:15 --> Config Class Initialized
INFO - 2025-03-14 20:44:15 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:44:15 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:44:15 --> Utf8 Class Initialized
INFO - 2025-03-14 20:44:15 --> URI Class Initialized
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:44:15 --> Router Class Initialized
INFO - 2025-03-14 20:44:15 --> Output Class Initialized
INFO - 2025-03-14 20:44:15 --> Security Class Initialized
DEBUG - 2025-03-14 20:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:44:15 --> Input Class Initialized
INFO - 2025-03-14 20:44:15 --> Language Class Initialized
INFO - 2025-03-14 20:44:15 --> Language Class Initialized
INFO - 2025-03-14 20:44:15 --> Config Class Initialized
INFO - 2025-03-14 20:44:15 --> Loader Class Initialized
INFO - 2025-03-14 20:44:15 --> Helper loaded: url_helper
INFO - 2025-03-14 20:44:15 --> Helper loaded: file_helper
INFO - 2025-03-14 20:44:15 --> Helper loaded: html_helper
INFO - 2025-03-14 20:44:15 --> Helper loaded: form_helper
INFO - 2025-03-14 20:44:15 --> Helper loaded: text_helper
INFO - 2025-03-14 20:44:15 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:44:15 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:44:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:44:15 --> Database Driver Class Initialized
INFO - 2025-03-14 20:44:15 --> Email Class Initialized
INFO - 2025-03-14 20:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:44:15 --> Form Validation Class Initialized
INFO - 2025-03-14 20:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:44:15 --> Pagination Class Initialized
INFO - 2025-03-14 20:44:15 --> Controller Class Initialized
DEBUG - 2025-03-14 20:44:15 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:44:15 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:44:15 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:44:15 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:44:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:44:15 --> Model Class Initialized
ERROR - 2025-03-14 20:44:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:44:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:44:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:44:15 --> Final output sent to browser
DEBUG - 2025-03-14 20:44:15 --> Total execution time: 0.1534
INFO - 2025-03-14 20:44:20 --> Config Class Initialized
INFO - 2025-03-14 20:44:20 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:44:20 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:44:20 --> Utf8 Class Initialized
INFO - 2025-03-14 20:44:20 --> URI Class Initialized
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:44:20 --> Router Class Initialized
INFO - 2025-03-14 20:44:20 --> Output Class Initialized
INFO - 2025-03-14 20:44:20 --> Security Class Initialized
DEBUG - 2025-03-14 20:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:44:20 --> Input Class Initialized
INFO - 2025-03-14 20:44:20 --> Language Class Initialized
INFO - 2025-03-14 20:44:20 --> Language Class Initialized
INFO - 2025-03-14 20:44:20 --> Config Class Initialized
INFO - 2025-03-14 20:44:20 --> Loader Class Initialized
INFO - 2025-03-14 20:44:20 --> Helper loaded: url_helper
INFO - 2025-03-14 20:44:20 --> Helper loaded: file_helper
INFO - 2025-03-14 20:44:20 --> Helper loaded: html_helper
INFO - 2025-03-14 20:44:20 --> Helper loaded: form_helper
INFO - 2025-03-14 20:44:20 --> Helper loaded: text_helper
INFO - 2025-03-14 20:44:20 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:44:20 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:44:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:44:20 --> Database Driver Class Initialized
INFO - 2025-03-14 20:44:20 --> Email Class Initialized
INFO - 2025-03-14 20:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:44:20 --> Form Validation Class Initialized
INFO - 2025-03-14 20:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:44:20 --> Pagination Class Initialized
INFO - 2025-03-14 20:44:20 --> Controller Class Initialized
DEBUG - 2025-03-14 20:44:20 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:44:20 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:44:20 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:44:20 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:20 --> DEBUG: Checking for duplicate -> 
DEBUG - 2025-03-14 20:44:20 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:44:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:44:20 --> Model Class Initialized
ERROR - 2025-03-14 20:44:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:44:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:44:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:44:20 --> Final output sent to browser
DEBUG - 2025-03-14 20:44:20 --> Total execution time: 0.0807
INFO - 2025-03-14 20:44:30 --> Config Class Initialized
INFO - 2025-03-14 20:44:30 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:44:30 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:44:30 --> Utf8 Class Initialized
INFO - 2025-03-14 20:44:30 --> URI Class Initialized
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:44:30 --> Router Class Initialized
INFO - 2025-03-14 20:44:30 --> Output Class Initialized
INFO - 2025-03-14 20:44:30 --> Security Class Initialized
DEBUG - 2025-03-14 20:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:44:30 --> Input Class Initialized
INFO - 2025-03-14 20:44:30 --> Language Class Initialized
INFO - 2025-03-14 20:44:30 --> Language Class Initialized
INFO - 2025-03-14 20:44:30 --> Config Class Initialized
INFO - 2025-03-14 20:44:30 --> Loader Class Initialized
INFO - 2025-03-14 20:44:30 --> Helper loaded: url_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: file_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: html_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: form_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: text_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:44:30 --> Database Driver Class Initialized
INFO - 2025-03-14 20:44:30 --> Email Class Initialized
INFO - 2025-03-14 20:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:44:30 --> Form Validation Class Initialized
INFO - 2025-03-14 20:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:44:30 --> Pagination Class Initialized
INFO - 2025-03-14 20:44:30 --> Controller Class Initialized
DEBUG - 2025-03-14 20:44:30 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:44:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:44:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:44:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:30 --> DEBUG: Checking for duplicate -> Import->Test1->ChieldTest1
ERROR - 2025-03-14 20:44:30 --> ERROR: Duplicate category found -> Import->Test1->ChieldTest1
INFO - 2025-03-14 20:44:30 --> Config Class Initialized
INFO - 2025-03-14 20:44:30 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:44:30 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:44:30 --> Utf8 Class Initialized
INFO - 2025-03-14 20:44:30 --> URI Class Initialized
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:44:30 --> Router Class Initialized
INFO - 2025-03-14 20:44:30 --> Output Class Initialized
INFO - 2025-03-14 20:44:30 --> Security Class Initialized
DEBUG - 2025-03-14 20:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:44:30 --> Input Class Initialized
INFO - 2025-03-14 20:44:30 --> Language Class Initialized
INFO - 2025-03-14 20:44:30 --> Language Class Initialized
INFO - 2025-03-14 20:44:30 --> Config Class Initialized
INFO - 2025-03-14 20:44:30 --> Loader Class Initialized
INFO - 2025-03-14 20:44:30 --> Helper loaded: url_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: file_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: html_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: form_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: text_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:44:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:44:30 --> Database Driver Class Initialized
INFO - 2025-03-14 20:44:30 --> Email Class Initialized
INFO - 2025-03-14 20:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:44:30 --> Form Validation Class Initialized
INFO - 2025-03-14 20:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:44:30 --> Pagination Class Initialized
INFO - 2025-03-14 20:44:30 --> Controller Class Initialized
DEBUG - 2025-03-14 20:44:30 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:44:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:44:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:44:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:30 --> DEBUG: Checking for duplicate -> 
DEBUG - 2025-03-14 20:44:30 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:44:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:44:30 --> Model Class Initialized
ERROR - 2025-03-14 20:44:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:44:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:44:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:44:30 --> Final output sent to browser
DEBUG - 2025-03-14 20:44:30 --> Total execution time: 0.1602
INFO - 2025-03-14 20:44:35 --> Config Class Initialized
INFO - 2025-03-14 20:44:35 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:44:35 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:44:35 --> Utf8 Class Initialized
INFO - 2025-03-14 20:44:35 --> URI Class Initialized
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:44:35 --> Router Class Initialized
INFO - 2025-03-14 20:44:35 --> Output Class Initialized
INFO - 2025-03-14 20:44:35 --> Security Class Initialized
DEBUG - 2025-03-14 20:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:44:35 --> Input Class Initialized
INFO - 2025-03-14 20:44:35 --> Language Class Initialized
INFO - 2025-03-14 20:44:35 --> Language Class Initialized
INFO - 2025-03-14 20:44:35 --> Config Class Initialized
INFO - 2025-03-14 20:44:35 --> Loader Class Initialized
INFO - 2025-03-14 20:44:35 --> Helper loaded: url_helper
INFO - 2025-03-14 20:44:35 --> Helper loaded: file_helper
INFO - 2025-03-14 20:44:35 --> Helper loaded: html_helper
INFO - 2025-03-14 20:44:35 --> Helper loaded: form_helper
INFO - 2025-03-14 20:44:35 --> Helper loaded: text_helper
INFO - 2025-03-14 20:44:35 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:44:35 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:44:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:44:35 --> Database Driver Class Initialized
INFO - 2025-03-14 20:44:35 --> Email Class Initialized
INFO - 2025-03-14 20:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:44:35 --> Form Validation Class Initialized
INFO - 2025-03-14 20:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:44:35 --> Pagination Class Initialized
INFO - 2025-03-14 20:44:35 --> Controller Class Initialized
DEBUG - 2025-03-14 20:44:35 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:44:35 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:44:35 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:44:35 --> Model Class Initialized
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:44:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:44:35 --> Model Class Initialized
ERROR - 2025-03-14 20:44:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:44:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:44:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:44:35 --> Final output sent to browser
DEBUG - 2025-03-14 20:44:35 --> Total execution time: 0.1766
INFO - 2025-03-14 20:47:59 --> Config Class Initialized
INFO - 2025-03-14 20:47:59 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:47:59 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:47:59 --> Utf8 Class Initialized
INFO - 2025-03-14 20:47:59 --> URI Class Initialized
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:47:59 --> Router Class Initialized
INFO - 2025-03-14 20:47:59 --> Output Class Initialized
INFO - 2025-03-14 20:47:59 --> Security Class Initialized
DEBUG - 2025-03-14 20:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:47:59 --> Input Class Initialized
INFO - 2025-03-14 20:47:59 --> Language Class Initialized
INFO - 2025-03-14 20:47:59 --> Language Class Initialized
INFO - 2025-03-14 20:47:59 --> Config Class Initialized
INFO - 2025-03-14 20:47:59 --> Loader Class Initialized
INFO - 2025-03-14 20:47:59 --> Helper loaded: url_helper
INFO - 2025-03-14 20:47:59 --> Helper loaded: file_helper
INFO - 2025-03-14 20:47:59 --> Helper loaded: html_helper
INFO - 2025-03-14 20:47:59 --> Helper loaded: form_helper
INFO - 2025-03-14 20:47:59 --> Helper loaded: text_helper
INFO - 2025-03-14 20:47:59 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:47:59 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:47:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:47:59 --> Database Driver Class Initialized
INFO - 2025-03-14 20:47:59 --> Email Class Initialized
INFO - 2025-03-14 20:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:47:59 --> Form Validation Class Initialized
INFO - 2025-03-14 20:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:47:59 --> Pagination Class Initialized
INFO - 2025-03-14 20:47:59 --> Controller Class Initialized
DEBUG - 2025-03-14 20:47:59 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:47:59 --> Model Class Initialized
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:47:59 --> Model Class Initialized
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:47:59 --> Model Class Initialized
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:47:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:47:59 --> Model Class Initialized
ERROR - 2025-03-14 20:47:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:47:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:47:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:47:59 --> Final output sent to browser
DEBUG - 2025-03-14 20:47:59 --> Total execution time: 0.0964
INFO - 2025-03-14 20:48:02 --> Config Class Initialized
INFO - 2025-03-14 20:48:02 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:48:02 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:48:02 --> Utf8 Class Initialized
INFO - 2025-03-14 20:48:02 --> URI Class Initialized
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:48:02 --> Router Class Initialized
INFO - 2025-03-14 20:48:02 --> Output Class Initialized
INFO - 2025-03-14 20:48:02 --> Security Class Initialized
DEBUG - 2025-03-14 20:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:48:02 --> Input Class Initialized
INFO - 2025-03-14 20:48:02 --> Language Class Initialized
INFO - 2025-03-14 20:48:02 --> Language Class Initialized
INFO - 2025-03-14 20:48:02 --> Config Class Initialized
INFO - 2025-03-14 20:48:02 --> Loader Class Initialized
INFO - 2025-03-14 20:48:02 --> Helper loaded: url_helper
INFO - 2025-03-14 20:48:02 --> Helper loaded: file_helper
INFO - 2025-03-14 20:48:02 --> Helper loaded: html_helper
INFO - 2025-03-14 20:48:02 --> Helper loaded: form_helper
INFO - 2025-03-14 20:48:02 --> Helper loaded: text_helper
INFO - 2025-03-14 20:48:02 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:48:02 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:48:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:48:02 --> Database Driver Class Initialized
INFO - 2025-03-14 20:48:02 --> Email Class Initialized
INFO - 2025-03-14 20:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:48:02 --> Form Validation Class Initialized
INFO - 2025-03-14 20:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:48:02 --> Pagination Class Initialized
INFO - 2025-03-14 20:48:02 --> Controller Class Initialized
DEBUG - 2025-03-14 20:48:02 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:48:02 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:48:02 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:48:02 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:02 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:48:02 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:48:02 --> Model Class Initialized
ERROR - 2025-03-14 20:48:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:48:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:48:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:48:02 --> Final output sent to browser
DEBUG - 2025-03-14 20:48:02 --> Total execution time: 0.1863
INFO - 2025-03-14 20:48:10 --> Config Class Initialized
INFO - 2025-03-14 20:48:10 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:48:10 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:48:10 --> Utf8 Class Initialized
INFO - 2025-03-14 20:48:10 --> URI Class Initialized
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:48:10 --> Router Class Initialized
INFO - 2025-03-14 20:48:10 --> Output Class Initialized
INFO - 2025-03-14 20:48:10 --> Security Class Initialized
DEBUG - 2025-03-14 20:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:48:10 --> Input Class Initialized
INFO - 2025-03-14 20:48:10 --> Language Class Initialized
INFO - 2025-03-14 20:48:10 --> Language Class Initialized
INFO - 2025-03-14 20:48:10 --> Config Class Initialized
INFO - 2025-03-14 20:48:10 --> Loader Class Initialized
INFO - 2025-03-14 20:48:10 --> Helper loaded: url_helper
INFO - 2025-03-14 20:48:10 --> Helper loaded: file_helper
INFO - 2025-03-14 20:48:10 --> Helper loaded: html_helper
INFO - 2025-03-14 20:48:10 --> Helper loaded: form_helper
INFO - 2025-03-14 20:48:10 --> Helper loaded: text_helper
INFO - 2025-03-14 20:48:10 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:48:10 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:48:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:48:10 --> Database Driver Class Initialized
INFO - 2025-03-14 20:48:10 --> Email Class Initialized
INFO - 2025-03-14 20:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:48:10 --> Form Validation Class Initialized
INFO - 2025-03-14 20:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:48:10 --> Pagination Class Initialized
INFO - 2025-03-14 20:48:10 --> Controller Class Initialized
DEBUG - 2025-03-14 20:48:10 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:48:10 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:48:10 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:48:10 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:10 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:48:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:48:10 --> Model Class Initialized
ERROR - 2025-03-14 20:48:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:48:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:48:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:48:10 --> Final output sent to browser
DEBUG - 2025-03-14 20:48:10 --> Total execution time: 0.1894
INFO - 2025-03-14 20:48:24 --> Config Class Initialized
INFO - 2025-03-14 20:48:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:48:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:48:24 --> Utf8 Class Initialized
INFO - 2025-03-14 20:48:24 --> URI Class Initialized
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:48:24 --> Router Class Initialized
INFO - 2025-03-14 20:48:24 --> Output Class Initialized
INFO - 2025-03-14 20:48:24 --> Security Class Initialized
DEBUG - 2025-03-14 20:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:48:24 --> Input Class Initialized
INFO - 2025-03-14 20:48:24 --> Language Class Initialized
INFO - 2025-03-14 20:48:24 --> Language Class Initialized
INFO - 2025-03-14 20:48:24 --> Config Class Initialized
INFO - 2025-03-14 20:48:24 --> Loader Class Initialized
INFO - 2025-03-14 20:48:24 --> Helper loaded: url_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: file_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: html_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: form_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: text_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:48:24 --> Database Driver Class Initialized
INFO - 2025-03-14 20:48:24 --> Email Class Initialized
INFO - 2025-03-14 20:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:48:24 --> Form Validation Class Initialized
INFO - 2025-03-14 20:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:48:24 --> Pagination Class Initialized
INFO - 2025-03-14 20:48:24 --> Controller Class Initialized
DEBUG - 2025-03-14 20:48:24 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:48:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:48:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:48:24 --> Model Class Initialized
ERROR - 2025-03-14 20:48:24 --> ERROR: Duplicate category found -> Import->Test1->ChieldTest1
INFO - 2025-03-14 20:48:24 --> Config Class Initialized
INFO - 2025-03-14 20:48:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:48:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:48:24 --> Utf8 Class Initialized
INFO - 2025-03-14 20:48:24 --> URI Class Initialized
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:48:24 --> Router Class Initialized
INFO - 2025-03-14 20:48:24 --> Output Class Initialized
INFO - 2025-03-14 20:48:24 --> Security Class Initialized
DEBUG - 2025-03-14 20:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:48:24 --> Input Class Initialized
INFO - 2025-03-14 20:48:24 --> Language Class Initialized
INFO - 2025-03-14 20:48:24 --> Language Class Initialized
INFO - 2025-03-14 20:48:24 --> Config Class Initialized
INFO - 2025-03-14 20:48:24 --> Loader Class Initialized
INFO - 2025-03-14 20:48:24 --> Helper loaded: url_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: file_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: html_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: form_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: text_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:48:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:48:24 --> Database Driver Class Initialized
INFO - 2025-03-14 20:48:24 --> Email Class Initialized
INFO - 2025-03-14 20:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:48:24 --> Form Validation Class Initialized
INFO - 2025-03-14 20:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:48:24 --> Pagination Class Initialized
INFO - 2025-03-14 20:48:24 --> Controller Class Initialized
DEBUG - 2025-03-14 20:48:24 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:48:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:48:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:48:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:24 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:48:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:48:24 --> Model Class Initialized
ERROR - 2025-03-14 20:48:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:48:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:48:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:48:24 --> Final output sent to browser
DEBUG - 2025-03-14 20:48:24 --> Total execution time: 0.0984
INFO - 2025-03-14 20:48:51 --> Config Class Initialized
INFO - 2025-03-14 20:48:51 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:48:51 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:48:51 --> Utf8 Class Initialized
INFO - 2025-03-14 20:48:51 --> URI Class Initialized
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:48:51 --> Router Class Initialized
INFO - 2025-03-14 20:48:51 --> Output Class Initialized
INFO - 2025-03-14 20:48:51 --> Security Class Initialized
DEBUG - 2025-03-14 20:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:48:51 --> Input Class Initialized
INFO - 2025-03-14 20:48:51 --> Language Class Initialized
INFO - 2025-03-14 20:48:51 --> Language Class Initialized
INFO - 2025-03-14 20:48:51 --> Config Class Initialized
INFO - 2025-03-14 20:48:51 --> Loader Class Initialized
INFO - 2025-03-14 20:48:51 --> Helper loaded: url_helper
INFO - 2025-03-14 20:48:51 --> Helper loaded: file_helper
INFO - 2025-03-14 20:48:51 --> Helper loaded: html_helper
INFO - 2025-03-14 20:48:51 --> Helper loaded: form_helper
INFO - 2025-03-14 20:48:51 --> Helper loaded: text_helper
INFO - 2025-03-14 20:48:51 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:48:51 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:48:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:48:51 --> Database Driver Class Initialized
INFO - 2025-03-14 20:48:51 --> Email Class Initialized
INFO - 2025-03-14 20:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:48:51 --> Form Validation Class Initialized
INFO - 2025-03-14 20:48:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:48:51 --> Pagination Class Initialized
INFO - 2025-03-14 20:48:51 --> Controller Class Initialized
DEBUG - 2025-03-14 20:48:51 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:48:51 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:48:51 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:48:51 --> Model Class Initialized
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:48:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:48:51 --> Model Class Initialized
ERROR - 2025-03-14 20:48:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:48:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:48:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:48:51 --> Final output sent to browser
DEBUG - 2025-03-14 20:48:51 --> Total execution time: 0.1605
INFO - 2025-03-14 20:49:14 --> Config Class Initialized
INFO - 2025-03-14 20:49:14 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:49:14 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:49:14 --> Utf8 Class Initialized
INFO - 2025-03-14 20:49:14 --> URI Class Initialized
DEBUG - 2025-03-14 20:49:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:49:14 --> Router Class Initialized
INFO - 2025-03-14 20:49:14 --> Output Class Initialized
INFO - 2025-03-14 20:49:14 --> Security Class Initialized
DEBUG - 2025-03-14 20:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:49:14 --> Input Class Initialized
INFO - 2025-03-14 20:49:14 --> Language Class Initialized
INFO - 2025-03-14 20:49:14 --> Language Class Initialized
INFO - 2025-03-14 20:49:14 --> Config Class Initialized
INFO - 2025-03-14 20:49:14 --> Loader Class Initialized
INFO - 2025-03-14 20:49:14 --> Helper loaded: url_helper
INFO - 2025-03-14 20:49:14 --> Helper loaded: file_helper
INFO - 2025-03-14 20:49:14 --> Helper loaded: html_helper
INFO - 2025-03-14 20:49:14 --> Helper loaded: form_helper
INFO - 2025-03-14 20:49:14 --> Helper loaded: text_helper
INFO - 2025-03-14 20:49:14 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:49:14 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:49:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:49:14 --> Database Driver Class Initialized
INFO - 2025-03-14 20:49:14 --> Email Class Initialized
INFO - 2025-03-14 20:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:49:14 --> Form Validation Class Initialized
INFO - 2025-03-14 20:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:49:14 --> Pagination Class Initialized
INFO - 2025-03-14 20:49:14 --> Controller Class Initialized
DEBUG - 2025-03-14 20:49:14 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:49:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:49:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:49:14 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:49:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:49:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:49:14 --> Model Class Initialized
ERROR - 2025-03-14 20:49:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:49:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:49:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:49:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:49:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:49:15 --> Final output sent to browser
DEBUG - 2025-03-14 20:49:15 --> Total execution time: 0.1906
INFO - 2025-03-14 20:49:24 --> Config Class Initialized
INFO - 2025-03-14 20:49:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:49:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:49:24 --> Utf8 Class Initialized
INFO - 2025-03-14 20:49:24 --> URI Class Initialized
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:49:24 --> Router Class Initialized
INFO - 2025-03-14 20:49:24 --> Output Class Initialized
INFO - 2025-03-14 20:49:24 --> Security Class Initialized
DEBUG - 2025-03-14 20:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:49:24 --> Input Class Initialized
INFO - 2025-03-14 20:49:24 --> Language Class Initialized
INFO - 2025-03-14 20:49:24 --> Language Class Initialized
INFO - 2025-03-14 20:49:24 --> Config Class Initialized
INFO - 2025-03-14 20:49:24 --> Loader Class Initialized
INFO - 2025-03-14 20:49:24 --> Helper loaded: url_helper
INFO - 2025-03-14 20:49:24 --> Helper loaded: file_helper
INFO - 2025-03-14 20:49:24 --> Helper loaded: html_helper
INFO - 2025-03-14 20:49:24 --> Helper loaded: form_helper
INFO - 2025-03-14 20:49:24 --> Helper loaded: text_helper
INFO - 2025-03-14 20:49:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:49:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:49:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:49:24 --> Database Driver Class Initialized
INFO - 2025-03-14 20:49:24 --> Email Class Initialized
INFO - 2025-03-14 20:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:49:24 --> Form Validation Class Initialized
INFO - 2025-03-14 20:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:49:24 --> Pagination Class Initialized
INFO - 2025-03-14 20:49:24 --> Controller Class Initialized
DEBUG - 2025-03-14 20:49:24 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:49:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:49:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:49:24 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:24 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:49:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:49:24 --> Model Class Initialized
ERROR - 2025-03-14 20:49:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:49:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:49:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:49:24 --> Final output sent to browser
DEBUG - 2025-03-14 20:49:24 --> Total execution time: 0.1786
INFO - 2025-03-14 20:49:55 --> Config Class Initialized
INFO - 2025-03-14 20:49:55 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:49:55 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:49:55 --> Utf8 Class Initialized
INFO - 2025-03-14 20:49:55 --> URI Class Initialized
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:49:55 --> Router Class Initialized
INFO - 2025-03-14 20:49:55 --> Output Class Initialized
INFO - 2025-03-14 20:49:55 --> Security Class Initialized
DEBUG - 2025-03-14 20:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:49:55 --> Input Class Initialized
INFO - 2025-03-14 20:49:55 --> Language Class Initialized
INFO - 2025-03-14 20:49:55 --> Language Class Initialized
INFO - 2025-03-14 20:49:55 --> Config Class Initialized
INFO - 2025-03-14 20:49:55 --> Loader Class Initialized
INFO - 2025-03-14 20:49:55 --> Helper loaded: url_helper
INFO - 2025-03-14 20:49:55 --> Helper loaded: file_helper
INFO - 2025-03-14 20:49:55 --> Helper loaded: html_helper
INFO - 2025-03-14 20:49:55 --> Helper loaded: form_helper
INFO - 2025-03-14 20:49:55 --> Helper loaded: text_helper
INFO - 2025-03-14 20:49:55 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:49:55 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:49:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:49:55 --> Database Driver Class Initialized
INFO - 2025-03-14 20:49:55 --> Email Class Initialized
INFO - 2025-03-14 20:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:49:55 --> Form Validation Class Initialized
INFO - 2025-03-14 20:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:49:55 --> Pagination Class Initialized
INFO - 2025-03-14 20:49:55 --> Controller Class Initialized
DEBUG - 2025-03-14 20:49:55 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:49:55 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:49:55 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:49:55 --> Model Class Initialized
DEBUG - 2025-03-14 20:49:55 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:49:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:49:55 --> Model Class Initialized
ERROR - 2025-03-14 20:49:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:49:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:49:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:49:55 --> Final output sent to browser
DEBUG - 2025-03-14 20:49:55 --> Total execution time: 0.1100
INFO - 2025-03-14 20:50:31 --> Config Class Initialized
INFO - 2025-03-14 20:50:31 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:50:31 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:50:31 --> Utf8 Class Initialized
INFO - 2025-03-14 20:50:31 --> URI Class Initialized
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:50:31 --> Router Class Initialized
INFO - 2025-03-14 20:50:31 --> Output Class Initialized
INFO - 2025-03-14 20:50:31 --> Security Class Initialized
DEBUG - 2025-03-14 20:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:50:31 --> Input Class Initialized
INFO - 2025-03-14 20:50:31 --> Language Class Initialized
INFO - 2025-03-14 20:50:31 --> Language Class Initialized
INFO - 2025-03-14 20:50:31 --> Config Class Initialized
INFO - 2025-03-14 20:50:31 --> Loader Class Initialized
INFO - 2025-03-14 20:50:31 --> Helper loaded: url_helper
INFO - 2025-03-14 20:50:31 --> Helper loaded: file_helper
INFO - 2025-03-14 20:50:31 --> Helper loaded: html_helper
INFO - 2025-03-14 20:50:31 --> Helper loaded: form_helper
INFO - 2025-03-14 20:50:31 --> Helper loaded: text_helper
INFO - 2025-03-14 20:50:31 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:50:31 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:50:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:50:31 --> Database Driver Class Initialized
INFO - 2025-03-14 20:50:31 --> Email Class Initialized
INFO - 2025-03-14 20:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:50:31 --> Form Validation Class Initialized
INFO - 2025-03-14 20:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:50:31 --> Pagination Class Initialized
INFO - 2025-03-14 20:50:31 --> Controller Class Initialized
DEBUG - 2025-03-14 20:50:31 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:50:31 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:50:31 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:50:31 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:50:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:50:31 --> Model Class Initialized
ERROR - 2025-03-14 20:50:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:50:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:50:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:50:31 --> Final output sent to browser
DEBUG - 2025-03-14 20:50:31 --> Total execution time: 0.1338
INFO - 2025-03-14 20:50:32 --> Config Class Initialized
INFO - 2025-03-14 20:50:32 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:50:32 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:50:32 --> Utf8 Class Initialized
INFO - 2025-03-14 20:50:32 --> URI Class Initialized
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:50:32 --> Router Class Initialized
INFO - 2025-03-14 20:50:32 --> Output Class Initialized
INFO - 2025-03-14 20:50:32 --> Security Class Initialized
DEBUG - 2025-03-14 20:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:50:32 --> Input Class Initialized
INFO - 2025-03-14 20:50:32 --> Language Class Initialized
INFO - 2025-03-14 20:50:32 --> Language Class Initialized
INFO - 2025-03-14 20:50:32 --> Config Class Initialized
INFO - 2025-03-14 20:50:32 --> Loader Class Initialized
INFO - 2025-03-14 20:50:32 --> Helper loaded: url_helper
INFO - 2025-03-14 20:50:32 --> Helper loaded: file_helper
INFO - 2025-03-14 20:50:32 --> Helper loaded: html_helper
INFO - 2025-03-14 20:50:32 --> Helper loaded: form_helper
INFO - 2025-03-14 20:50:32 --> Helper loaded: text_helper
INFO - 2025-03-14 20:50:32 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:50:32 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:50:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:50:32 --> Database Driver Class Initialized
INFO - 2025-03-14 20:50:32 --> Email Class Initialized
INFO - 2025-03-14 20:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:50:32 --> Form Validation Class Initialized
INFO - 2025-03-14 20:50:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:50:32 --> Pagination Class Initialized
INFO - 2025-03-14 20:50:32 --> Controller Class Initialized
DEBUG - 2025-03-14 20:50:32 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:50:32 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:50:32 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:50:32 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:32 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:50:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:50:32 --> Model Class Initialized
ERROR - 2025-03-14 20:50:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:50:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:50:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:50:32 --> Final output sent to browser
DEBUG - 2025-03-14 20:50:32 --> Total execution time: 0.0958
INFO - 2025-03-14 20:50:35 --> Config Class Initialized
INFO - 2025-03-14 20:50:35 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:50:35 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:50:35 --> Utf8 Class Initialized
INFO - 2025-03-14 20:50:35 --> URI Class Initialized
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/config/routes.php
INFO - 2025-03-14 20:50:35 --> Router Class Initialized
INFO - 2025-03-14 20:50:35 --> Output Class Initialized
INFO - 2025-03-14 20:50:35 --> Security Class Initialized
DEBUG - 2025-03-14 20:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:50:35 --> Input Class Initialized
INFO - 2025-03-14 20:50:35 --> Language Class Initialized
INFO - 2025-03-14 20:50:35 --> Language Class Initialized
INFO - 2025-03-14 20:50:35 --> Config Class Initialized
INFO - 2025-03-14 20:50:35 --> Loader Class Initialized
INFO - 2025-03-14 20:50:35 --> Helper loaded: url_helper
INFO - 2025-03-14 20:50:35 --> Helper loaded: file_helper
INFO - 2025-03-14 20:50:35 --> Helper loaded: html_helper
INFO - 2025-03-14 20:50:35 --> Helper loaded: form_helper
INFO - 2025-03-14 20:50:35 --> Helper loaded: text_helper
INFO - 2025-03-14 20:50:35 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:50:35 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:50:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:50:35 --> Database Driver Class Initialized
INFO - 2025-03-14 20:50:35 --> Email Class Initialized
INFO - 2025-03-14 20:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:50:35 --> Form Validation Class Initialized
INFO - 2025-03-14 20:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:50:35 --> Pagination Class Initialized
INFO - 2025-03-14 20:50:35 --> Controller Class Initialized
DEBUG - 2025-03-14 20:50:35 --> Supplier MX_Controller Initialized
INFO - 2025-03-14 20:50:35 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:50:35 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:50:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:50:35 --> Model Class Initialized
ERROR - 2025-03-14 20:50:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:50:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/views/form.php
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:50:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:50:35 --> Final output sent to browser
DEBUG - 2025-03-14 20:50:35 --> Total execution time: 0.1671
INFO - 2025-03-14 20:50:39 --> Config Class Initialized
INFO - 2025-03-14 20:50:39 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:50:39 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:50:39 --> Utf8 Class Initialized
INFO - 2025-03-14 20:50:39 --> URI Class Initialized
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:50:39 --> Router Class Initialized
INFO - 2025-03-14 20:50:39 --> Output Class Initialized
INFO - 2025-03-14 20:50:39 --> Security Class Initialized
DEBUG - 2025-03-14 20:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:50:39 --> Input Class Initialized
INFO - 2025-03-14 20:50:39 --> Language Class Initialized
INFO - 2025-03-14 20:50:39 --> Language Class Initialized
INFO - 2025-03-14 20:50:39 --> Config Class Initialized
INFO - 2025-03-14 20:50:39 --> Loader Class Initialized
INFO - 2025-03-14 20:50:39 --> Helper loaded: url_helper
INFO - 2025-03-14 20:50:39 --> Helper loaded: file_helper
INFO - 2025-03-14 20:50:39 --> Helper loaded: html_helper
INFO - 2025-03-14 20:50:39 --> Helper loaded: form_helper
INFO - 2025-03-14 20:50:39 --> Helper loaded: text_helper
INFO - 2025-03-14 20:50:39 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:50:39 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:50:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:50:39 --> Database Driver Class Initialized
INFO - 2025-03-14 20:50:39 --> Email Class Initialized
INFO - 2025-03-14 20:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:50:39 --> Form Validation Class Initialized
INFO - 2025-03-14 20:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:50:39 --> Pagination Class Initialized
INFO - 2025-03-14 20:50:39 --> Controller Class Initialized
DEBUG - 2025-03-14 20:50:39 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:50:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:50:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:50:39 --> Model Class Initialized
DEBUG - 2025-03-14 20:50:39 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:50:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:50:39 --> Model Class Initialized
ERROR - 2025-03-14 20:50:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:50:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:50:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:50:39 --> Final output sent to browser
DEBUG - 2025-03-14 20:50:39 --> Total execution time: 0.0921
INFO - 2025-03-14 20:54:26 --> Config Class Initialized
INFO - 2025-03-14 20:54:26 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:54:26 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:54:26 --> Utf8 Class Initialized
INFO - 2025-03-14 20:54:26 --> URI Class Initialized
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:54:26 --> Router Class Initialized
INFO - 2025-03-14 20:54:26 --> Output Class Initialized
INFO - 2025-03-14 20:54:26 --> Security Class Initialized
DEBUG - 2025-03-14 20:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:54:26 --> Input Class Initialized
INFO - 2025-03-14 20:54:26 --> Language Class Initialized
INFO - 2025-03-14 20:54:26 --> Language Class Initialized
INFO - 2025-03-14 20:54:26 --> Config Class Initialized
INFO - 2025-03-14 20:54:26 --> Loader Class Initialized
INFO - 2025-03-14 20:54:26 --> Helper loaded: url_helper
INFO - 2025-03-14 20:54:26 --> Helper loaded: file_helper
INFO - 2025-03-14 20:54:26 --> Helper loaded: html_helper
INFO - 2025-03-14 20:54:26 --> Helper loaded: form_helper
INFO - 2025-03-14 20:54:26 --> Helper loaded: text_helper
INFO - 2025-03-14 20:54:26 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:54:26 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:54:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:54:26 --> Database Driver Class Initialized
INFO - 2025-03-14 20:54:26 --> Email Class Initialized
INFO - 2025-03-14 20:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:54:26 --> Form Validation Class Initialized
INFO - 2025-03-14 20:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:54:26 --> Pagination Class Initialized
INFO - 2025-03-14 20:54:26 --> Controller Class Initialized
DEBUG - 2025-03-14 20:54:26 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:54:26 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:54:26 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:54:26 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:26 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:54:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:54:26 --> Model Class Initialized
ERROR - 2025-03-14 20:54:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:54:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:54:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:54:26 --> Final output sent to browser
DEBUG - 2025-03-14 20:54:26 --> Total execution time: 0.1151
INFO - 2025-03-14 20:54:30 --> Config Class Initialized
INFO - 2025-03-14 20:54:30 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:54:30 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:54:30 --> Utf8 Class Initialized
INFO - 2025-03-14 20:54:30 --> URI Class Initialized
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:54:30 --> Router Class Initialized
INFO - 2025-03-14 20:54:30 --> Output Class Initialized
INFO - 2025-03-14 20:54:30 --> Security Class Initialized
DEBUG - 2025-03-14 20:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:54:30 --> Input Class Initialized
INFO - 2025-03-14 20:54:30 --> Language Class Initialized
INFO - 2025-03-14 20:54:30 --> Language Class Initialized
INFO - 2025-03-14 20:54:30 --> Config Class Initialized
INFO - 2025-03-14 20:54:30 --> Loader Class Initialized
INFO - 2025-03-14 20:54:30 --> Helper loaded: url_helper
INFO - 2025-03-14 20:54:30 --> Helper loaded: file_helper
INFO - 2025-03-14 20:54:30 --> Helper loaded: html_helper
INFO - 2025-03-14 20:54:30 --> Helper loaded: form_helper
INFO - 2025-03-14 20:54:30 --> Helper loaded: text_helper
INFO - 2025-03-14 20:54:30 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:54:30 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:54:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:54:30 --> Database Driver Class Initialized
INFO - 2025-03-14 20:54:30 --> Email Class Initialized
INFO - 2025-03-14 20:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:54:30 --> Form Validation Class Initialized
INFO - 2025-03-14 20:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:54:30 --> Pagination Class Initialized
INFO - 2025-03-14 20:54:30 --> Controller Class Initialized
DEBUG - 2025-03-14 20:54:30 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:54:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:54:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:54:30 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:30 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:54:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:54:30 --> Model Class Initialized
ERROR - 2025-03-14 20:54:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:54:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:54:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:54:30 --> Final output sent to browser
DEBUG - 2025-03-14 20:54:30 --> Total execution time: 0.1799
INFO - 2025-03-14 20:54:43 --> Config Class Initialized
INFO - 2025-03-14 20:54:43 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:54:43 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:54:43 --> Utf8 Class Initialized
INFO - 2025-03-14 20:54:43 --> URI Class Initialized
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:54:43 --> Router Class Initialized
INFO - 2025-03-14 20:54:43 --> Output Class Initialized
INFO - 2025-03-14 20:54:43 --> Security Class Initialized
DEBUG - 2025-03-14 20:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:54:43 --> Input Class Initialized
INFO - 2025-03-14 20:54:43 --> Language Class Initialized
INFO - 2025-03-14 20:54:43 --> Language Class Initialized
INFO - 2025-03-14 20:54:43 --> Config Class Initialized
INFO - 2025-03-14 20:54:43 --> Loader Class Initialized
INFO - 2025-03-14 20:54:43 --> Helper loaded: url_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: file_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: html_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: form_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: text_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:54:43 --> Database Driver Class Initialized
INFO - 2025-03-14 20:54:43 --> Email Class Initialized
INFO - 2025-03-14 20:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:54:43 --> Form Validation Class Initialized
INFO - 2025-03-14 20:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:54:43 --> Pagination Class Initialized
INFO - 2025-03-14 20:54:43 --> Controller Class Initialized
DEBUG - 2025-03-14 20:54:43 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:54:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:54:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:54:43 --> Model Class Initialized
ERROR - 2025-03-14 20:54:43 --> ERROR: Duplicate category found -> Import->Test1->ChieldTest1
INFO - 2025-03-14 20:54:43 --> Config Class Initialized
INFO - 2025-03-14 20:54:43 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:54:43 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:54:43 --> Utf8 Class Initialized
INFO - 2025-03-14 20:54:43 --> URI Class Initialized
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:54:43 --> Router Class Initialized
INFO - 2025-03-14 20:54:43 --> Output Class Initialized
INFO - 2025-03-14 20:54:43 --> Security Class Initialized
DEBUG - 2025-03-14 20:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:54:43 --> Input Class Initialized
INFO - 2025-03-14 20:54:43 --> Language Class Initialized
INFO - 2025-03-14 20:54:43 --> Language Class Initialized
INFO - 2025-03-14 20:54:43 --> Config Class Initialized
INFO - 2025-03-14 20:54:43 --> Loader Class Initialized
INFO - 2025-03-14 20:54:43 --> Helper loaded: url_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: file_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: html_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: form_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: text_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:54:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:54:43 --> Database Driver Class Initialized
INFO - 2025-03-14 20:54:43 --> Email Class Initialized
INFO - 2025-03-14 20:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:54:43 --> Form Validation Class Initialized
INFO - 2025-03-14 20:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:54:43 --> Pagination Class Initialized
INFO - 2025-03-14 20:54:43 --> Controller Class Initialized
DEBUG - 2025-03-14 20:54:43 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:54:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:54:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:54:43 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:43 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:54:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:54:43 --> Model Class Initialized
ERROR - 2025-03-14 20:54:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:54:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:54:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:54:44 --> Final output sent to browser
DEBUG - 2025-03-14 20:54:44 --> Total execution time: 0.1524
INFO - 2025-03-14 20:54:49 --> Config Class Initialized
INFO - 2025-03-14 20:54:49 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:54:49 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:54:49 --> Utf8 Class Initialized
INFO - 2025-03-14 20:54:49 --> URI Class Initialized
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:54:49 --> Router Class Initialized
INFO - 2025-03-14 20:54:49 --> Output Class Initialized
INFO - 2025-03-14 20:54:49 --> Security Class Initialized
DEBUG - 2025-03-14 20:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:54:49 --> Input Class Initialized
INFO - 2025-03-14 20:54:49 --> Language Class Initialized
INFO - 2025-03-14 20:54:49 --> Language Class Initialized
INFO - 2025-03-14 20:54:49 --> Config Class Initialized
INFO - 2025-03-14 20:54:49 --> Loader Class Initialized
INFO - 2025-03-14 20:54:49 --> Helper loaded: url_helper
INFO - 2025-03-14 20:54:49 --> Helper loaded: file_helper
INFO - 2025-03-14 20:54:49 --> Helper loaded: html_helper
INFO - 2025-03-14 20:54:49 --> Helper loaded: form_helper
INFO - 2025-03-14 20:54:49 --> Helper loaded: text_helper
INFO - 2025-03-14 20:54:49 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:54:49 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:54:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:54:49 --> Database Driver Class Initialized
INFO - 2025-03-14 20:54:49 --> Email Class Initialized
INFO - 2025-03-14 20:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:54:49 --> Form Validation Class Initialized
INFO - 2025-03-14 20:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:54:49 --> Pagination Class Initialized
INFO - 2025-03-14 20:54:49 --> Controller Class Initialized
DEBUG - 2025-03-14 20:54:49 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:54:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:54:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:54:49 --> Model Class Initialized
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:54:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:54:49 --> Model Class Initialized
ERROR - 2025-03-14 20:54:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:54:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:54:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:54:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 20:54:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:54:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:54:50 --> Final output sent to browser
DEBUG - 2025-03-14 20:54:50 --> Total execution time: 0.1208
INFO - 2025-03-14 20:55:06 --> Config Class Initialized
INFO - 2025-03-14 20:55:06 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:55:06 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:55:06 --> Utf8 Class Initialized
INFO - 2025-03-14 20:55:06 --> URI Class Initialized
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:55:06 --> Router Class Initialized
INFO - 2025-03-14 20:55:06 --> Output Class Initialized
INFO - 2025-03-14 20:55:06 --> Security Class Initialized
DEBUG - 2025-03-14 20:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:55:06 --> Input Class Initialized
INFO - 2025-03-14 20:55:06 --> Language Class Initialized
INFO - 2025-03-14 20:55:06 --> Language Class Initialized
INFO - 2025-03-14 20:55:06 --> Config Class Initialized
INFO - 2025-03-14 20:55:06 --> Loader Class Initialized
INFO - 2025-03-14 20:55:06 --> Helper loaded: url_helper
INFO - 2025-03-14 20:55:06 --> Helper loaded: file_helper
INFO - 2025-03-14 20:55:06 --> Helper loaded: html_helper
INFO - 2025-03-14 20:55:06 --> Helper loaded: form_helper
INFO - 2025-03-14 20:55:06 --> Helper loaded: text_helper
INFO - 2025-03-14 20:55:06 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:55:06 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:55:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:55:06 --> Database Driver Class Initialized
INFO - 2025-03-14 20:55:06 --> Email Class Initialized
INFO - 2025-03-14 20:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:55:06 --> Form Validation Class Initialized
INFO - 2025-03-14 20:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:55:06 --> Pagination Class Initialized
INFO - 2025-03-14 20:55:06 --> Controller Class Initialized
DEBUG - 2025-03-14 20:55:06 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:55:06 --> Model Class Initialized
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:55:06 --> Model Class Initialized
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:55:06 --> Model Class Initialized
DEBUG - 2025-03-14 20:55:06 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:55:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:55:06 --> Model Class Initialized
ERROR - 2025-03-14 20:55:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:55:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:55:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:55:06 --> Final output sent to browser
DEBUG - 2025-03-14 20:55:06 --> Total execution time: 0.1356
INFO - 2025-03-14 20:55:34 --> Config Class Initialized
INFO - 2025-03-14 20:55:34 --> Hooks Class Initialized
DEBUG - 2025-03-14 20:55:34 --> UTF-8 Support Enabled
INFO - 2025-03-14 20:55:34 --> Utf8 Class Initialized
INFO - 2025-03-14 20:55:34 --> URI Class Initialized
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 20:55:34 --> Router Class Initialized
INFO - 2025-03-14 20:55:34 --> Output Class Initialized
INFO - 2025-03-14 20:55:34 --> Security Class Initialized
DEBUG - 2025-03-14 20:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 20:55:34 --> Input Class Initialized
INFO - 2025-03-14 20:55:34 --> Language Class Initialized
INFO - 2025-03-14 20:55:34 --> Language Class Initialized
INFO - 2025-03-14 20:55:34 --> Config Class Initialized
INFO - 2025-03-14 20:55:34 --> Loader Class Initialized
INFO - 2025-03-14 20:55:34 --> Helper loaded: url_helper
INFO - 2025-03-14 20:55:34 --> Helper loaded: file_helper
INFO - 2025-03-14 20:55:34 --> Helper loaded: html_helper
INFO - 2025-03-14 20:55:34 --> Helper loaded: form_helper
INFO - 2025-03-14 20:55:34 --> Helper loaded: text_helper
INFO - 2025-03-14 20:55:34 --> Helper loaded: lang_helper
INFO - 2025-03-14 20:55:34 --> Helper loaded: directory_helper
INFO - 2025-03-14 20:55:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 20:55:34 --> Database Driver Class Initialized
INFO - 2025-03-14 20:55:34 --> Email Class Initialized
INFO - 2025-03-14 20:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 20:55:34 --> Form Validation Class Initialized
INFO - 2025-03-14 20:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 20:55:34 --> Pagination Class Initialized
INFO - 2025-03-14 20:55:34 --> Controller Class Initialized
DEBUG - 2025-03-14 20:55:34 --> Product MX_Controller Initialized
INFO - 2025-03-14 20:55:34 --> Model Class Initialized
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 20:55:34 --> Model Class Initialized
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 20:55:34 --> Model Class Initialized
DEBUG - 2025-03-14 20:55:34 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 20:55:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 20:55:34 --> Model Class Initialized
ERROR - 2025-03-14 20:55:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 20:55:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 20:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 20:55:34 --> Final output sent to browser
DEBUG - 2025-03-14 20:55:34 --> Total execution time: 0.1704
INFO - 2025-03-14 21:02:51 --> Config Class Initialized
INFO - 2025-03-14 21:02:51 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:02:51 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:02:51 --> Utf8 Class Initialized
INFO - 2025-03-14 21:02:51 --> URI Class Initialized
DEBUG - 2025-03-14 21:02:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:02:51 --> Router Class Initialized
INFO - 2025-03-14 21:02:51 --> Output Class Initialized
INFO - 2025-03-14 21:02:51 --> Security Class Initialized
DEBUG - 2025-03-14 21:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:02:51 --> Input Class Initialized
INFO - 2025-03-14 21:02:51 --> Language Class Initialized
INFO - 2025-03-14 21:02:51 --> Language Class Initialized
INFO - 2025-03-14 21:02:51 --> Config Class Initialized
INFO - 2025-03-14 21:02:51 --> Loader Class Initialized
INFO - 2025-03-14 21:02:51 --> Helper loaded: url_helper
INFO - 2025-03-14 21:02:51 --> Helper loaded: file_helper
INFO - 2025-03-14 21:02:51 --> Helper loaded: html_helper
INFO - 2025-03-14 21:02:51 --> Helper loaded: form_helper
INFO - 2025-03-14 21:02:51 --> Helper loaded: text_helper
INFO - 2025-03-14 21:02:51 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:02:51 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:02:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:02:51 --> Database Driver Class Initialized
INFO - 2025-03-14 21:02:51 --> Email Class Initialized
INFO - 2025-03-14 21:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:02:51 --> Form Validation Class Initialized
INFO - 2025-03-14 21:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:02:51 --> Pagination Class Initialized
INFO - 2025-03-14 21:02:51 --> Controller Class Initialized
DEBUG - 2025-03-14 21:02:51 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:02:51 --> Model Class Initialized
DEBUG - 2025-03-14 21:02:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:02:51 --> Model Class Initialized
DEBUG - 2025-03-14 21:02:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:02:51 --> Model Class Initialized
DEBUG - 2025-03-14 21:02:51 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:02:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:02:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:02:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:02:51 --> Model Class Initialized
ERROR - 2025-03-14 21:02:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:02:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:02:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:02:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:02:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:02:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:02:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:02:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:02:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:02:52 --> Final output sent to browser
DEBUG - 2025-03-14 21:02:52 --> Total execution time: 0.2749
INFO - 2025-03-14 21:03:05 --> Config Class Initialized
INFO - 2025-03-14 21:03:05 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:05 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:05 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:05 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:05 --> Router Class Initialized
INFO - 2025-03-14 21:03:05 --> Output Class Initialized
INFO - 2025-03-14 21:03:05 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:05 --> Input Class Initialized
INFO - 2025-03-14 21:03:05 --> Language Class Initialized
INFO - 2025-03-14 21:03:05 --> Language Class Initialized
INFO - 2025-03-14 21:03:05 --> Config Class Initialized
INFO - 2025-03-14 21:03:05 --> Loader Class Initialized
INFO - 2025-03-14 21:03:05 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:05 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:05 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:05 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:05 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:05 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:05 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:05 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:05 --> Email Class Initialized
INFO - 2025-03-14 21:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:05 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:05 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:05 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:05 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:05 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:05 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:05 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:03:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:03:05 --> Model Class Initialized
ERROR - 2025-03-14 21:03:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:03:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:03:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:03:05 --> Final output sent to browser
DEBUG - 2025-03-14 21:03:05 --> Total execution time: 0.1406
INFO - 2025-03-14 21:03:09 --> Config Class Initialized
INFO - 2025-03-14 21:03:09 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:09 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:09 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:09 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:09 --> Router Class Initialized
INFO - 2025-03-14 21:03:09 --> Output Class Initialized
INFO - 2025-03-14 21:03:09 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:09 --> Input Class Initialized
INFO - 2025-03-14 21:03:09 --> Language Class Initialized
INFO - 2025-03-14 21:03:09 --> Language Class Initialized
INFO - 2025-03-14 21:03:09 --> Config Class Initialized
INFO - 2025-03-14 21:03:09 --> Loader Class Initialized
INFO - 2025-03-14 21:03:09 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:09 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:09 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:09 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:09 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:09 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:09 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:09 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:09 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:09 --> Email Class Initialized
INFO - 2025-03-14 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:09 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:09 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:09 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:09 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:09 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:09 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:09 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:09 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:03:09 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:03:09 --> Model Class Initialized
ERROR - 2025-03-14 21:03:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:03:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:03:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:03:09 --> Final output sent to browser
DEBUG - 2025-03-14 21:03:09 --> Total execution time: 0.1366
INFO - 2025-03-14 21:03:17 --> Config Class Initialized
INFO - 2025-03-14 21:03:17 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:17 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:17 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:17 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:17 --> Router Class Initialized
INFO - 2025-03-14 21:03:17 --> Output Class Initialized
INFO - 2025-03-14 21:03:17 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:17 --> Input Class Initialized
INFO - 2025-03-14 21:03:17 --> Language Class Initialized
INFO - 2025-03-14 21:03:17 --> Language Class Initialized
INFO - 2025-03-14 21:03:17 --> Config Class Initialized
INFO - 2025-03-14 21:03:17 --> Loader Class Initialized
INFO - 2025-03-14 21:03:17 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:17 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:17 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:17 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:17 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:17 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:17 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:17 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:17 --> Email Class Initialized
INFO - 2025-03-14 21:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:17 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:17 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:17 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:17 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:17 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:17 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:17 --> Model Class Initialized
ERROR - 2025-03-14 21:03:18 --> ERROR: Duplicate category found -> Import->Test1->ChieldTest1
INFO - 2025-03-14 21:03:18 --> Config Class Initialized
INFO - 2025-03-14 21:03:18 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:18 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:18 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:18 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:18 --> Router Class Initialized
INFO - 2025-03-14 21:03:18 --> Output Class Initialized
INFO - 2025-03-14 21:03:18 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:18 --> Input Class Initialized
INFO - 2025-03-14 21:03:18 --> Language Class Initialized
INFO - 2025-03-14 21:03:18 --> Language Class Initialized
INFO - 2025-03-14 21:03:18 --> Config Class Initialized
INFO - 2025-03-14 21:03:18 --> Loader Class Initialized
INFO - 2025-03-14 21:03:18 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:18 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:18 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:18 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:18 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:18 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:18 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:18 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:18 --> Email Class Initialized
INFO - 2025-03-14 21:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:18 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:18 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:18 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:18 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:18 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"33","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:03:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:03:18 --> Model Class Initialized
ERROR - 2025-03-14 21:03:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:03:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:03:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:03:18 --> Final output sent to browser
DEBUG - 2025-03-14 21:03:18 --> Total execution time: 0.0912
INFO - 2025-03-14 21:03:24 --> Config Class Initialized
INFO - 2025-03-14 21:03:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:24 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:24 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:24 --> Router Class Initialized
INFO - 2025-03-14 21:03:24 --> Output Class Initialized
INFO - 2025-03-14 21:03:24 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:24 --> Input Class Initialized
INFO - 2025-03-14 21:03:24 --> Language Class Initialized
INFO - 2025-03-14 21:03:24 --> Language Class Initialized
INFO - 2025-03-14 21:03:24 --> Config Class Initialized
INFO - 2025-03-14 21:03:24 --> Loader Class Initialized
INFO - 2025-03-14 21:03:24 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:24 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:24 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:24 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:24 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:24 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:24 --> Email Class Initialized
INFO - 2025-03-14 21:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:24 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:24 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:24 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:24 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:03:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:03:24 --> Model Class Initialized
ERROR - 2025-03-14 21:03:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:03:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:03:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:03:24 --> Final output sent to browser
DEBUG - 2025-03-14 21:03:24 --> Total execution time: 0.1000
INFO - 2025-03-14 21:03:29 --> Config Class Initialized
INFO - 2025-03-14 21:03:29 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:29 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:29 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:29 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:29 --> Router Class Initialized
INFO - 2025-03-14 21:03:29 --> Output Class Initialized
INFO - 2025-03-14 21:03:29 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:29 --> Input Class Initialized
INFO - 2025-03-14 21:03:29 --> Language Class Initialized
INFO - 2025-03-14 21:03:29 --> Language Class Initialized
INFO - 2025-03-14 21:03:29 --> Config Class Initialized
INFO - 2025-03-14 21:03:29 --> Loader Class Initialized
INFO - 2025-03-14 21:03:29 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:29 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:29 --> Email Class Initialized
INFO - 2025-03-14 21:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:29 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:29 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:29 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:29 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:29 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:29 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:29 --> Model Class Initialized
INFO - 2025-03-14 21:03:29 --> Config Class Initialized
INFO - 2025-03-14 21:03:29 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:29 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:29 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:29 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:29 --> Router Class Initialized
INFO - 2025-03-14 21:03:29 --> Output Class Initialized
INFO - 2025-03-14 21:03:29 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:29 --> Input Class Initialized
INFO - 2025-03-14 21:03:29 --> Language Class Initialized
INFO - 2025-03-14 21:03:29 --> Language Class Initialized
INFO - 2025-03-14 21:03:29 --> Config Class Initialized
INFO - 2025-03-14 21:03:29 --> Loader Class Initialized
INFO - 2025-03-14 21:03:29 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:29 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:29 --> Email Class Initialized
INFO - 2025-03-14 21:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:29 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:29 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:29 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:29 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:29 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:29 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:29 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:03:29 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:03:29 --> Model Class Initialized
ERROR - 2025-03-14 21:03:29 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:03:29 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:03:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:03:29 --> Final output sent to browser
DEBUG - 2025-03-14 21:03:29 --> Total execution time: 0.1436
INFO - 2025-03-14 21:03:34 --> Config Class Initialized
INFO - 2025-03-14 21:03:34 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:34 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:34 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:34 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:34 --> Router Class Initialized
INFO - 2025-03-14 21:03:34 --> Output Class Initialized
INFO - 2025-03-14 21:03:34 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:34 --> Input Class Initialized
INFO - 2025-03-14 21:03:34 --> Language Class Initialized
INFO - 2025-03-14 21:03:34 --> Language Class Initialized
INFO - 2025-03-14 21:03:34 --> Config Class Initialized
INFO - 2025-03-14 21:03:34 --> Loader Class Initialized
INFO - 2025-03-14 21:03:34 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:34 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:34 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:34 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:34 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:34 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:34 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:34 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:34 --> Email Class Initialized
INFO - 2025-03-14 21:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:34 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:34 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:34 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:34 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:34 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:34 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:34 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:34 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:03:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:03:34 --> Model Class Initialized
ERROR - 2025-03-14 21:03:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:03:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:03:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:03:34 --> Final output sent to browser
DEBUG - 2025-03-14 21:03:34 --> Total execution time: 0.0988
INFO - 2025-03-14 21:03:43 --> Config Class Initialized
INFO - 2025-03-14 21:03:43 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:43 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:43 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:43 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:43 --> Router Class Initialized
INFO - 2025-03-14 21:03:43 --> Output Class Initialized
INFO - 2025-03-14 21:03:43 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:43 --> Input Class Initialized
INFO - 2025-03-14 21:03:43 --> Language Class Initialized
INFO - 2025-03-14 21:03:43 --> Language Class Initialized
INFO - 2025-03-14 21:03:43 --> Config Class Initialized
INFO - 2025-03-14 21:03:43 --> Loader Class Initialized
INFO - 2025-03-14 21:03:43 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:43 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:43 --> Email Class Initialized
INFO - 2025-03-14 21:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:43 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:43 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:43 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:43 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:43 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:43 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:43 --> Model Class Initialized
INFO - 2025-03-14 21:03:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 21:03:43 --> INFO: Category Created Successfully -> Import->Test1->ChieldTest1
INFO - 2025-03-14 21:03:43 --> Config Class Initialized
INFO - 2025-03-14 21:03:43 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:03:43 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:03:43 --> Utf8 Class Initialized
INFO - 2025-03-14 21:03:43 --> URI Class Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:03:43 --> Router Class Initialized
INFO - 2025-03-14 21:03:43 --> Output Class Initialized
INFO - 2025-03-14 21:03:43 --> Security Class Initialized
DEBUG - 2025-03-14 21:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:03:43 --> Input Class Initialized
INFO - 2025-03-14 21:03:43 --> Language Class Initialized
INFO - 2025-03-14 21:03:43 --> Language Class Initialized
INFO - 2025-03-14 21:03:43 --> Config Class Initialized
INFO - 2025-03-14 21:03:43 --> Loader Class Initialized
INFO - 2025-03-14 21:03:43 --> Helper loaded: url_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: file_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: html_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: form_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: text_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:03:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:03:43 --> Database Driver Class Initialized
INFO - 2025-03-14 21:03:43 --> Email Class Initialized
INFO - 2025-03-14 21:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:03:43 --> Form Validation Class Initialized
INFO - 2025-03-14 21:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:03:43 --> Pagination Class Initialized
INFO - 2025-03-14 21:03:43 --> Controller Class Initialized
DEBUG - 2025-03-14 21:03:43 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:03:43 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:03:43 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:03:43 --> Model Class Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:03:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:03:43 --> Model Class Initialized
ERROR - 2025-03-14 21:03:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:03:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:03:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:03:43 --> Final output sent to browser
DEBUG - 2025-03-14 21:03:43 --> Total execution time: 0.1347
INFO - 2025-03-14 21:07:10 --> Config Class Initialized
INFO - 2025-03-14 21:07:10 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:07:10 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:07:10 --> Utf8 Class Initialized
INFO - 2025-03-14 21:07:10 --> URI Class Initialized
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:07:10 --> Router Class Initialized
INFO - 2025-03-14 21:07:10 --> Output Class Initialized
INFO - 2025-03-14 21:07:10 --> Security Class Initialized
DEBUG - 2025-03-14 21:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:07:10 --> Input Class Initialized
INFO - 2025-03-14 21:07:10 --> Language Class Initialized
INFO - 2025-03-14 21:07:10 --> Language Class Initialized
INFO - 2025-03-14 21:07:10 --> Config Class Initialized
INFO - 2025-03-14 21:07:10 --> Loader Class Initialized
INFO - 2025-03-14 21:07:10 --> Helper loaded: url_helper
INFO - 2025-03-14 21:07:10 --> Helper loaded: file_helper
INFO - 2025-03-14 21:07:10 --> Helper loaded: html_helper
INFO - 2025-03-14 21:07:10 --> Helper loaded: form_helper
INFO - 2025-03-14 21:07:10 --> Helper loaded: text_helper
INFO - 2025-03-14 21:07:10 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:07:10 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:07:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:07:10 --> Database Driver Class Initialized
INFO - 2025-03-14 21:07:10 --> Email Class Initialized
INFO - 2025-03-14 21:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:07:10 --> Form Validation Class Initialized
INFO - 2025-03-14 21:07:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:07:10 --> Pagination Class Initialized
INFO - 2025-03-14 21:07:10 --> Controller Class Initialized
DEBUG - 2025-03-14 21:07:10 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:07:10 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:07:10 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:07:10 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:07:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:07:10 --> Model Class Initialized
ERROR - 2025-03-14 21:07:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:07:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:07:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:07:10 --> Final output sent to browser
DEBUG - 2025-03-14 21:07:10 --> Total execution time: 0.1456
INFO - 2025-03-14 21:07:14 --> Config Class Initialized
INFO - 2025-03-14 21:07:14 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:07:14 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:07:14 --> Utf8 Class Initialized
INFO - 2025-03-14 21:07:14 --> URI Class Initialized
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:07:14 --> Router Class Initialized
INFO - 2025-03-14 21:07:14 --> Output Class Initialized
INFO - 2025-03-14 21:07:14 --> Security Class Initialized
DEBUG - 2025-03-14 21:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:07:14 --> Input Class Initialized
INFO - 2025-03-14 21:07:14 --> Language Class Initialized
INFO - 2025-03-14 21:07:14 --> Language Class Initialized
INFO - 2025-03-14 21:07:14 --> Config Class Initialized
INFO - 2025-03-14 21:07:14 --> Loader Class Initialized
INFO - 2025-03-14 21:07:14 --> Helper loaded: url_helper
INFO - 2025-03-14 21:07:14 --> Helper loaded: file_helper
INFO - 2025-03-14 21:07:14 --> Helper loaded: html_helper
INFO - 2025-03-14 21:07:14 --> Helper loaded: form_helper
INFO - 2025-03-14 21:07:14 --> Helper loaded: text_helper
INFO - 2025-03-14 21:07:14 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:07:14 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:07:14 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:07:14 --> Database Driver Class Initialized
INFO - 2025-03-14 21:07:14 --> Email Class Initialized
INFO - 2025-03-14 21:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:07:14 --> Form Validation Class Initialized
INFO - 2025-03-14 21:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:07:14 --> Pagination Class Initialized
INFO - 2025-03-14 21:07:14 --> Controller Class Initialized
DEBUG - 2025-03-14 21:07:14 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:07:14 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:14 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"34","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:07:14 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:07:14 --> Model Class Initialized
ERROR - 2025-03-14 21:07:14 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:07:14 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:07:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:07:14 --> Final output sent to browser
DEBUG - 2025-03-14 21:07:14 --> Total execution time: 0.1479
INFO - 2025-03-14 21:07:22 --> Config Class Initialized
INFO - 2025-03-14 21:07:22 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:07:22 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:07:22 --> Utf8 Class Initialized
INFO - 2025-03-14 21:07:22 --> URI Class Initialized
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:07:22 --> Router Class Initialized
INFO - 2025-03-14 21:07:22 --> Output Class Initialized
INFO - 2025-03-14 21:07:22 --> Security Class Initialized
DEBUG - 2025-03-14 21:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:07:22 --> Input Class Initialized
INFO - 2025-03-14 21:07:22 --> Language Class Initialized
INFO - 2025-03-14 21:07:22 --> Language Class Initialized
INFO - 2025-03-14 21:07:22 --> Config Class Initialized
INFO - 2025-03-14 21:07:22 --> Loader Class Initialized
INFO - 2025-03-14 21:07:22 --> Helper loaded: url_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: file_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: html_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: form_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: text_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:07:22 --> Database Driver Class Initialized
INFO - 2025-03-14 21:07:22 --> Email Class Initialized
INFO - 2025-03-14 21:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:07:22 --> Form Validation Class Initialized
INFO - 2025-03-14 21:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:07:22 --> Pagination Class Initialized
INFO - 2025-03-14 21:07:22 --> Controller Class Initialized
DEBUG - 2025-03-14 21:07:22 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:07:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:07:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:07:22 --> Model Class Initialized
ERROR - 2025-03-14 21:07:22 --> ERROR: Duplicate category found -> Import->Test1->ChieldTest1
INFO - 2025-03-14 21:07:22 --> Config Class Initialized
INFO - 2025-03-14 21:07:22 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:07:22 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:07:22 --> Utf8 Class Initialized
INFO - 2025-03-14 21:07:22 --> URI Class Initialized
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:07:22 --> Router Class Initialized
INFO - 2025-03-14 21:07:22 --> Output Class Initialized
INFO - 2025-03-14 21:07:22 --> Security Class Initialized
DEBUG - 2025-03-14 21:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:07:22 --> Input Class Initialized
INFO - 2025-03-14 21:07:22 --> Language Class Initialized
INFO - 2025-03-14 21:07:22 --> Language Class Initialized
INFO - 2025-03-14 21:07:22 --> Config Class Initialized
INFO - 2025-03-14 21:07:22 --> Loader Class Initialized
INFO - 2025-03-14 21:07:22 --> Helper loaded: url_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: file_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: html_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: form_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: text_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:07:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:07:22 --> Database Driver Class Initialized
INFO - 2025-03-14 21:07:22 --> Email Class Initialized
INFO - 2025-03-14 21:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:07:22 --> Form Validation Class Initialized
INFO - 2025-03-14 21:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:07:22 --> Pagination Class Initialized
INFO - 2025-03-14 21:07:22 --> Controller Class Initialized
DEBUG - 2025-03-14 21:07:22 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:07:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:07:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:07:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:22 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"34","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:07:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:07:22 --> Model Class Initialized
ERROR - 2025-03-14 21:07:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:07:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:07:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:07:22 --> Final output sent to browser
DEBUG - 2025-03-14 21:07:22 --> Total execution time: 0.1440
INFO - 2025-03-14 21:07:57 --> Config Class Initialized
INFO - 2025-03-14 21:07:57 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:07:57 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:07:57 --> Utf8 Class Initialized
INFO - 2025-03-14 21:07:57 --> URI Class Initialized
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:07:57 --> Router Class Initialized
INFO - 2025-03-14 21:07:57 --> Output Class Initialized
INFO - 2025-03-14 21:07:57 --> Security Class Initialized
DEBUG - 2025-03-14 21:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:07:57 --> Input Class Initialized
INFO - 2025-03-14 21:07:57 --> Language Class Initialized
INFO - 2025-03-14 21:07:57 --> Language Class Initialized
INFO - 2025-03-14 21:07:57 --> Config Class Initialized
INFO - 2025-03-14 21:07:57 --> Loader Class Initialized
INFO - 2025-03-14 21:07:57 --> Helper loaded: url_helper
INFO - 2025-03-14 21:07:57 --> Helper loaded: file_helper
INFO - 2025-03-14 21:07:57 --> Helper loaded: html_helper
INFO - 2025-03-14 21:07:57 --> Helper loaded: form_helper
INFO - 2025-03-14 21:07:57 --> Helper loaded: text_helper
INFO - 2025-03-14 21:07:57 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:07:57 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:07:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:07:57 --> Database Driver Class Initialized
INFO - 2025-03-14 21:07:57 --> Email Class Initialized
INFO - 2025-03-14 21:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:07:57 --> Form Validation Class Initialized
INFO - 2025-03-14 21:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:07:57 --> Pagination Class Initialized
INFO - 2025-03-14 21:07:57 --> Controller Class Initialized
DEBUG - 2025-03-14 21:07:57 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:07:57 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:07:57 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:07:57 --> Model Class Initialized
DEBUG - 2025-03-14 21:07:57 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"34","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:07:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:07:57 --> Model Class Initialized
ERROR - 2025-03-14 21:07:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:07:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:07:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:07:57 --> Final output sent to browser
DEBUG - 2025-03-14 21:07:57 --> Total execution time: 0.1184
INFO - 2025-03-14 21:08:18 --> Config Class Initialized
INFO - 2025-03-14 21:08:18 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:08:18 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:08:18 --> Utf8 Class Initialized
INFO - 2025-03-14 21:08:18 --> URI Class Initialized
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:08:18 --> Router Class Initialized
INFO - 2025-03-14 21:08:18 --> Output Class Initialized
INFO - 2025-03-14 21:08:18 --> Security Class Initialized
DEBUG - 2025-03-14 21:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:08:18 --> Input Class Initialized
INFO - 2025-03-14 21:08:18 --> Language Class Initialized
INFO - 2025-03-14 21:08:18 --> Language Class Initialized
INFO - 2025-03-14 21:08:18 --> Config Class Initialized
INFO - 2025-03-14 21:08:18 --> Loader Class Initialized
INFO - 2025-03-14 21:08:18 --> Helper loaded: url_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: file_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: html_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: form_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: text_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:08:18 --> Database Driver Class Initialized
INFO - 2025-03-14 21:08:18 --> Email Class Initialized
INFO - 2025-03-14 21:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:08:18 --> Form Validation Class Initialized
INFO - 2025-03-14 21:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:08:18 --> Pagination Class Initialized
INFO - 2025-03-14 21:08:18 --> Controller Class Initialized
DEBUG - 2025-03-14 21:08:18 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:08:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:08:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:08:18 --> Model Class Initialized
ERROR - 2025-03-14 21:08:18 --> ERROR: Duplicate category found -> Import->Test1->ChieldTest1
INFO - 2025-03-14 21:08:18 --> Config Class Initialized
INFO - 2025-03-14 21:08:18 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:08:18 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:08:18 --> Utf8 Class Initialized
INFO - 2025-03-14 21:08:18 --> URI Class Initialized
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:08:18 --> Router Class Initialized
INFO - 2025-03-14 21:08:18 --> Output Class Initialized
INFO - 2025-03-14 21:08:18 --> Security Class Initialized
DEBUG - 2025-03-14 21:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:08:18 --> Input Class Initialized
INFO - 2025-03-14 21:08:18 --> Language Class Initialized
INFO - 2025-03-14 21:08:18 --> Language Class Initialized
INFO - 2025-03-14 21:08:18 --> Config Class Initialized
INFO - 2025-03-14 21:08:18 --> Loader Class Initialized
INFO - 2025-03-14 21:08:18 --> Helper loaded: url_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: file_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: html_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: form_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: text_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:08:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:08:18 --> Database Driver Class Initialized
INFO - 2025-03-14 21:08:18 --> Email Class Initialized
INFO - 2025-03-14 21:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:08:18 --> Form Validation Class Initialized
INFO - 2025-03-14 21:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:08:18 --> Pagination Class Initialized
INFO - 2025-03-14 21:08:18 --> Controller Class Initialized
DEBUG - 2025-03-14 21:08:18 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:08:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:08:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:08:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:08:18 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"34","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:08:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:08:18 --> Model Class Initialized
ERROR - 2025-03-14 21:08:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:08:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:08:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:08:18 --> Final output sent to browser
DEBUG - 2025-03-14 21:08:18 --> Total execution time: 0.1343
INFO - 2025-03-14 21:12:15 --> Config Class Initialized
INFO - 2025-03-14 21:12:15 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:12:15 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:12:15 --> Utf8 Class Initialized
INFO - 2025-03-14 21:12:15 --> URI Class Initialized
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:12:15 --> Router Class Initialized
INFO - 2025-03-14 21:12:15 --> Output Class Initialized
INFO - 2025-03-14 21:12:15 --> Security Class Initialized
DEBUG - 2025-03-14 21:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:12:15 --> Input Class Initialized
INFO - 2025-03-14 21:12:15 --> Language Class Initialized
INFO - 2025-03-14 21:12:15 --> Language Class Initialized
INFO - 2025-03-14 21:12:15 --> Config Class Initialized
INFO - 2025-03-14 21:12:15 --> Loader Class Initialized
INFO - 2025-03-14 21:12:15 --> Helper loaded: url_helper
INFO - 2025-03-14 21:12:15 --> Helper loaded: file_helper
INFO - 2025-03-14 21:12:15 --> Helper loaded: html_helper
INFO - 2025-03-14 21:12:15 --> Helper loaded: form_helper
INFO - 2025-03-14 21:12:15 --> Helper loaded: text_helper
INFO - 2025-03-14 21:12:15 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:12:15 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:12:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:12:15 --> Database Driver Class Initialized
INFO - 2025-03-14 21:12:15 --> Email Class Initialized
INFO - 2025-03-14 21:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:12:15 --> Form Validation Class Initialized
INFO - 2025-03-14 21:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:12:15 --> Pagination Class Initialized
INFO - 2025-03-14 21:12:15 --> Controller Class Initialized
DEBUG - 2025-03-14 21:12:15 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:12:15 --> Model Class Initialized
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:12:15 --> Model Class Initialized
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:12:15 --> Model Class Initialized
DEBUG - 2025-03-14 21:12:15 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"34","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:12:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:12:15 --> Model Class Initialized
ERROR - 2025-03-14 21:12:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:12:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:12:15 --> Final output sent to browser
DEBUG - 2025-03-14 21:12:15 --> Total execution time: 0.1521
INFO - 2025-03-14 21:12:35 --> Config Class Initialized
INFO - 2025-03-14 21:12:35 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:12:35 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:12:35 --> Utf8 Class Initialized
INFO - 2025-03-14 21:12:35 --> URI Class Initialized
DEBUG - 2025-03-14 21:12:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:12:35 --> Router Class Initialized
INFO - 2025-03-14 21:12:35 --> Output Class Initialized
INFO - 2025-03-14 21:12:35 --> Security Class Initialized
DEBUG - 2025-03-14 21:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:12:35 --> Input Class Initialized
INFO - 2025-03-14 21:12:35 --> Language Class Initialized
INFO - 2025-03-14 21:12:35 --> Language Class Initialized
INFO - 2025-03-14 21:12:35 --> Config Class Initialized
INFO - 2025-03-14 21:12:35 --> Loader Class Initialized
INFO - 2025-03-14 21:12:35 --> Helper loaded: url_helper
INFO - 2025-03-14 21:12:35 --> Helper loaded: file_helper
INFO - 2025-03-14 21:12:35 --> Helper loaded: html_helper
INFO - 2025-03-14 21:12:35 --> Helper loaded: form_helper
INFO - 2025-03-14 21:12:35 --> Helper loaded: text_helper
INFO - 2025-03-14 21:12:35 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:12:35 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:12:35 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:12:35 --> Database Driver Class Initialized
INFO - 2025-03-14 21:12:35 --> Email Class Initialized
INFO - 2025-03-14 21:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:12:35 --> Form Validation Class Initialized
INFO - 2025-03-14 21:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:12:35 --> Pagination Class Initialized
INFO - 2025-03-14 21:12:35 --> Controller Class Initialized
DEBUG - 2025-03-14 21:12:35 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:12:35 --> Model Class Initialized
DEBUG - 2025-03-14 21:12:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:12:35 --> Model Class Initialized
DEBUG - 2025-03-14 21:12:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:12:35 --> Model Class Initialized
DEBUG - 2025-03-14 21:12:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:12:35 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:12:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:12:35 --> Model Class Initialized
ERROR - 2025-03-14 21:12:35 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:12:35 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:12:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:12:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:12:36 --> Final output sent to browser
DEBUG - 2025-03-14 21:12:36 --> Total execution time: 0.1920
INFO - 2025-03-14 21:13:13 --> Config Class Initialized
INFO - 2025-03-14 21:13:13 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:13:13 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:13:13 --> Utf8 Class Initialized
INFO - 2025-03-14 21:13:13 --> URI Class Initialized
DEBUG - 2025-03-14 21:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-14 21:13:13 --> No URI present. Default controller set.
INFO - 2025-03-14 21:13:13 --> Router Class Initialized
INFO - 2025-03-14 21:13:13 --> Output Class Initialized
INFO - 2025-03-14 21:13:13 --> Security Class Initialized
DEBUG - 2025-03-14 21:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:13:13 --> Input Class Initialized
INFO - 2025-03-14 21:13:13 --> Language Class Initialized
INFO - 2025-03-14 21:13:13 --> Language Class Initialized
INFO - 2025-03-14 21:13:13 --> Config Class Initialized
INFO - 2025-03-14 21:13:13 --> Loader Class Initialized
INFO - 2025-03-14 21:13:13 --> Helper loaded: url_helper
INFO - 2025-03-14 21:13:13 --> Helper loaded: file_helper
INFO - 2025-03-14 21:13:13 --> Helper loaded: html_helper
INFO - 2025-03-14 21:13:13 --> Helper loaded: form_helper
INFO - 2025-03-14 21:13:13 --> Helper loaded: text_helper
INFO - 2025-03-14 21:13:13 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:13:13 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:13:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:13:13 --> Database Driver Class Initialized
INFO - 2025-03-14 21:13:13 --> Email Class Initialized
INFO - 2025-03-14 21:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:13:13 --> Form Validation Class Initialized
INFO - 2025-03-14 21:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:13:13 --> Pagination Class Initialized
INFO - 2025-03-14 21:13:13 --> Controller Class Initialized
DEBUG - 2025-03-14 21:13:13 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:13:13 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:13:13 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:13:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:13:13 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-14 21:13:13 --> Final output sent to browser
DEBUG - 2025-03-14 21:13:13 --> Total execution time: 0.0257
INFO - 2025-03-14 21:13:28 --> Config Class Initialized
INFO - 2025-03-14 21:13:28 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:13:28 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:13:28 --> Utf8 Class Initialized
INFO - 2025-03-14 21:13:28 --> URI Class Initialized
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:13:28 --> Router Class Initialized
INFO - 2025-03-14 21:13:28 --> Output Class Initialized
INFO - 2025-03-14 21:13:28 --> Security Class Initialized
DEBUG - 2025-03-14 21:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:13:28 --> Input Class Initialized
INFO - 2025-03-14 21:13:28 --> Language Class Initialized
INFO - 2025-03-14 21:13:28 --> Language Class Initialized
INFO - 2025-03-14 21:13:28 --> Config Class Initialized
INFO - 2025-03-14 21:13:28 --> Loader Class Initialized
INFO - 2025-03-14 21:13:28 --> Helper loaded: url_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: file_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: html_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: form_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: text_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:13:28 --> Database Driver Class Initialized
INFO - 2025-03-14 21:13:28 --> Email Class Initialized
INFO - 2025-03-14 21:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:13:28 --> Form Validation Class Initialized
INFO - 2025-03-14 21:13:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:13:28 --> Pagination Class Initialized
INFO - 2025-03-14 21:13:28 --> Controller Class Initialized
DEBUG - 2025-03-14 21:13:28 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:13:28 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:13:28 --> Model Class Initialized
INFO - 2025-03-14 21:13:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 21:13:28 --> Config Class Initialized
INFO - 2025-03-14 21:13:28 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:13:28 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:13:28 --> Utf8 Class Initialized
INFO - 2025-03-14 21:13:28 --> URI Class Initialized
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:13:28 --> Router Class Initialized
INFO - 2025-03-14 21:13:28 --> Output Class Initialized
INFO - 2025-03-14 21:13:28 --> Security Class Initialized
DEBUG - 2025-03-14 21:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:13:28 --> Input Class Initialized
INFO - 2025-03-14 21:13:28 --> Language Class Initialized
INFO - 2025-03-14 21:13:28 --> Language Class Initialized
INFO - 2025-03-14 21:13:28 --> Config Class Initialized
INFO - 2025-03-14 21:13:28 --> Loader Class Initialized
INFO - 2025-03-14 21:13:28 --> Helper loaded: url_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: file_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: html_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: form_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: text_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:13:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:13:28 --> Database Driver Class Initialized
INFO - 2025-03-14 21:13:28 --> Email Class Initialized
INFO - 2025-03-14 21:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:13:28 --> Form Validation Class Initialized
INFO - 2025-03-14 21:13:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:13:28 --> Pagination Class Initialized
INFO - 2025-03-14 21:13:28 --> Controller Class Initialized
DEBUG - 2025-03-14 21:13:28 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:13:28 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:13:28 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:13:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:13:28 --> Model Class Initialized
ERROR - 2025-03-14 21:13:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:13:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:13:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:13:28 --> Final output sent to browser
DEBUG - 2025-03-14 21:13:28 --> Total execution time: 0.1110
INFO - 2025-03-14 21:13:41 --> Config Class Initialized
INFO - 2025-03-14 21:13:41 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:13:41 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:13:41 --> Utf8 Class Initialized
INFO - 2025-03-14 21:13:41 --> URI Class Initialized
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:13:41 --> Router Class Initialized
INFO - 2025-03-14 21:13:41 --> Output Class Initialized
INFO - 2025-03-14 21:13:41 --> Security Class Initialized
DEBUG - 2025-03-14 21:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:13:41 --> Input Class Initialized
INFO - 2025-03-14 21:13:41 --> Language Class Initialized
INFO - 2025-03-14 21:13:41 --> Language Class Initialized
INFO - 2025-03-14 21:13:41 --> Config Class Initialized
INFO - 2025-03-14 21:13:41 --> Loader Class Initialized
INFO - 2025-03-14 21:13:41 --> Helper loaded: url_helper
INFO - 2025-03-14 21:13:41 --> Helper loaded: file_helper
INFO - 2025-03-14 21:13:41 --> Helper loaded: html_helper
INFO - 2025-03-14 21:13:41 --> Helper loaded: form_helper
INFO - 2025-03-14 21:13:41 --> Helper loaded: text_helper
INFO - 2025-03-14 21:13:41 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:13:41 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:13:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:13:41 --> Database Driver Class Initialized
INFO - 2025-03-14 21:13:41 --> Email Class Initialized
INFO - 2025-03-14 21:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:13:41 --> Form Validation Class Initialized
INFO - 2025-03-14 21:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:13:41 --> Pagination Class Initialized
INFO - 2025-03-14 21:13:41 --> Controller Class Initialized
DEBUG - 2025-03-14 21:13:41 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:13:41 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:13:41 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:13:41 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:41 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"34","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:13:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:13:41 --> Model Class Initialized
ERROR - 2025-03-14 21:13:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:13:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:13:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:13:41 --> Final output sent to browser
DEBUG - 2025-03-14 21:13:41 --> Total execution time: 0.1458
INFO - 2025-03-14 21:13:56 --> Config Class Initialized
INFO - 2025-03-14 21:13:56 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:13:56 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:13:56 --> Utf8 Class Initialized
INFO - 2025-03-14 21:13:56 --> URI Class Initialized
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:13:56 --> Router Class Initialized
INFO - 2025-03-14 21:13:56 --> Output Class Initialized
INFO - 2025-03-14 21:13:56 --> Security Class Initialized
DEBUG - 2025-03-14 21:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:13:56 --> Input Class Initialized
INFO - 2025-03-14 21:13:56 --> Language Class Initialized
INFO - 2025-03-14 21:13:56 --> Language Class Initialized
INFO - 2025-03-14 21:13:56 --> Config Class Initialized
INFO - 2025-03-14 21:13:56 --> Loader Class Initialized
INFO - 2025-03-14 21:13:56 --> Helper loaded: url_helper
INFO - 2025-03-14 21:13:56 --> Helper loaded: file_helper
INFO - 2025-03-14 21:13:56 --> Helper loaded: html_helper
INFO - 2025-03-14 21:13:56 --> Helper loaded: form_helper
INFO - 2025-03-14 21:13:56 --> Helper loaded: text_helper
INFO - 2025-03-14 21:13:56 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:13:56 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:13:56 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:13:56 --> Database Driver Class Initialized
INFO - 2025-03-14 21:13:56 --> Email Class Initialized
INFO - 2025-03-14 21:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:13:56 --> Form Validation Class Initialized
INFO - 2025-03-14 21:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:13:56 --> Pagination Class Initialized
INFO - 2025-03-14 21:13:56 --> Controller Class Initialized
DEBUG - 2025-03-14 21:13:56 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:13:56 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:13:56 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:13:56 --> Model Class Initialized
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:13:56 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:13:56 --> Model Class Initialized
ERROR - 2025-03-14 21:13:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:13:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:13:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:13:56 --> Final output sent to browser
DEBUG - 2025-03-14 21:13:56 --> Total execution time: 0.1332
INFO - 2025-03-14 21:16:18 --> Config Class Initialized
INFO - 2025-03-14 21:16:18 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:16:18 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:16:18 --> Utf8 Class Initialized
INFO - 2025-03-14 21:16:18 --> URI Class Initialized
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:16:18 --> Router Class Initialized
INFO - 2025-03-14 21:16:18 --> Output Class Initialized
INFO - 2025-03-14 21:16:18 --> Security Class Initialized
DEBUG - 2025-03-14 21:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:16:18 --> Input Class Initialized
INFO - 2025-03-14 21:16:18 --> Language Class Initialized
INFO - 2025-03-14 21:16:18 --> Language Class Initialized
INFO - 2025-03-14 21:16:18 --> Config Class Initialized
INFO - 2025-03-14 21:16:18 --> Loader Class Initialized
INFO - 2025-03-14 21:16:18 --> Helper loaded: url_helper
INFO - 2025-03-14 21:16:18 --> Helper loaded: file_helper
INFO - 2025-03-14 21:16:18 --> Helper loaded: html_helper
INFO - 2025-03-14 21:16:18 --> Helper loaded: form_helper
INFO - 2025-03-14 21:16:18 --> Helper loaded: text_helper
INFO - 2025-03-14 21:16:18 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:16:18 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:16:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:16:18 --> Database Driver Class Initialized
INFO - 2025-03-14 21:16:18 --> Email Class Initialized
INFO - 2025-03-14 21:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:16:18 --> Form Validation Class Initialized
INFO - 2025-03-14 21:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:16:18 --> Pagination Class Initialized
INFO - 2025-03-14 21:16:18 --> Controller Class Initialized
DEBUG - 2025-03-14 21:16:18 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:16:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:16:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:16:18 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:16:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:16:18 --> Model Class Initialized
ERROR - 2025-03-14 21:16:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:16:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/unit_list.php
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:16:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:16:18 --> Final output sent to browser
DEBUG - 2025-03-14 21:16:18 --> Total execution time: 0.2303
INFO - 2025-03-14 21:16:22 --> Config Class Initialized
INFO - 2025-03-14 21:16:22 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:16:22 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:16:22 --> Utf8 Class Initialized
INFO - 2025-03-14 21:16:22 --> URI Class Initialized
DEBUG - 2025-03-14 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:16:22 --> Router Class Initialized
INFO - 2025-03-14 21:16:22 --> Output Class Initialized
INFO - 2025-03-14 21:16:22 --> Security Class Initialized
DEBUG - 2025-03-14 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:16:22 --> Input Class Initialized
INFO - 2025-03-14 21:16:22 --> Language Class Initialized
INFO - 2025-03-14 21:16:22 --> Language Class Initialized
INFO - 2025-03-14 21:16:22 --> Config Class Initialized
INFO - 2025-03-14 21:16:22 --> Loader Class Initialized
INFO - 2025-03-14 21:16:22 --> Helper loaded: url_helper
INFO - 2025-03-14 21:16:22 --> Helper loaded: file_helper
INFO - 2025-03-14 21:16:22 --> Helper loaded: html_helper
INFO - 2025-03-14 21:16:22 --> Helper loaded: form_helper
INFO - 2025-03-14 21:16:22 --> Helper loaded: text_helper
INFO - 2025-03-14 21:16:22 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:16:22 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:16:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:16:22 --> Database Driver Class Initialized
INFO - 2025-03-14 21:16:22 --> Email Class Initialized
INFO - 2025-03-14 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:16:22 --> Form Validation Class Initialized
INFO - 2025-03-14 21:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:16:22 --> Pagination Class Initialized
INFO - 2025-03-14 21:16:22 --> Controller Class Initialized
DEBUG - 2025-03-14 21:16:22 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:16:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:16:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:16:22 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:22 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"34","category_name":"Import->Test1->ChieldTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:16:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:16:22 --> Model Class Initialized
ERROR - 2025-03-14 21:16:22 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:16:22 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:16:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:16:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:16:23 --> Final output sent to browser
DEBUG - 2025-03-14 21:16:23 --> Total execution time: 0.1278
INFO - 2025-03-14 21:16:45 --> Config Class Initialized
INFO - 2025-03-14 21:16:45 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:16:45 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:16:45 --> Utf8 Class Initialized
INFO - 2025-03-14 21:16:45 --> URI Class Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:16:45 --> Router Class Initialized
INFO - 2025-03-14 21:16:45 --> Output Class Initialized
INFO - 2025-03-14 21:16:45 --> Security Class Initialized
DEBUG - 2025-03-14 21:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:16:45 --> Input Class Initialized
INFO - 2025-03-14 21:16:45 --> Language Class Initialized
INFO - 2025-03-14 21:16:45 --> Language Class Initialized
INFO - 2025-03-14 21:16:45 --> Config Class Initialized
INFO - 2025-03-14 21:16:45 --> Loader Class Initialized
INFO - 2025-03-14 21:16:45 --> Helper loaded: url_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: file_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: html_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: form_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: text_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:16:45 --> Database Driver Class Initialized
INFO - 2025-03-14 21:16:45 --> Email Class Initialized
INFO - 2025-03-14 21:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:16:45 --> Form Validation Class Initialized
INFO - 2025-03-14 21:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:16:45 --> Pagination Class Initialized
INFO - 2025-03-14 21:16:45 --> Controller Class Initialized
DEBUG - 2025-03-14 21:16:45 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:16:45 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:16:45 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:16:45 --> Model Class Initialized
INFO - 2025-03-14 21:16:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 21:16:45 --> INFO: Category Created Successfully -> Import->Test1->ChildTest1
INFO - 2025-03-14 21:16:45 --> Config Class Initialized
INFO - 2025-03-14 21:16:45 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:16:45 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:16:45 --> Utf8 Class Initialized
INFO - 2025-03-14 21:16:45 --> URI Class Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:16:45 --> Router Class Initialized
INFO - 2025-03-14 21:16:45 --> Output Class Initialized
INFO - 2025-03-14 21:16:45 --> Security Class Initialized
DEBUG - 2025-03-14 21:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:16:45 --> Input Class Initialized
INFO - 2025-03-14 21:16:45 --> Language Class Initialized
INFO - 2025-03-14 21:16:45 --> Language Class Initialized
INFO - 2025-03-14 21:16:45 --> Config Class Initialized
INFO - 2025-03-14 21:16:45 --> Loader Class Initialized
INFO - 2025-03-14 21:16:45 --> Helper loaded: url_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: file_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: html_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: form_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: text_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:16:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:16:45 --> Database Driver Class Initialized
INFO - 2025-03-14 21:16:45 --> Email Class Initialized
INFO - 2025-03-14 21:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:16:45 --> Form Validation Class Initialized
INFO - 2025-03-14 21:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:16:45 --> Pagination Class Initialized
INFO - 2025-03-14 21:16:45 --> Controller Class Initialized
DEBUG - 2025-03-14 21:16:45 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:16:45 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:16:45 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:16:45 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:16:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:16:45 --> Model Class Initialized
ERROR - 2025-03-14 21:16:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:16:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:16:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:16:45 --> Final output sent to browser
DEBUG - 2025-03-14 21:16:45 --> Total execution time: 0.1265
INFO - 2025-03-14 21:16:55 --> Config Class Initialized
INFO - 2025-03-14 21:16:55 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:16:55 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:16:55 --> Utf8 Class Initialized
INFO - 2025-03-14 21:16:55 --> URI Class Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:16:55 --> Router Class Initialized
INFO - 2025-03-14 21:16:55 --> Output Class Initialized
INFO - 2025-03-14 21:16:55 --> Security Class Initialized
DEBUG - 2025-03-14 21:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:16:55 --> Input Class Initialized
INFO - 2025-03-14 21:16:55 --> Language Class Initialized
INFO - 2025-03-14 21:16:55 --> Language Class Initialized
INFO - 2025-03-14 21:16:55 --> Config Class Initialized
INFO - 2025-03-14 21:16:55 --> Loader Class Initialized
INFO - 2025-03-14 21:16:55 --> Helper loaded: url_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: file_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: html_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: form_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: text_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:16:55 --> Database Driver Class Initialized
INFO - 2025-03-14 21:16:55 --> Email Class Initialized
INFO - 2025-03-14 21:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:16:55 --> Form Validation Class Initialized
INFO - 2025-03-14 21:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:16:55 --> Pagination Class Initialized
INFO - 2025-03-14 21:16:55 --> Controller Class Initialized
DEBUG - 2025-03-14 21:16:55 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:16:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:16:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:16:55 --> Model Class Initialized
INFO - 2025-03-14 21:16:55 --> Config Class Initialized
INFO - 2025-03-14 21:16:55 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:16:55 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:16:55 --> Utf8 Class Initialized
INFO - 2025-03-14 21:16:55 --> URI Class Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:16:55 --> Router Class Initialized
INFO - 2025-03-14 21:16:55 --> Output Class Initialized
INFO - 2025-03-14 21:16:55 --> Security Class Initialized
DEBUG - 2025-03-14 21:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:16:55 --> Input Class Initialized
INFO - 2025-03-14 21:16:55 --> Language Class Initialized
INFO - 2025-03-14 21:16:55 --> Language Class Initialized
INFO - 2025-03-14 21:16:55 --> Config Class Initialized
INFO - 2025-03-14 21:16:55 --> Loader Class Initialized
INFO - 2025-03-14 21:16:55 --> Helper loaded: url_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: file_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: html_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: form_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: text_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:16:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:16:55 --> Database Driver Class Initialized
INFO - 2025-03-14 21:16:55 --> Email Class Initialized
INFO - 2025-03-14 21:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:16:55 --> Form Validation Class Initialized
INFO - 2025-03-14 21:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:16:55 --> Pagination Class Initialized
INFO - 2025-03-14 21:16:55 --> Controller Class Initialized
DEBUG - 2025-03-14 21:16:55 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:16:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:16:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:16:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:16:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:16:55 --> Model Class Initialized
ERROR - 2025-03-14 21:16:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:16:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:16:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:16:55 --> Final output sent to browser
DEBUG - 2025-03-14 21:16:55 --> Total execution time: 0.1248
INFO - 2025-03-14 21:17:03 --> Config Class Initialized
INFO - 2025-03-14 21:17:03 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:17:03 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:17:03 --> Utf8 Class Initialized
INFO - 2025-03-14 21:17:03 --> URI Class Initialized
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:17:03 --> Router Class Initialized
INFO - 2025-03-14 21:17:03 --> Output Class Initialized
INFO - 2025-03-14 21:17:03 --> Security Class Initialized
DEBUG - 2025-03-14 21:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:17:03 --> Input Class Initialized
INFO - 2025-03-14 21:17:03 --> Language Class Initialized
INFO - 2025-03-14 21:17:03 --> Language Class Initialized
INFO - 2025-03-14 21:17:03 --> Config Class Initialized
INFO - 2025-03-14 21:17:03 --> Loader Class Initialized
INFO - 2025-03-14 21:17:03 --> Helper loaded: url_helper
INFO - 2025-03-14 21:17:03 --> Helper loaded: file_helper
INFO - 2025-03-14 21:17:03 --> Helper loaded: html_helper
INFO - 2025-03-14 21:17:03 --> Helper loaded: form_helper
INFO - 2025-03-14 21:17:03 --> Helper loaded: text_helper
INFO - 2025-03-14 21:17:03 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:17:03 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:17:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:17:03 --> Database Driver Class Initialized
INFO - 2025-03-14 21:17:03 --> Email Class Initialized
INFO - 2025-03-14 21:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:17:03 --> Form Validation Class Initialized
INFO - 2025-03-14 21:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:17:03 --> Pagination Class Initialized
INFO - 2025-03-14 21:17:03 --> Controller Class Initialized
DEBUG - 2025-03-14 21:17:03 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:17:03 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:17:03 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:17:03 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:03 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:17:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:17:03 --> Model Class Initialized
ERROR - 2025-03-14 21:17:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:17:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:17:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:17:03 --> Final output sent to browser
DEBUG - 2025-03-14 21:17:03 --> Total execution time: 0.1188
INFO - 2025-03-14 21:17:24 --> Config Class Initialized
INFO - 2025-03-14 21:17:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:17:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:17:24 --> Utf8 Class Initialized
INFO - 2025-03-14 21:17:24 --> URI Class Initialized
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:17:24 --> Router Class Initialized
INFO - 2025-03-14 21:17:24 --> Output Class Initialized
INFO - 2025-03-14 21:17:24 --> Security Class Initialized
DEBUG - 2025-03-14 21:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:17:24 --> Input Class Initialized
INFO - 2025-03-14 21:17:24 --> Language Class Initialized
INFO - 2025-03-14 21:17:24 --> Language Class Initialized
INFO - 2025-03-14 21:17:24 --> Config Class Initialized
INFO - 2025-03-14 21:17:24 --> Loader Class Initialized
INFO - 2025-03-14 21:17:24 --> Helper loaded: url_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: file_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: html_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: form_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: text_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:17:24 --> Database Driver Class Initialized
INFO - 2025-03-14 21:17:24 --> Email Class Initialized
INFO - 2025-03-14 21:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:17:24 --> Form Validation Class Initialized
INFO - 2025-03-14 21:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:17:24 --> Pagination Class Initialized
INFO - 2025-03-14 21:17:24 --> Controller Class Initialized
DEBUG - 2025-03-14 21:17:24 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:17:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:17:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:17:24 --> Model Class Initialized
ERROR - 2025-03-14 21:17:24 --> ERROR: Duplicate category found -> Import->Test1->ChildTest1
INFO - 2025-03-14 21:17:24 --> Config Class Initialized
INFO - 2025-03-14 21:17:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:17:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:17:24 --> Utf8 Class Initialized
INFO - 2025-03-14 21:17:24 --> URI Class Initialized
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:17:24 --> Router Class Initialized
INFO - 2025-03-14 21:17:24 --> Output Class Initialized
INFO - 2025-03-14 21:17:24 --> Security Class Initialized
DEBUG - 2025-03-14 21:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:17:24 --> Input Class Initialized
INFO - 2025-03-14 21:17:24 --> Language Class Initialized
INFO - 2025-03-14 21:17:24 --> Language Class Initialized
INFO - 2025-03-14 21:17:24 --> Config Class Initialized
INFO - 2025-03-14 21:17:24 --> Loader Class Initialized
INFO - 2025-03-14 21:17:24 --> Helper loaded: url_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: file_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: html_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: form_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: text_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:17:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:17:24 --> Database Driver Class Initialized
INFO - 2025-03-14 21:17:24 --> Email Class Initialized
INFO - 2025-03-14 21:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:17:24 --> Form Validation Class Initialized
INFO - 2025-03-14 21:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:17:24 --> Pagination Class Initialized
INFO - 2025-03-14 21:17:24 --> Controller Class Initialized
DEBUG - 2025-03-14 21:17:24 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:17:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:17:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:17:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:17:24 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:17:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:17:24 --> Model Class Initialized
ERROR - 2025-03-14 21:17:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:17:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:17:24 --> Final output sent to browser
DEBUG - 2025-03-14 21:17:24 --> Total execution time: 0.1314
INFO - 2025-03-14 21:22:11 --> Config Class Initialized
INFO - 2025-03-14 21:22:11 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:22:11 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:22:11 --> Utf8 Class Initialized
INFO - 2025-03-14 21:22:11 --> URI Class Initialized
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:22:11 --> Router Class Initialized
INFO - 2025-03-14 21:22:11 --> Output Class Initialized
INFO - 2025-03-14 21:22:11 --> Security Class Initialized
DEBUG - 2025-03-14 21:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:22:11 --> Input Class Initialized
INFO - 2025-03-14 21:22:11 --> Language Class Initialized
INFO - 2025-03-14 21:22:11 --> Language Class Initialized
INFO - 2025-03-14 21:22:11 --> Config Class Initialized
INFO - 2025-03-14 21:22:11 --> Loader Class Initialized
INFO - 2025-03-14 21:22:11 --> Helper loaded: url_helper
INFO - 2025-03-14 21:22:11 --> Helper loaded: file_helper
INFO - 2025-03-14 21:22:11 --> Helper loaded: html_helper
INFO - 2025-03-14 21:22:11 --> Helper loaded: form_helper
INFO - 2025-03-14 21:22:11 --> Helper loaded: text_helper
INFO - 2025-03-14 21:22:11 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:22:11 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:22:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:22:11 --> Database Driver Class Initialized
INFO - 2025-03-14 21:22:11 --> Email Class Initialized
INFO - 2025-03-14 21:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:22:11 --> Form Validation Class Initialized
INFO - 2025-03-14 21:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:22:11 --> Pagination Class Initialized
INFO - 2025-03-14 21:22:11 --> Controller Class Initialized
DEBUG - 2025-03-14 21:22:11 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:22:11 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:22:11 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:22:11 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:11 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:22:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:22:11 --> Model Class Initialized
ERROR - 2025-03-14 21:22:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:22:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:22:11 --> Final output sent to browser
DEBUG - 2025-03-14 21:22:11 --> Total execution time: 0.3801
INFO - 2025-03-14 21:22:19 --> Config Class Initialized
INFO - 2025-03-14 21:22:19 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:22:19 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:22:19 --> Utf8 Class Initialized
INFO - 2025-03-14 21:22:19 --> URI Class Initialized
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:22:19 --> Router Class Initialized
INFO - 2025-03-14 21:22:19 --> Output Class Initialized
INFO - 2025-03-14 21:22:19 --> Security Class Initialized
DEBUG - 2025-03-14 21:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:22:19 --> Input Class Initialized
INFO - 2025-03-14 21:22:19 --> Language Class Initialized
INFO - 2025-03-14 21:22:19 --> Language Class Initialized
INFO - 2025-03-14 21:22:19 --> Config Class Initialized
INFO - 2025-03-14 21:22:19 --> Loader Class Initialized
INFO - 2025-03-14 21:22:19 --> Helper loaded: url_helper
INFO - 2025-03-14 21:22:19 --> Helper loaded: file_helper
INFO - 2025-03-14 21:22:19 --> Helper loaded: html_helper
INFO - 2025-03-14 21:22:19 --> Helper loaded: form_helper
INFO - 2025-03-14 21:22:19 --> Helper loaded: text_helper
INFO - 2025-03-14 21:22:19 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:22:19 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:22:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:22:19 --> Database Driver Class Initialized
INFO - 2025-03-14 21:22:19 --> Email Class Initialized
INFO - 2025-03-14 21:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:22:19 --> Form Validation Class Initialized
INFO - 2025-03-14 21:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:22:19 --> Pagination Class Initialized
INFO - 2025-03-14 21:22:19 --> Controller Class Initialized
DEBUG - 2025-03-14 21:22:19 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:22:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:22:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:22:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:19 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:22:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:22:19 --> Model Class Initialized
ERROR - 2025-03-14 21:22:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:22:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:22:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:22:19 --> Final output sent to browser
DEBUG - 2025-03-14 21:22:19 --> Total execution time: 0.1166
INFO - 2025-03-14 21:22:26 --> Config Class Initialized
INFO - 2025-03-14 21:22:26 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:22:26 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:22:26 --> Utf8 Class Initialized
INFO - 2025-03-14 21:22:26 --> URI Class Initialized
DEBUG - 2025-03-14 21:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:22:26 --> Router Class Initialized
INFO - 2025-03-14 21:22:26 --> Output Class Initialized
INFO - 2025-03-14 21:22:26 --> Security Class Initialized
DEBUG - 2025-03-14 21:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:22:26 --> Input Class Initialized
INFO - 2025-03-14 21:22:26 --> Language Class Initialized
INFO - 2025-03-14 21:22:26 --> Language Class Initialized
INFO - 2025-03-14 21:22:26 --> Config Class Initialized
INFO - 2025-03-14 21:22:26 --> Loader Class Initialized
INFO - 2025-03-14 21:22:26 --> Helper loaded: url_helper
INFO - 2025-03-14 21:22:26 --> Helper loaded: file_helper
INFO - 2025-03-14 21:22:26 --> Helper loaded: html_helper
INFO - 2025-03-14 21:22:26 --> Helper loaded: form_helper
INFO - 2025-03-14 21:22:26 --> Helper loaded: text_helper
INFO - 2025-03-14 21:22:26 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:22:26 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:22:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:22:26 --> Database Driver Class Initialized
INFO - 2025-03-14 21:22:26 --> Email Class Initialized
INFO - 2025-03-14 21:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:22:26 --> Form Validation Class Initialized
INFO - 2025-03-14 21:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:22:26 --> Pagination Class Initialized
INFO - 2025-03-14 21:22:26 --> Controller Class Initialized
DEBUG - 2025-03-14 21:22:26 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:22:26 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:22:26 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:22:26 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:26 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:22:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:22:26 --> Model Class Initialized
ERROR - 2025-03-14 21:22:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:22:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:22:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:22:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:22:27 --> Final output sent to browser
DEBUG - 2025-03-14 21:22:27 --> Total execution time: 0.2963
INFO - 2025-03-14 21:22:50 --> Config Class Initialized
INFO - 2025-03-14 21:22:50 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:22:50 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:22:50 --> Utf8 Class Initialized
INFO - 2025-03-14 21:22:50 --> URI Class Initialized
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:22:50 --> Router Class Initialized
INFO - 2025-03-14 21:22:50 --> Output Class Initialized
INFO - 2025-03-14 21:22:50 --> Security Class Initialized
DEBUG - 2025-03-14 21:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:22:50 --> Input Class Initialized
INFO - 2025-03-14 21:22:50 --> Language Class Initialized
INFO - 2025-03-14 21:22:50 --> Language Class Initialized
INFO - 2025-03-14 21:22:50 --> Config Class Initialized
INFO - 2025-03-14 21:22:50 --> Loader Class Initialized
INFO - 2025-03-14 21:22:50 --> Helper loaded: url_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: file_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: html_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: form_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: text_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:22:50 --> Database Driver Class Initialized
INFO - 2025-03-14 21:22:50 --> Email Class Initialized
INFO - 2025-03-14 21:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:22:50 --> Form Validation Class Initialized
INFO - 2025-03-14 21:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:22:50 --> Pagination Class Initialized
INFO - 2025-03-14 21:22:50 --> Controller Class Initialized
DEBUG - 2025-03-14 21:22:50 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:22:50 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:22:50 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:22:50 --> Model Class Initialized
ERROR - 2025-03-14 21:22:50 --> ERROR: Duplicate category found -> Import->Test1->ChildTest1
INFO - 2025-03-14 21:22:50 --> Config Class Initialized
INFO - 2025-03-14 21:22:50 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:22:50 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:22:50 --> Utf8 Class Initialized
INFO - 2025-03-14 21:22:50 --> URI Class Initialized
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:22:50 --> Router Class Initialized
INFO - 2025-03-14 21:22:50 --> Output Class Initialized
INFO - 2025-03-14 21:22:50 --> Security Class Initialized
DEBUG - 2025-03-14 21:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:22:50 --> Input Class Initialized
INFO - 2025-03-14 21:22:50 --> Language Class Initialized
INFO - 2025-03-14 21:22:50 --> Language Class Initialized
INFO - 2025-03-14 21:22:50 --> Config Class Initialized
INFO - 2025-03-14 21:22:50 --> Loader Class Initialized
INFO - 2025-03-14 21:22:50 --> Helper loaded: url_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: file_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: html_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: form_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: text_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:22:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:22:50 --> Database Driver Class Initialized
INFO - 2025-03-14 21:22:50 --> Email Class Initialized
INFO - 2025-03-14 21:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:22:50 --> Form Validation Class Initialized
INFO - 2025-03-14 21:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:22:50 --> Pagination Class Initialized
INFO - 2025-03-14 21:22:50 --> Controller Class Initialized
DEBUG - 2025-03-14 21:22:50 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:22:50 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:22:50 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:22:50 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:50 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:22:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:22:50 --> Model Class Initialized
ERROR - 2025-03-14 21:22:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:22:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:22:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:22:50 --> Final output sent to browser
DEBUG - 2025-03-14 21:22:50 --> Total execution time: 0.1091
INFO - 2025-03-14 21:22:59 --> Config Class Initialized
INFO - 2025-03-14 21:22:59 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:22:59 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:22:59 --> Utf8 Class Initialized
INFO - 2025-03-14 21:22:59 --> URI Class Initialized
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:22:59 --> Router Class Initialized
INFO - 2025-03-14 21:22:59 --> Output Class Initialized
INFO - 2025-03-14 21:22:59 --> Security Class Initialized
DEBUG - 2025-03-14 21:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:22:59 --> Input Class Initialized
INFO - 2025-03-14 21:22:59 --> Language Class Initialized
INFO - 2025-03-14 21:22:59 --> Language Class Initialized
INFO - 2025-03-14 21:22:59 --> Config Class Initialized
INFO - 2025-03-14 21:22:59 --> Loader Class Initialized
INFO - 2025-03-14 21:22:59 --> Helper loaded: url_helper
INFO - 2025-03-14 21:22:59 --> Helper loaded: file_helper
INFO - 2025-03-14 21:22:59 --> Helper loaded: html_helper
INFO - 2025-03-14 21:22:59 --> Helper loaded: form_helper
INFO - 2025-03-14 21:22:59 --> Helper loaded: text_helper
INFO - 2025-03-14 21:22:59 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:22:59 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:22:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:22:59 --> Database Driver Class Initialized
INFO - 2025-03-14 21:22:59 --> Email Class Initialized
INFO - 2025-03-14 21:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:22:59 --> Form Validation Class Initialized
INFO - 2025-03-14 21:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:22:59 --> Pagination Class Initialized
INFO - 2025-03-14 21:22:59 --> Controller Class Initialized
DEBUG - 2025-03-14 21:22:59 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:22:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:22:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:22:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:22:59 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:22:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:22:59 --> Model Class Initialized
ERROR - 2025-03-14 21:22:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:22:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:22:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:22:59 --> Final output sent to browser
DEBUG - 2025-03-14 21:22:59 --> Total execution time: 0.0939
INFO - 2025-03-14 21:27:40 --> Config Class Initialized
INFO - 2025-03-14 21:27:40 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:27:40 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:27:40 --> Utf8 Class Initialized
INFO - 2025-03-14 21:27:40 --> URI Class Initialized
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:27:40 --> Router Class Initialized
INFO - 2025-03-14 21:27:40 --> Output Class Initialized
INFO - 2025-03-14 21:27:40 --> Security Class Initialized
DEBUG - 2025-03-14 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:27:40 --> Input Class Initialized
INFO - 2025-03-14 21:27:40 --> Language Class Initialized
INFO - 2025-03-14 21:27:40 --> Language Class Initialized
INFO - 2025-03-14 21:27:40 --> Config Class Initialized
INFO - 2025-03-14 21:27:40 --> Loader Class Initialized
INFO - 2025-03-14 21:27:40 --> Helper loaded: url_helper
INFO - 2025-03-14 21:27:40 --> Helper loaded: file_helper
INFO - 2025-03-14 21:27:40 --> Helper loaded: html_helper
INFO - 2025-03-14 21:27:40 --> Helper loaded: form_helper
INFO - 2025-03-14 21:27:40 --> Helper loaded: text_helper
INFO - 2025-03-14 21:27:40 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:27:40 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:27:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:27:40 --> Database Driver Class Initialized
INFO - 2025-03-14 21:27:40 --> Email Class Initialized
INFO - 2025-03-14 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:27:40 --> Form Validation Class Initialized
INFO - 2025-03-14 21:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:27:40 --> Pagination Class Initialized
INFO - 2025-03-14 21:27:40 --> Controller Class Initialized
DEBUG - 2025-03-14 21:27:40 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:27:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:27:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:27:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:40 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:27:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:27:40 --> Model Class Initialized
ERROR - 2025-03-14 21:27:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:27:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:27:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:27:40 --> Final output sent to browser
DEBUG - 2025-03-14 21:27:40 --> Total execution time: 0.1415
INFO - 2025-03-14 21:27:47 --> Config Class Initialized
INFO - 2025-03-14 21:27:47 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:27:47 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:27:47 --> Utf8 Class Initialized
INFO - 2025-03-14 21:27:47 --> URI Class Initialized
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:27:47 --> Router Class Initialized
INFO - 2025-03-14 21:27:47 --> Output Class Initialized
INFO - 2025-03-14 21:27:47 --> Security Class Initialized
DEBUG - 2025-03-14 21:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:27:47 --> Input Class Initialized
INFO - 2025-03-14 21:27:47 --> Language Class Initialized
INFO - 2025-03-14 21:27:47 --> Language Class Initialized
INFO - 2025-03-14 21:27:47 --> Config Class Initialized
INFO - 2025-03-14 21:27:47 --> Loader Class Initialized
INFO - 2025-03-14 21:27:47 --> Helper loaded: url_helper
INFO - 2025-03-14 21:27:47 --> Helper loaded: file_helper
INFO - 2025-03-14 21:27:47 --> Helper loaded: html_helper
INFO - 2025-03-14 21:27:47 --> Helper loaded: form_helper
INFO - 2025-03-14 21:27:47 --> Helper loaded: text_helper
INFO - 2025-03-14 21:27:47 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:27:47 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:27:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:27:47 --> Database Driver Class Initialized
INFO - 2025-03-14 21:27:47 --> Email Class Initialized
INFO - 2025-03-14 21:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:27:47 --> Form Validation Class Initialized
INFO - 2025-03-14 21:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:27:47 --> Pagination Class Initialized
INFO - 2025-03-14 21:27:47 --> Controller Class Initialized
DEBUG - 2025-03-14 21:27:47 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:27:47 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:27:47 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:27:47 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:47 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:27:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:27:47 --> Model Class Initialized
ERROR - 2025-03-14 21:27:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:27:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:27:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:27:47 --> Final output sent to browser
DEBUG - 2025-03-14 21:27:47 --> Total execution time: 0.1352
INFO - 2025-03-14 21:27:55 --> Config Class Initialized
INFO - 2025-03-14 21:27:55 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:27:55 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:27:55 --> Utf8 Class Initialized
INFO - 2025-03-14 21:27:55 --> URI Class Initialized
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:27:55 --> Router Class Initialized
INFO - 2025-03-14 21:27:55 --> Output Class Initialized
INFO - 2025-03-14 21:27:55 --> Security Class Initialized
DEBUG - 2025-03-14 21:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:27:55 --> Input Class Initialized
INFO - 2025-03-14 21:27:55 --> Language Class Initialized
INFO - 2025-03-14 21:27:55 --> Language Class Initialized
INFO - 2025-03-14 21:27:55 --> Config Class Initialized
INFO - 2025-03-14 21:27:55 --> Loader Class Initialized
INFO - 2025-03-14 21:27:55 --> Helper loaded: url_helper
INFO - 2025-03-14 21:27:55 --> Helper loaded: file_helper
INFO - 2025-03-14 21:27:55 --> Helper loaded: html_helper
INFO - 2025-03-14 21:27:55 --> Helper loaded: form_helper
INFO - 2025-03-14 21:27:55 --> Helper loaded: text_helper
INFO - 2025-03-14 21:27:55 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:27:55 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:27:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:27:55 --> Database Driver Class Initialized
INFO - 2025-03-14 21:27:55 --> Email Class Initialized
INFO - 2025-03-14 21:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:27:55 --> Form Validation Class Initialized
INFO - 2025-03-14 21:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:27:55 --> Pagination Class Initialized
INFO - 2025-03-14 21:27:55 --> Controller Class Initialized
DEBUG - 2025-03-14 21:27:55 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:27:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:27:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:27:55 --> Model Class Initialized
DEBUG - 2025-03-14 21:27:55 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:27:55 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:27:55 --> Model Class Initialized
ERROR - 2025-03-14 21:27:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:27:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:27:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:27:55 --> Final output sent to browser
DEBUG - 2025-03-14 21:27:55 --> Total execution time: 0.1240
INFO - 2025-03-14 21:28:06 --> Config Class Initialized
INFO - 2025-03-14 21:28:06 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:06 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:06 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:06 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:28:06 --> Router Class Initialized
INFO - 2025-03-14 21:28:06 --> Output Class Initialized
INFO - 2025-03-14 21:28:06 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:06 --> Input Class Initialized
INFO - 2025-03-14 21:28:06 --> Language Class Initialized
INFO - 2025-03-14 21:28:06 --> Language Class Initialized
INFO - 2025-03-14 21:28:06 --> Config Class Initialized
INFO - 2025-03-14 21:28:06 --> Loader Class Initialized
INFO - 2025-03-14 21:28:06 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:06 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:06 --> Email Class Initialized
INFO - 2025-03-14 21:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:06 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:06 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:06 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:06 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:28:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:28:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:28:06 --> Model Class Initialized
ERROR - 2025-03-14 21:28:06 --> ERROR: Duplicate category found -> Import->Test1->ChildTest1
INFO - 2025-03-14 21:28:06 --> Config Class Initialized
INFO - 2025-03-14 21:28:06 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:06 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:06 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:06 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:28:06 --> Router Class Initialized
INFO - 2025-03-14 21:28:06 --> Output Class Initialized
INFO - 2025-03-14 21:28:06 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:06 --> Input Class Initialized
INFO - 2025-03-14 21:28:06 --> Language Class Initialized
INFO - 2025-03-14 21:28:06 --> Language Class Initialized
INFO - 2025-03-14 21:28:06 --> Config Class Initialized
INFO - 2025-03-14 21:28:06 --> Loader Class Initialized
INFO - 2025-03-14 21:28:06 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:06 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:06 --> Email Class Initialized
INFO - 2025-03-14 21:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:06 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:06 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:06 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:06 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:28:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:28:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:28:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:06 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:28:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:28:06 --> Model Class Initialized
ERROR - 2025-03-14 21:28:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:28:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:28:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:28:06 --> Final output sent to browser
DEBUG - 2025-03-14 21:28:06 --> Total execution time: 0.0878
INFO - 2025-03-14 21:28:23 --> Config Class Initialized
INFO - 2025-03-14 21:28:23 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:23 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:23 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:23 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:28:23 --> Router Class Initialized
INFO - 2025-03-14 21:28:23 --> Output Class Initialized
INFO - 2025-03-14 21:28:23 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:23 --> Input Class Initialized
INFO - 2025-03-14 21:28:23 --> Language Class Initialized
INFO - 2025-03-14 21:28:23 --> Language Class Initialized
INFO - 2025-03-14 21:28:23 --> Config Class Initialized
INFO - 2025-03-14 21:28:23 --> Loader Class Initialized
INFO - 2025-03-14 21:28:23 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:23 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:23 --> Email Class Initialized
INFO - 2025-03-14 21:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:23 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:23 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:23 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:23 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:28:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:28:23 --> Model Class Initialized
INFO - 2025-03-14 21:28:23 --> Config Class Initialized
INFO - 2025-03-14 21:28:23 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:23 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:23 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:23 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:28:23 --> Router Class Initialized
INFO - 2025-03-14 21:28:23 --> Output Class Initialized
INFO - 2025-03-14 21:28:23 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:23 --> Input Class Initialized
INFO - 2025-03-14 21:28:23 --> Language Class Initialized
INFO - 2025-03-14 21:28:23 --> Language Class Initialized
INFO - 2025-03-14 21:28:23 --> Config Class Initialized
INFO - 2025-03-14 21:28:23 --> Loader Class Initialized
INFO - 2025-03-14 21:28:23 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:23 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:23 --> Email Class Initialized
INFO - 2025-03-14 21:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:23 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:23 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:23 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:23 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:28:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:28:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:28:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:28:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-14 21:28:23 --> Final output sent to browser
DEBUG - 2025-03-14 21:28:23 --> Total execution time: 0.0133
INFO - 2025-03-14 21:28:44 --> Config Class Initialized
INFO - 2025-03-14 21:28:44 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:44 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:44 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:44 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:28:44 --> Router Class Initialized
INFO - 2025-03-14 21:28:44 --> Output Class Initialized
INFO - 2025-03-14 21:28:44 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:44 --> Input Class Initialized
INFO - 2025-03-14 21:28:44 --> Language Class Initialized
INFO - 2025-03-14 21:28:44 --> Language Class Initialized
INFO - 2025-03-14 21:28:44 --> Config Class Initialized
INFO - 2025-03-14 21:28:44 --> Loader Class Initialized
INFO - 2025-03-14 21:28:44 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:44 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:44 --> Email Class Initialized
INFO - 2025-03-14 21:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:44 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:44 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:44 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:44 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:28:44 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:28:44 --> Model Class Initialized
INFO - 2025-03-14 21:28:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 21:28:44 --> Config Class Initialized
INFO - 2025-03-14 21:28:44 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:44 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:44 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:44 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:28:44 --> Router Class Initialized
INFO - 2025-03-14 21:28:44 --> Output Class Initialized
INFO - 2025-03-14 21:28:44 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:44 --> Input Class Initialized
INFO - 2025-03-14 21:28:44 --> Language Class Initialized
INFO - 2025-03-14 21:28:44 --> Language Class Initialized
INFO - 2025-03-14 21:28:44 --> Config Class Initialized
INFO - 2025-03-14 21:28:44 --> Loader Class Initialized
INFO - 2025-03-14 21:28:44 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:44 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:44 --> Email Class Initialized
INFO - 2025-03-14 21:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:44 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:44 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:44 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:44 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:28:44 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:28:44 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:28:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:28:44 --> Model Class Initialized
ERROR - 2025-03-14 21:28:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:28:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:28:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:28:44 --> Final output sent to browser
DEBUG - 2025-03-14 21:28:44 --> Total execution time: 0.1380
INFO - 2025-03-14 21:28:53 --> Config Class Initialized
INFO - 2025-03-14 21:28:53 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:53 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:53 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:53 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-14 21:28:53 --> Router Class Initialized
INFO - 2025-03-14 21:28:53 --> Output Class Initialized
INFO - 2025-03-14 21:28:53 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:53 --> Input Class Initialized
INFO - 2025-03-14 21:28:53 --> Language Class Initialized
INFO - 2025-03-14 21:28:53 --> Language Class Initialized
INFO - 2025-03-14 21:28:53 --> Config Class Initialized
INFO - 2025-03-14 21:28:53 --> Loader Class Initialized
INFO - 2025-03-14 21:28:53 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:53 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:53 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:53 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:53 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:53 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:53 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:53 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:53 --> Email Class Initialized
INFO - 2025-03-14 21:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:53 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:53 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:53 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:53 --> Invoice MX_Controller Initialized
INFO - 2025-03-14 21:28:59 --> Config Class Initialized
INFO - 2025-03-14 21:28:59 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:28:59 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:28:59 --> Utf8 Class Initialized
INFO - 2025-03-14 21:28:59 --> URI Class Initialized
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:28:59 --> Router Class Initialized
INFO - 2025-03-14 21:28:59 --> Output Class Initialized
INFO - 2025-03-14 21:28:59 --> Security Class Initialized
DEBUG - 2025-03-14 21:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:28:59 --> Input Class Initialized
INFO - 2025-03-14 21:28:59 --> Language Class Initialized
INFO - 2025-03-14 21:28:59 --> Language Class Initialized
INFO - 2025-03-14 21:28:59 --> Config Class Initialized
INFO - 2025-03-14 21:28:59 --> Loader Class Initialized
INFO - 2025-03-14 21:28:59 --> Helper loaded: url_helper
INFO - 2025-03-14 21:28:59 --> Helper loaded: file_helper
INFO - 2025-03-14 21:28:59 --> Helper loaded: html_helper
INFO - 2025-03-14 21:28:59 --> Helper loaded: form_helper
INFO - 2025-03-14 21:28:59 --> Helper loaded: text_helper
INFO - 2025-03-14 21:28:59 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:28:59 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:28:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:28:59 --> Database Driver Class Initialized
INFO - 2025-03-14 21:28:59 --> Email Class Initialized
INFO - 2025-03-14 21:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:28:59 --> Form Validation Class Initialized
INFO - 2025-03-14 21:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:28:59 --> Pagination Class Initialized
INFO - 2025-03-14 21:28:59 --> Controller Class Initialized
DEBUG - 2025-03-14 21:28:59 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:28:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:28:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:28:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:28:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:28:59 --> Model Class Initialized
ERROR - 2025-03-14 21:28:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:28:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:28:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:28:59 --> Final output sent to browser
DEBUG - 2025-03-14 21:28:59 --> Total execution time: 0.1220
INFO - 2025-03-14 21:29:01 --> Config Class Initialized
INFO - 2025-03-14 21:29:01 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:29:01 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:29:01 --> Utf8 Class Initialized
INFO - 2025-03-14 21:29:01 --> URI Class Initialized
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:29:01 --> Router Class Initialized
INFO - 2025-03-14 21:29:01 --> Output Class Initialized
INFO - 2025-03-14 21:29:01 --> Security Class Initialized
DEBUG - 2025-03-14 21:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:29:01 --> Input Class Initialized
INFO - 2025-03-14 21:29:01 --> Language Class Initialized
INFO - 2025-03-14 21:29:01 --> Language Class Initialized
INFO - 2025-03-14 21:29:01 --> Config Class Initialized
INFO - 2025-03-14 21:29:01 --> Loader Class Initialized
INFO - 2025-03-14 21:29:01 --> Helper loaded: url_helper
INFO - 2025-03-14 21:29:01 --> Helper loaded: file_helper
INFO - 2025-03-14 21:29:01 --> Helper loaded: html_helper
INFO - 2025-03-14 21:29:01 --> Helper loaded: form_helper
INFO - 2025-03-14 21:29:01 --> Helper loaded: text_helper
INFO - 2025-03-14 21:29:01 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:29:01 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:29:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:29:01 --> Database Driver Class Initialized
INFO - 2025-03-14 21:29:01 --> Email Class Initialized
INFO - 2025-03-14 21:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:29:01 --> Form Validation Class Initialized
INFO - 2025-03-14 21:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:29:01 --> Pagination Class Initialized
INFO - 2025-03-14 21:29:01 --> Controller Class Initialized
DEBUG - 2025-03-14 21:29:01 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:29:01 --> Model Class Initialized
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:29:01 --> Model Class Initialized
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:29:01 --> Model Class Initialized
DEBUG - 2025-03-14 21:29:01 --> DEBUG: Loading category_form page with data -> {"title":"Add Category","category":{"category_id":null,"category_name":"","parent_id":null,"status":null},"categories":[{"category_id":"2","category_name":"Frozen","parent_id":null,"status":"1"},{"category_id":"7","category_name":"Import","parent_id":null,"status":"1"},{"category_id":"1","category_name":"Juice","parent_id":null,"status":"1"},{"category_id":"3","category_name":"Fishs","parent_id":"2","status":"1"},{"category_id":"6","category_name":"River Fish","parent_id":"3","status":"1"},{"category_id":"8","category_name":"Fish","parent_id":"7","status":"1"},{"category_id":"18","category_name":"Import->Test1","parent_id":"7","status":"1"},{"category_id":"9","category_name":"Sea Fish","parent_id":"8","status":"1"},{"category_id":"35","category_name":"Import->Test1->ChildTest1","parent_id":"18","status":"1"}],"module":"product","page":"category_form"}
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:29:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:29:01 --> Model Class Initialized
ERROR - 2025-03-14 21:29:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:29:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_form.php
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:29:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:29:01 --> Final output sent to browser
DEBUG - 2025-03-14 21:29:01 --> Total execution time: 0.1139
INFO - 2025-03-14 21:30:42 --> Config Class Initialized
INFO - 2025-03-14 21:30:42 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:30:42 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:30:42 --> Utf8 Class Initialized
INFO - 2025-03-14 21:30:42 --> URI Class Initialized
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:30:42 --> Router Class Initialized
INFO - 2025-03-14 21:30:42 --> Output Class Initialized
INFO - 2025-03-14 21:30:42 --> Security Class Initialized
DEBUG - 2025-03-14 21:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:30:42 --> Input Class Initialized
INFO - 2025-03-14 21:30:42 --> Language Class Initialized
INFO - 2025-03-14 21:30:42 --> Language Class Initialized
INFO - 2025-03-14 21:30:42 --> Config Class Initialized
INFO - 2025-03-14 21:30:42 --> Loader Class Initialized
INFO - 2025-03-14 21:30:42 --> Helper loaded: url_helper
INFO - 2025-03-14 21:30:42 --> Helper loaded: file_helper
INFO - 2025-03-14 21:30:42 --> Helper loaded: html_helper
INFO - 2025-03-14 21:30:42 --> Helper loaded: form_helper
INFO - 2025-03-14 21:30:42 --> Helper loaded: text_helper
INFO - 2025-03-14 21:30:42 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:30:42 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:30:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:30:42 --> Database Driver Class Initialized
INFO - 2025-03-14 21:30:42 --> Email Class Initialized
INFO - 2025-03-14 21:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:30:42 --> Form Validation Class Initialized
INFO - 2025-03-14 21:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:30:42 --> Pagination Class Initialized
INFO - 2025-03-14 21:30:42 --> Controller Class Initialized
DEBUG - 2025-03-14 21:30:42 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:30:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:30:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:30:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:30:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:30:42 --> Model Class Initialized
ERROR - 2025-03-14 21:30:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:30:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:30:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:30:42 --> Final output sent to browser
DEBUG - 2025-03-14 21:30:42 --> Total execution time: 0.1158
INFO - 2025-03-14 21:32:36 --> Config Class Initialized
INFO - 2025-03-14 21:32:36 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:32:36 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:32:36 --> Utf8 Class Initialized
INFO - 2025-03-14 21:32:36 --> URI Class Initialized
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:32:36 --> Router Class Initialized
INFO - 2025-03-14 21:32:36 --> Output Class Initialized
INFO - 2025-03-14 21:32:36 --> Security Class Initialized
DEBUG - 2025-03-14 21:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:32:36 --> Input Class Initialized
INFO - 2025-03-14 21:32:36 --> Language Class Initialized
INFO - 2025-03-14 21:32:36 --> Language Class Initialized
INFO - 2025-03-14 21:32:36 --> Config Class Initialized
INFO - 2025-03-14 21:32:36 --> Loader Class Initialized
INFO - 2025-03-14 21:32:36 --> Helper loaded: url_helper
INFO - 2025-03-14 21:32:36 --> Helper loaded: file_helper
INFO - 2025-03-14 21:32:36 --> Helper loaded: html_helper
INFO - 2025-03-14 21:32:36 --> Helper loaded: form_helper
INFO - 2025-03-14 21:32:36 --> Helper loaded: text_helper
INFO - 2025-03-14 21:32:36 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:32:36 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:32:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:32:36 --> Database Driver Class Initialized
INFO - 2025-03-14 21:32:36 --> Email Class Initialized
INFO - 2025-03-14 21:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:32:36 --> Form Validation Class Initialized
INFO - 2025-03-14 21:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:32:36 --> Pagination Class Initialized
INFO - 2025-03-14 21:32:36 --> Controller Class Initialized
DEBUG - 2025-03-14 21:32:36 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:32:36 --> Model Class Initialized
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:32:36 --> Model Class Initialized
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:32:36 --> Model Class Initialized
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:32:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:32:36 --> Model Class Initialized
ERROR - 2025-03-14 21:32:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:32:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:32:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:32:36 --> Final output sent to browser
DEBUG - 2025-03-14 21:32:36 --> Total execution time: 0.1354
INFO - 2025-03-14 21:34:07 --> Config Class Initialized
INFO - 2025-03-14 21:34:07 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:34:07 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:34:07 --> Utf8 Class Initialized
INFO - 2025-03-14 21:34:07 --> URI Class Initialized
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:34:07 --> Router Class Initialized
INFO - 2025-03-14 21:34:07 --> Output Class Initialized
INFO - 2025-03-14 21:34:07 --> Security Class Initialized
DEBUG - 2025-03-14 21:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:34:07 --> Input Class Initialized
INFO - 2025-03-14 21:34:07 --> Language Class Initialized
INFO - 2025-03-14 21:34:07 --> Language Class Initialized
INFO - 2025-03-14 21:34:07 --> Config Class Initialized
INFO - 2025-03-14 21:34:07 --> Loader Class Initialized
INFO - 2025-03-14 21:34:07 --> Helper loaded: url_helper
INFO - 2025-03-14 21:34:07 --> Helper loaded: file_helper
INFO - 2025-03-14 21:34:07 --> Helper loaded: html_helper
INFO - 2025-03-14 21:34:07 --> Helper loaded: form_helper
INFO - 2025-03-14 21:34:07 --> Helper loaded: text_helper
INFO - 2025-03-14 21:34:07 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:34:07 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:34:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:34:07 --> Database Driver Class Initialized
INFO - 2025-03-14 21:34:07 --> Email Class Initialized
INFO - 2025-03-14 21:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:34:07 --> Form Validation Class Initialized
INFO - 2025-03-14 21:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:34:07 --> Pagination Class Initialized
INFO - 2025-03-14 21:34:07 --> Controller Class Initialized
DEBUG - 2025-03-14 21:34:07 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:34:07 --> Model Class Initialized
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:34:07 --> Model Class Initialized
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:34:07 --> Model Class Initialized
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:34:07 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:34:07 --> Model Class Initialized
ERROR - 2025-03-14 21:34:07 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:34:07 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:34:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:34:07 --> Final output sent to browser
DEBUG - 2025-03-14 21:34:07 --> Total execution time: 0.1443
INFO - 2025-03-14 21:39:13 --> Config Class Initialized
INFO - 2025-03-14 21:39:13 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:39:13 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:39:13 --> Utf8 Class Initialized
INFO - 2025-03-14 21:39:13 --> URI Class Initialized
DEBUG - 2025-03-14 21:39:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/service/config/routes.php
INFO - 2025-03-14 21:39:13 --> Router Class Initialized
INFO - 2025-03-14 21:39:13 --> Output Class Initialized
INFO - 2025-03-14 21:39:13 --> Security Class Initialized
DEBUG - 2025-03-14 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:39:13 --> Input Class Initialized
INFO - 2025-03-14 21:39:13 --> Language Class Initialized
INFO - 2025-03-14 21:39:13 --> Language Class Initialized
INFO - 2025-03-14 21:39:13 --> Config Class Initialized
INFO - 2025-03-14 21:39:13 --> Loader Class Initialized
INFO - 2025-03-14 21:39:13 --> Helper loaded: url_helper
INFO - 2025-03-14 21:39:13 --> Helper loaded: file_helper
INFO - 2025-03-14 21:39:13 --> Helper loaded: html_helper
INFO - 2025-03-14 21:39:13 --> Helper loaded: form_helper
INFO - 2025-03-14 21:39:13 --> Helper loaded: text_helper
INFO - 2025-03-14 21:39:13 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:39:13 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:39:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:39:13 --> Database Driver Class Initialized
INFO - 2025-03-14 21:39:13 --> Email Class Initialized
INFO - 2025-03-14 21:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:39:13 --> Form Validation Class Initialized
INFO - 2025-03-14 21:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:39:13 --> Pagination Class Initialized
INFO - 2025-03-14 21:39:13 --> Controller Class Initialized
DEBUG - 2025-03-14 21:39:13 --> Service MX_Controller Initialized
INFO - 2025-03-14 21:39:16 --> Config Class Initialized
INFO - 2025-03-14 21:39:16 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:39:16 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:39:16 --> Utf8 Class Initialized
INFO - 2025-03-14 21:39:16 --> URI Class Initialized
DEBUG - 2025-03-14 21:39:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/service/config/routes.php
INFO - 2025-03-14 21:39:16 --> Router Class Initialized
INFO - 2025-03-14 21:39:16 --> Output Class Initialized
INFO - 2025-03-14 21:39:16 --> Security Class Initialized
DEBUG - 2025-03-14 21:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:39:16 --> Input Class Initialized
INFO - 2025-03-14 21:39:16 --> Language Class Initialized
INFO - 2025-03-14 21:39:16 --> Language Class Initialized
INFO - 2025-03-14 21:39:16 --> Config Class Initialized
INFO - 2025-03-14 21:39:16 --> Loader Class Initialized
INFO - 2025-03-14 21:39:16 --> Helper loaded: url_helper
INFO - 2025-03-14 21:39:16 --> Helper loaded: file_helper
INFO - 2025-03-14 21:39:16 --> Helper loaded: html_helper
INFO - 2025-03-14 21:39:16 --> Helper loaded: form_helper
INFO - 2025-03-14 21:39:16 --> Helper loaded: text_helper
INFO - 2025-03-14 21:39:16 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:39:16 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:39:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:39:16 --> Database Driver Class Initialized
INFO - 2025-03-14 21:39:16 --> Email Class Initialized
INFO - 2025-03-14 21:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:39:16 --> Form Validation Class Initialized
INFO - 2025-03-14 21:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:39:16 --> Pagination Class Initialized
INFO - 2025-03-14 21:39:16 --> Controller Class Initialized
DEBUG - 2025-03-14 21:39:16 --> Service MX_Controller Initialized
INFO - 2025-03-14 21:39:39 --> Config Class Initialized
INFO - 2025-03-14 21:39:39 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:39:39 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:39:39 --> Utf8 Class Initialized
INFO - 2025-03-14 21:39:39 --> URI Class Initialized
DEBUG - 2025-03-14 21:39:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:39:39 --> Router Class Initialized
INFO - 2025-03-14 21:39:39 --> Output Class Initialized
INFO - 2025-03-14 21:39:39 --> Security Class Initialized
DEBUG - 2025-03-14 21:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:39:39 --> Input Class Initialized
INFO - 2025-03-14 21:39:39 --> Language Class Initialized
INFO - 2025-03-14 21:39:40 --> Language Class Initialized
INFO - 2025-03-14 21:39:40 --> Config Class Initialized
INFO - 2025-03-14 21:39:40 --> Loader Class Initialized
INFO - 2025-03-14 21:39:40 --> Helper loaded: url_helper
INFO - 2025-03-14 21:39:40 --> Helper loaded: file_helper
INFO - 2025-03-14 21:39:40 --> Helper loaded: html_helper
INFO - 2025-03-14 21:39:40 --> Helper loaded: form_helper
INFO - 2025-03-14 21:39:40 --> Helper loaded: text_helper
INFO - 2025-03-14 21:39:40 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:39:40 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:39:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:39:40 --> Database Driver Class Initialized
INFO - 2025-03-14 21:39:40 --> Email Class Initialized
INFO - 2025-03-14 21:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:39:40 --> Form Validation Class Initialized
INFO - 2025-03-14 21:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:39:40 --> Pagination Class Initialized
INFO - 2025-03-14 21:39:40 --> Controller Class Initialized
DEBUG - 2025-03-14 21:39:40 --> Setting MX_Controller Initialized
INFO - 2025-03-14 21:39:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-03-14 21:39:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:39:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:39:40 --> Model Class Initialized
ERROR - 2025-03-14 21:39:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:39:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/setting.php
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:39:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:39:40 --> Final output sent to browser
DEBUG - 2025-03-14 21:39:40 --> Total execution time: 0.1271
INFO - 2025-03-14 21:39:45 --> Config Class Initialized
INFO - 2025-03-14 21:39:45 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:39:45 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:39:45 --> Utf8 Class Initialized
INFO - 2025-03-14 21:39:45 --> URI Class Initialized
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:39:45 --> Router Class Initialized
INFO - 2025-03-14 21:39:45 --> Output Class Initialized
INFO - 2025-03-14 21:39:45 --> Security Class Initialized
DEBUG - 2025-03-14 21:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:39:45 --> Input Class Initialized
INFO - 2025-03-14 21:39:45 --> Language Class Initialized
INFO - 2025-03-14 21:39:45 --> Language Class Initialized
INFO - 2025-03-14 21:39:45 --> Config Class Initialized
INFO - 2025-03-14 21:39:45 --> Loader Class Initialized
INFO - 2025-03-14 21:39:45 --> Helper loaded: url_helper
INFO - 2025-03-14 21:39:45 --> Helper loaded: file_helper
INFO - 2025-03-14 21:39:45 --> Helper loaded: html_helper
INFO - 2025-03-14 21:39:45 --> Helper loaded: form_helper
INFO - 2025-03-14 21:39:45 --> Helper loaded: text_helper
INFO - 2025-03-14 21:39:45 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:39:45 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:39:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:39:45 --> Database Driver Class Initialized
INFO - 2025-03-14 21:39:45 --> Email Class Initialized
INFO - 2025-03-14 21:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:39:45 --> Form Validation Class Initialized
INFO - 2025-03-14 21:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:39:45 --> Pagination Class Initialized
INFO - 2025-03-14 21:39:45 --> Controller Class Initialized
DEBUG - 2025-03-14 21:39:45 --> Setting MX_Controller Initialized
INFO - 2025-03-14 21:39:45 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-03-14 21:39:45 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:39:45 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:39:45 --> Model Class Initialized
ERROR - 2025-03-14 21:39:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:39:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/company_list.php
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:39:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:39:45 --> Final output sent to browser
DEBUG - 2025-03-14 21:39:45 --> Total execution time: 0.0818
INFO - 2025-03-14 21:39:49 --> Config Class Initialized
INFO - 2025-03-14 21:39:49 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:39:49 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:39:49 --> Utf8 Class Initialized
INFO - 2025-03-14 21:39:49 --> URI Class Initialized
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:39:49 --> Router Class Initialized
INFO - 2025-03-14 21:39:49 --> Output Class Initialized
INFO - 2025-03-14 21:39:49 --> Security Class Initialized
DEBUG - 2025-03-14 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:39:49 --> Input Class Initialized
INFO - 2025-03-14 21:39:49 --> Language Class Initialized
INFO - 2025-03-14 21:39:49 --> Language Class Initialized
INFO - 2025-03-14 21:39:49 --> Config Class Initialized
INFO - 2025-03-14 21:39:49 --> Loader Class Initialized
INFO - 2025-03-14 21:39:49 --> Helper loaded: url_helper
INFO - 2025-03-14 21:39:49 --> Helper loaded: file_helper
INFO - 2025-03-14 21:39:49 --> Helper loaded: html_helper
INFO - 2025-03-14 21:39:49 --> Helper loaded: form_helper
INFO - 2025-03-14 21:39:49 --> Helper loaded: text_helper
INFO - 2025-03-14 21:39:49 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:39:49 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:39:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:39:49 --> Database Driver Class Initialized
INFO - 2025-03-14 21:39:49 --> Email Class Initialized
INFO - 2025-03-14 21:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:39:49 --> Form Validation Class Initialized
INFO - 2025-03-14 21:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:39:49 --> Pagination Class Initialized
INFO - 2025-03-14 21:39:49 --> Controller Class Initialized
DEBUG - 2025-03-14 21:39:49 --> User MX_Controller Initialized
INFO - 2025-03-14 21:39:49 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/User_model.php
INFO - 2025-03-14 21:39:49 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:39:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:39:49 --> Model Class Initialized
ERROR - 2025-03-14 21:39:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:39:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/user/form.php
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:39:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:39:49 --> Final output sent to browser
DEBUG - 2025-03-14 21:39:49 --> Total execution time: 0.1177
INFO - 2025-03-14 21:39:53 --> Config Class Initialized
INFO - 2025-03-14 21:39:53 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:39:53 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:39:53 --> Utf8 Class Initialized
INFO - 2025-03-14 21:39:53 --> URI Class Initialized
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:39:53 --> Router Class Initialized
INFO - 2025-03-14 21:39:53 --> Output Class Initialized
INFO - 2025-03-14 21:39:53 --> Security Class Initialized
DEBUG - 2025-03-14 21:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:39:53 --> Input Class Initialized
INFO - 2025-03-14 21:39:53 --> Language Class Initialized
INFO - 2025-03-14 21:39:53 --> Language Class Initialized
INFO - 2025-03-14 21:39:53 --> Config Class Initialized
INFO - 2025-03-14 21:39:53 --> Loader Class Initialized
INFO - 2025-03-14 21:39:53 --> Helper loaded: url_helper
INFO - 2025-03-14 21:39:53 --> Helper loaded: file_helper
INFO - 2025-03-14 21:39:53 --> Helper loaded: html_helper
INFO - 2025-03-14 21:39:53 --> Helper loaded: form_helper
INFO - 2025-03-14 21:39:53 --> Helper loaded: text_helper
INFO - 2025-03-14 21:39:53 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:39:53 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:39:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:39:53 --> Database Driver Class Initialized
INFO - 2025-03-14 21:39:53 --> Email Class Initialized
INFO - 2025-03-14 21:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:39:53 --> Form Validation Class Initialized
INFO - 2025-03-14 21:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:39:53 --> Pagination Class Initialized
INFO - 2025-03-14 21:39:53 --> Controller Class Initialized
DEBUG - 2025-03-14 21:39:53 --> Setting MX_Controller Initialized
INFO - 2025-03-14 21:39:53 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-03-14 21:39:53 --> Model Class Initialized
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:39:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:39:53 --> Model Class Initialized
ERROR - 2025-03-14 21:39:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:39:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/currency/currency_form.php
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:39:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:39:53 --> Final output sent to browser
DEBUG - 2025-03-14 21:39:53 --> Total execution time: 0.1294
INFO - 2025-03-14 21:40:01 --> Config Class Initialized
INFO - 2025-03-14 21:40:01 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:40:01 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:40:01 --> Utf8 Class Initialized
INFO - 2025-03-14 21:40:01 --> URI Class Initialized
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:40:01 --> Router Class Initialized
INFO - 2025-03-14 21:40:01 --> Output Class Initialized
INFO - 2025-03-14 21:40:01 --> Security Class Initialized
DEBUG - 2025-03-14 21:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:40:01 --> Input Class Initialized
INFO - 2025-03-14 21:40:01 --> Language Class Initialized
INFO - 2025-03-14 21:40:01 --> Language Class Initialized
INFO - 2025-03-14 21:40:01 --> Config Class Initialized
INFO - 2025-03-14 21:40:01 --> Loader Class Initialized
INFO - 2025-03-14 21:40:01 --> Helper loaded: url_helper
INFO - 2025-03-14 21:40:01 --> Helper loaded: file_helper
INFO - 2025-03-14 21:40:01 --> Helper loaded: html_helper
INFO - 2025-03-14 21:40:01 --> Helper loaded: form_helper
INFO - 2025-03-14 21:40:01 --> Helper loaded: text_helper
INFO - 2025-03-14 21:40:01 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:40:01 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:40:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:40:01 --> Database Driver Class Initialized
INFO - 2025-03-14 21:40:01 --> Email Class Initialized
INFO - 2025-03-14 21:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:40:01 --> Form Validation Class Initialized
INFO - 2025-03-14 21:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:40:01 --> Pagination Class Initialized
INFO - 2025-03-14 21:40:01 --> Controller Class Initialized
DEBUG - 2025-03-14 21:40:01 --> Setting MX_Controller Initialized
INFO - 2025-03-14 21:40:01 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Setting_model.php
INFO - 2025-03-14 21:40:01 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:40:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:40:01 --> Model Class Initialized
ERROR - 2025-03-14 21:40:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:40:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/setting.php
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:40:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:40:01 --> Final output sent to browser
DEBUG - 2025-03-14 21:40:01 --> Total execution time: 0.1193
INFO - 2025-03-14 21:40:19 --> Config Class Initialized
INFO - 2025-03-14 21:40:19 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:40:19 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:40:19 --> Utf8 Class Initialized
INFO - 2025-03-14 21:40:19 --> URI Class Initialized
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:40:19 --> Router Class Initialized
INFO - 2025-03-14 21:40:19 --> Output Class Initialized
INFO - 2025-03-14 21:40:19 --> Security Class Initialized
DEBUG - 2025-03-14 21:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:40:19 --> Input Class Initialized
INFO - 2025-03-14 21:40:19 --> Language Class Initialized
INFO - 2025-03-14 21:40:19 --> Language Class Initialized
INFO - 2025-03-14 21:40:19 --> Config Class Initialized
INFO - 2025-03-14 21:40:19 --> Loader Class Initialized
INFO - 2025-03-14 21:40:19 --> Helper loaded: url_helper
INFO - 2025-03-14 21:40:19 --> Helper loaded: file_helper
INFO - 2025-03-14 21:40:19 --> Helper loaded: html_helper
INFO - 2025-03-14 21:40:19 --> Helper loaded: form_helper
INFO - 2025-03-14 21:40:19 --> Helper loaded: text_helper
INFO - 2025-03-14 21:40:19 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:40:19 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:40:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:40:19 --> Database Driver Class Initialized
INFO - 2025-03-14 21:40:19 --> Email Class Initialized
INFO - 2025-03-14 21:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:40:19 --> Form Validation Class Initialized
INFO - 2025-03-14 21:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:40:19 --> Pagination Class Initialized
INFO - 2025-03-14 21:40:19 --> Controller Class Initialized
DEBUG - 2025-03-14 21:40:19 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:40:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:40:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:40:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:40:19 --> Model Class Initialized
ERROR - 2025-03-14 21:40:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:40:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:40:19 --> Final output sent to browser
DEBUG - 2025-03-14 21:40:19 --> Total execution time: 0.1157
INFO - 2025-03-14 21:40:23 --> Config Class Initialized
INFO - 2025-03-14 21:40:23 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:40:23 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:40:23 --> Utf8 Class Initialized
INFO - 2025-03-14 21:40:23 --> URI Class Initialized
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:40:23 --> Router Class Initialized
INFO - 2025-03-14 21:40:23 --> Output Class Initialized
INFO - 2025-03-14 21:40:23 --> Security Class Initialized
DEBUG - 2025-03-14 21:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:40:23 --> Input Class Initialized
INFO - 2025-03-14 21:40:23 --> Language Class Initialized
INFO - 2025-03-14 21:40:23 --> Language Class Initialized
INFO - 2025-03-14 21:40:23 --> Config Class Initialized
INFO - 2025-03-14 21:40:23 --> Loader Class Initialized
INFO - 2025-03-14 21:40:23 --> Helper loaded: url_helper
INFO - 2025-03-14 21:40:23 --> Helper loaded: file_helper
INFO - 2025-03-14 21:40:23 --> Helper loaded: html_helper
INFO - 2025-03-14 21:40:23 --> Helper loaded: form_helper
INFO - 2025-03-14 21:40:23 --> Helper loaded: text_helper
INFO - 2025-03-14 21:40:23 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:40:23 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:40:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:40:23 --> Database Driver Class Initialized
INFO - 2025-03-14 21:40:23 --> Email Class Initialized
INFO - 2025-03-14 21:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:40:23 --> Form Validation Class Initialized
INFO - 2025-03-14 21:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:40:23 --> Pagination Class Initialized
INFO - 2025-03-14 21:40:23 --> Controller Class Initialized
DEBUG - 2025-03-14 21:40:23 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:40:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:40:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:40:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:40:23 --> Model Class Initialized
ERROR - 2025-03-14 21:40:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:40:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_list.php
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:40:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:40:23 --> Final output sent to browser
DEBUG - 2025-03-14 21:40:23 --> Total execution time: 0.1147
INFO - 2025-03-14 21:40:42 --> Config Class Initialized
INFO - 2025-03-14 21:40:42 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:40:42 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:40:42 --> Utf8 Class Initialized
INFO - 2025-03-14 21:40:42 --> URI Class Initialized
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:40:42 --> Router Class Initialized
INFO - 2025-03-14 21:40:42 --> Output Class Initialized
INFO - 2025-03-14 21:40:42 --> Security Class Initialized
DEBUG - 2025-03-14 21:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:40:42 --> Input Class Initialized
INFO - 2025-03-14 21:40:42 --> Language Class Initialized
INFO - 2025-03-14 21:40:42 --> Language Class Initialized
INFO - 2025-03-14 21:40:42 --> Config Class Initialized
INFO - 2025-03-14 21:40:42 --> Loader Class Initialized
INFO - 2025-03-14 21:40:42 --> Helper loaded: url_helper
INFO - 2025-03-14 21:40:42 --> Helper loaded: file_helper
INFO - 2025-03-14 21:40:42 --> Helper loaded: html_helper
INFO - 2025-03-14 21:40:42 --> Helper loaded: form_helper
INFO - 2025-03-14 21:40:42 --> Helper loaded: text_helper
INFO - 2025-03-14 21:40:42 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:40:42 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:40:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:40:42 --> Database Driver Class Initialized
INFO - 2025-03-14 21:40:42 --> Email Class Initialized
INFO - 2025-03-14 21:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:40:42 --> Form Validation Class Initialized
INFO - 2025-03-14 21:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:40:42 --> Pagination Class Initialized
INFO - 2025-03-14 21:40:42 --> Controller Class Initialized
DEBUG - 2025-03-14 21:40:42 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:40:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:40:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:40:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:40:42 --> Model Class Initialized
ERROR - 2025-03-14 21:40:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:40:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/service_payment_form.php
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:40:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:40:42 --> Final output sent to browser
DEBUG - 2025-03-14 21:40:42 --> Total execution time: 0.1227
INFO - 2025-03-14 21:40:48 --> Config Class Initialized
INFO - 2025-03-14 21:40:48 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:40:48 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:40:48 --> Utf8 Class Initialized
INFO - 2025-03-14 21:40:48 --> URI Class Initialized
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:40:48 --> Router Class Initialized
INFO - 2025-03-14 21:40:48 --> Output Class Initialized
INFO - 2025-03-14 21:40:48 --> Security Class Initialized
DEBUG - 2025-03-14 21:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:40:48 --> Input Class Initialized
INFO - 2025-03-14 21:40:48 --> Language Class Initialized
INFO - 2025-03-14 21:40:48 --> Language Class Initialized
INFO - 2025-03-14 21:40:48 --> Config Class Initialized
INFO - 2025-03-14 21:40:48 --> Loader Class Initialized
INFO - 2025-03-14 21:40:48 --> Helper loaded: url_helper
INFO - 2025-03-14 21:40:48 --> Helper loaded: file_helper
INFO - 2025-03-14 21:40:48 --> Helper loaded: html_helper
INFO - 2025-03-14 21:40:48 --> Helper loaded: form_helper
INFO - 2025-03-14 21:40:48 --> Helper loaded: text_helper
INFO - 2025-03-14 21:40:48 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:40:48 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:40:48 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:40:48 --> Database Driver Class Initialized
INFO - 2025-03-14 21:40:48 --> Email Class Initialized
INFO - 2025-03-14 21:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:40:48 --> Form Validation Class Initialized
INFO - 2025-03-14 21:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:40:48 --> Pagination Class Initialized
INFO - 2025-03-14 21:40:48 --> Controller Class Initialized
DEBUG - 2025-03-14 21:40:48 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:40:48 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:40:48 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:40:48 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:40:48 --> Model Class Initialized
ERROR - 2025-03-14 21:40:48 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:40:48 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/cash_adjustment.php
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:40:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:40:48 --> Final output sent to browser
DEBUG - 2025-03-14 21:40:48 --> Total execution time: 0.1309
INFO - 2025-03-14 21:40:53 --> Config Class Initialized
INFO - 2025-03-14 21:40:53 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:40:53 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:40:53 --> Utf8 Class Initialized
INFO - 2025-03-14 21:40:53 --> URI Class Initialized
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:40:53 --> Router Class Initialized
INFO - 2025-03-14 21:40:53 --> Output Class Initialized
INFO - 2025-03-14 21:40:53 --> Security Class Initialized
DEBUG - 2025-03-14 21:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:40:53 --> Input Class Initialized
INFO - 2025-03-14 21:40:53 --> Language Class Initialized
INFO - 2025-03-14 21:40:53 --> Language Class Initialized
INFO - 2025-03-14 21:40:53 --> Config Class Initialized
INFO - 2025-03-14 21:40:53 --> Loader Class Initialized
INFO - 2025-03-14 21:40:53 --> Helper loaded: url_helper
INFO - 2025-03-14 21:40:53 --> Helper loaded: file_helper
INFO - 2025-03-14 21:40:53 --> Helper loaded: html_helper
INFO - 2025-03-14 21:40:53 --> Helper loaded: form_helper
INFO - 2025-03-14 21:40:53 --> Helper loaded: text_helper
INFO - 2025-03-14 21:40:53 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:40:53 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:40:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:40:53 --> Database Driver Class Initialized
INFO - 2025-03-14 21:40:53 --> Email Class Initialized
INFO - 2025-03-14 21:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:40:53 --> Form Validation Class Initialized
INFO - 2025-03-14 21:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:40:53 --> Pagination Class Initialized
INFO - 2025-03-14 21:40:53 --> Controller Class Initialized
DEBUG - 2025-03-14 21:40:53 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:40:53 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:40:53 --> Model Class Initialized
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:40:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:40:53 --> Model Class Initialized
ERROR - 2025-03-14 21:40:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:40:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_list.php
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:40:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:40:53 --> Final output sent to browser
DEBUG - 2025-03-14 21:40:53 --> Total execution time: 0.0891
INFO - 2025-03-14 21:41:13 --> Config Class Initialized
INFO - 2025-03-14 21:41:13 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:41:13 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:41:13 --> Utf8 Class Initialized
INFO - 2025-03-14 21:41:13 --> URI Class Initialized
DEBUG - 2025-03-14 21:41:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:41:13 --> Router Class Initialized
INFO - 2025-03-14 21:41:13 --> Output Class Initialized
INFO - 2025-03-14 21:41:13 --> Security Class Initialized
DEBUG - 2025-03-14 21:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:41:13 --> Input Class Initialized
INFO - 2025-03-14 21:41:13 --> Language Class Initialized
INFO - 2025-03-14 21:41:13 --> Language Class Initialized
INFO - 2025-03-14 21:41:13 --> Config Class Initialized
INFO - 2025-03-14 21:41:13 --> Loader Class Initialized
INFO - 2025-03-14 21:41:13 --> Helper loaded: url_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: file_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: html_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: form_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: text_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:41:13 --> Database Driver Class Initialized
INFO - 2025-03-14 21:41:13 --> Email Class Initialized
INFO - 2025-03-14 21:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:41:13 --> Form Validation Class Initialized
INFO - 2025-03-14 21:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:41:13 --> Pagination Class Initialized
INFO - 2025-03-14 21:41:13 --> Controller Class Initialized
DEBUG - 2025-03-14 21:41:13 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:41:13 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:41:13 --> Model Class Initialized
INFO - 2025-03-14 21:41:13 --> Config Class Initialized
INFO - 2025-03-14 21:41:13 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:41:13 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:41:13 --> Utf8 Class Initialized
INFO - 2025-03-14 21:41:13 --> URI Class Initialized
DEBUG - 2025-03-14 21:41:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:41:13 --> Router Class Initialized
INFO - 2025-03-14 21:41:13 --> Output Class Initialized
INFO - 2025-03-14 21:41:13 --> Security Class Initialized
DEBUG - 2025-03-14 21:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:41:13 --> Input Class Initialized
INFO - 2025-03-14 21:41:13 --> Language Class Initialized
INFO - 2025-03-14 21:41:13 --> Language Class Initialized
INFO - 2025-03-14 21:41:13 --> Config Class Initialized
INFO - 2025-03-14 21:41:13 --> Loader Class Initialized
INFO - 2025-03-14 21:41:13 --> Helper loaded: url_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: file_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: html_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: form_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: text_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:41:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:41:13 --> Database Driver Class Initialized
INFO - 2025-03-14 21:41:13 --> Email Class Initialized
INFO - 2025-03-14 21:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:41:13 --> Form Validation Class Initialized
INFO - 2025-03-14 21:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:41:13 --> Pagination Class Initialized
INFO - 2025-03-14 21:41:13 --> Controller Class Initialized
DEBUG - 2025-03-14 21:41:13 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:41:13 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:41:13 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:41:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:41:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:41:13 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-14 21:41:13 --> Final output sent to browser
DEBUG - 2025-03-14 21:41:13 --> Total execution time: 0.0126
INFO - 2025-03-14 21:41:24 --> Config Class Initialized
INFO - 2025-03-14 21:41:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:41:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:41:24 --> Utf8 Class Initialized
INFO - 2025-03-14 21:41:24 --> URI Class Initialized
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:41:24 --> Router Class Initialized
INFO - 2025-03-14 21:41:24 --> Output Class Initialized
INFO - 2025-03-14 21:41:24 --> Security Class Initialized
DEBUG - 2025-03-14 21:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:41:24 --> Input Class Initialized
INFO - 2025-03-14 21:41:24 --> Language Class Initialized
INFO - 2025-03-14 21:41:24 --> Language Class Initialized
INFO - 2025-03-14 21:41:24 --> Config Class Initialized
INFO - 2025-03-14 21:41:24 --> Loader Class Initialized
INFO - 2025-03-14 21:41:24 --> Helper loaded: url_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: file_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: html_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: form_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: text_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:41:24 --> Database Driver Class Initialized
INFO - 2025-03-14 21:41:24 --> Email Class Initialized
INFO - 2025-03-14 21:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:41:24 --> Form Validation Class Initialized
INFO - 2025-03-14 21:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:41:24 --> Pagination Class Initialized
INFO - 2025-03-14 21:41:24 --> Controller Class Initialized
DEBUG - 2025-03-14 21:41:24 --> Auth MX_Controller Initialized
INFO - 2025-03-14 21:41:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-14 21:41:24 --> Model Class Initialized
INFO - 2025-03-14 21:41:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 21:41:24 --> Config Class Initialized
INFO - 2025-03-14 21:41:24 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:41:24 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:41:24 --> Utf8 Class Initialized
INFO - 2025-03-14 21:41:24 --> URI Class Initialized
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:41:24 --> Router Class Initialized
INFO - 2025-03-14 21:41:24 --> Output Class Initialized
INFO - 2025-03-14 21:41:24 --> Security Class Initialized
DEBUG - 2025-03-14 21:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:41:24 --> Input Class Initialized
INFO - 2025-03-14 21:41:24 --> Language Class Initialized
INFO - 2025-03-14 21:41:24 --> Language Class Initialized
INFO - 2025-03-14 21:41:24 --> Config Class Initialized
INFO - 2025-03-14 21:41:24 --> Loader Class Initialized
INFO - 2025-03-14 21:41:24 --> Helper loaded: url_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: file_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: html_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: form_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: text_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:41:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:41:24 --> Database Driver Class Initialized
INFO - 2025-03-14 21:41:24 --> Email Class Initialized
INFO - 2025-03-14 21:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:41:24 --> Form Validation Class Initialized
INFO - 2025-03-14 21:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:41:24 --> Pagination Class Initialized
INFO - 2025-03-14 21:41:24 --> Controller Class Initialized
DEBUG - 2025-03-14 21:41:24 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:41:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:41:24 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:41:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:41:24 --> Model Class Initialized
ERROR - 2025-03-14 21:41:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:41:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:41:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:41:24 --> Final output sent to browser
DEBUG - 2025-03-14 21:41:24 --> Total execution time: 0.3061
INFO - 2025-03-14 21:41:37 --> Config Class Initialized
INFO - 2025-03-14 21:41:37 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:41:37 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:41:37 --> Utf8 Class Initialized
INFO - 2025-03-14 21:41:37 --> URI Class Initialized
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:41:37 --> Router Class Initialized
INFO - 2025-03-14 21:41:37 --> Output Class Initialized
INFO - 2025-03-14 21:41:37 --> Security Class Initialized
DEBUG - 2025-03-14 21:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:41:37 --> Input Class Initialized
INFO - 2025-03-14 21:41:37 --> Language Class Initialized
INFO - 2025-03-14 21:41:37 --> Language Class Initialized
INFO - 2025-03-14 21:41:37 --> Config Class Initialized
INFO - 2025-03-14 21:41:37 --> Loader Class Initialized
INFO - 2025-03-14 21:41:37 --> Helper loaded: url_helper
INFO - 2025-03-14 21:41:37 --> Helper loaded: file_helper
INFO - 2025-03-14 21:41:37 --> Helper loaded: html_helper
INFO - 2025-03-14 21:41:37 --> Helper loaded: form_helper
INFO - 2025-03-14 21:41:37 --> Helper loaded: text_helper
INFO - 2025-03-14 21:41:37 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:41:37 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:41:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:41:37 --> Database Driver Class Initialized
INFO - 2025-03-14 21:41:37 --> Email Class Initialized
INFO - 2025-03-14 21:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:41:37 --> Form Validation Class Initialized
INFO - 2025-03-14 21:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:41:37 --> Pagination Class Initialized
INFO - 2025-03-14 21:41:37 --> Controller Class Initialized
DEBUG - 2025-03-14 21:41:37 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:41:37 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:41:37 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:41:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:41:37 --> Model Class Initialized
ERROR - 2025-03-14 21:41:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:41:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_list.php
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:41:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:41:37 --> Final output sent to browser
DEBUG - 2025-03-14 21:41:37 --> Total execution time: 0.1089
INFO - 2025-03-14 21:41:59 --> Config Class Initialized
INFO - 2025-03-14 21:41:59 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:41:59 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:41:59 --> Utf8 Class Initialized
INFO - 2025-03-14 21:41:59 --> URI Class Initialized
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:41:59 --> Router Class Initialized
INFO - 2025-03-14 21:41:59 --> Output Class Initialized
INFO - 2025-03-14 21:41:59 --> Security Class Initialized
DEBUG - 2025-03-14 21:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:41:59 --> Input Class Initialized
INFO - 2025-03-14 21:41:59 --> Language Class Initialized
INFO - 2025-03-14 21:41:59 --> Language Class Initialized
INFO - 2025-03-14 21:41:59 --> Config Class Initialized
INFO - 2025-03-14 21:41:59 --> Loader Class Initialized
INFO - 2025-03-14 21:41:59 --> Helper loaded: url_helper
INFO - 2025-03-14 21:41:59 --> Helper loaded: file_helper
INFO - 2025-03-14 21:41:59 --> Helper loaded: html_helper
INFO - 2025-03-14 21:41:59 --> Helper loaded: form_helper
INFO - 2025-03-14 21:41:59 --> Helper loaded: text_helper
INFO - 2025-03-14 21:41:59 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:41:59 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:41:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:41:59 --> Database Driver Class Initialized
INFO - 2025-03-14 21:41:59 --> Email Class Initialized
INFO - 2025-03-14 21:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:41:59 --> Form Validation Class Initialized
INFO - 2025-03-14 21:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:41:59 --> Pagination Class Initialized
INFO - 2025-03-14 21:41:59 --> Controller Class Initialized
DEBUG - 2025-03-14 21:41:59 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:41:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:41:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:41:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:41:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:41:59 --> Model Class Initialized
ERROR - 2025-03-14 21:41:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:41:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:41:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:41:59 --> Final output sent to browser
DEBUG - 2025-03-14 21:41:59 --> Total execution time: 0.1295
INFO - 2025-03-14 21:42:19 --> Config Class Initialized
INFO - 2025-03-14 21:42:19 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:42:19 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:42:19 --> Utf8 Class Initialized
INFO - 2025-03-14 21:42:19 --> URI Class Initialized
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:42:19 --> Router Class Initialized
INFO - 2025-03-14 21:42:19 --> Output Class Initialized
INFO - 2025-03-14 21:42:19 --> Security Class Initialized
DEBUG - 2025-03-14 21:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:42:19 --> Input Class Initialized
INFO - 2025-03-14 21:42:19 --> Language Class Initialized
INFO - 2025-03-14 21:42:19 --> Language Class Initialized
INFO - 2025-03-14 21:42:19 --> Config Class Initialized
INFO - 2025-03-14 21:42:19 --> Loader Class Initialized
INFO - 2025-03-14 21:42:19 --> Helper loaded: url_helper
INFO - 2025-03-14 21:42:19 --> Helper loaded: file_helper
INFO - 2025-03-14 21:42:19 --> Helper loaded: html_helper
INFO - 2025-03-14 21:42:19 --> Helper loaded: form_helper
INFO - 2025-03-14 21:42:19 --> Helper loaded: text_helper
INFO - 2025-03-14 21:42:19 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:42:19 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:42:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:42:19 --> Database Driver Class Initialized
INFO - 2025-03-14 21:42:19 --> Email Class Initialized
INFO - 2025-03-14 21:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:42:19 --> Form Validation Class Initialized
INFO - 2025-03-14 21:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:42:19 --> Pagination Class Initialized
INFO - 2025-03-14 21:42:19 --> Controller Class Initialized
DEBUG - 2025-03-14 21:42:19 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:42:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:42:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:42:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:42:19 --> Model Class Initialized
ERROR - 2025-03-14 21:42:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:42:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:42:19 --> Final output sent to browser
DEBUG - 2025-03-14 21:42:19 --> Total execution time: 0.0813
INFO - 2025-03-14 21:42:39 --> Config Class Initialized
INFO - 2025-03-14 21:42:39 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:42:39 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:42:39 --> Utf8 Class Initialized
INFO - 2025-03-14 21:42:39 --> URI Class Initialized
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:42:39 --> Router Class Initialized
INFO - 2025-03-14 21:42:39 --> Output Class Initialized
INFO - 2025-03-14 21:42:39 --> Security Class Initialized
DEBUG - 2025-03-14 21:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:42:39 --> Input Class Initialized
INFO - 2025-03-14 21:42:39 --> Language Class Initialized
INFO - 2025-03-14 21:42:39 --> Language Class Initialized
INFO - 2025-03-14 21:42:39 --> Config Class Initialized
INFO - 2025-03-14 21:42:39 --> Loader Class Initialized
INFO - 2025-03-14 21:42:39 --> Helper loaded: url_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: file_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: html_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: form_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: text_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:42:39 --> Database Driver Class Initialized
INFO - 2025-03-14 21:42:39 --> Email Class Initialized
INFO - 2025-03-14 21:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:42:39 --> Form Validation Class Initialized
INFO - 2025-03-14 21:42:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:42:39 --> Pagination Class Initialized
INFO - 2025-03-14 21:42:39 --> Controller Class Initialized
DEBUG - 2025-03-14 21:42:39 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:42:39 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:42:39 --> Model Class Initialized
INFO - 2025-03-14 21:42:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-14 21:42:39 --> Config Class Initialized
INFO - 2025-03-14 21:42:39 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:42:39 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:42:39 --> Utf8 Class Initialized
INFO - 2025-03-14 21:42:39 --> URI Class Initialized
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:42:39 --> Router Class Initialized
INFO - 2025-03-14 21:42:39 --> Output Class Initialized
INFO - 2025-03-14 21:42:39 --> Security Class Initialized
DEBUG - 2025-03-14 21:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:42:39 --> Input Class Initialized
INFO - 2025-03-14 21:42:39 --> Language Class Initialized
INFO - 2025-03-14 21:42:39 --> Language Class Initialized
INFO - 2025-03-14 21:42:39 --> Config Class Initialized
INFO - 2025-03-14 21:42:39 --> Loader Class Initialized
INFO - 2025-03-14 21:42:39 --> Helper loaded: url_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: file_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: html_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: form_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: text_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:42:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:42:39 --> Database Driver Class Initialized
INFO - 2025-03-14 21:42:39 --> Email Class Initialized
INFO - 2025-03-14 21:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:42:39 --> Form Validation Class Initialized
INFO - 2025-03-14 21:42:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:42:39 --> Pagination Class Initialized
INFO - 2025-03-14 21:42:39 --> Controller Class Initialized
DEBUG - 2025-03-14 21:42:39 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:42:39 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:42:39 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:42:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:42:39 --> Model Class Initialized
ERROR - 2025-03-14 21:42:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:42:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:42:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:42:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:42:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:42:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_list.php
DEBUG - 2025-03-14 21:42:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:42:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:42:40 --> Final output sent to browser
DEBUG - 2025-03-14 21:42:40 --> Total execution time: 0.0692
INFO - 2025-03-14 21:42:46 --> Config Class Initialized
INFO - 2025-03-14 21:42:46 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:42:46 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:42:46 --> Utf8 Class Initialized
INFO - 2025-03-14 21:42:46 --> URI Class Initialized
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:42:46 --> Router Class Initialized
INFO - 2025-03-14 21:42:46 --> Output Class Initialized
INFO - 2025-03-14 21:42:46 --> Security Class Initialized
DEBUG - 2025-03-14 21:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:42:46 --> Input Class Initialized
INFO - 2025-03-14 21:42:46 --> Language Class Initialized
INFO - 2025-03-14 21:42:46 --> Language Class Initialized
INFO - 2025-03-14 21:42:46 --> Config Class Initialized
INFO - 2025-03-14 21:42:46 --> Loader Class Initialized
INFO - 2025-03-14 21:42:46 --> Helper loaded: url_helper
INFO - 2025-03-14 21:42:46 --> Helper loaded: file_helper
INFO - 2025-03-14 21:42:46 --> Helper loaded: html_helper
INFO - 2025-03-14 21:42:46 --> Helper loaded: form_helper
INFO - 2025-03-14 21:42:46 --> Helper loaded: text_helper
INFO - 2025-03-14 21:42:46 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:42:46 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:42:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:42:46 --> Database Driver Class Initialized
INFO - 2025-03-14 21:42:46 --> Email Class Initialized
INFO - 2025-03-14 21:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:42:46 --> Form Validation Class Initialized
INFO - 2025-03-14 21:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:42:46 --> Pagination Class Initialized
INFO - 2025-03-14 21:42:46 --> Controller Class Initialized
DEBUG - 2025-03-14 21:42:46 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:42:46 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:42:46 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:42:46 --> Model Class Initialized
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:42:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:42:46 --> Model Class Initialized
ERROR - 2025-03-14 21:42:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:42:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:42:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:42:46 --> Final output sent to browser
DEBUG - 2025-03-14 21:42:46 --> Total execution time: 0.1241
INFO - 2025-03-14 21:43:32 --> Config Class Initialized
INFO - 2025-03-14 21:43:32 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:43:32 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:43:32 --> Utf8 Class Initialized
INFO - 2025-03-14 21:43:32 --> URI Class Initialized
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:43:32 --> Router Class Initialized
INFO - 2025-03-14 21:43:32 --> Output Class Initialized
INFO - 2025-03-14 21:43:32 --> Security Class Initialized
DEBUG - 2025-03-14 21:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:43:32 --> Input Class Initialized
INFO - 2025-03-14 21:43:32 --> Language Class Initialized
INFO - 2025-03-14 21:43:32 --> Language Class Initialized
INFO - 2025-03-14 21:43:32 --> Config Class Initialized
INFO - 2025-03-14 21:43:32 --> Loader Class Initialized
INFO - 2025-03-14 21:43:32 --> Helper loaded: url_helper
INFO - 2025-03-14 21:43:32 --> Helper loaded: file_helper
INFO - 2025-03-14 21:43:32 --> Helper loaded: html_helper
INFO - 2025-03-14 21:43:32 --> Helper loaded: form_helper
INFO - 2025-03-14 21:43:32 --> Helper loaded: text_helper
INFO - 2025-03-14 21:43:32 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:43:32 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:43:32 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:43:32 --> Database Driver Class Initialized
INFO - 2025-03-14 21:43:32 --> Email Class Initialized
INFO - 2025-03-14 21:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:43:32 --> Form Validation Class Initialized
INFO - 2025-03-14 21:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:43:32 --> Pagination Class Initialized
INFO - 2025-03-14 21:43:32 --> Controller Class Initialized
DEBUG - 2025-03-14 21:43:32 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:43:32 --> Model Class Initialized
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:43:32 --> Model Class Initialized
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:43:32 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:43:32 --> Model Class Initialized
ERROR - 2025-03-14 21:43:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:43:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:43:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:43:32 --> Final output sent to browser
DEBUG - 2025-03-14 21:43:32 --> Total execution time: 0.1144
INFO - 2025-03-14 21:48:40 --> Config Class Initialized
INFO - 2025-03-14 21:48:40 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:48:40 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:48:40 --> Utf8 Class Initialized
INFO - 2025-03-14 21:48:40 --> URI Class Initialized
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:48:40 --> Router Class Initialized
INFO - 2025-03-14 21:48:40 --> Output Class Initialized
INFO - 2025-03-14 21:48:40 --> Security Class Initialized
DEBUG - 2025-03-14 21:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:48:40 --> Input Class Initialized
INFO - 2025-03-14 21:48:40 --> Language Class Initialized
INFO - 2025-03-14 21:48:40 --> Language Class Initialized
INFO - 2025-03-14 21:48:40 --> Config Class Initialized
INFO - 2025-03-14 21:48:40 --> Loader Class Initialized
INFO - 2025-03-14 21:48:40 --> Helper loaded: url_helper
INFO - 2025-03-14 21:48:40 --> Helper loaded: file_helper
INFO - 2025-03-14 21:48:40 --> Helper loaded: html_helper
INFO - 2025-03-14 21:48:40 --> Helper loaded: form_helper
INFO - 2025-03-14 21:48:40 --> Helper loaded: text_helper
INFO - 2025-03-14 21:48:40 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:48:40 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:48:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:48:40 --> Database Driver Class Initialized
INFO - 2025-03-14 21:48:40 --> Email Class Initialized
INFO - 2025-03-14 21:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:48:40 --> Form Validation Class Initialized
INFO - 2025-03-14 21:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:48:40 --> Pagination Class Initialized
INFO - 2025-03-14 21:48:40 --> Controller Class Initialized
DEBUG - 2025-03-14 21:48:40 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:48:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:48:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:48:40 --> Model Class Initialized
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:48:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:48:40 --> Model Class Initialized
ERROR - 2025-03-14 21:48:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:48:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:48:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:48:40 --> Final output sent to browser
DEBUG - 2025-03-14 21:48:40 --> Total execution time: 0.1316
INFO - 2025-03-14 21:49:19 --> Config Class Initialized
INFO - 2025-03-14 21:49:19 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:49:19 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:49:19 --> Utf8 Class Initialized
INFO - 2025-03-14 21:49:19 --> URI Class Initialized
DEBUG - 2025-03-14 21:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:49:19 --> Router Class Initialized
INFO - 2025-03-14 21:49:19 --> Output Class Initialized
INFO - 2025-03-14 21:49:19 --> Security Class Initialized
DEBUG - 2025-03-14 21:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:49:19 --> Input Class Initialized
INFO - 2025-03-14 21:49:19 --> Language Class Initialized
INFO - 2025-03-14 21:49:19 --> Language Class Initialized
INFO - 2025-03-14 21:49:19 --> Config Class Initialized
INFO - 2025-03-14 21:49:19 --> Loader Class Initialized
INFO - 2025-03-14 21:49:19 --> Helper loaded: url_helper
INFO - 2025-03-14 21:49:19 --> Helper loaded: file_helper
INFO - 2025-03-14 21:49:19 --> Helper loaded: html_helper
INFO - 2025-03-14 21:49:19 --> Helper loaded: form_helper
INFO - 2025-03-14 21:49:19 --> Helper loaded: text_helper
INFO - 2025-03-14 21:49:19 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:49:19 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:49:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:49:19 --> Database Driver Class Initialized
INFO - 2025-03-14 21:49:19 --> Email Class Initialized
INFO - 2025-03-14 21:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:49:19 --> Form Validation Class Initialized
INFO - 2025-03-14 21:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:49:19 --> Pagination Class Initialized
INFO - 2025-03-14 21:49:19 --> Controller Class Initialized
DEBUG - 2025-03-14 21:49:19 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:49:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:49:19 --> Model Class Initialized
DEBUG - 2025-03-14 21:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:49:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:49:19 --> Model Class Initialized
ERROR - 2025-03-14 21:49:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:49:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:49:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:49:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:49:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:49:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 21:49:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:49:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:49:20 --> Final output sent to browser
DEBUG - 2025-03-14 21:49:20 --> Total execution time: 0.1170
INFO - 2025-03-14 21:51:08 --> Config Class Initialized
INFO - 2025-03-14 21:51:08 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:51:08 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:51:08 --> Utf8 Class Initialized
INFO - 2025-03-14 21:51:08 --> URI Class Initialized
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/config/routes.php
INFO - 2025-03-14 21:51:08 --> Router Class Initialized
INFO - 2025-03-14 21:51:08 --> Output Class Initialized
INFO - 2025-03-14 21:51:08 --> Security Class Initialized
DEBUG - 2025-03-14 21:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:51:08 --> Input Class Initialized
INFO - 2025-03-14 21:51:08 --> Language Class Initialized
INFO - 2025-03-14 21:51:08 --> Language Class Initialized
INFO - 2025-03-14 21:51:08 --> Config Class Initialized
INFO - 2025-03-14 21:51:08 --> Loader Class Initialized
INFO - 2025-03-14 21:51:08 --> Helper loaded: url_helper
INFO - 2025-03-14 21:51:08 --> Helper loaded: file_helper
INFO - 2025-03-14 21:51:08 --> Helper loaded: html_helper
INFO - 2025-03-14 21:51:08 --> Helper loaded: form_helper
INFO - 2025-03-14 21:51:08 --> Helper loaded: text_helper
INFO - 2025-03-14 21:51:08 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:51:08 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:51:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:51:08 --> Database Driver Class Initialized
INFO - 2025-03-14 21:51:08 --> Email Class Initialized
INFO - 2025-03-14 21:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:51:08 --> Form Validation Class Initialized
INFO - 2025-03-14 21:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:51:08 --> Pagination Class Initialized
INFO - 2025-03-14 21:51:08 --> Controller Class Initialized
DEBUG - 2025-03-14 21:51:08 --> Product MX_Controller Initialized
INFO - 2025-03-14 21:51:08 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/models/Product_model.php
INFO - 2025-03-14 21:51:08 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/supplier/models/Supplier_model.php
INFO - 2025-03-14 21:51:08 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:51:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:51:08 --> Model Class Initialized
ERROR - 2025-03-14 21:51:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:51:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/product/views/category_list.php
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:51:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:51:08 --> Final output sent to browser
DEBUG - 2025-03-14 21:51:08 --> Total execution time: 0.1201
INFO - 2025-03-14 21:51:17 --> Config Class Initialized
INFO - 2025-03-14 21:51:17 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:51:17 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:51:17 --> Utf8 Class Initialized
INFO - 2025-03-14 21:51:17 --> URI Class Initialized
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:51:17 --> Router Class Initialized
INFO - 2025-03-14 21:51:17 --> Output Class Initialized
INFO - 2025-03-14 21:51:17 --> Security Class Initialized
DEBUG - 2025-03-14 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:51:17 --> Input Class Initialized
INFO - 2025-03-14 21:51:17 --> Language Class Initialized
INFO - 2025-03-14 21:51:17 --> Language Class Initialized
INFO - 2025-03-14 21:51:17 --> Config Class Initialized
INFO - 2025-03-14 21:51:17 --> Loader Class Initialized
INFO - 2025-03-14 21:51:17 --> Helper loaded: url_helper
INFO - 2025-03-14 21:51:17 --> Helper loaded: file_helper
INFO - 2025-03-14 21:51:17 --> Helper loaded: html_helper
INFO - 2025-03-14 21:51:17 --> Helper loaded: form_helper
INFO - 2025-03-14 21:51:17 --> Helper loaded: text_helper
INFO - 2025-03-14 21:51:17 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:51:17 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:51:17 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:51:17 --> Database Driver Class Initialized
INFO - 2025-03-14 21:51:17 --> Email Class Initialized
INFO - 2025-03-14 21:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:51:17 --> Form Validation Class Initialized
INFO - 2025-03-14 21:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:51:17 --> Pagination Class Initialized
INFO - 2025-03-14 21:51:17 --> Controller Class Initialized
DEBUG - 2025-03-14 21:51:17 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:51:17 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:51:17 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:51:17 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:51:17 --> Model Class Initialized
ERROR - 2025-03-14 21:51:17 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:51:17 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:51:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:51:17 --> Final output sent to browser
DEBUG - 2025-03-14 21:51:17 --> Total execution time: 0.1377
INFO - 2025-03-14 21:51:20 --> Config Class Initialized
INFO - 2025-03-14 21:51:20 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:51:20 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:51:20 --> Utf8 Class Initialized
INFO - 2025-03-14 21:51:20 --> URI Class Initialized
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:51:20 --> Router Class Initialized
INFO - 2025-03-14 21:51:20 --> Output Class Initialized
INFO - 2025-03-14 21:51:20 --> Security Class Initialized
DEBUG - 2025-03-14 21:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:51:20 --> Input Class Initialized
INFO - 2025-03-14 21:51:20 --> Language Class Initialized
INFO - 2025-03-14 21:51:20 --> Language Class Initialized
INFO - 2025-03-14 21:51:20 --> Config Class Initialized
INFO - 2025-03-14 21:51:20 --> Loader Class Initialized
INFO - 2025-03-14 21:51:20 --> Helper loaded: url_helper
INFO - 2025-03-14 21:51:20 --> Helper loaded: file_helper
INFO - 2025-03-14 21:51:20 --> Helper loaded: html_helper
INFO - 2025-03-14 21:51:20 --> Helper loaded: form_helper
INFO - 2025-03-14 21:51:20 --> Helper loaded: text_helper
INFO - 2025-03-14 21:51:20 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:51:20 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:51:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:51:20 --> Database Driver Class Initialized
INFO - 2025-03-14 21:51:20 --> Email Class Initialized
INFO - 2025-03-14 21:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:51:20 --> Form Validation Class Initialized
INFO - 2025-03-14 21:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:51:20 --> Pagination Class Initialized
INFO - 2025-03-14 21:51:20 --> Controller Class Initialized
DEBUG - 2025-03-14 21:51:20 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:51:20 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:51:20 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:51:20 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:51:20 --> Model Class Initialized
ERROR - 2025-03-14 21:51:20 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:51:20 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:51:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:51:20 --> Final output sent to browser
DEBUG - 2025-03-14 21:51:20 --> Total execution time: 0.1087
INFO - 2025-03-14 21:51:23 --> Config Class Initialized
INFO - 2025-03-14 21:51:23 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:51:23 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:51:23 --> Utf8 Class Initialized
INFO - 2025-03-14 21:51:23 --> URI Class Initialized
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:51:23 --> Router Class Initialized
INFO - 2025-03-14 21:51:23 --> Output Class Initialized
INFO - 2025-03-14 21:51:23 --> Security Class Initialized
DEBUG - 2025-03-14 21:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:51:23 --> Input Class Initialized
INFO - 2025-03-14 21:51:23 --> Language Class Initialized
INFO - 2025-03-14 21:51:23 --> Language Class Initialized
INFO - 2025-03-14 21:51:23 --> Config Class Initialized
INFO - 2025-03-14 21:51:23 --> Loader Class Initialized
INFO - 2025-03-14 21:51:23 --> Helper loaded: url_helper
INFO - 2025-03-14 21:51:23 --> Helper loaded: file_helper
INFO - 2025-03-14 21:51:23 --> Helper loaded: html_helper
INFO - 2025-03-14 21:51:23 --> Helper loaded: form_helper
INFO - 2025-03-14 21:51:23 --> Helper loaded: text_helper
INFO - 2025-03-14 21:51:23 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:51:23 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:51:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:51:23 --> Database Driver Class Initialized
INFO - 2025-03-14 21:51:23 --> Email Class Initialized
INFO - 2025-03-14 21:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:51:23 --> Form Validation Class Initialized
INFO - 2025-03-14 21:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:51:23 --> Pagination Class Initialized
INFO - 2025-03-14 21:51:23 --> Controller Class Initialized
DEBUG - 2025-03-14 21:51:23 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:51:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:51:23 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:51:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:51:23 --> Model Class Initialized
ERROR - 2025-03-14 21:51:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:51:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:51:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:51:23 --> Final output sent to browser
DEBUG - 2025-03-14 21:51:23 --> Total execution time: 0.1161
INFO - 2025-03-14 21:51:28 --> Config Class Initialized
INFO - 2025-03-14 21:51:28 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:51:28 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:51:28 --> Utf8 Class Initialized
INFO - 2025-03-14 21:51:28 --> URI Class Initialized
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:51:28 --> Router Class Initialized
INFO - 2025-03-14 21:51:28 --> Output Class Initialized
INFO - 2025-03-14 21:51:28 --> Security Class Initialized
DEBUG - 2025-03-14 21:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:51:28 --> Input Class Initialized
INFO - 2025-03-14 21:51:28 --> Language Class Initialized
INFO - 2025-03-14 21:51:28 --> Language Class Initialized
INFO - 2025-03-14 21:51:28 --> Config Class Initialized
INFO - 2025-03-14 21:51:28 --> Loader Class Initialized
INFO - 2025-03-14 21:51:28 --> Helper loaded: url_helper
INFO - 2025-03-14 21:51:28 --> Helper loaded: file_helper
INFO - 2025-03-14 21:51:28 --> Helper loaded: html_helper
INFO - 2025-03-14 21:51:28 --> Helper loaded: form_helper
INFO - 2025-03-14 21:51:28 --> Helper loaded: text_helper
INFO - 2025-03-14 21:51:28 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:51:28 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:51:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:51:28 --> Database Driver Class Initialized
INFO - 2025-03-14 21:51:28 --> Email Class Initialized
INFO - 2025-03-14 21:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:51:28 --> Form Validation Class Initialized
INFO - 2025-03-14 21:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:51:28 --> Pagination Class Initialized
INFO - 2025-03-14 21:51:28 --> Controller Class Initialized
DEBUG - 2025-03-14 21:51:28 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:51:28 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:51:28 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:51:28 --> Model Class Initialized
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:51:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:51:28 --> Model Class Initialized
ERROR - 2025-03-14 21:51:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:51:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:51:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:51:28 --> Final output sent to browser
DEBUG - 2025-03-14 21:51:28 --> Total execution time: 0.1218
INFO - 2025-03-14 21:53:57 --> Config Class Initialized
INFO - 2025-03-14 21:53:57 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:53:57 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:53:57 --> Utf8 Class Initialized
INFO - 2025-03-14 21:53:57 --> URI Class Initialized
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:53:57 --> Router Class Initialized
INFO - 2025-03-14 21:53:57 --> Output Class Initialized
INFO - 2025-03-14 21:53:57 --> Security Class Initialized
DEBUG - 2025-03-14 21:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:53:57 --> Input Class Initialized
INFO - 2025-03-14 21:53:57 --> Language Class Initialized
INFO - 2025-03-14 21:53:57 --> Language Class Initialized
INFO - 2025-03-14 21:53:57 --> Config Class Initialized
INFO - 2025-03-14 21:53:57 --> Loader Class Initialized
INFO - 2025-03-14 21:53:57 --> Helper loaded: url_helper
INFO - 2025-03-14 21:53:57 --> Helper loaded: file_helper
INFO - 2025-03-14 21:53:57 --> Helper loaded: html_helper
INFO - 2025-03-14 21:53:57 --> Helper loaded: form_helper
INFO - 2025-03-14 21:53:57 --> Helper loaded: text_helper
INFO - 2025-03-14 21:53:57 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:53:57 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:53:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:53:57 --> Database Driver Class Initialized
INFO - 2025-03-14 21:53:57 --> Email Class Initialized
INFO - 2025-03-14 21:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:53:57 --> Form Validation Class Initialized
INFO - 2025-03-14 21:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:53:57 --> Pagination Class Initialized
INFO - 2025-03-14 21:53:57 --> Controller Class Initialized
DEBUG - 2025-03-14 21:53:57 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:53:57 --> Model Class Initialized
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:53:57 --> Model Class Initialized
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:53:57 --> Model Class Initialized
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:53:57 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:53:57 --> Model Class Initialized
ERROR - 2025-03-14 21:53:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:53:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:53:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:53:57 --> Final output sent to browser
DEBUG - 2025-03-14 21:53:57 --> Total execution time: 0.2955
INFO - 2025-03-14 21:53:59 --> Config Class Initialized
INFO - 2025-03-14 21:53:59 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:53:59 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:53:59 --> Utf8 Class Initialized
INFO - 2025-03-14 21:53:59 --> URI Class Initialized
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:53:59 --> Router Class Initialized
INFO - 2025-03-14 21:53:59 --> Output Class Initialized
INFO - 2025-03-14 21:53:59 --> Security Class Initialized
DEBUG - 2025-03-14 21:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:53:59 --> Input Class Initialized
INFO - 2025-03-14 21:53:59 --> Language Class Initialized
INFO - 2025-03-14 21:53:59 --> Language Class Initialized
INFO - 2025-03-14 21:53:59 --> Config Class Initialized
INFO - 2025-03-14 21:53:59 --> Loader Class Initialized
INFO - 2025-03-14 21:53:59 --> Helper loaded: url_helper
INFO - 2025-03-14 21:53:59 --> Helper loaded: file_helper
INFO - 2025-03-14 21:53:59 --> Helper loaded: html_helper
INFO - 2025-03-14 21:53:59 --> Helper loaded: form_helper
INFO - 2025-03-14 21:53:59 --> Helper loaded: text_helper
INFO - 2025-03-14 21:53:59 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:53:59 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:53:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:53:59 --> Database Driver Class Initialized
INFO - 2025-03-14 21:53:59 --> Email Class Initialized
INFO - 2025-03-14 21:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:53:59 --> Form Validation Class Initialized
INFO - 2025-03-14 21:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:53:59 --> Pagination Class Initialized
INFO - 2025-03-14 21:53:59 --> Controller Class Initialized
DEBUG - 2025-03-14 21:53:59 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:53:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:53:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:53:59 --> Model Class Initialized
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:53:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:53:59 --> Model Class Initialized
ERROR - 2025-03-14 21:53:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:53:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:53:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:53:59 --> Final output sent to browser
DEBUG - 2025-03-14 21:53:59 --> Total execution time: 0.2043
INFO - 2025-03-14 21:54:02 --> Config Class Initialized
INFO - 2025-03-14 21:54:02 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:54:02 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:54:02 --> Utf8 Class Initialized
INFO - 2025-03-14 21:54:02 --> URI Class Initialized
DEBUG - 2025-03-14 21:54:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:54:02 --> Router Class Initialized
INFO - 2025-03-14 21:54:02 --> Output Class Initialized
INFO - 2025-03-14 21:54:02 --> Security Class Initialized
DEBUG - 2025-03-14 21:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:54:02 --> Input Class Initialized
INFO - 2025-03-14 21:54:02 --> Language Class Initialized
INFO - 2025-03-14 21:54:02 --> Language Class Initialized
INFO - 2025-03-14 21:54:02 --> Config Class Initialized
INFO - 2025-03-14 21:54:02 --> Loader Class Initialized
INFO - 2025-03-14 21:54:02 --> Helper loaded: url_helper
INFO - 2025-03-14 21:54:02 --> Helper loaded: file_helper
INFO - 2025-03-14 21:54:02 --> Helper loaded: html_helper
INFO - 2025-03-14 21:54:02 --> Helper loaded: form_helper
INFO - 2025-03-14 21:54:02 --> Helper loaded: text_helper
INFO - 2025-03-14 21:54:02 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:54:02 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:54:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:54:02 --> Database Driver Class Initialized
INFO - 2025-03-14 21:54:02 --> Email Class Initialized
INFO - 2025-03-14 21:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:54:02 --> Form Validation Class Initialized
INFO - 2025-03-14 21:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:54:02 --> Pagination Class Initialized
INFO - 2025-03-14 21:54:02 --> Controller Class Initialized
ERROR - 2025-03-14 21:54:02 --> 404 Page Not Found: ../modules/purchase/controllers/Purchase/add_payment_method
INFO - 2025-03-14 21:54:06 --> Config Class Initialized
INFO - 2025-03-14 21:54:06 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:54:06 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:54:06 --> Utf8 Class Initialized
INFO - 2025-03-14 21:54:06 --> URI Class Initialized
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:54:06 --> Router Class Initialized
INFO - 2025-03-14 21:54:06 --> Output Class Initialized
INFO - 2025-03-14 21:54:06 --> Security Class Initialized
DEBUG - 2025-03-14 21:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:54:06 --> Input Class Initialized
INFO - 2025-03-14 21:54:06 --> Language Class Initialized
INFO - 2025-03-14 21:54:06 --> Language Class Initialized
INFO - 2025-03-14 21:54:06 --> Config Class Initialized
INFO - 2025-03-14 21:54:06 --> Loader Class Initialized
INFO - 2025-03-14 21:54:06 --> Helper loaded: url_helper
INFO - 2025-03-14 21:54:06 --> Helper loaded: file_helper
INFO - 2025-03-14 21:54:06 --> Helper loaded: html_helper
INFO - 2025-03-14 21:54:06 --> Helper loaded: form_helper
INFO - 2025-03-14 21:54:06 --> Helper loaded: text_helper
INFO - 2025-03-14 21:54:06 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:54:06 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:54:06 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:54:06 --> Database Driver Class Initialized
INFO - 2025-03-14 21:54:06 --> Email Class Initialized
INFO - 2025-03-14 21:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:54:06 --> Form Validation Class Initialized
INFO - 2025-03-14 21:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:54:06 --> Pagination Class Initialized
INFO - 2025-03-14 21:54:06 --> Controller Class Initialized
DEBUG - 2025-03-14 21:54:06 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:54:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:54:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:54:06 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:54:06 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:54:06 --> Model Class Initialized
ERROR - 2025-03-14 21:54:06 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:54:06 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:54:06 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:54:06 --> Final output sent to browser
DEBUG - 2025-03-14 21:54:06 --> Total execution time: 0.1812
INFO - 2025-03-14 21:54:15 --> Config Class Initialized
INFO - 2025-03-14 21:54:15 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:54:15 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:54:15 --> Utf8 Class Initialized
INFO - 2025-03-14 21:54:15 --> URI Class Initialized
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:54:15 --> Router Class Initialized
INFO - 2025-03-14 21:54:15 --> Output Class Initialized
INFO - 2025-03-14 21:54:15 --> Security Class Initialized
DEBUG - 2025-03-14 21:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:54:15 --> Input Class Initialized
INFO - 2025-03-14 21:54:15 --> Language Class Initialized
INFO - 2025-03-14 21:54:15 --> Language Class Initialized
INFO - 2025-03-14 21:54:15 --> Config Class Initialized
INFO - 2025-03-14 21:54:15 --> Loader Class Initialized
INFO - 2025-03-14 21:54:15 --> Helper loaded: url_helper
INFO - 2025-03-14 21:54:15 --> Helper loaded: file_helper
INFO - 2025-03-14 21:54:15 --> Helper loaded: html_helper
INFO - 2025-03-14 21:54:15 --> Helper loaded: form_helper
INFO - 2025-03-14 21:54:15 --> Helper loaded: text_helper
INFO - 2025-03-14 21:54:15 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:54:15 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:54:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:54:15 --> Database Driver Class Initialized
INFO - 2025-03-14 21:54:15 --> Email Class Initialized
INFO - 2025-03-14 21:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:54:15 --> Form Validation Class Initialized
INFO - 2025-03-14 21:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:54:15 --> Pagination Class Initialized
INFO - 2025-03-14 21:54:15 --> Controller Class Initialized
DEBUG - 2025-03-14 21:54:15 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:54:15 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:54:15 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:54:15 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:54:15 --> Model Class Initialized
ERROR - 2025-03-14 21:54:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:54:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:54:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:54:15 --> Final output sent to browser
DEBUG - 2025-03-14 21:54:15 --> Total execution time: 0.0934
INFO - 2025-03-14 21:54:36 --> Config Class Initialized
INFO - 2025-03-14 21:54:36 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:54:36 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:54:36 --> Utf8 Class Initialized
INFO - 2025-03-14 21:54:36 --> URI Class Initialized
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:54:36 --> Router Class Initialized
INFO - 2025-03-14 21:54:36 --> Output Class Initialized
INFO - 2025-03-14 21:54:36 --> Security Class Initialized
DEBUG - 2025-03-14 21:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:54:36 --> Input Class Initialized
INFO - 2025-03-14 21:54:36 --> Language Class Initialized
INFO - 2025-03-14 21:54:36 --> Language Class Initialized
INFO - 2025-03-14 21:54:36 --> Config Class Initialized
INFO - 2025-03-14 21:54:36 --> Loader Class Initialized
INFO - 2025-03-14 21:54:36 --> Helper loaded: url_helper
INFO - 2025-03-14 21:54:36 --> Helper loaded: file_helper
INFO - 2025-03-14 21:54:36 --> Helper loaded: html_helper
INFO - 2025-03-14 21:54:36 --> Helper loaded: form_helper
INFO - 2025-03-14 21:54:36 --> Helper loaded: text_helper
INFO - 2025-03-14 21:54:36 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:54:36 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:54:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:54:36 --> Database Driver Class Initialized
INFO - 2025-03-14 21:54:36 --> Email Class Initialized
INFO - 2025-03-14 21:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:54:36 --> Form Validation Class Initialized
INFO - 2025-03-14 21:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:54:36 --> Pagination Class Initialized
INFO - 2025-03-14 21:54:36 --> Controller Class Initialized
DEBUG - 2025-03-14 21:54:36 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:54:36 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:54:36 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:54:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:54:36 --> Model Class Initialized
ERROR - 2025-03-14 21:54:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:54:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:54:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:54:36 --> Final output sent to browser
DEBUG - 2025-03-14 21:54:36 --> Total execution time: 0.1252
INFO - 2025-03-14 21:54:38 --> Config Class Initialized
INFO - 2025-03-14 21:54:38 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:54:38 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:54:38 --> Utf8 Class Initialized
INFO - 2025-03-14 21:54:38 --> URI Class Initialized
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-14 21:54:38 --> Router Class Initialized
INFO - 2025-03-14 21:54:38 --> Output Class Initialized
INFO - 2025-03-14 21:54:38 --> Security Class Initialized
DEBUG - 2025-03-14 21:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:54:38 --> Input Class Initialized
INFO - 2025-03-14 21:54:38 --> Language Class Initialized
INFO - 2025-03-14 21:54:38 --> Language Class Initialized
INFO - 2025-03-14 21:54:38 --> Config Class Initialized
INFO - 2025-03-14 21:54:38 --> Loader Class Initialized
INFO - 2025-03-14 21:54:38 --> Helper loaded: url_helper
INFO - 2025-03-14 21:54:38 --> Helper loaded: file_helper
INFO - 2025-03-14 21:54:38 --> Helper loaded: html_helper
INFO - 2025-03-14 21:54:38 --> Helper loaded: form_helper
INFO - 2025-03-14 21:54:38 --> Helper loaded: text_helper
INFO - 2025-03-14 21:54:38 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:54:38 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:54:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:54:38 --> Database Driver Class Initialized
INFO - 2025-03-14 21:54:38 --> Email Class Initialized
INFO - 2025-03-14 21:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:54:38 --> Form Validation Class Initialized
INFO - 2025-03-14 21:54:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:54:38 --> Pagination Class Initialized
INFO - 2025-03-14 21:54:38 --> Controller Class Initialized
DEBUG - 2025-03-14 21:54:38 --> Home MX_Controller Initialized
INFO - 2025-03-14 21:54:38 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-14 21:54:38 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:54:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:54:38 --> Model Class Initialized
ERROR - 2025-03-14 21:54:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:54:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:54:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:54:38 --> Final output sent to browser
DEBUG - 2025-03-14 21:54:38 --> Total execution time: 0.0990
INFO - 2025-03-14 21:54:42 --> Config Class Initialized
INFO - 2025-03-14 21:54:42 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:54:42 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:54:42 --> Utf8 Class Initialized
INFO - 2025-03-14 21:54:42 --> URI Class Initialized
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/config/routes.php
INFO - 2025-03-14 21:54:42 --> Router Class Initialized
INFO - 2025-03-14 21:54:42 --> Output Class Initialized
INFO - 2025-03-14 21:54:42 --> Security Class Initialized
DEBUG - 2025-03-14 21:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:54:42 --> Input Class Initialized
INFO - 2025-03-14 21:54:42 --> Language Class Initialized
INFO - 2025-03-14 21:54:42 --> Language Class Initialized
INFO - 2025-03-14 21:54:42 --> Config Class Initialized
INFO - 2025-03-14 21:54:42 --> Loader Class Initialized
INFO - 2025-03-14 21:54:42 --> Helper loaded: url_helper
INFO - 2025-03-14 21:54:42 --> Helper loaded: file_helper
INFO - 2025-03-14 21:54:42 --> Helper loaded: html_helper
INFO - 2025-03-14 21:54:42 --> Helper loaded: form_helper
INFO - 2025-03-14 21:54:42 --> Helper loaded: text_helper
INFO - 2025-03-14 21:54:42 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:54:42 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:54:42 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:54:42 --> Database Driver Class Initialized
INFO - 2025-03-14 21:54:42 --> Email Class Initialized
INFO - 2025-03-14 21:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:54:42 --> Form Validation Class Initialized
INFO - 2025-03-14 21:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:54:42 --> Pagination Class Initialized
INFO - 2025-03-14 21:54:42 --> Controller Class Initialized
DEBUG - 2025-03-14 21:54:42 --> Purchase MX_Controller Initialized
INFO - 2025-03-14 21:54:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/models/Purchase_model.php
INFO - 2025-03-14 21:54:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:54:42 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:54:42 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:54:42 --> Model Class Initialized
ERROR - 2025-03-14 21:54:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:54:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/purchase/views/add_purchase_form.php
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:54:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:54:42 --> Final output sent to browser
DEBUG - 2025-03-14 21:54:42 --> Total execution time: 0.1177
INFO - 2025-03-14 21:54:44 --> Config Class Initialized
INFO - 2025-03-14 21:54:44 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:54:44 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:54:44 --> Utf8 Class Initialized
INFO - 2025-03-14 21:54:44 --> URI Class Initialized
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:54:44 --> Router Class Initialized
INFO - 2025-03-14 21:54:44 --> Output Class Initialized
INFO - 2025-03-14 21:54:44 --> Security Class Initialized
DEBUG - 2025-03-14 21:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:54:44 --> Input Class Initialized
INFO - 2025-03-14 21:54:44 --> Language Class Initialized
INFO - 2025-03-14 21:54:44 --> Language Class Initialized
INFO - 2025-03-14 21:54:44 --> Config Class Initialized
INFO - 2025-03-14 21:54:44 --> Loader Class Initialized
INFO - 2025-03-14 21:54:44 --> Helper loaded: url_helper
INFO - 2025-03-14 21:54:44 --> Helper loaded: file_helper
INFO - 2025-03-14 21:54:44 --> Helper loaded: html_helper
INFO - 2025-03-14 21:54:44 --> Helper loaded: form_helper
INFO - 2025-03-14 21:54:44 --> Helper loaded: text_helper
INFO - 2025-03-14 21:54:44 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:54:44 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:54:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:54:44 --> Database Driver Class Initialized
INFO - 2025-03-14 21:54:44 --> Email Class Initialized
INFO - 2025-03-14 21:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:54:44 --> Form Validation Class Initialized
INFO - 2025-03-14 21:54:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:54:44 --> Pagination Class Initialized
INFO - 2025-03-14 21:54:44 --> Controller Class Initialized
DEBUG - 2025-03-14 21:54:44 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:54:44 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:54:44 --> Model Class Initialized
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:54:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:54:44 --> Model Class Initialized
ERROR - 2025-03-14 21:54:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:54:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:54:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:54:44 --> Final output sent to browser
DEBUG - 2025-03-14 21:54:44 --> Total execution time: 0.1111
INFO - 2025-03-14 21:55:05 --> Config Class Initialized
INFO - 2025-03-14 21:55:05 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:55:05 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:55:05 --> Utf8 Class Initialized
INFO - 2025-03-14 21:55:05 --> URI Class Initialized
DEBUG - 2025-03-14 21:55:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-14 21:55:05 --> Router Class Initialized
INFO - 2025-03-14 21:55:05 --> Output Class Initialized
INFO - 2025-03-14 21:55:05 --> Security Class Initialized
DEBUG - 2025-03-14 21:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:55:05 --> Input Class Initialized
INFO - 2025-03-14 21:55:05 --> Language Class Initialized
INFO - 2025-03-14 21:55:05 --> Language Class Initialized
INFO - 2025-03-14 21:55:05 --> Config Class Initialized
INFO - 2025-03-14 21:55:05 --> Loader Class Initialized
INFO - 2025-03-14 21:55:05 --> Helper loaded: url_helper
INFO - 2025-03-14 21:55:05 --> Helper loaded: file_helper
INFO - 2025-03-14 21:55:05 --> Helper loaded: html_helper
INFO - 2025-03-14 21:55:05 --> Helper loaded: form_helper
INFO - 2025-03-14 21:55:05 --> Helper loaded: text_helper
INFO - 2025-03-14 21:55:05 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:55:05 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:55:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:55:05 --> Database Driver Class Initialized
INFO - 2025-03-14 21:55:05 --> Email Class Initialized
INFO - 2025-03-14 21:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:55:05 --> Form Validation Class Initialized
INFO - 2025-03-14 21:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:55:05 --> Pagination Class Initialized
INFO - 2025-03-14 21:55:05 --> Controller Class Initialized
DEBUG - 2025-03-14 21:55:05 --> Invoice MX_Controller Initialized
INFO - 2025-03-14 21:58:36 --> Config Class Initialized
INFO - 2025-03-14 21:58:36 --> Hooks Class Initialized
DEBUG - 2025-03-14 21:58:36 --> UTF-8 Support Enabled
INFO - 2025-03-14 21:58:36 --> Utf8 Class Initialized
INFO - 2025-03-14 21:58:36 --> URI Class Initialized
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 21:58:36 --> Router Class Initialized
INFO - 2025-03-14 21:58:36 --> Output Class Initialized
INFO - 2025-03-14 21:58:36 --> Security Class Initialized
DEBUG - 2025-03-14 21:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 21:58:36 --> Input Class Initialized
INFO - 2025-03-14 21:58:36 --> Language Class Initialized
INFO - 2025-03-14 21:58:36 --> Language Class Initialized
INFO - 2025-03-14 21:58:36 --> Config Class Initialized
INFO - 2025-03-14 21:58:36 --> Loader Class Initialized
INFO - 2025-03-14 21:58:36 --> Helper loaded: url_helper
INFO - 2025-03-14 21:58:36 --> Helper loaded: file_helper
INFO - 2025-03-14 21:58:36 --> Helper loaded: html_helper
INFO - 2025-03-14 21:58:36 --> Helper loaded: form_helper
INFO - 2025-03-14 21:58:36 --> Helper loaded: text_helper
INFO - 2025-03-14 21:58:36 --> Helper loaded: lang_helper
INFO - 2025-03-14 21:58:36 --> Helper loaded: directory_helper
INFO - 2025-03-14 21:58:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 21:58:36 --> Database Driver Class Initialized
INFO - 2025-03-14 21:58:36 --> Email Class Initialized
INFO - 2025-03-14 21:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 21:58:36 --> Form Validation Class Initialized
INFO - 2025-03-14 21:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 21:58:36 --> Pagination Class Initialized
INFO - 2025-03-14 21:58:36 --> Controller Class Initialized
DEBUG - 2025-03-14 21:58:36 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 21:58:36 --> Model Class Initialized
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 21:58:36 --> Model Class Initialized
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 21:58:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 21:58:36 --> Model Class Initialized
ERROR - 2025-03-14 21:58:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 21:58:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 21:58:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 21:58:36 --> Final output sent to browser
DEBUG - 2025-03-14 21:58:36 --> Total execution time: 0.1273
INFO - 2025-03-14 22:02:27 --> Config Class Initialized
INFO - 2025-03-14 22:02:27 --> Hooks Class Initialized
DEBUG - 2025-03-14 22:02:27 --> UTF-8 Support Enabled
INFO - 2025-03-14 22:02:27 --> Utf8 Class Initialized
INFO - 2025-03-14 22:02:27 --> URI Class Initialized
DEBUG - 2025-03-14 22:02:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-14 22:02:27 --> Router Class Initialized
INFO - 2025-03-14 22:02:27 --> Output Class Initialized
INFO - 2025-03-14 22:02:27 --> Security Class Initialized
DEBUG - 2025-03-14 22:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 22:02:27 --> Input Class Initialized
INFO - 2025-03-14 22:02:27 --> Language Class Initialized
INFO - 2025-03-14 22:02:27 --> Language Class Initialized
INFO - 2025-03-14 22:02:27 --> Config Class Initialized
INFO - 2025-03-14 22:02:27 --> Loader Class Initialized
INFO - 2025-03-14 22:02:27 --> Helper loaded: url_helper
INFO - 2025-03-14 22:02:27 --> Helper loaded: file_helper
INFO - 2025-03-14 22:02:27 --> Helper loaded: html_helper
INFO - 2025-03-14 22:02:27 --> Helper loaded: form_helper
INFO - 2025-03-14 22:02:27 --> Helper loaded: text_helper
INFO - 2025-03-14 22:02:27 --> Helper loaded: lang_helper
INFO - 2025-03-14 22:02:27 --> Helper loaded: directory_helper
INFO - 2025-03-14 22:02:27 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 22:02:27 --> Database Driver Class Initialized
INFO - 2025-03-14 22:02:27 --> Email Class Initialized
INFO - 2025-03-14 22:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 22:02:27 --> Form Validation Class Initialized
INFO - 2025-03-14 22:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 22:02:27 --> Pagination Class Initialized
INFO - 2025-03-14 22:02:27 --> Controller Class Initialized
DEBUG - 2025-03-14 22:02:27 --> Invoice MX_Controller Initialized
INFO - 2025-03-14 22:02:31 --> Config Class Initialized
INFO - 2025-03-14 22:02:31 --> Hooks Class Initialized
DEBUG - 2025-03-14 22:02:31 --> UTF-8 Support Enabled
INFO - 2025-03-14 22:02:31 --> Utf8 Class Initialized
INFO - 2025-03-14 22:02:31 --> URI Class Initialized
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-14 22:02:31 --> Router Class Initialized
INFO - 2025-03-14 22:02:31 --> Output Class Initialized
INFO - 2025-03-14 22:02:31 --> Security Class Initialized
DEBUG - 2025-03-14 22:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 22:02:31 --> Input Class Initialized
INFO - 2025-03-14 22:02:31 --> Language Class Initialized
INFO - 2025-03-14 22:02:31 --> Language Class Initialized
INFO - 2025-03-14 22:02:31 --> Config Class Initialized
INFO - 2025-03-14 22:02:31 --> Loader Class Initialized
INFO - 2025-03-14 22:02:31 --> Helper loaded: url_helper
INFO - 2025-03-14 22:02:31 --> Helper loaded: file_helper
INFO - 2025-03-14 22:02:31 --> Helper loaded: html_helper
INFO - 2025-03-14 22:02:31 --> Helper loaded: form_helper
INFO - 2025-03-14 22:02:31 --> Helper loaded: text_helper
INFO - 2025-03-14 22:02:31 --> Helper loaded: lang_helper
INFO - 2025-03-14 22:02:31 --> Helper loaded: directory_helper
INFO - 2025-03-14 22:02:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 22:02:31 --> Database Driver Class Initialized
INFO - 2025-03-14 22:02:31 --> Email Class Initialized
INFO - 2025-03-14 22:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 22:02:31 --> Form Validation Class Initialized
INFO - 2025-03-14 22:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 22:02:31 --> Pagination Class Initialized
INFO - 2025-03-14 22:02:31 --> Controller Class Initialized
DEBUG - 2025-03-14 22:02:31 --> Accounts MX_Controller Initialized
INFO - 2025-03-14 22:02:31 --> Model Class Initialized
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-14 22:02:31 --> Model Class Initialized
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 22:02:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 22:02:31 --> Model Class Initialized
ERROR - 2025-03-14 22:02:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 22:02:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/payment_method_form.php
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 22:02:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 22:02:31 --> Final output sent to browser
DEBUG - 2025-03-14 22:02:31 --> Total execution time: 0.1081
INFO - 2025-03-14 22:03:08 --> Config Class Initialized
INFO - 2025-03-14 22:03:08 --> Hooks Class Initialized
DEBUG - 2025-03-14 22:03:08 --> UTF-8 Support Enabled
INFO - 2025-03-14 22:03:08 --> Utf8 Class Initialized
INFO - 2025-03-14 22:03:08 --> URI Class Initialized
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-14 22:03:08 --> Router Class Initialized
INFO - 2025-03-14 22:03:08 --> Output Class Initialized
INFO - 2025-03-14 22:03:08 --> Security Class Initialized
DEBUG - 2025-03-14 22:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 22:03:08 --> Input Class Initialized
INFO - 2025-03-14 22:03:08 --> Language Class Initialized
INFO - 2025-03-14 22:03:08 --> Language Class Initialized
INFO - 2025-03-14 22:03:08 --> Config Class Initialized
INFO - 2025-03-14 22:03:08 --> Loader Class Initialized
INFO - 2025-03-14 22:03:08 --> Helper loaded: url_helper
INFO - 2025-03-14 22:03:08 --> Helper loaded: file_helper
INFO - 2025-03-14 22:03:08 --> Helper loaded: html_helper
INFO - 2025-03-14 22:03:08 --> Helper loaded: form_helper
INFO - 2025-03-14 22:03:08 --> Helper loaded: text_helper
INFO - 2025-03-14 22:03:08 --> Helper loaded: lang_helper
INFO - 2025-03-14 22:03:08 --> Helper loaded: directory_helper
INFO - 2025-03-14 22:03:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 22:03:08 --> Database Driver Class Initialized
INFO - 2025-03-14 22:03:08 --> Email Class Initialized
INFO - 2025-03-14 22:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 22:03:08 --> Form Validation Class Initialized
INFO - 2025-03-14 22:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 22:03:08 --> Pagination Class Initialized
INFO - 2025-03-14 22:03:08 --> Controller Class Initialized
DEBUG - 2025-03-14 22:03:08 --> Customer MX_Controller Initialized
INFO - 2025-03-14 22:03:08 --> Model Class Initialized
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-14 22:03:08 --> Model Class Initialized
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 22:03:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 22:03:08 --> Model Class Initialized
ERROR - 2025-03-14 22:03:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 22:03:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 22:03:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 22:03:08 --> Final output sent to browser
DEBUG - 2025-03-14 22:03:08 --> Total execution time: 0.1521
INFO - 2025-03-14 22:12:23 --> Config Class Initialized
INFO - 2025-03-14 22:12:23 --> Hooks Class Initialized
DEBUG - 2025-03-14 22:12:23 --> UTF-8 Support Enabled
INFO - 2025-03-14 22:12:23 --> Utf8 Class Initialized
INFO - 2025-03-14 22:12:23 --> URI Class Initialized
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-14 22:12:23 --> Router Class Initialized
INFO - 2025-03-14 22:12:23 --> Output Class Initialized
INFO - 2025-03-14 22:12:23 --> Security Class Initialized
DEBUG - 2025-03-14 22:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-14 22:12:23 --> Input Class Initialized
INFO - 2025-03-14 22:12:23 --> Language Class Initialized
INFO - 2025-03-14 22:12:23 --> Language Class Initialized
INFO - 2025-03-14 22:12:23 --> Config Class Initialized
INFO - 2025-03-14 22:12:23 --> Loader Class Initialized
INFO - 2025-03-14 22:12:23 --> Helper loaded: url_helper
INFO - 2025-03-14 22:12:23 --> Helper loaded: file_helper
INFO - 2025-03-14 22:12:23 --> Helper loaded: html_helper
INFO - 2025-03-14 22:12:23 --> Helper loaded: form_helper
INFO - 2025-03-14 22:12:23 --> Helper loaded: text_helper
INFO - 2025-03-14 22:12:23 --> Helper loaded: lang_helper
INFO - 2025-03-14 22:12:23 --> Helper loaded: directory_helper
INFO - 2025-03-14 22:12:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-14 22:12:23 --> Database Driver Class Initialized
INFO - 2025-03-14 22:12:23 --> Email Class Initialized
INFO - 2025-03-14 22:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-14 22:12:23 --> Form Validation Class Initialized
INFO - 2025-03-14 22:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-14 22:12:23 --> Pagination Class Initialized
INFO - 2025-03-14 22:12:23 --> Controller Class Initialized
DEBUG - 2025-03-14 22:12:23 --> Customer MX_Controller Initialized
INFO - 2025-03-14 22:12:23 --> Model Class Initialized
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-14 22:12:23 --> Model Class Initialized
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-14 22:12:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-14 22:12:23 --> Model Class Initialized
ERROR - 2025-03-14 22:12:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-14 22:12:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/form.php
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-14 22:12:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-14 22:12:23 --> Final output sent to browser
DEBUG - 2025-03-14 22:12:23 --> Total execution time: 0.1297
