<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-15 01:12:32 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:12:32 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:12:32 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:12:32 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 01:12:32 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 01:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 01:12:32 --> Model Class Initialized
ERROR - 2025-04-15 01:12:32 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 01:12:32 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 01:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 01:12:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 01:12:33 --> Final output sent to browser
DEBUG - 2025-04-15 01:12:33 --> Total execution time: 0.0771
INFO - 2025-04-15 01:12:33 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:12:33 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:12:33 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:12:33 --> Model Class Initialized
INFO - 2025-04-15 01:12:33 --> Final output sent to browser
DEBUG - 2025-04-15 01:12:33 --> Total execution time: 0.0370
INFO - 2025-04-15 01:12:36 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:12:36 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:12:36 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:12:36 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 01:12:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 01:12:36 --> Model Class Initialized
ERROR - 2025-04-15 01:12:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 01:12:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 01:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 01:12:36 --> Final output sent to browser
DEBUG - 2025-04-15 01:12:36 --> Total execution time: 0.1191
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 01:12:42 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
ERROR - 2025-04-15 01:12:42 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 01:12:42 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 01:12:42 --> Final output sent to browser
DEBUG - 2025-04-15 01:12:42 --> Total execution time: 0.1125
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:12:42 --> Model Class Initialized
INFO - 2025-04-15 01:12:43 --> Final output sent to browser
DEBUG - 2025-04-15 01:12:43 --> Total execution time: 0.0569
INFO - 2025-04-15 01:12:45 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:12:45 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:12:45 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:12:45 --> Model Class Initialized
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 01:12:45 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 01:12:45 --> Model Class Initialized
ERROR - 2025-04-15 01:12:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 01:12:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 01:12:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 01:12:45 --> Final output sent to browser
DEBUG - 2025-04-15 01:12:45 --> Total execution time: 0.1222
INFO - 2025-04-15 01:24:51 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:24:51 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:24:51 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:24:51 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 01:24:51 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 01:24:51 --> Model Class Initialized
ERROR - 2025-04-15 01:24:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 01:24:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 01:24:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 01:24:51 --> Final output sent to browser
DEBUG - 2025-04-15 01:24:51 --> Total execution time: 0.1128
INFO - 2025-04-15 01:24:52 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:24:52 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:24:52 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:24:52 --> Model Class Initialized
INFO - 2025-04-15 01:24:52 --> Final output sent to browser
DEBUG - 2025-04-15 01:24:52 --> Total execution time: 0.0535
INFO - 2025-04-15 01:24:56 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:24:56 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:24:56 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:24:56 --> Model Class Initialized
DEBUG - 2025-04-15 01:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 01:24:56 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 01:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 01:24:56 --> Model Class Initialized
ERROR - 2025-04-15 01:24:56 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 01:24:56 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 01:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 01:24:56 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 01:24:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 01:24:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 01:24:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 01:24:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 01:24:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 01:24:57 --> Final output sent to browser
DEBUG - 2025-04-15 01:24:57 --> Total execution time: 0.1225
INFO - 2025-04-15 01:25:44 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:25:44 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:25:44 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:25:44 --> Model Class Initialized
INFO - 2025-04-15 01:25:44 --> Final output sent to browser
DEBUG - 2025-04-15 01:25:44 --> Total execution time: 0.0089
INFO - 2025-04-15 01:25:46 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:25:46 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:25:46 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:25:46 --> Model Class Initialized
INFO - 2025-04-15 01:25:46 --> Final output sent to browser
DEBUG - 2025-04-15 01:25:46 --> Total execution time: 0.0058
INFO - 2025-04-15 01:25:49 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:25:49 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:25:49 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:25:49 --> Model Class Initialized
INFO - 2025-04-15 01:25:49 --> Final output sent to browser
DEBUG - 2025-04-15 01:25:49 --> Total execution time: 0.0144
INFO - 2025-04-15 01:25:52 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 01:25:52 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 01:25:52 --> Model Class Initialized
DEBUG - 2025-04-15 01:25:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 01:25:52 --> Model Class Initialized
INFO - 2025-04-15 01:25:52 --> Final output sent to browser
DEBUG - 2025-04-15 01:25:52 --> Total execution time: 0.0082
INFO - 2025-04-15 02:14:47 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:47 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:47 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:47 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:14:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:14:47 --> Model Class Initialized
ERROR - 2025-04-15 02:14:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:14:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:14:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:14:48 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:48 --> Total execution time: 0.1364
INFO - 2025-04-15 02:14:48 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:48 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:48 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:48 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:48 --> Model Class Initialized
INFO - 2025-04-15 02:14:48 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:48 --> Total execution time: 0.0469
INFO - 2025-04-15 02:14:53 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:53 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:53 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:53 --> Model Class Initialized
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 286
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 286
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 286
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 286
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 288
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 288
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 292
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 292
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 293
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 293
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 294
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 294
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 295
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 295
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 296
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 296
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 297
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 297
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 298
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 298
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 299
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 299
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 300
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 300
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 301
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 301
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 302
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 302
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 304
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 304
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 305
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 305
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 306
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 306
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 307
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 307
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 310
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 310
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 311
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 311
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 312
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 312
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 313
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 313
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 316
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 316
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 316
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 316
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 317
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 317
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:14:53 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:14:53 --> Model Class Initialized
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 166
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 293
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 305
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 324
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 334
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 343
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
ERROR - 2025-04-15 02:14:53 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php 374
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:14:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:14:53 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:53 --> Total execution time: 0.1218
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:14:55 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
ERROR - 2025-04-15 02:14:55 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:14:55 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:14:55 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:55 --> Total execution time: 0.1393
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:55 --> Model Class Initialized
INFO - 2025-04-15 02:14:55 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:55 --> Total execution time: 0.0356
INFO - 2025-04-15 02:14:57 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:57 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:57 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:57 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:14:57 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:14:57 --> Model Class Initialized
ERROR - 2025-04-15 02:14:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:14:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:14:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:14:57 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:57 --> Total execution time: 0.0878
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:14:58 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
ERROR - 2025-04-15 02:14:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:14:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:14:58 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:58 --> Total execution time: 0.1287
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
DEBUG - 2025-04-15 02:14:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:14:58 --> Model Class Initialized
INFO - 2025-04-15 02:14:58 --> Final output sent to browser
DEBUG - 2025-04-15 02:14:58 --> Total execution time: 0.0439
INFO - 2025-04-15 02:15:00 --> Model Class Initialized
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:15:00 --> Model Class Initialized
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:15:00 --> Model Class Initialized
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:15:00 --> Model Class Initialized
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:15:00 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:15:00 --> Model Class Initialized
ERROR - 2025-04-15 02:15:00 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:15:00 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:15:00 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:15:00 --> Final output sent to browser
DEBUG - 2025-04-15 02:15:00 --> Total execution time: 0.1217
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:16:13 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
ERROR - 2025-04-15 02:16:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:16:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:16:13 --> Final output sent to browser
DEBUG - 2025-04-15 02:16:13 --> Total execution time: 0.1088
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:16:13 --> Model Class Initialized
INFO - 2025-04-15 02:16:13 --> Final output sent to browser
DEBUG - 2025-04-15 02:16:13 --> Total execution time: 0.0507
INFO - 2025-04-15 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:16:15 --> Model Class Initialized
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:16:15 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:16:15 --> Model Class Initialized
ERROR - 2025-04-15 02:16:15 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:16:15 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:16:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:16:15 --> Final output sent to browser
DEBUG - 2025-04-15 02:16:15 --> Total execution time: 0.1135
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:17:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
ERROR - 2025-04-15 02:17:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:17:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:17:16 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:16 --> Total execution time: 0.1076
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:16 --> Model Class Initialized
INFO - 2025-04-15 02:17:16 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:16 --> Total execution time: 0.0427
INFO - 2025-04-15 02:17:19 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:19 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:19 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:19 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:17:19 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:17:19 --> Model Class Initialized
ERROR - 2025-04-15 02:17:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:17:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:17:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:17:19 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:19 --> Total execution time: 0.1149
INFO - 2025-04-15 02:17:23 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:23 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:23 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:23 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:17:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:17:23 --> Model Class Initialized
ERROR - 2025-04-15 02:17:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:17:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:17:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:17:24 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:24 --> Total execution time: 0.1365
INFO - 2025-04-15 02:17:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:24 --> Model Class Initialized
INFO - 2025-04-15 02:17:24 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:24 --> Total execution time: 0.0428
INFO - 2025-04-15 02:17:26 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:26 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:26 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:26 --> Model Class Initialized
ERROR - 2025-04-15 02:17:26 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 317
ERROR - 2025-04-15 02:17:26 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 317
DEBUG - 2025-04-15 02:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:17:26 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:17:26 --> Model Class Initialized
ERROR - 2025-04-15 02:17:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:17:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:17:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:17:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:17:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:17:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:17:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:17:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:17:27 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:27 --> Total execution time: 0.1506
INFO - 2025-04-15 02:17:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:55 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:55 --> Model Class Initialized
INFO - 2025-04-15 02:17:55 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:55 --> Total execution time: 0.0081
INFO - 2025-04-15 02:17:57 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:17:57 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:17:57 --> Model Class Initialized
DEBUG - 2025-04-15 02:17:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:17:57 --> Model Class Initialized
INFO - 2025-04-15 02:17:57 --> Final output sent to browser
DEBUG - 2025-04-15 02:17:57 --> Total execution time: 0.0169
INFO - 2025-04-15 02:18:07 --> Model Class Initialized
DEBUG - 2025-04-15 02:18:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:18:07 --> Model Class Initialized
DEBUG - 2025-04-15 02:18:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:18:07 --> Model Class Initialized
DEBUG - 2025-04-15 02:18:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:18:07 --> Model Class Initialized
INFO - 2025-04-15 02:18:07 --> Final output sent to browser
DEBUG - 2025-04-15 02:18:07 --> Total execution time: 0.0102
INFO - 2025-04-15 02:29:52 --> Model Class Initialized
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:29:52 --> Model Class Initialized
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:29:52 --> Model Class Initialized
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:29:52 --> Model Class Initialized
ERROR - 2025-04-15 02:29:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:29:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:29:52 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-15 02:29:52 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:29:52 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:29:52 --> Model Class Initialized
ERROR - 2025-04-15 02:29:52 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:29:52 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 02:29:52 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:29:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:29:52 --> Final output sent to browser
DEBUG - 2025-04-15 02:29:52 --> Total execution time: 0.0932
INFO - 2025-04-15 02:29:59 --> Model Class Initialized
DEBUG - 2025-04-15 02:29:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:29:59 --> Model Class Initialized
DEBUG - 2025-04-15 02:29:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:29:59 --> Model Class Initialized
DEBUG - 2025-04-15 02:29:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:29:59 --> Model Class Initialized
INFO - 2025-04-15 02:29:59 --> Final output sent to browser
DEBUG - 2025-04-15 02:29:59 --> Total execution time: 0.0045
INFO - 2025-04-15 02:30:01 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:01 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:01 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:01 --> Model Class Initialized
INFO - 2025-04-15 02:30:01 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:01 --> Total execution time: 0.0063
INFO - 2025-04-15 02:30:03 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:03 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:03 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:03 --> Model Class Initialized
INFO - 2025-04-15 02:30:03 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:03 --> Total execution time: 0.0107
INFO - 2025-04-15 02:30:11 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:11 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:11 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:11 --> Model Class Initialized
INFO - 2025-04-15 02:30:11 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:11 --> Total execution time: 0.0082
INFO - 2025-04-15 02:30:12 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:12 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:12 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:12 --> Model Class Initialized
INFO - 2025-04-15 02:30:12 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:12 --> Total execution time: 0.0160
INFO - 2025-04-15 02:30:15 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:15 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:15 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:15 --> Model Class Initialized
INFO - 2025-04-15 02:30:15 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:15 --> Total execution time: 0.0090
INFO - 2025-04-15 02:30:25 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:25 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:25 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:25 --> Model Class Initialized
INFO - 2025-04-15 02:30:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-15 02:30:25 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 677
DEBUG - 2025-04-15 02:30:25 --> 📥 acc_transaction insert: {"vid":"182","fyear":"1","VNo":"CV-55","Vtype":"CV","referenceNo":"1096","VDate":"2025-04-15","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"400.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:30:25"}
DEBUG - 2025-04-15 02:30:25 --> 📥 acc_transaction insert: {"vid":"182","fyear":"1","VNo":"CV-55","Vtype":"CV","referenceNo":"1096","VDate":"2025-04-15","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"400.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:30:25"}
DEBUG - 2025-04-15 02:30:25 --> 📥 acc_transaction insert: {"vid":"183","fyear":"1","VNo":"JV-77","Vtype":"JV","referenceNo":"1096","VDate":"2025-04-15","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"180.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:30:25"}
DEBUG - 2025-04-15 02:30:25 --> 📥 acc_transaction insert: {"vid":"183","fyear":"1","VNo":"JV-77","Vtype":"JV","referenceNo":"1096","VDate":"2025-04-15","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"180.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:30:25"}
DEBUG - 2025-04-15 02:30:25 --> 📥 acc_transaction insert: {"vid":"184","fyear":"1","VNo":"JV-78","Vtype":"JV","referenceNo":"1096","VDate":"2025-04-15","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:30:25"}
DEBUG - 2025-04-15 02:30:25 --> 📥 acc_transaction insert: {"vid":"184","fyear":"1","VNo":"JV-78","Vtype":"JV","referenceNo":"1096","VDate":"2025-04-15","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:30:25"}
DEBUG - 2025-04-15 02:30:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-15 02:30:25 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:25 --> Total execution time: 0.0729
INFO - 2025-04-15 02:30:27 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:27 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:27 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:27 --> Model Class Initialized
ERROR - 2025-04-15 02:30:27 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:30:27 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:30:27 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-15 02:30:27 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:30:27 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:30:27 --> Model Class Initialized
ERROR - 2025-04-15 02:30:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:30:27 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 02:30:27 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:30:27 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:30:27 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:27 --> Total execution time: 0.1258
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:30:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
ERROR - 2025-04-15 02:30:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:30:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:30:34 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:34 --> Total execution time: 0.1028
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:34 --> Model Class Initialized
INFO - 2025-04-15 02:30:34 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:34 --> Total execution time: 0.0418
INFO - 2025-04-15 02:30:36 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:36 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:36 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:36 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:30:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:30:36 --> Model Class Initialized
ERROR - 2025-04-15 02:30:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:30:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:30:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:30:36 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:36 --> Total execution time: 0.1235
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:30:41 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
ERROR - 2025-04-15 02:30:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:30:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:30:41 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:41 --> Total execution time: 0.1288
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:30:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:30:41 --> Model Class Initialized
INFO - 2025-04-15 02:30:41 --> Final output sent to browser
DEBUG - 2025-04-15 02:30:41 --> Total execution time: 0.0495
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
INFO - 2025-04-15 02:31:41 --> Final output sent to browser
DEBUG - 2025-04-15 02:31:41 --> Total execution time: 0.0055
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:31:41 --> Model Class Initialized
INFO - 2025-04-15 02:31:41 --> Final output sent to browser
DEBUG - 2025-04-15 02:31:41 --> Total execution time: 0.0093
INFO - 2025-04-15 02:31:42 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:31:42 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:31:42 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:31:42 --> Model Class Initialized
INFO - 2025-04-15 02:31:42 --> Final output sent to browser
DEBUG - 2025-04-15 02:31:42 --> Total execution time: 0.0122
INFO - 2025-04-15 02:31:44 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:31:44 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:31:44 --> Model Class Initialized
DEBUG - 2025-04-15 02:31:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:31:44 --> Model Class Initialized
INFO - 2025-04-15 02:31:44 --> Final output sent to browser
DEBUG - 2025-04-15 02:31:44 --> Total execution time: 0.0075
INFO - 2025-04-15 02:33:02 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:02 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:02 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:02 --> Model Class Initialized
ERROR - 2025-04-15 02:33:02 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:33:02 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:33:02 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-15 02:33:02 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:33:02 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:33:02 --> Model Class Initialized
ERROR - 2025-04-15 02:33:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:33:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 02:33:02 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:33:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:33:02 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:02 --> Total execution time: 0.1089
INFO - 2025-04-15 02:33:07 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:07 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:07 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:07 --> Model Class Initialized
INFO - 2025-04-15 02:33:07 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:07 --> Total execution time: 0.0052
INFO - 2025-04-15 02:33:09 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:09 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:09 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:09 --> Model Class Initialized
INFO - 2025-04-15 02:33:09 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:09 --> Total execution time: 0.0064
INFO - 2025-04-15 02:33:14 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:14 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:14 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:14 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:14 --> Model Class Initialized
INFO - 2025-04-15 02:33:14 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:14 --> Total execution time: 0.0134
INFO - 2025-04-15 02:33:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:16 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:16 --> Model Class Initialized
INFO - 2025-04-15 02:33:16 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:16 --> Total execution time: 0.0134
INFO - 2025-04-15 02:33:17 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:17 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:17 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:17 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:17 --> Model Class Initialized
INFO - 2025-04-15 02:33:17 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:17 --> Total execution time: 0.0061
INFO - 2025-04-15 02:33:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:24 --> Model Class Initialized
INFO - 2025-04-15 02:33:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-15 02:33:24 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 677
DEBUG - 2025-04-15 02:33:24 --> 📥 acc_transaction insert: {"vid":"185","fyear":"1","VNo":"CV-56","Vtype":"CV","referenceNo":"1097","VDate":"2025-04-15","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"800.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:33:24"}
DEBUG - 2025-04-15 02:33:24 --> 📥 acc_transaction insert: {"vid":"185","fyear":"1","VNo":"CV-56","Vtype":"CV","referenceNo":"1097","VDate":"2025-04-15","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"800.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:33:24"}
DEBUG - 2025-04-15 02:33:24 --> 📥 acc_transaction insert: {"vid":"186","fyear":"1","VNo":"JV-79","Vtype":"JV","referenceNo":"1097","VDate":"2025-04-15","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"360.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:33:24"}
DEBUG - 2025-04-15 02:33:24 --> 📥 acc_transaction insert: {"vid":"186","fyear":"1","VNo":"JV-79","Vtype":"JV","referenceNo":"1097","VDate":"2025-04-15","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"360.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:33:24"}
DEBUG - 2025-04-15 02:33:24 --> 📥 acc_transaction insert: {"vid":"187","fyear":"1","VNo":"JV-80","Vtype":"JV","referenceNo":"1097","VDate":"2025-04-15","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:33:24"}
DEBUG - 2025-04-15 02:33:24 --> 📥 acc_transaction insert: {"vid":"187","fyear":"1","VNo":"JV-80","Vtype":"JV","referenceNo":"1097","VDate":"2025-04-15","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 02:33:24"}
DEBUG - 2025-04-15 02:33:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-15 02:33:24 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:24 --> Total execution time: 0.0554
INFO - 2025-04-15 02:33:26 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:26 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:26 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:26 --> Model Class Initialized
ERROR - 2025-04-15 02:33:26 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:33:26 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 02:33:26 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-15 02:33:26 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:33:26 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:33:26 --> Model Class Initialized
ERROR - 2025-04-15 02:33:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:33:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 02:33:26 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:33:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:33:26 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:26 --> Total execution time: 0.1368
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:33:31 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
ERROR - 2025-04-15 02:33:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:33:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:33:31 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:31 --> Total execution time: 0.1156
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:31 --> Model Class Initialized
INFO - 2025-04-15 02:33:31 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:31 --> Total execution time: 0.0624
INFO - 2025-04-15 02:33:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:33:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:33:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:33:34 --> Model Class Initialized
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 02:33:34 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 02:33:34 --> Model Class Initialized
ERROR - 2025-04-15 02:33:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 02:33:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 02:33:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 02:33:34 --> Final output sent to browser
DEBUG - 2025-04-15 02:33:34 --> Total execution time: 0.1504
INFO - 2025-04-15 02:34:23 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:34:23 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:34:23 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:34:23 --> Model Class Initialized
INFO - 2025-04-15 02:34:23 --> Final output sent to browser
DEBUG - 2025-04-15 02:34:23 --> Total execution time: 0.0112
INFO - 2025-04-15 02:34:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:34:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:34:24 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:34:24 --> Model Class Initialized
INFO - 2025-04-15 02:34:24 --> Final output sent to browser
DEBUG - 2025-04-15 02:34:24 --> Total execution time: 0.0124
INFO - 2025-04-15 02:34:29 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 02:34:29 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 02:34:29 --> Model Class Initialized
DEBUG - 2025-04-15 02:34:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 02:34:29 --> Model Class Initialized
INFO - 2025-04-15 02:34:29 --> Final output sent to browser
DEBUG - 2025-04-15 02:34:29 --> Total execution time: 0.0080
INFO - 2025-04-15 06:52:10 --> Config Class Initialized
INFO - 2025-04-15 06:52:10 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:52:10 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:52:10 --> Utf8 Class Initialized
INFO - 2025-04-15 06:52:10 --> URI Class Initialized
INFO - 2025-04-15 06:52:10 --> Router Class Initialized
INFO - 2025-04-15 06:52:10 --> Output Class Initialized
INFO - 2025-04-15 06:52:10 --> Security Class Initialized
DEBUG - 2025-04-15 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:52:10 --> Input Class Initialized
INFO - 2025-04-15 06:52:10 --> Language Class Initialized
INFO - 2025-04-15 06:52:10 --> Language Class Initialized
INFO - 2025-04-15 06:52:10 --> Config Class Initialized
INFO - 2025-04-15 06:52:10 --> Loader Class Initialized
INFO - 2025-04-15 06:52:10 --> Helper loaded: url_helper
INFO - 2025-04-15 06:52:10 --> Helper loaded: file_helper
INFO - 2025-04-15 06:52:10 --> Helper loaded: html_helper
INFO - 2025-04-15 06:52:10 --> Helper loaded: form_helper
INFO - 2025-04-15 06:52:10 --> Helper loaded: text_helper
INFO - 2025-04-15 06:52:10 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:52:10 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:52:10 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:52:10 --> Database Driver Class Initialized
INFO - 2025-04-15 06:52:10 --> Email Class Initialized
INFO - 2025-04-15 06:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:52:10 --> Form Validation Class Initialized
INFO - 2025-04-15 06:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:52:10 --> Pagination Class Initialized
INFO - 2025-04-15 06:52:10 --> Controller Class Initialized
INFO - 2025-04-15 06:52:10 --> Model Class Initialized
INFO - 2025-04-15 06:52:10 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:52:10 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:52:10 --> Final output sent to browser
DEBUG - 2025-04-15 06:52:10 --> Total execution time: 0.1072
INFO - 2025-04-15 06:52:27 --> Config Class Initialized
INFO - 2025-04-15 06:52:27 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:52:27 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:52:27 --> Utf8 Class Initialized
INFO - 2025-04-15 06:52:27 --> URI Class Initialized
INFO - 2025-04-15 06:52:27 --> Router Class Initialized
INFO - 2025-04-15 06:52:27 --> Output Class Initialized
INFO - 2025-04-15 06:52:27 --> Security Class Initialized
DEBUG - 2025-04-15 06:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:52:27 --> Input Class Initialized
INFO - 2025-04-15 06:52:27 --> Language Class Initialized
INFO - 2025-04-15 06:52:27 --> Language Class Initialized
INFO - 2025-04-15 06:52:27 --> Config Class Initialized
INFO - 2025-04-15 06:52:27 --> Loader Class Initialized
INFO - 2025-04-15 06:52:27 --> Helper loaded: url_helper
INFO - 2025-04-15 06:52:27 --> Helper loaded: file_helper
INFO - 2025-04-15 06:52:27 --> Helper loaded: html_helper
INFO - 2025-04-15 06:52:27 --> Helper loaded: form_helper
INFO - 2025-04-15 06:52:27 --> Helper loaded: text_helper
INFO - 2025-04-15 06:52:27 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:52:27 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:52:27 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:52:27 --> Database Driver Class Initialized
INFO - 2025-04-15 06:52:27 --> Email Class Initialized
INFO - 2025-04-15 06:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:52:27 --> Form Validation Class Initialized
INFO - 2025-04-15 06:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:52:27 --> Pagination Class Initialized
INFO - 2025-04-15 06:52:27 --> Controller Class Initialized
INFO - 2025-04-15 06:52:27 --> Model Class Initialized
INFO - 2025-04-15 06:52:27 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:52:27 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:52:27 --> Final output sent to browser
DEBUG - 2025-04-15 06:52:27 --> Total execution time: 0.0061
INFO - 2025-04-15 06:53:57 --> Config Class Initialized
INFO - 2025-04-15 06:53:57 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:53:57 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:53:57 --> Utf8 Class Initialized
INFO - 2025-04-15 06:53:57 --> URI Class Initialized
INFO - 2025-04-15 06:53:57 --> Router Class Initialized
INFO - 2025-04-15 06:53:57 --> Output Class Initialized
INFO - 2025-04-15 06:53:57 --> Security Class Initialized
DEBUG - 2025-04-15 06:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:53:57 --> Input Class Initialized
INFO - 2025-04-15 06:53:57 --> Language Class Initialized
INFO - 2025-04-15 06:53:57 --> Language Class Initialized
INFO - 2025-04-15 06:53:57 --> Config Class Initialized
INFO - 2025-04-15 06:53:57 --> Loader Class Initialized
INFO - 2025-04-15 06:53:57 --> Helper loaded: url_helper
INFO - 2025-04-15 06:53:57 --> Helper loaded: file_helper
INFO - 2025-04-15 06:53:57 --> Helper loaded: html_helper
INFO - 2025-04-15 06:53:57 --> Helper loaded: form_helper
INFO - 2025-04-15 06:53:57 --> Helper loaded: text_helper
INFO - 2025-04-15 06:53:57 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:53:57 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:53:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:53:57 --> Database Driver Class Initialized
INFO - 2025-04-15 06:53:57 --> Email Class Initialized
INFO - 2025-04-15 06:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:53:57 --> Form Validation Class Initialized
INFO - 2025-04-15 06:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:53:57 --> Pagination Class Initialized
INFO - 2025-04-15 06:53:57 --> Controller Class Initialized
INFO - 2025-04-15 06:53:57 --> Model Class Initialized
INFO - 2025-04-15 06:53:57 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:53:57 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:53:57 --> Final output sent to browser
DEBUG - 2025-04-15 06:53:57 --> Total execution time: 0.0868
INFO - 2025-04-15 06:55:17 --> Config Class Initialized
INFO - 2025-04-15 06:55:17 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:55:17 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:55:17 --> Utf8 Class Initialized
INFO - 2025-04-15 06:55:17 --> URI Class Initialized
INFO - 2025-04-15 06:55:17 --> Router Class Initialized
INFO - 2025-04-15 06:55:17 --> Output Class Initialized
INFO - 2025-04-15 06:55:17 --> Security Class Initialized
DEBUG - 2025-04-15 06:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:55:17 --> Input Class Initialized
INFO - 2025-04-15 06:55:17 --> Language Class Initialized
INFO - 2025-04-15 06:55:17 --> Language Class Initialized
INFO - 2025-04-15 06:55:17 --> Config Class Initialized
INFO - 2025-04-15 06:55:17 --> Loader Class Initialized
INFO - 2025-04-15 06:55:17 --> Helper loaded: url_helper
INFO - 2025-04-15 06:55:17 --> Helper loaded: file_helper
INFO - 2025-04-15 06:55:17 --> Helper loaded: html_helper
INFO - 2025-04-15 06:55:17 --> Helper loaded: form_helper
INFO - 2025-04-15 06:55:17 --> Helper loaded: text_helper
INFO - 2025-04-15 06:55:17 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:55:17 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:55:17 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:55:17 --> Database Driver Class Initialized
INFO - 2025-04-15 06:55:17 --> Email Class Initialized
INFO - 2025-04-15 06:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:55:17 --> Form Validation Class Initialized
INFO - 2025-04-15 06:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:55:17 --> Pagination Class Initialized
INFO - 2025-04-15 06:55:17 --> Controller Class Initialized
INFO - 2025-04-15 06:55:17 --> Model Class Initialized
INFO - 2025-04-15 06:55:17 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:55:17 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:55:17 --> Final output sent to browser
DEBUG - 2025-04-15 06:55:17 --> Total execution time: 0.0632
INFO - 2025-04-15 06:55:19 --> Config Class Initialized
INFO - 2025-04-15 06:55:19 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:55:19 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:55:19 --> Utf8 Class Initialized
INFO - 2025-04-15 06:55:19 --> URI Class Initialized
INFO - 2025-04-15 06:55:19 --> Router Class Initialized
INFO - 2025-04-15 06:55:19 --> Output Class Initialized
INFO - 2025-04-15 06:55:19 --> Security Class Initialized
DEBUG - 2025-04-15 06:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:55:19 --> Input Class Initialized
INFO - 2025-04-15 06:55:19 --> Language Class Initialized
INFO - 2025-04-15 06:55:19 --> Language Class Initialized
INFO - 2025-04-15 06:55:19 --> Config Class Initialized
INFO - 2025-04-15 06:55:19 --> Loader Class Initialized
INFO - 2025-04-15 06:55:19 --> Helper loaded: url_helper
INFO - 2025-04-15 06:55:19 --> Helper loaded: file_helper
INFO - 2025-04-15 06:55:19 --> Helper loaded: html_helper
INFO - 2025-04-15 06:55:19 --> Helper loaded: form_helper
INFO - 2025-04-15 06:55:19 --> Helper loaded: text_helper
INFO - 2025-04-15 06:55:19 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:55:19 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:55:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:55:19 --> Database Driver Class Initialized
INFO - 2025-04-15 06:55:19 --> Email Class Initialized
INFO - 2025-04-15 06:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:55:19 --> Form Validation Class Initialized
INFO - 2025-04-15 06:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:55:19 --> Pagination Class Initialized
INFO - 2025-04-15 06:55:19 --> Controller Class Initialized
INFO - 2025-04-15 06:55:19 --> Model Class Initialized
INFO - 2025-04-15 06:55:19 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:55:19 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:55:19 --> Final output sent to browser
DEBUG - 2025-04-15 06:55:19 --> Total execution time: 0.0601
INFO - 2025-04-15 06:57:00 --> Config Class Initialized
INFO - 2025-04-15 06:57:00 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:57:00 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:57:00 --> Utf8 Class Initialized
INFO - 2025-04-15 06:57:00 --> URI Class Initialized
INFO - 2025-04-15 06:57:00 --> Router Class Initialized
INFO - 2025-04-15 06:57:00 --> Output Class Initialized
INFO - 2025-04-15 06:57:00 --> Security Class Initialized
DEBUG - 2025-04-15 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:57:00 --> Input Class Initialized
INFO - 2025-04-15 06:57:00 --> Language Class Initialized
INFO - 2025-04-15 06:57:00 --> Language Class Initialized
INFO - 2025-04-15 06:57:00 --> Config Class Initialized
INFO - 2025-04-15 06:57:00 --> Loader Class Initialized
INFO - 2025-04-15 06:57:00 --> Helper loaded: url_helper
INFO - 2025-04-15 06:57:00 --> Helper loaded: file_helper
INFO - 2025-04-15 06:57:00 --> Helper loaded: html_helper
INFO - 2025-04-15 06:57:00 --> Helper loaded: form_helper
INFO - 2025-04-15 06:57:00 --> Helper loaded: text_helper
INFO - 2025-04-15 06:57:00 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:57:00 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:57:00 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:57:00 --> Database Driver Class Initialized
INFO - 2025-04-15 06:57:00 --> Email Class Initialized
INFO - 2025-04-15 06:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:57:00 --> Form Validation Class Initialized
INFO - 2025-04-15 06:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:57:00 --> Pagination Class Initialized
INFO - 2025-04-15 06:57:00 --> Controller Class Initialized
INFO - 2025-04-15 06:57:00 --> Model Class Initialized
INFO - 2025-04-15 06:57:00 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:57:00 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:57:00 --> Final output sent to browser
DEBUG - 2025-04-15 06:57:00 --> Total execution time: 0.0756
INFO - 2025-04-15 06:57:21 --> Config Class Initialized
INFO - 2025-04-15 06:57:21 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:57:21 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:57:21 --> Utf8 Class Initialized
INFO - 2025-04-15 06:57:21 --> URI Class Initialized
INFO - 2025-04-15 06:57:21 --> Router Class Initialized
INFO - 2025-04-15 06:57:21 --> Output Class Initialized
INFO - 2025-04-15 06:57:21 --> Security Class Initialized
DEBUG - 2025-04-15 06:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:57:21 --> Input Class Initialized
INFO - 2025-04-15 06:57:21 --> Language Class Initialized
INFO - 2025-04-15 06:57:21 --> Language Class Initialized
INFO - 2025-04-15 06:57:21 --> Config Class Initialized
INFO - 2025-04-15 06:57:21 --> Loader Class Initialized
INFO - 2025-04-15 06:57:21 --> Helper loaded: url_helper
INFO - 2025-04-15 06:57:21 --> Helper loaded: file_helper
INFO - 2025-04-15 06:57:21 --> Helper loaded: html_helper
INFO - 2025-04-15 06:57:21 --> Helper loaded: form_helper
INFO - 2025-04-15 06:57:21 --> Helper loaded: text_helper
INFO - 2025-04-15 06:57:21 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:57:21 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:57:21 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:57:21 --> Database Driver Class Initialized
INFO - 2025-04-15 06:57:21 --> Email Class Initialized
INFO - 2025-04-15 06:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:57:21 --> Form Validation Class Initialized
INFO - 2025-04-15 06:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:57:21 --> Pagination Class Initialized
INFO - 2025-04-15 06:57:21 --> Controller Class Initialized
INFO - 2025-04-15 06:57:21 --> Model Class Initialized
INFO - 2025-04-15 06:57:21 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:57:21 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:57:21 --> Final output sent to browser
DEBUG - 2025-04-15 06:57:21 --> Total execution time: 0.0802
INFO - 2025-04-15 06:57:54 --> Config Class Initialized
INFO - 2025-04-15 06:57:54 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:57:54 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:57:54 --> Utf8 Class Initialized
INFO - 2025-04-15 06:57:54 --> URI Class Initialized
INFO - 2025-04-15 06:57:54 --> Router Class Initialized
INFO - 2025-04-15 06:57:54 --> Output Class Initialized
INFO - 2025-04-15 06:57:54 --> Security Class Initialized
DEBUG - 2025-04-15 06:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:57:54 --> Input Class Initialized
INFO - 2025-04-15 06:57:54 --> Language Class Initialized
INFO - 2025-04-15 06:57:54 --> Language Class Initialized
INFO - 2025-04-15 06:57:54 --> Config Class Initialized
INFO - 2025-04-15 06:57:54 --> Loader Class Initialized
INFO - 2025-04-15 06:57:54 --> Helper loaded: url_helper
INFO - 2025-04-15 06:57:54 --> Helper loaded: file_helper
INFO - 2025-04-15 06:57:54 --> Helper loaded: html_helper
INFO - 2025-04-15 06:57:54 --> Helper loaded: form_helper
INFO - 2025-04-15 06:57:54 --> Helper loaded: text_helper
INFO - 2025-04-15 06:57:54 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:57:54 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:57:54 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:57:54 --> Database Driver Class Initialized
INFO - 2025-04-15 06:57:54 --> Email Class Initialized
INFO - 2025-04-15 06:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:57:54 --> Form Validation Class Initialized
INFO - 2025-04-15 06:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:57:54 --> Pagination Class Initialized
INFO - 2025-04-15 06:57:54 --> Controller Class Initialized
INFO - 2025-04-15 06:57:54 --> Model Class Initialized
INFO - 2025-04-15 06:57:54 --> Helper loaded: security_helper
DEBUG - 2025-04-15 06:57:54 --> Config file loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/config/jwt.php
INFO - 2025-04-15 06:57:54 --> Final output sent to browser
DEBUG - 2025-04-15 06:57:54 --> Total execution time: 0.0759
INFO - 2025-04-15 06:59:04 --> Config Class Initialized
INFO - 2025-04-15 06:59:04 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:04 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:04 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:04 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-04-15 06:59:04 --> No URI present. Default controller set.
INFO - 2025-04-15 06:59:04 --> Router Class Initialized
INFO - 2025-04-15 06:59:04 --> Output Class Initialized
INFO - 2025-04-15 06:59:04 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:04 --> Input Class Initialized
INFO - 2025-04-15 06:59:04 --> Language Class Initialized
INFO - 2025-04-15 06:59:04 --> Language Class Initialized
INFO - 2025-04-15 06:59:04 --> Config Class Initialized
INFO - 2025-04-15 06:59:04 --> Loader Class Initialized
INFO - 2025-04-15 06:59:04 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:04 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:04 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:04 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:04 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:04 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:04 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:04 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:04 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:04 --> Email Class Initialized
INFO - 2025-04-15 06:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:04 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:04 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:04 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:04 --> Auth MX_Controller Initialized
INFO - 2025-04-15 06:59:04 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-15 06:59:04 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 06:59:04 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 06:59:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 06:59:04 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-04-15 06:59:04 --> Final output sent to browser
DEBUG - 2025-04-15 06:59:04 --> Total execution time: 0.0299
INFO - 2025-04-15 06:59:12 --> Config Class Initialized
INFO - 2025-04-15 06:59:12 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:12 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:12 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:12 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-15 06:59:12 --> Router Class Initialized
INFO - 2025-04-15 06:59:12 --> Output Class Initialized
INFO - 2025-04-15 06:59:12 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:12 --> Input Class Initialized
INFO - 2025-04-15 06:59:12 --> Language Class Initialized
INFO - 2025-04-15 06:59:12 --> Language Class Initialized
INFO - 2025-04-15 06:59:12 --> Config Class Initialized
INFO - 2025-04-15 06:59:12 --> Loader Class Initialized
INFO - 2025-04-15 06:59:12 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:12 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:12 --> Email Class Initialized
INFO - 2025-04-15 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:12 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:12 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:12 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:12 --> Auth MX_Controller Initialized
INFO - 2025-04-15 06:59:12 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-04-15 06:59:12 --> Model Class Initialized
INFO - 2025-04-15 06:59:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-15 06:59:12 --> Config Class Initialized
INFO - 2025-04-15 06:59:12 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:12 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:12 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:12 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-15 06:59:12 --> Router Class Initialized
INFO - 2025-04-15 06:59:12 --> Output Class Initialized
INFO - 2025-04-15 06:59:12 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:12 --> Input Class Initialized
INFO - 2025-04-15 06:59:12 --> Language Class Initialized
INFO - 2025-04-15 06:59:12 --> Language Class Initialized
INFO - 2025-04-15 06:59:12 --> Config Class Initialized
INFO - 2025-04-15 06:59:12 --> Loader Class Initialized
INFO - 2025-04-15 06:59:12 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:12 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:12 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:12 --> Email Class Initialized
INFO - 2025-04-15 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:12 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:12 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:12 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:12 --> Home MX_Controller Initialized
INFO - 2025-04-15 06:59:12 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-15 06:59:12 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 06:59:12 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 06:59:12 --> Model Class Initialized
ERROR - 2025-04-15 06:59:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 06:59:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 06:59:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 06:59:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 06:59:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 06:59:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-15 06:59:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 06:59:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 06:59:13 --> Final output sent to browser
DEBUG - 2025-04-15 06:59:13 --> Total execution time: 0.7140
INFO - 2025-04-15 06:59:16 --> Config Class Initialized
INFO - 2025-04-15 06:59:16 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:16 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:16 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:16 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:16 --> Router Class Initialized
INFO - 2025-04-15 06:59:16 --> Output Class Initialized
INFO - 2025-04-15 06:59:16 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:16 --> Input Class Initialized
INFO - 2025-04-15 06:59:16 --> Language Class Initialized
INFO - 2025-04-15 06:59:16 --> Language Class Initialized
INFO - 2025-04-15 06:59:16 --> Config Class Initialized
INFO - 2025-04-15 06:59:16 --> Loader Class Initialized
INFO - 2025-04-15 06:59:16 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:16 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:16 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:16 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:16 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:16 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:16 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:16 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:16 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:16 --> Email Class Initialized
INFO - 2025-04-15 06:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:16 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:16 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:16 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:16 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:16 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:16 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:16 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:16 --> Model Class Initialized
ERROR - 2025-04-15 12:59:16 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 12:59:16 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 12:59:16 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-15 12:59:16 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 12:59:16 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 12:59:16 --> Model Class Initialized
ERROR - 2025-04-15 12:59:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 12:59:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 12:59:16 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 12:59:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 12:59:16 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:16 --> Total execution time: 0.1244
INFO - 2025-04-15 06:59:19 --> Config Class Initialized
INFO - 2025-04-15 06:59:19 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:19 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:19 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:19 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:19 --> Router Class Initialized
INFO - 2025-04-15 06:59:19 --> Output Class Initialized
INFO - 2025-04-15 06:59:19 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:19 --> Input Class Initialized
INFO - 2025-04-15 06:59:19 --> Language Class Initialized
INFO - 2025-04-15 06:59:19 --> Language Class Initialized
INFO - 2025-04-15 06:59:19 --> Config Class Initialized
INFO - 2025-04-15 06:59:19 --> Loader Class Initialized
INFO - 2025-04-15 06:59:19 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:19 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:19 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:19 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:19 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:19 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:19 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:19 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:19 --> Email Class Initialized
INFO - 2025-04-15 06:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:19 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:19 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:19 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:19 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:19 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:19 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:19 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:19 --> Model Class Initialized
INFO - 2025-04-15 12:59:19 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:19 --> Total execution time: 0.0148
INFO - 2025-04-15 06:59:20 --> Config Class Initialized
INFO - 2025-04-15 06:59:20 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:20 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:20 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:20 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:20 --> Router Class Initialized
INFO - 2025-04-15 06:59:20 --> Output Class Initialized
INFO - 2025-04-15 06:59:20 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:20 --> Input Class Initialized
INFO - 2025-04-15 06:59:20 --> Language Class Initialized
INFO - 2025-04-15 06:59:20 --> Language Class Initialized
INFO - 2025-04-15 06:59:20 --> Config Class Initialized
INFO - 2025-04-15 06:59:20 --> Loader Class Initialized
INFO - 2025-04-15 06:59:20 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:20 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:20 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:20 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:20 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:20 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:20 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:20 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:20 --> Email Class Initialized
INFO - 2025-04-15 06:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:20 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:20 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:20 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:20 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:20 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:20 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:20 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:20 --> Model Class Initialized
INFO - 2025-04-15 12:59:20 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:20 --> Total execution time: 0.0268
INFO - 2025-04-15 06:59:23 --> Config Class Initialized
INFO - 2025-04-15 06:59:23 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:23 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:23 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:23 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:23 --> Router Class Initialized
INFO - 2025-04-15 06:59:23 --> Output Class Initialized
INFO - 2025-04-15 06:59:23 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:23 --> Input Class Initialized
INFO - 2025-04-15 06:59:23 --> Language Class Initialized
INFO - 2025-04-15 06:59:23 --> Language Class Initialized
INFO - 2025-04-15 06:59:23 --> Config Class Initialized
INFO - 2025-04-15 06:59:23 --> Loader Class Initialized
INFO - 2025-04-15 06:59:23 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:23 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:23 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:23 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:23 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:23 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:23 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:23 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:23 --> Email Class Initialized
INFO - 2025-04-15 06:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:23 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:23 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:23 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:23 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:23 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:23 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:23 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:23 --> Model Class Initialized
INFO - 2025-04-15 12:59:23 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:23 --> Total execution time: 0.0106
INFO - 2025-04-15 06:59:24 --> Config Class Initialized
INFO - 2025-04-15 06:59:24 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:24 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:24 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:24 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:24 --> Router Class Initialized
INFO - 2025-04-15 06:59:24 --> Output Class Initialized
INFO - 2025-04-15 06:59:24 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:24 --> Input Class Initialized
INFO - 2025-04-15 06:59:24 --> Language Class Initialized
INFO - 2025-04-15 06:59:24 --> Language Class Initialized
INFO - 2025-04-15 06:59:24 --> Config Class Initialized
INFO - 2025-04-15 06:59:24 --> Loader Class Initialized
INFO - 2025-04-15 06:59:24 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:24 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:24 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:24 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:24 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:24 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:24 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:24 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:24 --> Email Class Initialized
INFO - 2025-04-15 06:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:24 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:24 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:24 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:24 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:24 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:24 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:24 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:24 --> Model Class Initialized
INFO - 2025-04-15 12:59:24 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:24 --> Total execution time: 0.0362
INFO - 2025-04-15 06:59:26 --> Config Class Initialized
INFO - 2025-04-15 06:59:26 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:26 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:26 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:26 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:26 --> Router Class Initialized
INFO - 2025-04-15 06:59:26 --> Output Class Initialized
INFO - 2025-04-15 06:59:26 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:26 --> Input Class Initialized
INFO - 2025-04-15 06:59:26 --> Language Class Initialized
INFO - 2025-04-15 06:59:26 --> Language Class Initialized
INFO - 2025-04-15 06:59:26 --> Config Class Initialized
INFO - 2025-04-15 06:59:26 --> Loader Class Initialized
INFO - 2025-04-15 06:59:26 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:26 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:26 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:26 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:26 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:26 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:26 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:26 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:26 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:26 --> Email Class Initialized
INFO - 2025-04-15 06:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:26 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:26 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:26 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:26 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:26 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:26 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:26 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:26 --> Model Class Initialized
INFO - 2025-04-15 12:59:26 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:26 --> Total execution time: 0.0120
INFO - 2025-04-15 06:59:39 --> Config Class Initialized
INFO - 2025-04-15 06:59:39 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:39 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:39 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:39 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:39 --> Router Class Initialized
INFO - 2025-04-15 06:59:39 --> Output Class Initialized
INFO - 2025-04-15 06:59:39 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:39 --> Input Class Initialized
INFO - 2025-04-15 06:59:39 --> Language Class Initialized
INFO - 2025-04-15 06:59:39 --> Language Class Initialized
INFO - 2025-04-15 06:59:39 --> Config Class Initialized
INFO - 2025-04-15 06:59:39 --> Loader Class Initialized
INFO - 2025-04-15 06:59:39 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:39 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:39 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:39 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:39 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:39 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:39 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:39 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:39 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:39 --> Email Class Initialized
INFO - 2025-04-15 06:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:39 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:39 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:39 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:39 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:39 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:39 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:39 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:39 --> Model Class Initialized
INFO - 2025-04-15 12:59:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-04-15 12:59:39 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 677
DEBUG - 2025-04-15 12:59:39 --> 📥 acc_transaction insert: {"vid":"188","fyear":"1","VNo":"CV-57","Vtype":"CV","referenceNo":"1098","VDate":"2025-04-15","COAID":"1020101","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"250.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"3010301","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 12:59:39"}
DEBUG - 2025-04-15 12:59:39 --> 📥 acc_transaction insert: {"vid":"188","fyear":"1","VNo":"CV-57","Vtype":"CV","referenceNo":"1098","VDate":"2025-04-15","COAID":"3010301","Narration":"Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales Voucher for customer","Debit":"0.00","Credit":"250.00","StoreID":0,"IsPosted":1,"RevCodde":"1020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 12:59:39"}
DEBUG - 2025-04-15 12:59:39 --> 📥 acc_transaction insert: {"vid":"189","fyear":"1","VNo":"JV-81","Vtype":"JV","referenceNo":"1098","VDate":"2025-04-15","COAID":"4010101","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"200.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"1020401","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 12:59:39"}
DEBUG - 2025-04-15 12:59:39 --> 📥 acc_transaction insert: {"vid":"189","fyear":"1","VNo":"JV-81","Vtype":"JV","referenceNo":"1098","VDate":"2025-04-15","COAID":"1020401","Narration":"Sales cost of goods Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Sales cost of goods Voucher for customer","Debit":"0.00","Credit":"200.00","StoreID":0,"IsPosted":1,"RevCodde":"4010101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 12:59:39"}
DEBUG - 2025-04-15 12:59:39 --> 📥 acc_transaction insert: {"vid":"190","fyear":"1","VNo":"JV-82","Vtype":"JV","referenceNo":"1098","VDate":"2025-04-15","COAID":"4021101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"5020101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 12:59:39"}
DEBUG - 2025-04-15 12:59:39 --> 📥 acc_transaction insert: {"vid":"190","fyear":"1","VNo":"JV-82","Vtype":"JV","referenceNo":"1098","VDate":"2025-04-15","COAID":"5020101","Narration":"Tax for Sales Voucher","chequeNo":"","chequeDate":null,"isHonour":"0","ledgerComment":"Tax for Sales Voucher for customer","Debit":"0.00","Credit":"0.00","StoreID":0,"IsPosted":1,"RevCodde":"4021101","subType":"1","subCode":null,"IsAppove":1,"CreateBy":"1","CreateDate":"2025-04-15 12:59:39"}
DEBUG - 2025-04-15 12:59:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/pos_print.php
INFO - 2025-04-15 12:59:39 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:39 --> Total execution time: 0.1408
INFO - 2025-04-15 06:59:41 --> Config Class Initialized
INFO - 2025-04-15 06:59:41 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:41 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:41 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:41 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:41 --> Router Class Initialized
INFO - 2025-04-15 06:59:41 --> Output Class Initialized
INFO - 2025-04-15 06:59:41 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:41 --> Input Class Initialized
INFO - 2025-04-15 06:59:41 --> Language Class Initialized
INFO - 2025-04-15 06:59:41 --> Language Class Initialized
INFO - 2025-04-15 06:59:41 --> Config Class Initialized
INFO - 2025-04-15 06:59:41 --> Loader Class Initialized
INFO - 2025-04-15 06:59:41 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:41 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:41 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:41 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:41 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:41 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:41 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:41 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:41 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:41 --> Email Class Initialized
INFO - 2025-04-15 06:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:41 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:41 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:41 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:41 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:41 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:41 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:41 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:41 --> Model Class Initialized
ERROR - 2025-04-15 12:59:41 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 12:59:41 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-04-15 12:59:41 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-04-15 12:59:41 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 12:59:41 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 12:59:41 --> Model Class Initialized
ERROR - 2025-04-15 12:59:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 12:59:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 12:59:41 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 90
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 12:59:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 12:59:41 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:41 --> Total execution time: 0.1157
INFO - 2025-04-15 06:59:45 --> Config Class Initialized
INFO - 2025-04-15 06:59:45 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:45 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:45 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:45 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:45 --> Router Class Initialized
INFO - 2025-04-15 06:59:45 --> Output Class Initialized
INFO - 2025-04-15 06:59:45 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:45 --> Input Class Initialized
INFO - 2025-04-15 06:59:45 --> Language Class Initialized
INFO - 2025-04-15 06:59:45 --> Language Class Initialized
INFO - 2025-04-15 06:59:45 --> Config Class Initialized
INFO - 2025-04-15 06:59:45 --> Loader Class Initialized
INFO - 2025-04-15 06:59:45 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:45 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:45 --> Email Class Initialized
INFO - 2025-04-15 06:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:45 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:45 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:45 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:45 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 12:59:45 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
ERROR - 2025-04-15 12:59:45 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 12:59:45 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 12:59:45 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:45 --> Total execution time: 0.1070
INFO - 2025-04-15 06:59:45 --> Config Class Initialized
INFO - 2025-04-15 06:59:45 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:45 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:45 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:45 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 06:59:45 --> Router Class Initialized
INFO - 2025-04-15 06:59:45 --> Output Class Initialized
INFO - 2025-04-15 06:59:45 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:45 --> Input Class Initialized
INFO - 2025-04-15 06:59:45 --> Language Class Initialized
INFO - 2025-04-15 06:59:45 --> Language Class Initialized
INFO - 2025-04-15 06:59:45 --> Config Class Initialized
INFO - 2025-04-15 06:59:45 --> Loader Class Initialized
INFO - 2025-04-15 06:59:45 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:45 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:45 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:45 --> Email Class Initialized
INFO - 2025-04-15 06:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:45 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:45 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:45 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:45 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
DEBUG - 2025-04-15 12:59:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 12:59:45 --> Model Class Initialized
INFO - 2025-04-15 12:59:45 --> Final output sent to browser
DEBUG - 2025-04-15 12:59:45 --> Total execution time: 0.0314
INFO - 2025-04-15 06:59:57 --> Config Class Initialized
INFO - 2025-04-15 06:59:57 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:57 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:57 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:57 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-15 06:59:57 --> Router Class Initialized
INFO - 2025-04-15 06:59:57 --> Output Class Initialized
INFO - 2025-04-15 06:59:57 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:57 --> Input Class Initialized
INFO - 2025-04-15 06:59:57 --> Language Class Initialized
INFO - 2025-04-15 06:59:57 --> Language Class Initialized
INFO - 2025-04-15 06:59:57 --> Config Class Initialized
INFO - 2025-04-15 06:59:57 --> Loader Class Initialized
INFO - 2025-04-15 06:59:57 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:57 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:57 --> Email Class Initialized
INFO - 2025-04-15 06:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:57 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:57 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:57 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:57 --> Report MX_Controller Initialized
INFO - 2025-04-15 06:59:57 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-15 06:59:57 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 06:59:57 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 06:59:57 --> Model Class Initialized
ERROR - 2025-04-15 06:59:57 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 06:59:57 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 06:59:57 --> Final output sent to browser
DEBUG - 2025-04-15 06:59:57 --> Total execution time: 0.1304
INFO - 2025-04-15 06:59:57 --> Config Class Initialized
INFO - 2025-04-15 06:59:57 --> Hooks Class Initialized
DEBUG - 2025-04-15 06:59:57 --> UTF-8 Support Enabled
INFO - 2025-04-15 06:59:57 --> Utf8 Class Initialized
INFO - 2025-04-15 06:59:57 --> URI Class Initialized
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-15 06:59:57 --> Router Class Initialized
INFO - 2025-04-15 06:59:57 --> Output Class Initialized
INFO - 2025-04-15 06:59:57 --> Security Class Initialized
DEBUG - 2025-04-15 06:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 06:59:57 --> Input Class Initialized
INFO - 2025-04-15 06:59:57 --> Language Class Initialized
INFO - 2025-04-15 06:59:57 --> Language Class Initialized
INFO - 2025-04-15 06:59:57 --> Config Class Initialized
INFO - 2025-04-15 06:59:57 --> Loader Class Initialized
INFO - 2025-04-15 06:59:57 --> Helper loaded: url_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: file_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: html_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: form_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: text_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: lang_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: directory_helper
INFO - 2025-04-15 06:59:57 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 06:59:57 --> Database Driver Class Initialized
INFO - 2025-04-15 06:59:57 --> Email Class Initialized
INFO - 2025-04-15 06:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 06:59:57 --> Form Validation Class Initialized
INFO - 2025-04-15 06:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 06:59:57 --> Pagination Class Initialized
INFO - 2025-04-15 06:59:57 --> Controller Class Initialized
DEBUG - 2025-04-15 06:59:57 --> Report MX_Controller Initialized
INFO - 2025-04-15 06:59:57 --> Model Class Initialized
DEBUG - 2025-04-15 06:59:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-15 06:59:57 --> Model Class Initialized
INFO - 2025-04-15 06:59:57 --> Final output sent to browser
DEBUG - 2025-04-15 06:59:57 --> Total execution time: 0.0188
INFO - 2025-04-15 07:00:09 --> Config Class Initialized
INFO - 2025-04-15 07:00:09 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:09 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:09 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:09 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:09 --> Router Class Initialized
INFO - 2025-04-15 07:00:09 --> Output Class Initialized
INFO - 2025-04-15 07:00:09 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:09 --> Input Class Initialized
INFO - 2025-04-15 07:00:09 --> Language Class Initialized
INFO - 2025-04-15 07:00:09 --> Language Class Initialized
INFO - 2025-04-15 07:00:09 --> Config Class Initialized
INFO - 2025-04-15 07:00:09 --> Loader Class Initialized
INFO - 2025-04-15 07:00:09 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:09 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:09 --> Email Class Initialized
INFO - 2025-04-15 07:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:09 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:09 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:09 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:09 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 13:00:09 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
ERROR - 2025-04-15 13:00:09 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 13:00:09 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice.php
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 13:00:09 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:09 --> Total execution time: 0.1540
INFO - 2025-04-15 07:00:09 --> Config Class Initialized
INFO - 2025-04-15 07:00:09 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:09 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:09 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:09 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:09 --> Router Class Initialized
INFO - 2025-04-15 07:00:09 --> Output Class Initialized
INFO - 2025-04-15 07:00:09 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:09 --> Input Class Initialized
INFO - 2025-04-15 07:00:09 --> Language Class Initialized
INFO - 2025-04-15 07:00:09 --> Language Class Initialized
INFO - 2025-04-15 07:00:09 --> Config Class Initialized
INFO - 2025-04-15 07:00:09 --> Loader Class Initialized
INFO - 2025-04-15 07:00:09 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:09 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:09 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:09 --> Email Class Initialized
INFO - 2025-04-15 07:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:09 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:09 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:09 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:09 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:09 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:09 --> Model Class Initialized
INFO - 2025-04-15 13:00:09 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:09 --> Total execution time: 0.0684
INFO - 2025-04-15 07:00:11 --> Config Class Initialized
INFO - 2025-04-15 07:00:11 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:11 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:11 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:11 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:11 --> Router Class Initialized
INFO - 2025-04-15 07:00:11 --> Output Class Initialized
INFO - 2025-04-15 07:00:11 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:11 --> Input Class Initialized
INFO - 2025-04-15 07:00:11 --> Language Class Initialized
INFO - 2025-04-15 07:00:11 --> Language Class Initialized
INFO - 2025-04-15 07:00:11 --> Config Class Initialized
INFO - 2025-04-15 07:00:11 --> Loader Class Initialized
INFO - 2025-04-15 07:00:11 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:11 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:11 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:11 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:11 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:11 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:11 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:11 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:11 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:11 --> Email Class Initialized
INFO - 2025-04-15 07:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:11 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:11 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:11 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:11 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:11 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:11 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:11 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:11 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 13:00:11 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 13:00:11 --> Model Class Initialized
ERROR - 2025-04-15 13:00:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 13:00:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html.php
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 13:00:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 13:00:11 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:11 --> Total execution time: 0.1651
INFO - 2025-04-15 07:00:19 --> Config Class Initialized
INFO - 2025-04-15 07:00:19 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:19 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:19 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:19 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-15 07:00:19 --> Router Class Initialized
INFO - 2025-04-15 07:00:19 --> Output Class Initialized
INFO - 2025-04-15 07:00:19 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:19 --> Input Class Initialized
INFO - 2025-04-15 07:00:19 --> Language Class Initialized
INFO - 2025-04-15 07:00:19 --> Language Class Initialized
INFO - 2025-04-15 07:00:19 --> Config Class Initialized
INFO - 2025-04-15 07:00:19 --> Loader Class Initialized
INFO - 2025-04-15 07:00:19 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:19 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:19 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:19 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:19 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:19 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:19 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:19 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:19 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:19 --> Email Class Initialized
INFO - 2025-04-15 07:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:19 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:19 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:19 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:19 --> Returns MX_Controller Initialized
INFO - 2025-04-15 07:00:19 --> Model Class Initialized
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-15 07:00:19 --> Model Class Initialized
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 07:00:19 --> Model Class Initialized
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 07:00:19 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 07:00:19 --> Model Class Initialized
ERROR - 2025-04-15 07:00:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 07:00:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 07:00:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 07:00:19 --> Final output sent to browser
DEBUG - 2025-04-15 07:00:19 --> Total execution time: 0.1412
INFO - 2025-04-15 07:00:24 --> Config Class Initialized
INFO - 2025-04-15 07:00:24 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:24 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:24 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:24 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-15 07:00:24 --> Router Class Initialized
INFO - 2025-04-15 07:00:24 --> Output Class Initialized
INFO - 2025-04-15 07:00:24 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:24 --> Input Class Initialized
INFO - 2025-04-15 07:00:24 --> Language Class Initialized
INFO - 2025-04-15 07:00:24 --> Language Class Initialized
INFO - 2025-04-15 07:00:24 --> Config Class Initialized
INFO - 2025-04-15 07:00:24 --> Loader Class Initialized
INFO - 2025-04-15 07:00:24 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:24 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:24 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:24 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:24 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:24 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:24 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:24 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:24 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:24 --> Email Class Initialized
INFO - 2025-04-15 07:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:24 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:24 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:24 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:24 --> Returns MX_Controller Initialized
INFO - 2025-04-15 07:00:24 --> Model Class Initialized
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-15 07:00:24 --> Model Class Initialized
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 07:00:24 --> Model Class Initialized
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 07:00:24 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 07:00:24 --> Model Class Initialized
ERROR - 2025-04-15 07:00:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 07:00:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_form.php
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 07:00:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 07:00:24 --> Final output sent to browser
DEBUG - 2025-04-15 07:00:24 --> Total execution time: 0.1720
INFO - 2025-04-15 07:00:43 --> Config Class Initialized
INFO - 2025-04-15 07:00:43 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:43 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:43 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:43 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:43 --> Router Class Initialized
INFO - 2025-04-15 07:00:43 --> Output Class Initialized
INFO - 2025-04-15 07:00:43 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:43 --> Input Class Initialized
INFO - 2025-04-15 07:00:43 --> Language Class Initialized
INFO - 2025-04-15 07:00:43 --> Language Class Initialized
INFO - 2025-04-15 07:00:43 --> Config Class Initialized
INFO - 2025-04-15 07:00:43 --> Loader Class Initialized
INFO - 2025-04-15 07:00:43 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:43 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:43 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:43 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:43 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:43 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:43 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:43 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:43 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:43 --> Email Class Initialized
INFO - 2025-04-15 07:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:43 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:43 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:43 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:43 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:43 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:43 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:43 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:43 --> Model Class Initialized
INFO - 2025-04-15 13:00:43 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:43 --> Total execution time: 0.0053
INFO - 2025-04-15 07:00:46 --> Config Class Initialized
INFO - 2025-04-15 07:00:46 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:46 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:46 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:46 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:46 --> Router Class Initialized
INFO - 2025-04-15 07:00:46 --> Output Class Initialized
INFO - 2025-04-15 07:00:46 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:46 --> Input Class Initialized
INFO - 2025-04-15 07:00:46 --> Language Class Initialized
INFO - 2025-04-15 07:00:46 --> Language Class Initialized
INFO - 2025-04-15 07:00:46 --> Config Class Initialized
INFO - 2025-04-15 07:00:46 --> Loader Class Initialized
INFO - 2025-04-15 07:00:46 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:46 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:46 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:46 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:46 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:46 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:46 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:46 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:46 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:46 --> Email Class Initialized
INFO - 2025-04-15 07:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:46 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:46 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:46 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:46 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:46 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:46 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:46 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:46 --> Model Class Initialized
INFO - 2025-04-15 13:00:46 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:46 --> Total execution time: 0.0061
INFO - 2025-04-15 07:00:47 --> Config Class Initialized
INFO - 2025-04-15 07:00:47 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:47 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:47 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:47 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:47 --> Router Class Initialized
INFO - 2025-04-15 07:00:47 --> Output Class Initialized
INFO - 2025-04-15 07:00:47 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:47 --> Input Class Initialized
INFO - 2025-04-15 07:00:47 --> Language Class Initialized
INFO - 2025-04-15 07:00:47 --> Language Class Initialized
INFO - 2025-04-15 07:00:47 --> Config Class Initialized
INFO - 2025-04-15 07:00:47 --> Loader Class Initialized
INFO - 2025-04-15 07:00:47 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:47 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:47 --> Email Class Initialized
INFO - 2025-04-15 07:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:47 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:47 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:47 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
INFO - 2025-04-15 13:00:47 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:47 --> Total execution time: 0.0131
INFO - 2025-04-15 07:00:47 --> Config Class Initialized
INFO - 2025-04-15 07:00:47 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:47 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:47 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:47 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:47 --> Router Class Initialized
INFO - 2025-04-15 07:00:47 --> Output Class Initialized
INFO - 2025-04-15 07:00:47 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:47 --> Input Class Initialized
INFO - 2025-04-15 07:00:47 --> Language Class Initialized
INFO - 2025-04-15 07:00:47 --> Language Class Initialized
INFO - 2025-04-15 07:00:47 --> Config Class Initialized
INFO - 2025-04-15 07:00:47 --> Loader Class Initialized
INFO - 2025-04-15 07:00:47 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:47 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:47 --> Email Class Initialized
INFO - 2025-04-15 07:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:47 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:47 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:47 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:47 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:47 --> Model Class Initialized
INFO - 2025-04-15 13:00:47 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:47 --> Total execution time: 0.0115
INFO - 2025-04-15 07:00:50 --> Config Class Initialized
INFO - 2025-04-15 07:00:50 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:50 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:50 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:50 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:50 --> Router Class Initialized
INFO - 2025-04-15 07:00:50 --> Output Class Initialized
INFO - 2025-04-15 07:00:50 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:50 --> Input Class Initialized
INFO - 2025-04-15 07:00:50 --> Language Class Initialized
INFO - 2025-04-15 07:00:50 --> Language Class Initialized
INFO - 2025-04-15 07:00:50 --> Config Class Initialized
INFO - 2025-04-15 07:00:50 --> Loader Class Initialized
INFO - 2025-04-15 07:00:50 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:50 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:50 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:50 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:50 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:50 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:50 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:50 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:50 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:50 --> Email Class Initialized
INFO - 2025-04-15 07:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:50 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:50 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:50 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:50 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:50 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:50 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:50 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:50 --> Model Class Initialized
INFO - 2025-04-15 13:00:50 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:50 --> Total execution time: 0.0167
INFO - 2025-04-15 07:00:53 --> Config Class Initialized
INFO - 2025-04-15 07:00:53 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:00:53 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:00:53 --> Utf8 Class Initialized
INFO - 2025-04-15 07:00:53 --> URI Class Initialized
DEBUG - 2025-04-15 07:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-04-15 07:00:53 --> Router Class Initialized
INFO - 2025-04-15 07:00:53 --> Output Class Initialized
INFO - 2025-04-15 07:00:53 --> Security Class Initialized
DEBUG - 2025-04-15 07:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:00:53 --> Input Class Initialized
INFO - 2025-04-15 07:00:53 --> Language Class Initialized
INFO - 2025-04-15 07:00:53 --> Language Class Initialized
INFO - 2025-04-15 07:00:53 --> Config Class Initialized
INFO - 2025-04-15 07:00:53 --> Loader Class Initialized
INFO - 2025-04-15 07:00:53 --> Helper loaded: url_helper
INFO - 2025-04-15 07:00:53 --> Helper loaded: file_helper
INFO - 2025-04-15 07:00:53 --> Helper loaded: html_helper
INFO - 2025-04-15 07:00:53 --> Helper loaded: form_helper
INFO - 2025-04-15 07:00:53 --> Helper loaded: text_helper
INFO - 2025-04-15 07:00:53 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:00:53 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:00:53 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:00:53 --> Database Driver Class Initialized
INFO - 2025-04-15 07:00:53 --> Email Class Initialized
INFO - 2025-04-15 07:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:00:53 --> Form Validation Class Initialized
INFO - 2025-04-15 07:00:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:00:53 --> Pagination Class Initialized
INFO - 2025-04-15 07:00:53 --> Controller Class Initialized
DEBUG - 2025-04-15 07:00:53 --> Invoice MX_Controller Initialized
INFO - 2025-04-15 13:00:53 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-04-15 13:00:53 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-04-15 13:00:53 --> Model Class Initialized
DEBUG - 2025-04-15 13:00:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 13:00:53 --> Model Class Initialized
INFO - 2025-04-15 13:00:53 --> Final output sent to browser
DEBUG - 2025-04-15 13:00:53 --> Total execution time: 0.0066
INFO - 2025-04-15 07:01:20 --> Config Class Initialized
INFO - 2025-04-15 07:01:20 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:01:20 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:01:20 --> Utf8 Class Initialized
INFO - 2025-04-15 07:01:20 --> URI Class Initialized
DEBUG - 2025-04-15 07:01:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-15 07:01:20 --> Router Class Initialized
INFO - 2025-04-15 07:01:20 --> Output Class Initialized
INFO - 2025-04-15 07:01:20 --> Security Class Initialized
DEBUG - 2025-04-15 07:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:01:20 --> Input Class Initialized
INFO - 2025-04-15 07:01:20 --> Language Class Initialized
INFO - 2025-04-15 07:01:20 --> Language Class Initialized
INFO - 2025-04-15 07:01:20 --> Config Class Initialized
INFO - 2025-04-15 07:01:20 --> Loader Class Initialized
INFO - 2025-04-15 07:01:20 --> Helper loaded: url_helper
INFO - 2025-04-15 07:01:20 --> Helper loaded: file_helper
INFO - 2025-04-15 07:01:20 --> Helper loaded: html_helper
INFO - 2025-04-15 07:01:20 --> Helper loaded: form_helper
INFO - 2025-04-15 07:01:20 --> Helper loaded: text_helper
INFO - 2025-04-15 07:01:20 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:01:20 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:01:20 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:01:20 --> Database Driver Class Initialized
INFO - 2025-04-15 07:01:20 --> Email Class Initialized
INFO - 2025-04-15 07:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:01:20 --> Form Validation Class Initialized
INFO - 2025-04-15 07:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:01:20 --> Pagination Class Initialized
INFO - 2025-04-15 07:01:20 --> Controller Class Initialized
DEBUG - 2025-04-15 07:01:20 --> Returns MX_Controller Initialized
INFO - 2025-04-15 07:01:20 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-15 07:01:20 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 07:01:20 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:20 --> 🔁 return_invoice() called | finyear: 1
DEBUG - 2025-04-15 07:01:20 --> ✅ Proceeding with return_invoice_entry()
ERROR - 2025-04-15 07:01:20 --> Severity: error --> Exception: Unknown column 'quantity' in 'field list' /Users/faiz.shiraji/Sites/GenITech_B2B/system/database/drivers/mysqli/mysqli_driver.php 317
INFO - 2025-04-15 07:01:23 --> Config Class Initialized
INFO - 2025-04-15 07:01:23 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:01:23 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:01:23 --> Utf8 Class Initialized
INFO - 2025-04-15 07:01:23 --> URI Class Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-15 07:01:23 --> Router Class Initialized
INFO - 2025-04-15 07:01:23 --> Output Class Initialized
INFO - 2025-04-15 07:01:23 --> Security Class Initialized
DEBUG - 2025-04-15 07:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:01:23 --> Input Class Initialized
INFO - 2025-04-15 07:01:23 --> Language Class Initialized
INFO - 2025-04-15 07:01:23 --> Language Class Initialized
INFO - 2025-04-15 07:01:23 --> Config Class Initialized
INFO - 2025-04-15 07:01:23 --> Loader Class Initialized
INFO - 2025-04-15 07:01:23 --> Helper loaded: url_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: file_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: html_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: form_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: text_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:01:23 --> Database Driver Class Initialized
INFO - 2025-04-15 07:01:23 --> Email Class Initialized
INFO - 2025-04-15 07:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:01:23 --> Form Validation Class Initialized
INFO - 2025-04-15 07:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:01:23 --> Pagination Class Initialized
INFO - 2025-04-15 07:01:23 --> Controller Class Initialized
DEBUG - 2025-04-15 07:01:23 --> Returns MX_Controller Initialized
INFO - 2025-04-15 07:01:23 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-15 07:01:23 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 07:01:23 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:23 --> 🔁 return_invoice() called | finyear: 
ERROR - 2025-04-15 07:01:23 --> ❌ Financial year missing or invalid.
INFO - 2025-04-15 07:01:23 --> Config Class Initialized
INFO - 2025-04-15 07:01:23 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:01:23 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:01:23 --> Utf8 Class Initialized
INFO - 2025-04-15 07:01:23 --> URI Class Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-15 07:01:23 --> Router Class Initialized
INFO - 2025-04-15 07:01:23 --> Output Class Initialized
INFO - 2025-04-15 07:01:23 --> Security Class Initialized
DEBUG - 2025-04-15 07:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:01:23 --> Input Class Initialized
INFO - 2025-04-15 07:01:23 --> Language Class Initialized
INFO - 2025-04-15 07:01:23 --> Language Class Initialized
INFO - 2025-04-15 07:01:23 --> Config Class Initialized
INFO - 2025-04-15 07:01:23 --> Loader Class Initialized
INFO - 2025-04-15 07:01:23 --> Helper loaded: url_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: file_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: html_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: form_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: text_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:01:23 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:01:23 --> Database Driver Class Initialized
INFO - 2025-04-15 07:01:23 --> Email Class Initialized
INFO - 2025-04-15 07:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:01:23 --> Form Validation Class Initialized
INFO - 2025-04-15 07:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:01:23 --> Pagination Class Initialized
INFO - 2025-04-15 07:01:23 --> Controller Class Initialized
DEBUG - 2025-04-15 07:01:23 --> Returns MX_Controller Initialized
INFO - 2025-04-15 07:01:23 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-15 07:01:23 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 07:01:23 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 07:01:23 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 07:01:23 --> Model Class Initialized
ERROR - 2025-04-15 07:01:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 07:01:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/form.php
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 07:01:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 07:01:23 --> Final output sent to browser
DEBUG - 2025-04-15 07:01:23 --> Total execution time: 0.1426
INFO - 2025-04-15 07:01:28 --> Config Class Initialized
INFO - 2025-04-15 07:01:28 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:01:28 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:01:28 --> Utf8 Class Initialized
INFO - 2025-04-15 07:01:28 --> URI Class Initialized
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-15 07:01:28 --> Router Class Initialized
INFO - 2025-04-15 07:01:28 --> Output Class Initialized
INFO - 2025-04-15 07:01:28 --> Security Class Initialized
DEBUG - 2025-04-15 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:01:28 --> Input Class Initialized
INFO - 2025-04-15 07:01:28 --> Language Class Initialized
INFO - 2025-04-15 07:01:28 --> Language Class Initialized
INFO - 2025-04-15 07:01:28 --> Config Class Initialized
INFO - 2025-04-15 07:01:28 --> Loader Class Initialized
INFO - 2025-04-15 07:01:28 --> Helper loaded: url_helper
INFO - 2025-04-15 07:01:28 --> Helper loaded: file_helper
INFO - 2025-04-15 07:01:28 --> Helper loaded: html_helper
INFO - 2025-04-15 07:01:28 --> Helper loaded: form_helper
INFO - 2025-04-15 07:01:28 --> Helper loaded: text_helper
INFO - 2025-04-15 07:01:28 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:01:28 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:01:28 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:01:28 --> Database Driver Class Initialized
INFO - 2025-04-15 07:01:28 --> Email Class Initialized
INFO - 2025-04-15 07:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:01:28 --> Form Validation Class Initialized
INFO - 2025-04-15 07:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:01:28 --> Pagination Class Initialized
INFO - 2025-04-15 07:01:28 --> Controller Class Initialized
DEBUG - 2025-04-15 07:01:28 --> Returns MX_Controller Initialized
INFO - 2025-04-15 07:01:28 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-15 07:01:28 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 07:01:28 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 07:01:28 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 07:01:28 --> Model Class Initialized
ERROR - 2025-04-15 07:01:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 07:01:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/invoice_return_list.php
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 07:01:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 07:01:28 --> Final output sent to browser
DEBUG - 2025-04-15 07:01:28 --> Total execution time: 0.1164
INFO - 2025-04-15 07:01:36 --> Config Class Initialized
INFO - 2025-04-15 07:01:36 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:01:36 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:01:36 --> Utf8 Class Initialized
INFO - 2025-04-15 07:01:36 --> URI Class Initialized
DEBUG - 2025-04-15 07:01:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/config/routes.php
INFO - 2025-04-15 07:01:36 --> Router Class Initialized
INFO - 2025-04-15 07:01:36 --> Output Class Initialized
INFO - 2025-04-15 07:01:36 --> Security Class Initialized
DEBUG - 2025-04-15 07:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:01:36 --> Input Class Initialized
INFO - 2025-04-15 07:01:36 --> Language Class Initialized
INFO - 2025-04-15 07:01:36 --> Language Class Initialized
INFO - 2025-04-15 07:01:36 --> Config Class Initialized
INFO - 2025-04-15 07:01:36 --> Loader Class Initialized
INFO - 2025-04-15 07:01:36 --> Helper loaded: url_helper
INFO - 2025-04-15 07:01:36 --> Helper loaded: file_helper
INFO - 2025-04-15 07:01:36 --> Helper loaded: html_helper
INFO - 2025-04-15 07:01:36 --> Helper loaded: form_helper
INFO - 2025-04-15 07:01:36 --> Helper loaded: text_helper
INFO - 2025-04-15 07:01:36 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:01:36 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:01:36 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:01:36 --> Database Driver Class Initialized
INFO - 2025-04-15 07:01:36 --> Email Class Initialized
INFO - 2025-04-15 07:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:01:36 --> Form Validation Class Initialized
INFO - 2025-04-15 07:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:01:36 --> Pagination Class Initialized
INFO - 2025-04-15 07:01:36 --> Controller Class Initialized
DEBUG - 2025-04-15 07:01:36 --> Returns MX_Controller Initialized
INFO - 2025-04-15 07:01:36 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/models/Return_model.php
INFO - 2025-04-15 07:01:36 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-04-15 07:01:36 --> Model Class Initialized
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 213
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 215
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 216
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 220
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 221
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 222
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 223
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 224
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 225
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 229
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 230
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 232
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 233
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 234
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 236
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Attempt to read property "first_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Attempt to read property "last_name" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 241
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/controllers/Returns.php 246
DEBUG - 2025-04-15 07:01:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 07:01:36 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 07:01:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 07:01:36 --> Model Class Initialized
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 07:01:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 07:01:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 07:01:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 07:01:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 07:01:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-04-15 07:01:37 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-15 07:01:37 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 48
ERROR - 2025-04-15 07:01:37 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 119
ERROR - 2025-04-15 07:01:37 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-15 07:01:37 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 210
ERROR - 2025-04-15 07:01:37 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
ERROR - 2025-04-15 07:01:37 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php 217
DEBUG - 2025-04-15 07:01:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/return/views/pos_print.php
DEBUG - 2025-04-15 07:01:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 07:01:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 07:01:37 --> Final output sent to browser
DEBUG - 2025-04-15 07:01:37 --> Total execution time: 0.1374
INFO - 2025-04-15 07:01:47 --> Config Class Initialized
INFO - 2025-04-15 07:01:47 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:01:47 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:01:47 --> Utf8 Class Initialized
INFO - 2025-04-15 07:01:47 --> URI Class Initialized
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-15 07:01:47 --> Router Class Initialized
INFO - 2025-04-15 07:01:47 --> Output Class Initialized
INFO - 2025-04-15 07:01:47 --> Security Class Initialized
DEBUG - 2025-04-15 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:01:47 --> Input Class Initialized
INFO - 2025-04-15 07:01:47 --> Language Class Initialized
INFO - 2025-04-15 07:01:47 --> Language Class Initialized
INFO - 2025-04-15 07:01:47 --> Config Class Initialized
INFO - 2025-04-15 07:01:47 --> Loader Class Initialized
INFO - 2025-04-15 07:01:47 --> Helper loaded: url_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: file_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: html_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: form_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: text_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:01:47 --> Database Driver Class Initialized
INFO - 2025-04-15 07:01:47 --> Email Class Initialized
INFO - 2025-04-15 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:01:47 --> Form Validation Class Initialized
INFO - 2025-04-15 07:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:01:47 --> Pagination Class Initialized
INFO - 2025-04-15 07:01:47 --> Controller Class Initialized
DEBUG - 2025-04-15 07:01:47 --> Report MX_Controller Initialized
INFO - 2025-04-15 07:01:47 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-15 07:01:47 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 07:01:47 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 07:01:47 --> Model Class Initialized
ERROR - 2025-04-15 07:01:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 07:01:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/stock_report.php
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 07:01:47 --> Final output sent to browser
DEBUG - 2025-04-15 07:01:47 --> Total execution time: 0.1967
INFO - 2025-04-15 07:01:47 --> Config Class Initialized
INFO - 2025-04-15 07:01:47 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:01:47 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:01:47 --> Utf8 Class Initialized
INFO - 2025-04-15 07:01:47 --> URI Class Initialized
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-04-15 07:01:47 --> Router Class Initialized
INFO - 2025-04-15 07:01:47 --> Output Class Initialized
INFO - 2025-04-15 07:01:47 --> Security Class Initialized
DEBUG - 2025-04-15 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:01:47 --> Input Class Initialized
INFO - 2025-04-15 07:01:47 --> Language Class Initialized
INFO - 2025-04-15 07:01:47 --> Language Class Initialized
INFO - 2025-04-15 07:01:47 --> Config Class Initialized
INFO - 2025-04-15 07:01:47 --> Loader Class Initialized
INFO - 2025-04-15 07:01:47 --> Helper loaded: url_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: file_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: html_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: form_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: text_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:01:47 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:01:47 --> Database Driver Class Initialized
INFO - 2025-04-15 07:01:47 --> Email Class Initialized
INFO - 2025-04-15 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:01:47 --> Form Validation Class Initialized
INFO - 2025-04-15 07:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:01:47 --> Pagination Class Initialized
INFO - 2025-04-15 07:01:47 --> Controller Class Initialized
DEBUG - 2025-04-15 07:01:47 --> Report MX_Controller Initialized
INFO - 2025-04-15 07:01:47 --> Model Class Initialized
DEBUG - 2025-04-15 07:01:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-04-15 07:01:47 --> Model Class Initialized
INFO - 2025-04-15 07:01:47 --> Final output sent to browser
DEBUG - 2025-04-15 07:01:47 --> Total execution time: 0.0097
INFO - 2025-04-15 07:02:08 --> Config Class Initialized
INFO - 2025-04-15 07:02:08 --> Hooks Class Initialized
DEBUG - 2025-04-15 07:02:08 --> UTF-8 Support Enabled
INFO - 2025-04-15 07:02:08 --> Utf8 Class Initialized
INFO - 2025-04-15 07:02:08 --> URI Class Initialized
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-04-15 07:02:08 --> Router Class Initialized
INFO - 2025-04-15 07:02:08 --> Output Class Initialized
INFO - 2025-04-15 07:02:08 --> Security Class Initialized
DEBUG - 2025-04-15 07:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 07:02:08 --> Input Class Initialized
INFO - 2025-04-15 07:02:08 --> Language Class Initialized
INFO - 2025-04-15 07:02:08 --> Language Class Initialized
INFO - 2025-04-15 07:02:08 --> Config Class Initialized
INFO - 2025-04-15 07:02:08 --> Loader Class Initialized
INFO - 2025-04-15 07:02:08 --> Helper loaded: url_helper
INFO - 2025-04-15 07:02:08 --> Helper loaded: file_helper
INFO - 2025-04-15 07:02:08 --> Helper loaded: html_helper
INFO - 2025-04-15 07:02:08 --> Helper loaded: form_helper
INFO - 2025-04-15 07:02:08 --> Helper loaded: text_helper
INFO - 2025-04-15 07:02:08 --> Helper loaded: lang_helper
INFO - 2025-04-15 07:02:08 --> Helper loaded: directory_helper
INFO - 2025-04-15 07:02:08 --> Helper loaded: dompdf_helper
INFO - 2025-04-15 07:02:08 --> Database Driver Class Initialized
INFO - 2025-04-15 07:02:08 --> Email Class Initialized
INFO - 2025-04-15 07:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-15 07:02:08 --> Form Validation Class Initialized
INFO - 2025-04-15 07:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-04-15 07:02:08 --> Pagination Class Initialized
INFO - 2025-04-15 07:02:08 --> Controller Class Initialized
DEBUG - 2025-04-15 07:02:08 --> Home MX_Controller Initialized
INFO - 2025-04-15 07:02:08 --> Model Class Initialized
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-04-15 07:02:08 --> Model Class Initialized
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-04-15 07:02:08 --> Template MX_Controller Initialized
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-04-15 07:02:08 --> Model Class Initialized
ERROR - 2025-04-15 07:02:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-04-15 07:02:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-04-15 07:02:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-04-15 07:02:08 --> Final output sent to browser
DEBUG - 2025-04-15 07:02:08 --> Total execution time: 0.1381
