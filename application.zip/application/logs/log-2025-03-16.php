<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-16 02:11:25 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:11:25 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:11:25 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:11:25 --> Model Class Initialized
ERROR - 2025-03-16 02:11:25 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-16 02:11:25 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-16 02:11:25 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-16 02:11:25 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 02:11:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 02:11:25 --> Model Class Initialized
ERROR - 2025-03-16 02:11:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 02:11:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-16 02:11:25 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 02:11:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 02:11:25 --> Final output sent to browser
DEBUG - 2025-03-16 02:11:25 --> Total execution time: 0.0974
INFO - 2025-03-16 02:11:29 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:11:29 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:11:29 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:11:29 --> Model Class Initialized
INFO - 2025-03-16 02:11:29 --> Final output sent to browser
DEBUG - 2025-03-16 02:11:29 --> Total execution time: 0.0116
INFO - 2025-03-16 02:11:30 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:11:30 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:11:30 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:11:30 --> Model Class Initialized
INFO - 2025-03-16 02:11:30 --> Final output sent to browser
DEBUG - 2025-03-16 02:11:30 --> Total execution time: 0.0087
INFO - 2025-03-16 02:11:35 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:11:35 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:11:35 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:35 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:11:35 --> Model Class Initialized
INFO - 2025-03-16 02:11:35 --> Final output sent to browser
DEBUG - 2025-03-16 02:11:35 --> Total execution time: 0.0108
INFO - 2025-03-16 02:11:36 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:11:36 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:11:36 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:11:36 --> Model Class Initialized
INFO - 2025-03-16 02:11:36 --> Final output sent to browser
DEBUG - 2025-03-16 02:11:36 --> Total execution time: 0.0191
INFO - 2025-03-16 02:11:39 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:11:39 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:11:39 --> Model Class Initialized
DEBUG - 2025-03-16 02:11:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:11:39 --> Model Class Initialized
INFO - 2025-03-16 02:11:39 --> Final output sent to browser
DEBUG - 2025-03-16 02:11:39 --> Total execution time: 0.0093
INFO - 2025-03-16 02:12:02 --> Model Class Initialized
DEBUG - 2025-03-16 02:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:12:02 --> Model Class Initialized
DEBUG - 2025-03-16 02:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:12:02 --> Model Class Initialized
DEBUG - 2025-03-16 02:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:12:02 --> Model Class Initialized
INFO - 2025-03-16 02:12:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-03-16 02:12:02 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 478
ERROR - 2025-03-16 02:12:02 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php 479
DEBUG - 2025-03-16 02:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/invoice_html_manual.php
INFO - 2025-03-16 02:12:02 --> Final output sent to browser
DEBUG - 2025-03-16 02:12:02 --> Total execution time: 0.0756
INFO - 2025-03-16 02:12:04 --> Model Class Initialized
DEBUG - 2025-03-16 02:12:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 02:12:04 --> Model Class Initialized
DEBUG - 2025-03-16 02:12:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 02:12:04 --> Model Class Initialized
DEBUG - 2025-03-16 02:12:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 02:12:04 --> Model Class Initialized
ERROR - 2025-03-16 02:12:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-16 02:12:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 32
ERROR - 2025-03-16 02:12:04 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
ERROR - 2025-03-16 02:12:04 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/controllers/Invoice.php 33
DEBUG - 2025-03-16 02:12:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 02:12:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 02:12:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 02:12:04 --> Model Class Initialized
ERROR - 2025-03-16 02:12:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 02:12:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 02:12:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 02:12:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 02:12:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 02:12:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-16 02:12:05 --> Severity: Warning --> foreach() argument must be of type array|object, false given /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php 86
DEBUG - 2025-03-16 02:12:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/add_invoice_form.php
DEBUG - 2025-03-16 02:12:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 02:12:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 02:12:05 --> Final output sent to browser
DEBUG - 2025-03-16 02:12:05 --> Total execution time: 0.1292
INFO - 2025-03-16 05:22:01 --> Config Class Initialized
INFO - 2025-03-16 05:22:01 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:22:01 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:22:01 --> Utf8 Class Initialized
INFO - 2025-03-16 05:22:01 --> URI Class Initialized
DEBUG - 2025-03-16 05:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-16 05:22:01 --> No URI present. Default controller set.
INFO - 2025-03-16 05:22:01 --> Router Class Initialized
INFO - 2025-03-16 05:22:01 --> Output Class Initialized
INFO - 2025-03-16 05:22:01 --> Security Class Initialized
DEBUG - 2025-03-16 05:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:22:01 --> Input Class Initialized
INFO - 2025-03-16 05:22:01 --> Language Class Initialized
INFO - 2025-03-16 05:22:01 --> Language Class Initialized
INFO - 2025-03-16 05:22:01 --> Config Class Initialized
INFO - 2025-03-16 05:22:01 --> Loader Class Initialized
INFO - 2025-03-16 05:22:01 --> Helper loaded: url_helper
INFO - 2025-03-16 05:22:01 --> Helper loaded: file_helper
INFO - 2025-03-16 05:22:01 --> Helper loaded: html_helper
INFO - 2025-03-16 05:22:01 --> Helper loaded: form_helper
INFO - 2025-03-16 05:22:01 --> Helper loaded: text_helper
INFO - 2025-03-16 05:22:01 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:22:01 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:22:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:22:01 --> Database Driver Class Initialized
INFO - 2025-03-16 05:22:01 --> Email Class Initialized
INFO - 2025-03-16 05:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:22:01 --> Form Validation Class Initialized
INFO - 2025-03-16 05:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:22:01 --> Pagination Class Initialized
INFO - 2025-03-16 05:22:01 --> Controller Class Initialized
DEBUG - 2025-03-16 05:22:01 --> Auth MX_Controller Initialized
INFO - 2025-03-16 05:22:01 --> Model Class Initialized
DEBUG - 2025-03-16 05:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 05:22:01 --> Model Class Initialized
DEBUG - 2025-03-16 05:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:22:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:22:01 --> Model Class Initialized
DEBUG - 2025-03-16 05:22:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-16 05:22:01 --> Final output sent to browser
DEBUG - 2025-03-16 05:22:01 --> Total execution time: 0.0436
INFO - 2025-03-16 05:22:11 --> Config Class Initialized
INFO - 2025-03-16 05:22:11 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:22:11 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:22:11 --> Utf8 Class Initialized
INFO - 2025-03-16 05:22:11 --> URI Class Initialized
DEBUG - 2025-03-16 05:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 05:22:11 --> Router Class Initialized
INFO - 2025-03-16 05:22:11 --> Output Class Initialized
INFO - 2025-03-16 05:22:11 --> Security Class Initialized
DEBUG - 2025-03-16 05:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:22:11 --> Input Class Initialized
INFO - 2025-03-16 05:22:11 --> Language Class Initialized
INFO - 2025-03-16 05:22:11 --> Language Class Initialized
INFO - 2025-03-16 05:22:11 --> Config Class Initialized
INFO - 2025-03-16 05:22:11 --> Loader Class Initialized
INFO - 2025-03-16 05:22:11 --> Helper loaded: url_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: file_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: html_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: form_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: text_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:22:11 --> Database Driver Class Initialized
INFO - 2025-03-16 05:22:11 --> Email Class Initialized
INFO - 2025-03-16 05:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:22:11 --> Form Validation Class Initialized
INFO - 2025-03-16 05:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:22:11 --> Pagination Class Initialized
INFO - 2025-03-16 05:22:11 --> Controller Class Initialized
DEBUG - 2025-03-16 05:22:11 --> Auth MX_Controller Initialized
INFO - 2025-03-16 05:22:11 --> Model Class Initialized
DEBUG - 2025-03-16 05:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 05:22:11 --> Model Class Initialized
INFO - 2025-03-16 05:22:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-16 05:22:11 --> Config Class Initialized
INFO - 2025-03-16 05:22:11 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:22:11 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:22:11 --> Utf8 Class Initialized
INFO - 2025-03-16 05:22:11 --> URI Class Initialized
DEBUG - 2025-03-16 05:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 05:22:11 --> Router Class Initialized
INFO - 2025-03-16 05:22:11 --> Output Class Initialized
INFO - 2025-03-16 05:22:11 --> Security Class Initialized
DEBUG - 2025-03-16 05:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:22:11 --> Input Class Initialized
INFO - 2025-03-16 05:22:11 --> Language Class Initialized
INFO - 2025-03-16 05:22:11 --> Language Class Initialized
INFO - 2025-03-16 05:22:11 --> Config Class Initialized
INFO - 2025-03-16 05:22:11 --> Loader Class Initialized
INFO - 2025-03-16 05:22:11 --> Helper loaded: url_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: file_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: html_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: form_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: text_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:22:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:22:11 --> Database Driver Class Initialized
INFO - 2025-03-16 05:22:11 --> Email Class Initialized
INFO - 2025-03-16 05:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:22:11 --> Form Validation Class Initialized
INFO - 2025-03-16 05:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:22:11 --> Pagination Class Initialized
INFO - 2025-03-16 05:22:11 --> Controller Class Initialized
DEBUG - 2025-03-16 05:22:11 --> Home MX_Controller Initialized
INFO - 2025-03-16 05:22:11 --> Model Class Initialized
DEBUG - 2025-03-16 05:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-16 05:22:11 --> Model Class Initialized
DEBUG - 2025-03-16 05:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:22:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:22:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:22:11 --> Model Class Initialized
ERROR - 2025-03-16 05:22:12 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:22:12 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:22:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:22:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:22:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:22:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:22:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-16 05:22:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:22:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:22:12 --> Final output sent to browser
DEBUG - 2025-03-16 05:22:12 --> Total execution time: 0.4318
INFO - 2025-03-16 05:23:23 --> Config Class Initialized
INFO - 2025-03-16 05:23:23 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:23:23 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:23:23 --> Utf8 Class Initialized
INFO - 2025-03-16 05:23:23 --> URI Class Initialized
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:23:23 --> Router Class Initialized
INFO - 2025-03-16 05:23:23 --> Output Class Initialized
INFO - 2025-03-16 05:23:23 --> Security Class Initialized
DEBUG - 2025-03-16 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:23:23 --> Input Class Initialized
INFO - 2025-03-16 05:23:23 --> Language Class Initialized
INFO - 2025-03-16 05:23:23 --> Language Class Initialized
INFO - 2025-03-16 05:23:23 --> Config Class Initialized
INFO - 2025-03-16 05:23:23 --> Loader Class Initialized
INFO - 2025-03-16 05:23:23 --> Helper loaded: url_helper
INFO - 2025-03-16 05:23:23 --> Helper loaded: file_helper
INFO - 2025-03-16 05:23:23 --> Helper loaded: html_helper
INFO - 2025-03-16 05:23:23 --> Helper loaded: form_helper
INFO - 2025-03-16 05:23:23 --> Helper loaded: text_helper
INFO - 2025-03-16 05:23:23 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:23:23 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:23:23 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:23:23 --> Database Driver Class Initialized
INFO - 2025-03-16 05:23:23 --> Email Class Initialized
INFO - 2025-03-16 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:23:23 --> Form Validation Class Initialized
INFO - 2025-03-16 05:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:23:23 --> Pagination Class Initialized
INFO - 2025-03-16 05:23:23 --> Controller Class Initialized
DEBUG - 2025-03-16 05:23:23 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:23:23 --> Model Class Initialized
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:23:23 --> Model Class Initialized
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:23:23 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:23:23 --> Model Class Initialized
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:23:23 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/treeview.php
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:23:23 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:23:23 --> Final output sent to browser
DEBUG - 2025-03-16 05:23:23 --> Total execution time: 0.1029
INFO - 2025-03-16 05:24:12 --> Config Class Initialized
INFO - 2025-03-16 05:24:12 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:24:12 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:24:12 --> Utf8 Class Initialized
INFO - 2025-03-16 05:24:12 --> URI Class Initialized
DEBUG - 2025-03-16 05:24:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:24:12 --> Router Class Initialized
INFO - 2025-03-16 05:24:12 --> Output Class Initialized
INFO - 2025-03-16 05:24:12 --> Security Class Initialized
DEBUG - 2025-03-16 05:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:24:12 --> Input Class Initialized
INFO - 2025-03-16 05:24:12 --> Language Class Initialized
INFO - 2025-03-16 05:24:12 --> Language Class Initialized
INFO - 2025-03-16 05:24:12 --> Config Class Initialized
INFO - 2025-03-16 05:24:12 --> Loader Class Initialized
INFO - 2025-03-16 05:24:12 --> Helper loaded: url_helper
INFO - 2025-03-16 05:24:12 --> Helper loaded: file_helper
INFO - 2025-03-16 05:24:12 --> Helper loaded: html_helper
INFO - 2025-03-16 05:24:12 --> Helper loaded: form_helper
INFO - 2025-03-16 05:24:12 --> Helper loaded: text_helper
INFO - 2025-03-16 05:24:12 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:24:12 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:24:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:24:12 --> Database Driver Class Initialized
INFO - 2025-03-16 05:24:12 --> Email Class Initialized
INFO - 2025-03-16 05:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:24:12 --> Form Validation Class Initialized
INFO - 2025-03-16 05:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:24:12 --> Pagination Class Initialized
INFO - 2025-03-16 05:24:12 --> Controller Class Initialized
DEBUG - 2025-03-16 05:24:12 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:24:12 --> Model Class Initialized
DEBUG - 2025-03-16 05:24:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:24:12 --> Model Class Initialized
INFO - 2025-03-16 05:24:12 --> Final output sent to browser
DEBUG - 2025-03-16 05:24:12 --> Total execution time: 0.0093
INFO - 2025-03-16 05:24:13 --> Config Class Initialized
INFO - 2025-03-16 05:24:13 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:24:13 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:24:13 --> Utf8 Class Initialized
INFO - 2025-03-16 05:24:13 --> URI Class Initialized
DEBUG - 2025-03-16 05:24:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:24:13 --> Router Class Initialized
INFO - 2025-03-16 05:24:13 --> Output Class Initialized
INFO - 2025-03-16 05:24:13 --> Security Class Initialized
DEBUG - 2025-03-16 05:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:24:13 --> Input Class Initialized
INFO - 2025-03-16 05:24:13 --> Language Class Initialized
INFO - 2025-03-16 05:24:13 --> Language Class Initialized
INFO - 2025-03-16 05:24:13 --> Config Class Initialized
INFO - 2025-03-16 05:24:13 --> Loader Class Initialized
INFO - 2025-03-16 05:24:13 --> Helper loaded: url_helper
INFO - 2025-03-16 05:24:13 --> Helper loaded: file_helper
INFO - 2025-03-16 05:24:13 --> Helper loaded: html_helper
INFO - 2025-03-16 05:24:13 --> Helper loaded: form_helper
INFO - 2025-03-16 05:24:13 --> Helper loaded: text_helper
INFO - 2025-03-16 05:24:13 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:24:13 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:24:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:24:13 --> Database Driver Class Initialized
INFO - 2025-03-16 05:24:13 --> Email Class Initialized
INFO - 2025-03-16 05:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:24:13 --> Form Validation Class Initialized
INFO - 2025-03-16 05:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:24:13 --> Pagination Class Initialized
INFO - 2025-03-16 05:24:13 --> Controller Class Initialized
DEBUG - 2025-03-16 05:24:13 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:24:13 --> Model Class Initialized
DEBUG - 2025-03-16 05:24:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:24:13 --> Model Class Initialized
INFO - 2025-03-16 05:24:13 --> Final output sent to browser
DEBUG - 2025-03-16 05:24:13 --> Total execution time: 0.0079
INFO - 2025-03-16 05:24:53 --> Config Class Initialized
INFO - 2025-03-16 05:24:53 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:24:53 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:24:53 --> Utf8 Class Initialized
INFO - 2025-03-16 05:24:53 --> URI Class Initialized
DEBUG - 2025-03-16 05:24:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:24:53 --> Router Class Initialized
INFO - 2025-03-16 05:24:53 --> Output Class Initialized
INFO - 2025-03-16 05:24:53 --> Security Class Initialized
DEBUG - 2025-03-16 05:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:24:53 --> Input Class Initialized
INFO - 2025-03-16 05:24:53 --> Language Class Initialized
INFO - 2025-03-16 05:24:53 --> Language Class Initialized
INFO - 2025-03-16 05:24:53 --> Config Class Initialized
INFO - 2025-03-16 05:24:53 --> Loader Class Initialized
INFO - 2025-03-16 05:24:53 --> Helper loaded: url_helper
INFO - 2025-03-16 05:24:53 --> Helper loaded: file_helper
INFO - 2025-03-16 05:24:53 --> Helper loaded: html_helper
INFO - 2025-03-16 05:24:53 --> Helper loaded: form_helper
INFO - 2025-03-16 05:24:53 --> Helper loaded: text_helper
INFO - 2025-03-16 05:24:53 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:24:53 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:24:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:24:53 --> Database Driver Class Initialized
INFO - 2025-03-16 05:24:53 --> Email Class Initialized
INFO - 2025-03-16 05:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:24:53 --> Form Validation Class Initialized
INFO - 2025-03-16 05:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:24:53 --> Pagination Class Initialized
INFO - 2025-03-16 05:24:53 --> Controller Class Initialized
DEBUG - 2025-03-16 05:24:53 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:24:53 --> Model Class Initialized
DEBUG - 2025-03-16 05:24:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:24:53 --> Model Class Initialized
INFO - 2025-03-16 05:24:53 --> Final output sent to browser
DEBUG - 2025-03-16 05:24:53 --> Total execution time: 0.0126
INFO - 2025-03-16 05:24:59 --> Config Class Initialized
INFO - 2025-03-16 05:24:59 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:24:59 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:24:59 --> Utf8 Class Initialized
INFO - 2025-03-16 05:24:59 --> URI Class Initialized
DEBUG - 2025-03-16 05:24:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:24:59 --> Router Class Initialized
INFO - 2025-03-16 05:24:59 --> Output Class Initialized
INFO - 2025-03-16 05:24:59 --> Security Class Initialized
DEBUG - 2025-03-16 05:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:24:59 --> Input Class Initialized
INFO - 2025-03-16 05:24:59 --> Language Class Initialized
INFO - 2025-03-16 05:24:59 --> Language Class Initialized
INFO - 2025-03-16 05:24:59 --> Config Class Initialized
INFO - 2025-03-16 05:24:59 --> Loader Class Initialized
INFO - 2025-03-16 05:24:59 --> Helper loaded: url_helper
INFO - 2025-03-16 05:24:59 --> Helper loaded: file_helper
INFO - 2025-03-16 05:24:59 --> Helper loaded: html_helper
INFO - 2025-03-16 05:24:59 --> Helper loaded: form_helper
INFO - 2025-03-16 05:24:59 --> Helper loaded: text_helper
INFO - 2025-03-16 05:24:59 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:24:59 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:24:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:24:59 --> Database Driver Class Initialized
INFO - 2025-03-16 05:24:59 --> Email Class Initialized
INFO - 2025-03-16 05:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:24:59 --> Form Validation Class Initialized
INFO - 2025-03-16 05:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:24:59 --> Pagination Class Initialized
INFO - 2025-03-16 05:24:59 --> Controller Class Initialized
DEBUG - 2025-03-16 05:24:59 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:24:59 --> Model Class Initialized
DEBUG - 2025-03-16 05:24:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:24:59 --> Model Class Initialized
INFO - 2025-03-16 05:24:59 --> Final output sent to browser
DEBUG - 2025-03-16 05:24:59 --> Total execution time: 0.0128
INFO - 2025-03-16 05:25:05 --> Config Class Initialized
INFO - 2025-03-16 05:25:05 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:25:05 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:25:05 --> Utf8 Class Initialized
INFO - 2025-03-16 05:25:05 --> URI Class Initialized
DEBUG - 2025-03-16 05:25:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:25:05 --> Router Class Initialized
INFO - 2025-03-16 05:25:05 --> Output Class Initialized
INFO - 2025-03-16 05:25:05 --> Security Class Initialized
DEBUG - 2025-03-16 05:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:25:05 --> Input Class Initialized
INFO - 2025-03-16 05:25:05 --> Language Class Initialized
INFO - 2025-03-16 05:25:05 --> Language Class Initialized
INFO - 2025-03-16 05:25:05 --> Config Class Initialized
INFO - 2025-03-16 05:25:05 --> Loader Class Initialized
INFO - 2025-03-16 05:25:05 --> Helper loaded: url_helper
INFO - 2025-03-16 05:25:05 --> Helper loaded: file_helper
INFO - 2025-03-16 05:25:05 --> Helper loaded: html_helper
INFO - 2025-03-16 05:25:05 --> Helper loaded: form_helper
INFO - 2025-03-16 05:25:05 --> Helper loaded: text_helper
INFO - 2025-03-16 05:25:05 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:25:05 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:25:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:25:05 --> Database Driver Class Initialized
INFO - 2025-03-16 05:25:05 --> Email Class Initialized
INFO - 2025-03-16 05:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:25:05 --> Form Validation Class Initialized
INFO - 2025-03-16 05:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:25:05 --> Pagination Class Initialized
INFO - 2025-03-16 05:25:05 --> Controller Class Initialized
DEBUG - 2025-03-16 05:25:05 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:25:05 --> Model Class Initialized
DEBUG - 2025-03-16 05:25:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:25:05 --> Model Class Initialized
INFO - 2025-03-16 05:25:05 --> Final output sent to browser
DEBUG - 2025-03-16 05:25:05 --> Total execution time: 0.0135
INFO - 2025-03-16 05:25:07 --> Config Class Initialized
INFO - 2025-03-16 05:25:07 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:25:07 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:25:07 --> Utf8 Class Initialized
INFO - 2025-03-16 05:25:07 --> URI Class Initialized
DEBUG - 2025-03-16 05:25:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:25:07 --> Router Class Initialized
INFO - 2025-03-16 05:25:07 --> Output Class Initialized
INFO - 2025-03-16 05:25:07 --> Security Class Initialized
DEBUG - 2025-03-16 05:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:25:07 --> Input Class Initialized
INFO - 2025-03-16 05:25:07 --> Language Class Initialized
INFO - 2025-03-16 05:25:07 --> Language Class Initialized
INFO - 2025-03-16 05:25:07 --> Config Class Initialized
INFO - 2025-03-16 05:25:07 --> Loader Class Initialized
INFO - 2025-03-16 05:25:07 --> Helper loaded: url_helper
INFO - 2025-03-16 05:25:07 --> Helper loaded: file_helper
INFO - 2025-03-16 05:25:07 --> Helper loaded: html_helper
INFO - 2025-03-16 05:25:07 --> Helper loaded: form_helper
INFO - 2025-03-16 05:25:07 --> Helper loaded: text_helper
INFO - 2025-03-16 05:25:07 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:25:07 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:25:07 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:25:07 --> Database Driver Class Initialized
INFO - 2025-03-16 05:25:07 --> Email Class Initialized
INFO - 2025-03-16 05:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:25:07 --> Form Validation Class Initialized
INFO - 2025-03-16 05:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:25:07 --> Pagination Class Initialized
INFO - 2025-03-16 05:25:07 --> Controller Class Initialized
DEBUG - 2025-03-16 05:25:07 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:25:07 --> Model Class Initialized
DEBUG - 2025-03-16 05:25:07 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:25:07 --> Model Class Initialized
INFO - 2025-03-16 05:25:07 --> Final output sent to browser
DEBUG - 2025-03-16 05:25:07 --> Total execution time: 0.0138
INFO - 2025-03-16 05:25:08 --> Config Class Initialized
INFO - 2025-03-16 05:25:08 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:25:08 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:25:08 --> Utf8 Class Initialized
INFO - 2025-03-16 05:25:08 --> URI Class Initialized
DEBUG - 2025-03-16 05:25:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:25:08 --> Router Class Initialized
INFO - 2025-03-16 05:25:08 --> Output Class Initialized
INFO - 2025-03-16 05:25:08 --> Security Class Initialized
DEBUG - 2025-03-16 05:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:25:08 --> Input Class Initialized
INFO - 2025-03-16 05:25:08 --> Language Class Initialized
INFO - 2025-03-16 05:25:08 --> Language Class Initialized
INFO - 2025-03-16 05:25:08 --> Config Class Initialized
INFO - 2025-03-16 05:25:08 --> Loader Class Initialized
INFO - 2025-03-16 05:25:08 --> Helper loaded: url_helper
INFO - 2025-03-16 05:25:08 --> Helper loaded: file_helper
INFO - 2025-03-16 05:25:08 --> Helper loaded: html_helper
INFO - 2025-03-16 05:25:08 --> Helper loaded: form_helper
INFO - 2025-03-16 05:25:08 --> Helper loaded: text_helper
INFO - 2025-03-16 05:25:08 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:25:08 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:25:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:25:08 --> Database Driver Class Initialized
INFO - 2025-03-16 05:25:08 --> Email Class Initialized
INFO - 2025-03-16 05:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:25:08 --> Form Validation Class Initialized
INFO - 2025-03-16 05:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:25:08 --> Pagination Class Initialized
INFO - 2025-03-16 05:25:08 --> Controller Class Initialized
DEBUG - 2025-03-16 05:25:08 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:25:08 --> Model Class Initialized
DEBUG - 2025-03-16 05:25:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:25:08 --> Model Class Initialized
INFO - 2025-03-16 05:25:08 --> Final output sent to browser
DEBUG - 2025-03-16 05:25:08 --> Total execution time: 0.0099
INFO - 2025-03-16 05:25:10 --> Config Class Initialized
INFO - 2025-03-16 05:25:10 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:25:10 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:25:10 --> Utf8 Class Initialized
INFO - 2025-03-16 05:25:10 --> URI Class Initialized
DEBUG - 2025-03-16 05:25:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:25:10 --> Router Class Initialized
INFO - 2025-03-16 05:25:10 --> Output Class Initialized
INFO - 2025-03-16 05:25:10 --> Security Class Initialized
DEBUG - 2025-03-16 05:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:25:10 --> Input Class Initialized
INFO - 2025-03-16 05:25:10 --> Language Class Initialized
INFO - 2025-03-16 05:25:10 --> Language Class Initialized
INFO - 2025-03-16 05:25:10 --> Config Class Initialized
INFO - 2025-03-16 05:25:10 --> Loader Class Initialized
INFO - 2025-03-16 05:25:10 --> Helper loaded: url_helper
INFO - 2025-03-16 05:25:10 --> Helper loaded: file_helper
INFO - 2025-03-16 05:25:10 --> Helper loaded: html_helper
INFO - 2025-03-16 05:25:10 --> Helper loaded: form_helper
INFO - 2025-03-16 05:25:10 --> Helper loaded: text_helper
INFO - 2025-03-16 05:25:10 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:25:10 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:25:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:25:10 --> Database Driver Class Initialized
INFO - 2025-03-16 05:25:10 --> Email Class Initialized
INFO - 2025-03-16 05:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:25:10 --> Form Validation Class Initialized
INFO - 2025-03-16 05:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:25:10 --> Pagination Class Initialized
INFO - 2025-03-16 05:25:10 --> Controller Class Initialized
DEBUG - 2025-03-16 05:25:10 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:25:10 --> Model Class Initialized
DEBUG - 2025-03-16 05:25:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:25:10 --> Model Class Initialized
INFO - 2025-03-16 05:25:10 --> Final output sent to browser
DEBUG - 2025-03-16 05:25:10 --> Total execution time: 0.0087
INFO - 2025-03-16 05:25:12 --> Config Class Initialized
INFO - 2025-03-16 05:25:12 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:25:12 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:25:12 --> Utf8 Class Initialized
INFO - 2025-03-16 05:25:12 --> URI Class Initialized
DEBUG - 2025-03-16 05:25:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:25:12 --> Router Class Initialized
INFO - 2025-03-16 05:25:12 --> Output Class Initialized
INFO - 2025-03-16 05:25:12 --> Security Class Initialized
DEBUG - 2025-03-16 05:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:25:12 --> Input Class Initialized
INFO - 2025-03-16 05:25:12 --> Language Class Initialized
INFO - 2025-03-16 05:25:12 --> Language Class Initialized
INFO - 2025-03-16 05:25:12 --> Config Class Initialized
INFO - 2025-03-16 05:25:12 --> Loader Class Initialized
INFO - 2025-03-16 05:25:12 --> Helper loaded: url_helper
INFO - 2025-03-16 05:25:12 --> Helper loaded: file_helper
INFO - 2025-03-16 05:25:12 --> Helper loaded: html_helper
INFO - 2025-03-16 05:25:12 --> Helper loaded: form_helper
INFO - 2025-03-16 05:25:12 --> Helper loaded: text_helper
INFO - 2025-03-16 05:25:12 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:25:12 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:25:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:25:12 --> Database Driver Class Initialized
INFO - 2025-03-16 05:25:12 --> Email Class Initialized
INFO - 2025-03-16 05:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:25:12 --> Form Validation Class Initialized
INFO - 2025-03-16 05:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:25:12 --> Pagination Class Initialized
INFO - 2025-03-16 05:25:12 --> Controller Class Initialized
DEBUG - 2025-03-16 05:25:12 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:25:12 --> Model Class Initialized
DEBUG - 2025-03-16 05:25:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:25:12 --> Model Class Initialized
INFO - 2025-03-16 05:25:12 --> Final output sent to browser
DEBUG - 2025-03-16 05:25:12 --> Total execution time: 0.0138
INFO - 2025-03-16 05:25:13 --> Config Class Initialized
INFO - 2025-03-16 05:25:13 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:25:13 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:25:13 --> Utf8 Class Initialized
INFO - 2025-03-16 05:25:13 --> URI Class Initialized
DEBUG - 2025-03-16 05:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:25:13 --> Router Class Initialized
INFO - 2025-03-16 05:25:13 --> Output Class Initialized
INFO - 2025-03-16 05:25:13 --> Security Class Initialized
DEBUG - 2025-03-16 05:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:25:13 --> Input Class Initialized
INFO - 2025-03-16 05:25:13 --> Language Class Initialized
INFO - 2025-03-16 05:25:13 --> Language Class Initialized
INFO - 2025-03-16 05:25:13 --> Config Class Initialized
INFO - 2025-03-16 05:25:13 --> Loader Class Initialized
INFO - 2025-03-16 05:25:13 --> Helper loaded: url_helper
INFO - 2025-03-16 05:25:13 --> Helper loaded: file_helper
INFO - 2025-03-16 05:25:13 --> Helper loaded: html_helper
INFO - 2025-03-16 05:25:13 --> Helper loaded: form_helper
INFO - 2025-03-16 05:25:13 --> Helper loaded: text_helper
INFO - 2025-03-16 05:25:13 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:25:13 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:25:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:25:13 --> Database Driver Class Initialized
INFO - 2025-03-16 05:25:13 --> Email Class Initialized
INFO - 2025-03-16 05:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:25:13 --> Form Validation Class Initialized
INFO - 2025-03-16 05:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:25:13 --> Pagination Class Initialized
INFO - 2025-03-16 05:25:13 --> Controller Class Initialized
DEBUG - 2025-03-16 05:25:13 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:25:13 --> Model Class Initialized
DEBUG - 2025-03-16 05:25:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:25:13 --> Model Class Initialized
INFO - 2025-03-16 05:25:13 --> Final output sent to browser
DEBUG - 2025-03-16 05:25:13 --> Total execution time: 0.0122
INFO - 2025-03-16 05:27:46 --> Config Class Initialized
INFO - 2025-03-16 05:27:46 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:27:46 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:27:46 --> Utf8 Class Initialized
INFO - 2025-03-16 05:27:46 --> URI Class Initialized
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:27:46 --> Router Class Initialized
INFO - 2025-03-16 05:27:46 --> Output Class Initialized
INFO - 2025-03-16 05:27:46 --> Security Class Initialized
DEBUG - 2025-03-16 05:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:27:46 --> Input Class Initialized
INFO - 2025-03-16 05:27:46 --> Language Class Initialized
INFO - 2025-03-16 05:27:46 --> Language Class Initialized
INFO - 2025-03-16 05:27:46 --> Config Class Initialized
INFO - 2025-03-16 05:27:46 --> Loader Class Initialized
INFO - 2025-03-16 05:27:46 --> Helper loaded: url_helper
INFO - 2025-03-16 05:27:46 --> Helper loaded: file_helper
INFO - 2025-03-16 05:27:46 --> Helper loaded: html_helper
INFO - 2025-03-16 05:27:46 --> Helper loaded: form_helper
INFO - 2025-03-16 05:27:46 --> Helper loaded: text_helper
INFO - 2025-03-16 05:27:46 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:27:46 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:27:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:27:46 --> Database Driver Class Initialized
INFO - 2025-03-16 05:27:46 --> Email Class Initialized
INFO - 2025-03-16 05:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:27:46 --> Form Validation Class Initialized
INFO - 2025-03-16 05:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:27:46 --> Pagination Class Initialized
INFO - 2025-03-16 05:27:46 --> Controller Class Initialized
DEBUG - 2025-03-16 05:27:46 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:27:46 --> Model Class Initialized
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:27:46 --> Model Class Initialized
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:27:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:27:46 --> Model Class Initialized
ERROR - 2025-03-16 05:27:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:27:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subaccount_list.php
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:27:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:27:46 --> Final output sent to browser
DEBUG - 2025-03-16 05:27:46 --> Total execution time: 0.1025
INFO - 2025-03-16 05:27:51 --> Config Class Initialized
INFO - 2025-03-16 05:27:51 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:27:51 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:27:51 --> Utf8 Class Initialized
INFO - 2025-03-16 05:27:51 --> URI Class Initialized
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:27:51 --> Router Class Initialized
INFO - 2025-03-16 05:27:51 --> Output Class Initialized
INFO - 2025-03-16 05:27:51 --> Security Class Initialized
DEBUG - 2025-03-16 05:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:27:51 --> Input Class Initialized
INFO - 2025-03-16 05:27:51 --> Language Class Initialized
INFO - 2025-03-16 05:27:51 --> Language Class Initialized
INFO - 2025-03-16 05:27:51 --> Config Class Initialized
INFO - 2025-03-16 05:27:51 --> Loader Class Initialized
INFO - 2025-03-16 05:27:51 --> Helper loaded: url_helper
INFO - 2025-03-16 05:27:51 --> Helper loaded: file_helper
INFO - 2025-03-16 05:27:51 --> Helper loaded: html_helper
INFO - 2025-03-16 05:27:51 --> Helper loaded: form_helper
INFO - 2025-03-16 05:27:51 --> Helper loaded: text_helper
INFO - 2025-03-16 05:27:51 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:27:51 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:27:51 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:27:51 --> Database Driver Class Initialized
INFO - 2025-03-16 05:27:51 --> Email Class Initialized
INFO - 2025-03-16 05:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:27:51 --> Form Validation Class Initialized
INFO - 2025-03-16 05:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:27:51 --> Pagination Class Initialized
INFO - 2025-03-16 05:27:51 --> Controller Class Initialized
DEBUG - 2025-03-16 05:27:51 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:27:51 --> Model Class Initialized
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:27:51 --> Model Class Initialized
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:27:51 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:27:51 --> Model Class Initialized
ERROR - 2025-03-16 05:27:51 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:27:51 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/predefined_accounts.php
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:27:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:27:51 --> Final output sent to browser
DEBUG - 2025-03-16 05:27:51 --> Total execution time: 0.1783
INFO - 2025-03-16 05:28:11 --> Config Class Initialized
INFO - 2025-03-16 05:28:11 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:28:11 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:28:11 --> Utf8 Class Initialized
INFO - 2025-03-16 05:28:11 --> URI Class Initialized
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:28:11 --> Router Class Initialized
INFO - 2025-03-16 05:28:11 --> Output Class Initialized
INFO - 2025-03-16 05:28:11 --> Security Class Initialized
DEBUG - 2025-03-16 05:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:28:11 --> Input Class Initialized
INFO - 2025-03-16 05:28:11 --> Language Class Initialized
INFO - 2025-03-16 05:28:11 --> Language Class Initialized
INFO - 2025-03-16 05:28:11 --> Config Class Initialized
INFO - 2025-03-16 05:28:11 --> Loader Class Initialized
INFO - 2025-03-16 05:28:11 --> Helper loaded: url_helper
INFO - 2025-03-16 05:28:11 --> Helper loaded: file_helper
INFO - 2025-03-16 05:28:11 --> Helper loaded: html_helper
INFO - 2025-03-16 05:28:11 --> Helper loaded: form_helper
INFO - 2025-03-16 05:28:11 --> Helper loaded: text_helper
INFO - 2025-03-16 05:28:11 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:28:11 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:28:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:28:11 --> Database Driver Class Initialized
INFO - 2025-03-16 05:28:11 --> Email Class Initialized
INFO - 2025-03-16 05:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:28:11 --> Form Validation Class Initialized
INFO - 2025-03-16 05:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:28:11 --> Pagination Class Initialized
INFO - 2025-03-16 05:28:11 --> Controller Class Initialized
DEBUG - 2025-03-16 05:28:11 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:28:11 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:28:11 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:28:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:28:11 --> Model Class Initialized
ERROR - 2025-03-16 05:28:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:28:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subaccount_list.php
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:28:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:28:11 --> Final output sent to browser
DEBUG - 2025-03-16 05:28:11 --> Total execution time: 0.1015
INFO - 2025-03-16 05:28:13 --> Config Class Initialized
INFO - 2025-03-16 05:28:13 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:28:13 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:28:13 --> Utf8 Class Initialized
INFO - 2025-03-16 05:28:13 --> URI Class Initialized
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:28:13 --> Router Class Initialized
INFO - 2025-03-16 05:28:13 --> Output Class Initialized
INFO - 2025-03-16 05:28:13 --> Security Class Initialized
DEBUG - 2025-03-16 05:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:28:13 --> Input Class Initialized
INFO - 2025-03-16 05:28:13 --> Language Class Initialized
INFO - 2025-03-16 05:28:13 --> Language Class Initialized
INFO - 2025-03-16 05:28:13 --> Config Class Initialized
INFO - 2025-03-16 05:28:13 --> Loader Class Initialized
INFO - 2025-03-16 05:28:13 --> Helper loaded: url_helper
INFO - 2025-03-16 05:28:13 --> Helper loaded: file_helper
INFO - 2025-03-16 05:28:13 --> Helper loaded: html_helper
INFO - 2025-03-16 05:28:13 --> Helper loaded: form_helper
INFO - 2025-03-16 05:28:13 --> Helper loaded: text_helper
INFO - 2025-03-16 05:28:13 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:28:13 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:28:13 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:28:13 --> Database Driver Class Initialized
INFO - 2025-03-16 05:28:13 --> Email Class Initialized
INFO - 2025-03-16 05:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:28:13 --> Form Validation Class Initialized
INFO - 2025-03-16 05:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:28:13 --> Pagination Class Initialized
INFO - 2025-03-16 05:28:13 --> Controller Class Initialized
DEBUG - 2025-03-16 05:28:13 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:28:13 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:28:13 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:28:13 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:28:13 --> Model Class Initialized
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:13 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/treeview.php
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:28:13 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:28:13 --> Final output sent to browser
DEBUG - 2025-03-16 05:28:13 --> Total execution time: 0.1040
INFO - 2025-03-16 05:28:16 --> Config Class Initialized
INFO - 2025-03-16 05:28:16 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:28:16 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:28:16 --> Utf8 Class Initialized
INFO - 2025-03-16 05:28:16 --> URI Class Initialized
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:28:16 --> Router Class Initialized
INFO - 2025-03-16 05:28:16 --> Output Class Initialized
INFO - 2025-03-16 05:28:16 --> Security Class Initialized
DEBUG - 2025-03-16 05:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:28:16 --> Input Class Initialized
INFO - 2025-03-16 05:28:16 --> Language Class Initialized
INFO - 2025-03-16 05:28:16 --> Language Class Initialized
INFO - 2025-03-16 05:28:16 --> Config Class Initialized
INFO - 2025-03-16 05:28:16 --> Loader Class Initialized
INFO - 2025-03-16 05:28:16 --> Helper loaded: url_helper
INFO - 2025-03-16 05:28:16 --> Helper loaded: file_helper
INFO - 2025-03-16 05:28:16 --> Helper loaded: html_helper
INFO - 2025-03-16 05:28:16 --> Helper loaded: form_helper
INFO - 2025-03-16 05:28:16 --> Helper loaded: text_helper
INFO - 2025-03-16 05:28:16 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:28:16 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:28:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:28:16 --> Database Driver Class Initialized
INFO - 2025-03-16 05:28:16 --> Email Class Initialized
INFO - 2025-03-16 05:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:28:16 --> Form Validation Class Initialized
INFO - 2025-03-16 05:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:28:16 --> Pagination Class Initialized
INFO - 2025-03-16 05:28:16 --> Controller Class Initialized
DEBUG - 2025-03-16 05:28:16 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:28:16 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:28:16 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:28:16 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:28:16 --> Model Class Initialized
ERROR - 2025-03-16 05:28:16 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:28:16 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subaccount_list.php
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:28:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:28:16 --> Final output sent to browser
DEBUG - 2025-03-16 05:28:16 --> Total execution time: 0.2075
INFO - 2025-03-16 05:28:18 --> Config Class Initialized
INFO - 2025-03-16 05:28:18 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:28:18 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:28:18 --> Utf8 Class Initialized
INFO - 2025-03-16 05:28:18 --> URI Class Initialized
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:28:18 --> Router Class Initialized
INFO - 2025-03-16 05:28:18 --> Output Class Initialized
INFO - 2025-03-16 05:28:18 --> Security Class Initialized
DEBUG - 2025-03-16 05:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:28:18 --> Input Class Initialized
INFO - 2025-03-16 05:28:18 --> Language Class Initialized
INFO - 2025-03-16 05:28:18 --> Language Class Initialized
INFO - 2025-03-16 05:28:18 --> Config Class Initialized
INFO - 2025-03-16 05:28:18 --> Loader Class Initialized
INFO - 2025-03-16 05:28:18 --> Helper loaded: url_helper
INFO - 2025-03-16 05:28:18 --> Helper loaded: file_helper
INFO - 2025-03-16 05:28:18 --> Helper loaded: html_helper
INFO - 2025-03-16 05:28:18 --> Helper loaded: form_helper
INFO - 2025-03-16 05:28:18 --> Helper loaded: text_helper
INFO - 2025-03-16 05:28:18 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:28:18 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:28:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:28:18 --> Database Driver Class Initialized
INFO - 2025-03-16 05:28:18 --> Email Class Initialized
INFO - 2025-03-16 05:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:28:18 --> Form Validation Class Initialized
INFO - 2025-03-16 05:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:28:18 --> Pagination Class Initialized
INFO - 2025-03-16 05:28:18 --> Controller Class Initialized
DEBUG - 2025-03-16 05:28:18 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:28:18 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:28:18 --> Model Class Initialized
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:28:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:28:18 --> Model Class Initialized
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Undefined array key 84 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 05:28:18 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/treeview.php
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:28:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:28:18 --> Final output sent to browser
DEBUG - 2025-03-16 05:28:18 --> Total execution time: 0.2007
INFO - 2025-03-16 05:29:11 --> Config Class Initialized
INFO - 2025-03-16 05:29:11 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:29:11 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:29:11 --> Utf8 Class Initialized
INFO - 2025-03-16 05:29:11 --> URI Class Initialized
DEBUG - 2025-03-16 05:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:29:11 --> Router Class Initialized
INFO - 2025-03-16 05:29:11 --> Output Class Initialized
INFO - 2025-03-16 05:29:11 --> Security Class Initialized
DEBUG - 2025-03-16 05:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:29:11 --> Input Class Initialized
INFO - 2025-03-16 05:29:11 --> Language Class Initialized
INFO - 2025-03-16 05:29:11 --> Language Class Initialized
INFO - 2025-03-16 05:29:11 --> Config Class Initialized
INFO - 2025-03-16 05:29:11 --> Loader Class Initialized
INFO - 2025-03-16 05:29:11 --> Helper loaded: url_helper
INFO - 2025-03-16 05:29:11 --> Helper loaded: file_helper
INFO - 2025-03-16 05:29:11 --> Helper loaded: html_helper
INFO - 2025-03-16 05:29:11 --> Helper loaded: form_helper
INFO - 2025-03-16 05:29:11 --> Helper loaded: text_helper
INFO - 2025-03-16 05:29:11 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:29:11 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:29:11 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:29:11 --> Database Driver Class Initialized
INFO - 2025-03-16 05:29:11 --> Email Class Initialized
INFO - 2025-03-16 05:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:29:11 --> Form Validation Class Initialized
INFO - 2025-03-16 05:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:29:11 --> Pagination Class Initialized
INFO - 2025-03-16 05:29:11 --> Controller Class Initialized
DEBUG - 2025-03-16 05:29:11 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:29:11 --> Model Class Initialized
DEBUG - 2025-03-16 05:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:29:11 --> Model Class Initialized
DEBUG - 2025-03-16 05:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:29:11 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:29:11 --> Model Class Initialized
ERROR - 2025-03-16 05:29:11 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:29:11 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:29:11 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subaccount_list.php
DEBUG - 2025-03-16 05:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:29:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:29:12 --> Final output sent to browser
DEBUG - 2025-03-16 05:29:12 --> Total execution time: 0.1555
INFO - 2025-03-16 05:29:25 --> Config Class Initialized
INFO - 2025-03-16 05:29:25 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:29:25 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:29:25 --> Utf8 Class Initialized
INFO - 2025-03-16 05:29:25 --> URI Class Initialized
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:29:25 --> Router Class Initialized
INFO - 2025-03-16 05:29:25 --> Output Class Initialized
INFO - 2025-03-16 05:29:25 --> Security Class Initialized
DEBUG - 2025-03-16 05:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:29:25 --> Input Class Initialized
INFO - 2025-03-16 05:29:25 --> Language Class Initialized
INFO - 2025-03-16 05:29:25 --> Language Class Initialized
INFO - 2025-03-16 05:29:25 --> Config Class Initialized
INFO - 2025-03-16 05:29:25 --> Loader Class Initialized
INFO - 2025-03-16 05:29:25 --> Helper loaded: url_helper
INFO - 2025-03-16 05:29:25 --> Helper loaded: file_helper
INFO - 2025-03-16 05:29:25 --> Helper loaded: html_helper
INFO - 2025-03-16 05:29:25 --> Helper loaded: form_helper
INFO - 2025-03-16 05:29:25 --> Helper loaded: text_helper
INFO - 2025-03-16 05:29:25 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:29:25 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:29:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:29:25 --> Database Driver Class Initialized
INFO - 2025-03-16 05:29:25 --> Email Class Initialized
INFO - 2025-03-16 05:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:29:25 --> Form Validation Class Initialized
INFO - 2025-03-16 05:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:29:25 --> Pagination Class Initialized
INFO - 2025-03-16 05:29:25 --> Controller Class Initialized
DEBUG - 2025-03-16 05:29:25 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:29:25 --> Model Class Initialized
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:29:25 --> Model Class Initialized
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:29:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:29:25 --> Model Class Initialized
ERROR - 2025-03-16 05:29:25 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:29:25 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/predefined_accounts.php
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:29:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:29:25 --> Final output sent to browser
DEBUG - 2025-03-16 05:29:25 --> Total execution time: 0.1086
INFO - 2025-03-16 05:35:53 --> Config Class Initialized
INFO - 2025-03-16 05:35:53 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:35:53 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:35:53 --> Utf8 Class Initialized
INFO - 2025-03-16 05:35:53 --> URI Class Initialized
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:35:53 --> Router Class Initialized
INFO - 2025-03-16 05:35:53 --> Output Class Initialized
INFO - 2025-03-16 05:35:53 --> Security Class Initialized
DEBUG - 2025-03-16 05:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:35:53 --> Input Class Initialized
INFO - 2025-03-16 05:35:53 --> Language Class Initialized
INFO - 2025-03-16 05:35:53 --> Language Class Initialized
INFO - 2025-03-16 05:35:53 --> Config Class Initialized
INFO - 2025-03-16 05:35:53 --> Loader Class Initialized
INFO - 2025-03-16 05:35:53 --> Helper loaded: url_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: file_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: html_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: form_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: text_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:35:53 --> Database Driver Class Initialized
INFO - 2025-03-16 05:35:53 --> Email Class Initialized
INFO - 2025-03-16 05:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:35:53 --> Form Validation Class Initialized
INFO - 2025-03-16 05:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:35:53 --> Pagination Class Initialized
INFO - 2025-03-16 05:35:53 --> Controller Class Initialized
DEBUG - 2025-03-16 05:35:53 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:35:53 --> Model Class Initialized
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:35:53 --> Model Class Initialized
INFO - 2025-03-16 05:35:53 --> Config Class Initialized
INFO - 2025-03-16 05:35:53 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:35:53 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:35:53 --> Utf8 Class Initialized
INFO - 2025-03-16 05:35:53 --> URI Class Initialized
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:35:53 --> Router Class Initialized
INFO - 2025-03-16 05:35:53 --> Output Class Initialized
INFO - 2025-03-16 05:35:53 --> Security Class Initialized
DEBUG - 2025-03-16 05:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:35:53 --> Input Class Initialized
INFO - 2025-03-16 05:35:53 --> Language Class Initialized
INFO - 2025-03-16 05:35:53 --> Language Class Initialized
INFO - 2025-03-16 05:35:53 --> Config Class Initialized
INFO - 2025-03-16 05:35:53 --> Loader Class Initialized
INFO - 2025-03-16 05:35:53 --> Helper loaded: url_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: file_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: html_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: form_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: text_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:35:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:35:53 --> Database Driver Class Initialized
INFO - 2025-03-16 05:35:53 --> Email Class Initialized
INFO - 2025-03-16 05:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:35:53 --> Form Validation Class Initialized
INFO - 2025-03-16 05:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:35:53 --> Pagination Class Initialized
INFO - 2025-03-16 05:35:53 --> Controller Class Initialized
DEBUG - 2025-03-16 05:35:53 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:35:53 --> Model Class Initialized
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:35:53 --> Model Class Initialized
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:35:53 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:35:53 --> Model Class Initialized
ERROR - 2025-03-16 05:35:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:35:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/predefined_accounts.php
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:35:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:35:53 --> Final output sent to browser
DEBUG - 2025-03-16 05:35:53 --> Total execution time: 0.1039
INFO - 2025-03-16 05:35:59 --> Config Class Initialized
INFO - 2025-03-16 05:35:59 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:35:59 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:35:59 --> Utf8 Class Initialized
INFO - 2025-03-16 05:35:59 --> URI Class Initialized
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:35:59 --> Router Class Initialized
INFO - 2025-03-16 05:35:59 --> Output Class Initialized
INFO - 2025-03-16 05:35:59 --> Security Class Initialized
DEBUG - 2025-03-16 05:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:35:59 --> Input Class Initialized
INFO - 2025-03-16 05:35:59 --> Language Class Initialized
INFO - 2025-03-16 05:35:59 --> Language Class Initialized
INFO - 2025-03-16 05:35:59 --> Config Class Initialized
INFO - 2025-03-16 05:35:59 --> Loader Class Initialized
INFO - 2025-03-16 05:35:59 --> Helper loaded: url_helper
INFO - 2025-03-16 05:35:59 --> Helper loaded: file_helper
INFO - 2025-03-16 05:35:59 --> Helper loaded: html_helper
INFO - 2025-03-16 05:35:59 --> Helper loaded: form_helper
INFO - 2025-03-16 05:35:59 --> Helper loaded: text_helper
INFO - 2025-03-16 05:35:59 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:35:59 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:35:59 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:35:59 --> Database Driver Class Initialized
INFO - 2025-03-16 05:35:59 --> Email Class Initialized
INFO - 2025-03-16 05:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:35:59 --> Form Validation Class Initialized
INFO - 2025-03-16 05:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:35:59 --> Pagination Class Initialized
INFO - 2025-03-16 05:35:59 --> Controller Class Initialized
DEBUG - 2025-03-16 05:35:59 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:35:59 --> Model Class Initialized
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:35:59 --> Model Class Initialized
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:35:59 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:35:59 --> Model Class Initialized
ERROR - 2025-03-16 05:35:59 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:35:59 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/financial_year_list.php
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:35:59 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:35:59 --> Final output sent to browser
DEBUG - 2025-03-16 05:35:59 --> Total execution time: 0.2008
INFO - 2025-03-16 05:36:04 --> Config Class Initialized
INFO - 2025-03-16 05:36:04 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:36:04 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:36:04 --> Utf8 Class Initialized
INFO - 2025-03-16 05:36:04 --> URI Class Initialized
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:36:04 --> Router Class Initialized
INFO - 2025-03-16 05:36:04 --> Output Class Initialized
INFO - 2025-03-16 05:36:04 --> Security Class Initialized
DEBUG - 2025-03-16 05:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:36:04 --> Input Class Initialized
INFO - 2025-03-16 05:36:04 --> Language Class Initialized
INFO - 2025-03-16 05:36:04 --> Language Class Initialized
INFO - 2025-03-16 05:36:04 --> Config Class Initialized
INFO - 2025-03-16 05:36:04 --> Loader Class Initialized
INFO - 2025-03-16 05:36:04 --> Helper loaded: url_helper
INFO - 2025-03-16 05:36:04 --> Helper loaded: file_helper
INFO - 2025-03-16 05:36:04 --> Helper loaded: html_helper
INFO - 2025-03-16 05:36:04 --> Helper loaded: form_helper
INFO - 2025-03-16 05:36:04 --> Helper loaded: text_helper
INFO - 2025-03-16 05:36:04 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:36:04 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:36:04 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:36:04 --> Database Driver Class Initialized
INFO - 2025-03-16 05:36:04 --> Email Class Initialized
INFO - 2025-03-16 05:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:36:04 --> Form Validation Class Initialized
INFO - 2025-03-16 05:36:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:36:04 --> Pagination Class Initialized
INFO - 2025-03-16 05:36:04 --> Controller Class Initialized
DEBUG - 2025-03-16 05:36:04 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:36:04 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:36:04 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:36:04 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:36:04 --> Model Class Initialized
ERROR - 2025-03-16 05:36:04 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:36:04 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance_list.php
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:36:04 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:36:04 --> Final output sent to browser
DEBUG - 2025-03-16 05:36:04 --> Total execution time: 0.1658
INFO - 2025-03-16 05:36:18 --> Config Class Initialized
INFO - 2025-03-16 05:36:18 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:36:18 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:36:18 --> Utf8 Class Initialized
INFO - 2025-03-16 05:36:18 --> URI Class Initialized
DEBUG - 2025-03-16 05:36:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:36:18 --> Router Class Initialized
INFO - 2025-03-16 05:36:18 --> Output Class Initialized
INFO - 2025-03-16 05:36:18 --> Security Class Initialized
DEBUG - 2025-03-16 05:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:36:18 --> Input Class Initialized
INFO - 2025-03-16 05:36:18 --> Language Class Initialized
INFO - 2025-03-16 05:36:18 --> Language Class Initialized
INFO - 2025-03-16 05:36:18 --> Config Class Initialized
INFO - 2025-03-16 05:36:18 --> Loader Class Initialized
INFO - 2025-03-16 05:36:18 --> Helper loaded: url_helper
INFO - 2025-03-16 05:36:18 --> Helper loaded: file_helper
INFO - 2025-03-16 05:36:18 --> Helper loaded: html_helper
INFO - 2025-03-16 05:36:18 --> Helper loaded: form_helper
INFO - 2025-03-16 05:36:18 --> Helper loaded: text_helper
INFO - 2025-03-16 05:36:18 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:36:18 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:36:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:36:18 --> Database Driver Class Initialized
INFO - 2025-03-16 05:36:18 --> Email Class Initialized
INFO - 2025-03-16 05:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:36:18 --> Form Validation Class Initialized
INFO - 2025-03-16 05:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:36:18 --> Pagination Class Initialized
INFO - 2025-03-16 05:36:18 --> Controller Class Initialized
DEBUG - 2025-03-16 05:36:18 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:36:18 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:36:18 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:36:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:36:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:36:18 --> Model Class Initialized
ERROR - 2025-03-16 05:36:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:36:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:36:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:36:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance.php
DEBUG - 2025-03-16 05:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:36:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:36:19 --> Final output sent to browser
DEBUG - 2025-03-16 05:36:19 --> Total execution time: 0.1492
INFO - 2025-03-16 05:36:24 --> Config Class Initialized
INFO - 2025-03-16 05:36:24 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:36:24 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:36:24 --> Utf8 Class Initialized
INFO - 2025-03-16 05:36:24 --> URI Class Initialized
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:36:24 --> Router Class Initialized
INFO - 2025-03-16 05:36:24 --> Output Class Initialized
INFO - 2025-03-16 05:36:24 --> Security Class Initialized
DEBUG - 2025-03-16 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:36:24 --> Input Class Initialized
INFO - 2025-03-16 05:36:24 --> Language Class Initialized
INFO - 2025-03-16 05:36:24 --> Language Class Initialized
INFO - 2025-03-16 05:36:24 --> Config Class Initialized
INFO - 2025-03-16 05:36:24 --> Loader Class Initialized
INFO - 2025-03-16 05:36:24 --> Helper loaded: url_helper
INFO - 2025-03-16 05:36:24 --> Helper loaded: file_helper
INFO - 2025-03-16 05:36:24 --> Helper loaded: html_helper
INFO - 2025-03-16 05:36:24 --> Helper loaded: form_helper
INFO - 2025-03-16 05:36:24 --> Helper loaded: text_helper
INFO - 2025-03-16 05:36:24 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:36:24 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:36:24 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:36:24 --> Database Driver Class Initialized
INFO - 2025-03-16 05:36:24 --> Email Class Initialized
INFO - 2025-03-16 05:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:36:24 --> Form Validation Class Initialized
INFO - 2025-03-16 05:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:36:24 --> Pagination Class Initialized
INFO - 2025-03-16 05:36:24 --> Controller Class Initialized
DEBUG - 2025-03-16 05:36:24 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:36:24 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:36:24 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:36:24 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:36:24 --> Model Class Initialized
ERROR - 2025-03-16 05:36:24 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:36:24 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/financial_year_list.php
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:36:24 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:36:24 --> Final output sent to browser
DEBUG - 2025-03-16 05:36:24 --> Total execution time: 0.0992
INFO - 2025-03-16 05:36:30 --> Config Class Initialized
INFO - 2025-03-16 05:36:30 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:36:30 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:36:30 --> Utf8 Class Initialized
INFO - 2025-03-16 05:36:30 --> URI Class Initialized
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:36:30 --> Router Class Initialized
INFO - 2025-03-16 05:36:30 --> Output Class Initialized
INFO - 2025-03-16 05:36:30 --> Security Class Initialized
DEBUG - 2025-03-16 05:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:36:30 --> Input Class Initialized
INFO - 2025-03-16 05:36:30 --> Language Class Initialized
INFO - 2025-03-16 05:36:30 --> Language Class Initialized
INFO - 2025-03-16 05:36:30 --> Config Class Initialized
INFO - 2025-03-16 05:36:30 --> Loader Class Initialized
INFO - 2025-03-16 05:36:30 --> Helper loaded: url_helper
INFO - 2025-03-16 05:36:30 --> Helper loaded: file_helper
INFO - 2025-03-16 05:36:30 --> Helper loaded: html_helper
INFO - 2025-03-16 05:36:30 --> Helper loaded: form_helper
INFO - 2025-03-16 05:36:30 --> Helper loaded: text_helper
INFO - 2025-03-16 05:36:30 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:36:30 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:36:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:36:30 --> Database Driver Class Initialized
INFO - 2025-03-16 05:36:30 --> Email Class Initialized
INFO - 2025-03-16 05:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:36:30 --> Form Validation Class Initialized
INFO - 2025-03-16 05:36:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:36:30 --> Pagination Class Initialized
INFO - 2025-03-16 05:36:30 --> Controller Class Initialized
DEBUG - 2025-03-16 05:36:30 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:36:30 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:36:30 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:36:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:36:30 --> Model Class Initialized
ERROR - 2025-03-16 05:36:30 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:36:30 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance_list.php
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:36:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:36:30 --> Final output sent to browser
DEBUG - 2025-03-16 05:36:30 --> Total execution time: 0.1692
INFO - 2025-03-16 05:36:33 --> Config Class Initialized
INFO - 2025-03-16 05:36:33 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:36:33 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:36:33 --> Utf8 Class Initialized
INFO - 2025-03-16 05:36:33 --> URI Class Initialized
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:36:33 --> Router Class Initialized
INFO - 2025-03-16 05:36:33 --> Output Class Initialized
INFO - 2025-03-16 05:36:33 --> Security Class Initialized
DEBUG - 2025-03-16 05:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:36:33 --> Input Class Initialized
INFO - 2025-03-16 05:36:33 --> Language Class Initialized
INFO - 2025-03-16 05:36:33 --> Language Class Initialized
INFO - 2025-03-16 05:36:33 --> Config Class Initialized
INFO - 2025-03-16 05:36:33 --> Loader Class Initialized
INFO - 2025-03-16 05:36:33 --> Helper loaded: url_helper
INFO - 2025-03-16 05:36:33 --> Helper loaded: file_helper
INFO - 2025-03-16 05:36:33 --> Helper loaded: html_helper
INFO - 2025-03-16 05:36:33 --> Helper loaded: form_helper
INFO - 2025-03-16 05:36:33 --> Helper loaded: text_helper
INFO - 2025-03-16 05:36:33 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:36:33 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:36:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:36:33 --> Database Driver Class Initialized
INFO - 2025-03-16 05:36:33 --> Email Class Initialized
INFO - 2025-03-16 05:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:36:33 --> Form Validation Class Initialized
INFO - 2025-03-16 05:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:36:33 --> Pagination Class Initialized
INFO - 2025-03-16 05:36:33 --> Controller Class Initialized
DEBUG - 2025-03-16 05:36:33 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:36:33 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:36:33 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:36:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:36:33 --> Model Class Initialized
ERROR - 2025-03-16 05:36:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:36:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance.php
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:36:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:36:33 --> Final output sent to browser
DEBUG - 2025-03-16 05:36:33 --> Total execution time: 0.1649
INFO - 2025-03-16 05:36:41 --> Config Class Initialized
INFO - 2025-03-16 05:36:41 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:36:41 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:36:41 --> Utf8 Class Initialized
INFO - 2025-03-16 05:36:41 --> URI Class Initialized
DEBUG - 2025-03-16 05:36:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:36:41 --> Router Class Initialized
INFO - 2025-03-16 05:36:41 --> Output Class Initialized
INFO - 2025-03-16 05:36:41 --> Security Class Initialized
DEBUG - 2025-03-16 05:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:36:41 --> Input Class Initialized
INFO - 2025-03-16 05:36:41 --> Language Class Initialized
INFO - 2025-03-16 05:36:41 --> Language Class Initialized
INFO - 2025-03-16 05:36:41 --> Config Class Initialized
INFO - 2025-03-16 05:36:41 --> Loader Class Initialized
INFO - 2025-03-16 05:36:41 --> Helper loaded: url_helper
INFO - 2025-03-16 05:36:41 --> Helper loaded: file_helper
INFO - 2025-03-16 05:36:41 --> Helper loaded: html_helper
INFO - 2025-03-16 05:36:41 --> Helper loaded: form_helper
INFO - 2025-03-16 05:36:41 --> Helper loaded: text_helper
INFO - 2025-03-16 05:36:41 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:36:41 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:36:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:36:41 --> Database Driver Class Initialized
INFO - 2025-03-16 05:36:41 --> Email Class Initialized
INFO - 2025-03-16 05:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:36:41 --> Form Validation Class Initialized
INFO - 2025-03-16 05:36:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:36:41 --> Pagination Class Initialized
INFO - 2025-03-16 05:36:41 --> Controller Class Initialized
DEBUG - 2025-03-16 05:36:41 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:36:41 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:36:41 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:36:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:36:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:36:41 --> Model Class Initialized
ERROR - 2025-03-16 05:36:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:36:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:36:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/financial_year_list.php
DEBUG - 2025-03-16 05:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:36:42 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:36:42 --> Final output sent to browser
DEBUG - 2025-03-16 05:36:42 --> Total execution time: 0.1933
INFO - 2025-03-16 05:36:55 --> Config Class Initialized
INFO - 2025-03-16 05:36:55 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:36:55 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:36:55 --> Utf8 Class Initialized
INFO - 2025-03-16 05:36:55 --> URI Class Initialized
DEBUG - 2025-03-16 05:36:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:36:55 --> Router Class Initialized
INFO - 2025-03-16 05:36:55 --> Output Class Initialized
INFO - 2025-03-16 05:36:55 --> Security Class Initialized
DEBUG - 2025-03-16 05:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:36:55 --> Input Class Initialized
INFO - 2025-03-16 05:36:55 --> Language Class Initialized
INFO - 2025-03-16 05:36:55 --> Language Class Initialized
INFO - 2025-03-16 05:36:55 --> Config Class Initialized
INFO - 2025-03-16 05:36:55 --> Loader Class Initialized
INFO - 2025-03-16 05:36:55 --> Helper loaded: url_helper
INFO - 2025-03-16 05:36:55 --> Helper loaded: file_helper
INFO - 2025-03-16 05:36:55 --> Helper loaded: html_helper
INFO - 2025-03-16 05:36:55 --> Helper loaded: form_helper
INFO - 2025-03-16 05:36:55 --> Helper loaded: text_helper
INFO - 2025-03-16 05:36:55 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:36:55 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:36:55 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:36:55 --> Database Driver Class Initialized
INFO - 2025-03-16 05:36:55 --> Email Class Initialized
INFO - 2025-03-16 05:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:36:55 --> Form Validation Class Initialized
INFO - 2025-03-16 05:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:36:55 --> Pagination Class Initialized
INFO - 2025-03-16 05:36:55 --> Controller Class Initialized
DEBUG - 2025-03-16 05:36:55 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:36:55 --> Model Class Initialized
DEBUG - 2025-03-16 05:36:55 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:36:55 --> Model Class Initialized
INFO - 2025-03-16 05:36:55 --> Final output sent to browser
DEBUG - 2025-03-16 05:36:55 --> Total execution time: 0.0064
INFO - 2025-03-16 05:37:31 --> Config Class Initialized
INFO - 2025-03-16 05:37:31 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:37:31 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:37:31 --> Utf8 Class Initialized
INFO - 2025-03-16 05:37:31 --> URI Class Initialized
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:37:31 --> Router Class Initialized
INFO - 2025-03-16 05:37:31 --> Output Class Initialized
INFO - 2025-03-16 05:37:31 --> Security Class Initialized
DEBUG - 2025-03-16 05:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:37:31 --> Input Class Initialized
INFO - 2025-03-16 05:37:31 --> Language Class Initialized
INFO - 2025-03-16 05:37:31 --> Language Class Initialized
INFO - 2025-03-16 05:37:31 --> Config Class Initialized
INFO - 2025-03-16 05:37:31 --> Loader Class Initialized
INFO - 2025-03-16 05:37:31 --> Helper loaded: url_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: file_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: html_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: form_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: text_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:37:31 --> Database Driver Class Initialized
INFO - 2025-03-16 05:37:31 --> Email Class Initialized
INFO - 2025-03-16 05:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:37:31 --> Form Validation Class Initialized
INFO - 2025-03-16 05:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:37:31 --> Pagination Class Initialized
INFO - 2025-03-16 05:37:31 --> Controller Class Initialized
DEBUG - 2025-03-16 05:37:31 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:37:31 --> Model Class Initialized
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:37:31 --> Model Class Initialized
INFO - 2025-03-16 05:37:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-16 05:37:31 --> Config Class Initialized
INFO - 2025-03-16 05:37:31 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:37:31 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:37:31 --> Utf8 Class Initialized
INFO - 2025-03-16 05:37:31 --> URI Class Initialized
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:37:31 --> Router Class Initialized
INFO - 2025-03-16 05:37:31 --> Output Class Initialized
INFO - 2025-03-16 05:37:31 --> Security Class Initialized
DEBUG - 2025-03-16 05:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:37:31 --> Input Class Initialized
INFO - 2025-03-16 05:37:31 --> Language Class Initialized
INFO - 2025-03-16 05:37:31 --> Language Class Initialized
INFO - 2025-03-16 05:37:31 --> Config Class Initialized
INFO - 2025-03-16 05:37:31 --> Loader Class Initialized
INFO - 2025-03-16 05:37:31 --> Helper loaded: url_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: file_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: html_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: form_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: text_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:37:31 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:37:31 --> Database Driver Class Initialized
INFO - 2025-03-16 05:37:31 --> Email Class Initialized
INFO - 2025-03-16 05:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:37:31 --> Form Validation Class Initialized
INFO - 2025-03-16 05:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:37:31 --> Pagination Class Initialized
INFO - 2025-03-16 05:37:31 --> Controller Class Initialized
DEBUG - 2025-03-16 05:37:31 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:37:31 --> Model Class Initialized
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:37:31 --> Model Class Initialized
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:37:31 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:37:31 --> Model Class Initialized
ERROR - 2025-03-16 05:37:31 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:37:31 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:37:31 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/financial_year_list.php
DEBUG - 2025-03-16 05:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:37:32 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:37:32 --> Final output sent to browser
DEBUG - 2025-03-16 05:37:32 --> Total execution time: 0.1496
INFO - 2025-03-16 05:37:34 --> Config Class Initialized
INFO - 2025-03-16 05:37:34 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:37:34 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:37:34 --> Utf8 Class Initialized
INFO - 2025-03-16 05:37:34 --> URI Class Initialized
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:37:34 --> Router Class Initialized
INFO - 2025-03-16 05:37:34 --> Output Class Initialized
INFO - 2025-03-16 05:37:34 --> Security Class Initialized
DEBUG - 2025-03-16 05:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:37:34 --> Input Class Initialized
INFO - 2025-03-16 05:37:34 --> Language Class Initialized
INFO - 2025-03-16 05:37:34 --> Language Class Initialized
INFO - 2025-03-16 05:37:34 --> Config Class Initialized
INFO - 2025-03-16 05:37:34 --> Loader Class Initialized
INFO - 2025-03-16 05:37:34 --> Helper loaded: url_helper
INFO - 2025-03-16 05:37:34 --> Helper loaded: file_helper
INFO - 2025-03-16 05:37:34 --> Helper loaded: html_helper
INFO - 2025-03-16 05:37:34 --> Helper loaded: form_helper
INFO - 2025-03-16 05:37:34 --> Helper loaded: text_helper
INFO - 2025-03-16 05:37:34 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:37:34 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:37:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:37:34 --> Database Driver Class Initialized
INFO - 2025-03-16 05:37:34 --> Email Class Initialized
INFO - 2025-03-16 05:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:37:34 --> Form Validation Class Initialized
INFO - 2025-03-16 05:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:37:34 --> Pagination Class Initialized
INFO - 2025-03-16 05:37:34 --> Controller Class Initialized
DEBUG - 2025-03-16 05:37:34 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:37:34 --> Model Class Initialized
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:37:34 --> Model Class Initialized
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:37:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:37:34 --> Model Class Initialized
ERROR - 2025-03-16 05:37:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:37:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance_list.php
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:37:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:37:34 --> Final output sent to browser
DEBUG - 2025-03-16 05:37:34 --> Total execution time: 0.1613
INFO - 2025-03-16 05:37:37 --> Config Class Initialized
INFO - 2025-03-16 05:37:37 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:37:37 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:37:37 --> Utf8 Class Initialized
INFO - 2025-03-16 05:37:37 --> URI Class Initialized
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:37:37 --> Router Class Initialized
INFO - 2025-03-16 05:37:37 --> Output Class Initialized
INFO - 2025-03-16 05:37:37 --> Security Class Initialized
DEBUG - 2025-03-16 05:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:37:37 --> Input Class Initialized
INFO - 2025-03-16 05:37:37 --> Language Class Initialized
INFO - 2025-03-16 05:37:37 --> Language Class Initialized
INFO - 2025-03-16 05:37:37 --> Config Class Initialized
INFO - 2025-03-16 05:37:37 --> Loader Class Initialized
INFO - 2025-03-16 05:37:37 --> Helper loaded: url_helper
INFO - 2025-03-16 05:37:37 --> Helper loaded: file_helper
INFO - 2025-03-16 05:37:37 --> Helper loaded: html_helper
INFO - 2025-03-16 05:37:37 --> Helper loaded: form_helper
INFO - 2025-03-16 05:37:37 --> Helper loaded: text_helper
INFO - 2025-03-16 05:37:37 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:37:37 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:37:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:37:37 --> Database Driver Class Initialized
INFO - 2025-03-16 05:37:37 --> Email Class Initialized
INFO - 2025-03-16 05:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:37:37 --> Form Validation Class Initialized
INFO - 2025-03-16 05:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:37:37 --> Pagination Class Initialized
INFO - 2025-03-16 05:37:37 --> Controller Class Initialized
DEBUG - 2025-03-16 05:37:37 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:37:37 --> Model Class Initialized
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:37:37 --> Model Class Initialized
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:37:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:37:37 --> Model Class Initialized
ERROR - 2025-03-16 05:37:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:37:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance.php
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:37:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:37:37 --> Final output sent to browser
DEBUG - 2025-03-16 05:37:37 --> Total execution time: 0.1389
INFO - 2025-03-16 05:38:15 --> Config Class Initialized
INFO - 2025-03-16 05:38:15 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:15 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:15 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:15 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:15 --> Router Class Initialized
INFO - 2025-03-16 05:38:15 --> Output Class Initialized
INFO - 2025-03-16 05:38:15 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:15 --> Input Class Initialized
INFO - 2025-03-16 05:38:15 --> Language Class Initialized
INFO - 2025-03-16 05:38:15 --> Language Class Initialized
INFO - 2025-03-16 05:38:15 --> Config Class Initialized
INFO - 2025-03-16 05:38:15 --> Loader Class Initialized
INFO - 2025-03-16 05:38:15 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:15 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:15 --> Email Class Initialized
INFO - 2025-03-16 05:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:15 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:15 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:15 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:15 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:15 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:15 --> Model Class Initialized
INFO - 2025-03-16 05:38:15 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:15 --> Total execution time: 0.0074
INFO - 2025-03-16 05:38:15 --> Config Class Initialized
INFO - 2025-03-16 05:38:15 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:15 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:15 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:15 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:15 --> Router Class Initialized
INFO - 2025-03-16 05:38:15 --> Output Class Initialized
INFO - 2025-03-16 05:38:15 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:15 --> Input Class Initialized
INFO - 2025-03-16 05:38:15 --> Language Class Initialized
INFO - 2025-03-16 05:38:15 --> Language Class Initialized
INFO - 2025-03-16 05:38:15 --> Config Class Initialized
INFO - 2025-03-16 05:38:15 --> Loader Class Initialized
INFO - 2025-03-16 05:38:15 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:15 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:15 --> Email Class Initialized
INFO - 2025-03-16 05:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:15 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:15 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:15 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:15 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:15 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:15 --> Model Class Initialized
INFO - 2025-03-16 05:38:15 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:15 --> Total execution time: 0.0067
INFO - 2025-03-16 05:38:20 --> Config Class Initialized
INFO - 2025-03-16 05:38:20 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:20 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:20 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:20 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:20 --> Router Class Initialized
INFO - 2025-03-16 05:38:20 --> Output Class Initialized
INFO - 2025-03-16 05:38:20 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:20 --> Input Class Initialized
INFO - 2025-03-16 05:38:20 --> Language Class Initialized
INFO - 2025-03-16 05:38:20 --> Language Class Initialized
INFO - 2025-03-16 05:38:20 --> Config Class Initialized
INFO - 2025-03-16 05:38:20 --> Loader Class Initialized
INFO - 2025-03-16 05:38:20 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:20 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:20 --> Email Class Initialized
INFO - 2025-03-16 05:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:20 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:20 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:20 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:20 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:20 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:20 --> Model Class Initialized
INFO - 2025-03-16 05:38:20 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:20 --> Total execution time: 0.0092
INFO - 2025-03-16 05:38:20 --> Config Class Initialized
INFO - 2025-03-16 05:38:20 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:20 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:20 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:20 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:20 --> Router Class Initialized
INFO - 2025-03-16 05:38:20 --> Output Class Initialized
INFO - 2025-03-16 05:38:20 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:20 --> Input Class Initialized
INFO - 2025-03-16 05:38:20 --> Language Class Initialized
INFO - 2025-03-16 05:38:20 --> Language Class Initialized
INFO - 2025-03-16 05:38:20 --> Config Class Initialized
INFO - 2025-03-16 05:38:20 --> Loader Class Initialized
INFO - 2025-03-16 05:38:20 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:20 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:20 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:20 --> Email Class Initialized
INFO - 2025-03-16 05:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:20 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:20 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:20 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:20 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:20 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:20 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:20 --> Model Class Initialized
INFO - 2025-03-16 05:38:20 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:20 --> Total execution time: 0.0080
INFO - 2025-03-16 05:38:37 --> Config Class Initialized
INFO - 2025-03-16 05:38:37 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:37 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:37 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:37 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:37 --> Router Class Initialized
INFO - 2025-03-16 05:38:37 --> Output Class Initialized
INFO - 2025-03-16 05:38:37 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:37 --> Input Class Initialized
INFO - 2025-03-16 05:38:37 --> Language Class Initialized
INFO - 2025-03-16 05:38:37 --> Language Class Initialized
INFO - 2025-03-16 05:38:37 --> Config Class Initialized
INFO - 2025-03-16 05:38:37 --> Loader Class Initialized
INFO - 2025-03-16 05:38:37 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:37 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:37 --> Email Class Initialized
INFO - 2025-03-16 05:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:37 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:37 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:37 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:37 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:37 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:37 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:38:37 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:38:37 --> Model Class Initialized
ERROR - 2025-03-16 05:38:37 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:38:37 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/debit_voucher_list.php
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:38:37 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:37 --> Total execution time: 0.1038
INFO - 2025-03-16 05:38:37 --> Config Class Initialized
INFO - 2025-03-16 05:38:37 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:37 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:37 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:37 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:37 --> Router Class Initialized
INFO - 2025-03-16 05:38:37 --> Output Class Initialized
INFO - 2025-03-16 05:38:37 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:37 --> Input Class Initialized
INFO - 2025-03-16 05:38:37 --> Language Class Initialized
INFO - 2025-03-16 05:38:37 --> Language Class Initialized
INFO - 2025-03-16 05:38:37 --> Config Class Initialized
INFO - 2025-03-16 05:38:37 --> Loader Class Initialized
INFO - 2025-03-16 05:38:37 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:37 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:37 --> Email Class Initialized
INFO - 2025-03-16 05:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:37 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:37 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:37 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:37 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:37 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:37 --> Model Class Initialized
INFO - 2025-03-16 05:38:37 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:37 --> Total execution time: 0.0082
INFO - 2025-03-16 05:38:38 --> Config Class Initialized
INFO - 2025-03-16 05:38:38 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:38 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:38 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:38 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:38 --> Router Class Initialized
INFO - 2025-03-16 05:38:38 --> Output Class Initialized
INFO - 2025-03-16 05:38:38 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:38 --> Input Class Initialized
INFO - 2025-03-16 05:38:38 --> Language Class Initialized
INFO - 2025-03-16 05:38:38 --> Language Class Initialized
INFO - 2025-03-16 05:38:38 --> Config Class Initialized
INFO - 2025-03-16 05:38:38 --> Loader Class Initialized
INFO - 2025-03-16 05:38:38 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:38 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:38 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:38 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:38 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:38 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:38 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:38 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:38 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:38 --> Email Class Initialized
INFO - 2025-03-16 05:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:38 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:38 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:38 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:38 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:38 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:38 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:38:38 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:38:38 --> Model Class Initialized
ERROR - 2025-03-16 05:38:38 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:38:38 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:38:38 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:38:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:38:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:38:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance_list.php
DEBUG - 2025-03-16 05:38:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:38:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:38:39 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:39 --> Total execution time: 0.1979
INFO - 2025-03-16 05:38:46 --> Config Class Initialized
INFO - 2025-03-16 05:38:46 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:38:46 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:38:46 --> Utf8 Class Initialized
INFO - 2025-03-16 05:38:46 --> URI Class Initialized
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:38:46 --> Router Class Initialized
INFO - 2025-03-16 05:38:46 --> Output Class Initialized
INFO - 2025-03-16 05:38:46 --> Security Class Initialized
DEBUG - 2025-03-16 05:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:38:46 --> Input Class Initialized
INFO - 2025-03-16 05:38:46 --> Language Class Initialized
INFO - 2025-03-16 05:38:46 --> Language Class Initialized
INFO - 2025-03-16 05:38:46 --> Config Class Initialized
INFO - 2025-03-16 05:38:46 --> Loader Class Initialized
INFO - 2025-03-16 05:38:46 --> Helper loaded: url_helper
INFO - 2025-03-16 05:38:46 --> Helper loaded: file_helper
INFO - 2025-03-16 05:38:46 --> Helper loaded: html_helper
INFO - 2025-03-16 05:38:46 --> Helper loaded: form_helper
INFO - 2025-03-16 05:38:46 --> Helper loaded: text_helper
INFO - 2025-03-16 05:38:46 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:38:46 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:38:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:38:46 --> Database Driver Class Initialized
INFO - 2025-03-16 05:38:46 --> Email Class Initialized
INFO - 2025-03-16 05:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:38:46 --> Form Validation Class Initialized
INFO - 2025-03-16 05:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:38:46 --> Pagination Class Initialized
INFO - 2025-03-16 05:38:46 --> Controller Class Initialized
DEBUG - 2025-03-16 05:38:46 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:38:46 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:38:46 --> Model Class Initialized
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:38:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:38:46 --> Model Class Initialized
ERROR - 2025-03-16 05:38:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:38:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance.php
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:38:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:38:46 --> Final output sent to browser
DEBUG - 2025-03-16 05:38:46 --> Total execution time: 0.1586
INFO - 2025-03-16 05:39:50 --> Config Class Initialized
INFO - 2025-03-16 05:39:50 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:39:50 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:39:50 --> Utf8 Class Initialized
INFO - 2025-03-16 05:39:50 --> URI Class Initialized
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:39:50 --> Router Class Initialized
INFO - 2025-03-16 05:39:50 --> Output Class Initialized
INFO - 2025-03-16 05:39:50 --> Security Class Initialized
DEBUG - 2025-03-16 05:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:39:50 --> Input Class Initialized
INFO - 2025-03-16 05:39:50 --> Language Class Initialized
INFO - 2025-03-16 05:39:50 --> Language Class Initialized
INFO - 2025-03-16 05:39:50 --> Config Class Initialized
INFO - 2025-03-16 05:39:50 --> Loader Class Initialized
INFO - 2025-03-16 05:39:50 --> Helper loaded: url_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: file_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: html_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: form_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: text_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:39:50 --> Database Driver Class Initialized
INFO - 2025-03-16 05:39:50 --> Email Class Initialized
INFO - 2025-03-16 05:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:39:50 --> Form Validation Class Initialized
INFO - 2025-03-16 05:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:39:50 --> Pagination Class Initialized
INFO - 2025-03-16 05:39:50 --> Controller Class Initialized
DEBUG - 2025-03-16 05:39:50 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:39:50 --> Model Class Initialized
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:39:50 --> Model Class Initialized
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:39:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:39:50 --> Model Class Initialized
ERROR - 2025-03-16 05:39:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:39:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/debit_voucher_list.php
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:39:50 --> Final output sent to browser
DEBUG - 2025-03-16 05:39:50 --> Total execution time: 0.1078
INFO - 2025-03-16 05:39:50 --> Config Class Initialized
INFO - 2025-03-16 05:39:50 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:39:50 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:39:50 --> Utf8 Class Initialized
INFO - 2025-03-16 05:39:50 --> URI Class Initialized
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:39:50 --> Router Class Initialized
INFO - 2025-03-16 05:39:50 --> Output Class Initialized
INFO - 2025-03-16 05:39:50 --> Security Class Initialized
DEBUG - 2025-03-16 05:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:39:50 --> Input Class Initialized
INFO - 2025-03-16 05:39:50 --> Language Class Initialized
INFO - 2025-03-16 05:39:50 --> Language Class Initialized
INFO - 2025-03-16 05:39:50 --> Config Class Initialized
INFO - 2025-03-16 05:39:50 --> Loader Class Initialized
INFO - 2025-03-16 05:39:50 --> Helper loaded: url_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: file_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: html_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: form_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: text_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:39:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:39:50 --> Database Driver Class Initialized
INFO - 2025-03-16 05:39:50 --> Email Class Initialized
INFO - 2025-03-16 05:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:39:50 --> Form Validation Class Initialized
INFO - 2025-03-16 05:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:39:50 --> Pagination Class Initialized
INFO - 2025-03-16 05:39:50 --> Controller Class Initialized
DEBUG - 2025-03-16 05:39:50 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:39:50 --> Model Class Initialized
DEBUG - 2025-03-16 05:39:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:39:50 --> Model Class Initialized
INFO - 2025-03-16 05:39:50 --> Final output sent to browser
DEBUG - 2025-03-16 05:39:50 --> Total execution time: 0.0069
INFO - 2025-03-16 05:40:19 --> Config Class Initialized
INFO - 2025-03-16 05:40:19 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:40:19 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:40:19 --> Utf8 Class Initialized
INFO - 2025-03-16 05:40:19 --> URI Class Initialized
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:40:19 --> Router Class Initialized
INFO - 2025-03-16 05:40:19 --> Output Class Initialized
INFO - 2025-03-16 05:40:19 --> Security Class Initialized
DEBUG - 2025-03-16 05:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:40:19 --> Input Class Initialized
INFO - 2025-03-16 05:40:19 --> Language Class Initialized
INFO - 2025-03-16 05:40:19 --> Language Class Initialized
INFO - 2025-03-16 05:40:19 --> Config Class Initialized
INFO - 2025-03-16 05:40:19 --> Loader Class Initialized
INFO - 2025-03-16 05:40:19 --> Helper loaded: url_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: file_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: html_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: form_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: text_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:40:19 --> Database Driver Class Initialized
INFO - 2025-03-16 05:40:19 --> Email Class Initialized
INFO - 2025-03-16 05:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:40:19 --> Form Validation Class Initialized
INFO - 2025-03-16 05:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:40:19 --> Pagination Class Initialized
INFO - 2025-03-16 05:40:19 --> Controller Class Initialized
DEBUG - 2025-03-16 05:40:19 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:40:19 --> Model Class Initialized
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:40:19 --> Model Class Initialized
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:40:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:40:19 --> Model Class Initialized
ERROR - 2025-03-16 05:40:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:40:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/journal_voucher_list.php
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:40:19 --> Final output sent to browser
DEBUG - 2025-03-16 05:40:19 --> Total execution time: 0.0900
INFO - 2025-03-16 05:40:19 --> Config Class Initialized
INFO - 2025-03-16 05:40:19 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:40:19 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:40:19 --> Utf8 Class Initialized
INFO - 2025-03-16 05:40:19 --> URI Class Initialized
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:40:19 --> Router Class Initialized
INFO - 2025-03-16 05:40:19 --> Output Class Initialized
INFO - 2025-03-16 05:40:19 --> Security Class Initialized
DEBUG - 2025-03-16 05:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:40:19 --> Input Class Initialized
INFO - 2025-03-16 05:40:19 --> Language Class Initialized
INFO - 2025-03-16 05:40:19 --> Language Class Initialized
INFO - 2025-03-16 05:40:19 --> Config Class Initialized
INFO - 2025-03-16 05:40:19 --> Loader Class Initialized
INFO - 2025-03-16 05:40:19 --> Helper loaded: url_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: file_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: html_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: form_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: text_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:40:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:40:19 --> Database Driver Class Initialized
INFO - 2025-03-16 05:40:19 --> Email Class Initialized
INFO - 2025-03-16 05:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:40:19 --> Form Validation Class Initialized
INFO - 2025-03-16 05:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:40:19 --> Pagination Class Initialized
INFO - 2025-03-16 05:40:19 --> Controller Class Initialized
DEBUG - 2025-03-16 05:40:19 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:40:19 --> Model Class Initialized
DEBUG - 2025-03-16 05:40:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:40:19 --> Model Class Initialized
INFO - 2025-03-16 05:40:19 --> Final output sent to browser
DEBUG - 2025-03-16 05:40:19 --> Total execution time: 0.0070
INFO - 2025-03-16 05:40:28 --> Config Class Initialized
INFO - 2025-03-16 05:40:28 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:40:28 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:40:28 --> Utf8 Class Initialized
INFO - 2025-03-16 05:40:28 --> URI Class Initialized
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:40:28 --> Router Class Initialized
INFO - 2025-03-16 05:40:28 --> Output Class Initialized
INFO - 2025-03-16 05:40:28 --> Security Class Initialized
DEBUG - 2025-03-16 05:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:40:28 --> Input Class Initialized
INFO - 2025-03-16 05:40:28 --> Language Class Initialized
INFO - 2025-03-16 05:40:28 --> Language Class Initialized
INFO - 2025-03-16 05:40:28 --> Config Class Initialized
INFO - 2025-03-16 05:40:28 --> Loader Class Initialized
INFO - 2025-03-16 05:40:28 --> Helper loaded: url_helper
INFO - 2025-03-16 05:40:28 --> Helper loaded: file_helper
INFO - 2025-03-16 05:40:28 --> Helper loaded: html_helper
INFO - 2025-03-16 05:40:28 --> Helper loaded: form_helper
INFO - 2025-03-16 05:40:28 --> Helper loaded: text_helper
INFO - 2025-03-16 05:40:28 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:40:28 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:40:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:40:28 --> Database Driver Class Initialized
INFO - 2025-03-16 05:40:28 --> Email Class Initialized
INFO - 2025-03-16 05:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:40:28 --> Form Validation Class Initialized
INFO - 2025-03-16 05:40:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:40:28 --> Pagination Class Initialized
INFO - 2025-03-16 05:40:28 --> Controller Class Initialized
DEBUG - 2025-03-16 05:40:28 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:40:28 --> Model Class Initialized
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:40:28 --> Model Class Initialized
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:40:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:40:28 --> Model Class Initialized
ERROR - 2025-03-16 05:40:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:40:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/general_ledger.php
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:40:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:40:28 --> Final output sent to browser
DEBUG - 2025-03-16 05:40:28 --> Total execution time: 0.2132
INFO - 2025-03-16 05:40:40 --> Config Class Initialized
INFO - 2025-03-16 05:40:40 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:40:40 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:40:40 --> Utf8 Class Initialized
INFO - 2025-03-16 05:40:40 --> URI Class Initialized
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:40:40 --> Router Class Initialized
INFO - 2025-03-16 05:40:40 --> Output Class Initialized
INFO - 2025-03-16 05:40:40 --> Security Class Initialized
DEBUG - 2025-03-16 05:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:40:40 --> Input Class Initialized
INFO - 2025-03-16 05:40:40 --> Language Class Initialized
INFO - 2025-03-16 05:40:40 --> Language Class Initialized
INFO - 2025-03-16 05:40:40 --> Config Class Initialized
INFO - 2025-03-16 05:40:40 --> Loader Class Initialized
INFO - 2025-03-16 05:40:40 --> Helper loaded: url_helper
INFO - 2025-03-16 05:40:40 --> Helper loaded: file_helper
INFO - 2025-03-16 05:40:40 --> Helper loaded: html_helper
INFO - 2025-03-16 05:40:40 --> Helper loaded: form_helper
INFO - 2025-03-16 05:40:40 --> Helper loaded: text_helper
INFO - 2025-03-16 05:40:40 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:40:40 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:40:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:40:40 --> Database Driver Class Initialized
INFO - 2025-03-16 05:40:40 --> Email Class Initialized
INFO - 2025-03-16 05:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:40:40 --> Form Validation Class Initialized
INFO - 2025-03-16 05:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:40:40 --> Pagination Class Initialized
INFO - 2025-03-16 05:40:40 --> Controller Class Initialized
DEBUG - 2025-03-16 05:40:40 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:40:40 --> Model Class Initialized
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:40:40 --> Model Class Initialized
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:40:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:40:40 --> Model Class Initialized
ERROR - 2025-03-16 05:40:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:40:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/sub_ledger.php
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:40:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:40:40 --> Final output sent to browser
DEBUG - 2025-03-16 05:40:40 --> Total execution time: 0.1414
INFO - 2025-03-16 05:41:34 --> Config Class Initialized
INFO - 2025-03-16 05:41:34 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:41:34 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:41:34 --> Utf8 Class Initialized
INFO - 2025-03-16 05:41:34 --> URI Class Initialized
DEBUG - 2025-03-16 05:41:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:41:34 --> Router Class Initialized
INFO - 2025-03-16 05:41:34 --> Output Class Initialized
INFO - 2025-03-16 05:41:34 --> Security Class Initialized
DEBUG - 2025-03-16 05:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:41:34 --> Input Class Initialized
INFO - 2025-03-16 05:41:34 --> Language Class Initialized
INFO - 2025-03-16 05:41:34 --> Language Class Initialized
INFO - 2025-03-16 05:41:34 --> Config Class Initialized
INFO - 2025-03-16 05:41:34 --> Loader Class Initialized
INFO - 2025-03-16 05:41:34 --> Helper loaded: url_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: file_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: html_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: form_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: text_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:41:34 --> Database Driver Class Initialized
INFO - 2025-03-16 05:41:34 --> Email Class Initialized
INFO - 2025-03-16 05:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:41:34 --> Form Validation Class Initialized
INFO - 2025-03-16 05:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:41:34 --> Pagination Class Initialized
INFO - 2025-03-16 05:41:34 --> Controller Class Initialized
DEBUG - 2025-03-16 05:41:34 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:41:34 --> Model Class Initialized
DEBUG - 2025-03-16 05:41:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:41:34 --> Model Class Initialized
INFO - 2025-03-16 05:41:34 --> Final output sent to browser
DEBUG - 2025-03-16 05:41:34 --> Total execution time: 0.0062
INFO - 2025-03-16 05:41:34 --> Config Class Initialized
INFO - 2025-03-16 05:41:34 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:41:34 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:41:34 --> Utf8 Class Initialized
INFO - 2025-03-16 05:41:34 --> URI Class Initialized
DEBUG - 2025-03-16 05:41:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:41:34 --> Router Class Initialized
INFO - 2025-03-16 05:41:34 --> Output Class Initialized
INFO - 2025-03-16 05:41:34 --> Security Class Initialized
DEBUG - 2025-03-16 05:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:41:34 --> Input Class Initialized
INFO - 2025-03-16 05:41:34 --> Language Class Initialized
INFO - 2025-03-16 05:41:34 --> Language Class Initialized
INFO - 2025-03-16 05:41:34 --> Config Class Initialized
INFO - 2025-03-16 05:41:34 --> Loader Class Initialized
INFO - 2025-03-16 05:41:34 --> Helper loaded: url_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: file_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: html_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: form_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: text_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:41:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:41:34 --> Database Driver Class Initialized
INFO - 2025-03-16 05:41:34 --> Email Class Initialized
INFO - 2025-03-16 05:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:41:34 --> Form Validation Class Initialized
INFO - 2025-03-16 05:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:41:34 --> Pagination Class Initialized
INFO - 2025-03-16 05:41:34 --> Controller Class Initialized
DEBUG - 2025-03-16 05:41:34 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:41:34 --> Model Class Initialized
DEBUG - 2025-03-16 05:41:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:41:34 --> Model Class Initialized
INFO - 2025-03-16 05:41:34 --> Final output sent to browser
DEBUG - 2025-03-16 05:41:34 --> Total execution time: 0.0058
INFO - 2025-03-16 05:41:41 --> Config Class Initialized
INFO - 2025-03-16 05:41:41 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:41:41 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:41:41 --> Utf8 Class Initialized
INFO - 2025-03-16 05:41:41 --> URI Class Initialized
DEBUG - 2025-03-16 05:41:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:41:41 --> Router Class Initialized
INFO - 2025-03-16 05:41:41 --> Output Class Initialized
INFO - 2025-03-16 05:41:41 --> Security Class Initialized
DEBUG - 2025-03-16 05:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:41:41 --> Input Class Initialized
INFO - 2025-03-16 05:41:41 --> Language Class Initialized
INFO - 2025-03-16 05:41:41 --> Language Class Initialized
INFO - 2025-03-16 05:41:41 --> Config Class Initialized
INFO - 2025-03-16 05:41:41 --> Loader Class Initialized
INFO - 2025-03-16 05:41:41 --> Helper loaded: url_helper
INFO - 2025-03-16 05:41:41 --> Helper loaded: file_helper
INFO - 2025-03-16 05:41:41 --> Helper loaded: html_helper
INFO - 2025-03-16 05:41:41 --> Helper loaded: form_helper
INFO - 2025-03-16 05:41:41 --> Helper loaded: text_helper
INFO - 2025-03-16 05:41:41 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:41:41 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:41:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:41:41 --> Database Driver Class Initialized
INFO - 2025-03-16 05:41:41 --> Email Class Initialized
INFO - 2025-03-16 05:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:41:41 --> Form Validation Class Initialized
INFO - 2025-03-16 05:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:41:41 --> Pagination Class Initialized
INFO - 2025-03-16 05:41:41 --> Controller Class Initialized
DEBUG - 2025-03-16 05:41:41 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:41:41 --> Model Class Initialized
DEBUG - 2025-03-16 05:41:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:41:41 --> Model Class Initialized
INFO - 2025-03-16 05:41:41 --> Final output sent to browser
DEBUG - 2025-03-16 05:41:41 --> Total execution time: 0.0159
INFO - 2025-03-16 05:42:01 --> Config Class Initialized
INFO - 2025-03-16 05:42:01 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:42:01 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:42:01 --> Utf8 Class Initialized
INFO - 2025-03-16 05:42:01 --> URI Class Initialized
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:42:01 --> Router Class Initialized
INFO - 2025-03-16 05:42:01 --> Output Class Initialized
INFO - 2025-03-16 05:42:01 --> Security Class Initialized
DEBUG - 2025-03-16 05:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:42:01 --> Input Class Initialized
INFO - 2025-03-16 05:42:01 --> Language Class Initialized
INFO - 2025-03-16 05:42:01 --> Language Class Initialized
INFO - 2025-03-16 05:42:01 --> Config Class Initialized
INFO - 2025-03-16 05:42:01 --> Loader Class Initialized
INFO - 2025-03-16 05:42:01 --> Helper loaded: url_helper
INFO - 2025-03-16 05:42:01 --> Helper loaded: file_helper
INFO - 2025-03-16 05:42:01 --> Helper loaded: html_helper
INFO - 2025-03-16 05:42:01 --> Helper loaded: form_helper
INFO - 2025-03-16 05:42:01 --> Helper loaded: text_helper
INFO - 2025-03-16 05:42:01 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:42:01 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:42:01 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:42:01 --> Database Driver Class Initialized
INFO - 2025-03-16 05:42:01 --> Email Class Initialized
INFO - 2025-03-16 05:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:42:01 --> Form Validation Class Initialized
INFO - 2025-03-16 05:42:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:42:01 --> Pagination Class Initialized
INFO - 2025-03-16 05:42:01 --> Controller Class Initialized
DEBUG - 2025-03-16 05:42:01 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:42:01 --> Model Class Initialized
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:42:01 --> Model Class Initialized
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:42:01 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:42:01 --> Model Class Initialized
ERROR - 2025-03-16 05:42:01 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:42:01 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subl_ledger_report.php
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:42:01 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:42:01 --> Final output sent to browser
DEBUG - 2025-03-16 05:42:01 --> Total execution time: 0.1634
INFO - 2025-03-16 05:42:19 --> Config Class Initialized
INFO - 2025-03-16 05:42:19 --> Hooks Class Initialized
DEBUG - 2025-03-16 05:42:19 --> UTF-8 Support Enabled
INFO - 2025-03-16 05:42:19 --> Utf8 Class Initialized
INFO - 2025-03-16 05:42:19 --> URI Class Initialized
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 05:42:19 --> Router Class Initialized
INFO - 2025-03-16 05:42:19 --> Output Class Initialized
INFO - 2025-03-16 05:42:19 --> Security Class Initialized
DEBUG - 2025-03-16 05:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 05:42:19 --> Input Class Initialized
INFO - 2025-03-16 05:42:19 --> Language Class Initialized
INFO - 2025-03-16 05:42:19 --> Language Class Initialized
INFO - 2025-03-16 05:42:19 --> Config Class Initialized
INFO - 2025-03-16 05:42:19 --> Loader Class Initialized
INFO - 2025-03-16 05:42:19 --> Helper loaded: url_helper
INFO - 2025-03-16 05:42:19 --> Helper loaded: file_helper
INFO - 2025-03-16 05:42:19 --> Helper loaded: html_helper
INFO - 2025-03-16 05:42:19 --> Helper loaded: form_helper
INFO - 2025-03-16 05:42:19 --> Helper loaded: text_helper
INFO - 2025-03-16 05:42:19 --> Helper loaded: lang_helper
INFO - 2025-03-16 05:42:19 --> Helper loaded: directory_helper
INFO - 2025-03-16 05:42:19 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 05:42:19 --> Database Driver Class Initialized
INFO - 2025-03-16 05:42:19 --> Email Class Initialized
INFO - 2025-03-16 05:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 05:42:19 --> Form Validation Class Initialized
INFO - 2025-03-16 05:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 05:42:19 --> Pagination Class Initialized
INFO - 2025-03-16 05:42:19 --> Controller Class Initialized
DEBUG - 2025-03-16 05:42:19 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 05:42:19 --> Model Class Initialized
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 05:42:19 --> Model Class Initialized
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 05:42:19 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 05:42:19 --> Model Class Initialized
ERROR - 2025-03-16 05:42:19 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 05:42:19 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subl_ledger_report.php
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 05:42:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 05:42:19 --> Final output sent to browser
DEBUG - 2025-03-16 05:42:19 --> Total execution time: 0.2242
INFO - 2025-03-16 06:06:25 --> Config Class Initialized
INFO - 2025-03-16 06:06:25 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:06:25 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:06:25 --> Utf8 Class Initialized
INFO - 2025-03-16 06:06:25 --> URI Class Initialized
DEBUG - 2025-03-16 06:06:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:06:25 --> Router Class Initialized
INFO - 2025-03-16 06:06:25 --> Output Class Initialized
INFO - 2025-03-16 06:06:25 --> Security Class Initialized
DEBUG - 2025-03-16 06:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:06:25 --> Input Class Initialized
INFO - 2025-03-16 06:06:25 --> Language Class Initialized
INFO - 2025-03-16 06:06:25 --> Language Class Initialized
INFO - 2025-03-16 06:06:25 --> Config Class Initialized
INFO - 2025-03-16 06:06:25 --> Loader Class Initialized
INFO - 2025-03-16 06:06:25 --> Helper loaded: url_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: file_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: html_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: form_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: text_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:06:25 --> Database Driver Class Initialized
INFO - 2025-03-16 06:06:25 --> Email Class Initialized
INFO - 2025-03-16 06:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:06:25 --> Form Validation Class Initialized
INFO - 2025-03-16 06:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:06:25 --> Pagination Class Initialized
INFO - 2025-03-16 06:06:25 --> Controller Class Initialized
DEBUG - 2025-03-16 06:06:25 --> Auth MX_Controller Initialized
INFO - 2025-03-16 06:06:25 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 06:06:25 --> Model Class Initialized
INFO - 2025-03-16 06:06:25 --> Config Class Initialized
INFO - 2025-03-16 06:06:25 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:06:25 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:06:25 --> Utf8 Class Initialized
INFO - 2025-03-16 06:06:25 --> URI Class Initialized
DEBUG - 2025-03-16 06:06:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:06:25 --> Router Class Initialized
INFO - 2025-03-16 06:06:25 --> Output Class Initialized
INFO - 2025-03-16 06:06:25 --> Security Class Initialized
DEBUG - 2025-03-16 06:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:06:25 --> Input Class Initialized
INFO - 2025-03-16 06:06:25 --> Language Class Initialized
INFO - 2025-03-16 06:06:25 --> Language Class Initialized
INFO - 2025-03-16 06:06:25 --> Config Class Initialized
INFO - 2025-03-16 06:06:25 --> Loader Class Initialized
INFO - 2025-03-16 06:06:25 --> Helper loaded: url_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: file_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: html_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: form_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: text_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:06:25 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:06:25 --> Database Driver Class Initialized
INFO - 2025-03-16 06:06:25 --> Email Class Initialized
INFO - 2025-03-16 06:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:06:25 --> Form Validation Class Initialized
INFO - 2025-03-16 06:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:06:25 --> Pagination Class Initialized
INFO - 2025-03-16 06:06:25 --> Controller Class Initialized
DEBUG - 2025-03-16 06:06:25 --> Auth MX_Controller Initialized
INFO - 2025-03-16 06:06:25 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 06:06:25 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:06:25 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:06:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:06:25 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:25 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-16 06:06:25 --> Final output sent to browser
DEBUG - 2025-03-16 06:06:25 --> Total execution time: 0.0174
INFO - 2025-03-16 06:06:30 --> Config Class Initialized
INFO - 2025-03-16 06:06:30 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:06:30 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:06:30 --> Utf8 Class Initialized
INFO - 2025-03-16 06:06:30 --> URI Class Initialized
DEBUG - 2025-03-16 06:06:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:06:30 --> Router Class Initialized
INFO - 2025-03-16 06:06:30 --> Output Class Initialized
INFO - 2025-03-16 06:06:30 --> Security Class Initialized
DEBUG - 2025-03-16 06:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:06:30 --> Input Class Initialized
INFO - 2025-03-16 06:06:30 --> Language Class Initialized
INFO - 2025-03-16 06:06:30 --> Language Class Initialized
INFO - 2025-03-16 06:06:30 --> Config Class Initialized
INFO - 2025-03-16 06:06:30 --> Loader Class Initialized
INFO - 2025-03-16 06:06:30 --> Helper loaded: url_helper
INFO - 2025-03-16 06:06:30 --> Helper loaded: file_helper
INFO - 2025-03-16 06:06:30 --> Helper loaded: html_helper
INFO - 2025-03-16 06:06:30 --> Helper loaded: form_helper
INFO - 2025-03-16 06:06:30 --> Helper loaded: text_helper
INFO - 2025-03-16 06:06:30 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:06:30 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:06:30 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:06:30 --> Database Driver Class Initialized
INFO - 2025-03-16 06:06:30 --> Email Class Initialized
INFO - 2025-03-16 06:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:06:30 --> Form Validation Class Initialized
INFO - 2025-03-16 06:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:06:30 --> Pagination Class Initialized
INFO - 2025-03-16 06:06:30 --> Controller Class Initialized
DEBUG - 2025-03-16 06:06:30 --> Auth MX_Controller Initialized
INFO - 2025-03-16 06:06:30 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 06:06:30 --> Model Class Initialized
INFO - 2025-03-16 06:06:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-03-16 06:06:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:06:30 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:06:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:06:30 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:30 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-16 06:06:30 --> Final output sent to browser
DEBUG - 2025-03-16 06:06:30 --> Total execution time: 0.0175
INFO - 2025-03-16 06:06:46 --> Config Class Initialized
INFO - 2025-03-16 06:06:46 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:06:46 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:06:46 --> Utf8 Class Initialized
INFO - 2025-03-16 06:06:46 --> URI Class Initialized
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:06:46 --> Router Class Initialized
INFO - 2025-03-16 06:06:46 --> Output Class Initialized
INFO - 2025-03-16 06:06:46 --> Security Class Initialized
DEBUG - 2025-03-16 06:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:06:46 --> Input Class Initialized
INFO - 2025-03-16 06:06:46 --> Language Class Initialized
INFO - 2025-03-16 06:06:46 --> Language Class Initialized
INFO - 2025-03-16 06:06:46 --> Config Class Initialized
INFO - 2025-03-16 06:06:46 --> Loader Class Initialized
INFO - 2025-03-16 06:06:46 --> Helper loaded: url_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: file_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: html_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: form_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: text_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:06:46 --> Database Driver Class Initialized
INFO - 2025-03-16 06:06:46 --> Email Class Initialized
INFO - 2025-03-16 06:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:06:46 --> Form Validation Class Initialized
INFO - 2025-03-16 06:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:06:46 --> Pagination Class Initialized
INFO - 2025-03-16 06:06:46 --> Controller Class Initialized
DEBUG - 2025-03-16 06:06:46 --> Auth MX_Controller Initialized
INFO - 2025-03-16 06:06:46 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 06:06:46 --> Model Class Initialized
INFO - 2025-03-16 06:06:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-16 06:06:46 --> Config Class Initialized
INFO - 2025-03-16 06:06:46 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:06:46 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:06:46 --> Utf8 Class Initialized
INFO - 2025-03-16 06:06:46 --> URI Class Initialized
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:06:46 --> Router Class Initialized
INFO - 2025-03-16 06:06:46 --> Output Class Initialized
INFO - 2025-03-16 06:06:46 --> Security Class Initialized
DEBUG - 2025-03-16 06:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:06:46 --> Input Class Initialized
INFO - 2025-03-16 06:06:46 --> Language Class Initialized
INFO - 2025-03-16 06:06:46 --> Language Class Initialized
INFO - 2025-03-16 06:06:46 --> Config Class Initialized
INFO - 2025-03-16 06:06:46 --> Loader Class Initialized
INFO - 2025-03-16 06:06:46 --> Helper loaded: url_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: file_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: html_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: form_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: text_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:06:46 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:06:46 --> Database Driver Class Initialized
INFO - 2025-03-16 06:06:46 --> Email Class Initialized
INFO - 2025-03-16 06:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:06:46 --> Form Validation Class Initialized
INFO - 2025-03-16 06:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:06:46 --> Pagination Class Initialized
INFO - 2025-03-16 06:06:46 --> Controller Class Initialized
DEBUG - 2025-03-16 06:06:46 --> Home MX_Controller Initialized
INFO - 2025-03-16 06:06:46 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-16 06:06:46 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:06:46 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:06:46 --> Model Class Initialized
ERROR - 2025-03-16 06:06:46 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:06:46 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 06:06:46 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 06:06:46 --> Final output sent to browser
DEBUG - 2025-03-16 06:06:46 --> Total execution time: 0.3206
INFO - 2025-03-16 06:06:53 --> Config Class Initialized
INFO - 2025-03-16 06:06:53 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:06:53 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:06:53 --> Utf8 Class Initialized
INFO - 2025-03-16 06:06:53 --> URI Class Initialized
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:06:53 --> Router Class Initialized
INFO - 2025-03-16 06:06:53 --> Output Class Initialized
INFO - 2025-03-16 06:06:53 --> Security Class Initialized
DEBUG - 2025-03-16 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:06:53 --> Input Class Initialized
INFO - 2025-03-16 06:06:53 --> Language Class Initialized
INFO - 2025-03-16 06:06:53 --> Language Class Initialized
INFO - 2025-03-16 06:06:53 --> Config Class Initialized
INFO - 2025-03-16 06:06:53 --> Loader Class Initialized
INFO - 2025-03-16 06:06:53 --> Helper loaded: url_helper
INFO - 2025-03-16 06:06:53 --> Helper loaded: file_helper
INFO - 2025-03-16 06:06:53 --> Helper loaded: html_helper
INFO - 2025-03-16 06:06:53 --> Helper loaded: form_helper
INFO - 2025-03-16 06:06:53 --> Helper loaded: text_helper
INFO - 2025-03-16 06:06:53 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:06:53 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:06:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:06:53 --> Database Driver Class Initialized
INFO - 2025-03-16 06:06:53 --> Email Class Initialized
INFO - 2025-03-16 06:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:06:53 --> Form Validation Class Initialized
INFO - 2025-03-16 06:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:06:53 --> Pagination Class Initialized
INFO - 2025-03-16 06:06:53 --> Controller Class Initialized
DEBUG - 2025-03-16 06:06:53 --> Backup_restore MX_Controller Initialized
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:06:53 --> Template MX_Controller Initialized
INFO - 2025-03-16 06:06:53 --> Model Class Initialized
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:06:53 --> Model Class Initialized
ERROR - 2025-03-16 06:06:53 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:06:53 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/backup_restore/import.php
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 06:06:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 06:06:53 --> Final output sent to browser
DEBUG - 2025-03-16 06:06:53 --> Total execution time: 0.0981
INFO - 2025-03-16 06:07:12 --> Config Class Initialized
INFO - 2025-03-16 06:07:12 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:07:12 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:07:12 --> Utf8 Class Initialized
INFO - 2025-03-16 06:07:12 --> URI Class Initialized
DEBUG - 2025-03-16 06:07:12 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:07:12 --> Router Class Initialized
INFO - 2025-03-16 06:07:12 --> Output Class Initialized
INFO - 2025-03-16 06:07:12 --> Security Class Initialized
DEBUG - 2025-03-16 06:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:07:12 --> Input Class Initialized
INFO - 2025-03-16 06:07:12 --> Language Class Initialized
INFO - 2025-03-16 06:07:12 --> Language Class Initialized
INFO - 2025-03-16 06:07:12 --> Config Class Initialized
INFO - 2025-03-16 06:07:12 --> Loader Class Initialized
INFO - 2025-03-16 06:07:12 --> Helper loaded: url_helper
INFO - 2025-03-16 06:07:12 --> Helper loaded: file_helper
INFO - 2025-03-16 06:07:12 --> Helper loaded: html_helper
INFO - 2025-03-16 06:07:12 --> Helper loaded: form_helper
INFO - 2025-03-16 06:07:12 --> Helper loaded: text_helper
INFO - 2025-03-16 06:07:12 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:07:12 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:07:12 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:07:12 --> Database Driver Class Initialized
INFO - 2025-03-16 06:07:12 --> Email Class Initialized
INFO - 2025-03-16 06:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:07:12 --> Form Validation Class Initialized
INFO - 2025-03-16 06:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:07:12 --> Pagination Class Initialized
INFO - 2025-03-16 06:07:12 --> Controller Class Initialized
DEBUG - 2025-03-16 06:07:12 --> Backup_restore MX_Controller Initialized
INFO - 2025-03-16 06:07:12 --> Upload Class Initialized
INFO - 2025-03-16 06:12:51 --> Config Class Initialized
INFO - 2025-03-16 06:12:51 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:12:51 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:12:51 --> Utf8 Class Initialized
INFO - 2025-03-16 06:12:51 --> URI Class Initialized
DEBUG - 2025-03-16 06:12:51 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:12:51 --> Router Class Initialized
INFO - 2025-03-16 06:12:51 --> Output Class Initialized
INFO - 2025-03-16 06:12:51 --> Security Class Initialized
DEBUG - 2025-03-16 06:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:12:51 --> Input Class Initialized
INFO - 2025-03-16 06:12:51 --> Language Class Initialized
ERROR - 2025-03-16 06:12:51 --> 404 Page Not Found: ../modules/dashboard/controllers//index
INFO - 2025-03-16 06:12:54 --> Config Class Initialized
INFO - 2025-03-16 06:12:54 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:12:54 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:12:54 --> Utf8 Class Initialized
INFO - 2025-03-16 06:12:58 --> Config Class Initialized
INFO - 2025-03-16 06:12:58 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:12:58 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:12:58 --> Utf8 Class Initialized
INFO - 2025-03-16 06:12:58 --> URI Class Initialized
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-16 06:12:58 --> No URI present. Default controller set.
INFO - 2025-03-16 06:12:58 --> Router Class Initialized
INFO - 2025-03-16 06:12:58 --> Output Class Initialized
INFO - 2025-03-16 06:12:58 --> Security Class Initialized
DEBUG - 2025-03-16 06:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:12:58 --> Input Class Initialized
INFO - 2025-03-16 06:12:58 --> Language Class Initialized
INFO - 2025-03-16 06:12:58 --> Language Class Initialized
INFO - 2025-03-16 06:12:58 --> Config Class Initialized
INFO - 2025-03-16 06:12:58 --> Loader Class Initialized
INFO - 2025-03-16 06:12:58 --> Helper loaded: url_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: file_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: html_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: form_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: text_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:12:58 --> Database Driver Class Initialized
INFO - 2025-03-16 06:12:58 --> Email Class Initialized
INFO - 2025-03-16 06:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:12:58 --> Form Validation Class Initialized
INFO - 2025-03-16 06:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:12:58 --> Pagination Class Initialized
INFO - 2025-03-16 06:12:58 --> Controller Class Initialized
DEBUG - 2025-03-16 06:12:58 --> Auth MX_Controller Initialized
INFO - 2025-03-16 06:12:58 --> Model Class Initialized
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 06:12:58 --> Model Class Initialized
INFO - 2025-03-16 06:12:58 --> Config Class Initialized
INFO - 2025-03-16 06:12:58 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:12:58 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:12:58 --> Utf8 Class Initialized
INFO - 2025-03-16 06:12:58 --> URI Class Initialized
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:12:58 --> Router Class Initialized
INFO - 2025-03-16 06:12:58 --> Output Class Initialized
INFO - 2025-03-16 06:12:58 --> Security Class Initialized
DEBUG - 2025-03-16 06:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:12:58 --> Input Class Initialized
INFO - 2025-03-16 06:12:58 --> Language Class Initialized
INFO - 2025-03-16 06:12:58 --> Language Class Initialized
INFO - 2025-03-16 06:12:58 --> Config Class Initialized
INFO - 2025-03-16 06:12:58 --> Loader Class Initialized
INFO - 2025-03-16 06:12:58 --> Helper loaded: url_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: file_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: html_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: form_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: text_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:12:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:12:58 --> Database Driver Class Initialized
INFO - 2025-03-16 06:12:58 --> Email Class Initialized
INFO - 2025-03-16 06:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:12:58 --> Form Validation Class Initialized
INFO - 2025-03-16 06:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:12:58 --> Pagination Class Initialized
INFO - 2025-03-16 06:12:58 --> Controller Class Initialized
DEBUG - 2025-03-16 06:12:58 --> Home MX_Controller Initialized
INFO - 2025-03-16 06:12:58 --> Model Class Initialized
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-16 06:12:58 --> Model Class Initialized
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:12:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:12:58 --> Model Class Initialized
ERROR - 2025-03-16 06:12:58 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 28
ERROR - 2025-03-16 06:12:58 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 28
ERROR - 2025-03-16 06:12:58 --> Severity: Warning --> Attempt to read property "discount_type" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 29
ERROR - 2025-03-16 06:12:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:12:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:12:58 --> Severity: Warning --> Attempt to read property "currency" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 33
ERROR - 2025-03-16 06:12:58 --> Severity: Warning --> Attempt to read property "currency_position" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 34
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 06:12:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 06:12:58 --> Final output sent to browser
DEBUG - 2025-03-16 06:12:58 --> Total execution time: 0.0817
INFO - 2025-03-16 06:13:08 --> Config Class Initialized
INFO - 2025-03-16 06:13:08 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:13:08 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:13:08 --> Utf8 Class Initialized
INFO - 2025-03-16 06:13:08 --> URI Class Initialized
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:13:08 --> Router Class Initialized
INFO - 2025-03-16 06:13:08 --> Output Class Initialized
INFO - 2025-03-16 06:13:08 --> Security Class Initialized
DEBUG - 2025-03-16 06:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:13:08 --> Input Class Initialized
INFO - 2025-03-16 06:13:08 --> Language Class Initialized
INFO - 2025-03-16 06:13:08 --> Language Class Initialized
INFO - 2025-03-16 06:13:08 --> Config Class Initialized
INFO - 2025-03-16 06:13:08 --> Loader Class Initialized
INFO - 2025-03-16 06:13:08 --> Helper loaded: url_helper
INFO - 2025-03-16 06:13:08 --> Helper loaded: file_helper
INFO - 2025-03-16 06:13:08 --> Helper loaded: html_helper
INFO - 2025-03-16 06:13:08 --> Helper loaded: form_helper
INFO - 2025-03-16 06:13:08 --> Helper loaded: text_helper
INFO - 2025-03-16 06:13:08 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:13:08 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:13:08 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:13:08 --> Database Driver Class Initialized
INFO - 2025-03-16 06:13:08 --> Email Class Initialized
INFO - 2025-03-16 06:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:13:08 --> Form Validation Class Initialized
INFO - 2025-03-16 06:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:13:08 --> Pagination Class Initialized
INFO - 2025-03-16 06:13:08 --> Controller Class Initialized
DEBUG - 2025-03-16 06:13:08 --> Home MX_Controller Initialized
INFO - 2025-03-16 06:13:08 --> Model Class Initialized
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-16 06:13:08 --> Model Class Initialized
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:13:08 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:13:08 --> Model Class Initialized
ERROR - 2025-03-16 06:13:08 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 28
ERROR - 2025-03-16 06:13:08 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 28
ERROR - 2025-03-16 06:13:08 --> Severity: Warning --> Attempt to read property "discount_type" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 29
ERROR - 2025-03-16 06:13:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:13:08 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:13:08 --> Severity: Warning --> Attempt to read property "currency" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 33
ERROR - 2025-03-16 06:13:08 --> Severity: Warning --> Attempt to read property "currency_position" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 34
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 06:13:08 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 06:13:08 --> Final output sent to browser
DEBUG - 2025-03-16 06:13:08 --> Total execution time: 0.0538
INFO - 2025-03-16 06:13:10 --> Config Class Initialized
INFO - 2025-03-16 06:13:10 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:13:10 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:13:10 --> Utf8 Class Initialized
INFO - 2025-03-16 06:13:10 --> URI Class Initialized
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:13:10 --> Router Class Initialized
INFO - 2025-03-16 06:13:10 --> Output Class Initialized
INFO - 2025-03-16 06:13:10 --> Security Class Initialized
DEBUG - 2025-03-16 06:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:13:10 --> Input Class Initialized
INFO - 2025-03-16 06:13:10 --> Language Class Initialized
INFO - 2025-03-16 06:13:10 --> Language Class Initialized
INFO - 2025-03-16 06:13:10 --> Config Class Initialized
INFO - 2025-03-16 06:13:10 --> Loader Class Initialized
INFO - 2025-03-16 06:13:10 --> Helper loaded: url_helper
INFO - 2025-03-16 06:13:10 --> Helper loaded: file_helper
INFO - 2025-03-16 06:13:10 --> Helper loaded: html_helper
INFO - 2025-03-16 06:13:10 --> Helper loaded: form_helper
INFO - 2025-03-16 06:13:10 --> Helper loaded: text_helper
INFO - 2025-03-16 06:13:10 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:13:10 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:13:10 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:13:10 --> Database Driver Class Initialized
INFO - 2025-03-16 06:13:10 --> Email Class Initialized
INFO - 2025-03-16 06:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:13:10 --> Form Validation Class Initialized
INFO - 2025-03-16 06:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:13:10 --> Pagination Class Initialized
INFO - 2025-03-16 06:13:10 --> Controller Class Initialized
DEBUG - 2025-03-16 06:13:10 --> Home MX_Controller Initialized
INFO - 2025-03-16 06:13:10 --> Model Class Initialized
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-16 06:13:10 --> Model Class Initialized
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:13:10 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:13:10 --> Model Class Initialized
ERROR - 2025-03-16 06:13:10 --> Severity: Warning --> Trying to access array offset on false /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 28
ERROR - 2025-03-16 06:13:10 --> Severity: Warning --> Trying to access array offset on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 28
ERROR - 2025-03-16 06:13:10 --> Severity: Warning --> Attempt to read property "discount_type" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 29
ERROR - 2025-03-16 06:13:10 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:13:10 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:13:10 --> Severity: Warning --> Attempt to read property "currency" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 33
ERROR - 2025-03-16 06:13:10 --> Severity: Warning --> Attempt to read property "currency_position" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 34
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 06:13:10 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 06:13:10 --> Final output sent to browser
DEBUG - 2025-03-16 06:13:10 --> Total execution time: 0.0496
INFO - 2025-03-16 06:18:39 --> Config Class Initialized
INFO - 2025-03-16 06:18:39 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:18:39 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:18:39 --> Utf8 Class Initialized
INFO - 2025-03-16 06:18:39 --> URI Class Initialized
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 06:18:39 --> Router Class Initialized
INFO - 2025-03-16 06:18:39 --> Output Class Initialized
INFO - 2025-03-16 06:18:39 --> Security Class Initialized
DEBUG - 2025-03-16 06:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:18:39 --> Input Class Initialized
INFO - 2025-03-16 06:18:39 --> Language Class Initialized
INFO - 2025-03-16 06:18:39 --> Language Class Initialized
INFO - 2025-03-16 06:18:39 --> Config Class Initialized
INFO - 2025-03-16 06:18:39 --> Loader Class Initialized
INFO - 2025-03-16 06:18:39 --> Helper loaded: url_helper
INFO - 2025-03-16 06:18:39 --> Helper loaded: file_helper
INFO - 2025-03-16 06:18:39 --> Helper loaded: html_helper
INFO - 2025-03-16 06:18:39 --> Helper loaded: form_helper
INFO - 2025-03-16 06:18:39 --> Helper loaded: text_helper
INFO - 2025-03-16 06:18:39 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:18:39 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:18:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:18:39 --> Database Driver Class Initialized
INFO - 2025-03-16 06:18:39 --> Email Class Initialized
INFO - 2025-03-16 06:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:18:39 --> Form Validation Class Initialized
INFO - 2025-03-16 06:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:18:39 --> Pagination Class Initialized
INFO - 2025-03-16 06:18:39 --> Controller Class Initialized
DEBUG - 2025-03-16 06:18:39 --> Home MX_Controller Initialized
INFO - 2025-03-16 06:18:39 --> Model Class Initialized
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-16 06:18:39 --> Model Class Initialized
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:18:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:18:39 --> Model Class Initialized
ERROR - 2025-03-16 06:18:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:18:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 06:18:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 06:18:39 --> Final output sent to browser
DEBUG - 2025-03-16 06:18:39 --> Total execution time: 0.1039
INFO - 2025-03-16 06:19:03 --> Config Class Initialized
INFO - 2025-03-16 06:19:03 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:19:03 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:19:03 --> Utf8 Class Initialized
INFO - 2025-03-16 06:19:03 --> URI Class Initialized
DEBUG - 2025-03-16 06:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-16 06:19:03 --> Router Class Initialized
INFO - 2025-03-16 06:19:03 --> Output Class Initialized
INFO - 2025-03-16 06:19:03 --> Security Class Initialized
DEBUG - 2025-03-16 06:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:19:03 --> Input Class Initialized
INFO - 2025-03-16 06:19:03 --> Language Class Initialized
INFO - 2025-03-16 06:19:03 --> Language Class Initialized
INFO - 2025-03-16 06:19:03 --> Config Class Initialized
INFO - 2025-03-16 06:19:03 --> Loader Class Initialized
INFO - 2025-03-16 06:19:03 --> Helper loaded: url_helper
INFO - 2025-03-16 06:19:03 --> Helper loaded: file_helper
INFO - 2025-03-16 06:19:03 --> Helper loaded: html_helper
INFO - 2025-03-16 06:19:03 --> Helper loaded: form_helper
INFO - 2025-03-16 06:19:03 --> Helper loaded: text_helper
INFO - 2025-03-16 06:19:03 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:19:03 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:19:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:19:03 --> Database Driver Class Initialized
INFO - 2025-03-16 06:19:03 --> Email Class Initialized
INFO - 2025-03-16 06:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:19:03 --> Form Validation Class Initialized
INFO - 2025-03-16 06:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:19:03 --> Pagination Class Initialized
INFO - 2025-03-16 06:19:03 --> Controller Class Initialized
DEBUG - 2025-03-16 06:19:03 --> Invoice MX_Controller Initialized
INFO - 2025-03-16 12:19:03 --> Model Class Initialized
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 12:19:03 --> Model Class Initialized
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 12:19:03 --> Model Class Initialized
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 12:19:03 --> Model Class Initialized
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 12:19:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 12:19:03 --> Model Class Initialized
ERROR - 2025-03-16 12:19:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 12:19:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/terms_form.php
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 12:19:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 12:19:03 --> Final output sent to browser
DEBUG - 2025-03-16 12:19:03 --> Total execution time: 0.1393
INFO - 2025-03-16 06:27:41 --> Config Class Initialized
INFO - 2025-03-16 06:27:41 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:27:41 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:27:41 --> Utf8 Class Initialized
INFO - 2025-03-16 06:27:41 --> URI Class Initialized
DEBUG - 2025-03-16 06:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/config/routes.php
INFO - 2025-03-16 06:27:41 --> Router Class Initialized
INFO - 2025-03-16 06:27:41 --> Output Class Initialized
INFO - 2025-03-16 06:27:41 --> Security Class Initialized
DEBUG - 2025-03-16 06:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:27:41 --> Input Class Initialized
INFO - 2025-03-16 06:27:41 --> Language Class Initialized
INFO - 2025-03-16 06:27:41 --> Language Class Initialized
INFO - 2025-03-16 06:27:41 --> Config Class Initialized
INFO - 2025-03-16 06:27:41 --> Loader Class Initialized
INFO - 2025-03-16 06:27:41 --> Helper loaded: url_helper
INFO - 2025-03-16 06:27:41 --> Helper loaded: file_helper
INFO - 2025-03-16 06:27:41 --> Helper loaded: html_helper
INFO - 2025-03-16 06:27:41 --> Helper loaded: form_helper
INFO - 2025-03-16 06:27:41 --> Helper loaded: text_helper
INFO - 2025-03-16 06:27:41 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:27:41 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:27:41 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:27:41 --> Database Driver Class Initialized
INFO - 2025-03-16 06:27:41 --> Email Class Initialized
INFO - 2025-03-16 06:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:27:41 --> Form Validation Class Initialized
INFO - 2025-03-16 06:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:27:41 --> Pagination Class Initialized
INFO - 2025-03-16 06:27:41 --> Controller Class Initialized
DEBUG - 2025-03-16 06:27:41 --> Invoice MX_Controller Initialized
INFO - 2025-03-16 12:27:41 --> Model Class Initialized
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/models/Invoice_model.php
INFO - 2025-03-16 12:27:41 --> Model Class Initialized
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 12:27:41 --> Model Class Initialized
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 12:27:41 --> Model Class Initialized
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 12:27:41 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 12:27:41 --> Model Class Initialized
ERROR - 2025-03-16 12:27:41 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 12:27:41 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/invoice/views/terms_list.php
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 12:27:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 12:27:41 --> Final output sent to browser
DEBUG - 2025-03-16 12:27:41 --> Total execution time: 0.1561
INFO - 2025-03-16 06:27:49 --> Config Class Initialized
INFO - 2025-03-16 06:27:49 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:27:49 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:27:49 --> Utf8 Class Initialized
INFO - 2025-03-16 06:27:49 --> URI Class Initialized
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-16 06:27:49 --> Router Class Initialized
INFO - 2025-03-16 06:27:49 --> Output Class Initialized
INFO - 2025-03-16 06:27:49 --> Security Class Initialized
DEBUG - 2025-03-16 06:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:27:49 --> Input Class Initialized
INFO - 2025-03-16 06:27:49 --> Language Class Initialized
INFO - 2025-03-16 06:27:49 --> Language Class Initialized
INFO - 2025-03-16 06:27:49 --> Config Class Initialized
INFO - 2025-03-16 06:27:49 --> Loader Class Initialized
INFO - 2025-03-16 06:27:49 --> Helper loaded: url_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: file_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: html_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: form_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: text_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:27:49 --> Database Driver Class Initialized
INFO - 2025-03-16 06:27:49 --> Email Class Initialized
INFO - 2025-03-16 06:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:27:49 --> Form Validation Class Initialized
INFO - 2025-03-16 06:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:27:49 --> Pagination Class Initialized
INFO - 2025-03-16 06:27:49 --> Controller Class Initialized
DEBUG - 2025-03-16 06:27:49 --> Customer MX_Controller Initialized
INFO - 2025-03-16 06:27:49 --> Model Class Initialized
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 06:27:49 --> Model Class Initialized
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 06:27:49 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 06:27:49 --> Model Class Initialized
ERROR - 2025-03-16 06:27:49 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 06:27:49 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/views/customer_list.php
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 06:27:49 --> Final output sent to browser
DEBUG - 2025-03-16 06:27:49 --> Total execution time: 0.1538
INFO - 2025-03-16 06:27:49 --> Config Class Initialized
INFO - 2025-03-16 06:27:49 --> Hooks Class Initialized
DEBUG - 2025-03-16 06:27:49 --> UTF-8 Support Enabled
INFO - 2025-03-16 06:27:49 --> Utf8 Class Initialized
INFO - 2025-03-16 06:27:49 --> URI Class Initialized
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/config/routes.php
INFO - 2025-03-16 06:27:49 --> Router Class Initialized
INFO - 2025-03-16 06:27:49 --> Output Class Initialized
INFO - 2025-03-16 06:27:49 --> Security Class Initialized
DEBUG - 2025-03-16 06:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 06:27:49 --> Input Class Initialized
INFO - 2025-03-16 06:27:49 --> Language Class Initialized
INFO - 2025-03-16 06:27:49 --> Language Class Initialized
INFO - 2025-03-16 06:27:49 --> Config Class Initialized
INFO - 2025-03-16 06:27:49 --> Loader Class Initialized
INFO - 2025-03-16 06:27:49 --> Helper loaded: url_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: file_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: html_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: form_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: text_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: lang_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: directory_helper
INFO - 2025-03-16 06:27:49 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 06:27:49 --> Database Driver Class Initialized
INFO - 2025-03-16 06:27:49 --> Email Class Initialized
INFO - 2025-03-16 06:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 06:27:49 --> Form Validation Class Initialized
INFO - 2025-03-16 06:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 06:27:49 --> Pagination Class Initialized
INFO - 2025-03-16 06:27:49 --> Controller Class Initialized
DEBUG - 2025-03-16 06:27:49 --> Customer MX_Controller Initialized
INFO - 2025-03-16 06:27:49 --> Model Class Initialized
DEBUG - 2025-03-16 06:27:49 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/customer/models/Customer_model.php
INFO - 2025-03-16 06:27:49 --> Model Class Initialized
ERROR - 2025-03-16 06:27:49 --> DEBUG: getCustomerList() called.
ERROR - 2025-03-16 06:27:49 --> DEBUG: Received customer_id = null
ERROR - 2025-03-16 06:27:49 --> DEBUG: Received customfiled = null
ERROR - 2025-03-16 06:27:49 --> DEBUG: Search Value = 
ERROR - 2025-03-16 06:27:49 --> DEBUG: Counting total records...
ERROR - 2025-03-16 06:27:49 --> DEBUG: Total Records = 9
ERROR - 2025-03-16 06:27:49 --> DEBUG: Fetching filtered records...
ERROR - 2025-03-16 06:27:49 --> DEBUG: Records fetched -> [{"customer_id":"23","customer_name":"Americas Best Wings","customer_address":"830 North Rolling Road","customer_mobile":"4248669552","customer_email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"21228","country":"United States","status":"1","balance":"0.00"},{"customer_id":"15","customer_name":"Md. Faiz Shiraji","customer_address":"80\/2 West Rampura","customer_mobile":"01791631664","customer_email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"1219","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"20","customer_name":"Mofajjol Hossain","customer_address":"Test Address","customer_mobile":"01778855441","customer_email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":null,"zip":null,"country":null,"status":"1","balance":"0.00"},{"customer_id":"22","customer_name":"Mr John","customer_address":"chattagram","customer_mobile":"01841452343","customer_email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"","status":"1","balance":"0.00"},{"customer_id":"19","customer_name":"Mr Rahim","customer_address":"xyx","customer_mobile":"+8801949452343","customer_email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"4000","country":"Bangladesh","status":"1","balance":"0.00"},{"customer_id":"1","customer_name":"PaySenz Merchant1","customer_address":"Gulshan, Dhaka","customer_mobile":"+8801612312312","customer_email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":null,"zip":"","country":"Bangladesh","status":"1","balance":"0.00"}]
ERROR - 2025-03-16 06:27:49 --> DEBUG: Final JSON response -> [{"sl":1,"customer_name":"Americas Best Wings","address":"830 North Rolling Road","mobile":"4248669552","email":"nyemchow@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"21228","country":"United States","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/23\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(23)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":2,"customer_name":"Md. Faiz Shiraji","address":"80\/2 West Rampura","mobile":"01791631664","email":"faiz.shiraji@cloudwell.co","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"1219","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/15\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(15)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":3,"customer_name":"Mofajjol Hossain","address":"Test Address","mobile":"01778855441","email":"mofajjol@gmail.com","vat_no":null,"sales_permit_number":null,"sales_permit":"N\/A","zip":null,"country":null,"balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/20\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(20)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":4,"customer_name":"Mr John","address":"chattagram","mobile":"01841452343","email":"hyz@yahoo.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/22\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(22)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":5,"customer_name":"Mr Rahim","address":"xyx","mobile":"+8801949452343","email":"abc@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"4000","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/19\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(19)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"},{"sl":6,"customer_name":"PaySenz Merchant1","address":"Gulshan, Dhaka","mobile":"+8801612312312","email":"paysenz.merchant1@gmail.com","vat_no":"","sales_permit_number":null,"sales_permit":"N\/A","zip":"","country":"Bangladesh","balance":"0.00","status":"1","button":" <a href=\"http:\/\/localhost:8000\/edit_customer\/1\" \r\n              class=\"btn btn-info btn-xs m-b-5 custom_btn\" title=\"Update\">\r\n              <i class=\"pe-7s-note\"><\/i>\r\n          <\/a> <a onclick=\"customerdelete(1)\" href=\"javascript:void(0)\" \r\n              class=\"btn btn-danger btn-xs m-b-5 custom_btn\" title=\"Delete\">\r\n              <i class=\"pe-7s-trash\"><\/i>\r\n          <\/a>"}]
INFO - 2025-03-16 07:55:22 --> Config Class Initialized
INFO - 2025-03-16 07:55:22 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:22 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:22 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:22 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
DEBUG - 2025-03-16 07:55:22 --> No URI present. Default controller set.
INFO - 2025-03-16 07:55:22 --> Router Class Initialized
INFO - 2025-03-16 07:55:22 --> Output Class Initialized
INFO - 2025-03-16 07:55:22 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:22 --> Input Class Initialized
INFO - 2025-03-16 07:55:22 --> Language Class Initialized
INFO - 2025-03-16 07:55:22 --> Language Class Initialized
INFO - 2025-03-16 07:55:22 --> Config Class Initialized
INFO - 2025-03-16 07:55:22 --> Loader Class Initialized
INFO - 2025-03-16 07:55:22 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:22 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:22 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:22 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:22 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:22 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:22 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:22 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:22 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:22 --> Email Class Initialized
INFO - 2025-03-16 07:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:22 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:22 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:22 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:22 --> Auth MX_Controller Initialized
INFO - 2025-03-16 07:55:22 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 07:55:22 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 07:55:22 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 07:55:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 07:55:22 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:22 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/login.php
INFO - 2025-03-16 07:55:22 --> Final output sent to browser
DEBUG - 2025-03-16 07:55:22 --> Total execution time: 0.0446
INFO - 2025-03-16 07:55:33 --> Config Class Initialized
INFO - 2025-03-16 07:55:33 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:33 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:33 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:33 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 07:55:33 --> Router Class Initialized
INFO - 2025-03-16 07:55:33 --> Output Class Initialized
INFO - 2025-03-16 07:55:33 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:33 --> Input Class Initialized
INFO - 2025-03-16 07:55:33 --> Language Class Initialized
INFO - 2025-03-16 07:55:33 --> Language Class Initialized
INFO - 2025-03-16 07:55:33 --> Config Class Initialized
INFO - 2025-03-16 07:55:33 --> Loader Class Initialized
INFO - 2025-03-16 07:55:33 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:33 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:33 --> Email Class Initialized
INFO - 2025-03-16 07:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:33 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:33 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:33 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:33 --> Auth MX_Controller Initialized
INFO - 2025-03-16 07:55:33 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Auth_model.php
INFO - 2025-03-16 07:55:33 --> Model Class Initialized
INFO - 2025-03-16 07:55:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-03-16 07:55:33 --> Config Class Initialized
INFO - 2025-03-16 07:55:33 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:33 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:33 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:33 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/config/routes.php
INFO - 2025-03-16 07:55:33 --> Router Class Initialized
INFO - 2025-03-16 07:55:33 --> Output Class Initialized
INFO - 2025-03-16 07:55:33 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:33 --> Input Class Initialized
INFO - 2025-03-16 07:55:33 --> Language Class Initialized
INFO - 2025-03-16 07:55:33 --> Language Class Initialized
INFO - 2025-03-16 07:55:33 --> Config Class Initialized
INFO - 2025-03-16 07:55:33 --> Loader Class Initialized
INFO - 2025-03-16 07:55:33 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:33 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:33 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:33 --> Email Class Initialized
INFO - 2025-03-16 07:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:33 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:33 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:33 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:33 --> Home MX_Controller Initialized
INFO - 2025-03-16 07:55:33 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/models/Home_model.php
INFO - 2025-03-16 07:55:33 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 07:55:33 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 07:55:33 --> Model Class Initialized
ERROR - 2025-03-16 07:55:33 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 07:55:33 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 07:55:33 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 07:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/dashboard/views/home/home.php
DEBUG - 2025-03-16 07:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 07:55:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 07:55:34 --> Final output sent to browser
DEBUG - 2025-03-16 07:55:34 --> Total execution time: 0.6026
INFO - 2025-03-16 07:55:43 --> Config Class Initialized
INFO - 2025-03-16 07:55:43 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:43 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:43 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:43 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:55:43 --> Router Class Initialized
INFO - 2025-03-16 07:55:43 --> Output Class Initialized
INFO - 2025-03-16 07:55:43 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:43 --> Input Class Initialized
INFO - 2025-03-16 07:55:43 --> Language Class Initialized
INFO - 2025-03-16 07:55:43 --> Language Class Initialized
INFO - 2025-03-16 07:55:43 --> Config Class Initialized
INFO - 2025-03-16 07:55:43 --> Loader Class Initialized
INFO - 2025-03-16 07:55:43 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:43 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:43 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:43 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:43 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:43 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:43 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:43 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:43 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:43 --> Email Class Initialized
INFO - 2025-03-16 07:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:43 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:43 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:43 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:43 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:55:43 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:55:43 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 07:55:43 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 07:55:43 --> Model Class Initialized
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 64
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Undefined array key 85 /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
ERROR - 2025-03-16 07:55:43 --> Severity: Warning --> Attempt to read property "PHeadCode" on null /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php 66
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/treeview.php
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 07:55:43 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 07:55:43 --> Final output sent to browser
DEBUG - 2025-03-16 07:55:43 --> Total execution time: 0.1404
INFO - 2025-03-16 07:55:47 --> Config Class Initialized
INFO - 2025-03-16 07:55:47 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:47 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:47 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:47 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:55:47 --> Router Class Initialized
INFO - 2025-03-16 07:55:47 --> Output Class Initialized
INFO - 2025-03-16 07:55:47 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:47 --> Input Class Initialized
INFO - 2025-03-16 07:55:47 --> Language Class Initialized
INFO - 2025-03-16 07:55:47 --> Language Class Initialized
INFO - 2025-03-16 07:55:47 --> Config Class Initialized
INFO - 2025-03-16 07:55:47 --> Loader Class Initialized
INFO - 2025-03-16 07:55:47 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:47 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:47 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:47 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:47 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:47 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:47 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:47 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:47 --> Email Class Initialized
INFO - 2025-03-16 07:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:47 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:47 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:47 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:47 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:55:47 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:55:47 --> Model Class Initialized
INFO - 2025-03-16 07:55:47 --> Final output sent to browser
DEBUG - 2025-03-16 07:55:47 --> Total execution time: 0.0141
INFO - 2025-03-16 07:55:52 --> Config Class Initialized
INFO - 2025-03-16 07:55:52 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:52 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:52 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:52 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:55:52 --> Router Class Initialized
INFO - 2025-03-16 07:55:52 --> Output Class Initialized
INFO - 2025-03-16 07:55:52 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:52 --> Input Class Initialized
INFO - 2025-03-16 07:55:52 --> Language Class Initialized
INFO - 2025-03-16 07:55:52 --> Language Class Initialized
INFO - 2025-03-16 07:55:52 --> Config Class Initialized
INFO - 2025-03-16 07:55:52 --> Loader Class Initialized
INFO - 2025-03-16 07:55:52 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:52 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:52 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:52 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:52 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:52 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:52 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:52 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:52 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:52 --> Email Class Initialized
INFO - 2025-03-16 07:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:52 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:52 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:52 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:52 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:55:52 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:52 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:55:52 --> Model Class Initialized
INFO - 2025-03-16 07:55:52 --> Final output sent to browser
DEBUG - 2025-03-16 07:55:52 --> Total execution time: 0.0115
INFO - 2025-03-16 07:55:53 --> Config Class Initialized
INFO - 2025-03-16 07:55:53 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:53 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:53 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:53 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:55:53 --> Router Class Initialized
INFO - 2025-03-16 07:55:53 --> Output Class Initialized
INFO - 2025-03-16 07:55:53 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:53 --> Input Class Initialized
INFO - 2025-03-16 07:55:53 --> Language Class Initialized
INFO - 2025-03-16 07:55:53 --> Language Class Initialized
INFO - 2025-03-16 07:55:53 --> Config Class Initialized
INFO - 2025-03-16 07:55:53 --> Loader Class Initialized
INFO - 2025-03-16 07:55:53 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:53 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:53 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:53 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:53 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:53 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:53 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:53 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:53 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:53 --> Email Class Initialized
INFO - 2025-03-16 07:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:53 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:53 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:53 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:53 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:55:53 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:53 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:55:53 --> Model Class Initialized
INFO - 2025-03-16 07:55:53 --> Final output sent to browser
DEBUG - 2025-03-16 07:55:53 --> Total execution time: 0.0060
INFO - 2025-03-16 07:55:57 --> Config Class Initialized
INFO - 2025-03-16 07:55:57 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:55:57 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:55:57 --> Utf8 Class Initialized
INFO - 2025-03-16 07:55:57 --> URI Class Initialized
DEBUG - 2025-03-16 07:55:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:55:57 --> Router Class Initialized
INFO - 2025-03-16 07:55:57 --> Output Class Initialized
INFO - 2025-03-16 07:55:57 --> Security Class Initialized
DEBUG - 2025-03-16 07:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:55:57 --> Input Class Initialized
INFO - 2025-03-16 07:55:57 --> Language Class Initialized
INFO - 2025-03-16 07:55:57 --> Language Class Initialized
INFO - 2025-03-16 07:55:57 --> Config Class Initialized
INFO - 2025-03-16 07:55:57 --> Loader Class Initialized
INFO - 2025-03-16 07:55:57 --> Helper loaded: url_helper
INFO - 2025-03-16 07:55:57 --> Helper loaded: file_helper
INFO - 2025-03-16 07:55:57 --> Helper loaded: html_helper
INFO - 2025-03-16 07:55:57 --> Helper loaded: form_helper
INFO - 2025-03-16 07:55:57 --> Helper loaded: text_helper
INFO - 2025-03-16 07:55:57 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:55:57 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:55:57 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:55:57 --> Database Driver Class Initialized
INFO - 2025-03-16 07:55:57 --> Email Class Initialized
INFO - 2025-03-16 07:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:55:57 --> Form Validation Class Initialized
INFO - 2025-03-16 07:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:55:57 --> Pagination Class Initialized
INFO - 2025-03-16 07:55:57 --> Controller Class Initialized
DEBUG - 2025-03-16 07:55:57 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:55:57 --> Model Class Initialized
DEBUG - 2025-03-16 07:55:57 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:55:57 --> Model Class Initialized
INFO - 2025-03-16 07:55:57 --> Final output sent to browser
DEBUG - 2025-03-16 07:55:57 --> Total execution time: 0.0095
INFO - 2025-03-16 07:56:05 --> Config Class Initialized
INFO - 2025-03-16 07:56:05 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:56:05 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:56:05 --> Utf8 Class Initialized
INFO - 2025-03-16 07:56:05 --> URI Class Initialized
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:56:05 --> Router Class Initialized
INFO - 2025-03-16 07:56:05 --> Output Class Initialized
INFO - 2025-03-16 07:56:05 --> Security Class Initialized
DEBUG - 2025-03-16 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:56:05 --> Input Class Initialized
INFO - 2025-03-16 07:56:05 --> Language Class Initialized
INFO - 2025-03-16 07:56:05 --> Language Class Initialized
INFO - 2025-03-16 07:56:05 --> Config Class Initialized
INFO - 2025-03-16 07:56:05 --> Loader Class Initialized
INFO - 2025-03-16 07:56:05 --> Helper loaded: url_helper
INFO - 2025-03-16 07:56:05 --> Helper loaded: file_helper
INFO - 2025-03-16 07:56:05 --> Helper loaded: html_helper
INFO - 2025-03-16 07:56:05 --> Helper loaded: form_helper
INFO - 2025-03-16 07:56:05 --> Helper loaded: text_helper
INFO - 2025-03-16 07:56:05 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:56:05 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:56:05 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:56:05 --> Database Driver Class Initialized
INFO - 2025-03-16 07:56:05 --> Email Class Initialized
INFO - 2025-03-16 07:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:56:05 --> Form Validation Class Initialized
INFO - 2025-03-16 07:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:56:05 --> Pagination Class Initialized
INFO - 2025-03-16 07:56:05 --> Controller Class Initialized
DEBUG - 2025-03-16 07:56:05 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:56:05 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:56:05 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 07:56:05 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 07:56:05 --> Model Class Initialized
ERROR - 2025-03-16 07:56:05 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 07:56:05 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subaccount_list.php
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 07:56:05 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 07:56:05 --> Final output sent to browser
DEBUG - 2025-03-16 07:56:05 --> Total execution time: 0.2285
INFO - 2025-03-16 07:56:18 --> Config Class Initialized
INFO - 2025-03-16 07:56:18 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:56:18 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:56:18 --> Utf8 Class Initialized
INFO - 2025-03-16 07:56:18 --> URI Class Initialized
DEBUG - 2025-03-16 07:56:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:56:18 --> Router Class Initialized
INFO - 2025-03-16 07:56:18 --> Output Class Initialized
INFO - 2025-03-16 07:56:18 --> Security Class Initialized
DEBUG - 2025-03-16 07:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:56:18 --> Input Class Initialized
INFO - 2025-03-16 07:56:18 --> Language Class Initialized
INFO - 2025-03-16 07:56:18 --> Language Class Initialized
INFO - 2025-03-16 07:56:18 --> Config Class Initialized
INFO - 2025-03-16 07:56:18 --> Loader Class Initialized
INFO - 2025-03-16 07:56:18 --> Helper loaded: url_helper
INFO - 2025-03-16 07:56:18 --> Helper loaded: file_helper
INFO - 2025-03-16 07:56:18 --> Helper loaded: html_helper
INFO - 2025-03-16 07:56:18 --> Helper loaded: form_helper
INFO - 2025-03-16 07:56:18 --> Helper loaded: text_helper
INFO - 2025-03-16 07:56:18 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:56:18 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:56:18 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:56:18 --> Database Driver Class Initialized
INFO - 2025-03-16 07:56:18 --> Email Class Initialized
INFO - 2025-03-16 07:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:56:18 --> Form Validation Class Initialized
INFO - 2025-03-16 07:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:56:18 --> Pagination Class Initialized
INFO - 2025-03-16 07:56:18 --> Controller Class Initialized
DEBUG - 2025-03-16 07:56:18 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:56:18 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:56:18 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 07:56:18 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 07:56:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 07:56:18 --> Model Class Initialized
ERROR - 2025-03-16 07:56:18 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 07:56:18 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 07:56:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 07:56:18 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 07:56:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 07:56:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 07:56:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/predefined_accounts.php
DEBUG - 2025-03-16 07:56:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 07:56:19 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 07:56:19 --> Final output sent to browser
DEBUG - 2025-03-16 07:56:19 --> Total execution time: 0.2334
INFO - 2025-03-16 07:56:40 --> Config Class Initialized
INFO - 2025-03-16 07:56:40 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:56:40 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:56:40 --> Utf8 Class Initialized
INFO - 2025-03-16 07:56:40 --> URI Class Initialized
DEBUG - 2025-03-16 07:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:56:40 --> Router Class Initialized
INFO - 2025-03-16 07:56:40 --> Output Class Initialized
INFO - 2025-03-16 07:56:40 --> Security Class Initialized
DEBUG - 2025-03-16 07:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:56:40 --> Input Class Initialized
INFO - 2025-03-16 07:56:40 --> Language Class Initialized
INFO - 2025-03-16 07:56:40 --> Language Class Initialized
INFO - 2025-03-16 07:56:40 --> Config Class Initialized
INFO - 2025-03-16 07:56:40 --> Loader Class Initialized
INFO - 2025-03-16 07:56:40 --> Helper loaded: url_helper
INFO - 2025-03-16 07:56:40 --> Helper loaded: file_helper
INFO - 2025-03-16 07:56:40 --> Helper loaded: html_helper
INFO - 2025-03-16 07:56:40 --> Helper loaded: form_helper
INFO - 2025-03-16 07:56:40 --> Helper loaded: text_helper
INFO - 2025-03-16 07:56:40 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:56:40 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:56:40 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:56:40 --> Database Driver Class Initialized
INFO - 2025-03-16 07:56:40 --> Email Class Initialized
INFO - 2025-03-16 07:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:56:40 --> Form Validation Class Initialized
INFO - 2025-03-16 07:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:56:40 --> Pagination Class Initialized
INFO - 2025-03-16 07:56:40 --> Controller Class Initialized
DEBUG - 2025-03-16 07:56:40 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:56:40 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:56:40 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 07:56:40 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 07:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 07:56:40 --> Model Class Initialized
ERROR - 2025-03-16 07:56:40 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 07:56:40 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 07:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 07:56:40 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 07:56:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 07:56:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 07:56:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/financial_year_list.php
DEBUG - 2025-03-16 07:56:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 07:56:41 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 07:56:41 --> Final output sent to browser
DEBUG - 2025-03-16 07:56:41 --> Total execution time: 0.2159
INFO - 2025-03-16 07:56:50 --> Config Class Initialized
INFO - 2025-03-16 07:56:50 --> Hooks Class Initialized
DEBUG - 2025-03-16 07:56:50 --> UTF-8 Support Enabled
INFO - 2025-03-16 07:56:50 --> Utf8 Class Initialized
INFO - 2025-03-16 07:56:50 --> URI Class Initialized
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 07:56:50 --> Router Class Initialized
INFO - 2025-03-16 07:56:50 --> Output Class Initialized
INFO - 2025-03-16 07:56:50 --> Security Class Initialized
DEBUG - 2025-03-16 07:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 07:56:50 --> Input Class Initialized
INFO - 2025-03-16 07:56:50 --> Language Class Initialized
INFO - 2025-03-16 07:56:50 --> Language Class Initialized
INFO - 2025-03-16 07:56:50 --> Config Class Initialized
INFO - 2025-03-16 07:56:50 --> Loader Class Initialized
INFO - 2025-03-16 07:56:50 --> Helper loaded: url_helper
INFO - 2025-03-16 07:56:50 --> Helper loaded: file_helper
INFO - 2025-03-16 07:56:50 --> Helper loaded: html_helper
INFO - 2025-03-16 07:56:50 --> Helper loaded: form_helper
INFO - 2025-03-16 07:56:50 --> Helper loaded: text_helper
INFO - 2025-03-16 07:56:50 --> Helper loaded: lang_helper
INFO - 2025-03-16 07:56:50 --> Helper loaded: directory_helper
INFO - 2025-03-16 07:56:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 07:56:50 --> Database Driver Class Initialized
INFO - 2025-03-16 07:56:50 --> Email Class Initialized
INFO - 2025-03-16 07:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 07:56:50 --> Form Validation Class Initialized
INFO - 2025-03-16 07:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 07:56:50 --> Pagination Class Initialized
INFO - 2025-03-16 07:56:50 --> Controller Class Initialized
DEBUG - 2025-03-16 07:56:50 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 07:56:50 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 07:56:50 --> Model Class Initialized
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 07:56:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 07:56:50 --> Model Class Initialized
ERROR - 2025-03-16 07:56:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 07:56:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/opening_balance_list.php
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 07:56:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 07:56:50 --> Final output sent to browser
DEBUG - 2025-03-16 07:56:50 --> Total execution time: 0.0839
INFO - 2025-03-16 08:03:50 --> Config Class Initialized
INFO - 2025-03-16 08:03:50 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:03:50 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:03:50 --> Utf8 Class Initialized
INFO - 2025-03-16 08:03:50 --> URI Class Initialized
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:03:50 --> Router Class Initialized
INFO - 2025-03-16 08:03:50 --> Output Class Initialized
INFO - 2025-03-16 08:03:50 --> Security Class Initialized
DEBUG - 2025-03-16 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:03:50 --> Input Class Initialized
INFO - 2025-03-16 08:03:50 --> Language Class Initialized
INFO - 2025-03-16 08:03:50 --> Language Class Initialized
INFO - 2025-03-16 08:03:50 --> Config Class Initialized
INFO - 2025-03-16 08:03:50 --> Loader Class Initialized
INFO - 2025-03-16 08:03:50 --> Helper loaded: url_helper
INFO - 2025-03-16 08:03:50 --> Helper loaded: file_helper
INFO - 2025-03-16 08:03:50 --> Helper loaded: html_helper
INFO - 2025-03-16 08:03:50 --> Helper loaded: form_helper
INFO - 2025-03-16 08:03:50 --> Helper loaded: text_helper
INFO - 2025-03-16 08:03:50 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:03:50 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:03:50 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:03:50 --> Database Driver Class Initialized
INFO - 2025-03-16 08:03:50 --> Email Class Initialized
INFO - 2025-03-16 08:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:03:50 --> Form Validation Class Initialized
INFO - 2025-03-16 08:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:03:50 --> Pagination Class Initialized
INFO - 2025-03-16 08:03:50 --> Controller Class Initialized
DEBUG - 2025-03-16 08:03:50 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:03:50 --> Model Class Initialized
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:03:50 --> Model Class Initialized
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:03:50 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:03:50 --> Model Class Initialized
ERROR - 2025-03-16 08:03:50 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:03:50 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/cash_book.php
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:03:50 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:03:50 --> Final output sent to browser
DEBUG - 2025-03-16 08:03:50 --> Total execution time: 0.2827
INFO - 2025-03-16 08:04:03 --> Config Class Initialized
INFO - 2025-03-16 08:04:03 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:04:03 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:04:03 --> Utf8 Class Initialized
INFO - 2025-03-16 08:04:03 --> URI Class Initialized
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:04:03 --> Router Class Initialized
INFO - 2025-03-16 08:04:03 --> Output Class Initialized
INFO - 2025-03-16 08:04:03 --> Security Class Initialized
DEBUG - 2025-03-16 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:04:03 --> Input Class Initialized
INFO - 2025-03-16 08:04:03 --> Language Class Initialized
INFO - 2025-03-16 08:04:03 --> Language Class Initialized
INFO - 2025-03-16 08:04:03 --> Config Class Initialized
INFO - 2025-03-16 08:04:03 --> Loader Class Initialized
INFO - 2025-03-16 08:04:03 --> Helper loaded: url_helper
INFO - 2025-03-16 08:04:03 --> Helper loaded: file_helper
INFO - 2025-03-16 08:04:03 --> Helper loaded: html_helper
INFO - 2025-03-16 08:04:03 --> Helper loaded: form_helper
INFO - 2025-03-16 08:04:03 --> Helper loaded: text_helper
INFO - 2025-03-16 08:04:03 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:04:03 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:04:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:04:03 --> Database Driver Class Initialized
INFO - 2025-03-16 08:04:03 --> Email Class Initialized
INFO - 2025-03-16 08:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:04:03 --> Form Validation Class Initialized
INFO - 2025-03-16 08:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:04:03 --> Pagination Class Initialized
INFO - 2025-03-16 08:04:03 --> Controller Class Initialized
DEBUG - 2025-03-16 08:04:03 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:04:03 --> Model Class Initialized
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:04:03 --> Model Class Initialized
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:04:03 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:04:03 --> Model Class Initialized
ERROR - 2025-03-16 08:04:03 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:04:03 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/cash_book_report.php
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:04:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:04:03 --> Final output sent to browser
DEBUG - 2025-03-16 08:04:03 --> Total execution time: 0.1603
INFO - 2025-03-16 08:05:44 --> Config Class Initialized
INFO - 2025-03-16 08:05:44 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:05:44 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:05:44 --> Utf8 Class Initialized
INFO - 2025-03-16 08:05:44 --> URI Class Initialized
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:05:44 --> Router Class Initialized
INFO - 2025-03-16 08:05:44 --> Output Class Initialized
INFO - 2025-03-16 08:05:44 --> Security Class Initialized
DEBUG - 2025-03-16 08:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:05:44 --> Input Class Initialized
INFO - 2025-03-16 08:05:44 --> Language Class Initialized
INFO - 2025-03-16 08:05:44 --> Language Class Initialized
INFO - 2025-03-16 08:05:44 --> Config Class Initialized
INFO - 2025-03-16 08:05:44 --> Loader Class Initialized
INFO - 2025-03-16 08:05:44 --> Helper loaded: url_helper
INFO - 2025-03-16 08:05:44 --> Helper loaded: file_helper
INFO - 2025-03-16 08:05:44 --> Helper loaded: html_helper
INFO - 2025-03-16 08:05:44 --> Helper loaded: form_helper
INFO - 2025-03-16 08:05:44 --> Helper loaded: text_helper
INFO - 2025-03-16 08:05:44 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:05:44 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:05:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:05:44 --> Database Driver Class Initialized
INFO - 2025-03-16 08:05:44 --> Email Class Initialized
INFO - 2025-03-16 08:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:05:44 --> Form Validation Class Initialized
INFO - 2025-03-16 08:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:05:44 --> Pagination Class Initialized
INFO - 2025-03-16 08:05:44 --> Controller Class Initialized
DEBUG - 2025-03-16 08:05:44 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:05:44 --> Model Class Initialized
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:05:44 --> Model Class Initialized
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:05:44 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:05:44 --> Model Class Initialized
ERROR - 2025-03-16 08:05:44 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:05:44 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/credit_voucher_list.php
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:05:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:05:44 --> Final output sent to browser
DEBUG - 2025-03-16 08:05:44 --> Total execution time: 0.1395
INFO - 2025-03-16 08:05:45 --> Config Class Initialized
INFO - 2025-03-16 08:05:45 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:05:45 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:05:45 --> Utf8 Class Initialized
INFO - 2025-03-16 08:05:45 --> URI Class Initialized
DEBUG - 2025-03-16 08:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:05:45 --> Router Class Initialized
INFO - 2025-03-16 08:05:45 --> Output Class Initialized
INFO - 2025-03-16 08:05:45 --> Security Class Initialized
DEBUG - 2025-03-16 08:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:05:45 --> Input Class Initialized
INFO - 2025-03-16 08:05:45 --> Language Class Initialized
INFO - 2025-03-16 08:05:45 --> Language Class Initialized
INFO - 2025-03-16 08:05:45 --> Config Class Initialized
INFO - 2025-03-16 08:05:45 --> Loader Class Initialized
INFO - 2025-03-16 08:05:45 --> Helper loaded: url_helper
INFO - 2025-03-16 08:05:45 --> Helper loaded: file_helper
INFO - 2025-03-16 08:05:45 --> Helper loaded: html_helper
INFO - 2025-03-16 08:05:45 --> Helper loaded: form_helper
INFO - 2025-03-16 08:05:45 --> Helper loaded: text_helper
INFO - 2025-03-16 08:05:45 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:05:45 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:05:45 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:05:45 --> Database Driver Class Initialized
INFO - 2025-03-16 08:05:45 --> Email Class Initialized
INFO - 2025-03-16 08:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:05:45 --> Form Validation Class Initialized
INFO - 2025-03-16 08:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:05:45 --> Pagination Class Initialized
INFO - 2025-03-16 08:05:45 --> Controller Class Initialized
DEBUG - 2025-03-16 08:05:45 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:05:45 --> Model Class Initialized
DEBUG - 2025-03-16 08:05:45 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:05:45 --> Model Class Initialized
INFO - 2025-03-16 08:05:45 --> Final output sent to browser
DEBUG - 2025-03-16 08:05:45 --> Total execution time: 0.0080
INFO - 2025-03-16 08:05:54 --> Config Class Initialized
INFO - 2025-03-16 08:05:54 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:05:54 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:05:54 --> Utf8 Class Initialized
INFO - 2025-03-16 08:05:54 --> URI Class Initialized
DEBUG - 2025-03-16 08:05:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:05:54 --> Router Class Initialized
INFO - 2025-03-16 08:05:54 --> Output Class Initialized
INFO - 2025-03-16 08:05:54 --> Security Class Initialized
DEBUG - 2025-03-16 08:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:05:54 --> Input Class Initialized
INFO - 2025-03-16 08:05:54 --> Language Class Initialized
INFO - 2025-03-16 08:05:54 --> Language Class Initialized
INFO - 2025-03-16 08:05:54 --> Config Class Initialized
INFO - 2025-03-16 08:05:54 --> Loader Class Initialized
INFO - 2025-03-16 08:05:54 --> Helper loaded: url_helper
INFO - 2025-03-16 08:05:54 --> Helper loaded: file_helper
INFO - 2025-03-16 08:05:54 --> Helper loaded: html_helper
INFO - 2025-03-16 08:05:54 --> Helper loaded: form_helper
INFO - 2025-03-16 08:05:54 --> Helper loaded: text_helper
INFO - 2025-03-16 08:05:54 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:05:54 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:05:54 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:05:54 --> Database Driver Class Initialized
INFO - 2025-03-16 08:05:54 --> Email Class Initialized
INFO - 2025-03-16 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:05:54 --> Form Validation Class Initialized
INFO - 2025-03-16 08:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:05:54 --> Pagination Class Initialized
INFO - 2025-03-16 08:05:54 --> Controller Class Initialized
DEBUG - 2025-03-16 08:05:54 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:05:54 --> Model Class Initialized
DEBUG - 2025-03-16 08:05:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:05:54 --> Model Class Initialized
DEBUG - 2025-03-16 08:05:54 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/cv_view_details.php
INFO - 2025-03-16 08:05:54 --> Final output sent to browser
DEBUG - 2025-03-16 08:05:54 --> Total execution time: 0.0339
INFO - 2025-03-16 08:06:28 --> Config Class Initialized
INFO - 2025-03-16 08:06:28 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:06:28 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:06:28 --> Utf8 Class Initialized
INFO - 2025-03-16 08:06:28 --> URI Class Initialized
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:06:28 --> Router Class Initialized
INFO - 2025-03-16 08:06:28 --> Output Class Initialized
INFO - 2025-03-16 08:06:28 --> Security Class Initialized
DEBUG - 2025-03-16 08:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:06:28 --> Input Class Initialized
INFO - 2025-03-16 08:06:28 --> Language Class Initialized
INFO - 2025-03-16 08:06:28 --> Language Class Initialized
INFO - 2025-03-16 08:06:28 --> Config Class Initialized
INFO - 2025-03-16 08:06:28 --> Loader Class Initialized
INFO - 2025-03-16 08:06:28 --> Helper loaded: url_helper
INFO - 2025-03-16 08:06:28 --> Helper loaded: file_helper
INFO - 2025-03-16 08:06:28 --> Helper loaded: html_helper
INFO - 2025-03-16 08:06:28 --> Helper loaded: form_helper
INFO - 2025-03-16 08:06:28 --> Helper loaded: text_helper
INFO - 2025-03-16 08:06:28 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:06:28 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:06:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:06:28 --> Database Driver Class Initialized
INFO - 2025-03-16 08:06:28 --> Email Class Initialized
INFO - 2025-03-16 08:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:06:28 --> Form Validation Class Initialized
INFO - 2025-03-16 08:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:06:28 --> Pagination Class Initialized
INFO - 2025-03-16 08:06:28 --> Controller Class Initialized
DEBUG - 2025-03-16 08:06:28 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:06:28 --> Model Class Initialized
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:06:28 --> Model Class Initialized
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:06:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:06:28 --> Model Class Initialized
ERROR - 2025-03-16 08:06:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:06:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/subaccount_list.php
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:06:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:06:28 --> Final output sent to browser
DEBUG - 2025-03-16 08:06:28 --> Total execution time: 0.1919
INFO - 2025-03-16 08:06:39 --> Config Class Initialized
INFO - 2025-03-16 08:06:39 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:06:39 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:06:39 --> Utf8 Class Initialized
INFO - 2025-03-16 08:06:39 --> URI Class Initialized
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:06:39 --> Router Class Initialized
INFO - 2025-03-16 08:06:39 --> Output Class Initialized
INFO - 2025-03-16 08:06:39 --> Security Class Initialized
DEBUG - 2025-03-16 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:06:39 --> Input Class Initialized
INFO - 2025-03-16 08:06:39 --> Language Class Initialized
INFO - 2025-03-16 08:06:39 --> Language Class Initialized
INFO - 2025-03-16 08:06:39 --> Config Class Initialized
INFO - 2025-03-16 08:06:39 --> Loader Class Initialized
INFO - 2025-03-16 08:06:39 --> Helper loaded: url_helper
INFO - 2025-03-16 08:06:39 --> Helper loaded: file_helper
INFO - 2025-03-16 08:06:39 --> Helper loaded: html_helper
INFO - 2025-03-16 08:06:39 --> Helper loaded: form_helper
INFO - 2025-03-16 08:06:39 --> Helper loaded: text_helper
INFO - 2025-03-16 08:06:39 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:06:39 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:06:39 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:06:39 --> Database Driver Class Initialized
INFO - 2025-03-16 08:06:39 --> Email Class Initialized
INFO - 2025-03-16 08:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:06:39 --> Form Validation Class Initialized
INFO - 2025-03-16 08:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:06:39 --> Pagination Class Initialized
INFO - 2025-03-16 08:06:39 --> Controller Class Initialized
DEBUG - 2025-03-16 08:06:39 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:06:39 --> Model Class Initialized
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:06:39 --> Model Class Initialized
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:06:39 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:06:39 --> Model Class Initialized
ERROR - 2025-03-16 08:06:39 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:06:39 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/general_ledger.php
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:06:39 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:06:39 --> Final output sent to browser
DEBUG - 2025-03-16 08:06:39 --> Total execution time: 0.1763
INFO - 2025-03-16 08:06:58 --> Config Class Initialized
INFO - 2025-03-16 08:06:58 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:06:58 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:06:58 --> Utf8 Class Initialized
INFO - 2025-03-16 08:06:58 --> URI Class Initialized
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:06:58 --> Router Class Initialized
INFO - 2025-03-16 08:06:58 --> Output Class Initialized
INFO - 2025-03-16 08:06:58 --> Security Class Initialized
DEBUG - 2025-03-16 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:06:58 --> Input Class Initialized
INFO - 2025-03-16 08:06:58 --> Language Class Initialized
INFO - 2025-03-16 08:06:58 --> Language Class Initialized
INFO - 2025-03-16 08:06:58 --> Config Class Initialized
INFO - 2025-03-16 08:06:58 --> Loader Class Initialized
INFO - 2025-03-16 08:06:58 --> Helper loaded: url_helper
INFO - 2025-03-16 08:06:58 --> Helper loaded: file_helper
INFO - 2025-03-16 08:06:58 --> Helper loaded: html_helper
INFO - 2025-03-16 08:06:58 --> Helper loaded: form_helper
INFO - 2025-03-16 08:06:58 --> Helper loaded: text_helper
INFO - 2025-03-16 08:06:58 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:06:58 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:06:58 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:06:58 --> Database Driver Class Initialized
INFO - 2025-03-16 08:06:58 --> Email Class Initialized
INFO - 2025-03-16 08:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:06:58 --> Form Validation Class Initialized
INFO - 2025-03-16 08:06:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:06:58 --> Pagination Class Initialized
INFO - 2025-03-16 08:06:58 --> Controller Class Initialized
DEBUG - 2025-03-16 08:06:58 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:06:58 --> Model Class Initialized
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:06:58 --> Model Class Initialized
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:06:58 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:06:58 --> Model Class Initialized
ERROR - 2025-03-16 08:06:58 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:06:58 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/general_ledger_report.php
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:06:58 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:06:58 --> Final output sent to browser
DEBUG - 2025-03-16 08:06:58 --> Total execution time: 0.1842
INFO - 2025-03-16 08:07:26 --> Config Class Initialized
INFO - 2025-03-16 08:07:26 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:07:26 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:07:26 --> Utf8 Class Initialized
INFO - 2025-03-16 08:07:26 --> URI Class Initialized
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:07:26 --> Router Class Initialized
INFO - 2025-03-16 08:07:26 --> Output Class Initialized
INFO - 2025-03-16 08:07:26 --> Security Class Initialized
DEBUG - 2025-03-16 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:07:26 --> Input Class Initialized
INFO - 2025-03-16 08:07:26 --> Language Class Initialized
INFO - 2025-03-16 08:07:26 --> Language Class Initialized
INFO - 2025-03-16 08:07:26 --> Config Class Initialized
INFO - 2025-03-16 08:07:26 --> Loader Class Initialized
INFO - 2025-03-16 08:07:26 --> Helper loaded: url_helper
INFO - 2025-03-16 08:07:26 --> Helper loaded: file_helper
INFO - 2025-03-16 08:07:26 --> Helper loaded: html_helper
INFO - 2025-03-16 08:07:26 --> Helper loaded: form_helper
INFO - 2025-03-16 08:07:26 --> Helper loaded: text_helper
INFO - 2025-03-16 08:07:26 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:07:26 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:07:26 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:07:26 --> Database Driver Class Initialized
INFO - 2025-03-16 08:07:26 --> Email Class Initialized
INFO - 2025-03-16 08:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:07:26 --> Form Validation Class Initialized
INFO - 2025-03-16 08:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:07:26 --> Pagination Class Initialized
INFO - 2025-03-16 08:07:26 --> Controller Class Initialized
DEBUG - 2025-03-16 08:07:26 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:07:26 --> Model Class Initialized
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:07:26 --> Model Class Initialized
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:07:26 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:07:26 --> Model Class Initialized
ERROR - 2025-03-16 08:07:26 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:07:26 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/contra_voucher_list.php
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:07:26 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:07:26 --> Final output sent to browser
DEBUG - 2025-03-16 08:07:26 --> Total execution time: 0.1733
INFO - 2025-03-16 08:07:34 --> Config Class Initialized
INFO - 2025-03-16 08:07:34 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:07:34 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:07:34 --> Utf8 Class Initialized
INFO - 2025-03-16 08:07:34 --> URI Class Initialized
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:07:34 --> Router Class Initialized
INFO - 2025-03-16 08:07:34 --> Output Class Initialized
INFO - 2025-03-16 08:07:34 --> Security Class Initialized
DEBUG - 2025-03-16 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:07:34 --> Input Class Initialized
INFO - 2025-03-16 08:07:34 --> Language Class Initialized
INFO - 2025-03-16 08:07:34 --> Language Class Initialized
INFO - 2025-03-16 08:07:34 --> Config Class Initialized
INFO - 2025-03-16 08:07:34 --> Loader Class Initialized
INFO - 2025-03-16 08:07:34 --> Helper loaded: url_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: file_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: html_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: form_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: text_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:07:34 --> Database Driver Class Initialized
INFO - 2025-03-16 08:07:34 --> Email Class Initialized
INFO - 2025-03-16 08:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:07:34 --> Form Validation Class Initialized
INFO - 2025-03-16 08:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:07:34 --> Pagination Class Initialized
INFO - 2025-03-16 08:07:34 --> Controller Class Initialized
DEBUG - 2025-03-16 08:07:34 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:07:34 --> Model Class Initialized
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:07:34 --> Model Class Initialized
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:07:34 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:07:34 --> Model Class Initialized
ERROR - 2025-03-16 08:07:34 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:07:34 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/credit_voucher_list.php
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:07:34 --> Final output sent to browser
DEBUG - 2025-03-16 08:07:34 --> Total execution time: 0.1825
INFO - 2025-03-16 08:07:34 --> Config Class Initialized
INFO - 2025-03-16 08:07:34 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:07:34 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:07:34 --> Utf8 Class Initialized
INFO - 2025-03-16 08:07:34 --> URI Class Initialized
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:07:34 --> Router Class Initialized
INFO - 2025-03-16 08:07:34 --> Output Class Initialized
INFO - 2025-03-16 08:07:34 --> Security Class Initialized
DEBUG - 2025-03-16 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:07:34 --> Input Class Initialized
INFO - 2025-03-16 08:07:34 --> Language Class Initialized
INFO - 2025-03-16 08:07:34 --> Language Class Initialized
INFO - 2025-03-16 08:07:34 --> Config Class Initialized
INFO - 2025-03-16 08:07:34 --> Loader Class Initialized
INFO - 2025-03-16 08:07:34 --> Helper loaded: url_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: file_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: html_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: form_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: text_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:07:34 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:07:34 --> Database Driver Class Initialized
INFO - 2025-03-16 08:07:34 --> Email Class Initialized
INFO - 2025-03-16 08:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:07:34 --> Form Validation Class Initialized
INFO - 2025-03-16 08:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:07:34 --> Pagination Class Initialized
INFO - 2025-03-16 08:07:34 --> Controller Class Initialized
DEBUG - 2025-03-16 08:07:34 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:07:34 --> Model Class Initialized
DEBUG - 2025-03-16 08:07:34 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:07:34 --> Model Class Initialized
INFO - 2025-03-16 08:07:34 --> Final output sent to browser
DEBUG - 2025-03-16 08:07:34 --> Total execution time: 0.0082
INFO - 2025-03-16 08:07:44 --> Config Class Initialized
INFO - 2025-03-16 08:07:44 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:07:44 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:07:44 --> Utf8 Class Initialized
INFO - 2025-03-16 08:07:44 --> URI Class Initialized
DEBUG - 2025-03-16 08:07:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:07:44 --> Router Class Initialized
INFO - 2025-03-16 08:07:44 --> Output Class Initialized
INFO - 2025-03-16 08:07:44 --> Security Class Initialized
DEBUG - 2025-03-16 08:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:07:44 --> Input Class Initialized
INFO - 2025-03-16 08:07:44 --> Language Class Initialized
INFO - 2025-03-16 08:07:44 --> Language Class Initialized
INFO - 2025-03-16 08:07:44 --> Config Class Initialized
INFO - 2025-03-16 08:07:44 --> Loader Class Initialized
INFO - 2025-03-16 08:07:44 --> Helper loaded: url_helper
INFO - 2025-03-16 08:07:44 --> Helper loaded: file_helper
INFO - 2025-03-16 08:07:44 --> Helper loaded: html_helper
INFO - 2025-03-16 08:07:44 --> Helper loaded: form_helper
INFO - 2025-03-16 08:07:44 --> Helper loaded: text_helper
INFO - 2025-03-16 08:07:44 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:07:44 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:07:44 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:07:44 --> Database Driver Class Initialized
INFO - 2025-03-16 08:07:44 --> Email Class Initialized
INFO - 2025-03-16 08:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:07:44 --> Form Validation Class Initialized
INFO - 2025-03-16 08:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:07:44 --> Pagination Class Initialized
INFO - 2025-03-16 08:07:44 --> Controller Class Initialized
DEBUG - 2025-03-16 08:07:44 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:07:44 --> Model Class Initialized
DEBUG - 2025-03-16 08:07:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:07:44 --> Model Class Initialized
DEBUG - 2025-03-16 08:07:44 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/cv_view_details.php
INFO - 2025-03-16 08:07:44 --> Final output sent to browser
DEBUG - 2025-03-16 08:07:44 --> Total execution time: 0.0301
INFO - 2025-03-16 08:11:47 --> Config Class Initialized
INFO - 2025-03-16 08:11:47 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:11:47 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:11:47 --> Utf8 Class Initialized
INFO - 2025-03-16 08:11:47 --> URI Class Initialized
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:11:47 --> Router Class Initialized
INFO - 2025-03-16 08:11:47 --> Output Class Initialized
INFO - 2025-03-16 08:11:47 --> Security Class Initialized
DEBUG - 2025-03-16 08:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:11:47 --> Input Class Initialized
INFO - 2025-03-16 08:11:47 --> Language Class Initialized
INFO - 2025-03-16 08:11:47 --> Language Class Initialized
INFO - 2025-03-16 08:11:47 --> Config Class Initialized
INFO - 2025-03-16 08:11:47 --> Loader Class Initialized
INFO - 2025-03-16 08:11:47 --> Helper loaded: url_helper
INFO - 2025-03-16 08:11:47 --> Helper loaded: file_helper
INFO - 2025-03-16 08:11:47 --> Helper loaded: html_helper
INFO - 2025-03-16 08:11:47 --> Helper loaded: form_helper
INFO - 2025-03-16 08:11:47 --> Helper loaded: text_helper
INFO - 2025-03-16 08:11:47 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:11:47 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:11:47 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:11:47 --> Database Driver Class Initialized
INFO - 2025-03-16 08:11:47 --> Email Class Initialized
INFO - 2025-03-16 08:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:11:47 --> Form Validation Class Initialized
INFO - 2025-03-16 08:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:11:47 --> Pagination Class Initialized
INFO - 2025-03-16 08:11:47 --> Controller Class Initialized
DEBUG - 2025-03-16 08:11:47 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:11:47 --> Model Class Initialized
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:11:47 --> Model Class Initialized
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:11:47 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:11:47 --> Model Class Initialized
ERROR - 2025-03-16 08:11:47 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:11:47 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
ERROR - 2025-03-16 08:11:47 --> Severity: Warning --> Undefined variable $dtpFromDate /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/coa_print.php 46
ERROR - 2025-03-16 08:11:47 --> Severity: Warning --> Undefined variable $dtpToDate /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/coa_print.php 46
ERROR - 2025-03-16 08:11:47 --> Severity: Warning --> Undefined variable $dtpFromDate /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/coa_print.php 78
ERROR - 2025-03-16 08:11:47 --> Severity: Warning --> Undefined variable $dtpToDate /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/coa_print.php 78
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/coa_print.php
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:11:47 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:11:47 --> Final output sent to browser
DEBUG - 2025-03-16 08:11:47 --> Total execution time: 0.2110
INFO - 2025-03-16 08:12:02 --> Config Class Initialized
INFO - 2025-03-16 08:12:02 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:02 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:02 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:02 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-16 08:12:02 --> Router Class Initialized
INFO - 2025-03-16 08:12:02 --> Output Class Initialized
INFO - 2025-03-16 08:12:02 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:02 --> Input Class Initialized
INFO - 2025-03-16 08:12:02 --> Language Class Initialized
INFO - 2025-03-16 08:12:02 --> Language Class Initialized
INFO - 2025-03-16 08:12:02 --> Config Class Initialized
INFO - 2025-03-16 08:12:02 --> Loader Class Initialized
INFO - 2025-03-16 08:12:02 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:02 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:02 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:02 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:02 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:02 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:02 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:02 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:02 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:02 --> Email Class Initialized
INFO - 2025-03-16 08:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:02 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:02 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:02 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:02 --> Report MX_Controller Initialized
INFO - 2025-03-16 08:12:02 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-16 08:12:02 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:12:02 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:12:02 --> Model Class Initialized
ERROR - 2025-03-16 08:12:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:12:02 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/due_report.php
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:12:02 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:12:02 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:02 --> Total execution time: 0.1902
INFO - 2025-03-16 08:12:03 --> Config Class Initialized
INFO - 2025-03-16 08:12:03 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:03 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:03 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:03 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-16 08:12:03 --> Router Class Initialized
INFO - 2025-03-16 08:12:03 --> Output Class Initialized
INFO - 2025-03-16 08:12:03 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:03 --> Input Class Initialized
INFO - 2025-03-16 08:12:03 --> Language Class Initialized
INFO - 2025-03-16 08:12:03 --> Language Class Initialized
INFO - 2025-03-16 08:12:03 --> Config Class Initialized
INFO - 2025-03-16 08:12:03 --> Loader Class Initialized
INFO - 2025-03-16 08:12:03 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:03 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:03 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:03 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:03 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:03 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:03 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:03 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:03 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:03 --> Email Class Initialized
INFO - 2025-03-16 08:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:03 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:03 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:03 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:03 --> Report MX_Controller Initialized
INFO - 2025-03-16 08:12:03 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:03 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-16 08:12:03 --> Model Class Initialized
INFO - 2025-03-16 08:12:03 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:03 --> Total execution time: 0.0096
INFO - 2025-03-16 08:12:15 --> Config Class Initialized
INFO - 2025-03-16 08:12:15 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:15 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:15 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:15 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-16 08:12:15 --> Router Class Initialized
INFO - 2025-03-16 08:12:15 --> Output Class Initialized
INFO - 2025-03-16 08:12:15 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:15 --> Input Class Initialized
INFO - 2025-03-16 08:12:15 --> Language Class Initialized
INFO - 2025-03-16 08:12:15 --> Language Class Initialized
INFO - 2025-03-16 08:12:15 --> Config Class Initialized
INFO - 2025-03-16 08:12:15 --> Loader Class Initialized
INFO - 2025-03-16 08:12:15 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:15 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:15 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:15 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:15 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:15 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:15 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:15 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:15 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:15 --> Email Class Initialized
INFO - 2025-03-16 08:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:15 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:15 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:15 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:15 --> Report MX_Controller Initialized
INFO - 2025-03-16 08:12:15 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:15 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-16 08:12:15 --> Model Class Initialized
INFO - 2025-03-16 08:12:15 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:15 --> Total execution time: 0.0147
INFO - 2025-03-16 08:12:16 --> Config Class Initialized
INFO - 2025-03-16 08:12:16 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:16 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:16 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:16 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-16 08:12:16 --> Router Class Initialized
INFO - 2025-03-16 08:12:16 --> Output Class Initialized
INFO - 2025-03-16 08:12:16 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:16 --> Input Class Initialized
INFO - 2025-03-16 08:12:16 --> Language Class Initialized
INFO - 2025-03-16 08:12:16 --> Language Class Initialized
INFO - 2025-03-16 08:12:16 --> Config Class Initialized
INFO - 2025-03-16 08:12:16 --> Loader Class Initialized
INFO - 2025-03-16 08:12:16 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:16 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:16 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:16 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:16 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:16 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:16 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:16 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:16 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:16 --> Email Class Initialized
INFO - 2025-03-16 08:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:16 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:16 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:16 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:16 --> Report MX_Controller Initialized
INFO - 2025-03-16 08:12:16 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:16 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-16 08:12:16 --> Model Class Initialized
INFO - 2025-03-16 08:12:16 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:16 --> Total execution time: 0.0172
INFO - 2025-03-16 08:12:28 --> Config Class Initialized
INFO - 2025-03-16 08:12:28 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:28 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:28 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:28 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:12:28 --> Router Class Initialized
INFO - 2025-03-16 08:12:28 --> Output Class Initialized
INFO - 2025-03-16 08:12:28 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:28 --> Input Class Initialized
INFO - 2025-03-16 08:12:28 --> Language Class Initialized
INFO - 2025-03-16 08:12:28 --> Language Class Initialized
INFO - 2025-03-16 08:12:28 --> Config Class Initialized
INFO - 2025-03-16 08:12:28 --> Loader Class Initialized
INFO - 2025-03-16 08:12:28 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:28 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:28 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:28 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:28 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:28 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:28 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:28 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:28 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:28 --> Email Class Initialized
INFO - 2025-03-16 08:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:28 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:28 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:28 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:28 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:12:28 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:12:28 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:12:28 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:12:28 --> Model Class Initialized
ERROR - 2025-03-16 08:12:28 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:12:28 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/views/credit_voucher_list.php
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:12:28 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:12:28 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:28 --> Total execution time: 0.1775
INFO - 2025-03-16 08:12:29 --> Config Class Initialized
INFO - 2025-03-16 08:12:29 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:29 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:29 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:29 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/config/routes.php
INFO - 2025-03-16 08:12:29 --> Router Class Initialized
INFO - 2025-03-16 08:12:29 --> Output Class Initialized
INFO - 2025-03-16 08:12:29 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:29 --> Input Class Initialized
INFO - 2025-03-16 08:12:29 --> Language Class Initialized
INFO - 2025-03-16 08:12:29 --> Language Class Initialized
INFO - 2025-03-16 08:12:29 --> Config Class Initialized
INFO - 2025-03-16 08:12:29 --> Loader Class Initialized
INFO - 2025-03-16 08:12:29 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:29 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:29 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:29 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:29 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:29 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:29 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:29 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:29 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:29 --> Email Class Initialized
INFO - 2025-03-16 08:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:29 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:29 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:29 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:29 --> Accounts MX_Controller Initialized
INFO - 2025-03-16 08:12:29 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:29 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/account/models/Accounts_model.php
INFO - 2025-03-16 08:12:29 --> Model Class Initialized
INFO - 2025-03-16 08:12:29 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:29 --> Total execution time: 0.0092
INFO - 2025-03-16 08:12:36 --> Config Class Initialized
INFO - 2025-03-16 08:12:36 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:36 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:36 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:36 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-16 08:12:36 --> Router Class Initialized
INFO - 2025-03-16 08:12:36 --> Output Class Initialized
INFO - 2025-03-16 08:12:36 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:36 --> Input Class Initialized
INFO - 2025-03-16 08:12:36 --> Language Class Initialized
INFO - 2025-03-16 08:12:36 --> Language Class Initialized
INFO - 2025-03-16 08:12:36 --> Config Class Initialized
INFO - 2025-03-16 08:12:36 --> Loader Class Initialized
INFO - 2025-03-16 08:12:36 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:36 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:36 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:36 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:36 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:36 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:36 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:36 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:36 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:36 --> Email Class Initialized
INFO - 2025-03-16 08:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:36 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:36 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:36 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:36 --> Report MX_Controller Initialized
INFO - 2025-03-16 08:12:36 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-16 08:12:36 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/controllers/../modules/template/controllers/Template.php
DEBUG - 2025-03-16 08:12:36 --> Template MX_Controller Initialized
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/models/Template_model.php
INFO - 2025-03-16 08:12:36 --> Model Class Initialized
ERROR - 2025-03-16 08:12:36 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
ERROR - 2025-03-16 08:12:36 --> Severity: Warning --> file_get_contents(https://update.paysenz.com/saleserp/autoupdate/update_info): Failed to open stream: php_network_getaddresses: getaddrinfo for update.paysenz.com failed: nodename nor servname provided, or not known /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/controllers/Template.php 30
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/head.php
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/header.php
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/sidebar.php
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/messages.php
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/views/due_report.php
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/includes/js.php
DEBUG - 2025-03-16 08:12:36 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/template/views/layout.php
INFO - 2025-03-16 08:12:36 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:36 --> Total execution time: 0.1027
INFO - 2025-03-16 08:12:37 --> Config Class Initialized
INFO - 2025-03-16 08:12:37 --> Hooks Class Initialized
DEBUG - 2025-03-16 08:12:37 --> UTF-8 Support Enabled
INFO - 2025-03-16 08:12:37 --> Utf8 Class Initialized
INFO - 2025-03-16 08:12:37 --> URI Class Initialized
DEBUG - 2025-03-16 08:12:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/config/routes.php
INFO - 2025-03-16 08:12:37 --> Router Class Initialized
INFO - 2025-03-16 08:12:37 --> Output Class Initialized
INFO - 2025-03-16 08:12:37 --> Security Class Initialized
DEBUG - 2025-03-16 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-16 08:12:37 --> Input Class Initialized
INFO - 2025-03-16 08:12:37 --> Language Class Initialized
INFO - 2025-03-16 08:12:37 --> Language Class Initialized
INFO - 2025-03-16 08:12:37 --> Config Class Initialized
INFO - 2025-03-16 08:12:37 --> Loader Class Initialized
INFO - 2025-03-16 08:12:37 --> Helper loaded: url_helper
INFO - 2025-03-16 08:12:37 --> Helper loaded: file_helper
INFO - 2025-03-16 08:12:37 --> Helper loaded: html_helper
INFO - 2025-03-16 08:12:37 --> Helper loaded: form_helper
INFO - 2025-03-16 08:12:37 --> Helper loaded: text_helper
INFO - 2025-03-16 08:12:37 --> Helper loaded: lang_helper
INFO - 2025-03-16 08:12:37 --> Helper loaded: directory_helper
INFO - 2025-03-16 08:12:37 --> Helper loaded: dompdf_helper
INFO - 2025-03-16 08:12:37 --> Database Driver Class Initialized
INFO - 2025-03-16 08:12:37 --> Email Class Initialized
INFO - 2025-03-16 08:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-03-16 08:12:37 --> Form Validation Class Initialized
INFO - 2025-03-16 08:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-03-16 08:12:37 --> Pagination Class Initialized
INFO - 2025-03-16 08:12:37 --> Controller Class Initialized
DEBUG - 2025-03-16 08:12:37 --> Report MX_Controller Initialized
INFO - 2025-03-16 08:12:37 --> Model Class Initialized
DEBUG - 2025-03-16 08:12:37 --> File loaded: /Users/faiz.shiraji/Sites/GenITech_B2B/application/modules/report/models/Report_model.php
INFO - 2025-03-16 08:12:37 --> Model Class Initialized
INFO - 2025-03-16 08:12:37 --> Final output sent to browser
DEBUG - 2025-03-16 08:12:37 --> Total execution time: 0.0064
